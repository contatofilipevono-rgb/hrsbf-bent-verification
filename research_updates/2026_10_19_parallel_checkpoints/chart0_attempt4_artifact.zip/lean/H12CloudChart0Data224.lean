import H12CloudChart0Data223

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env56728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,4177,32768,33166,37033,37151,1024,32768,37892,33141,33860,1142,380,33813,5522,4177,37113,34928,504,33276,257,1108,37032,512]

theorem envBound56728 : H12AffineFastState.Bounded env56728 := by
  intro p hp
  have h : env56728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56727_56728 : H12AffineEnvironment.transform 13 4177 env56727 = env56728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56727 == env56728) = true)

theorem identity56728 : scanCanonicalize (H12AffineFastState.compose env56728 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound56728 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,501,4177,32768,33166,37033,37151,1024,32768,37892,33141,33860,1142,380,33813,5522,4177,37113,34682,504,33276,257,1108,37032,512]

theorem envBound56729 : H12AffineFastState.Bounded env56729 := by
  intro p hp
  have h : env56729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56728_56729 : H12AffineEnvironment.transform 10 1802 env56728 = env56729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env56728 == env56729) = true)

theorem identity56729 : scanCanonicalize (H12AffineFastState.compose env56729 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound56729 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,501,4177,341,219,4604,4170,1024,341,5457,32,1297,1142,380,1344,5522,4177,4524,1583,504,169,257,1108,4605,512]

theorem envBound56730 : H12AffineFastState.Bounded env56730 := by
  intro p hp
  have h : env56730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56729_56730 : H12AffineEnvironment.transform 14 341 env56729 = env56730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env56729 == env56730) = true)

def env56731 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,4096,301,4177,341,3,4388,4170,1024,341,5457,32,1297,1142,380,1344,5450,4177,4468,1583,288,113,257,1108,4389,512]

theorem envBound56731 : H12AffineFastState.Bounded env56731 := by
  intro p hp
  have h : env56731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56730_56731 : H12AffineEnvironment.transform 6 88 env56730 = env56731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env56730 == env56731) = true)

def env56732 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,0,301,81,341,3,292,74,1024,341,1361,32,1297,1142,380,1344,1354,81,372,1583,288,113,257,1108,293,512]

theorem envBound56732 : H12AffineFastState.Bounded env56732 := by
  intro p hp
  have h : env56732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56731_56732 : H12AffineEnvironment.transform 11 0 env56731 = env56732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56731 == env56732) = true)

theorem identity56732 : scanCanonicalize (H12AffineFastState.compose env56732 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56733 : List Nat := [2,4,8,16,32,64,88,20,512,1024,1566,0,57,81,65,3,48,74,1024,65,1093,32,1029,1142,104,1108,1118,81,96,1583,52,113,21,1108,49,512]

theorem envBound56733 : H12AffineFastState.Bounded env56733 := by
  intro p hp
  have h : env56733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56732_56733 : H12AffineEnvironment.transform 7 20 env56732 = env56733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56732 == env56733) = true)

theorem identity56733 : scanCanonicalize (H12AffineFastState.compose env56733 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 639) := by decide +kernel

theorem selectedBound56733 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56734 : List Nat := [2,4,8,16,32,64,88,20,512,639,97,0,57,81,65,3,48,74,639,65,570,32,634,521,104,555,545,81,96,80,52,113,21,555,49,512]

theorem envBound56734 : H12AffineFastState.Bounded env56734 := by
  intro p hp
  have h : env56734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56733_56734 : H12AffineEnvironment.transform 9 639 env56733 = env56734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 639 env56733 == env56734) = true)

theorem identity56734 : scanCanonicalize (H12AffineFastState.compose env56734 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound56734 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56735 : List Nat := [2,4,8,16,32,64,88,20,32,95,97,0,57,81,65,3,48,74,95,65,26,32,90,41,104,11,1,81,96,80,52,113,21,11,49,32]

theorem envBound56735 : H12AffineFastState.Bounded env56735 := by
  intro p hp
  have h : env56735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56734_56735 : H12AffineEnvironment.transform 8 32 env56734 = env56735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env56734 == env56735) = true)

theorem identity56735 : scanCanonicalize (H12AffineFastState.compose env56735 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound56735 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env56736 : List Nat := [2,4,8,16,32,59,35,20,32,36,26,0,57,42,58,3,48,49,36,58,26,32,33,41,19,11,1,42,27,43,52,10,21,11,49,32]

theorem envBound56736 : H12AffineFastState.Bounded env56736 := by
  intro p hp
  have h : env56736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56735_56736 : H12AffineEnvironment.transform 5 59 env56735 = env56736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env56735 == env56736) = true)

theorem identity56736 : scanCanonicalize (H12AffineFastState.compose env56736 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56737 : List Nat := [2,4,8,16,16,11,19,20,16,20,26,0,9,26,10,3,0,1,20,10,26,16,17,25,19,11,1,26,27,27,4,10,21,11,1,16]

theorem envBound56737 : H12AffineFastState.Bounded env56737 := by
  intro p hp
  have h : env56737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56736_56737 : H12AffineEnvironment.transform 4 16 env56736 = env56737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56736 == env56737) = true)

def env56738 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,1,301,80,341,3,293,75,1024,341,1360,32,1297,1142,380,1344,1355,80,373,1583,288,113,257,1108,292,512]

theorem envBound56738 : H12AffineFastState.Bounded env56738 := by
  intro p hp
  have h : env56738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56731_56738 : H12AffineEnvironment.transform 11 1 env56731 = env56738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56731 == env56738) = true)

theorem identity56738 : scanCanonicalize (H12AffineFastState.compose env56738 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound56738 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56739 : List Nat := [2,4,8,16,32,64,88,256,512,516,270,1,301,80,341,3,293,75,516,341,852,32,789,626,380,836,847,80,373,43,288,113,257,592,292,512]

theorem envBound56739 : H12AffineFastState.Bounded env56739 := by
  intro p hp
  have h : env56739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56738_56739 : H12AffineEnvironment.transform 9 516 env56738 = env56739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env56738 == env56739) = true)

theorem identity56739 : scanCanonicalize (H12AffineFastState.compose env56739 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound56739 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56740 : List Nat := [2,4,8,16,32,64,88,256,90,94,270,1,301,80,341,3,293,75,94,341,270,32,335,40,380,286,277,80,373,43,288,113,257,10,292,90]

theorem envBound56740 : H12AffineFastState.Bounded env56740 := by
  intro p hp
  have h : env56740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56739_56740 : H12AffineEnvironment.transform 8 90 env56739 = env56740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env56739 == env56740) = true)

theorem identity56740 : scanCanonicalize (H12AffineFastState.compose env56740 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56740 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56741 : List Nat := [2,4,8,16,32,64,88,21,90,94,27,1,56,80,64,3,48,75,94,64,27,32,90,40,105,11,0,80,96,43,53,113,20,10,49,90]

theorem envBound56741 : H12AffineFastState.Bounded env56741 := by
  intro p hp
  have h : env56741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56740_56741 : H12AffineEnvironment.transform 7 21 env56740 = env56741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56740 == env56741) = true)

theorem identity56741 : scanCanonicalize (H12AffineFastState.compose env56741 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56741 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56742 : List Nat := [2,4,8,16,32,16,8,21,10,14,27,1,56,0,16,3,48,27,14,16,27,32,10,40,57,11,0,0,48,43,53,33,20,10,49,10]

theorem envBound56742 : H12AffineFastState.Bounded env56742 := by
  intro p hp
  have h : env56742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56741_56742 : H12AffineEnvironment.transform 5 16 env56741 = env56742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56741 == env56742) = true)

theorem identity56742 : scanCanonicalize (H12AffineFastState.compose env56742 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56742 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56743 : List Nat := [2,4,8,16,10,16,8,21,10,14,27,1,18,0,16,3,26,27,14,16,27,10,10,2,19,11,0,0,26,1,31,11,20,10,27,10]

theorem envBound56743 : H12AffineFastState.Bounded env56743 := by
  intro p hp
  have h : env56743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56742_56743 : H12AffineEnvironment.transform 4 10 env56742 = env56743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56742 == env56743) = true)

def env56744 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,4096,300,4177,341,2,4389,4170,1024,341,5457,32,1297,1142,380,1344,5451,4177,4469,1583,289,112,257,1108,4388,512]

theorem envBound56744 : H12AffineFastState.Bounded env56744 := by
  intro p hp
  have h : env56744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56730_56744 : H12AffineEnvironment.transform 6 89 env56730 = env56744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env56730 == env56744) = true)

def env56745 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,0,300,81,341,2,293,74,1024,341,1361,32,1297,1142,380,1344,1355,81,373,1583,289,112,257,1108,292,512]

theorem envBound56745 : H12AffineFastState.Bounded env56745 := by
  intro p hp
  have h : env56745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56744_56745 : H12AffineEnvironment.transform 11 0 env56744 = env56745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56744 == env56745) = true)

theorem identity56745 : scanCanonicalize (H12AffineFastState.compose env56745 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 369) := by decide +kernel

theorem selectedBound56745 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56746 : List Nat := [2,4,8,16,32,64,89,256,512,369,635,0,300,81,341,2,293,74,369,341,32,32,96,263,380,49,58,81,373,862,289,112,257,293,292,512]

theorem envBound56746 : H12AffineFastState.Bounded env56746 := by
  intro p hp
  have h : env56746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56745_56746 : H12AffineEnvironment.transform 9 369 env56745 = env56746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 369 env56745 == env56746) = true)

theorem identity56746 : scanCanonicalize (H12AffineFastState.compose env56746 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound56746 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env56747 : List Nat := [2,4,8,16,32,64,89,79,512,62,635,0,99,81,26,2,106,74,62,26,32,32,96,72,51,49,58,81,58,529,110,112,78,106,107,512]

theorem envBound56747 : H12AffineFastState.Bounded env56747 := by
  intro p hp
  have h : env56747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56746_56747 : H12AffineEnvironment.transform 7 79 env56746 = env56747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env56746 == env56747) = true)

theorem identity56747 : scanCanonicalize (H12AffineFastState.compose env56747 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56747 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56748 : List Nat := [2,4,8,11,32,64,66,79,512,37,608,0,99,74,1,2,106,74,37,1,32,32,96,72,40,42,33,74,33,522,110,107,78,106,107,512]

theorem envBound56748 : H12AffineFastState.Bounded env56748 := by
  intro p hp
  have h : env56748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56747_56748 : H12AffineEnvironment.transform 3 11 env56747 = env56748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56747 == env56748) = true)

theorem identity56748 : scanCanonicalize (H12AffineFastState.compose env56748 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound56748 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56749 : List Nat := [2,4,8,11,32,64,66,79,96,37,0,0,99,74,1,2,106,74,37,1,32,32,96,72,40,42,33,74,33,106,110,107,78,106,107,96]

theorem envBound56749 : H12AffineFastState.Bounded env56749 := by
  intro p hp
  have h : env56749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56748_56749 : H12AffineEnvironment.transform 8 96 env56748 = env56749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env56748 == env56749) = true)

def env56750 : List Nat := [2,4,8,11,32,32,34,47,0,37,0,0,3,42,1,2,10,42,37,1,32,32,0,40,40,42,33,42,33,10,14,11,46,10,11,0]

theorem envBound56750 : H12AffineFastState.Bounded env56750 := by
  intro p hp
  have h : env56750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56749_56750 : H12AffineEnvironment.transform 5 32 env56749 = env56750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56749 == env56750) = true)

theorem identity56750 : scanCanonicalize (H12AffineFastState.compose env56750 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56751 : List Nat := [2,4,3,0,32,32,34,36,0,37,0,0,3,33,1,2,1,33,37,1,32,32,0,35,35,33,33,33,33,1,5,0,37,1,0,0]

theorem envBound56751 : H12AffineFastState.Bounded env56751 := by
  intro p hp
  have h : env56751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56750_56751 : H12AffineEnvironment.transform 2 3 env56750 = env56751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56750 == env56751) = true)

def env56752 : List Nat := [2,4,8,11,32,33,35,46,1,37,0,0,2,43,1,2,11,43,37,1,32,32,1,41,40,42,33,43,33,11,15,10,47,11,10,1]

theorem envBound56752 : H12AffineFastState.Bounded env56752 := by
  intro p hp
  have h : env56752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56749_56752 : H12AffineEnvironment.transform 5 33 env56749 = env56752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56749 == env56752) = true)

def env56753 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,1,300,80,341,2,292,75,1024,341,1360,32,1297,1142,380,1344,1354,80,372,1583,289,112,257,1108,293,512]

theorem envBound56753 : H12AffineFastState.Bounded env56753 := by
  intro p hp
  have h : env56753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56744_56753 : H12AffineEnvironment.transform 11 1 env56744 = env56753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56744 == env56753) = true)

theorem identity56753 : scanCanonicalize (H12AffineFastState.compose env56753 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound56753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56754 : List Nat := [2,4,8,16,32,64,89,256,97,1024,1387,1,300,80,341,2,292,75,1024,341,1360,32,1297,1142,380,1344,1354,80,372,1102,289,112,257,1108,293,97]

theorem envBound56754 : H12AffineFastState.Bounded env56754 := by
  intro p hp
  have h : env56754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56753_56754 : H12AffineEnvironment.transform 8 97 env56753 = env56754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env56753 == env56754) = true)

theorem identity56754 : scanCanonicalize (H12AffineFastState.compose env56754 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56754 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env56755 : List Nat := [2,4,8,11,32,64,66,256,97,1024,1387,1,300,75,334,2,292,75,1024,334,1355,32,1290,1133,359,1344,1354,75,367,1102,289,107,257,1103,293,97]

theorem envBound56755 : H12AffineFastState.Bounded env56755 := by
  intro p hp
  have h : env56755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56754_56755 : H12AffineEnvironment.transform 3 11 env56754 = env56755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56754 == env56755) = true)

theorem identity56755 : scanCanonicalize (H12AffineFastState.compose env56755 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 362) := by decide +kernel

theorem selectedBound56755 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env56756 : List Nat := [2,4,8,11,32,64,66,256,97,362,1,1,300,75,334,2,292,75,362,334,33,32,96,263,359,42,32,75,367,292,289,107,257,293,293,97]

theorem envBound56756 : H12AffineFastState.Bounded env56756 := by
  intro p hp
  have h : env56756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56755_56756 : H12AffineEnvironment.transform 9 362 env56755 = env56756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 362 env56755 == env56756) = true)

theorem identity56756 : scanCanonicalize (H12AffineFastState.compose env56756 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound56756 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56757 : List Nat := [2,4,8,11,32,64,66,79,97,37,1,1,99,75,1,2,107,75,37,1,33,32,96,72,40,42,32,75,32,107,110,107,78,106,106,97]

theorem envBound56757 : H12AffineFastState.Bounded env56757 := by
  intro p hp
  have h : env56757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56756_56757 : H12AffineEnvironment.transform 7 79 env56756 = env56757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env56756 == env56757) = true)

def env56758 : List Nat := [2,4,8,11,32,32,34,47,1,37,1,1,3,43,1,2,11,43,37,1,33,32,0,40,40,42,32,43,32,11,14,11,46,10,10,1]

theorem envBound56758 : H12AffineFastState.Bounded env56758 := by
  intro p hp
  have h : env56758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56757_56758 : H12AffineEnvironment.transform 5 32 env56757 = env56758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56757 == env56758) = true)

theorem identity56758 : scanCanonicalize (H12AffineFastState.compose env56758 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56759 : List Nat := [2,4,3,0,32,32,34,36,1,37,1,1,3,32,1,2,0,32,37,1,33,32,0,35,35,33,32,32,32,0,5,0,37,1,1,1]

theorem envBound56759 : H12AffineFastState.Bounded env56759 := by
  intro p hp
  have h : env56759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56758_56759 : H12AffineEnvironment.transform 2 3 env56758 = env56759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56758 == env56759) = true)

def env56760 : List Nat := [2,4,8,11,32,33,35,46,0,37,1,1,2,42,1,2,10,42,37,1,33,32,1,41,40,42,32,42,32,10,15,10,47,11,11,0]

theorem envBound56760 : H12AffineFastState.Bounded env56760 := by
  intro p hp
  have h : env56760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56757_56760 : H12AffineEnvironment.transform 5 33 env56757 = env56760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56757 == env56760) = true)

def env56761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142598,28889,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound56761 : H12AffineFastState.Bounded env56761 := by
  intro p hp
  have h : env56761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56723_56761 : H12AffineEnvironment.transform 21 41089 env56723 = env56761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56723 == env56761) = true)

theorem identity56761 : scanCanonicalize (H12AffineFastState.compose env56761 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 9397) := by decide +kernel

theorem selectedBound56761 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9397,32768,65536,78034,74869,1024,32768,2097152,41089,2101313,2142598,5228,2106612,103453,9397,77954,72942,2176390,74118,257,2163918,78035,14053]

theorem envBound56762 : H12AffineFastState.Bounded env56762 := by
  intro p hp
  have h : env56762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56761_56762 : H12AffineEnvironment.transform 13 9397 env56761 = env56762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9397 env56761 == env56762) = true)

theorem identity56762 : scanCanonicalize (H12AffineFastState.compose env56762 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound56762 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,444,32768,65536,71131,65916,1024,32768,2097152,34184,2101313,2135183,5228,2097661,103453,444,71051,72942,2166927,66703,257,2163918,71130,5100]

theorem envBound56763 : H12AffineFastState.Bounded env56763 := by
  intro p hp
  have h : env56763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56762_56763 : H12AffineEnvironment.transform 12 1289 env56762 = env56763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env56762 == env56763) = true)

theorem identity56763 : scanCanonicalize (H12AffineFastState.compose env56763 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 66663) := by decide +kernel

theorem selectedBound56763 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,444,32768,65536,71131,65916,1024,32768,66663,34184,70694,102632,5228,66970,103453,444,71051,72942,5352,66703,257,169,71130,5100]

theorem envBound56764 : H12AffineFastState.Bounded env56764 := by
  intro p hp
  have h : env56764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56763_56764 : H12AffineEnvironment.transform 20 66663 env56763 = env56764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66663 env56763 == env56764) = true)

theorem identity56764 : scanCanonicalize (H12AffineFastState.compose env56764 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound56764 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,65536,66615,65916,1024,32768,66663,34184,67018,98564,1408,66970,99825,444,66663,68866,1284,66703,257,169,66614,512]

theorem envBound56765 : H12AffineFastState.Bounded env56765 := by
  intro p hp
  have h : env56765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56764_56765 : H12AffineEnvironment.transform 11 492 env56764 = env56765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env56764 == env56765) = true)

theorem identity56765 : scanCanonicalize (H12AffineFastState.compose env56765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound56765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,1875,868,1583,1024,32768,820,34184,665,34391,1408,713,33442,444,820,2641,1284,988,257,169,869,512]

theorem envBound56766 : H12AffineFastState.Bounded env56766 := by
  intro p hp
  have h : env56766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56765_56766 : H12AffineEnvironment.transform 15 1875 env56765 = env56766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env56765 == env56766) = true)

def env56767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4273309,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound56767 : H12AffineFastState.Bounded env56767 := by
  intro p hp
  have h : env56767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56722_56767 : H12AffineEnvironment.transform 17 82113 env56722 = env56767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env56722 == env56767) = true)

def env56768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142599,28888,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound56768 : H12AffineFastState.Bounded env56768 := by
  intro p hp
  have h : env56768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56767_56768 : H12AffineEnvironment.transform 21 41088 env56767 = env56768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56767 == env56768) = true)

theorem identity56768 : scanCanonicalize (H12AffineFastState.compose env56768 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 12709) := by decide +kernel

theorem selectedBound56768 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78180,1024,32768,2097152,41088,2101312,2142599,381,2109925,103453,12709,77954,68095,2176391,74119,257,2167263,78035,9204]

theorem envBound56769 : H12AffineFastState.Bounded env56769 := by
  intro p hp
  have h : env56769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56768_56769 : H12AffineEnvironment.transform 13 12709 env56768 = env56769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12709 env56768 == env56769) = true)

theorem identity56769 : scanCanonicalize (H12AffineFastState.compose env56769 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound56769 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78180,1024,32768,71050,41088,67018,107533,381,74863,103453,12709,77954,68095,8205,74119,257,1109,78035,9204]

theorem envBound56770 : H12AffineFastState.Bounded env56770 := by
  intro p hp
  have h : env56770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56769_56770 : H12AffineEnvironment.transform 20 71050 env56769 = env56770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env56769 == env56770) = true)

theorem identity56770 : scanCanonicalize (H12AffineFastState.compose env56770 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 41082) := by decide +kernel

theorem selectedBound56770 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,41082,37032,37150,1024,32768,46576,41088,42416,1143,381,33813,13415,12709,37112,43397,8205,33277,257,1109,37033,9204]

theorem envBound56771 : H12AffineFastState.Bounded env56771 := by
  intro p hp
  have h : env56771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56770_56771 : H12AffineEnvironment.transform 15 41082 env56770 = env56771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41082 env56770 == env56771) = true)

theorem identity56771 : scanCanonicalize (H12AffineFastState.compose env56771 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound56771 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env56772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,4177,32768,33166,37032,37150,1024,32768,37892,33140,33860,1143,381,33813,5523,4177,37112,34929,505,33277,257,1109,37033,512]

theorem envBound56772 : H12AffineFastState.Bounded env56772 := by
  intro p hp
  have h : env56772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56771_56772 : H12AffineEnvironment.transform 12 500 env56771 = env56772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env56771 == env56772) = true)

theorem identity56772 : scanCanonicalize (H12AffineFastState.compose env56772 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound56772 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,500,4177,32768,33166,37032,37150,1024,32768,37892,33140,33860,1143,381,33813,5523,4177,37112,34683,505,33277,257,1109,37033,512]

theorem envBound56773 : H12AffineFastState.Bounded env56773 := by
  intro p hp
  have h : env56773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56772_56773 : H12AffineEnvironment.transform 10 1802 env56772 = env56773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env56772 == env56773) = true)

theorem identity56773 : scanCanonicalize (H12AffineFastState.compose env56773 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound56773 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,500,4177,340,218,4604,4170,1024,340,5456,32,1296,1143,381,1345,5523,4177,4524,1583,505,169,257,1109,4605,512]

theorem envBound56774 : H12AffineFastState.Bounded env56774 := by
  intro p hp
  have h : env56774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56773_56774 : H12AffineEnvironment.transform 14 340 env56773 = env56774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env56773 == env56774) = true)

def env56775 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,4096,300,4177,340,2,4388,4170,1024,340,5456,32,1296,1143,381,1345,5451,4177,4468,1583,289,113,257,1109,4389,512]

theorem envBound56775 : H12AffineFastState.Bounded env56775 := by
  intro p hp
  have h : env56775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56774_56775 : H12AffineEnvironment.transform 6 88 env56774 = env56775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env56774 == env56775) = true)

def env56776 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,0,300,81,340,2,292,74,1024,340,1360,32,1296,1143,381,1345,1355,81,372,1583,289,113,257,1109,293,512]

theorem envBound56776 : H12AffineFastState.Bounded env56776 := by
  intro p hp
  have h : env56776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56775_56776 : H12AffineEnvironment.transform 11 0 env56775 = env56776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56775 == env56776) = true)

theorem identity56776 : scanCanonicalize (H12AffineFastState.compose env56776 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56777 : List Nat := [2,4,8,16,32,64,88,20,512,1024,1566,0,56,81,64,2,48,74,1024,64,1092,32,1028,1143,105,1109,1119,81,96,1583,53,113,21,1109,49,512]

theorem envBound56777 : H12AffineFastState.Bounded env56777 := by
  intro p hp
  have h : env56777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56776_56777 : H12AffineEnvironment.transform 7 20 env56776 = env56777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56776 == env56777) = true)

theorem identity56777 : scanCanonicalize (H12AffineFastState.compose env56777 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 639) := by decide +kernel

theorem selectedBound56777 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56778 : List Nat := [2,4,8,16,32,64,88,20,512,639,97,0,56,81,64,2,48,74,639,64,571,32,635,520,105,554,544,81,96,80,53,113,21,554,49,512]

theorem envBound56778 : H12AffineFastState.Bounded env56778 := by
  intro p hp
  have h : env56778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56777_56778 : H12AffineEnvironment.transform 9 639 env56777 = env56778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 639 env56777 == env56778) = true)

theorem identity56778 : scanCanonicalize (H12AffineFastState.compose env56778 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound56778 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56779 : List Nat := [2,4,8,16,32,64,88,20,33,94,97,0,56,81,64,2,48,74,94,64,26,32,90,41,105,11,1,81,96,80,53,113,21,11,49,33]

theorem envBound56779 : H12AffineFastState.Bounded env56779 := by
  intro p hp
  have h : env56779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56778_56779 : H12AffineEnvironment.transform 8 33 env56778 = env56779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env56778 == env56779) = true)

theorem identity56779 : scanCanonicalize (H12AffineFastState.compose env56779 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound56779 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env56780 : List Nat := [2,4,8,16,32,59,35,20,33,37,26,0,56,42,59,2,48,49,37,59,26,32,33,41,18,11,1,42,27,43,53,10,21,11,49,33]

theorem envBound56780 : H12AffineFastState.Bounded env56780 := by
  intro p hp
  have h : env56780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56779_56780 : H12AffineEnvironment.transform 5 59 env56779 = env56780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env56779 == env56780) = true)

theorem identity56780 : scanCanonicalize (H12AffineFastState.compose env56780 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56781 : List Nat := [2,4,8,16,16,11,19,20,17,21,26,0,8,26,11,2,0,1,21,11,26,16,17,25,18,11,1,26,27,27,5,10,21,11,1,17]

theorem envBound56781 : H12AffineFastState.Bounded env56781 := by
  intro p hp
  have h : env56781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56780_56781 : H12AffineEnvironment.transform 4 16 env56780 = env56781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56780 == env56781) = true)

def env56782 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,1,300,80,340,2,293,75,1024,340,1361,32,1296,1143,381,1345,1354,80,373,1583,289,113,257,1109,292,512]

theorem envBound56782 : H12AffineFastState.Bounded env56782 := by
  intro p hp
  have h : env56782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56775_56782 : H12AffineEnvironment.transform 11 1 env56775 = env56782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56775 == env56782) = true)

theorem identity56782 : scanCanonicalize (H12AffineFastState.compose env56782 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound56782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56783 : List Nat := [2,4,8,16,32,64,88,256,512,516,270,1,300,80,340,2,293,75,516,340,853,32,788,627,381,837,846,80,373,43,289,113,257,593,292,512]

theorem envBound56783 : H12AffineFastState.Bounded env56783 := by
  intro p hp
  have h : env56783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56782_56783 : H12AffineEnvironment.transform 9 516 env56782 = env56783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env56782 == env56783) = true)

theorem identity56783 : scanCanonicalize (H12AffineFastState.compose env56783 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound56783 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56784 : List Nat := [2,4,8,16,32,64,88,256,91,95,270,1,300,80,340,2,293,75,95,340,270,32,335,40,381,286,277,80,373,43,289,113,257,10,292,91]

theorem envBound56784 : H12AffineFastState.Bounded env56784 := by
  intro p hp
  have h : env56784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56783_56784 : H12AffineEnvironment.transform 8 91 env56783 = env56784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env56783 == env56784) = true)

theorem identity56784 : scanCanonicalize (H12AffineFastState.compose env56784 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56784 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56785 : List Nat := [2,4,8,16,32,64,88,21,91,95,27,1,57,80,65,2,48,75,95,65,27,32,90,40,104,11,0,80,96,43,52,113,20,10,49,91]

theorem envBound56785 : H12AffineFastState.Bounded env56785 := by
  intro p hp
  have h : env56785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56784_56785 : H12AffineEnvironment.transform 7 21 env56784 = env56785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56784 == env56785) = true)

theorem identity56785 : scanCanonicalize (H12AffineFastState.compose env56785 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56785 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56786 : List Nat := [2,4,8,16,32,16,8,21,11,15,27,1,57,0,17,2,48,27,15,17,27,32,10,40,56,11,0,0,48,43,52,33,20,10,49,11]

theorem envBound56786 : H12AffineFastState.Bounded env56786 := by
  intro p hp
  have h : env56786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56785_56786 : H12AffineEnvironment.transform 5 16 env56785 = env56786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56785 == env56786) = true)

theorem identity56786 : scanCanonicalize (H12AffineFastState.compose env56786 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56786 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56787 : List Nat := [2,4,8,16,10,16,8,21,11,15,27,1,19,0,17,2,26,27,15,17,27,10,10,2,18,11,0,0,26,1,30,11,20,10,27,11]

theorem envBound56787 : H12AffineFastState.Bounded env56787 := by
  intro p hp
  have h : env56787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56786_56787 : H12AffineEnvironment.transform 4 10 env56786 = env56787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56786 == env56787) = true)

def env56788 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,4096,301,4177,340,3,4389,4170,1024,340,5456,32,1296,1143,381,1345,5450,4177,4469,1583,288,112,257,1109,4388,512]

theorem envBound56788 : H12AffineFastState.Bounded env56788 := by
  intro p hp
  have h : env56788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56774_56788 : H12AffineEnvironment.transform 6 89 env56774 = env56788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env56774 == env56788) = true)

def env56789 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,0,301,81,340,3,293,74,1024,340,1360,32,1296,1143,381,1345,1354,81,373,1583,288,112,257,1109,292,512]

theorem envBound56789 : H12AffineFastState.Bounded env56789 := by
  intro p hp
  have h : env56789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56788_56789 : H12AffineEnvironment.transform 11 0 env56788 = env56789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56788 == env56789) = true)

theorem identity56789 : scanCanonicalize (H12AffineFastState.compose env56789 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 369) := by decide +kernel

theorem selectedBound56789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56790 : List Nat := [2,4,8,16,32,64,89,256,512,369,635,0,301,81,340,3,293,74,369,340,33,32,97,262,381,48,59,81,373,862,288,112,257,292,292,512]

theorem envBound56790 : H12AffineFastState.Bounded env56790 := by
  intro p hp
  have h : env56790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56789_56790 : H12AffineEnvironment.transform 9 369 env56789 = env56790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 369 env56789 == env56790) = true)

theorem identity56790 : scanCanonicalize (H12AffineFastState.compose env56790 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound56790 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env56791 : List Nat := [2,4,8,16,32,64,89,78,512,63,635,0,99,81,26,3,107,74,63,26,33,32,97,72,51,48,59,81,59,528,110,112,79,106,106,512]

theorem envBound56791 : H12AffineFastState.Bounded env56791 := by
  intro p hp
  have h : env56791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56790_56791 : H12AffineEnvironment.transform 7 78 env56790 = env56791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env56790 == env56791) = true)

theorem identity56791 : scanCanonicalize (H12AffineFastState.compose env56791 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56791 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56792 : List Nat := [2,4,8,11,32,64,66,78,512,36,608,0,99,74,1,3,107,74,36,1,33,32,97,72,40,43,32,74,32,523,110,107,79,106,106,512]

theorem envBound56792 : H12AffineFastState.Bounded env56792 := by
  intro p hp
  have h : env56792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56791_56792 : H12AffineEnvironment.transform 3 11 env56791 = env56792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56791 == env56792) = true)

theorem identity56792 : scanCanonicalize (H12AffineFastState.compose env56792 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound56792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56793 : List Nat := [2,4,8,11,32,64,66,78,96,36,0,0,99,74,1,3,107,74,36,1,33,32,97,72,40,43,32,74,32,107,110,107,79,106,106,96]

theorem envBound56793 : H12AffineFastState.Bounded env56793 := by
  intro p hp
  have h : env56793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56792_56793 : H12AffineEnvironment.transform 8 96 env56792 = env56793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env56792 == env56793) = true)

def env56794 : List Nat := [2,4,8,11,32,32,34,46,0,36,0,0,3,42,1,3,11,42,36,1,33,32,1,40,40,43,32,42,32,11,14,11,47,10,10,0]

theorem envBound56794 : H12AffineFastState.Bounded env56794 := by
  intro p hp
  have h : env56794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56793_56794 : H12AffineEnvironment.transform 5 32 env56793 = env56794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56793 == env56794) = true)

theorem identity56794 : scanCanonicalize (H12AffineFastState.compose env56794 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56795 : List Nat := [2,4,2,1,32,32,34,36,0,36,0,0,3,32,1,3,1,32,36,1,33,32,1,34,34,33,32,32,32,1,4,1,37,0,0,0]

theorem envBound56795 : H12AffineFastState.Bounded env56795 := by
  intro p hp
  have h : env56795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56794_56795 : H12AffineEnvironment.transform 2 2 env56794 = env56795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56794 == env56795) = true)

def env56796 : List Nat := [2,4,8,11,32,33,35,47,1,36,0,0,2,43,1,3,10,43,36,1,33,32,0,41,40,43,32,43,32,10,15,10,46,11,11,1]

theorem envBound56796 : H12AffineFastState.Bounded env56796 := by
  intro p hp
  have h : env56796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56793_56796 : H12AffineEnvironment.transform 5 33 env56793 = env56796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56793 == env56796) = true)

def env56797 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,1,301,80,340,3,292,75,1024,340,1361,32,1296,1143,381,1345,1355,80,372,1583,288,112,257,1109,293,512]

theorem envBound56797 : H12AffineFastState.Bounded env56797 := by
  intro p hp
  have h : env56797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56788_56797 : H12AffineEnvironment.transform 11 1 env56788 = env56797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56788 == env56797) = true)

theorem identity56797 : scanCanonicalize (H12AffineFastState.compose env56797 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound56797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56798 : List Nat := [2,4,8,16,32,64,89,256,97,1024,1387,1,301,80,340,3,292,75,1024,340,1361,32,1296,1143,381,1345,1355,80,372,1102,288,112,257,1109,293,97]

theorem envBound56798 : H12AffineFastState.Bounded env56798 := by
  intro p hp
  have h : env56798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56797_56798 : H12AffineEnvironment.transform 8 97 env56797 = env56798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env56797 == env56798) = true)

theorem identity56798 : scanCanonicalize (H12AffineFastState.compose env56798 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56798 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env56799 : List Nat := [2,4,8,11,32,64,66,256,97,1024,1387,1,301,75,335,3,292,75,1024,335,1354,32,1291,1132,358,1345,1355,75,367,1102,288,107,257,1102,293,97]

theorem envBound56799 : H12AffineFastState.Bounded env56799 := by
  intro p hp
  have h : env56799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56798_56799 : H12AffineEnvironment.transform 3 11 env56798 = env56799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56798 == env56799) = true)

theorem identity56799 : scanCanonicalize (H12AffineFastState.compose env56799 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 362) := by decide +kernel

theorem selectedBound56799 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env56800 : List Nat := [2,4,8,11,32,64,66,256,97,362,1,1,301,75,335,3,292,75,362,335,32,32,97,262,358,43,33,75,367,292,288,107,257,292,293,97]

theorem envBound56800 : H12AffineFastState.Bounded env56800 := by
  intro p hp
  have h : env56800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56799_56800 : H12AffineEnvironment.transform 9 362 env56799 = env56800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 362 env56799 == env56800) = true)

theorem identity56800 : scanCanonicalize (H12AffineFastState.compose env56800 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound56800 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56801 : List Nat := [2,4,8,11,32,64,66,78,97,36,1,1,99,75,1,3,106,75,36,1,32,32,97,72,40,43,33,75,33,106,110,107,79,106,107,97]

theorem envBound56801 : H12AffineFastState.Bounded env56801 := by
  intro p hp
  have h : env56801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56800_56801 : H12AffineEnvironment.transform 7 78 env56800 = env56801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env56800 == env56801) = true)

def env56802 : List Nat := [2,4,8,11,32,32,34,46,1,36,1,1,3,43,1,3,10,43,36,1,32,32,1,40,40,43,33,43,33,10,14,11,47,10,11,1]

theorem envBound56802 : H12AffineFastState.Bounded env56802 := by
  intro p hp
  have h : env56802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56801_56802 : H12AffineEnvironment.transform 5 32 env56801 = env56802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56801 == env56802) = true)

theorem identity56802 : scanCanonicalize (H12AffineFastState.compose env56802 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56803 : List Nat := [2,4,2,1,32,32,34,36,1,36,1,1,3,33,1,3,0,33,36,1,32,32,1,34,34,33,33,33,33,0,4,1,37,0,1,1]

theorem envBound56803 : H12AffineFastState.Bounded env56803 := by
  intro p hp
  have h : env56803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56802_56803 : H12AffineEnvironment.transform 2 2 env56802 = env56803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56802 == env56803) = true)

def env56804 : List Nat := [2,4,8,11,32,33,35,47,0,36,1,1,2,42,1,3,11,42,36,1,32,32,0,41,40,43,33,42,33,11,15,10,46,11,10,0]

theorem envBound56804 : H12AffineFastState.Bounded env56804 := by
  intro p hp
  have h : env56804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56801_56804 : H12AffineEnvironment.transform 5 33 env56801 = env56804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56801 == env56804) = true)

def env56805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142598,28889,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound56805 : H12AffineFastState.Bounded env56805 := by
  intro p hp
  have h : env56805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56767_56805 : H12AffineEnvironment.transform 21 41089 env56767 = env56805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56767 == env56805) = true)

theorem identity56805 : scanCanonicalize (H12AffineFastState.compose env56805 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5348) := by decide +kernel

theorem selectedBound56805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5348,16384,32768,65536,66614,82113,1024,32768,2097152,37989,2101313,2131298,17469,2113601,103452,16384,66662,85183,2163042,71010,257,2184351,66615,21072]

theorem envBound56806 : H12AffineFastState.Bounded env56806 := by
  intro p hp
  have h : env56806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56805_56806 : H12AffineEnvironment.transform 12 5348 env56805 = env56806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5348 env56805 == env56806) = true)

theorem identity56806 : scanCanonicalize (H12AffineFastState.compose env56806 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56806 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,16384,32768,65536,66614,82113,1024,32768,2097152,34184,2097580,2131298,17469,2113601,99825,16384,66662,85183,2163042,66703,257,2180466,66615,17341]

theorem envBound56807 : H12AffineFastState.Bounded env56807 := by
  intro p hp
  have h : env56807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56806_56807 : H12AffineEnvironment.transform 11 493 env56806 = env56807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56806 == env56807) = true)

theorem identity56807 : scanCanonicalize (H12AffineFastState.compose env56807 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 83419) := by decide +kernel

theorem selectedBound56807 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,16384,32768,65536,66614,82113,1024,32768,83419,34184,83063,114873,17469,66970,99825,16384,66662,85183,17593,66703,257,169,66615,17341]

theorem envBound56808 : H12AffineFastState.Bounded env56808 := by
  intro p hp
  have h : env56808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56807_56808 : H12AffineEnvironment.transform 20 83419 env56807 = env56808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83419 env56807 == env56808) = true)

theorem identity56808 : scanCanonicalize (H12AffineFastState.compose env56808 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound56808 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,65536,66614,65916,1024,32768,66662,34184,67018,98564,1408,66970,99825,445,66662,68866,1284,66703,257,169,66615,512]

theorem envBound56809 : H12AffineFastState.Bounded env56809 := by
  intro p hp
  have h : env56809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56808_56809 : H12AffineEnvironment.transform 13 445 env56808 = env56809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env56808 == env56809) = true)

theorem identity56809 : scanCanonicalize (H12AffineFastState.compose env56809 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound56809 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,1875,869,1583,1024,32768,821,34184,665,34391,1408,713,33442,445,821,2641,1284,988,257,169,868,512]

theorem envBound56810 : H12AffineFastState.Bounded env56810 := by
  intro p hp
  have h : env56810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56809_56810 : H12AffineEnvironment.transform 15 1875 env56809 = env56810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env56809 == env56810) = true)

def env56811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4486237,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound56811 : H12AffineFastState.Bounded env56811 := by
  intro p hp
  have h : env56811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56721_56811 : H12AffineEnvironment.transform 22 6336705 env56721 = env56811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env56721 == env56811) = true)

def env56812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4273309,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound56812 : H12AffineFastState.Bounded env56812 := by
  intro p hp
  have h : env56812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56811_56812 : H12AffineEnvironment.transform 17 82112 env56811 = env56812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env56811 == env56812) = true)

def env56813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142598,28888,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound56813 : H12AffineFastState.Bounded env56813 := by
  intro p hp
  have h : env56813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56812_56813 : H12AffineEnvironment.transform 21 41088 env56812 = env56813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56812 == env56813) = true)

theorem identity56813 : scanCanonicalize (H12AffineFastState.compose env56813 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound56813 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,65536,78034,70765,1024,32768,2097152,41088,2101313,2142598,9333,2102508,103453,5293,77954,77047,2176390,74118,257,2176215,78035,1788]

theorem envBound56814 : H12AffineFastState.Bounded env56814 := by
  intro p hp
  have h : env56814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56813_56814 : H12AffineEnvironment.transform 13 5293 env56813 = env56814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env56813 == env56814) = true)

theorem identity56814 : scanCanonicalize (H12AffineFastState.compose env56814 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound56814 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,65536,78034,70765,1024,32768,71050,41088,67019,107532,9333,65894,103453,5293,77954,77047,8204,74118,257,8541,78035,1788]

theorem envBound56815 : H12AffineFastState.Bounded env56815 := by
  intro p hp
  have h : env56815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56814_56815 : H12AffineEnvironment.transform 20 71050 env56814 = env56815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env56814 == env56815) = true)

theorem identity56815 : scanCanonicalize (H12AffineFastState.compose env56815 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound56815 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,33166,45404,38371,1024,32768,37892,41088,33861,9602,9333,33000,5523,5293,45324,44409,8204,40968,257,8541,45405,1788]

theorem envBound56816 : H12AffineFastState.Bounded env56816 := by
  intro p hp
  have h : env56816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56815_56816 : H12AffineEnvironment.transform 15 33166 env56815 = env56816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env56815 == env56816) = true)

def env56817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5293,32768,33166,45324,38323,1024,32768,37892,41088,33813,9602,9253,32952,5523,5293,45324,44329,8204,40968,257,8461,45325,1708]

theorem envBound56817 : H12AffineFastState.Bounded env56817 := by
  intro p hp
  have h : env56817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56816_56817 : H12AffineEnvironment.transform 5 16 env56816 = env56817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56816 == env56817) = true)

theorem identity56817 : scanCanonicalize (H12AffineFastState.compose env56817 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound56817 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env56818 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4097,32768,33166,45324,37151,172,32768,37032,41088,32953,8494,8329,32952,4415,4097,45324,43397,8204,40968,257,8461,45325,512]

theorem envBound56818 : H12AffineFastState.Bounded env56818 := by
  intro p hp
  have h : env56818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56817_56818 : H12AffineEnvironment.transform 9 172 env56817 = env56818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env56817 == env56818) = true)

theorem identity56818 : scanCanonicalize (H12AffineFastState.compose env56818 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound56818 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56819 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2563,4097,32768,33166,39695,37151,172,32768,37032,35459,32953,2861,2698,32952,4415,4097,39695,33670,2575,35339,257,2830,39694,512]

theorem envBound56819 : H12AffineFastState.Bounded env56819 := by
  intro p hp
  have h : env56819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56818_56819 : H12AffineEnvironment.transform 12 2563 env56818 = env56819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env56818 == env56819) = true)

theorem identity56819 : scanCanonicalize (H12AffineFastState.compose env56819 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound56819 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56820 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2563,4097,2723,2861,4524,7100,172,2723,6667,32,2586,2861,2698,2587,4415,4097,4524,2341,2575,168,257,2830,4525,512]

theorem envBound56820 : H12AffineFastState.Bounded env56820 := by
  intro p hp
  have h : env56820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56819_56820 : H12AffineEnvironment.transform 14 2723 env56819 = env56820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env56819 == env56820) = true)

theorem identity56820 : scanCanonicalize (H12AffineFastState.compose env56820 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound56820 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env56821 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,2090,2563,2091,2723,2861,2438,918,172,2723,545,32,2586,2861,2698,2587,2325,2091,2438,2341,2575,168,257,2830,2439,512]

theorem envBound56821 : H12AffineFastState.Bounded env56821 := by
  intro p hp
  have h : env56821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56820_56821 : H12AffineEnvironment.transform 11 2090 env56820 = env56821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env56820 == env56821) = true)

theorem identity56821 : scanCanonicalize (H12AffineFastState.compose env56821 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56821 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env56822 : List Nat := [2,4,8,16,32,16,57,256,512,21,2048,2090,2563,2091,2586,2861,2367,815,21,2586,545,32,2586,2861,2611,2587,2325,2091,2367,2341,2575,17,257,2830,2366,512]

theorem envBound56822 : H12AffineFastState.Bounded env56822 := by
  intro p hp
  have h : env56822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56821_56822 : H12AffineEnvironment.transform 6 57 env56821 = env56822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56821 == env56822) = true)

theorem identity56822 : scanCanonicalize (H12AffineFastState.compose env56822 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound56822 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56823 : List Nat := [2,4,8,16,32,16,57,256,512,21,798,820,285,821,260,51,545,815,21,260,545,32,260,51,301,261,523,821,545,571,273,17,257,16,544,512]

theorem envBound56823 : H12AffineFastState.Bounded env56823 := by
  intro p hp
  have h : env56823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56822_56823 : H12AffineEnvironment.transform 10 798 env56822 = env56823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env56822 == env56823) = true)

def env56824 : List Nat := [2,4,8,16,16,16,9,256,512,21,798,772,285,773,260,3,529,799,21,260,529,16,260,3,285,261,523,773,529,523,273,17,257,16,528,512]

theorem envBound56824 : H12AffineFastState.Bounded env56824 := by
  intro p hp
  have h : env56824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56823_56824 : H12AffineEnvironment.transform 4 16 env56823 = env56824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56823 == env56824) = true)

theorem identity56824 : scanCanonicalize (H12AffineFastState.compose env56824 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound56824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56825 : List Nat := [2,4,8,16,16,16,9,30,512,21,512,538,3,539,26,3,529,513,21,26,529,16,26,3,3,27,523,539,529,523,15,17,31,16,528,512]

theorem envBound56825 : H12AffineFastState.Bounded env56825 := by
  intro p hp
  have h : env56825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56824_56825 : H12AffineEnvironment.transform 7 30 env56824 = env56825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env56824 == env56825) = true)

theorem identity56825 : scanCanonicalize (H12AffineFastState.compose env56825 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56826 : List Nat := [2,4,8,11,11,11,9,5,512,14,512,513,3,512,1,3,522,513,14,1,522,11,1,3,3,0,523,512,522,523,15,10,4,11,523,512]

theorem envBound56826 : H12AffineFastState.Bounded env56826 := by
  intro p hp
  have h : env56826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56825_56826 : H12AffineEnvironment.transform 3 11 env56825 = env56826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56825 == env56826) = true)

def env56827 : List Nat := [2,4,8,16,17,16,8,256,512,21,798,773,285,772,260,2,528,798,21,260,528,17,260,2,284,261,523,772,528,522,273,17,257,16,529,512]

theorem envBound56827 : H12AffineFastState.Bounded env56827 := by
  intro p hp
  have h : env56827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56823_56827 : H12AffineEnvironment.transform 4 17 env56823 = env56827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56823 == env56827) = true)

theorem identity56827 : scanCanonicalize (H12AffineFastState.compose env56827 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound56827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56828 : List Nat := [2,4,8,16,17,16,8,256,11,21,277,270,285,271,260,2,27,277,21,260,27,17,260,2,284,261,0,271,27,1,273,17,257,16,26,11]

theorem envBound56828 : H12AffineFastState.Bounded env56828 := by
  intro p hp
  have h : env56828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56827_56828 : H12AffineEnvironment.transform 8 11 env56827 = env56828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env56827 == env56828) = true)

theorem identity56828 : scanCanonicalize (H12AffineFastState.compose env56828 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56829 : List Nat := [2,4,8,16,17,16,8,14,11,21,27,0,19,1,10,2,27,27,21,10,27,17,10,2,18,11,0,1,27,1,31,17,15,16,26,11]

theorem envBound56829 : H12AffineFastState.Bounded env56829 := by
  intro p hp
  have h : env56829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56828_56829 : H12AffineEnvironment.transform 7 14 env56828 = env56829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56828 == env56829) = true)

def env56830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5293,32768,33166,45325,38322,1024,32768,37892,41088,33812,9602,9252,32953,5523,5293,45324,44328,8204,40968,257,8460,45324,1709]

theorem envBound56830 : H12AffineFastState.Bounded env56830 := by
  intro p hp
  have h : env56830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56816_56830 : H12AffineEnvironment.transform 5 17 env56816 = env56830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56816 == env56830) = true)

def env56831 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,32768,33166,45325,38274,1024,32768,37892,41088,33812,9602,9236,32905,5523,5277,45324,44312,8204,40968,257,8460,45324,1693]

theorem envBound56831 : H12AffineFastState.Bounded env56831 := by
  intro p hp
  have h : env56831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56830_56831 : H12AffineEnvironment.transform 4 16 env56830 = env56831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56830 == env56831) = true)

def env56832 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,1296,1182,13341,4242,1024,1296,4372,9616,260,9602,9236,1433,5523,5277,13340,10248,8204,9496,257,8460,13340,1693]

theorem envBound56832 : H12AffineFastState.Bounded env56832 := by
  intro p hp
  have h : env56832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56831_56832 : H12AffineEnvironment.transform 14 1296 env56831 = env56832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env56831 == env56832) = true)

theorem identity56832 : scanCanonicalize (H12AffineFastState.compose env56832 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound56832 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56833 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,2194,8192,3087,1296,1182,11407,2048,1024,1296,2438,9616,260,9602,9236,1433,3329,3087,11406,10248,8204,9496,257,8460,11406,1693]

theorem envBound56833 : H12AffineFastState.Bounded env56833 := by
  intro p hp
  have h : env56833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56832_56833 : H12AffineEnvironment.transform 11 2194 env56832 = env56833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env56832 == env56833) = true)

theorem identity56833 : scanCanonicalize (H12AffineFastState.compose env56833 (packedSelected [3,4,5,7,10,11,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound56833 : packedSelected [3,4,5,7,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env56834 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,2194,8192,2074,261,139,10394,2048,21,261,2438,8581,260,8599,8193,396,2324,2074,10395,10248,8204,8461,257,8460,10395,648]

theorem envBound56834 : H12AffineFastState.Bounded env56834 := by
  intro p hp
  have h : env56834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56833_56834 : H12AffineEnvironment.transform 9 21 env56833 = env56834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env56833 == env56834) = true)

theorem identity56834 : scanCanonicalize (H12AffineFastState.compose env56834 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2975) := by decide +kernel

theorem selectedBound56834 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env56835 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,2194,2975,2074,261,139,773,2048,21,261,2438,2586,260,2568,2974,396,2324,2074,772,919,2963,2706,257,2707,772,648]

theorem envBound56835 : H12AffineFastState.Bounded env56835 := by
  intro p hp
  have h : env56835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56834_56835 : H12AffineEnvironment.transform 12 2975 env56834 = env56835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2975 env56834 == env56835) = true)

theorem identity56835 : scanCanonicalize (H12AffineFastState.compose env56835 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56835 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56836 : List Nat := [2,4,8,16,16,17,128,20,512,21,2048,2194,2699,2074,17,139,529,2048,21,17,2194,2586,16,2568,2698,152,2048,2074,528,643,2695,2706,21,2707,528,648]

theorem envBound56836 : H12AffineFastState.Bounded env56836 := by
  intro p hp
  have h : env56836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56835_56836 : H12AffineEnvironment.transform 7 20 env56835 = env56836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56835 == env56836) = true)

theorem identity56836 : scanCanonicalize (H12AffineFastState.compose env56836 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound56836 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env56837 : List Nat := [2,4,8,16,16,17,128,20,512,21,539,649,144,513,17,139,529,539,21,17,649,1,16,19,145,152,539,513,528,643,156,137,21,136,528,648]

theorem envBound56837 : H12AffineFastState.Bounded env56837 := by
  intro p hp
  have h : env56837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56836_56837 : H12AffineEnvironment.transform 10 539 env56836 = env56837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env56836 == env56837) = true)

theorem identity56837 : scanCanonicalize (H12AffineFastState.compose env56837 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound56837 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56838 : List Nat := [2,4,8,16,16,17,19,20,512,21,539,538,3,513,17,24,529,539,21,17,538,1,16,19,2,11,539,513,528,528,15,26,21,27,528,539]

theorem envBound56838 : H12AffineFastState.Bounded env56838 := by
  intro p hp
  have h : env56838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56837_56838 : H12AffineEnvironment.transform 6 19 env56837 = env56838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env56837 == env56838) = true)

theorem identity56838 : scanCanonicalize (H12AffineFastState.compose env56838 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56838 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56839 : List Nat := [2,4,8,1,1,0,2,5,512,4,522,523,3,513,0,9,512,522,4,0,523,1,1,2,2,11,522,513,513,513,15,11,4,10,513,522]

theorem envBound56839 : H12AffineFastState.Bounded env56839 := by
  intro p hp
  have h : env56839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56838_56839 : H12AffineEnvironment.transform 3 1 env56838 = env56839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56838 == env56839) = true)

theorem identity56839 : scanCanonicalize (H12AffineFastState.compose env56839 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56839 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56840 : List Nat := [2,4,2,1,1,0,2,5,512,4,512,513,3,513,0,3,512,512,4,0,513,1,1,2,2,1,512,513,513,513,5,1,4,0,513,512]

theorem envBound56840 : H12AffineFastState.Bounded env56840 := by
  intro p hp
  have h : env56840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56839_56840 : H12AffineEnvironment.transform 2 2 env56839 = env56840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56839 == env56840) = true)

def env56841 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,1297,1183,13340,4243,1024,1297,4373,9617,261,9602,9236,1432,5523,5277,13341,10249,8204,9497,257,8460,13341,1693]

theorem envBound56841 : H12AffineFastState.Bounded env56841 := by
  intro p hp
  have h : env56841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56831_56841 : H12AffineEnvironment.transform 14 1297 env56831 = env56841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env56831 == env56841) = true)

theorem identity56841 : scanCanonicalize (H12AffineFastState.compose env56841 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound56841 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56842 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,2075,8192,3206,1297,1183,11271,2184,1024,1297,2318,9617,261,9602,9236,1432,3464,3206,11270,10249,8204,9497,257,8460,11270,1693]

theorem envBound56842 : H12AffineFastState.Bounded env56842 := by
  intro p hp
  have h : env56842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56841_56842 : H12AffineEnvironment.transform 11 2075 env56841 = env56842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env56841 == env56842) = true)

theorem identity56842 : scanCanonicalize (H12AffineFastState.compose env56842 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56842 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56843 : List Nat := [2,4,8,16,16,17,128,256,512,20,2048,2075,8192,2194,261,139,10259,2184,20,261,2318,8581,261,8598,8192,396,2460,2194,10258,10249,8204,8461,257,8460,10258,649]

theorem envBound56843 : H12AffineFastState.Bounded env56843 := by
  intro p hp
  have h : env56843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56842_56843 : H12AffineEnvironment.transform 9 20 env56842 = env56843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56842 == env56843) = true)

theorem identity56843 : scanCanonicalize (H12AffineFastState.compose env56843 (packedSelected [0,1,4,5,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2839) := by decide +kernel

theorem selectedBound56843 : packedSelected [0,1,4,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env56844 : List Nat := [2,4,8,16,16,17,128,256,512,20,2048,2075,2839,2194,261,139,772,2184,20,261,2318,2706,261,2689,2839,396,2460,2194,773,798,2843,2586,257,2587,773,649]

theorem envBound56844 : H12AffineFastState.Bounded env56844 := by
  intro p hp
  have h : env56844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56843_56844 : H12AffineEnvironment.transform 12 2839 env56843 = env56844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2839 env56843 == env56844) = true)

theorem identity56844 : scanCanonicalize (H12AffineFastState.compose env56844 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56844 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56845 : List Nat := [2,4,8,16,16,17,128,20,512,20,2048,2075,2563,2194,17,139,528,2184,20,17,2074,2706,17,2689,2563,152,2184,2194,529,522,2575,2586,21,2587,529,649]

theorem envBound56845 : H12AffineFastState.Bounded env56845 := by
  intro p hp
  have h : env56845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56844_56845 : H12AffineEnvironment.transform 7 20 env56844 = env56845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56844 == env56845) = true)

theorem identity56845 : scanCanonicalize (H12AffineFastState.compose env56845 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56845 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56846 : List Nat := [2,4,8,16,16,17,9,20,512,20,2048,2075,2563,2075,17,2,528,2049,20,17,2074,2587,17,2568,2563,17,2049,2075,529,522,2575,2586,21,2587,529,512]

theorem envBound56846 : H12AffineFastState.Bounded env56846 := by
  intro p hp
  have h : env56846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56845_56846 : H12AffineEnvironment.transform 6 9 env56845 = env56846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56845 == env56846) = true)

theorem identity56846 : scanCanonicalize (H12AffineFastState.compose env56846 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound56846 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56847 : List Nat := [2,4,8,16,16,17,9,20,16,20,2048,2075,2067,2075,17,2,0,2049,20,17,2074,2059,17,2072,2067,17,2049,2075,1,26,2079,2058,21,2059,1,16]

theorem envBound56847 : H12AffineFastState.Bounded env56847 := by
  intro p hp
  have h : env56847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56846_56847 : H12AffineEnvironment.transform 8 16 env56846 = env56847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env56846 == env56847) = true)

theorem identity56847 : scanCanonicalize (H12AffineFastState.compose env56847 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56847 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56848 : List Nat := [2,4,8,16,16,17,9,20,16,20,1,26,18,26,17,2,0,0,20,17,27,10,17,25,18,17,0,26,1,26,30,11,21,10,1,16]

theorem envBound56848 : H12AffineFastState.Bounded env56848 := by
  intro p hp
  have h : env56848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56847_56848 : H12AffineEnvironment.transform 10 1 env56847 = env56848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56847 == env56848) = true)

theorem identity56848 : scanCanonicalize (H12AffineFastState.compose env56848 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56848 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56849 : List Nat := [2,4,8,11,11,10,9,15,11,15,1,1,9,1,10,2,0,0,15,10,0,10,10,2,9,10,0,1,1,1,5,11,14,10,1,11]

theorem envBound56849 : H12AffineFastState.Bounded env56849 := by
  intro p hp
  have h : env56849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56848_56849 : H12AffineEnvironment.transform 3 11 env56848 = env56849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56848 == env56849) = true)

theorem identity56849 : scanCanonicalize (H12AffineFastState.compose env56849 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56849 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56850 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,1,3,1,0,2,0,0,5,0,0,0,0,2,3,0,0,1,1,1,5,1,4,0,1,1]

theorem envBound56850 : H12AffineFastState.Bounded env56850 := by
  intro p hp
  have h : env56850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56849_56850 : H12AffineEnvironment.transform 2 2 env56849 = env56850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56849 == env56850) = true)

def env56851 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,32768,33166,45325,38275,1024,32768,37892,41088,33812,9602,9237,32904,5523,5276,45324,44313,8204,40968,257,8460,45324,1692]

theorem envBound56851 : H12AffineFastState.Bounded env56851 := by
  intro p hp
  have h : env56851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56830_56851 : H12AffineEnvironment.transform 4 17 env56830 = env56851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56830 == env56851) = true)

def env56852 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,1296,1182,13341,4243,1024,1296,4372,9616,260,9602,9237,1432,5523,5276,13340,10249,8204,9496,257,8460,13340,1692]

theorem envBound56852 : H12AffineFastState.Bounded env56852 := by
  intro p hp
  have h : env56852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56852 : H12AffineEnvironment.transform 14 1296 env56851 = env56852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env56851 == env56852) = true)

theorem identity56852 : scanCanonicalize (H12AffineFastState.compose env56852 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6543) := by decide +kernel

theorem selectedBound56852 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56853 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,6543,5276,1296,1182,3474,4243,1024,1296,4372,7199,260,7181,7578,1432,5523,5276,3475,4486,6531,7319,257,6275,3475,1692]

theorem envBound56853 : H12AffineFastState.Bounded env56853 := by
  intro p hp
  have h : env56853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56852_56853 : H12AffineEnvironment.transform 12 6543 env56852 = env56853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6543 env56852 == env56853) = true)

theorem identity56853 : scanCanonicalize (H12AffineFastState.compose env56853 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound56853 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56854 : List Nat := [2,4,8,16,17,17,128,256,512,21,2048,4096,6543,4233,261,139,2439,4243,21,261,4372,6154,260,6168,6543,397,4486,4233,2438,4486,6531,6274,257,6275,2438,649]

theorem envBound56854 : H12AffineFastState.Bounded env56854 := by
  intro p hp
  have h : env56854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56853_56854 : H12AffineEnvironment.transform 9 21 env56853 = env56854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env56853 == env56854) = true)

theorem identity56854 : scanCanonicalize (H12AffineFastState.compose env56854 (packedSelected [2,3,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 919) := by decide +kernel

theorem selectedBound56854 : packedSelected [2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env56855 : List Nat := [2,4,8,16,17,17,128,256,512,21,919,4096,4632,4233,261,139,528,4243,21,261,4372,5021,260,5007,4632,397,4486,4233,529,4486,4628,4885,257,4884,529,649]

theorem envBound56855 : H12AffineFastState.Bounded env56855 := by
  intro p hp
  have h : env56855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56854_56855 : H12AffineEnvironment.transform 10 919 env56854 = env56855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 919 env56854 == env56855) = true)

theorem identity56855 : scanCanonicalize (H12AffineFastState.compose env56855 (packedSelected [2,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound56855 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env56856 : List Nat := [2,4,8,16,17,17,128,256,512,21,919,529,9,664,261,139,528,642,21,261,773,396,260,414,9,397,919,664,529,919,5,260,257,261,529,649]

theorem envBound56856 : H12AffineFastState.Bounded env56856 := by
  intro p hp
  have h : env56856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56855_56856 : H12AffineEnvironment.transform 11 529 env56855 = env56856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env56855 == env56856) = true)

theorem identity56856 : scanCanonicalize (H12AffineFastState.compose env56856 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound56856 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56857 : List Nat := [2,4,8,16,17,17,128,157,512,21,522,529,9,664,152,139,528,642,21,152,664,17,153,3,9,16,522,664,529,522,5,153,156,152,529,649]

theorem envBound56857 : H12AffineFastState.Bounded env56857 := by
  intro p hp
  have h : env56857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56856_56857 : H12AffineEnvironment.transform 7 157 env56856 = env56857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env56856 == env56857) = true)

theorem identity56857 : scanCanonicalize (H12AffineFastState.compose env56857 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56857 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56858 : List Nat := [2,4,8,16,17,17,9,20,512,21,522,529,9,529,17,2,528,523,21,17,529,17,16,3,9,16,522,529,529,522,5,16,21,17,529,512]

theorem envBound56858 : H12AffineFastState.Bounded env56858 := by
  intro p hp
  have h : env56858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56857_56858 : H12AffineEnvironment.transform 6 9 env56857 = env56858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56857 == env56858) = true)

theorem identity56858 : scanCanonicalize (H12AffineFastState.compose env56858 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound56858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56859 : List Nat := [2,4,8,16,17,17,9,20,16,21,26,1,9,1,17,2,0,27,21,17,1,17,16,3,9,16,26,1,1,26,5,16,21,17,1,16]

theorem envBound56859 : H12AffineFastState.Bounded env56859 := by
  intro p hp
  have h : env56859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56858_56859 : H12AffineEnvironment.transform 8 16 env56858 = env56859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env56858 == env56859) = true)

theorem identity56859 : scanCanonicalize (H12AffineFastState.compose env56859 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56860 : List Nat := [2,4,8,10,11,11,9,14,10,15,0,1,9,1,11,2,0,1,15,11,1,11,10,3,9,10,0,1,1,0,5,10,15,11,1,10]

theorem envBound56860 : H12AffineFastState.Bounded env56860 := by
  intro p hp
  have h : env56860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56859_56860 : H12AffineEnvironment.transform 3 10 env56859 = env56860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56859 == env56860) = true)

def env56861 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,1297,1183,13340,4242,1024,1297,4373,9617,261,9602,9237,1433,5523,5276,13341,10248,8204,9497,257,8460,13341,1692]

theorem envBound56861 : H12AffineFastState.Bounded env56861 := by
  intro p hp
  have h : env56861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56861 : H12AffineEnvironment.transform 14 1297 env56851 = env56861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env56851 == env56861) = true)

theorem identity56861 : scanCanonicalize (H12AffineFastState.compose env56861 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6406) := by decide +kernel

theorem selectedBound56861 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56862 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,6406,5276,1297,1183,3354,4242,1024,1297,4373,7319,261,7300,7443,1433,5523,5276,3355,4366,6410,7199,257,6154,3355,1692]

theorem envBound56862 : H12AffineFastState.Bounded env56862 := by
  intro p hp
  have h : env56862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56861_56862 : H12AffineEnvironment.transform 12 6406 env56861 = env56862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6406 env56861 == env56862) = true)

theorem identity56862 : scanCanonicalize (H12AffineFastState.compose env56862 (packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound56862 : packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env56863 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,1945,3743,773,1297,1183,3354,1803,1024,1297,1676,2830,261,2845,2698,1433,522,773,3355,1687,3731,2950,257,3987,3355,1692]

theorem envBound56863 : H12AffineFastState.Bounded env56863 := by
  intro p hp
  have h : env56863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56862_56863 : H12AffineEnvironment.transform 11 1945 env56862 = env56863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env56862 == env56863) = true)

theorem identity56863 : scanCanonicalize (H12AffineFastState.compose env56863 (packedSelected [8,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56863 : packedSelected [8,10,13] rootPS < 2^1333 := by decide +kernel

def env56864 : List Nat := [2,4,8,16,17,17,3,256,512,1024,2048,1818,3612,773,1297,1052,3354,1803,1024,1297,1551,2830,261,2845,2569,1306,522,773,3355,1556,3600,2821,257,3856,3355,1567]

theorem envBound56864 : H12AffineFastState.Bounded env56864 := by
  intro p hp
  have h : env56864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56863_56864 : H12AffineEnvironment.transform 6 3 env56863 = env56864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56863 == env56864) = true)

theorem identity56864 : scanCanonicalize (H12AffineFastState.compose env56864 (packedSelected [4,5,7,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound56864 : packedSelected [4,5,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env56865 : List Nat := [2,4,8,16,17,17,3,256,512,1024,788,1818,1288,773,1297,1052,1550,1803,1024,1297,1551,26,261,9,285,1306,522,773,1551,1556,1284,17,257,1028,1551,1567]

theorem envBound56865 : H12AffineFastState.Bounded env56865 := by
  intro p hp
  have h : env56865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56864_56865 : H12AffineEnvironment.transform 10 788 env56864 = env56865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env56864 == env56865) = true)

theorem identity56865 : scanCanonicalize (H12AffineFastState.compose env56865 (packedSelected [0,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56865 : packedSelected [0,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56866 : List Nat := [2,4,3,16,17,17,3,256,512,1024,788,1809,1283,773,1297,1047,1541,1792,1024,1297,1540,17,261,2,278,1297,513,773,1540,1556,1284,17,257,1028,1540,1556]

theorem envBound56866 : H12AffineFastState.Bounded env56866 := by
  intro p hp
  have h : env56866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56865_56866 : H12AffineEnvironment.transform 2 3 env56865 = env56866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56865 == env56866) = true)

theorem identity56866 : scanCanonicalize (H12AffineFastState.compose env56866 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56866 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env56867 : List Nat := [2,4,3,16,17,17,3,256,512,4,788,789,263,773,277,19,513,772,4,277,512,17,261,2,278,277,513,773,512,528,256,17,257,0,512,528]

theorem envBound56867 : H12AffineFastState.Bounded env56867 := by
  intro p hp
  have h : env56867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56866_56867 : H12AffineEnvironment.transform 9 4 env56866 = env56867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56866 == env56867) = true)

def env56868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142599,28889,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound56868 : H12AffineFastState.Bounded env56868 := by
  intro p hp
  have h : env56868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56812_56868 : H12AffineEnvironment.transform 21 41089 env56812 = env56868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56812 == env56868) = true)

theorem identity56868 : scanCanonicalize (H12AffineFastState.compose env56868 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound56868 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,32768,65536,74046,82112,1024,32768,2097152,41089,2097580,2138219,24885,2113600,99824,16384,74094,92599,2172011,74119,257,2187387,74047,17340]

theorem envBound56869 : H12AffineFastState.Bounded env56869 := by
  intro p hp
  have h : env56869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56868_56869 : H12AffineEnvironment.transform 11 492 env56868 = env56869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env56868 == env56869) = true)

theorem identity56869 : scanCanonicalize (H12AffineFastState.compose env56869 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56869 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,16384,32768,65536,66614,82112,1024,32768,2097152,34185,2097580,2131299,17469,2113600,99824,16384,66662,85183,2163043,66703,257,2180467,66615,17340]

theorem envBound56870 : H12AffineFastState.Bounded env56870 := by
  intro p hp
  have h : env56870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56869_56870 : H12AffineEnvironment.transform 12 1288 env56869 = env56870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56869 == env56870) = true)

theorem identity56870 : scanCanonicalize (H12AffineFastState.compose env56870 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 83419) := by decide +kernel

theorem selectedBound56870 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,16384,32768,65536,66614,82112,1024,32768,83419,34185,83063,114872,17469,66971,99824,16384,66662,85183,17592,66703,257,168,66615,17340]

theorem envBound56871 : H12AffineFastState.Bounded env56871 := by
  intro p hp
  have h : env56871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56870_56871 : H12AffineEnvironment.transform 20 83419 env56870 = env56871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83419 env56870 == env56871) = true)

theorem identity56871 : scanCanonicalize (H12AffineFastState.compose env56871 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound56871 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,65536,66614,65916,1024,32768,66663,34185,67019,98564,1409,66971,99824,444,66662,68867,1284,66703,257,168,66615,512]

theorem envBound56872 : H12AffineFastState.Bounded env56872 := by
  intro p hp
  have h : env56872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56871_56872 : H12AffineEnvironment.transform 13 444 env56871 = env56872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env56871 == env56872) = true)

theorem identity56872 : scanCanonicalize (H12AffineFastState.compose env56872 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound56872 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,1875,869,1583,1024,32768,820,34185,664,34391,1409,712,33443,444,821,2640,1284,988,257,168,868,512]

theorem envBound56873 : H12AffineFastState.Bounded env56873 := by
  intro p hp
  have h : env56873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56872_56873 : H12AffineEnvironment.transform 15 1875 env56872 = env56873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env56872 == env56873) = true)

def env56874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4273308,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound56874 : H12AffineFastState.Bounded env56874 := by
  intro p hp
  have h : env56874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56811_56874 : H12AffineEnvironment.transform 17 82113 env56811 = env56874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env56811 == env56874) = true)

def env56875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142598,28888,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound56875 : H12AffineFastState.Bounded env56875 := by
  intro p hp
  have h : env56875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56874_56875 : H12AffineEnvironment.transform 21 41088 env56874 = env56875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56874 == env56875) = true)

theorem identity56875 : scanCanonicalize (H12AffineFastState.compose env56875 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound56875 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56876 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,78034,82113,253,32768,2097152,41088,2101313,2142598,28888,2113601,102625,16384,77954,96346,2175355,74118,257,2187386,78035,21073]

theorem envBound56876 : H12AffineFastState.Bounded env56876 := by
  intro p hp
  have h : env56876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56875_56876 : H12AffineEnvironment.transform 9 253 env56875 = env56876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env56875 == env56876) = true)

theorem identity56876 : scanCanonicalize (H12AffineFastState.compose env56876 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 70007) := by decide +kernel

theorem selectedBound56876 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56877 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,78034,82113,253,32768,70007,41088,65846,106737,28888,86326,102625,16384,77954,96346,8204,74118,257,28941,78035,21073]

theorem envBound56877 : H12AffineFastState.Bounded env56877 := by
  intro p hp
  have h : env56877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56876_56877 : H12AffineEnvironment.transform 20 70007 env56876 = env56877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70007 env56876 == env56877) = true)

theorem identity56877 : scanCanonicalize (H12AffineFastState.compose env56877 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound56877 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56878 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,33166,45404,49487,253,32768,37113,41088,32952,8575,28888,53432,4463,16384,45324,63956,8204,40968,257,28941,45405,21073]

theorem envBound56878 : H12AffineFastState.Bounded env56878 := by
  intro p hp
  have h : env56878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56877_56878 : H12AffineEnvironment.transform 15 33166 env56877 = env56878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env56877 == env56878) = true)

def env56879 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,4096,32768,33166,45404,37199,253,32768,37113,41088,32952,8575,8408,32952,4463,4096,45324,43476,8204,40968,257,8461,45405,593]

theorem envBound56879 : H12AffineFastState.Bounded env56879 := by
  intro p hp
  have h : env56879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56878_56879 : H12AffineEnvironment.transform 13 4096 env56878 = env56879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env56878 == env56879) = true)

def env56880 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4096,32768,33166,45324,37151,173,32768,37033,41088,32952,8495,8328,32952,4415,4096,45324,43396,8204,40968,257,8461,45325,513]

theorem envBound56880 : H12AffineFastState.Bounded env56880 := by
  intro p hp
  have h : env56880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56879_56880 : H12AffineEnvironment.transform 5 16 env56879 = env56880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56879 == env56880) = true)

theorem identity56880 : scanCanonicalize (H12AffineFastState.compose env56880 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound56880 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56881 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4096,33,431,12589,4414,173,33,4232,8353,153,8495,8328,153,4415,4096,12589,10661,8204,8233,257,8461,12588,513]

theorem envBound56881 : H12AffineFastState.Bounded env56881 := by
  intro p hp
  have h : env56881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56880_56881 : H12AffineEnvironment.transform 14 33 env56880 = env56881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env56880 == env56881) = true)

theorem identity56881 : scanCanonicalize (H12AffineFastState.compose env56881 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound56881 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56882 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,300,4096,33,431,4097,4414,173,33,4232,397,153,3,420,153,4415,4096,4097,2185,288,261,257,33,4096,513]

theorem envBound56882 : H12AffineFastState.Bounded env56882 := by
  intro p hp
  have h : env56882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56881_56882 : H12AffineEnvironment.transform 12 300 env56881 = env56882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env56881 == env56882) = true)

theorem identity56882 : scanCanonicalize (H12AffineFastState.compose env56882 (packedSelected [0,1,2,4,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 901) := by decide +kernel

theorem selectedBound56882 : packedSelected [0,1,2,4,9,10,13] rootPS < 2^1333 := by decide +kernel

def env56883 : List Nat := [2,4,8,16,32,16,128,256,512,173,901,4096,300,4096,33,431,4097,4414,173,33,4232,397,153,3,420,153,4415,4096,4097,780,288,261,257,33,4096,513]

theorem envBound56883 : H12AffineFastState.Bounded env56883 := by
  intro p hp
  have h : env56883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56882_56883 : H12AffineEnvironment.transform 10 901 env56882 = env56883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 901 env56882 == env56883) = true)

theorem identity56883 : scanCanonicalize (H12AffineFastState.compose env56883 (packedSelected [0,1,2,4,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 791) := by decide +kernel

theorem selectedBound56883 : packedSelected [0,1,2,4,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56884 : List Nat := [2,4,8,16,32,16,128,256,512,173,901,791,300,791,33,431,790,553,173,33,927,397,153,3,420,153,552,791,790,780,288,261,257,33,791,513]

theorem envBound56884 : H12AffineFastState.Bounded env56884 := by
  intro p hp
  have h : env56884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56883_56884 : H12AffineEnvironment.transform 11 791 env56883 = env56884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 791 env56883 == env56884) = true)

theorem identity56884 : scanCanonicalize (H12AffineFastState.compose env56884 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound56884 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56885 : List Nat := [2,4,8,16,32,16,128,6,512,173,643,529,42,529,33,169,528,553,173,33,665,139,153,3,162,153,552,529,528,522,38,3,7,33,529,513]

theorem envBound56885 : H12AffineFastState.Bounded env56885 := by
  intro p hp
  have h : env56885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56884_56885 : H12AffineEnvironment.transform 7 6 env56884 = env56885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env56884 == env56885) = true)

theorem identity56885 : scanCanonicalize (H12AffineFastState.compose env56885 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 155) := by decide +kernel

theorem selectedBound56885 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env56886 : List Nat := [2,4,8,16,32,16,128,6,155,173,24,138,42,138,33,169,139,178,173,33,2,139,153,3,162,153,179,138,139,145,38,3,7,33,138,154]

theorem envBound56886 : H12AffineFastState.Bounded env56886 := by
  intro p hp
  have h : env56886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56885_56886 : H12AffineEnvironment.transform 8 155 env56885 = env56886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 155 env56885 == env56886) = true)

theorem identity56886 : scanCanonicalize (H12AffineFastState.compose env56886 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound56886 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56887 : List Nat := [2,4,8,16,2,16,128,6,155,143,24,138,8,138,3,139,139,144,143,3,2,139,153,3,128,153,145,138,139,145,4,3,7,3,138,154]

theorem envBound56887 : H12AffineFastState.Bounded env56887 := by
  intro p hp
  have h : env56887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56886_56887 : H12AffineEnvironment.transform 4 2 env56886 = env56887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env56886 == env56887) = true)

theorem identity56887 : scanCanonicalize (H12AffineFastState.compose env56887 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56887 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56888 : List Nat := [2,4,8,16,2,16,2,6,25,13,24,8,8,8,3,9,9,18,13,3,2,9,27,3,2,27,19,8,9,19,4,3,7,3,8,24]

theorem envBound56888 : H12AffineFastState.Bounded env56888 := by
  intro p hp
  have h : env56888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56887_56888 : H12AffineEnvironment.transform 6 2 env56887 = env56888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56887 == env56888) = true)

theorem identity56888 : scanCanonicalize (H12AffineFastState.compose env56888 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56889 : List Nat := [2,4,3,16,2,16,2,6,18,6,19,3,3,3,3,2,2,18,6,3,2,2,16,3,2,16,19,3,2,19,4,3,7,3,3,19]

theorem envBound56889 : H12AffineFastState.Bounded env56889 := by
  intro p hp
  have h : env56889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56888_56889 : H12AffineEnvironment.transform 2 3 env56888 = env56889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56888 == env56889) = true)

theorem identity56889 : scanCanonicalize (H12AffineFastState.compose env56889 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56890 : List Nat := [0,4,1,16,0,16,0,4,16,4,17,1,1,1,1,0,0,16,4,1,0,0,16,1,0,16,17,1,0,17,4,1,5,1,1,17]

theorem envBound56890 : H12AffineFastState.Bounded env56890 := by
  intro p hp
  have h : env56890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56889_56890 : H12AffineEnvironment.transform 0 0 env56889 = env56890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56889 == env56890) = true)

theorem identity56890 : scanCanonicalize (H12AffineFastState.compose env56890 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56890 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56891 : List Nat := [0,4,1,0,0,0,0,4,0,4,1,1,1,1,1,0,0,0,4,1,0,0,0,1,0,0,1,1,0,1,4,1,5,1,1,1]

theorem envBound56891 : H12AffineFastState.Bounded env56891 := by
  intro p hp
  have h : env56891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56890_56891 : H12AffineEnvironment.transform 3 0 env56890 = env56891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56890 == env56891) = true)

def env56892 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,8192,4096,32768,33166,45325,37150,172,32768,37032,41088,32952,8494,8329,32952,4414,4096,45324,43397,8204,40968,257,8461,45324,512]

theorem envBound56892 : H12AffineFastState.Bounded env56892 := by
  intro p hp
  have h : env56892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56879_56892 : H12AffineEnvironment.transform 5 17 env56879 = env56892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56879 == env56892) = true)

theorem identity56892 : scanCanonicalize (H12AffineFastState.compose env56892 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound56892 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56893 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,2563,4096,32768,33166,39694,37150,172,32768,37032,35459,32952,2861,2698,32952,4414,4096,39695,33670,2575,35339,257,2830,39695,512]

theorem envBound56893 : H12AffineFastState.Bounded env56893 := by
  intro p hp
  have h : env56893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56892_56893 : H12AffineEnvironment.transform 12 2563 env56892 = env56893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env56892 == env56893) = true)

theorem identity56893 : scanCanonicalize (H12AffineFastState.compose env56893 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound56893 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56894 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,2563,4096,2723,2861,4525,7101,172,2723,6667,32,2587,2861,2698,2587,4414,4096,4524,2341,2575,168,257,2830,4524,512]

theorem envBound56894 : H12AffineFastState.Bounded env56894 := by
  intro p hp
  have h : env56894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56893_56894 : H12AffineEnvironment.transform 14 2723 env56893 = env56894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env56893 == env56894) = true)

theorem identity56894 : scanCanonicalize (H12AffineFastState.compose env56894 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound56894 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env56895 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,545,2563,545,2723,2861,908,2460,172,2723,2090,32,2587,2861,2698,2587,799,545,909,2341,2575,168,257,2830,909,512]

theorem envBound56895 : H12AffineFastState.Bounded env56895 := by
  intro p hp
  have h : env56895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56894_56895 : H12AffineEnvironment.transform 11 545 env56894 = env56895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env56894 == env56895) = true)

theorem identity56895 : scanCanonicalize (H12AffineFastState.compose env56895 (packedSelected [1,3,4,9,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound56895 : packedSelected [1,3,4,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env56896 : List Nat := [2,4,8,16,32,17,128,256,512,172,935,545,420,545,260,138,908,571,172,260,909,32,444,138,301,444,799,545,909,642,424,168,257,169,909,512]

theorem envBound56896 : H12AffineFastState.Bounded env56896 := by
  intro p hp
  have h : env56896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56895_56896 : H12AffineEnvironment.transform 10 935 env56895 = env56896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env56895 == env56896) = true)

theorem identity56896 : scanCanonicalize (H12AffineFastState.compose env56896 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56896 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56897 : List Nat := [2,4,8,16,32,17,128,20,512,172,691,545,176,545,16,138,664,571,172,16,665,32,168,138,57,168,523,545,665,642,188,168,21,169,665,512]

theorem envBound56897 : H12AffineFastState.Bounded env56897 := by
  intro p hp
  have h : env56897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56896_56897 : H12AffineEnvironment.transform 7 20 env56896 = env56897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56896 == env56897) = true)

def env56898 : List Nat := [2,4,8,16,32,17,128,20,48,172,131,17,176,17,16,138,168,11,172,16,169,32,168,138,57,168,59,17,169,178,188,168,21,169,169,48]

theorem envBound56898 : H12AffineFastState.Bounded env56898 := by
  intro p hp
  have h : env56898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56897_56898 : H12AffineEnvironment.transform 8 48 env56897 = env56898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56897 == env56898) = true)

theorem identity56898 : scanCanonicalize (H12AffineFastState.compose env56898 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound56898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56899 : List Nat := [2,4,8,16,27,17,128,20,11,151,131,17,139,17,16,138,147,11,151,16,146,27,147,138,2,147,0,17,146,137,135,147,21,146,146,11]

theorem envBound56899 : H12AffineFastState.Bounded env56899 := by
  intro p hp
  have h : env56899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56898_56899 : H12AffineEnvironment.transform 4 27 env56898 = env56899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env56898 == env56899) = true)

def env56900 : List Nat := [2,4,8,0,11,1,128,4,11,135,131,1,139,1,0,138,131,11,135,0,130,11,131,138,2,131,0,1,130,137,135,131,5,130,130,11]

theorem envBound56900 : H12AffineFastState.Bounded env56900 := by
  intro p hp
  have h : env56900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56899_56900 : H12AffineEnvironment.transform 3 0 env56899 = env56900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56899 == env56900) = true)

theorem identity56900 : scanCanonicalize (H12AffineFastState.compose env56900 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56900 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56901 : List Nat := [2,4,2,0,1,1,128,4,1,135,131,1,129,1,0,128,131,1,135,0,130,1,131,128,2,131,0,1,130,131,135,131,5,130,130,1]

theorem envBound56901 : H12AffineFastState.Bounded env56901 := by
  intro p hp
  have h : env56901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56900_56901 : H12AffineEnvironment.transform 2 2 env56900 = env56901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56900 == env56901) = true)

def env56902 : List Nat := [2,4,8,1,10,0,128,5,11,134,131,0,139,0,1,138,130,11,134,1,131,10,130,138,2,130,0,0,131,137,135,130,4,131,131,11]

theorem envBound56902 : H12AffineFastState.Bounded env56902 := by
  intro p hp
  have h : env56902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56899_56902 : H12AffineEnvironment.transform 3 1 env56899 = env56902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56899 == env56902) = true)

def env56903 : List Nat := [2,4,8,16,32,17,128,20,49,172,130,16,176,16,16,138,169,10,172,16,168,32,168,138,57,168,58,16,168,179,188,168,21,169,168,49]

theorem envBound56903 : H12AffineFastState.Bounded env56903 := by
  intro p hp
  have h : env56903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56897_56903 : H12AffineEnvironment.transform 8 49 env56897 = env56903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56897 == env56903) = true)

theorem identity56903 : scanCanonicalize (H12AffineFastState.compose env56903 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound56903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56904 : List Nat := [2,4,8,16,32,17,51,20,49,31,49,16,3,16,16,57,26,10,31,16,27,32,27,57,57,27,58,16,27,0,15,27,21,26,27,49]

theorem envBound56904 : H12AffineFastState.Bounded env56904 := by
  intro p hp
  have h : env56904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56903_56904 : H12AffineEnvironment.transform 6 51 env56903 = env56904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env56903 == env56904) = true)

def env56905 : List Nat := [2,4,8,16,16,17,3,20,1,31,1,16,3,16,16,9,26,10,31,16,27,16,27,9,9,27,10,16,27,0,15,27,21,26,27,1]

theorem envBound56905 : H12AffineFastState.Bounded env56905 := by
  intro p hp
  have h : env56905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56904_56905 : H12AffineEnvironment.transform 4 16 env56904 = env56905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56904 == env56905) = true)

def env56906 : List Nat := [2,4,8,16,17,17,2,20,0,31,0,16,3,16,16,8,26,10,31,16,27,17,27,8,8,27,11,16,27,0,15,27,21,26,27,0]

theorem envBound56906 : H12AffineFastState.Bounded env56906 := by
  intro p hp
  have h : env56906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56904_56906 : H12AffineEnvironment.transform 4 17 env56904 = env56906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56904 == env56906) = true)

theorem identity56906 : scanCanonicalize (H12AffineFastState.compose env56906 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56907 : List Nat := [2,4,8,10,11,11,2,14,0,5,0,10,3,10,10,8,0,10,5,10,1,11,1,8,8,1,11,10,1,0,15,1,15,0,1,0]

theorem envBound56907 : H12AffineFastState.Bounded env56907 := by
  intro p hp
  have h : env56907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56906_56907 : H12AffineEnvironment.transform 3 10 env56906 = env56907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56906 == env56907) = true)

def env56908 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,4097,32768,33166,45404,37198,253,32768,37113,41088,32952,8575,8409,32953,4463,4097,45324,43477,8204,40968,257,8460,45405,592]

theorem envBound56908 : H12AffineFastState.Bounded env56908 := by
  intro p hp
  have h : env56908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56878_56908 : H12AffineEnvironment.transform 13 4097 env56878 = env56908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env56878 == env56908) = true)

theorem identity56908 : scanCanonicalize (H12AffineFastState.compose env56908 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56908 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env56909 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4097,32768,33166,45324,37150,173,32768,37033,41088,32952,8495,8329,32953,4415,4097,45324,43397,8204,40968,257,8460,45325,512]

theorem envBound56909 : H12AffineFastState.Bounded env56909 := by
  intro p hp
  have h : env56909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56908_56909 : H12AffineEnvironment.transform 5 16 env56908 = env56909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56908 == env56909) = true)

theorem identity56909 : scanCanonicalize (H12AffineFastState.compose env56909 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound56909 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56910 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2563,4097,32768,33166,39695,37150,173,32768,37033,35459,32952,2860,2698,32953,4415,4097,39695,33670,2575,35339,257,2831,39694,512]

theorem envBound56910 : H12AffineFastState.Bounded env56910 := by
  intro p hp
  have h : env56910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56909_56910 : H12AffineEnvironment.transform 12 2563 env56909 = env56910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env56909 == env56910) = true)

theorem identity56910 : scanCanonicalize (H12AffineFastState.compose env56910 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound56910 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56911 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2563,4097,2723,2861,4524,7101,173,2723,6666,32,2587,2860,2698,2586,4415,4097,4524,2341,2575,168,257,2831,4525,512]

theorem envBound56911 : H12AffineFastState.Bounded env56911 := by
  intro p hp
  have h : env56911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56910_56911 : H12AffineEnvironment.transform 14 2723 env56910 = env56911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env56910 == env56911) = true)

theorem identity56911 : scanCanonicalize (H12AffineFastState.compose env56911 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound56911 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env56912 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,2090,2563,2091,2723,2861,2438,919,173,2723,544,32,2587,2860,2698,2586,2325,2091,2438,2341,2575,168,257,2831,2439,512]

theorem envBound56912 : H12AffineFastState.Bounded env56912 := by
  intro p hp
  have h : env56912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56911_56912 : H12AffineEnvironment.transform 11 2090 env56911 = env56912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env56911 == env56912) = true)

theorem identity56912 : scanCanonicalize (H12AffineFastState.compose env56912 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56912 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env56913 : List Nat := [2,4,8,16,32,16,57,256,512,20,2048,2090,2563,2091,2586,2861,2367,814,20,2586,544,32,2587,2860,2611,2586,2325,2091,2367,2341,2575,17,257,2831,2366,512]

theorem envBound56913 : H12AffineFastState.Bounded env56913 := by
  intro p hp
  have h : env56913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56912_56913 : H12AffineEnvironment.transform 6 57 env56912 = env56913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56912 == env56913) = true)

theorem identity56913 : scanCanonicalize (H12AffineFastState.compose env56913 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound56913 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56914 : List Nat := [2,4,8,16,32,16,57,256,512,20,799,821,284,820,261,50,544,814,20,261,544,32,260,51,300,261,522,820,544,570,272,17,257,16,545,512]

theorem envBound56914 : H12AffineFastState.Bounded env56914 := by
  intro p hp
  have h : env56914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56913_56914 : H12AffineEnvironment.transform 10 799 env56913 = env56914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env56913 == env56914) = true)

def env56915 : List Nat := [2,4,8,16,16,16,9,256,512,20,799,773,284,772,261,2,528,798,20,261,528,16,260,3,284,261,522,772,528,522,272,17,257,16,529,512]

theorem envBound56915 : H12AffineFastState.Bounded env56915 := by
  intro p hp
  have h : env56915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56914_56915 : H12AffineEnvironment.transform 4 16 env56914 = env56915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56914 == env56915) = true)

theorem identity56915 : scanCanonicalize (H12AffineFastState.compose env56915 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound56915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56916 : List Nat := [2,4,8,16,16,16,9,31,512,20,512,538,3,539,26,2,528,513,20,26,528,16,27,3,3,26,522,539,528,522,15,17,30,16,529,512]

theorem envBound56916 : H12AffineFastState.Bounded env56916 := by
  intro p hp
  have h : env56916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56915_56916 : H12AffineEnvironment.transform 7 31 env56915 = env56916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env56915 == env56916) = true)

theorem identity56916 : scanCanonicalize (H12AffineFastState.compose env56916 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56917 : List Nat := [2,4,8,11,11,11,9,4,512,15,512,513,3,512,1,2,523,513,15,1,523,11,0,3,3,1,522,512,523,522,15,10,5,11,522,512]

theorem envBound56917 : H12AffineFastState.Bounded env56917 := by
  intro p hp
  have h : env56917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56916_56917 : H12AffineEnvironment.transform 3 11 env56916 = env56917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56916 == env56917) = true)

def env56918 : List Nat := [2,4,8,16,17,16,8,256,512,20,799,772,284,773,261,3,529,799,20,261,529,17,260,2,285,261,522,773,529,523,272,17,257,16,528,512]

theorem envBound56918 : H12AffineFastState.Bounded env56918 := by
  intro p hp
  have h : env56918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56914_56918 : H12AffineEnvironment.transform 4 17 env56914 = env56918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56914 == env56918) = true)

theorem identity56918 : scanCanonicalize (H12AffineFastState.compose env56918 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound56918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56919 : List Nat := [2,4,8,16,17,16,8,256,10,20,277,270,284,271,261,3,27,277,20,261,27,17,260,2,285,261,0,271,27,1,272,17,257,16,26,10]

theorem envBound56919 : H12AffineFastState.Bounded env56919 := by
  intro p hp
  have h : env56919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56918_56919 : H12AffineEnvironment.transform 8 10 env56918 = env56919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env56918 == env56919) = true)

theorem identity56919 : scanCanonicalize (H12AffineFastState.compose env56919 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56919 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56920 : List Nat := [2,4,8,16,17,16,8,14,10,20,27,0,18,1,11,3,27,27,20,11,27,17,10,2,19,11,0,1,27,1,30,17,15,16,26,10]

theorem envBound56920 : H12AffineFastState.Bounded env56920 := by
  intro p hp
  have h : env56920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56919_56920 : H12AffineEnvironment.transform 7 14 env56919 = env56920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56919 == env56920) = true)

def env56921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142599,28889,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound56921 : H12AffineFastState.Bounded env56921 := by
  intro p hp
  have h : env56921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56874_56921 : H12AffineEnvironment.transform 21 41089 env56874 = env56921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56874 == env56921) = true)

theorem identity56921 : scanCanonicalize (H12AffineFastState.compose env56921 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound56921 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,32768,65536,78034,65916,1024,32768,2097152,41089,2101312,2142599,12644,2097661,103453,445,77954,80358,2176391,74119,257,2171334,78035,5101]

theorem envBound56922 : H12AffineFastState.Bounded env56922 := by
  intro p hp
  have h : env56922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56921_56922 : H12AffineEnvironment.transform 13 445 env56921 = env56922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env56921 == env56922) = true)

theorem identity56922 : scanCanonicalize (H12AffineFastState.compose env56922 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56922 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,445,32768,65536,71130,65916,1024,32768,2097152,34185,2101312,2135183,5228,2097661,103453,445,71050,72942,2166927,66703,257,2163918,71131,5101]

theorem envBound56923 : H12AffineFastState.Bounded env56923 := by
  intro p hp
  have h : env56923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56922_56923 : H12AffineEnvironment.transform 12 1288 env56922 = env56923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56922 == env56923) = true)

theorem identity56923 : scanCanonicalize (H12AffineFastState.compose env56923 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 66662) := by decide +kernel

theorem selectedBound56923 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,445,32768,65536,71130,65916,1024,32768,66662,34185,70694,102633,5228,66971,103453,445,71050,72942,5353,66703,257,168,71131,5101]

theorem envBound56924 : H12AffineFastState.Bounded env56924 := by
  intro p hp
  have h : env56924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56923_56924 : H12AffineEnvironment.transform 20 66662 env56923 = env56924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66662 env56923 == env56924) = true)

theorem identity56924 : scanCanonicalize (H12AffineFastState.compose env56924 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56924 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,65536,66615,65916,1024,32768,66662,34185,67019,98564,1409,66971,99824,445,66663,68867,1284,66703,257,168,66614,512]

theorem envBound56925 : H12AffineFastState.Bounded env56925 := by
  intro p hp
  have h : env56925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56924_56925 : H12AffineEnvironment.transform 11 493 env56924 = env56925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56924 == env56925) = true)

theorem identity56925 : scanCanonicalize (H12AffineFastState.compose env56925 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound56925 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,1875,868,1583,1024,32768,821,34185,664,34391,1409,712,33443,445,820,2640,1284,988,257,168,869,512]

theorem envBound56926 : H12AffineFastState.Bounded env56926 := by
  intro p hp
  have h : env56926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56925_56926 : H12AffineEnvironment.transform 15 1875 env56925 = env56926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env56925 == env56926) = true)

def env56927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,4247641,8409088,10798236,16384,77954,4315354,8463815,10564039,257,6406394,78035,4256464]

theorem envBound56927 : H12AffineFastState.Bounded env56927 := by
  intro p hp
  have h : env56927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56720_56927 : H12AffineEnvironment.transform 24 4247641 env56720 = env56927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env56720 == env56927) = true)

def env56928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4486236,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound56928 : H12AffineFastState.Bounded env56928 := by
  intro p hp
  have h : env56928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56927_56928 : H12AffineEnvironment.transform 22 6336704 env56927 = env56928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env56927 == env56928) = true)

def env56929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4273308,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound56929 : H12AffineFastState.Bounded env56929 := by
  intro p hp
  have h : env56929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56928_56929 : H12AffineEnvironment.transform 17 82112 env56928 = env56929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env56928 == env56929) = true)

def env56930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142599,28889,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound56930 : H12AffineFastState.Bounded env56930 := by
  intro p hp
  have h : env56930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56929_56930 : H12AffineEnvironment.transform 21 41088 env56929 = env56930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56929 == env56930) = true)

theorem identity56930 : scanCanonicalize (H12AffineFastState.compose env56930 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17849) := by decide +kernel

theorem selectedBound56930 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17849,65536,78034,82112,1024,17849,2097152,25913,2101312,2126910,28889,2113600,86437,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound56931 : H12AffineFastState.Bounded env56931 := by
  intro p hp
  have h : env56931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56930_56931 : H12AffineEnvironment.transform 14 17849 env56930 = env56931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17849 env56930 == env56931) = true)

theorem identity56931 : scanCanonicalize (H12AffineFastState.compose env56931 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound56931 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12512,65536,78034,79257,1024,12512,2097152,4192,2101312,2097511,1408,2110745,75004,13657,77954,68867,2176391,74119,257,2168099,78035,9993]

theorem envBound56932 : H12AffineFastState.Bounded env56932 := by
  intro p hp
  have h : env56932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56931_56932 : H12AffineEnvironment.transform 13 13657 env56931 = env56932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env56931 == env56932) = true)

theorem identity56932 : scanCanonicalize (H12AffineFastState.compose env56932 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound56932 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12512,65536,78034,79257,1024,12512,71050,4192,67018,70893,1408,73875,75004,13657,77954,68867,8205,74119,257,169,78035,9993]

theorem envBound56933 : H12AffineFastState.Bounded env56933 := by
  intro p hp
  have h : env56933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56932_56933 : H12AffineEnvironment.transform 20 71050 env56932 = env56933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env56932 == env56933) = true)

theorem identity56933 : scanCanonicalize (H12AffineFastState.compose env56933 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56933 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,65536,71130,69777,1024,5608,71050,4192,67018,70893,1408,66971,66036,4177,71050,68867,1285,66703,257,169,71131,513]

theorem envBound56934 : H12AffineFastState.Bounded env56934 := by
  intro p hp
  have h : env56934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56933_56934 : H12AffineEnvironment.transform 12 1288 env56933 = env56934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56933 == env56934) = true)

theorem identity56934 : scanCanonicalize (H12AffineFastState.compose env56934 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound56934 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,515,6105,4754,1024,5608,6025,4192,1993,5870,1408,1944,1015,4177,6025,3840,1285,1676,257,169,6104,513]

theorem envBound56935 : H12AffineFastState.Bounded env56935 := by
  intro p hp
  have h : env56935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56934_56935 : H12AffineEnvironment.transform 15 515 env56934 = env56935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env56934 == env56935) = true)

theorem identity56935 : scanCanonicalize (H12AffineFastState.compose env56935 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound56935 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,445,1028,515,1589,894,1024,1028,1637,396,1993,1794,1408,1944,1015,445,1637,3840,1285,1676,257,169,1588,513]

theorem envBound56936 : H12AffineFastState.Bounded env56936 := by
  intro p hp
  have h : env56936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56935_56936 : H12AffineEnvironment.transform 11 492 env56935 = env56936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env56935 == env56936) = true)

theorem identity56936 : scanCanonicalize (H12AffineFastState.compose env56936 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound56936 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,492,1288,445,1028,515,1589,894,1024,1028,1637,396,1993,1794,1408,1944,1015,445,1637,10,1285,1676,257,169,1588,513]

theorem envBound56937 : H12AffineFastState.Bounded env56937 := by
  intro p hp
  have h : env56937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56936_56937 : H12AffineEnvironment.transform 10 1802 env56936 = env56937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env56936 == env56937) = true)

theorem identity56937 : scanCanonicalize (H12AffineFastState.compose env56937 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound56937 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56938 : List Nat := [2,4,8,16,32,64,128,256,512,905,131,492,641,445,909,515,444,894,905,909,492,396,64,139,521,17,1015,445,492,10,652,261,257,169,445,513]

theorem envBound56938 : H12AffineFastState.Bounded env56938 := by
  intro p hp
  have h : env56938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56937_56938 : H12AffineEnvironment.transform 9 905 env56937 = env56938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env56937 == env56938) = true)

theorem identity56938 : scanCanonicalize (H12AffineFastState.compose env56938 (packedSelected [0,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56938 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env56939 : List Nat := [2,4,8,1,32,64,128,256,512,905,131,492,641,428,909,515,429,879,905,909,492,396,64,139,521,0,998,428,492,10,652,261,257,169,428,513]

theorem envBound56939 : H12AffineFastState.Bounded env56939 := by
  intro p hp
  have h : env56939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56938_56939 : H12AffineEnvironment.transform 3 1 env56938 = env56939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56938 == env56939) = true)

theorem identity56939 : scanCanonicalize (H12AffineFastState.compose env56939 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56939 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56940 : List Nat := [2,4,8,1,10,64,128,256,512,905,131,454,641,390,909,515,391,837,905,909,454,396,64,139,521,0,972,390,454,10,652,261,257,131,390,513]

theorem envBound56940 : H12AffineFastState.Bounded env56940 := by
  intro p hp
  have h : env56940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56939_56940 : H12AffineEnvironment.transform 4 10 env56939 = env56940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56939 == env56940) = true)

theorem identity56940 : scanCanonicalize (H12AffineFastState.compose env56940 (packedSelected [3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 334) := by decide +kernel

theorem selectedBound56940 : packedSelected [3,4,9] rootPS < 2^1333 := by decide +kernel

def env56941 : List Nat := [2,4,8,1,10,64,128,256,334,199,131,454,463,390,195,333,391,11,199,195,454,396,64,139,327,0,130,390,454,10,450,261,257,131,390,335]

theorem envBound56941 : H12AffineFastState.Bounded env56941 := by
  intro p hp
  have h : env56941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56940_56941 : H12AffineEnvironment.transform 8 334 env56940 = env56941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 334 env56940 == env56941) = true)

theorem identity56941 : scanCanonicalize (H12AffineFastState.compose env56941 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56941 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56942 : List Nat := [2,4,8,1,10,64,8,256,334,79,11,334,327,270,75,333,271,11,79,75,334,260,64,3,327,0,10,270,334,10,330,261,257,11,270,335]

theorem envBound56942 : H12AffineFastState.Bounded env56942 := by
  intro p hp
  have h : env56942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56941_56942 : H12AffineEnvironment.transform 6 8 env56941 = env56942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56941 == env56942) = true)

theorem identity56942 : scanCanonicalize (H12AffineFastState.compose env56942 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound56942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56943 : List Nat := [2,4,8,1,10,64,8,6,72,79,11,72,65,8,75,75,9,11,79,75,72,2,64,3,65,0,10,8,72,10,76,3,7,11,8,73]

theorem envBound56943 : H12AffineFastState.Bounded env56943 := by
  intro p hp
  have h : env56943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56942_56943 : H12AffineEnvironment.transform 7 6 env56942 = env56943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env56942 == env56943) = true)

theorem identity56943 : scanCanonicalize (H12AffineFastState.compose env56943 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56944 : List Nat := [2,4,2,1,0,64,2,6,66,69,1,66,65,2,65,65,3,1,69,65,66,2,64,3,65,0,0,2,66,0,70,3,7,1,2,67]

theorem envBound56944 : H12AffineFastState.Bounded env56944 := by
  intro p hp
  have h : env56944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56943_56944 : H12AffineEnvironment.transform 2 2 env56943 = env56944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56943 == env56944) = true)

def env56945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142598,28888,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound56945 : H12AffineFastState.Bounded env56945 := by
  intro p hp
  have h : env56945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56929_56945 : H12AffineEnvironment.transform 21 41089 env56929 = env56945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56929 == env56945) = true)

theorem identity56945 : scanCanonicalize (H12AffineFastState.compose env56945 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 249) := by decide +kernel

theorem selectedBound56945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,249,65536,78034,82112,1024,249,2097152,8312,2101313,2109823,28888,2113601,70884,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound56946 : H12AffineFastState.Bounded env56946 := by
  intro p hp
  have h : env56946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56945_56946 : H12AffineEnvironment.transform 14 249 env56945 = env56946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 249 env56945 == env56946) = true)

theorem identity56946 : scanCanonicalize (H12AffineFastState.compose env56946 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound56946 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,249,65536,78034,82112,1024,249,83418,8312,87451,95397,28888,66971,70884,16384,77954,96347,28764,74118,257,9633,78035,21073]

theorem envBound56947 : H12AffineFastState.Bounded env56947 := by
  intro p hp
  have h : env56947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56946_56947 : H12AffineEnvironment.transform 20 83418 env56946 = env56947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env56946 == env56947) = true)

theorem identity56947 : scanCanonicalize (H12AffineFastState.compose env56947 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56947 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,65536,78034,69777,1024,249,71051,8312,67018,74996,8329,66971,70884,4177,77954,75786,8205,74118,257,9633,78035,512]

theorem envBound56948 : H12AffineFastState.Bounded env56948 := by
  intro p hp
  have h : env56948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56947_56948 : H12AffineEnvironment.transform 13 4177 env56947 = env56948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56947 == env56948) = true)

theorem identity56948 : scanCanonicalize (H12AffineFastState.compose env56948 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound56948 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,375,12709,4582,1024,249,5372,8312,1213,9603,8329,1260,5523,4177,12789,10621,8205,8433,257,9633,12708,512]

theorem envBound56949 : H12AffineFastState.Bounded env56949 := by
  intro p hp
  have h : env56949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56948_56949 : H12AffineEnvironment.transform 15 375 env56948 = env56949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env56948 == env56949) = true)

theorem identity56949 : scanCanonicalize (H12AffineFastState.compose env56949 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound56949 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,249,375,8027,4582,1024,249,5372,3718,1213,2941,3703,1260,5523,4177,7947,1923,3827,3599,257,2911,8026,512]

theorem envBound56950 : H12AffineFastState.Bounded env56950 := by
  intro p hp
  have h : env56950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56949_56950 : H12AffineEnvironment.transform 12 3838 env56949 = env56950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env56949 == env56950) = true)

theorem identity56950 : scanCanonicalize (H12AffineFastState.compose env56950 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound56950 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,88,4177,249,375,4605,4582,1024,249,5372,32,1213,1499,209,1260,5523,4177,4525,1923,85,169,257,1529,4604,512]

theorem envBound56951 : H12AffineFastState.Bounded env56951 := by
  intro p hp
  have h : env56951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56950_56951 : H12AffineEnvironment.transform 10 1702 env56950 = env56951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env56950 == env56951) = true)

def env56952 : List Nat := [2,4,8,16,32,64,128,256,512,392,814,4096,88,4177,249,375,4605,4582,392,249,4468,32,309,83,209,356,4123,4177,4525,523,85,169,257,113,4604,512]

theorem envBound56952 : H12AffineFastState.Bounded env56952 := by
  intro p hp
  have h : env56952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56951_56952 : H12AffineEnvironment.transform 9 392 env56951 = env56952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env56951 == env56952) = true)

def env56953 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,4096,40,4129,137,263,4493,4502,392,137,4356,32,309,35,161,276,4123,4129,4525,523,37,169,257,1,4492,512]

theorem envBound56953 : H12AffineFastState.Bounded env56953 := by
  intro p hp
  have h : env56953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56952_56953 : H12AffineEnvironment.transform 5 48 env56952 = env56953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56952 == env56953) = true)

theorem identity56953 : scanCanonicalize (H12AffineFastState.compose env56953 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound56953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56954 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,642,40,675,137,263,783,788,392,137,902,32,309,35,161,276,665,675,815,523,37,169,257,1,782,512]

theorem envBound56954 : H12AffineFastState.Bounded env56954 := by
  intro p hp
  have h : env56954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56953_56954 : H12AffineEnvironment.transform 11 642 env56953 = env56954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env56953 == env56954) = true)

theorem identity56954 : scanCanonicalize (H12AffineFastState.compose env56954 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56954 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56955 : List Nat := [2,4,8,16,32,48,128,20,512,156,570,642,40,675,137,19,539,512,156,137,658,32,33,35,161,0,665,675,571,523,37,169,21,1,538,512]

theorem envBound56955 : H12AffineFastState.Bounded env56955 := by
  intro p hp
  have h : env56955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56954_56955 : H12AffineEnvironment.transform 7 20 env56954 = env56955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56954 == env56955) = true)

theorem identity56955 : scanCanonicalize (H12AffineFastState.compose env56955 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound56955 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56956 : List Nat := [2,4,8,16,32,48,51,20,512,47,570,561,40,528,58,19,539,512,47,58,545,32,33,35,18,0,554,528,571,523,37,26,21,1,538,512]

theorem envBound56956 : H12AffineFastState.Bounded env56956 := by
  intro p hp
  have h : env56956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56955_56956 : H12AffineEnvironment.transform 6 51 env56955 = env56956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env56955 == env56956) = true)

theorem identity56956 : scanCanonicalize (H12AffineFastState.compose env56956 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56956 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env56957 : List Nat := [2,4,8,16,1,17,18,20,512,14,539,528,9,528,27,19,539,512,14,27,512,1,0,2,18,0,523,528,538,523,4,26,21,1,538,512]

theorem envBound56957 : H12AffineFastState.Bounded env56957 := by
  intro p hp
  have h : env56957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56956_56957 : H12AffineEnvironment.transform 4 1 env56956 = env56957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56956 == env56957) = true)

def env56958 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,4096,41,4128,136,262,4492,4503,392,136,4357,32,309,34,160,277,4123,4128,4525,523,36,169,257,0,4493,512]

theorem envBound56958 : H12AffineFastState.Bounded env56958 := by
  intro p hp
  have h : env56958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56952_56958 : H12AffineEnvironment.transform 5 49 env56952 = env56958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56952 == env56958) = true)

theorem identity56958 : scanCanonicalize (H12AffineFastState.compose env56958 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound56958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56959 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,554,41,522,136,262,934,957,392,136,815,32,309,34,160,277,561,522,903,523,36,169,257,0,935,512]

theorem envBound56959 : H12AffineFastState.Bounded env56959 := by
  intro p hp
  have h : env56959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56958_56959 : H12AffineEnvironment.transform 11 554 env56958 = env56959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env56958 == env56959) = true)

theorem identity56959 : scanCanonicalize (H12AffineFastState.compose env56959 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound56959 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56960 : List Nat := [2,4,8,16,32,49,128,15,512,135,545,554,41,522,136,9,681,690,135,136,544,32,58,34,160,26,561,522,648,523,36,169,14,0,680,512]

theorem envBound56960 : H12AffineFastState.Bounded env56960 := by
  intro p hp
  have h : env56960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56959_56960 : H12AffineEnvironment.transform 7 15 env56959 = env56960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env56959 == env56960) = true)

theorem identity56960 : scanCanonicalize (H12AffineFastState.compose env56960 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound56960 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56961 : List Nat := [2,4,8,16,32,49,50,15,512,53,545,554,41,522,58,9,539,512,53,58,544,32,58,34,18,26,561,522,570,523,36,27,14,0,538,512]

theorem envBound56961 : H12AffineFastState.Bounded env56961 := by
  intro p hp
  have h : env56961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56960_56961 : H12AffineEnvironment.transform 6 50 env56960 = env56961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env56960 == env56961) = true)

theorem identity56961 : scanCanonicalize (H12AffineFastState.compose env56961 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56961 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env56962 : List Nat := [2,4,8,16,10,27,24,15,512,31,523,512,3,522,16,9,539,512,31,16,522,10,16,8,18,26,539,522,528,523,14,27,14,0,538,512]

theorem envBound56962 : H12AffineFastState.Bounded env56962 := by
  intro p hp
  have h : env56962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56961_56962 : H12AffineEnvironment.transform 4 10 env56961 = env56962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56961 == env56962) = true)

theorem identity56962 : scanCanonicalize (H12AffineFastState.compose env56962 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56963 : List Nat := [2,4,8,10,10,1,2,15,512,5,523,512,3,522,10,9,513,512,5,10,522,10,10,8,8,0,513,522,522,523,14,1,14,0,512,512]

theorem envBound56963 : H12AffineFastState.Bounded env56963 := by
  intro p hp
  have h : env56963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56962_56963 : H12AffineEnvironment.transform 3 10 env56962 = env56963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56962 == env56963) = true)

def env56964 : List Nat := [2,4,8,16,32,64,128,256,512,393,815,4096,88,4177,249,375,4605,4582,393,249,4469,32,308,82,209,357,4122,4177,4525,522,85,169,257,112,4604,512]

theorem envBound56964 : H12AffineFastState.Bounded env56964 := by
  intro p hp
  have h : env56964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56951_56964 : H12AffineEnvironment.transform 9 393 env56951 = env56964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env56951 == env56964) = true)

def env56965 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,4096,40,4129,137,263,4493,4502,393,137,4357,32,308,34,161,277,4122,4129,4525,522,37,169,257,0,4492,512]

theorem envBound56965 : H12AffineFastState.Bounded env56965 := by
  intro p hp
  have h : env56965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56964_56965 : H12AffineEnvironment.transform 5 48 env56964 = env56965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56964 == env56965) = true)

theorem identity56965 : scanCanonicalize (H12AffineFastState.compose env56965 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 903) := by decide +kernel

theorem selectedBound56965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56966 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,903,40,934,137,263,522,529,393,137,642,32,308,34,161,277,925,934,554,522,37,169,257,0,523,512]

theorem envBound56966 : H12AffineFastState.Bounded env56966 := by
  intro p hp
  have h : env56966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56965_56966 : H12AffineEnvironment.transform 11 903 env56965 = env56966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 903 env56965 == env56966) = true)

theorem identity56966 : scanCanonicalize (H12AffineFastState.compose env56966 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound56966 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56967 : List Nat := [2,4,8,16,32,48,128,256,276,393,59,147,40,178,137,263,286,261,393,137,406,32,308,34,161,277,137,178,318,286,37,169,257,0,287,276]

theorem envBound56967 : H12AffineFastState.Bounded env56967 := by
  intro p hp
  have h : env56967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56966_56967 : H12AffineEnvironment.transform 8 276 env56966 = env56967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env56966 == env56967) = true)

theorem identity56967 : scanCanonicalize (H12AffineFastState.compose env56967 (packedSelected [0,1,4,7,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound56967 : packedSelected [0,1,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env56968 : List Nat := [2,4,8,16,32,48,128,31,11,150,59,147,40,178,137,24,1,26,150,137,137,32,43,34,161,10,137,178,33,1,37,169,30,0,0,11]

theorem envBound56968 : H12AffineFastState.Bounded env56968 := by
  intro p hp
  have h : env56968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56967_56968 : H12AffineEnvironment.transform 7 31 env56967 = env56968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env56967 == env56968) = true)

theorem identity56968 : scanCanonicalize (H12AffineFastState.compose env56968 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56968 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56969 : List Nat := [2,4,8,16,32,48,40,31,11,62,59,59,40,26,33,24,1,26,62,33,33,32,43,34,9,10,33,26,33,1,37,1,30,0,0,11]

theorem envBound56969 : H12AffineFastState.Bounded env56969 := by
  intro p hp
  have h : env56969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56968_56969 : H12AffineEnvironment.transform 6 40 env56968 = env56969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56968 == env56969) = true)

def env56970 : List Nat := [2,4,8,0,32,32,40,15,11,46,43,43,40,10,33,8,1,10,46,33,33,32,43,34,9,10,33,10,33,1,37,1,14,0,0,11]

theorem envBound56970 : H12AffineFastState.Bounded env56970 := by
  intro p hp
  have h : env56970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56969_56970 : H12AffineEnvironment.transform 3 0 env56969 = env56970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56969 == env56970) = true)

def env56971 : List Nat := [2,4,8,1,32,33,40,14,11,47,42,42,40,11,33,9,1,11,47,33,33,32,43,34,9,10,33,11,33,1,37,1,15,0,0,11]

theorem envBound56971 : H12AffineFastState.Bounded env56971 := by
  intro p hp
  have h : env56971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56969_56971 : H12AffineEnvironment.transform 3 1 env56969 = env56971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56969 == env56971) = true)

theorem identity56971 : scanCanonicalize (H12AffineFastState.compose env56971 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56972 : List Nat := [2,4,8,1,11,10,3,14,11,4,1,1,3,11,10,9,1,11,4,10,10,11,0,9,9,10,10,11,10,1,14,1,15,0,0,11]

theorem envBound56972 : H12AffineFastState.Bounded env56972 := by
  intro p hp
  have h : env56972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56971_56972 : H12AffineEnvironment.transform 4 11 env56971 = env56972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56971 == env56972) = true)

def env56973 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,4096,41,4128,136,262,4492,4503,393,136,4356,32,308,35,160,276,4122,4128,4525,522,36,169,257,1,4493,512]

theorem envBound56973 : H12AffineFastState.Bounded env56973 := by
  intro p hp
  have h : env56973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56964_56973 : H12AffineEnvironment.transform 5 49 env56964 = env56973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56964 == env56973) = true)

theorem identity56973 : scanCanonicalize (H12AffineFastState.compose env56973 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 815) := by decide +kernel

theorem selectedBound56973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56974 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,815,41,783,136,262,675,696,393,136,555,32,308,35,160,276,821,783,642,522,36,169,257,1,674,512]

theorem envBound56974 : H12AffineFastState.Bounded env56974 := by
  intro p hp
  have h : env56974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56973_56974 : H12AffineEnvironment.transform 11 815 env56973 = env56974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 815 env56973 == env56974) = true)

theorem identity56974 : scanCanonicalize (H12AffineFastState.compose env56974 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound56974 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56975 : List Nat := [2,4,8,16,32,49,128,256,11,393,292,292,41,260,136,262,168,179,393,136,32,32,308,35,160,276,318,260,137,1,36,169,257,1,169,11]

theorem envBound56975 : H12AffineFastState.Bounded env56975 := by
  intro p hp
  have h : env56975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56974_56975 : H12AffineEnvironment.transform 8 11 env56974 = env56975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env56974 == env56975) = true)

theorem identity56975 : scanCanonicalize (H12AffineFastState.compose env56975 (packedSelected [0,4,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound56975 : packedSelected [0,4,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56976 : List Nat := [2,4,8,16,32,49,128,30,11,151,58,58,41,26,136,24,168,179,151,136,32,32,42,35,160,10,32,26,137,1,36,169,31,1,169,11]

theorem envBound56976 : H12AffineFastState.Bounded env56976 := by
  intro p hp
  have h : env56976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56975_56976 : H12AffineEnvironment.transform 7 30 env56975 = env56976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env56975 == env56976) = true)

theorem identity56976 : scanCanonicalize (H12AffineFastState.compose env56976 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56976 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env56977 : List Nat := [2,4,8,16,32,49,41,30,11,62,58,58,41,26,33,24,1,26,62,33,32,32,42,35,9,10,32,26,32,1,36,0,31,1,0,11]

theorem envBound56977 : H12AffineFastState.Bounded env56977 := by
  intro p hp
  have h : env56977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56976_56977 : H12AffineEnvironment.transform 6 41 env56976 = env56977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56976 == env56977) = true)

def env56978 : List Nat := [2,4,8,0,32,33,41,14,11,46,42,42,41,10,33,8,1,10,46,33,32,32,42,35,9,10,32,10,32,1,36,0,15,1,0,11]

theorem envBound56978 : H12AffineFastState.Bounded env56978 := by
  intro p hp
  have h : env56978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56977_56978 : H12AffineEnvironment.transform 3 0 env56977 = env56978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56977 == env56978) = true)

theorem identity56978 : scanCanonicalize (H12AffineFastState.compose env56978 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56979 : List Nat := [2,4,8,0,11,10,2,14,11,5,1,1,2,10,10,8,1,10,5,10,11,11,1,8,9,10,11,10,11,1,15,0,15,1,0,11]

theorem envBound56979 : H12AffineFastState.Bounded env56979 := by
  intro p hp
  have h : env56979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56978_56979 : H12AffineEnvironment.transform 4 11 env56978 = env56979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56978 == env56979) = true)

def env56980 : List Nat := [2,4,8,1,32,32,41,15,11,47,43,43,41,11,33,9,1,11,47,33,32,32,42,35,9,10,32,11,32,1,36,0,14,1,0,11]

theorem envBound56980 : H12AffineFastState.Bounded env56980 := by
  intro p hp
  have h : env56980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56977_56980 : H12AffineEnvironment.transform 3 1 env56977 = env56980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56977 == env56980) = true)

def env56981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4273309,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound56981 : H12AffineFastState.Bounded env56981 := by
  intro p hp
  have h : env56981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56928_56981 : H12AffineEnvironment.transform 17 82113 env56928 = env56981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env56928 == env56981) = true)

def env56982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142599,28889,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound56982 : H12AffineFastState.Bounded env56982 := by
  intro p hp
  have h : env56982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56981_56982 : H12AffineEnvironment.transform 21 41088 env56981 = env56982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56981 == env56982) = true)

theorem identity56982 : scanCanonicalize (H12AffineFastState.compose env56982 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 5608) := by decide +kernel

theorem selectedBound56982 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5608,65536,78034,82113,1024,5608,2097152,13672,2101312,2106479,28889,2113600,66037,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound56983 : H12AffineFastState.Bounded env56983 := by
  intro p hp
  have h : env56983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56982_56983 : H12AffineEnvironment.transform 14 5608 env56982 = env56983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5608 env56982 == env56983) = true)

theorem identity56983 : scanCanonicalize (H12AffineFastState.compose env56983 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound56983 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5608,65536,78034,79256,1024,5608,2097152,13672,2101312,2106479,1408,2110745,66037,13657,77954,68867,2176391,74119,257,2168099,78035,9993]

theorem envBound56984 : H12AffineFastState.Bounded env56984 := by
  intro p hp
  have h : env56984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56983_56984 : H12AffineEnvironment.transform 13 13657 env56983 = env56984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env56983 == env56984) = true)

theorem identity56984 : scanCanonicalize (H12AffineFastState.compose env56984 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound56984 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5608,65536,78034,79256,1024,5608,71050,13672,67018,78309,1408,73875,66037,13657,77954,68867,8205,74119,257,169,78035,9993]

theorem envBound56985 : H12AffineFastState.Bounded env56985 := by
  intro p hp
  have h : env56985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56984_56985 : H12AffineEnvironment.transform 20 71050 env56984 = env56985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env56984 == env56985) = true)

theorem identity56985 : scanCanonicalize (H12AffineFastState.compose env56985 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56985 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env56986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,65536,71130,69776,1024,5608,71050,4192,67018,70893,1408,66971,66037,4177,71050,68867,1285,66703,257,169,71131,513]

theorem envBound56986 : H12AffineFastState.Bounded env56986 := by
  intro p hp
  have h : env56986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56985_56986 : H12AffineEnvironment.transform 12 1288 env56985 = env56986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56985 == env56986) = true)

theorem identity56986 : scanCanonicalize (H12AffineFastState.compose env56986 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound56986 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,515,6105,4755,1024,5608,6025,4192,1993,5870,1408,1944,1014,4177,6025,3840,1285,1676,257,169,6104,513]

theorem envBound56987 : H12AffineFastState.Bounded env56987 := by
  intro p hp
  have h : env56987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56986_56987 : H12AffineEnvironment.transform 15 515 env56986 = env56987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env56986 == env56987) = true)

theorem identity56987 : scanCanonicalize (H12AffineFastState.compose env56987 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound56987 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,445,1028,515,1589,895,1024,1028,1637,396,1993,1794,1408,1944,1014,445,1637,3840,1285,1676,257,169,1588,513]

theorem envBound56988 : H12AffineFastState.Bounded env56988 := by
  intro p hp
  have h : env56988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56987_56988 : H12AffineEnvironment.transform 11 492 env56987 = env56988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env56987 == env56988) = true)

theorem identity56988 : scanCanonicalize (H12AffineFastState.compose env56988 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound56988 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,492,1288,445,1028,515,1589,895,1024,1028,1637,396,1993,1794,1408,1944,1014,445,1637,11,1285,1676,257,169,1588,513]

theorem envBound56989 : H12AffineFastState.Bounded env56989 := by
  intro p hp
  have h : env56989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56988_56989 : H12AffineEnvironment.transform 10 1803 env56988 = env56989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env56988 == env56989) = true)

theorem identity56989 : scanCanonicalize (H12AffineFastState.compose env56989 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound56989 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56990 : List Nat := [2,4,8,16,32,64,128,256,512,904,131,492,640,445,908,515,445,895,904,908,493,396,65,138,520,16,1014,445,493,11,653,260,257,169,444,513]

theorem envBound56990 : H12AffineFastState.Bounded env56990 := by
  intro p hp
  have h : env56990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56989_56990 : H12AffineEnvironment.transform 9 904 env56989 = env56990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env56989 == env56990) = true)

theorem identity56990 : scanCanonicalize (H12AffineFastState.compose env56990 (packedSelected [0,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound56990 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env56991 : List Nat := [2,4,8,16,32,48,128,256,512,904,131,412,640,445,908,515,445,783,904,908,413,396,49,138,520,16,902,445,413,11,653,260,257,169,444,513]

theorem envBound56991 : H12AffineFastState.Bounded env56991 := by
  intro p hp
  have h : env56991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56990_56991 : H12AffineEnvironment.transform 5 48 env56990 = env56991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56990 == env56991) = true)

def env56992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142598,28888,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound56992 : H12AffineFastState.Bounded env56992 := by
  intro p hp
  have h : env56992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56981_56992 : H12AffineEnvironment.transform 21 41089 env56981 = env56992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56981 == env56992) = true)

theorem identity56992 : scanCanonicalize (H12AffineFastState.compose env56992 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 20649) := by decide +kernel

theorem selectedBound56992 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20649,65536,78034,82113,1024,20649,2097152,28712,2101313,2122031,28888,2113601,83125,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound56993 : H12AffineFastState.Bounded env56993 := by
  intro p hp
  have h : env56993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56992_56993 : H12AffineEnvironment.transform 14 20649 env56992 = env56993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20649 env56992 == env56993) = true)

theorem identity56993 : scanCanonicalize (H12AffineFastState.compose env56993 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound56993 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20649,65536,78034,82113,1024,20649,83418,28712,87451,74997,28888,66971,83125,16384,77954,96347,28764,74118,257,9633,78035,21073]

theorem envBound56994 : H12AffineFastState.Bounded env56994 := by
  intro p hp
  have h : env56994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56993_56994 : H12AffineEnvironment.transform 20 83418 env56993 = env56994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env56993 == env56994) = true)

theorem identity56994 : scanCanonicalize (H12AffineFastState.compose env56994 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56994 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,65536,78034,69776,1024,248,71051,8313,67018,74997,8329,66971,70884,4177,77954,75786,8205,74118,257,9633,78035,512]

theorem envBound56995 : H12AffineFastState.Bounded env56995 := by
  intro p hp
  have h : env56995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56994_56995 : H12AffineEnvironment.transform 13 4177 env56994 = env56995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56994 == env56995) = true)

theorem identity56995 : scanCanonicalize (H12AffineFastState.compose env56995 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound56995 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,374,12708,4582,1024,248,5373,8313,1212,9603,8329,1261,5522,4177,12788,10620,8205,8432,257,9633,12709,512]

theorem envBound56996 : H12AffineFastState.Bounded env56996 := by
  intro p hp
  have h : env56996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0