import H12CloudChart0Data230

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity58591 : scanCanonicalize (H12AffineFastState.compose env58591 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound58591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58592 : List Nat := [2,4,8,16,32,16,57,21,42,14,59,11,8,11,17,50,11,10,15,17,11,33,16,51,57,17,58,11,11,10,31,17,21,16,11,43]

theorem envBound58592 : H12AffineFastState.Bounded env58592 := by
  intro p hp
  have h : env58592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58591_58592 : H12AffineEnvironment.transform 6 57 env58591 = env58592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58591 == env58592) = true)

theorem identity58592 : scanCanonicalize (H12AffineFastState.compose env58592 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58592 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58593 : List Nat := [2,4,8,16,10,16,19,21,0,14,17,11,8,11,17,24,11,10,15,17,11,11,16,25,19,17,16,11,11,10,31,17,21,16,11,1]

theorem envBound58593 : H12AffineFastState.Bounded env58593 := by
  intro p hp
  have h : env58593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58592_58593 : H12AffineEnvironment.transform 4 10 env58592 = env58593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58592 == env58593) = true)

theorem identity58593 : scanCanonicalize (H12AffineFastState.compose env58593 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58594 : List Nat := [2,4,8,8,10,8,11,13,0,14,9,11,8,11,9,0,11,10,15,9,11,11,8,1,11,9,8,11,11,10,7,9,13,8,11,1]

theorem envBound58594 : H12AffineFastState.Bounded env58594 := by
  intro p hp
  have h : env58594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58593_58594 : H12AffineEnvironment.transform 3 8 env58593 = env58594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58593 == env58594) = true)

def leafEnv58594 : List Nat := [2,4,8,8,10,8,11,13,0,14,9,11,8,11,9,0,11,10,15,9,11,11,8,1,7,11,1,9,8,11,11,10,7,9,13,8,5,3,11,1,1,10,0]

def active58594 : List Nat := [0,1,2]

def tree58594 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58594 : H12WitnessSearch.Good tree58594 := H12GlobalWitnessIndex.good

theorem leafIdentity58594 : H12AffineFastState.composeSystem env58594 rootObs = leafEnv58594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58594 rootObs == leafEnv58594) = true)

theorem terminalChecked58594 : H12PackedTerminal.terminalCheckFast leafEnv58594 active58594 tree58594 = true := by decide +kernel

def env58595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8329,8388688,12919239,4177,131152,4294795,8463815,8594567,256,4425194,131072,512]

theorem envBound58595 : H12AffineFastState.Bounded env58595 := by
  intro p hp
  have h : env58595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58576_58595 : H12AffineEnvironment.transform 13 4177 env58576 = env58595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58576 == env58595) = true)

theorem identity58595 : scanCanonicalize (H12AffineFastState.compose env58595 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58595 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1025,32768,2097152,4194304,8388608,8430022,8329,8388688,12919239,4177,77955,4294795,8463815,8393812,256,4240697,78035,512]

theorem envBound58596 : H12AffineFastState.Bounded env58596 := by
  intro p hp
  have h : env58596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58595_58596 : H12AffineEnvironment.transform 16 78035 env58595 = env58596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58595 == env58596) = true)

theorem identity58596 : scanCanonicalize (H12AffineFastState.compose env58596 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 103747) := by decide +kernel

theorem selectedBound58596 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1025,32768,2097152,103747,8388608,8430022,8329,8388688,8696964,4177,77955,7624,8463815,8393812,256,73850,78035,512]

theorem envBound58597 : H12AffineFastState.Bounded env58597 := by
  intro p hp
  have h : env58597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58596_58597 : H12AffineEnvironment.transform 21 103747 env58596 = env58597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103747 env58596 == env58597) = true)

theorem identity58597 : scanCanonicalize (H12AffineFastState.compose env58597 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 38242) := by decide +kernel

theorem selectedBound58597 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env58598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,262144,1025,32768,2097152,33,8388608,8430022,8329,8388688,8696964,4177,42465,7624,8433829,8393812,256,46360,42417,512]

theorem envBound58598 : H12AffineFastState.Bounded env58598 := by
  intro p hp
  have h : env58598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58597_58598 : H12AffineEnvironment.transform 15 38242 env58597 = env58598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38242 env58597 == env58598) = true)

def env58599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,262144,1025,32768,2097152,33,64,41350,8329,16,308420,4177,42465,7624,45285,5140,256,46360,42417,512]

theorem envBound58599 : H12AffineFastState.Bounded env58599 := by
  intro p hp
  have h : env58599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58598_58599 : H12AffineEnvironment.transform 22 64 env58598 = env58599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env58598 == env58599) = true)

theorem identity58599 : scanCanonicalize (H12AffineFastState.compose env58599 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 48324) := by decide +kernel

theorem selectedBound58599 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,48324,1025,32768,2097152,33,64,41350,8329,16,2048,4177,42465,7624,45285,5140,256,46360,42417,512]

theorem envBound58600 : H12AffineFastState.Bounded env58600 := by
  intro p hp
  have h : env58600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58599_58600 : H12AffineEnvironment.transform 17 48324 env58599 = env58600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48324 env58599 == env58600) = true)

theorem identity58600 : scanCanonicalize (H12AffineFastState.compose env58600 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 1944) := by decide +kernel

theorem selectedBound58600 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,48324,1025,32768,1944,33,64,41350,8329,16,2048,4177,42465,7624,45285,5140,256,46360,42417,512]

theorem envBound58601 : H12AffineFastState.Bounded env58601 := by
  intro p hp
  have h : env58601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58600_58601 : H12AffineEnvironment.transform 20 1944 env58600 = env58601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1944 env58600 == env58601) = true)

theorem identity58601 : scanCanonicalize (H12AffineFastState.compose env58601 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58601 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13423,1212,7625,1025,8461,1944,33,64,139,8329,16,2048,4177,1260,7624,4584,5140,256,5141,1212,512]

theorem envBound58602 : H12AffineFastState.Bounded env58602 := by
  intro p hp
  have h : env58602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58601_58602 : H12AffineEnvironment.transform 14 8461 env58601 = env58602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58601 == env58602) = true)

theorem identity58602 : scanCanonicalize (H12AffineFastState.compose env58602 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound58602 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env58603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,8192,2586,8461,11812,1212,1922,1025,8461,1944,33,64,139,8329,16,2048,2586,1260,1923,2979,3679,256,3678,1212,512]

theorem envBound58603 : H12AffineFastState.Bounded env58603 := by
  intro p hp
  have h : env58603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58602_58603 : H12AffineEnvironment.transform 11 2635 env58602 = env58603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env58602 == env58603) = true)

theorem identity58603 : scanCanonicalize (H12AffineFastState.compose env58603 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 1111) := by decide +kernel

theorem selectedBound58603 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,1111,2586,1370,2675,1212,1922,1025,1370,1944,33,64,139,1246,16,2048,2586,1260,1923,2979,3679,256,3678,1212,512]

theorem envBound58604 : H12AffineFastState.Bounded env58604 := by
  intro p hp
  have h : env58604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58603_58604 : H12AffineEnvironment.transform 12 1111 env58603 = env58604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1111 env58603 == env58604) = true)

theorem identity58604 : scanCanonicalize (H12AffineFastState.compose env58604 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound58604 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env58605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,1261,1111,1212,1370,1237,1212,1922,1025,1370,1944,33,64,139,1246,16,1702,1212,1260,1923,1285,249,256,248,1212,512]

theorem envBound58605 : H12AffineFastState.Bounded env58605 := by
  intro p hp
  have h : env58605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58604_58605 : H12AffineEnvironment.transform 10 1702 env58604 = env58605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env58604 == env58605) = true)

theorem identity58605 : scanCanonicalize (H12AffineFastState.compose env58605 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound58605 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58606 : List Nat := [2,4,8,16,32,64,128,256,292,1024,1410,1261,1111,1212,1370,1237,1212,1190,1025,1370,1212,33,64,139,1246,16,1410,1212,1260,1191,1285,249,256,248,1212,292]

theorem envBound58606 : H12AffineFastState.Bounded env58606 := by
  intro p hp
  have h : env58606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58605_58606 : H12AffineEnvironment.transform 8 292 env58605 = env58606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env58605 == env58606) = true)

def env58607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,262144,1025,32768,2097152,33,65,41351,8329,17,308421,4177,42465,7624,45284,5141,256,46360,42417,512]

theorem envBound58607 : H12AffineFastState.Bounded env58607 := by
  intro p hp
  have h : env58607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58598_58607 : H12AffineEnvironment.transform 22 65 env58598 = env58607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65 env58598 == env58607) = true)

theorem identity58607 : scanCanonicalize (H12AffineFastState.compose env58607 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound58607 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,43049,1025,32768,2097152,33,65,41351,8329,17,7404,4177,42465,7624,45284,5141,256,46360,42417,512]

theorem envBound58608 : H12AffineFastState.Bounded env58608 := by
  intro p hp
  have h : env58608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58607_58608 : H12AffineEnvironment.transform 17 43049 env58607 = env58608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env58607 == env58608) = true)

theorem identity58608 : scanCanonicalize (H12AffineFastState.compose env58608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 4980) := by decide +kernel

theorem selectedBound58608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42417,43049,1025,32768,4980,33,65,41351,8329,17,7404,4177,42465,7624,45284,5141,256,46360,42417,512]

theorem envBound58609 : H12AffineFastState.Bounded env58609 := by
  intro p hp
  have h : env58609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58608_58609 : H12AffineEnvironment.transform 20 4980 env58608 = env58609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4980 env58608 == env58609) = true)

theorem identity58609 : scanCanonicalize (H12AffineFastState.compose env58609 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(14+1) ^^^ 13793) := by decide +kernel

theorem selectedBound58609 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env58610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13793,8323,4176,7624,1025,13793,4980,33,65,5222,8329,17,7404,4177,4096,7624,1285,5141,256,249,4176,512]

theorem envBound58610 : H12AffineFastState.Bounded env58610 := by
  intro p hp
  have h : env58610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58609_58610 : H12AffineEnvironment.transform 14 13793 env58609 = env58610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13793 env58609 == env58610) = true)

theorem identity58610 : scanCanonicalize (H12AffineFastState.compose env58610 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound58610 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1212,8460,8323,1213,2341,1025,8460,1945,33,65,139,8329,17,2049,1212,1261,2341,1285,248,256,249,1213,512]

theorem envBound58611 : H12AffineFastState.Bounded env58611 := by
  intro p hp
  have h : env58611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58610_58611 : H12AffineEnvironment.transform 11 1261 env58610 = env58611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env58610 == env58611) = true)

theorem identity58611 : scanCanonicalize (H12AffineFastState.compose env58611 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound58611 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2948,1212,2696,2823,1213,2341,1025,2696,1945,33,65,139,2829,17,2049,1212,1261,2341,1285,248,256,249,1213,512]

theorem envBound58612 : H12AffineFastState.Bounded env58612 := by
  intro p hp
  have h : env58612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58611_58612 : H12AffineEnvironment.transform 12 2948 env58611 = env58612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env58611 == env58612) = true)

def env58613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131152,4315354,8463815,4294967296,256,4307611964,131073,33563273]

theorem envBound58613 : H12AffineFastState.Bounded env58613 := by
  intro p hp
  have h : env58613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58572_58613 : H12AffineEnvironment.transform 34 131073 env58572 = env58613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58572 == env58613) = true)

theorem identity58613 : scanCanonicalize (H12AffineFastState.compose env58613 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 10695815) := by decide +kernel

theorem selectedBound58613 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131152,4315354,8463815,10695815,256,6538683,131073,33563273]

theorem envBound58614 : H12AffineFastState.Bounded env58614 := by
  intro p hp
  have h : env58614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58613_58614 : H12AffineEnvironment.transform 31 10695815 env58613 = env58614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10695815 env58613 == env58614) = true)

theorem identity58614 : scanCanonicalize (H12AffineFastState.compose env58614 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound58614 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388689,134217728,4176,131152,4294794,8463815,10695815,256,6526443,131073,33563273]

theorem envBound58615 : H12AffineFastState.Bounded env58615 := by
  intro p hp
  have h : env58615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58614_58615 : H12AffineEnvironment.transform 13 4176 env58614 = env58615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58614 == env58615) = true)

theorem identity58615 : scanCanonicalize (H12AffineFastState.compose env58615 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58615 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,134217728,4176,131152,4294794,8463815,10695815,256,6526443,131073,513]

theorem envBound58616 : H12AffineFastState.Bounded env58616 := by
  intro p hp
  have h : env58616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58615_58616 : H12AffineEnvironment.transform 24 8328 env58615 = env58616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58615 == env58616) = true)

theorem identity58616 : scanCanonicalize (H12AffineFastState.compose env58616 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound58616 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,8724554,4176,131152,4294794,8463815,10695815,256,6526443,131073,513]

theorem envBound58617 : H12AffineFastState.Bounded env58617 := by
  intro p hp
  have h : env58617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58616_58617 : H12AffineEnvironment.transform 26 8724554 env58616 = env58617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env58616 == env58617) = true)

theorem identity58617 : scanCanonicalize (H12AffineFastState.compose env58617 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58617 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,4194304,8388608,8430022,8328,8388689,8724554,4176,131152,4294794,8463815,8594567,256,4425195,131073,513]

theorem envBound58618 : H12AffineFastState.Bounded env58618 := by
  intro p hp
  have h : env58618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58617_58618 : H12AffineEnvironment.transform 20 4096 env58617 = env58618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58617 == env58618) = true)

theorem identity58618 : scanCanonicalize (H12AffineFastState.compose env58618 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370577) := by decide +kernel

theorem selectedBound58618 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,4194304,4370577,4329815,8328,4370624,4690139,4176,131152,4294794,4429142,4297750,256,4425195,131073,513]

theorem envBound58619 : H12AffineFastState.Bounded env58619 := by
  intro p hp
  have h : env58619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58618_58619 : H12AffineEnvironment.transform 22 4370577 env58618 = env58619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370577 env58618 == env58619) = true)

theorem identity58619 : scanCanonicalize (H12AffineFastState.compose env58619 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58619 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,176412,135386,8328,176461,495958,4176,131152,100615,234715,103835,256,230502,131073,513]

theorem envBound58620 : H12AffineFastState.Bounded env58620 := by
  intro p hp
  have h : env58620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58619_58620 : H12AffineEnvironment.transform 21 397 env58619 = env58620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58619 == env58620) = true)

theorem identity58620 : scanCanonicalize (H12AffineFastState.compose env58620 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58620 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,131072,262144,1025,8461,4096,397,135185,135386,8328,135232,471131,4176,131152,75786,210390,78998,256,206187,131073,513]

theorem envBound58621 : H12AffineFastState.Bounded env58621 := by
  intro p hp
  have h : env58621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58620_58621 : H12AffineEnvironment.transform 14 8461 env58620 = env58621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58620 == env58621) = true)

theorem identity58621 : scanCanonicalize (H12AffineFastState.compose env58621 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58621 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,1212,262144,1025,8461,4096,397,5293,5222,8328,5372,341223,4176,1260,75786,78186,78998,256,74199,1213,513]

theorem envBound58622 : H12AffineFastState.Bounded env58622 := by
  intro p hp
  have h : env58622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58621_58622 : H12AffineEnvironment.transform 16 1212 env58621 = env58622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env58621 == env58622) = true)

theorem identity58622 : scanCanonicalize (H12AffineFastState.compose env58622 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 75787) := by decide +kernel

theorem selectedBound58622 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,1212,75787,1025,8461,4096,397,5293,5222,8328,5372,7404,4176,1260,75786,78186,78998,256,74199,1213,513]

theorem envBound58623 : H12AffineFastState.Bounded env58623 := by
  intro p hp
  have h : env58623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58622_58623 : H12AffineEnvironment.transform 17 75787 env58622 = env58623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75787 env58622 == env58623) = true)

theorem identity58623 : scanCanonicalize (H12AffineFastState.compose env58623 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58623 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58624 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8353,65536,1212,75787,1025,8353,4096,33,5293,5222,8328,5372,7404,4176,1260,75786,78022,78998,172,73851,1213,513]

theorem envBound58624 : H12AffineFastState.Bounded env58624 := by
  intro p hp
  have h : env58624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58623_58624 : H12AffineEnvironment.transform 7 172 env58623 = env58624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58623 == env58624) = true)

theorem identity58624 : scanCanonicalize (H12AffineFastState.compose env58624 (packedSelected [0,5,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1711) := by decide +kernel

theorem selectedBound58624 : packedSelected [0,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env58625 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8353,1711,1212,11940,1025,8353,4096,33,5293,5222,8328,5372,7404,4176,1260,11941,13929,12857,172,9940,1213,513]

theorem envBound58625 : H12AffineFastState.Bounded env58625 := by
  intro p hp
  have h : env58625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58624_58625 : H12AffineEnvironment.transform 15 1711 env58624 = env58625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1711 env58624 == env58625) = true)

theorem identity58625 : scanCanonicalize (H12AffineFastState.compose env58625 (packedSelected [0,3,6,7,8,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound58625 : packedSelected [0,3,6,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env58626 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1703,4096,8192,4176,8353,1711,1212,8195,1025,8353,4096,33,5293,5222,8328,5372,4683,4176,1260,8194,13929,12857,172,9940,1213,513]

theorem envBound58626 : H12AffineFastState.Bounded env58626 := by
  intro p hp
  have h : env58626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58625_58626 : H12AffineEnvironment.transform 10 1703 env58625 = env58626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env58625 == env58626) = true)

theorem identity58626 : scanCanonicalize (H12AffineFastState.compose env58626 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound58626 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env58627 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1703,1260,8192,1212,8353,1711,1212,8195,1025,8353,1260,33,65,138,8328,16,1703,1212,1260,8194,8837,9941,172,9940,1213,513]

theorem envBound58627 : H12AffineFastState.Bounded env58627 := by
  intro p hp
  have h : env58627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58626_58627 : H12AffineEnvironment.transform 11 1260 env58626 = env58627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env58626 == env58627) = true)

theorem identity58627 : scanCanonicalize (H12AffineFastState.compose env58627 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58627 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58628 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,1212,8192,1212,8353,1711,1212,8195,1025,8353,1212,33,17,138,8328,16,1703,1212,1212,8194,8837,9861,172,9860,1213,513]

theorem envBound58628 : H12AffineFastState.Bounded env58628 := by
  intro p hp
  have h : env58628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58627_58628 : H12AffineEnvironment.transform 5 16 env58627 = env58628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58627 == env58628) = true)

theorem identity58628 : scanCanonicalize (H12AffineFastState.compose env58628 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58628 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58629 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,1212,8,1212,169,1711,1212,11,1025,169,1212,33,17,138,128,16,1703,1212,1212,10,653,1677,172,1676,1213,513]

theorem envBound58629 : H12AffineFastState.Bounded env58629 := by
  intro p hp
  have h : env58629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58628_58629 : H12AffineEnvironment.transform 12 8 env58628 = env58629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58628 == env58629) = true)

theorem identity58629 : scanCanonicalize (H12AffineFastState.compose env58629 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound58629 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58630 : List Nat := [2,4,8,16,32,16,128,172,512,574,153,642,8,642,169,145,642,11,575,169,642,33,17,138,128,16,153,642,642,10,653,179,172,178,643,513]

theorem envBound58630 : H12AffineFastState.Bounded env58630 := by
  intro p hp
  have h : env58630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58629_58630 : H12AffineEnvironment.transform 9 574 env58629 = env58630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env58629 == env58630) = true)

theorem identity58630 : scanCanonicalize (H12AffineFastState.compose env58630 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58630 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58631 : List Nat := [2,4,8,16,32,16,128,172,26,36,153,152,8,152,169,145,152,11,37,169,152,33,17,138,128,16,153,152,152,10,151,179,172,178,153,27]

theorem envBound58631 : H12AffineFastState.Bounded env58631 := by
  intro p hp
  have h : env58631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58630_58631 : H12AffineEnvironment.transform 8 26 env58630 = env58631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58630 == env58631) = true)

def env58632 : List Nat := [2,4,8,16,32,16,56,20,26,36,33,32,8,32,17,41,32,11,37,17,32,33,17,50,56,16,33,32,32,10,47,11,20,10,33,27]

theorem envBound58632 : H12AffineFastState.Bounded env58632 := by
  intro p hp
  have h : env58632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58632 : H12AffineEnvironment.transform 6 56 env58631 = env58632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env58631 == env58632) = true)

theorem identity58632 : scanCanonicalize (H12AffineFastState.compose env58632 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58633 : List Nat := [2,4,8,10,32,10,34,14,0,36,33,32,8,32,11,41,32,11,37,11,32,33,11,40,34,10,33,32,32,10,47,11,14,10,33,1]

theorem envBound58633 : H12AffineFastState.Bounded env58633 := by
  intro p hp
  have h : env58633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58632_58633 : H12AffineEnvironment.transform 3 10 env58632 = env58633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58632 == env58633) = true)

theorem identity58633 : scanCanonicalize (H12AffineFastState.compose env58633 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound58633 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58634 : List Nat := [2,4,8,10,9,10,11,14,0,13,8,9,8,9,11,0,9,11,12,11,9,8,11,1,11,10,8,9,9,10,6,11,14,10,8,1]

theorem envBound58634 : H12AffineFastState.Bounded env58634 := by
  intro p hp
  have h : env58634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58633_58634 : H12AffineEnvironment.transform 4 9 env58633 = env58634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env58633 == env58634) = true)

def leafEnv58634 : List Nat := [2,4,8,10,9,10,11,14,0,13,8,9,8,9,11,0,9,11,12,11,9,8,11,1,6,11,1,10,8,9,9,10,6,11,14,10,5,3,8,1,1,9,0]

def active58634 : List Nat := [0,1,2]

def tree58634 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58634 : H12WitnessSearch.Good tree58634 := H12GlobalWitnessIndex.good

theorem leafIdentity58634 : H12AffineFastState.composeSystem env58634 rootObs = leafEnv58634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58634 rootObs == leafEnv58634) = true)

theorem terminalChecked58634 : H12PackedTerminal.terminalCheckFast leafEnv58634 active58634 tree58634 = true := by decide +kernel

def env58635 : List Nat := [2,4,8,16,32,16,57,21,26,36,32,33,8,33,16,40,33,11,37,16,33,33,17,51,57,16,32,33,33,10,46,10,21,11,32,27]

theorem envBound58635 : H12AffineFastState.Bounded env58635 := by
  intro p hp
  have h : env58635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58635 : H12AffineEnvironment.transform 6 57 env58631 = env58635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58631 == env58635) = true)

def env58636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,67108864,134217728,16385,76174416,80317659,8463814,4294967296,525569,4366311740,34359738368,33563273]

theorem envBound58636 : H12AffineFastState.Bounded env58636 := by
  intro p hp
  have h : env58636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56658_58636 : H12AffineEnvironment.transform 27 16385 env56658 = env58636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env56658 == env58636) = true)

def env58637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,8409088,134217728,16385,656464,4840667,8463814,4294967296,525569,4307611964,34359738368,33563273]

theorem envBound58637 : H12AffineFastState.Bounded env58637 := by
  intro p hp
  have h : env58637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58636_58637 : H12AffineEnvironment.transform 25 8409088 env58636 = env58637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409088 env58636 == env58637) = true)

def env58638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131152,4315355,8463814,4294967296,257,4307611964,34359738368,33563273]

theorem envBound58638 : H12AffineFastState.Bounded env58638 := by
  intro p hp
  have h : env58638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58637_58638 : H12AffineEnvironment.transform 18 1024 env58637 = env58638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env58637 == env58638) = true)

def env58639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131152,4315355,8463814,4294967296,257,4307611964,131072,33563273]

theorem envBound58639 : H12AffineFastState.Bounded env58639 := by
  intro p hp
  have h : env58639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58638_58639 : H12AffineEnvironment.transform 34 131072 env58638 = env58639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58638 == env58639) = true)

theorem identity58639 : scanCanonicalize (H12AffineFastState.compose env58639 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 149382611) := by decide +kernel

theorem selectedBound58639 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131152,4315355,8463814,149382611,257,136811759,131072,33563273]

theorem envBound58640 : H12AffineFastState.Bounded env58640 := by
  intro p hp
  have h : env58640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58639_58640 : H12AffineEnvironment.transform 31 149382611 env58639 = env58640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 149382611 env58639 == env58640) = true)

theorem identity58640 : scanCanonicalize (H12AffineFastState.compose env58640 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58640 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4176,131152,4294794,8463814,149370242,257,136811759,131072,33563273]

theorem envBound58641 : H12AffineFastState.Bounded env58641 := by
  intro p hp
  have h : env58641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58640_58641 : H12AffineEnvironment.transform 13 4177 env58640 = env58641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58640 == env58641) = true)

theorem identity58641 : scanCanonicalize (H12AffineFastState.compose env58641 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58641 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,134217728,4176,131152,4294794,8463814,149370242,257,136811759,131072,513]

theorem envBound58642 : H12AffineFastState.Bounded env58642 := by
  intro p hp
  have h : env58642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58641_58642 : H12AffineEnvironment.transform 24 8328 env58641 = env58642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58641 == env58642) = true)

theorem identity58642 : scanCanonicalize (H12AffineFastState.compose env58642 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724555) := by decide +kernel

theorem selectedBound58642 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,8724555,4176,131152,4294794,8463814,6428105,257,10663076,131072,513]

theorem envBound58643 : H12AffineFastState.Bounded env58643 := by
  intro p hp
  have h : env58643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58642_58643 : H12AffineEnvironment.transform 26 8724555 env58642 = env58643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724555 env58642 == env58643) = true)

theorem identity58643 : scanCanonicalize (H12AffineFastState.compose env58643 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58643 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,8388608,8430023,8328,8388689,8724555,4176,131152,4294794,8463814,4326856,257,8561829,131072,513]

theorem envBound58644 : H12AffineFastState.Bounded env58644 := by
  intro p hp
  have h : env58644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58643_58644 : H12AffineEnvironment.transform 20 4097 env58643 = env58644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58643 == env58644) = true)

theorem identity58644 : scanCanonicalize (H12AffineFastState.compose env58644 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370576) := by decide +kernel

theorem selectedBound58644 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,4370576,4329815,8328,4370625,4690139,4176,131152,4294794,4429142,4326856,257,4199477,131072,513]

theorem envBound58645 : H12AffineFastState.Bounded env58645 := by
  intro p hp
  have h : env58645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58644_58645 : H12AffineEnvironment.transform 22 4370576 env58644 = env58645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370576 env58644 == env58645) = true)

theorem identity58645 : scanCanonicalize (H12AffineFastState.compose env58645 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58645 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,176413,135386,8328,176460,495958,4176,131152,100615,234715,132165,257,5560,131072,513]

theorem envBound58646 : H12AffineFastState.Bounded env58646 := by
  intro p hp
  have h : env58646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58645_58646 : H12AffineEnvironment.transform 21 397 env58645 = env58646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58645 == env58646) = true)

theorem identity58646 : scanCanonicalize (H12AffineFastState.compose env58646 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58646 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,131072,262144,1024,8460,4097,397,135185,135386,8328,135232,471130,4176,131152,75787,210391,132165,257,5560,131072,513]

theorem envBound58647 : H12AffineFastState.Bounded env58647 := by
  intro p hp
  have h : env58647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58646_58647 : H12AffineEnvironment.transform 14 8460 env58646 = env58647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58646 == env58647) = true)

theorem identity58647 : scanCanonicalize (H12AffineFastState.compose env58647 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13422) := by decide +kernel

theorem selectedBound58647 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13422,131072,262144,1024,8460,4097,397,135185,135386,8328,135232,394292,4176,131152,7269,131513,132165,257,5560,131072,513]

theorem envBound58648 : H12AffineFastState.Bounded env58648 := by
  intro p hp
  have h : env58648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58647_58648 : H12AffineEnvironment.transform 15 13422 env58647 = env58648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13422 env58647 == env58648) = true)

theorem identity58648 : scanCanonicalize (H12AffineFastState.compose env58648 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 7268) := by decide +kernel

theorem selectedBound58648 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13422,131072,7268,1024,8460,4097,397,135185,135386,8328,135232,137296,4176,131152,7269,131513,132165,257,5560,131072,513]

theorem envBound58649 : H12AffineFastState.Bounded env58649 := by
  intro p hp
  have h : env58649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58648_58649 : H12AffineEnvironment.transform 17 7268 env58648 = env58649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7268 env58648 == env58649) = true)

theorem identity58649 : scanCanonicalize (H12AffineFastState.compose env58649 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58649 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58650 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8352,13422,131072,7268,1024,8352,4097,33,135185,135386,8328,135232,137296,4176,131152,7269,131093,132165,173,5140,131072,513]

theorem envBound58650 : H12AffineFastState.Bounded env58650 := by
  intro p hp
  have h : env58650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58649_58650 : H12AffineEnvironment.transform 7 172 env58649 = env58650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58649 == env58650) = true)

theorem identity58650 : scanCanonicalize (H12AffineFastState.compose env58650 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound58650 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58651 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8352,13422,4176,7268,1024,8352,4097,33,65,138,8328,16,2048,4176,4096,7269,4165,5141,173,5140,4176,513]

theorem envBound58651 : H12AffineFastState.Bounded env58651 := by
  intro p hp
  have h : env58651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58650_58651 : H12AffineEnvironment.transform 16 4176 env58650 = env58651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env58650 == env58651) = true)

theorem identity58651 : scanCanonicalize (H12AffineFastState.compose env58651 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58651 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58652 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8352,13374,4096,7220,1024,8352,4097,33,17,138,8328,16,2048,4096,4096,7221,4117,5141,173,5140,4096,513]

theorem envBound58652 : H12AffineFastState.Bounded env58652 := by
  intro p hp
  have h : env58652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58651_58652 : H12AffineEnvironment.transform 5 16 env58651 = env58652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58651 == env58652) = true)

theorem identity58652 : scanCanonicalize (H12AffineFastState.compose env58652 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58652 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58653 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8,4097,168,5174,4096,7220,1024,168,4097,33,17,138,128,16,2048,4096,4096,7221,4117,5141,173,5140,4096,513]

theorem envBound58653 : H12AffineFastState.Bounded env58653 := by
  intro p hp
  have h : env58653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58652_58653 : H12AffineEnvironment.transform 12 8 env58652 = env58653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58652 == env58653) = true)

theorem identity58653 : scanCanonicalize (H12AffineFastState.compose env58653 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound58653 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58654 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,665,8,664,168,1711,665,3757,1024,168,664,33,17,138,128,16,2048,665,665,3756,652,1676,173,1677,665,513]

theorem envBound58654 : H12AffineFastState.Bounded env58654 := by
  intro p hp
  have h : env58654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58653_58654 : H12AffineEnvironment.transform 11 665 env58653 = env58654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env58653 == env58654) = true)

theorem identity58654 : scanCanonicalize (H12AffineFastState.compose env58654 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58654 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58655 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1213,665,8,664,168,1711,665,528,1024,168,664,33,17,138,128,16,1213,665,665,529,652,1676,173,1677,665,513]

theorem envBound58655 : H12AffineFastState.Bounded env58655 := by
  intro p hp
  have h : env58655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58654_58655 : H12AffineEnvironment.transform 10 1213 env58654 = env58655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env58654 == env58655) = true)

theorem identity58655 : scanCanonicalize (H12AffineFastState.compose env58655 (packedSelected [1,2,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58655 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env58656 : List Nat := [2,4,8,16,32,16,128,172,512,548,665,665,8,664,168,139,665,528,548,168,664,33,17,138,128,16,665,665,665,529,652,168,173,169,665,513]

theorem envBound58656 : H12AffineFastState.Bounded env58656 := by
  intro p hp
  have h : env58656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58655_58656 : H12AffineEnvironment.transform 9 548 env58655 = env58656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58655 == env58656) = true)

theorem identity58656 : scanCanonicalize (H12AffineFastState.compose env58656 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58656 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58657 : List Nat := [2,4,8,10,32,10,128,172,512,548,643,643,8,642,168,139,643,522,548,168,642,33,11,138,128,10,643,643,643,523,652,168,173,169,643,513]

theorem envBound58657 : H12AffineFastState.Bounded env58657 := by
  intro p hp
  have h : env58657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58656_58657 : H12AffineEnvironment.transform 3 10 env58656 = env58657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58656 == env58657) = true)

theorem identity58657 : scanCanonicalize (H12AffineFastState.compose env58657 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound58657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58658 : List Nat := [2,4,8,10,32,10,128,172,163,135,32,32,8,33,168,139,32,169,135,168,33,33,11,138,128,10,32,32,32,168,47,168,173,169,32,162]

theorem envBound58658 : H12AffineFastState.Bounded env58658 := by
  intro p hp
  have h : env58658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58657_58658 : H12AffineEnvironment.transform 8 163 env58657 = env58658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env58657 == env58658) = true)

theorem identity58658 : scanCanonicalize (H12AffineFastState.compose env58658 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound58658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58659 : List Nat := [2,4,8,10,32,10,11,39,40,12,32,32,8,33,35,0,32,34,12,35,33,33,11,1,11,10,32,32,32,35,47,35,38,34,32,41]

theorem envBound58659 : H12AffineFastState.Bounded env58659 := by
  intro p hp
  have h : env58659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58658_58659 : H12AffineEnvironment.transform 6 11 env58658 = env58659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env58658 == env58659) = true)

theorem identity58659 : scanCanonicalize (H12AffineFastState.compose env58659 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound58659 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env58660 : List Nat := [2,4,8,10,8,10,11,15,0,12,8,8,8,9,11,0,8,10,12,11,9,9,11,1,11,10,8,8,8,11,7,11,14,10,8,1]

theorem envBound58660 : H12AffineFastState.Bounded env58660 := by
  intro p hp
  have h : env58660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58659_58660 : H12AffineEnvironment.transform 4 8 env58659 = env58660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env58659 == env58660) = true)

def leafEnv58660 : List Nat := [2,4,8,10,8,10,11,15,0,12,8,8,8,9,11,0,8,10,12,11,9,9,11,1,6,11,1,10,8,8,8,11,7,11,14,10,4,3,8,1,1,9,0]

def active58660 : List Nat := [0,1,2]

def tree58660 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58660 : H12WitnessSearch.Good tree58660 := H12GlobalWitnessIndex.good

theorem leafIdentity58660 : H12AffineFastState.composeSystem env58660 rootObs = leafEnv58660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58660 rootObs == leafEnv58660) = true)

theorem terminalChecked58660 : H12PackedTerminal.terminalCheckFast leafEnv58660 active58660 tree58660 = true := by decide +kernel

def env58661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131152,4315355,8463814,4294967296,257,4307611964,131073,33563273]

theorem envBound58661 : H12AffineFastState.Bounded env58661 := by
  intro p hp
  have h : env58661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58638_58661 : H12AffineEnvironment.transform 34 131073 env58638 = env58661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58638 == env58661) = true)

theorem identity58661 : scanCanonicalize (H12AffineFastState.compose env58661 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 147289554) := by decide +kernel

theorem selectedBound58661 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131152,4315355,8463814,147289554,257,134710510,131073,33563273]

theorem envBound58662 : H12AffineFastState.Bounded env58662 := by
  intro p hp
  have h : env58662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58661_58662 : H12AffineEnvironment.transform 31 147289554 env58661 = env58662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147289554 env58661 == env58662) = true)

theorem identity58662 : scanCanonicalize (H12AffineFastState.compose env58662 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58662 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,12919238,16385,131152,4315355,8463814,152596,257,12756264,131073,33563273]

theorem envBound58663 : H12AffineFastState.Bounded env58663 := by
  intro p hp
  have h : env58663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58662_58663 : H12AffineEnvironment.transform 26 12919238 env58662 = env58663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58662 == env58663) = true)

theorem identity58663 : scanCanonicalize (H12AffineFastState.compose env58663 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound58663 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env58664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,28889,8409088,12919238,16385,131152,4315355,8463814,152596,257,12756264,131073,21072]

theorem envBound58664 : H12AffineFastState.Bounded env58664 := by
  intro p hp
  have h : env58664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58663_58664 : H12AffineEnvironment.transform 24 28889 env58663 = env58664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env58663 == env58664) = true)

def env58665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8329,8388688,12919238,4177,131152,4294795,8463814,132164,257,12756264,131073,512]

theorem envBound58665 : H12AffineFastState.Bounded env58665 := by
  intro p hp
  have h : env58665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58664_58665 : H12AffineEnvironment.transform 13 4176 env58664 = env58665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58664 == env58665) = true)

theorem identity58665 : scanCanonicalize (H12AffineFastState.compose env58665 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58665 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,8329,8388688,12919238,4177,77955,4294795,8463814,78999,257,12686843,78034,512]

theorem envBound58666 : H12AffineFastState.Bounded env58666 := by
  intro p hp
  have h : env58666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58665_58666 : H12AffineEnvironment.transform 16 78035 env58665 = env58666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58665 == env58666) = true)

theorem identity58666 : scanCanonicalize (H12AffineFastState.compose env58666 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 4240768) := by decide +kernel

theorem selectedBound58666 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,4240768,4199495,8329,4240848,365638,4177,77955,4294795,4296774,78999,257,73851,78034,512]

theorem envBound58667 : H12AffineFastState.Bounded env58667 := by
  intro p hp
  have h : env58667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58666_58667 : H12AffineEnvironment.transform 22 4240768 env58666 = env58667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240768 env58666 == env58667) = true)

theorem identity58667 : scanCanonicalize (H12AffineFastState.compose env58667 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound58667 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env58668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,33,46497,5222,8329,46577,365638,4177,77955,100522,102503,78999,257,73851,78034,512]

theorem envBound58668 : H12AffineFastState.Bounded env58668 := by
  intro p hp
  have h : env58668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58667_58668 : H12AffineEnvironment.transform 21 33 env58667 = env58668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env58667 == env58668) = true)

def env58669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,262144,1024,32768,2097152,33,41293,138,8329,41245,360618,1213,74863,100522,99467,73851,257,73851,74814,512]

theorem envBound58669 : H12AffineFastState.Bounded env58669 := by
  intro p hp
  have h : env58669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58668_58669 : H12AffineEnvironment.transform 11 1260 env58668 = env58669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env58668 == env58669) = true)

theorem identity58669 : scanCanonicalize (H12AffineFastState.compose env58669 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 75546) := by decide +kernel

theorem selectedBound58669 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,262144,1024,32768,75546,33,41293,138,8329,41245,360618,1213,74863,100522,99467,73851,257,73851,74814,512]

theorem envBound58670 : H12AffineFastState.Bounded env58670 := by
  intro p hp
  have h : env58670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58669_58670 : H12AffineEnvironment.transform 20 75546 env58669 = env58670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75546 env58669 == env58670) = true)

theorem identity58670 : scanCanonicalize (H12AffineFastState.compose env58670 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound58670 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env58671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,100523,1024,32768,75546,33,41293,138,8329,41245,2049,1213,74863,100522,99467,73851,257,73851,74814,512]

theorem envBound58671 : H12AffineFastState.Bounded env58671 := by
  intro p hp
  have h : env58671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58670_58671 : H12AffineEnvironment.transform 17 100523 env58670 = env58671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env58670 == env58671) = true)

theorem identity58671 : scanCanonicalize (H12AffineFastState.compose env58671 (packedSelected [0,1,3,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound58671 : packedSelected [0,1,3,7,12,15] rootPS < 2^1333 := by decide +kernel

def env58672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,0,65536,74815,67755,1024,0,75546,33,8525,138,8329,8477,2049,1213,74863,67754,66699,73851,257,73851,74814,512]

theorem envBound58672 : H12AffineFastState.Bounded env58672 := by
  intro p hp
  have h : env58672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58671_58672 : H12AffineEnvironment.transform 14 0 env58671 = env58672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env58671 == env58672) = true)

def env58673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,262144,1024,32768,2097152,33,41292,139,8329,41244,360619,1212,74862,100522,99466,73850,257,73851,74815,512]

theorem envBound58673 : H12AffineFastState.Bounded env58673 := by
  intro p hp
  have h : env58673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58668_58673 : H12AffineEnvironment.transform 11 1261 env58668 = env58673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env58668 == env58673) = true)

theorem identity58673 : scanCanonicalize (H12AffineFastState.compose env58673 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 265916) := by decide +kernel

theorem selectedBound58673 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,262144,1024,32768,265916,33,41292,139,8329,41244,360619,1212,74862,100522,99466,73850,257,73851,74815,512]

theorem envBound58674 : H12AffineFastState.Bounded env58674 := by
  intro p hp
  have h : env58674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58673_58674 : H12AffineEnvironment.transform 20 265916 env58673 = env58674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 265916 env58673 == env58674) = true)

theorem identity58674 : scanCanonicalize (H12AffineFastState.compose env58674 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound58674 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,43049,1024,32768,42645,33,41292,139,8329,41244,75906,1212,74862,100522,99466,73850,257,73851,74815,512]

theorem envBound58675 : H12AffineFastState.Bounded env58675 := by
  intro p hp
  have h : env58675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58674_58675 : H12AffineEnvironment.transform 17 43049 env58674 = env58675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env58674 == env58675) = true)

theorem identity58675 : scanCanonicalize (H12AffineFastState.compose env58675 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound58675 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env58676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,33167,42417,43049,1024,32768,42645,33,41292,139,8329,41244,43277,1212,42465,2341,1285,41461,257,41460,42416,512]

theorem envBound58676 : H12AffineFastState.Bounded env58676 := by
  intro p hp
  have h : env58676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58675_58676 : H12AffineEnvironment.transform 15 33167 env58675 = env58676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env58675 == env58676) = true)

def env58677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,8312,8695,1481,2129,1024,8312,1773,33,308,139,8329,356,2421,1212,1433,2341,1285,397,257,396,1480,512]

theorem envBound58677 : H12AffineFastState.Bounded env58677 := by
  intro p hp
  have h : env58677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58676_58677 : H12AffineEnvironment.transform 14 8312 env58676 = env58677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env58676 == env58677) = true)

theorem identity58677 : scanCanonicalize (H12AffineFastState.compose env58677 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2517) := by decide +kernel

theorem selectedBound58677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2517,1213,2477,2082,1481,2129,1024,2477,1773,33,308,139,2396,356,2421,1212,1433,2341,1285,397,257,396,1480,512]

theorem envBound58678 : H12AffineFastState.Bounded env58678 := by
  intro p hp
  have h : env58678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58677_58678 : H12AffineEnvironment.transform 12 2517 env58677 = env58678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2517 env58677 == env58678) = true)

def env58679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,8313,8694,1480,2128,1024,8313,1772,33,309,139,8329,357,2420,1212,1432,2341,1285,396,257,397,1481,512]

theorem envBound58679 : H12AffineFastState.Bounded env58679 := by
  intro p hp
  have h : env58679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58676_58679 : H12AffineEnvironment.transform 14 8313 env58676 = env58679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env58676 == env58679) = true)

theorem identity58679 : scanCanonicalize (H12AffineFastState.compose env58679 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound58679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2209,1213,2264,2391,1480,2128,1024,2264,1772,33,309,139,2088,357,2420,1212,1432,2341,1285,396,257,397,1481,512]

theorem envBound58680 : H12AffineFastState.Bounded env58680 := by
  intro p hp
  have h : env58680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58679_58680 : H12AffineEnvironment.transform 12 2209 env58679 = env58680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env58679 == env58680) = true)

def env58681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,12919238,4176,131152,4294794,8463814,132165,257,12756264,131073,513]

theorem envBound58681 : H12AffineFastState.Bounded env58681 := by
  intro p hp
  have h : env58681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58664_58681 : H12AffineEnvironment.transform 13 4177 env58664 = env58681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58664 == env58681) = true)

theorem identity58681 : scanCanonicalize (H12AffineFastState.compose env58681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,397,8388608,8430023,8328,8388689,8724555,4176,131152,100615,8463814,132165,257,8561829,131073,513]

theorem envBound58682 : H12AffineFastState.Bounded env58682 := by
  intro p hp
  have h : env58682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58681_58682 : H12AffineEnvironment.transform 21 397 env58681 = env58682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58681 == env58682) = true)

theorem identity58682 : scanCanonicalize (H12AffineFastState.compose env58682 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58682 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,8388608,8430023,8328,8388689,8724555,4176,131152,100615,8463814,132165,257,8561829,131073,513]

theorem envBound58683 : H12AffineFastState.Bounded env58683 := by
  intro p hp
  have h : env58683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58682_58683 : H12AffineEnvironment.transform 20 4097 env58682 = env58683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58682 == env58683) = true)

theorem identity58683 : scanCanonicalize (H12AffineFastState.compose env58683 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176413) := by decide +kernel

theorem selectedBound58683 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,176413,135386,8328,176460,495958,4176,131152,100615,234715,132165,257,5560,131073,513]

theorem envBound58684 : H12AffineFastState.Bounded env58684 := by
  intro p hp
  have h : env58684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58683_58684 : H12AffineEnvironment.transform 22 176413 env58683 = env58684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176413 env58683 == env58684) = true)

theorem identity58684 : scanCanonicalize (H12AffineFastState.compose env58684 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58684 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,131072,262144,1024,8461,4097,397,135184,135386,8328,135233,471131,4176,131152,75786,210390,132165,257,5560,131073,513]

theorem envBound58685 : H12AffineFastState.Bounded env58685 := by
  intro p hp
  have h : env58685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58684_58685 : H12AffineEnvironment.transform 14 8461 env58684 = env58685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58684 == env58685) = true)

theorem identity58685 : scanCanonicalize (H12AffineFastState.compose env58685 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13423) := by decide +kernel

theorem selectedBound58685 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13423,131072,262144,1024,8461,4097,397,135184,135386,8328,135233,394292,4176,131152,7269,131513,132165,257,5560,131073,513]

theorem envBound58686 : H12AffineFastState.Bounded env58686 := by
  intro p hp
  have h : env58686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58685_58686 : H12AffineEnvironment.transform 15 13423 env58685 = env58686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13423 env58685 == env58686) = true)

theorem identity58686 : scanCanonicalize (H12AffineFastState.compose env58686 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 134197) := by decide +kernel

theorem selectedBound58686 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13423,131072,134197,1024,8461,4097,397,135184,135386,8328,135233,2049,4176,131152,7269,131513,132165,257,5560,131073,513]

theorem envBound58687 : H12AffineFastState.Bounded env58687 := by
  intro p hp
  have h : env58687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58686_58687 : H12AffineEnvironment.transform 17 134197 env58686 = env58687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 134197 env58686 == env58687) = true)

theorem identity58687 : scanCanonicalize (H12AffineFastState.compose env58687 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58687 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58688 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8353,13423,131072,134197,1024,8353,4097,33,135184,135386,8328,135233,2049,4176,131152,7269,131093,132165,173,5140,131073,513]

theorem envBound58688 : H12AffineFastState.Bounded env58688 := by
  intro p hp
  have h : env58688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58687_58688 : H12AffineEnvironment.transform 7 172 env58687 = env58688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58687 == env58688) = true)

theorem identity58688 : scanCanonicalize (H12AffineFastState.compose env58688 (packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2267) := by decide +kernel

theorem selectedBound58688 : packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58689 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,2267,4177,2170,7348,131072,134197,1024,2170,4097,33,135184,135386,2131,135233,2049,4176,131152,7269,131093,132165,173,5140,131073,513]

theorem envBound58689 : H12AffineFastState.Bounded env58689 := by
  intro p hp
  have h : env58689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58688_58689 : H12AffineEnvironment.transform 12 2267 env58688 = env58689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2267 env58688 == env58689) = true)

theorem identity58689 : scanCanonicalize (H12AffineFastState.compose env58689 (packedSelected [0,2,3,7,8,10,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58689 : packedSelected [0,2,3,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env58690 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,2267,4177,2170,7348,4096,7221,1024,2170,4097,33,16,218,2131,65,2049,4176,4176,7269,4117,5189,173,5140,4097,513]

theorem envBound58690 : H12AffineFastState.Bounded env58690 := by
  intro p hp
  have h : env58690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58689_58690 : H12AffineEnvironment.transform 16 4096 env58689 = env58690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env58689 == env58690) = true)

theorem identity58690 : scanCanonicalize (H12AffineFastState.compose env58690 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound58690 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58691 : List Nat := [2,4,8,16,32,64,128,172,512,1024,211,4096,8,4177,169,5223,4096,5350,1024,169,4097,33,16,218,128,65,210,4176,4176,5302,4117,5189,173,5140,4097,513]

theorem envBound58691 : H12AffineFastState.Bounded env58691 := by
  intro p hp
  have h : env58691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58690_58691 : H12AffineEnvironment.transform 10 211 env58690 = env58691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env58690 == env58691) = true)

theorem identity58691 : scanCanonicalize (H12AffineFastState.compose env58691 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound58691 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env58692 : List Nat := [2,4,8,16,32,64,128,172,512,1024,211,1071,8,1150,169,72,1071,201,1024,169,1070,33,16,218,128,65,210,1151,1151,153,1082,106,173,59,1070,513]

theorem envBound58692 : H12AffineFastState.Bounded env58692 := by
  intro p hp
  have h : env58692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58691_58692 : H12AffineEnvironment.transform 11 1071 env58691 = env58692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env58691 == env58692) = true)

theorem identity58692 : scanCanonicalize (H12AffineFastState.compose env58692 (packedSelected [4,5,7,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58692 : packedSelected [4,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58693 : List Nat := [2,4,8,16,32,16,128,172,512,1024,131,1071,8,1070,169,24,1071,153,1024,169,1070,33,16,138,128,17,130,1071,1071,153,1082,58,173,59,1070,513]

theorem envBound58693 : H12AffineFastState.Bounded env58693 := by
  intro p hp
  have h : env58693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58692_58693 : H12AffineEnvironment.transform 5 16 env58692 = env58693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58692 == env58693) = true)

theorem identity58693 : scanCanonicalize (H12AffineFastState.compose env58693 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 182) := by decide +kernel

theorem selectedBound58693 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58694 : List Nat := [2,4,8,16,32,16,128,172,512,182,131,153,8,152,169,24,153,153,182,169,152,33,16,138,128,17,130,153,153,153,140,58,173,59,152,513]

theorem envBound58694 : H12AffineFastState.Bounded env58694 := by
  intro p hp
  have h : env58694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58693_58694 : H12AffineEnvironment.transform 9 182 env58693 = env58694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 182 env58693 == env58694) = true)

theorem identity58694 : scanCanonicalize (H12AffineFastState.compose env58694 (packedSelected [1,2,10] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound58694 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env58695 : List Nat := [2,4,8,16,32,16,128,172,147,182,131,153,8,152,169,24,153,153,182,169,152,33,16,138,128,17,130,153,153,153,140,58,173,59,152,146]

theorem envBound58695 : H12AffineFastState.Bounded env58695 := by
  intro p hp
  have h : env58695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58694_58695 : H12AffineEnvironment.transform 8 147 env58694 = env58695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env58694 == env58695) = true)

def env58696 : List Nat := [2,4,8,16,16,16,128,156,147,134,131,153,8,152,153,24,153,153,134,153,152,17,16,138,128,17,130,153,153,153,140,10,157,11,152,146]

theorem envBound58696 : H12AffineFastState.Bounded env58696 := by
  intro p hp
  have h : env58696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58695_58696 : H12AffineEnvironment.transform 4 16 env58695 = env58696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58695 == env58696) = true)

theorem identity58696 : scanCanonicalize (H12AffineFastState.compose env58696 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58696 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58697 : List Nat := [2,4,8,16,16,16,19,15,0,21,16,10,8,11,10,24,10,10,21,10,11,17,16,25,19,17,17,10,10,10,31,10,14,11,11,1]

theorem envBound58697 : H12AffineFastState.Bounded env58697 := by
  intro p hp
  have h : env58697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58696_58697 : H12AffineEnvironment.transform 6 19 env58696 = env58697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58696 == env58697) = true)

theorem identity58697 : scanCanonicalize (H12AffineFastState.compose env58697 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound58697 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58698 : List Nat := [2,4,8,9,9,9,10,15,0,12,9,10,8,11,10,1,10,10,12,10,11,8,9,0,10,8,8,10,10,10,6,10,14,11,11,1]

theorem envBound58698 : H12AffineFastState.Bounded env58698 := by
  intro p hp
  have h : env58698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58697_58698 : H12AffineEnvironment.transform 3 9 env58697 = env58698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env58697 == env58698) = true)

theorem identity58698 : scanCanonicalize (H12AffineFastState.compose env58698 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58699 : List Nat := [0,4,8,9,9,9,8,13,0,12,9,8,8,9,8,1,8,8,12,8,9,8,9,0,8,8,8,8,8,8,4,8,12,9,9,1]

theorem envBound58699 : H12AffineFastState.Bounded env58699 := by
  intro p hp
  have h : env58699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58698_58699 : H12AffineEnvironment.transform 0 0 env58698 = env58699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58698 == env58699) = true)

def leafEnv58699 : List Nat := [0,4,8,9,9,9,8,13,0,12,9,8,8,9,8,1,8,8,12,8,9,8,9,0,5,8,1,8,8,8,8,8,4,8,12,9,4,1,9,1,1,8,0]

def active58699 : List Nat := [1,2]

def tree58699 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58699 : H12WitnessSearch.Good tree58699 := H12GlobalWitnessIndex.good

theorem leafIdentity58699 : H12AffineFastState.composeSystem env58699 rootObs = leafEnv58699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58699 rootObs == leafEnv58699) = true)

theorem terminalChecked58699 : H12PackedTerminal.terminalCheckFast leafEnv58699 active58699 tree58699 = true := by decide +kernel

def env58700 : List Nat := [2,4,8,16,17,16,128,157,147,135,131,153,8,152,152,24,153,153,135,152,152,16,16,138,128,17,130,153,153,153,140,11,156,10,152,146]

theorem envBound58700 : H12AffineFastState.Bounded env58700 := by
  intro p hp
  have h : env58700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58695_58700 : H12AffineEnvironment.transform 4 17 env58695 = env58700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58695 == env58700) = true)

def env58701 : List Nat := [2,4,8,0,1,0,128,141,131,135,131,137,8,136,136,8,137,137,135,136,136,0,0,138,128,1,130,137,137,137,140,11,140,10,136,130]

theorem envBound58701 : H12AffineFastState.Bounded env58701 := by
  intro p hp
  have h : env58701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58700_58701 : H12AffineEnvironment.transform 3 0 env58700 = env58701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58700 == env58701) = true)

theorem identity58701 : scanCanonicalize (H12AffineFastState.compose env58701 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound58701 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58702 : List Nat := [2,4,8,0,1,0,0,13,3,7,3,9,8,8,8,8,9,9,7,8,8,0,0,10,0,1,2,9,9,9,12,11,12,10,8,2]

theorem envBound58702 : H12AffineFastState.Bounded env58702 := by
  intro p hp
  have h : env58702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58701_58702 : H12AffineEnvironment.transform 6 0 env58701 = env58702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env58701 == env58702) = true)

def env58703 : List Nat := [2,4,0,0,1,0,0,5,3,7,3,1,0,0,0,0,1,1,7,0,0,0,0,2,0,1,2,1,1,1,4,3,4,2,0,2]

theorem envBound58703 : H12AffineFastState.Bounded env58703 := by
  intro p hp
  have h : env58703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58702_58703 : H12AffineEnvironment.transform 2 0 env58702 = env58703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58702 == env58703) = true)

def env58704 : List Nat := [2,4,1,0,1,0,0,4,3,7,3,0,1,1,1,1,0,0,7,1,1,0,0,3,0,1,2,0,0,0,5,2,5,3,1,2]

theorem envBound58704 : H12AffineFastState.Bounded env58704 := by
  intro p hp
  have h : env58704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58702_58704 : H12AffineEnvironment.transform 2 1 env58702 = env58704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58702 == env58704) = true)

theorem identity58704 : scanCanonicalize (H12AffineFastState.compose env58704 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58704 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58705 : List Nat := [1,4,1,0,1,0,0,4,0,4,0,0,1,1,1,1,0,0,4,1,1,0,0,0,0,1,1,0,0,0,5,1,5,0,1,1]

theorem envBound58705 : H12AffineFastState.Bounded env58705 := by
  intro p hp
  have h : env58705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58704_58705 : H12AffineEnvironment.transform 0 1 env58704 = env58705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58704 == env58705) = true)

def leafEnv58705 : List Nat := [1,4,1,0,1,0,0,4,0,4,0,0,1,1,1,1,0,0,4,1,1,0,0,0,4,0,1,1,1,0,0,0,5,1,5,0,4,0,1,1,1,0,0]

def active58705 : List Nat := [1]

def tree58705 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58705 : H12WitnessSearch.Good tree58705 := H12GlobalWitnessIndex.good

theorem leafIdentity58705 : H12AffineFastState.composeSystem env58705 rootObs = leafEnv58705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58705 rootObs == leafEnv58705) = true)

theorem terminalChecked58705 : H12PackedTerminal.terminalCheckFast leafEnv58705 active58705 tree58705 = true := by decide +kernel

def env58706 : List Nat := [2,4,8,1,0,1,128,140,130,135,131,136,8,137,137,9,136,136,135,137,137,1,1,138,128,0,130,136,136,136,140,11,141,10,137,131]

theorem envBound58706 : H12AffineFastState.Bounded env58706 := by
  intro p hp
  have h : env58706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58700_58706 : H12AffineEnvironment.transform 3 1 env58700 = env58706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58700 == env58706) = true)

theorem identity58706 : scanCanonicalize (H12AffineFastState.compose env58706 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58707 : List Nat := [1,4,8,1,0,1,128,140,129,132,128,136,8,137,137,9,136,136,132,137,137,1,1,137,128,0,129,136,136,136,140,8,141,9,137,128]

theorem envBound58707 : H12AffineFastState.Bounded env58707 := by
  intro p hp
  have h : env58707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58706_58707 : H12AffineEnvironment.transform 0 1 env58706 = env58707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58706 == env58707) = true)

def env58708 : List Nat := [1,4,8,1,0,1,0,12,1,4,0,8,8,9,9,9,8,8,4,9,9,1,1,9,0,0,1,8,8,8,12,8,13,9,9,0]

theorem envBound58708 : H12AffineFastState.Bounded env58708 := by
  intro p hp
  have h : env58708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58707_58708 : H12AffineEnvironment.transform 6 0 env58707 = env58708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env58707 == env58708) = true)

def env58709 : List Nat := [1,4,8,1,0,1,1,13,0,5,1,9,8,8,8,9,9,9,5,8,8,1,1,8,1,0,0,9,9,9,13,8,12,9,8,1]

theorem envBound58709 : H12AffineFastState.Bounded env58709 := by
  intro p hp
  have h : env58709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58707_58709 : H12AffineEnvironment.transform 6 1 env58707 = env58709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env58707 == env58709) = true)

theorem identity58709 : scanCanonicalize (H12AffineFastState.compose env58709 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58710 : List Nat := [1,4,0,1,0,1,1,5,0,5,1,1,0,0,0,1,1,1,5,0,0,1,1,0,1,0,0,1,1,1,5,0,4,1,0,1]

theorem envBound58710 : H12AffineFastState.Bounded env58710 := by
  intro p hp
  have h : env58710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58709_58710 : H12AffineEnvironment.transform 2 0 env58709 = env58710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58709 == env58710) = true)

def leafEnv58710 : List Nat := [1,4,0,1,0,1,1,5,0,5,1,1,0,0,0,1,1,1,5,0,0,1,1,0,4,1,1,0,0,1,1,1,5,0,4,1,4,0,0,1,1,1,0]

def active58710 : List Nat := [1]

def tree58710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58710 : H12WitnessSearch.Good tree58710 := H12GlobalWitnessIndex.good

theorem leafIdentity58710 : H12AffineFastState.composeSystem env58710 rootObs = leafEnv58710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58710 rootObs == leafEnv58710) = true)

theorem terminalChecked58710 : H12PackedTerminal.terminalCheckFast leafEnv58710 active58710 tree58710 = true := by decide +kernel

def env58711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131153,4315354,8463814,4294967296,256,4307611964,34359738368,33563273]

theorem envBound58711 : H12AffineFastState.Bounded env58711 := by
  intro p hp
  have h : env58711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58637_58711 : H12AffineEnvironment.transform 18 1025 env58637 = env58711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env58637 == env58711) = true)

def env58712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131153,4315354,8463814,4294967296,256,4307611964,131072,33563273]

theorem envBound58712 : H12AffineFastState.Bounded env58712 := by
  intro p hp
  have h : env58712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58711_58712 : H12AffineEnvironment.transform 34 131072 env58711 = env58712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58711 == env58712) = true)

theorem identity58712 : scanCanonicalize (H12AffineFastState.compose env58712 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 140976339) := by decide +kernel

theorem selectedBound58712 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131153,4315354,8463814,140976339,256,145215983,131072,33563273]

theorem envBound58713 : H12AffineFastState.Bounded env58713 := by
  intro p hp
  have h : env58713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58712_58713 : H12AffineEnvironment.transform 31 140976339 env58712 = env58713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 140976339 env58712 == env58713) = true)

theorem identity58713 : scanCanonicalize (H12AffineFastState.compose env58713 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58713 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78035,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,77954,4315354,8463814,140775424,256,145023292,78035,33563273]

theorem envBound58714 : H12AffineFastState.Bounded env58714 := by
  intro p hp
  have h : env58714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58713_58714 : H12AffineEnvironment.transform 16 78035 env58713 = env58714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58713 == env58714) = true)

def env58715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399766,33554432,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,33563273]

theorem envBound58715 : H12AffineFastState.Bounded env58715 := by
  intro p hp
  have h : env58715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58714_58715 : H12AffineEnvironment.transform 14 2640 env58714 = env58715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2640 env58714 == env58715) = true)

def env58716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399766,8328,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,513]

theorem envBound58716 : H12AffineFastState.Bounded env58716 := by
  intro p hp
  have h : env58716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58715_58716 : H12AffineEnvironment.transform 24 8328 env58715 = env58716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58715 == env58716) = true)

theorem identity58716 : scanCanonicalize (H12AffineFastState.compose env58716 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 6376002) := by decide +kernel

theorem selectedBound58716 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,6376002,6382036,8328,6363714,134217728,16385,77954,4280970,6320004,140775424,256,138748206,78035,513]

theorem envBound58717 : H12AffineFastState.Bounded env58717 := by
  intro p hp
  have h : env58717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58716_58717 : H12AffineEnvironment.transform 22 6376002 env58716 = env58717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6376002 env58716 == env58717) = true)

theorem identity58717 : scanCanonicalize (H12AffineFastState.compose env58717 (packedSelected [6,25] rootPS)) = affineNative (2^(26+1) ^^^ 2374613) := by decide +kernel

theorem selectedBound58717 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,6376002,6382036,8328,6363714,2374613,16385,77954,4280970,6320004,4205525,256,6363899,78035,513]

theorem envBound58718 : H12AffineFastState.Bounded env58718 := by
  intro p hp
  have h : env58718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58717_58718 : H12AffineEnvironment.transform 26 2374613 env58717 = env58718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2374613 env58717 == env58718) = true)

theorem identity58718 : scanCanonicalize (H12AffineFastState.compose env58718 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(21+1) ^^^ 2101644) := by decide +kernel

theorem selectedBound58718 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,2101644,89038,94296,8328,68558,2374613,16385,77954,2179846,32264,2112089,256,68471,78035,513]

theorem envBound58719 : H12AffineFastState.Bounded env58719 := by
  intro p hp
  have h : env58719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58718_58719 : H12AffineEnvironment.transform 21 2101644 env58718 = env58719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101644 env58718 == env58719) = true)

theorem identity58719 : scanCanonicalize (H12AffineFastState.compose env58719 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 16464) := by decide +kernel

theorem selectedBound58719 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,16464,20956,89038,94296,8328,68558,293765,16385,77954,66390,32264,31241,256,68471,78035,513]

theorem envBound58720 : H12AffineFastState.Bounded env58720 := by
  intro p hp
  have h : env58720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58719_58720 : H12AffineEnvironment.transform 20 16464 env58719 = env58720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env58719 == env58720) = true)

theorem identity58720 : scanCanonicalize (H12AffineFastState.compose env58720 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 15116) := by decide +kernel

theorem selectedBound58720 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env58721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2640,65536,78035,262144,1025,2640,15196,10960,73922,68436,8328,68558,262281,15117,77954,66390,1284,261,256,68471,78035,513]

theorem envBound58721 : H12AffineFastState.Bounded env58721 := by
  intro p hp
  have h : env58721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58720_58721 : H12AffineEnvironment.transform 13 15116 env58720 = env58721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15116 env58720 == env58721) = true)

theorem identity58721 : scanCanonicalize (H12AffineFastState.compose env58721 (packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 72394) := by decide +kernel

theorem selectedBound58721 : packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env58722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2640,65536,78035,72394,1025,2640,15196,10960,73922,68436,8328,68558,72259,15117,77954,66390,1284,261,256,68471,78035,513]

theorem envBound58722 : H12AffineFastState.Bounded env58722 := by
  intro p hp
  have h : env58722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58721_58722 : H12AffineEnvironment.transform 17 72394 env58721 = env58722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72394 env58721 == env58722) = true)

theorem identity58722 : scanCanonicalize (H12AffineFastState.compose env58722 (packedSelected [3,5,8,13,15,17,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 5102) := by decide +kernel

theorem selectedBound58722 : packedSelected [3,5,8,13,15,17,28,38] rootPS < 2^1333 := by decide +kernel

def env58723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2640,5102,9021,2340,1025,2640,15196,10960,13100,6330,8328,6176,2477,15117,9068,4280,1284,261,256,6297,9021,513]

theorem envBound58723 : H12AffineFastState.Bounded env58723 := by
  intro p hp
  have h : env58723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58722_58723 : H12AffineEnvironment.transform 15 5102 env58722 = env58723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5102 env58722 == env58723) = true)

theorem identity58723 : scanCanonicalize (H12AffineFastState.compose env58723 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2908) := by decide +kernel

theorem selectedBound58723 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2908,4176,2640,5102,2145,2340,1025,2640,4096,396,6256,6330,3028,6176,2477,4177,2096,4280,1284,261,256,6297,2145,513]

theorem envBound58724 : H12AffineFastState.Bounded env58724 := by
  intro p hp
  have h : env58724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58723_58724 : H12AffineEnvironment.transform 12 2908 env58723 = env58724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2908 env58723 == env58724) = true)

theorem identity58724 : scanCanonicalize (H12AffineFastState.compose env58724 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound58724 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,665,2908,713,2640,375,2145,2340,1025,2640,665,396,2793,2595,3028,2745,2477,712,2096,545,1284,261,256,2560,2145,513]

theorem envBound58725 : H12AffineFastState.Bounded env58725 := by
  intro p hp
  have h : env58725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58724_58725 : H12AffineEnvironment.transform 11 665 env58724 = env58725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env58724 == env58725) = true)

theorem identity58725 : scanCanonicalize (H12AffineFastState.compose env58725 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 625) := by decide +kernel

theorem selectedBound58725 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,625,665,301,713,33,375,528,853,1025,33,665,396,152,82,421,200,988,712,577,545,1284,261,256,113,528,513]

theorem envBound58726 : H12AffineFastState.Bounded env58726 := by
  intro p hp
  have h : env58726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58725_58726 : H12AffineEnvironment.transform 10 625 env58725 = env58726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 625 env58725 == env58726) = true)

theorem identity58726 : scanCanonicalize (H12AffineFastState.compose env58726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58727 : List Nat := [2,4,8,16,32,64,128,172,512,1024,625,665,129,713,33,219,528,761,1025,33,665,32,152,82,9,200,624,712,577,545,1192,169,172,113,528,513]

theorem envBound58727 : H12AffineFastState.Bounded env58727 := by
  intro p hp
  have h : env58727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58726_58727 : H12AffineEnvironment.transform 7 172 env58726 = env58727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58726 == env58727) = true)

theorem identity58727 : scanCanonicalize (H12AffineFastState.compose env58727 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58727 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58728 : List Nat := [2,4,8,16,32,64,19,63,512,1024,625,522,18,602,33,72,528,618,1025,33,522,32,11,82,9,91,624,603,577,545,1083,58,63,113,528,513]

theorem envBound58728 : H12AffineFastState.Bounded env58728 := by
  intro p hp
  have h : env58728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58727_58728 : H12AffineEnvironment.transform 6 19 env58727 = env58728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58727 == env58728) = true)

theorem identity58728 : scanCanonicalize (H12AffineFastState.compose env58728 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58728 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58729 : List Nat := [2,4,8,10,32,64,9,37,512,1024,619,522,8,576,33,72,522,618,1025,33,522,32,11,72,9,65,618,577,577,545,1057,32,37,107,522,513]

theorem envBound58729 : H12AffineFastState.Bounded env58729 := by
  intro p hp
  have h : env58729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58728_58729 : H12AffineEnvironment.transform 3 10 env58728 = env58729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58728 == env58729) = true)

theorem identity58729 : scanCanonicalize (H12AffineFastState.compose env58729 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound58729 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58730 : List Nat := [2,4,8,10,32,3,9,37,512,1024,552,522,8,515,33,11,522,553,1025,33,522,32,11,11,9,2,553,514,514,545,1057,32,37,40,522,513]

theorem envBound58730 : H12AffineFastState.Bounded env58730 := by
  intro p hp
  have h : env58730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58729_58730 : H12AffineEnvironment.transform 5 3 env58729 = env58730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env58729 == env58730) = true)

def env58731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399766,8329,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,512]

theorem envBound58731 : H12AffineFastState.Bounded env58731 := by
  intro p hp
  have h : env58731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58715_58731 : H12AffineEnvironment.transform 24 8329 env58715 = env58731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env58715 == env58731) = true)

theorem identity58731 : scanCanonicalize (H12AffineFastState.compose env58731 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58731 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399766,8329,8388689,134217728,4176,77954,4260571,8463814,140775424,256,144980797,78035,512]

theorem envBound58732 : H12AffineFastState.Bounded env58732 := by
  intro p hp
  have h : env58732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58731_58732 : H12AffineEnvironment.transform 13 4177 env58731 = env58732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58731 == env58732) = true)

theorem identity58732 : scanCanonicalize (H12AffineFastState.compose env58732 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58732 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399766,8329,8388689,12919238,4176,77954,4260571,8463814,10564038,256,6363899,78035,512]

theorem envBound58733 : H12AffineFastState.Bounded env58733 := by
  intro p hp
  have h : env58733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58732_58733 : H12AffineEnvironment.transform 26 12919238 env58732 = env58733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58732 == env58733) = true)

theorem identity58733 : scanCanonicalize (H12AffineFastState.compose env58733 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 3039) := by decide +kernel

theorem selectedBound58733 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3039,15116,262144,1025,2640,2097152,4194304,8388608,8399766,8329,8388689,12855833,4176,15197,4196612,8400409,10500633,256,6295844,15116,512]

theorem envBound58734 : H12AffineFastState.Bounded env58734 := by
  intro p hp
  have h : env58734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58733_58734 : H12AffineEnvironment.transform 15 3039 env58733 = env58734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3039 env58733 == env58734) = true)

theorem identity58734 : scanCanonicalize (H12AffineFastState.compose env58734 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 270176) := by decide +kernel

theorem selectedBound58734 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3039,15116,262144,1025,2640,2097152,270176,8388608,8399766,8329,8388689,8402297,4176,15197,267876,8400409,10500633,256,2362948,15116,512]

theorem envBound58735 : H12AffineFastState.Bounded env58735 := by
  intro p hp
  have h : env58735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58734_58735 : H12AffineEnvironment.transform 21 270176 env58734 = env58735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270176 env58734 == env58735) = true)

theorem identity58735 : scanCanonicalize (H12AffineFastState.compose env58735 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound58735 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env58736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3039,15116,8000,1025,2640,2097152,32,8388608,8399766,8329,8388689,8402297,4176,15197,2340,8400409,10500633,256,2101508,15116,512]

theorem envBound58736 : H12AffineFastState.Bounded env58736 := by
  intro p hp
  have h : env58736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58735_58736 : H12AffineEnvironment.transform 17 8000 env58735 = env58736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env58735 == env58736) = true)

def env58737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3039,15116,8000,1025,2640,2097152,32,8296,3070,8329,8249,5393,4176,15197,2340,3697,2103921,256,2101508,15116,512]

theorem envBound58737 : H12AffineFastState.Bounded env58737 := by
  intro p hp
  have h : env58737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58736_58737 : H12AffineEnvironment.transform 22 8296 env58736 = env58737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8296 env58736 == env58737) = true)

def env58738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,80,479,12556,5440,1025,80,2097152,32,8296,510,8329,8249,5393,4176,12637,804,1137,2101361,256,2101508,12556,512]

theorem envBound58738 : H12AffineFastState.Bounded env58738 := by
  intro p hp
  have h : env58738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58737_58738 : H12AffineEnvironment.transform 10 512 env58737 = env58738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58737 == env58738) = true)

theorem identity58738 : scanCanonicalize (H12AffineFastState.compose env58738 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5756) := by decide +kernel

theorem selectedBound58738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,5756,4177,80,479,1904,5440,1025,80,2097152,32,5652,510,5877,5701,5393,4176,1825,804,1137,2101361,256,2101508,1904,512]

theorem envBound58739 : H12AffineFastState.Bounded env58739 := by
  intro p hp
  have h : env58739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58738_58739 : H12AffineEnvironment.transform 12 5756 env58738 = env58739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5756 env58738 == env58739) = true)

def env58740 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5196,4177,80,479,1344,5440,1025,80,2097152,32,5156,510,5317,5237,5393,4176,1297,276,1137,2101361,256,2101508,1344,48]

theorem envBound58740 : H12AffineFastState.Bounded env58740 := by
  intro p hp
  have h : env58740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58739_58740 : H12AffineEnvironment.transform 8 48 env58739 = env58740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58739 == env58740) = true)

theorem identity58740 : scanCanonicalize (H12AffineFastState.compose env58740 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1345) := by decide +kernel

theorem selectedBound58740 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58741 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5196,4177,80,479,1344,5440,1025,80,1345,32,5156,510,5317,5237,5393,4176,1297,276,1137,5424,256,5189,1344,48]

theorem envBound58741 : H12AffineFastState.Bounded env58741 := by
  intro p hp
  have h : env58741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58740_58741 : H12AffineEnvironment.transform 20 1345 env58740 = env58741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1345 env58740 == env58741) = true)

def env58742 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5197,4177,80,479,1345,5440,1025,80,2097152,32,5157,510,5316,5236,5393,4176,1296,277,1137,2101361,256,2101508,1345,49]

theorem envBound58742 : H12AffineFastState.Bounded env58742 := by
  intro p hp
  have h : env58742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58739_58742 : H12AffineEnvironment.transform 8 49 env58739 = env58742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58739 == env58742) = true)

theorem identity58742 : scanCanonicalize (H12AffineFastState.compose env58742 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1076) := by decide +kernel

theorem selectedBound58742 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58743 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5197,4177,80,479,1345,5440,1025,80,1076,32,5157,510,5316,5236,5393,4176,1296,277,1137,5189,256,5424,1345,49]

theorem envBound58743 : H12AffineFastState.Bounded env58743 := by
  intro p hp
  have h : env58743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58742_58743 : H12AffineEnvironment.transform 20 1076 env58742 = env58743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1076 env58742 == env58743) = true)

theorem identity58743 : scanCanonicalize (H12AffineFastState.compose env58743 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58743 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58744 : List Nat := [2,4,8,16,32,64,128,117,49,1024,49,4096,5197,4177,80,170,1076,5173,1025,80,1076,32,5157,139,5316,5236,5220,4176,1125,96,1137,5189,117,5189,1076,49]

theorem envBound58744 : H12AffineFastState.Bounded env58744 := by
  intro p hp
  have h : env58744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58743_58744 : H12AffineEnvironment.transform 7 117 env58743 = env58744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58743 == env58744) = true)

theorem identity58744 : scanCanonicalize (H12AffineFastState.compose env58744 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound58744 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58745 : List Nat := [2,4,8,16,32,64,128,117,49,1024,49,1,1100,80,80,170,1076,1076,1025,80,1076,32,1060,139,1221,1141,1125,81,1125,96,1137,1092,117,1092,1076,49]

theorem envBound58745 : H12AffineFastState.Bounded env58745 := by
  intro p hp
  have h : env58745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58744_58745 : H12AffineEnvironment.transform 11 1 env58744 = env58745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58744 == env58745) = true)

theorem identity58745 : scanCanonicalize (H12AffineFastState.compose env58745 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58745 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58746 : List Nat := [2,4,8,16,16,64,128,69,1,1024,1,1,1100,80,80,154,1028,1028,1025,80,1028,16,1044,139,1221,1093,1109,81,1109,80,1089,1092,69,1092,1028,1]

theorem envBound58746 : H12AffineFastState.Bounded env58746 := by
  intro p hp
  have h : env58746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58745_58746 : H12AffineEnvironment.transform 4 16 env58745 = env58746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58745 == env58746) = true)

theorem identity58746 : scanCanonicalize (H12AffineFastState.compose env58746 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58746 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58747 : List Nat := [2,4,8,16,16,17,128,20,1,1024,1,1,1053,1,1,154,1028,1028,1025,1,1028,16,1044,139,1172,1044,1028,0,1028,1,1040,1045,20,1045,1028,1]

theorem envBound58747 : H12AffineFastState.Bounded env58747 := by
  intro p hp
  have h : env58747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58746_58747 : H12AffineEnvironment.transform 5 17 env58746 = env58747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58746 == env58747) = true)

theorem identity58747 : scanCanonicalize (H12AffineFastState.compose env58747 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58747 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58748 : List Nat := [2,4,8,16,16,17,19,20,1,1024,1,1,1053,1,1,9,1028,1028,1025,1,1028,16,1044,24,1031,1044,1028,0,1028,1,1040,1045,20,1045,1028,1]

theorem envBound58748 : H12AffineFastState.Bounded env58748 := by
  intro p hp
  have h : env58748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58747_58748 : H12AffineEnvironment.transform 6 19 env58747 = env58748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58747 == env58748) = true)

theorem identity58748 : scanCanonicalize (H12AffineFastState.compose env58748 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58748 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58749 : List Nat := [2,4,8,10,10,11,9,14,1,1024,1,1,1031,1,1,9,1028,1028,1025,1,1028,10,1038,2,1031,1038,1028,0,1028,1,1034,1039,14,1039,1028,1]

theorem envBound58749 : H12AffineFastState.Bounded env58749 := by
  intro p hp
  have h : env58749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58748_58749 : H12AffineEnvironment.transform 3 10 env58748 = env58749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58748 == env58749) = true)

theorem identity58749 : scanCanonicalize (H12AffineFastState.compose env58749 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58749 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58750 : List Nat := [2,4,8,10,10,11,9,14,1,4,1,1,3,1,1,9,0,0,5,1,0,10,10,2,3,10,0,0,0,1,14,11,14,11,0,1]

theorem envBound58750 : H12AffineFastState.Bounded env58750 := by
  intro p hp
  have h : env58750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58749_58750 : H12AffineEnvironment.transform 9 4 env58749 = env58750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58749 == env58750) = true)

def env58751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,81,478,12557,5441,1025,81,2097152,32,8296,511,8329,8249,5393,4176,12636,805,1136,2101360,256,2101508,12557,512]

theorem envBound58751 : H12AffineFastState.Bounded env58751 := by
  intro p hp
  have h : env58751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58737_58751 : H12AffineEnvironment.transform 10 513 env58737 = env58751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58737 == env58751) = true)

theorem identity58751 : scanCanonicalize (H12AffineFastState.compose env58751 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1620) := by decide +kernel

theorem selectedBound58751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,8192,1541,81,478,10073,789,1025,81,2097152,32,8296,511,8329,8249,837,1540,9992,805,1136,2098724,256,2099024,10073,512]

theorem envBound58752 : H12AffineFastState.Bounded env58752 := by
  intro p hp
  have h : env58752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58751_58752 : H12AffineEnvironment.transform 11 1620 env58751 = env58752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1620 env58751 == env58752) = true)

def env58753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,536,1541,81,478,1345,789,1025,81,2097152,32,624,511,657,545,837,1540,1296,805,1136,2098724,256,2099024,1345,512]

theorem envBound58753 : H12AffineFastState.Bounded env58753 := by
  intro p hp
  have h : env58753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58752_58753 : H12AffineEnvironment.transform 12 536 env58752 = env58753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58752 == env58753) = true)

theorem identity58753 : scanCanonicalize (H12AffineFastState.compose env58753 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1076) := by decide +kernel

theorem selectedBound58753 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,536,1541,81,478,1345,789,1025,81,1076,32,624,511,657,545,837,1540,1296,805,1136,528,256,868,1345,512]

theorem envBound58754 : H12AffineFastState.Bounded env58754 := by
  intro p hp
  have h : env58754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58753_58754 : H12AffineEnvironment.transform 20 1076 env58753 = env58754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1076 env58753 == env58754) = true)

theorem identity58754 : scanCanonicalize (H12AffineFastState.compose env58754 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58754 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58755 : List Nat := [2,4,8,16,32,64,128,116,512,1024,513,1620,536,1541,81,170,1077,609,1025,81,1076,32,624,139,657,545,561,1540,1124,593,1136,528,116,528,1077,512]

theorem envBound58755 : H12AffineFastState.Bounded env58755 := by
  intro p hp
  have h : env58755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58754_58755 : H12AffineEnvironment.transform 7 116 env58754 = env58755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58754 == env58755) = true)

theorem identity58755 : scanCanonicalize (H12AffineFastState.compose env58755 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound58755 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58756 : List Nat := [2,4,8,16,32,64,128,116,512,84,513,512,536,593,81,170,97,609,85,81,96,32,624,139,657,545,561,592,48,593,36,528,116,528,97,512]

theorem envBound58756 : H12AffineFastState.Bounded env58756 := by
  intro p hp
  have h : env58756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58755_58756 : H12AffineEnvironment.transform 9 84 env58755 = env58756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58755 == env58756) = true)

theorem identity58756 : scanCanonicalize (H12AffineFastState.compose env58756 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58756 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58757 : List Nat := [2,4,8,16,32,64,128,116,1,84,0,1,25,80,81,170,97,96,85,81,96,32,113,139,144,32,48,81,48,80,36,17,116,17,97,1]

theorem envBound58757 : H12AffineFastState.Bounded env58757 := by
  intro p hp
  have h : env58757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58756_58757 : H12AffineEnvironment.transform 8 1 env58756 = env58757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58756 == env58757) = true)

theorem identity58757 : scanCanonicalize (H12AffineFastState.compose env58757 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58757 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58758 : List Nat := [2,4,8,16,32,33,128,21,1,53,0,1,25,49,48,170,0,1,52,48,1,32,16,139,144,32,48,48,48,49,36,17,21,17,0,1]

theorem envBound58758 : H12AffineFastState.Bounded env58758 := by
  intro p hp
  have h : env58758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58757_58758 : H12AffineEnvironment.transform 5 33 env58757 = env58758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58757 == env58758) = true)

theorem identity58758 : scanCanonicalize (H12AffineFastState.compose env58758 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58759 : List Nat := [2,4,8,16,32,33,19,21,1,53,0,1,25,49,48,57,0,1,52,48,1,32,16,24,3,32,48,48,48,49,36,17,21,17,0,1]

theorem envBound58759 : H12AffineFastState.Bounded env58759 := by
  intro p hp
  have h : env58759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58758_58759 : H12AffineEnvironment.transform 6 19 env58758 = env58759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58758 == env58759) = true)

def env58760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,537,1541,81,478,1344,789,1025,81,2097152,32,625,511,656,544,837,1540,1297,805,1136,2098724,256,2099024,1344,512]

theorem envBound58760 : H12AffineFastState.Bounded env58760 := by
  intro p hp
  have h : env58760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58752_58760 : H12AffineEnvironment.transform 12 537 env58752 = env58760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58752 == env58760) = true)

theorem identity58760 : scanCanonicalize (H12AffineFastState.compose env58760 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1344) := by decide +kernel

theorem selectedBound58760 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,537,1541,81,478,1344,789,1025,81,1344,32,625,511,656,544,837,1540,1297,805,1136,868,256,528,1344,512]

theorem envBound58761 : H12AffineFastState.Bounded env58761 := by
  intro p hp
  have h : env58761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58760_58761 : H12AffineEnvironment.transform 20 1344 env58760 = env58761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1344 env58760 == env58761) = true)

def env58762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3039,15116,8000,1025,2640,2097152,32,8297,3071,8329,8248,5392,4176,15197,2340,3696,2103920,256,2101508,15116,512]

theorem envBound58762 : H12AffineFastState.Bounded env58762 := by
  intro p hp
  have h : env58762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58736_58762 : H12AffineEnvironment.transform 22 8297 env58736 = env58762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8297 env58736 == env58762) = true)

def env58763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,80,479,12556,5440,1025,80,2097152,32,8297,511,8329,8248,5392,4176,12637,804,1136,2101360,256,2101508,12556,512]

theorem envBound58763 : H12AffineFastState.Bounded env58763 := by
  intro p hp
  have h : env58763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58762_58763 : H12AffineEnvironment.transform 10 512 env58762 = env58763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58762 == env58763) = true)

theorem identity58763 : scanCanonicalize (H12AffineFastState.compose env58763 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound58763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,8192,1904,80,479,9773,609,1025,80,2097152,32,8297,511,8329,8248,561,1905,9852,804,1136,2099025,256,2098725,9773,512]

theorem envBound58764 : H12AffineFastState.Bounded env58764 := by
  intro p hp
  have h : env58764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58763_58764 : H12AffineEnvironment.transform 11 1825 env58763 = env58764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env58763 == env58764) = true)

def env58765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,536,1904,80,479,1077,609,1025,80,2097152,32,625,511,657,544,561,1905,1124,804,1136,2099025,256,2098725,1077,512]

theorem envBound58765 : H12AffineFastState.Bounded env58765 := by
  intro p hp
  have h : env58765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58764_58765 : H12AffineEnvironment.transform 12 536 env58764 = env58765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58764 == env58765) = true)

theorem identity58765 : scanCanonicalize (H12AffineFastState.compose env58765 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1857) := by decide +kernel

theorem selectedBound58765 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,536,1904,80,479,1077,609,1025,80,1857,32,625,511,657,544,561,1905,1124,804,1136,16,256,356,1077,512]

theorem envBound58766 : H12AffineFastState.Bounded env58766 := by
  intro p hp
  have h : env58766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58765_58766 : H12AffineEnvironment.transform 20 1857 env58765 = env58766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1857 env58765 == env58766) = true)

theorem identity58766 : scanCanonicalize (H12AffineFastState.compose env58766 (packedSelected [1,3,4,6,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58766 : packedSelected [1,3,4,6,9,13] rootPS < 2^1333 := by decide +kernel

def env58767 : List Nat := [2,4,8,16,32,64,128,117,512,1024,512,1620,536,1541,80,170,1077,609,1025,80,1588,32,625,138,657,544,561,1540,1124,593,1136,16,117,17,1077,512]

theorem envBound58767 : H12AffineFastState.Bounded env58767 := by
  intro p hp
  have h : env58767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58766_58767 : H12AffineEnvironment.transform 7 117 env58766 = env58767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58766 == env58767) = true)

theorem identity58767 : scanCanonicalize (H12AffineFastState.compose env58767 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58767 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58768 : List Nat := [2,4,8,16,32,64,128,117,0,1024,0,1108,24,1029,80,170,1077,97,1025,80,1076,32,113,138,145,32,49,1028,1124,81,1136,16,117,17,1077,0]

theorem envBound58768 : H12AffineFastState.Bounded env58768 := by
  intro p hp
  have h : env58768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58767_58768 : H12AffineEnvironment.transform 8 0 env58767 = env58768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58767 == env58768) = true)

theorem identity58768 : scanCanonicalize (H12AffineFastState.compose env58768 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound58768 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env58769 : List Nat := [2,4,8,16,32,64,128,117,0,220,0,136,24,217,80,170,233,97,221,80,232,32,113,138,145,32,49,216,184,81,172,16,117,17,233,0]

theorem envBound58769 : H12AffineFastState.Bounded env58769 := by
  intro p hp
  have h : env58769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58768_58769 : H12AffineEnvironment.transform 9 220 env58768 = env58769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env58768 == env58769) = true)

theorem identity58769 : scanCanonicalize (H12AffineFastState.compose env58769 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound58769 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58770 : List Nat := [2,4,8,16,32,64,57,117,0,101,0,49,24,96,80,19,80,97,100,80,81,32,113,51,40,32,49,97,1,81,21,16,117,17,80,0]

theorem envBound58770 : H12AffineFastState.Bounded env58770 := by
  intro p hp
  have h : env58770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58769_58770 : H12AffineEnvironment.transform 6 57 env58769 = env58770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58769 == env58770) = true)

theorem identity58770 : scanCanonicalize (H12AffineFastState.compose env58770 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58770 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env58771 : List Nat := [2,4,8,16,16,64,9,69,0,85,0,1,24,80,80,19,80,81,84,80,81,16,65,3,24,16,1,81,1,81,21,16,69,17,80,0]

theorem envBound58771 : H12AffineFastState.Bounded env58771 := by
  intro p hp
  have h : env58771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58770_58771 : H12AffineEnvironment.transform 4 16 env58770 = env58771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58770 == env58771) = true)

theorem identity58771 : scanCanonicalize (H12AffineFastState.compose env58771 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58772 : List Nat := [2,4,8,16,16,10,9,15,0,31,0,1,24,26,26,19,26,27,30,26,27,16,11,3,24,16,1,27,1,27,21,16,15,17,26,0]

theorem envBound58772 : H12AffineFastState.Bounded env58772 := by
  intro p hp
  have h : env58772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58771_58772 : H12AffineEnvironment.transform 5 10 env58771 = env58772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58771 == env58772) = true)

theorem identity58772 : scanCanonicalize (H12AffineFastState.compose env58772 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58772 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58773 : List Nat := [2,4,8,10,10,10,9,15,0,5,0,1,2,0,0,9,0,1,4,0,1,10,11,3,2,10,1,1,1,1,15,10,15,11,0,0]

theorem envBound58773 : H12AffineFastState.Bounded env58773 := by
  intro p hp
  have h : env58773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58772_58773 : H12AffineEnvironment.transform 3 10 env58772 = env58773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58772 == env58773) = true)

def env58774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,537,1904,80,479,1076,609,1025,80,2097152,32,624,511,656,545,561,1905,1125,804,1136,2099025,256,2098725,1076,512]

theorem envBound58774 : H12AffineFastState.Bounded env58774 := by
  intro p hp
  have h : env58774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58764_58774 : H12AffineEnvironment.transform 12 537 env58764 = env58774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58764 == env58774) = true)

theorem identity58774 : scanCanonicalize (H12AffineFastState.compose env58774 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1588) := by decide +kernel

theorem selectedBound58774 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,537,1904,80,479,1076,609,1025,80,1588,32,624,511,656,545,561,1905,1125,804,1136,357,256,17,1076,512]

theorem envBound58775 : H12AffineFastState.Bounded env58775 := by
  intro p hp
  have h : env58775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58774_58775 : H12AffineEnvironment.transform 20 1588 env58774 = env58775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1588 env58774 == env58775) = true)

theorem identity58775 : scanCanonicalize (H12AffineFastState.compose env58775 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58775 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58776 : List Nat := [2,4,8,16,32,64,128,256,0,1024,0,1313,25,1392,80,479,1076,97,1025,80,1076,32,112,511,144,33,49,1393,1125,292,1136,357,256,17,1076,0]

theorem envBound58776 : H12AffineFastState.Bounded env58776 := by
  intro p hp
  have h : env58776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58775_58776 : H12AffineEnvironment.transform 8 0 env58775 = env58776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58775 == env58776) = true)

theorem identity58776 : scanCanonicalize (H12AffineFastState.compose env58776 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58776 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env58777 : List Nat := [2,4,8,16,32,64,128,117,0,1024,0,1108,25,1029,80,170,1076,97,1025,80,1076,32,112,138,144,33,49,1028,1125,81,1136,16,117,17,1076,0]

theorem envBound58777 : H12AffineFastState.Bounded env58777 := by
  intro p hp
  have h : env58777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58776_58777 : H12AffineEnvironment.transform 7 117 env58776 = env58777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58776 == env58777) = true)

def env58778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,81,478,12557,5441,1025,81,2097152,32,8297,510,8329,8248,5392,4176,12636,805,1137,2101361,256,2101508,12557,512]

theorem envBound58778 : H12AffineFastState.Bounded env58778 := by
  intro p hp
  have h : env58778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58762_58778 : H12AffineEnvironment.transform 10 513 env58762 = env58778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58762 == env58778) = true)

theorem identity58778 : scanCanonicalize (H12AffineFastState.compose env58778 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5897) := by decide +kernel

theorem selectedBound58778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,5897,4177,81,478,1540,5441,1025,81,2097152,32,5984,510,6016,5937,5392,4176,1621,805,1137,2101361,256,2101508,1540,512]

theorem envBound58779 : H12AffineFastState.Bounded env58779 := by
  intro p hp
  have h : env58779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58778_58779 : H12AffineEnvironment.transform 12 5897 env58778 = env58779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5897 env58778 == env58779) = true)

def env58780 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5433,4177,81,478,1076,5441,1025,81,2097152,32,5456,510,5552,5377,5392,4176,1125,277,1137,2101361,256,2101508,1076,48]

theorem envBound58780 : H12AffineFastState.Bounded env58780 := by
  intro p hp
  have h : env58780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58779_58780 : H12AffineEnvironment.transform 8 48 env58779 = env58780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58779 == env58780) = true)

theorem identity58780 : scanCanonicalize (H12AffineFastState.compose env58780 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1393) := by decide +kernel

theorem selectedBound58780 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58781 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5433,4177,81,478,1076,5441,1025,81,1393,32,5456,510,5552,5377,5392,4176,1125,277,1137,5376,256,5237,1076,48]

theorem envBound58781 : H12AffineFastState.Bounded env58781 := by
  intro p hp
  have h : env58781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58780_58781 : H12AffineEnvironment.transform 20 1393 env58780 = env58781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1393 env58780 == env58781) = true)

theorem identity58781 : scanCanonicalize (H12AffineFastState.compose env58781 (packedSelected [1,3,4,6,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58781 : packedSelected [1,3,4,6,9,13] rootPS < 2^1333 := by decide +kernel

def env58782 : List Nat := [2,4,8,16,32,64,128,116,48,1024,49,4096,5197,4177,81,170,1076,5173,1025,81,1029,32,5156,138,5316,5237,5220,4176,1125,97,1137,5236,116,5237,1076,48]

theorem envBound58782 : H12AffineFastState.Bounded env58782 := by
  intro p hp
  have h : env58782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58781_58782 : H12AffineEnvironment.transform 7 116 env58781 = env58782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58781 == env58782) = true)

def env58783 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5432,4177,81,478,1077,5441,1025,81,2097152,32,5457,510,5553,5376,5392,4176,1124,276,1137,2101361,256,2101508,1077,49]

theorem envBound58783 : H12AffineFastState.Bounded env58783 := by
  intro p hp
  have h : env58783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58779_58783 : H12AffineEnvironment.transform 8 49 env58779 = env58783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58779 == env58783) = true)

theorem identity58783 : scanCanonicalize (H12AffineFastState.compose env58783 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58783 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58784 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5432,4177,81,478,1077,5441,1025,81,1028,32,5457,510,5553,5376,5392,4176,1124,276,1137,5237,256,5376,1077,49]

theorem envBound58784 : H12AffineFastState.Bounded env58784 := by
  intro p hp
  have h : env58784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58783_58784 : H12AffineEnvironment.transform 20 1028 env58783 = env58784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env58783 == env58784) = true)

theorem identity58784 : scanCanonicalize (H12AffineFastState.compose env58784 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58784 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58785 : List Nat := [2,4,8,16,16,64,128,256,1,1024,0,4096,5384,4177,81,478,1029,5441,1025,81,1028,16,5457,462,5505,5376,5392,4176,1108,276,1089,5189,256,5376,1029,1]

theorem envBound58785 : H12AffineFastState.Bounded env58785 := by
  intro p hp
  have h : env58785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58784_58785 : H12AffineEnvironment.transform 4 16 env58784 = env58785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58784 == env58785) = true)

theorem identity58785 : scanCanonicalize (H12AffineFastState.compose env58785 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58785 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env58786 : List Nat := [2,4,8,16,16,64,128,68,1,1024,0,4096,5196,4177,81,154,1029,5125,1025,81,1028,16,5141,138,5317,5188,5204,4176,1108,80,1089,5189,68,5188,1029,1]

theorem envBound58786 : H12AffineFastState.Bounded env58786 := by
  intro p hp
  have h : env58786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58785_58786 : H12AffineEnvironment.transform 7 68 env58785 = env58786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58785 == env58786) = true)

def env58787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399767,33554432,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,33563273]

theorem envBound58787 : H12AffineFastState.Bounded env58787 := by
  intro p hp
  have h : env58787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58714_58787 : H12AffineEnvironment.transform 14 2641 env58714 = env58787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2641 env58714 == env58787) = true)

def env58788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399767,8328,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,513]

theorem envBound58788 : H12AffineFastState.Bounded env58788 := by
  intro p hp
  have h : env58788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58787_58788 : H12AffineEnvironment.transform 24 8328 env58787 = env58788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58787 == env58788) = true)

theorem identity58788 : scanCanonicalize (H12AffineFastState.compose env58788 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 6376003) := by decide +kernel

theorem selectedBound58788 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,6376003,6382036,8328,6363715,134217728,16385,77954,4280971,6320005,140775424,256,138748206,78035,513]

theorem envBound58789 : H12AffineFastState.Bounded env58789 := by
  intro p hp
  have h : env58789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58788_58789 : H12AffineEnvironment.transform 22 6376003 env58788 = env58789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6376003 env58788 == env58789) = true)

theorem identity58789 : scanCanonicalize (H12AffineFastState.compose env58789 (packedSelected [6,25] rootPS)) = affineNative (2^(26+1) ^^^ 2374612) := by decide +kernel

theorem selectedBound58789 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,6376003,6382036,8328,6363715,2374612,16385,77954,4280971,6320005,4205524,256,6363898,78035,513]

theorem envBound58790 : H12AffineFastState.Bounded env58790 := by
  intro p hp
  have h : env58790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58789_58790 : H12AffineEnvironment.transform 26 2374612 env58789 = env58790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2374612 env58789 == env58790) = true)

theorem identity58790 : scanCanonicalize (H12AffineFastState.compose env58790 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(21+1) ^^^ 2101644) := by decide +kernel

theorem selectedBound58790 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,2101644,89039,94296,8328,68559,2374612,16385,77954,2179847,32265,2112088,256,68470,78035,513]

theorem envBound58791 : H12AffineFastState.Bounded env58791 := by
  intro p hp
  have h : env58791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58790_58791 : H12AffineEnvironment.transform 21 2101644 env58790 = env58791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101644 env58790 == env58791) = true)

theorem identity58791 : scanCanonicalize (H12AffineFastState.compose env58791 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 16464) := by decide +kernel

theorem selectedBound58791 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,16464,20956,89039,94296,8328,68559,293764,16385,77954,66391,32265,31240,256,68470,78035,513]

theorem envBound58792 : H12AffineFastState.Bounded env58792 := by
  intro p hp
  have h : env58792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58791_58792 : H12AffineEnvironment.transform 20 16464 env58791 = env58792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env58791 == env58792) = true)

theorem identity58792 : scanCanonicalize (H12AffineFastState.compose env58792 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 15117) := by decide +kernel

theorem selectedBound58792 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env58793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2641,65536,78035,262144,1025,2641,15197,10961,73922,68437,8328,68559,262281,15116,77954,66391,1284,261,256,68470,78035,513]

theorem envBound58793 : H12AffineFastState.Bounded env58793 := by
  intro p hp
  have h : env58793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58792_58793 : H12AffineEnvironment.transform 13 15117 env58792 = env58793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15117 env58792 == env58793) = true)

theorem identity58793 : scanCanonicalize (H12AffineFastState.compose env58793 (packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 72394) := by decide +kernel

theorem selectedBound58793 : packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env58794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2641,65536,78035,72394,1025,2641,15197,10961,73922,68437,8328,68559,72259,15116,77954,66391,1284,261,256,68470,78035,513]

theorem envBound58794 : H12AffineFastState.Bounded env58794 := by
  intro p hp
  have h : env58794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58793_58794 : H12AffineEnvironment.transform 17 72394 env58793 = env58794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72394 env58793 == env58794) = true)

theorem identity58794 : scanCanonicalize (H12AffineFastState.compose env58794 (packedSelected [3,5,8,13,15,17,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 5102) := by decide +kernel

theorem selectedBound58794 : packedSelected [3,5,8,13,15,17,28,38] rootPS < 2^1333 := by decide +kernel

def env58795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2641,5102,9021,2340,1025,2641,15197,10961,13100,6331,8328,6177,2477,15116,9068,4281,1284,261,256,6296,9021,513]

theorem envBound58795 : H12AffineFastState.Bounded env58795 := by
  intro p hp
  have h : env58795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58794_58795 : H12AffineEnvironment.transform 15 5102 env58794 = env58795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5102 env58794 == env58795) = true)

theorem identity58795 : scanCanonicalize (H12AffineFastState.compose env58795 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2909) := by decide +kernel

theorem selectedBound58795 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2909,4176,2641,5102,2144,2340,1025,2641,4096,396,6257,6331,3029,6177,2477,4177,2097,4281,1284,261,256,6296,2144,513]

theorem envBound58796 : H12AffineFastState.Bounded env58796 := by
  intro p hp
  have h : env58796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58795_58796 : H12AffineEnvironment.transform 12 2909 env58795 = env58796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2909 env58795 == env58796) = true)

theorem identity58796 : scanCanonicalize (H12AffineFastState.compose env58796 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound58796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,665,2909,713,2641,375,2144,2340,1025,2641,665,396,2792,2594,3029,2744,2477,712,2097,544,1284,261,256,2561,2144,513]

theorem envBound58797 : H12AffineFastState.Bounded env58797 := by
  intro p hp
  have h : env58797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58796_58797 : H12AffineEnvironment.transform 11 665 env58796 = env58797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env58796 == env58797) = true)

theorem identity58797 : scanCanonicalize (H12AffineFastState.compose env58797 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound58797 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,624,665,301,713,33,375,528,852,1025,33,665,396,152,82,421,200,989,712,577,544,1284,261,256,113,528,513]

theorem envBound58798 : H12AffineFastState.Bounded env58798 := by
  intro p hp
  have h : env58798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58797_58798 : H12AffineEnvironment.transform 10 624 env58797 = env58798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env58797 == env58798) = true)

theorem identity58798 : scanCanonicalize (H12AffineFastState.compose env58798 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58798 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58799 : List Nat := [2,4,8,16,32,64,128,172,512,1024,624,665,129,713,33,219,528,760,1025,33,665,32,152,82,9,200,625,712,577,544,1192,169,172,113,528,513]

theorem envBound58799 : H12AffineFastState.Bounded env58799 := by
  intro p hp
  have h : env58799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58798_58799 : H12AffineEnvironment.transform 7 172 env58798 = env58799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58798 == env58799) = true)

theorem identity58799 : scanCanonicalize (H12AffineFastState.compose env58799 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58799 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58800 : List Nat := [2,4,8,16,32,64,19,63,512,1024,624,522,18,602,33,72,528,619,1025,33,522,32,11,82,9,91,625,603,577,544,1083,58,63,113,528,513]

theorem envBound58800 : H12AffineFastState.Bounded env58800 := by
  intro p hp
  have h : env58800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58799_58800 : H12AffineEnvironment.transform 6 19 env58799 = env58800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58799 == env58800) = true)

theorem identity58800 : scanCanonicalize (H12AffineFastState.compose env58800 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58800 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58801 : List Nat := [2,4,8,10,32,64,9,37,512,1024,618,522,8,576,33,72,522,619,1025,33,522,32,11,72,9,65,619,577,577,544,1057,32,37,107,522,513]

theorem envBound58801 : H12AffineFastState.Bounded env58801 := by
  intro p hp
  have h : env58801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58800_58801 : H12AffineEnvironment.transform 3 10 env58800 = env58801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58800 == env58801) = true)

theorem identity58801 : scanCanonicalize (H12AffineFastState.compose env58801 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound58801 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58802 : List Nat := [2,4,8,10,32,2,9,37,512,1024,552,522,8,514,33,10,522,553,1025,33,522,32,11,10,9,3,553,515,515,544,1057,32,37,41,522,513]

theorem envBound58802 : H12AffineFastState.Bounded env58802 := by
  intro p hp
  have h : env58802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58801_58802 : H12AffineEnvironment.transform 5 2 env58801 = env58802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env58801 == env58802) = true)

def env58803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399767,8329,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,512]

theorem envBound58803 : H12AffineFastState.Bounded env58803 := by
  intro p hp
  have h : env58803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58787_58803 : H12AffineEnvironment.transform 24 8329 env58787 = env58803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env58787 == env58803) = true)

theorem identity58803 : scanCanonicalize (H12AffineFastState.compose env58803 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58803 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399767,8329,8388689,134217728,4176,77954,4260570,8463814,140775424,256,144980796,78035,512]

theorem envBound58804 : H12AffineFastState.Bounded env58804 := by
  intro p hp
  have h : env58804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58803_58804 : H12AffineEnvironment.transform 13 4177 env58803 = env58804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58803 == env58804) = true)

theorem identity58804 : scanCanonicalize (H12AffineFastState.compose env58804 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58804 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399767,8329,8388689,12919238,4176,77954,4260570,8463814,10564038,256,6363898,78035,512]

theorem envBound58805 : H12AffineFastState.Bounded env58805 := by
  intro p hp
  have h : env58805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58804_58805 : H12AffineEnvironment.transform 26 12919238 env58804 = env58805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58804 == env58805) = true)

theorem identity58805 : scanCanonicalize (H12AffineFastState.compose env58805 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 3038) := by decide +kernel

theorem selectedBound58805 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3038,15117,262144,1025,2641,2097152,4194304,8388608,8399767,8329,8388689,12855832,4176,15196,4196612,8400408,10500632,256,6295844,15117,512]

theorem envBound58806 : H12AffineFastState.Bounded env58806 := by
  intro p hp
  have h : env58806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58805_58806 : H12AffineEnvironment.transform 15 3038 env58805 = env58806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3038 env58805 == env58806) = true)

theorem identity58806 : scanCanonicalize (H12AffineFastState.compose env58806 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 270176) := by decide +kernel

theorem selectedBound58806 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3038,15117,262144,1025,2641,2097152,270176,8388608,8399767,8329,8388689,8402296,4176,15196,267876,8400408,10500632,256,2362948,15117,512]

theorem envBound58807 : H12AffineFastState.Bounded env58807 := by
  intro p hp
  have h : env58807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58806_58807 : H12AffineEnvironment.transform 21 270176 env58806 = env58807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270176 env58806 == env58807) = true)

theorem identity58807 : scanCanonicalize (H12AffineFastState.compose env58807 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound58807 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env58808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3038,15117,8000,1025,2641,2097152,32,8388608,8399767,8329,8388689,8402296,4176,15196,2340,8400408,10500632,256,2101508,15117,512]

theorem envBound58808 : H12AffineFastState.Bounded env58808 := by
  intro p hp
  have h : env58808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58807_58808 : H12AffineEnvironment.transform 17 8000 env58807 = env58808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env58807 == env58808) = true)

def env58809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3038,15117,8000,1025,2641,2097152,32,8296,3071,8329,8249,5392,4176,15196,2340,3696,2103920,256,2101508,15117,512]

theorem envBound58809 : H12AffineFastState.Bounded env58809 := by
  intro p hp
  have h : env58809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58808_58809 : H12AffineEnvironment.transform 22 8296 env58808 = env58809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8296 env58808 == env58809) = true)

def env58810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,81,478,12557,5440,1025,81,2097152,32,8296,511,8329,8249,5392,4176,12636,804,1136,2101360,256,2101508,12557,512]

theorem envBound58810 : H12AffineFastState.Bounded env58810 := by
  intro p hp
  have h : env58810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58809_58810 : H12AffineEnvironment.transform 10 512 env58809 = env58810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58809 == env58810) = true)

theorem identity58810 : scanCanonicalize (H12AffineFastState.compose env58810 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1621) := by decide +kernel

theorem selectedBound58810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,8192,1540,81,478,10072,789,1025,81,2097152,32,8296,511,8329,8249,837,1541,9993,804,1136,2098725,256,2099025,10072,512]

theorem envBound58811 : H12AffineFastState.Bounded env58811 := by
  intro p hp
  have h : env58811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58810_58811 : H12AffineEnvironment.transform 11 1621 env58810 = env58811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1621 env58810 == env58811) = true)

def env58812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,536,1540,81,478,1344,789,1025,81,2097152,32,624,511,657,545,837,1541,1297,804,1136,2098725,256,2099025,1344,512]

theorem envBound58812 : H12AffineFastState.Bounded env58812 := by
  intro p hp
  have h : env58812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58811_58812 : H12AffineEnvironment.transform 12 536 env58811 = env58812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58811 == env58812) = true)

theorem identity58812 : scanCanonicalize (H12AffineFastState.compose env58812 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1904) := by decide +kernel

theorem selectedBound58812 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,536,1540,81,478,1344,789,1025,81,1904,32,624,511,657,545,837,1541,1297,804,1136,341,256,33,1344,512]

theorem envBound58813 : H12AffineFastState.Bounded env58813 := by
  intro p hp
  have h : env58813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58812_58813 : H12AffineEnvironment.transform 20 1904 env58812 = env58813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1904 env58812 == env58813) = true)

theorem identity58813 : scanCanonicalize (H12AffineFastState.compose env58813 (packedSelected [1,3,6,7,9,10,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58813 : packedSelected [1,3,6,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env58814 : List Nat := [2,4,8,16,32,64,128,256,372,1024,372,1313,364,1392,81,478,1344,97,1025,81,1028,32,260,511,485,341,49,1393,1297,80,1136,341,256,33,1344,372]

theorem envBound58814 : H12AffineFastState.Bounded env58814 := by
  intro p hp
  have h : env58814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58813_58814 : H12AffineEnvironment.transform 8 372 env58813 = env58814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58813 == env58814) = true)

theorem identity58814 : scanCanonicalize (H12AffineFastState.compose env58814 (packedSelected [0,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58814 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env58815 : List Nat := [2,4,8,16,32,64,128,117,1,1024,1,1108,25,1029,81,171,1077,97,1025,81,1028,32,113,138,144,32,49,1028,1124,80,1136,32,117,33,1077,1]

theorem envBound58815 : H12AffineFastState.Bounded env58815 := by
  intro p hp
  have h : env58815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58814_58815 : H12AffineEnvironment.transform 7 117 env58814 = env58815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58814 == env58815) = true)

def env58816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,537,1540,81,478,1345,789,1025,81,2097152,32,625,511,656,544,837,1541,1296,804,1136,2098725,256,2099025,1345,512]

theorem envBound58816 : H12AffineFastState.Bounded env58816 := by
  intro p hp
  have h : env58816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58811_58816 : H12AffineEnvironment.transform 12 537 env58811 = env58816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58811 == env58816) = true)

theorem identity58816 : scanCanonicalize (H12AffineFastState.compose env58816 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1541) := by decide +kernel

theorem selectedBound58816 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,537,1540,81,478,1345,789,1025,81,1541,32,625,511,656,544,837,1541,1296,804,1136,32,256,340,1345,512]

theorem envBound58817 : H12AffineFastState.Bounded env58817 := by
  intro p hp
  have h : env58817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58816_58817 : H12AffineEnvironment.transform 20 1541 env58816 = env58817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1541 env58816 == env58817) = true)

theorem identity58817 : scanCanonicalize (H12AffineFastState.compose env58817 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58817 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58818 : List Nat := [2,4,8,16,32,64,128,117,512,1024,512,1621,537,1540,81,171,1076,608,1025,81,1541,32,625,138,656,544,560,1541,1125,593,1136,32,117,33,1076,512]

theorem envBound58818 : H12AffineFastState.Bounded env58818 := by
  intro p hp
  have h : env58818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58817_58818 : H12AffineEnvironment.transform 7 117 env58817 = env58818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58817 == env58818) = true)

theorem identity58818 : scanCanonicalize (H12AffineFastState.compose env58818 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58819 : List Nat := [2,4,8,16,32,64,128,117,0,1024,0,1109,25,1028,81,171,1076,96,1025,81,1029,32,113,138,144,32,48,1029,1125,81,1136,32,117,33,1076,0]

theorem envBound58819 : H12AffineFastState.Bounded env58819 := by
  intro p hp
  have h : env58819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58818_58819 : H12AffineEnvironment.transform 8 0 env58818 = env58819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58818 == env58819) = true)

def env58820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,80,479,12556,5441,1025,80,2097152,32,8296,510,8329,8249,5392,4176,12637,805,1137,2101361,256,2101508,12556,512]

theorem envBound58820 : H12AffineFastState.Bounded env58820 := by
  intro p hp
  have h : env58820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58809_58820 : H12AffineEnvironment.transform 10 513 env58809 = env58820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58809 == env58820) = true)

theorem identity58820 : scanCanonicalize (H12AffineFastState.compose env58820 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5757) := by decide +kernel

theorem selectedBound58820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,5757,4177,80,479,1905,5441,1025,80,2097152,32,5653,510,5876,5700,5392,4176,1824,805,1137,2101361,256,2101508,1905,512]

theorem envBound58821 : H12AffineFastState.Bounded env58821 := by
  intro p hp
  have h : env58821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58820_58821 : H12AffineEnvironment.transform 12 5757 env58820 = env58821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5757 env58820 == env58821) = true)

def env58822 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5197,4177,80,479,1345,5441,1025,80,2097152,32,5157,510,5316,5236,5392,4176,1296,277,1137,2101361,256,2101508,1345,48]

theorem envBound58822 : H12AffineFastState.Bounded env58822 := by
  intro p hp
  have h : env58822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58821_58822 : H12AffineEnvironment.transform 8 48 env58821 = env58822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58821 == env58822) = true)

theorem identity58822 : scanCanonicalize (H12AffineFastState.compose env58822 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58822 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58823 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5197,4177,80,479,1345,5441,1025,80,4177,32,5157,510,5316,5236,5392,4176,1296,277,1137,32,256,341,1345,48]

theorem envBound58823 : H12AffineFastState.Bounded env58823 := by
  intro p hp
  have h : env58823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58822_58823 : H12AffineEnvironment.transform 20 4177 env58822 = env58823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4177 env58822 == env58823) = true)

theorem identity58823 : scanCanonicalize (H12AffineFastState.compose env58823 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58823 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58824 : List Nat := [2,4,8,16,32,64,128,116,48,1024,49,4096,5197,4177,80,171,1077,5173,1025,80,4177,32,5157,138,5316,5236,5220,4176,1124,97,1137,32,116,33,1077,48]

theorem envBound58824 : H12AffineFastState.Bounded env58824 := by
  intro p hp
  have h : env58824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58823_58824 : H12AffineEnvironment.transform 7 116 env58823 = env58824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58823 == env58824) = true)

theorem identity58824 : scanCanonicalize (H12AffineFastState.compose env58824 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58824 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58825 : List Nat := [2,4,8,16,17,64,128,69,1,1024,0,4096,5197,4177,80,154,1028,5124,1025,80,4177,17,5140,138,5316,5189,5205,4176,1109,80,1088,17,69,16,1028,1]

theorem envBound58825 : H12AffineFastState.Bounded env58825 := by
  intro p hp
  have h : env58825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58824_58825 : H12AffineEnvironment.transform 4 17 env58824 = env58825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58824 == env58825) = true)

def env58826 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5196,4177,80,479,1344,5441,1025,80,2097152,32,5156,510,5317,5237,5392,4176,1297,276,1137,2101361,256,2101508,1344,49]

theorem envBound58826 : H12AffineFastState.Bounded env58826 := by
  intro p hp
  have h : env58826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58821_58826 : H12AffineEnvironment.transform 8 49 env58821 = env58826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58821 == env58826) = true)

theorem identity58826 : scanCanonicalize (H12AffineFastState.compose env58826 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4389) := by decide +kernel

theorem selectedBound58826 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58827 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5196,4177,80,479,1344,5441,1025,80,4389,32,5156,510,5317,5237,5392,4176,1297,276,1137,340,256,33,1344,49]

theorem envBound58827 : H12AffineFastState.Bounded env58827 := by
  intro p hp
  have h : env58827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58826_58827 : H12AffineEnvironment.transform 20 4389 env58826 = env58827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4389 env58826 == env58827) = true)

theorem identity58827 : scanCanonicalize (H12AffineFastState.compose env58827 (packedSelected [1,3,6,7,9,10,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58827 : packedSelected [1,3,6,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env58828 : List Nat := [2,4,8,16,32,64,128,69,49,1024,48,4096,5196,4177,80,154,1029,5124,1025,80,4192,32,5156,187,5317,5237,5205,4176,1108,81,1137,17,69,33,1029,49]

theorem envBound58828 : H12AffineFastState.Bounded env58828 := by
  intro p hp
  have h : env58828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58827_58828 : H12AffineEnvironment.transform 7 69 env58827 = env58828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58827 == env58828) = true)

theorem identity58828 : scanCanonicalize (H12AffineFastState.compose env58828 (packedSelected [0,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58828 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env58829 : List Nat := [2,4,8,16,17,64,128,69,0,1024,1,4096,5196,4177,80,154,1029,5124,1025,80,4177,17,5141,138,5317,5188,5205,4176,1108,81,1088,17,69,16,1029,0]

theorem envBound58829 : H12AffineFastState.Bounded env58829 := by
  intro p hp
  have h : env58829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58828_58829 : H12AffineEnvironment.transform 4 17 env58828 = env58829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58828 == env58829) = true)

def env58830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3038,15117,8000,1025,2641,2097152,32,8297,3070,8329,8248,5393,4176,15196,2340,3697,2103921,256,2101508,15117,512]

theorem envBound58830 : H12AffineFastState.Bounded env58830 := by
  intro p hp
  have h : env58830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58808_58830 : H12AffineEnvironment.transform 22 8297 env58808 = env58830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8297 env58808 == env58830) = true)

def env58831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,81,478,12557,5440,1025,81,2097152,32,8297,510,8329,8248,5393,4176,12636,804,1137,2101361,256,2101508,12557,512]

theorem envBound58831 : H12AffineFastState.Bounded env58831 := by
  intro p hp
  have h : env58831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58830_58831 : H12AffineEnvironment.transform 10 512 env58830 = env58831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58830 == env58831) = true)

theorem identity58831 : scanCanonicalize (H12AffineFastState.compose env58831 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5896) := by decide +kernel

theorem selectedBound58831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,5896,4177,81,478,1541,5440,1025,81,2097152,32,5985,510,6017,5936,5393,4176,1620,804,1137,2101361,256,2101508,1541,512]

theorem envBound58832 : H12AffineFastState.Bounded env58832 := by
  intro p hp
  have h : env58832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58831_58832 : H12AffineEnvironment.transform 12 5896 env58831 = env58832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5896 env58831 == env58832) = true)

def env58833 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5432,4177,81,478,1077,5440,1025,81,2097152,32,5457,510,5553,5376,5393,4176,1124,276,1137,2101361,256,2101508,1077,48]

theorem envBound58833 : H12AffineFastState.Bounded env58833 := by
  intro p hp
  have h : env58833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58832_58833 : H12AffineEnvironment.transform 8 48 env58832 = env58833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58832 == env58833) = true)

theorem identity58833 : scanCanonicalize (H12AffineFastState.compose env58833 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4372) := by decide +kernel

theorem selectedBound58833 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58834 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5432,4177,81,478,1077,5440,1025,81,4372,32,5457,510,5553,5376,5393,4176,1124,276,1137,357,256,16,1077,48]

theorem envBound58834 : H12AffineFastState.Bounded env58834 := by
  intro p hp
  have h : env58834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58833_58834 : H12AffineEnvironment.transform 20 4372 env58833 = env58834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4372 env58833 == env58834) = true)

theorem identity58834 : scanCanonicalize (H12AffineFastState.compose env58834 (packedSelected [4,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58834 : packedSelected [4,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58835 : List Nat := [2,4,8,16,32,64,128,116,48,1024,48,4096,5196,4177,81,170,1077,5172,1025,81,4192,32,5157,138,5317,5236,5221,4176,1124,96,1137,17,116,16,1077,48]

theorem envBound58835 : H12AffineFastState.Bounded env58835 := by
  intro p hp
  have h : env58835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58834_58835 : H12AffineEnvironment.transform 7 116 env58834 = env58835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58834 == env58835) = true)

theorem identity58835 : scanCanonicalize (H12AffineFastState.compose env58835 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58835 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58836 : List Nat := [2,4,8,16,17,64,128,69,1,1024,1,4096,5196,4177,81,155,1028,5125,1025,81,4177,17,5140,138,5317,5189,5204,4176,1109,81,1088,17,69,16,1028,1]

theorem envBound58836 : H12AffineFastState.Bounded env58836 := by
  intro p hp
  have h : env58836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58835_58836 : H12AffineEnvironment.transform 4 17 env58835 = env58836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58835 == env58836) = true)

def env58837 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5433,4177,81,478,1076,5440,1025,81,2097152,32,5456,510,5552,5377,5393,4176,1125,277,1137,2101361,256,2101508,1076,49]

theorem envBound58837 : H12AffineFastState.Bounded env58837 := by
  intro p hp
  have h : env58837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58832_58837 : H12AffineEnvironment.transform 8 49 env58832 = env58837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58832 == env58837) = true)

theorem identity58837 : scanCanonicalize (H12AffineFastState.compose env58837 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4192) := by decide +kernel

theorem selectedBound58837 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58838 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5433,4177,81,478,1076,5440,1025,81,4192,32,5456,510,5552,5377,5393,4176,1125,277,1137,17,256,356,1076,49]

theorem envBound58838 : H12AffineFastState.Bounded env58838 := by
  intro p hp
  have h : env58838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58837_58838 : H12AffineEnvironment.transform 20 4192 env58837 = env58838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4192 env58837 == env58838) = true)

theorem identity58838 : scanCanonicalize (H12AffineFastState.compose env58838 (packedSelected [0,3,5,7,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58838 : packedSelected [0,3,5,7,12,13] rootPS < 2^1333 := by decide +kernel

def env58839 : List Nat := [2,4,8,16,32,64,128,69,49,1024,49,4096,5244,4177,81,155,1076,5125,1025,81,4192,32,5141,187,5365,5188,5204,4176,1125,80,1137,17,69,33,1076,49]

theorem envBound58839 : H12AffineFastState.Bounded env58839 := by
  intro p hp
  have h : env58839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58838_58839 : H12AffineEnvironment.transform 7 69 env58838 = env58839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58838 == env58839) = true)

theorem identity58839 : scanCanonicalize (H12AffineFastState.compose env58839 (packedSelected [1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58839 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env58840 : List Nat := [2,4,8,16,17,64,128,69,0,1024,0,4096,5197,4177,81,155,1029,5125,1025,81,4177,17,5141,138,5316,5188,5204,4176,1108,80,1088,17,69,16,1029,0]

theorem envBound58840 : H12AffineFastState.Bounded env58840 := by
  intro p hp
  have h : env58840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58839_58840 : H12AffineEnvironment.transform 4 17 env58839 = env58840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58839 == env58840) = true)

def env58841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,80,479,12556,5441,1025,80,2097152,32,8297,511,8329,8248,5393,4176,12637,805,1136,2101360,256,2101508,12556,512]

theorem envBound58841 : H12AffineFastState.Bounded env58841 := by
  intro p hp
  have h : env58841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58830_58841 : H12AffineEnvironment.transform 10 513 env58830 = env58841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58830 == env58841) = true)

theorem identity58841 : scanCanonicalize (H12AffineFastState.compose env58841 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound58841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,8192,1905,80,479,9772,609,1025,80,2097152,32,8297,511,8329,8248,561,1904,9853,805,1136,2099024,256,2098724,9772,512]

theorem envBound58842 : H12AffineFastState.Bounded env58842 := by
  intro p hp
  have h : env58842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58841_58842 : H12AffineEnvironment.transform 11 1824 env58841 = env58842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env58841 == env58842) = true)

def env58843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,536,1905,80,479,1076,609,1025,80,2097152,32,625,511,657,544,561,1904,1125,805,1136,2099024,256,2098724,1076,512]

theorem envBound58843 : H12AffineFastState.Bounded env58843 := by
  intro p hp
  have h : env58843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58842_58843 : H12AffineEnvironment.transform 12 536 env58842 = env58843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58842 == env58843) = true)

theorem identity58843 : scanCanonicalize (H12AffineFastState.compose env58843 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound58843 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,536,1905,80,479,1076,609,1025,80,1029,32,625,511,657,544,561,1904,1125,805,1136,853,256,545,1076,512]

theorem envBound58844 : H12AffineFastState.Bounded env58844 := by
  intro p hp
  have h : env58844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58843_58844 : H12AffineEnvironment.transform 20 1029 env58843 = env58844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env58843 == env58844) = true)

theorem identity58844 : scanCanonicalize (H12AffineFastState.compose env58844 (packedSelected [4,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58844 : packedSelected [4,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58845 : List Nat := [2,4,8,16,32,64,128,117,512,1024,513,1621,536,1540,80,170,1076,609,1025,80,1029,32,625,138,657,544,561,1541,1125,592,1136,544,117,545,1076,512]

theorem envBound58845 : H12AffineFastState.Bounded env58845 := by
  intro p hp
  have h : env58845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58844_58845 : H12AffineEnvironment.transform 7 117 env58844 = env58845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58844 == env58845) = true)

theorem identity58845 : scanCanonicalize (H12AffineFastState.compose env58845 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58845 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58846 : List Nat := [2,4,8,16,32,64,128,117,0,1024,1,1109,24,1028,80,170,1076,97,1025,80,1029,32,113,138,145,32,49,1029,1125,80,1136,32,117,33,1076,0]

theorem envBound58846 : H12AffineFastState.Bounded env58846 := by
  intro p hp
  have h : env58846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58845_58846 : H12AffineEnvironment.transform 8 0 env58845 = env58846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58845 == env58846) = true)

def env58847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,537,1905,80,479,1077,609,1025,80,2097152,32,624,511,656,545,561,1904,1124,805,1136,2099024,256,2098724,1077,512]

theorem envBound58847 : H12AffineFastState.Bounded env58847 := by
  intro p hp
  have h : env58847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58842_58847 : H12AffineEnvironment.transform 12 537 env58842 = env58847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58842 == env58847) = true)

theorem identity58847 : scanCanonicalize (H12AffineFastState.compose env58847 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1393) := by decide +kernel

theorem selectedBound58847 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,537,1905,80,479,1077,609,1025,80,1393,32,624,511,656,545,561,1904,1124,805,1136,545,256,853,1077,512]

theorem envBound58848 : H12AffineFastState.Bounded env58848 := by
  intro p hp
  have h : env58848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58847_58848 : H12AffineEnvironment.transform 20 1393 env58847 = env58848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1393 env58847 == env58848) = true)

theorem identity58848 : scanCanonicalize (H12AffineFastState.compose env58848 (packedSelected [0,3,5,7,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

end H12CloudChart0