import H12CloudChart0Data207

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound52656 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,13388,10281,1024,8541,4160,32,16,73737,8193,65,2049,5393,4097,10281,1365,33,256,33,5457,74251]

theorem envBound52657 : H12AffineFastState.Bounded env52657 := by
  intro p hp
  have h : env52657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52656_52657 : H12AffineEnvironment.transform 14 8540 env52656 = env52657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52656 == env52657) = true)

theorem identity52657 : scanCanonicalize (H12AffineFastState.compose env52657 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound52657 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,2,13388,10281,1024,8541,4160,32,16,8203,8193,65,2049,5393,4097,10281,1365,33,256,33,5457,8713]

theorem envBound52658 : H12AffineFastState.Bounded env52658 := by
  intro p hp
  have h : env52658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52657_52658 : H12AffineEnvironment.transform 15 2 env52657 = env52658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env52657 == env52658) = true)

theorem identity52658 : scanCanonicalize (H12AffineFastState.compose env52658 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52658 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env52659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,2,5392,2421,1024,1,4160,32,16,343,349,65,2049,5393,4097,2421,1365,33,256,33,5457,853]

theorem envBound52659 : H12AffineFastState.Bounded env52659 := by
  intro p hp
  have h : env52659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52658_52659 : H12AffineEnvironment.transform 12 348 env52658 = env52659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52658 == env52659) = true)

theorem identity52659 : scanCanonicalize (H12AffineFastState.compose env52659 (packedSelected [0,2,7,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52659 : packedSelected [0,2,7,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52660 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,2,5392,2340,1024,1,4113,32,16,262,268,16,2049,5393,4097,2340,1284,33,256,33,5376,772]

theorem envBound52660 : H12AffineFastState.Bounded env52660 := by
  intro p hp
  have h : env52660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52659_52660 : H12AffineEnvironment.transform 5 17 env52659 = env52660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52659 == env52660) = true)

theorem identity52660 : scanCanonicalize (H12AffineFastState.compose env52660 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3361) := by decide +kernel

theorem selectedBound52660 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52661 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3361,269,2080,0,2,2097,2340,1024,1,3376,32,16,262,268,16,2049,2096,3360,2340,1284,33,256,33,2081,772]

theorem envBound52661 : H12AffineFastState.Bounded env52661 := by
  intro p hp
  have h : env52661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52660_52661 : H12AffineEnvironment.transform 11 3361 env52660 = env52661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3361 env52660 == env52661) = true)

theorem identity52661 : scanCanonicalize (H12AffineFastState.compose env52661 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52661 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52662 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2324,269,2080,0,2,2097,2340,53,1,2309,32,16,262,268,16,2049,2096,2325,2340,305,33,256,33,2081,772]

theorem envBound52662 : H12AffineFastState.Bounded env52662 := by
  intro p hp
  have h : env52662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52661_52662 : H12AffineEnvironment.transform 9 53 env52661 = env52662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52661 == env52662) = true)

theorem identity52662 : scanCanonicalize (H12AffineFastState.compose env52662 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound52662 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52663 : List Nat := [2,4,8,16,32,17,9,256,512,53,260,16,269,292,0,2,309,32,53,1,1,32,16,262,268,16,261,308,17,32,305,33,256,33,293,772]

theorem envBound52663 : H12AffineFastState.Bounded env52663 := by
  intro p hp
  have h : env52663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52662_52663 : H12AffineEnvironment.transform 10 260 env52662 = env52663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env52662 == env52663) = true)

theorem identity52663 : scanCanonicalize (H12AffineFastState.compose env52663 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52663 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env52664 : List Nat := [2,4,8,16,1,17,9,256,512,20,260,16,269,261,0,2,276,1,20,1,1,1,16,262,268,16,261,277,17,1,272,0,256,0,260,772]

theorem envBound52664 : H12AffineFastState.Bounded env52664 := by
  intro p hp
  have h : env52664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52663_52664 : H12AffineEnvironment.transform 4 1 env52663 = env52664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52663 == env52664) = true)

theorem identity52664 : scanCanonicalize (H12AffineFastState.compose env52664 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52664 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env52665 : List Nat := [2,4,8,16,1,17,9,256,16,20,260,16,269,261,0,2,276,1,20,1,1,1,16,262,268,16,261,277,17,1,272,0,256,0,260,276]

theorem envBound52665 : H12AffineFastState.Bounded env52665 := by
  intro p hp
  have h : env52665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52664_52665 : H12AffineEnvironment.transform 8 16 env52664 = env52665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52664 == env52665) = true)

theorem identity52665 : scanCanonicalize (H12AffineFastState.compose env52665 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52665 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52666 : List Nat := [2,4,8,16,1,17,9,5,16,20,1,16,8,0,0,2,17,1,20,1,1,1,16,3,9,16,0,16,17,1,21,0,5,0,1,17]

theorem envBound52666 : H12AffineFastState.Bounded env52666 := by
  intro p hp
  have h : env52666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52665_52666 : H12AffineEnvironment.transform 7 5 env52665 = env52666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52665 == env52666) = true)

theorem identity52666 : scanCanonicalize (H12AffineFastState.compose env52666 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52667 : List Nat := [2,4,8,1,1,0,9,5,1,5,1,1,8,0,0,2,0,1,5,1,1,1,1,3,9,1,0,1,0,1,4,0,5,0,1,0]

theorem envBound52667 : H12AffineFastState.Bounded env52667 := by
  intro p hp
  have h : env52667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52666_52667 : H12AffineEnvironment.transform 3 1 env52666 = env52667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52666 == env52667) = true)

theorem identity52667 : scanCanonicalize (H12AffineFastState.compose env52667 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52668 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,1,2,0,0,2,0,1,5,1,1,1,1,3,3,1,0,1,0,1,4,0,5,0,1,0]

theorem envBound52668 : H12AffineFastState.Bounded env52668 := by
  intro p hp
  have h : env52668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52667_52668 : H12AffineEnvironment.transform 2 2 env52667 = env52668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52667 == env52668) = true)

def env52669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56572,1024,32769,58516,62588,62660,98780,8328,65,2185,57797,17664,32040,61704,62708,256,21792,46212,120543]

theorem envBound52669 : H12AffineFastState.Bounded env52669 := by
  intro p hp
  have h : env52669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52645_52669 : H12AffineEnvironment.transform 16 38161 env52645 = env52669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52645 == env52669) = true)

def env52670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35324,1024,32769,45460,41340,41412,98780,8328,65,2185,46277,4096,10280,41992,41460,256,32,46212,99295]

theorem envBound52670 : H12AffineFastState.Bounded env52670 := by
  intro p hp
  have h : env52670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52669_52670 : H12AffineEnvironment.transform 13 5376 env52669 = env52670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52669 == env52670) = true)

theorem identity52670 : scanCanonicalize (H12AffineFastState.compose env52670 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound52670 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,10281,1024,8660,4161,169,17,73737,8328,65,2185,5392,4096,10280,1501,33,256,32,5457,74250]

theorem envBound52671 : H12AffineFastState.Bounded env52671 := by
  intro p hp
  have h : env52671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52670_52671 : H12AffineEnvironment.transform 14 8661 env52670 = env52671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env52670 == env52671) = true)

theorem identity52671 : scanCanonicalize (H12AffineFastState.compose env52671 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound52671 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,81,65536,5440,2477,1024,80,4161,169,17,65933,268,65,2185,5392,4096,2476,1501,33,256,32,5457,66446]

theorem envBound52672 : H12AffineFastState.Bounded env52672 := by
  intro p hp
  have h : env52672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52671_52672 : H12AffineEnvironment.transform 12 388 env52671 = env52672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env52671 == env52672) = true)

theorem identity52672 : scanCanonicalize (H12AffineFastState.compose env52672 (packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound52672 : packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env52673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,81,478,5440,2477,1024,80,4161,169,17,83,268,65,2185,5392,4096,2476,1501,33,256,32,5457,592]

theorem envBound52673 : H12AffineFastState.Bounded env52673 := by
  intro p hp
  have h : env52673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52672_52673 : H12AffineEnvironment.transform 15 478 env52672 = env52673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env52672 == env52673) = true)

theorem identity52673 : scanCanonicalize (H12AffineFastState.compose env52673 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52673 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env52674 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,399,5393,2477,1024,1,4112,169,17,2,268,16,2185,5392,4096,2476,1420,33,256,32,5376,513]

theorem envBound52674 : H12AffineFastState.Bounded env52674 := by
  intro p hp
  have h : env52674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52673_52674 : H12AffineEnvironment.transform 5 17 env52673 = env52674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52673 == env52674) = true)

theorem identity52674 : scanCanonicalize (H12AffineFastState.compose env52674 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound52674 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52675 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,539,388,1819,0,399,1802,2477,1024,1,523,169,17,2,268,16,2185,1803,539,2476,1420,33,256,32,1819,513]

theorem envBound52675 : H12AffineFastState.Bounded env52675 := by
  intro p hp
  have h : env52675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52674_52675 : H12AffineEnvironment.transform 11 539 env52674 = env52675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env52674 == env52675) = true)

theorem identity52675 : scanCanonicalize (H12AffineFastState.compose env52675 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound52675 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env52676 : List Nat := [2,4,8,16,32,17,128,256,10,1024,2048,17,388,1297,0,399,1280,2477,1024,1,1,169,17,2,268,16,2185,1281,17,2476,1420,33,256,32,1297,11]

theorem envBound52676 : H12AffineFastState.Bounded env52676 := by
  intro p hp
  have h : env52676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52675_52676 : H12AffineEnvironment.transform 8 10 env52675 = env52676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env52675 == env52676) = true)

theorem identity52676 : scanCanonicalize (H12AffineFastState.compose env52676 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound52676 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52677 : List Nat := [2,4,8,16,32,17,128,256,10,1024,292,17,388,1297,0,399,1280,137,1024,1,1,169,17,2,268,16,429,1281,17,136,1420,33,256,32,1297,11]

theorem envBound52677 : H12AffineFastState.Bounded env52677 := by
  intro p hp
  have h : env52677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52676_52677 : H12AffineEnvironment.transform 10 292 env52676 = env52677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env52676 == env52677) = true)

theorem identity52677 : scanCanonicalize (H12AffineFastState.compose env52677 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound52677 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52678 : List Nat := [2,4,8,16,32,17,128,256,10,189,292,17,388,428,0,399,445,137,189,1,1,169,17,2,268,16,429,444,17,136,305,33,256,32,428,11]

theorem envBound52678 : H12AffineFastState.Bounded env52678 := by
  intro p hp
  have h : env52678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52677_52678 : H12AffineEnvironment.transform 9 189 env52677 = env52678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env52677 == env52678) = true)

theorem identity52678 : scanCanonicalize (H12AffineFastState.compose env52678 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52678 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52679 : List Nat := [2,4,8,16,0,17,128,256,10,157,260,17,388,396,0,399,413,137,157,1,1,137,17,2,268,16,397,412,17,136,273,1,256,0,396,11]

theorem envBound52679 : H12AffineFastState.Bounded env52679 := by
  intro p hp
  have h : env52679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52678_52679 : H12AffineEnvironment.transform 4 0 env52678 = env52679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52678 == env52679) = true)

theorem identity52679 : scanCanonicalize (H12AffineFastState.compose env52679 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52679 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env52680 : List Nat := [2,4,8,16,0,17,128,4,10,157,0,17,128,136,0,139,153,137,157,1,1,137,17,2,8,16,137,152,17,136,21,1,4,0,136,11]

theorem envBound52680 : H12AffineFastState.Bounded env52680 := by
  intro p hp
  have h : env52680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52679_52680 : H12AffineEnvironment.transform 7 4 env52679 = env52680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52679 == env52680) = true)

theorem identity52680 : scanCanonicalize (H12AffineFastState.compose env52680 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52681 : List Nat := [2,4,8,16,0,17,9,4,10,20,0,17,9,1,0,2,16,0,20,1,1,0,17,2,8,16,0,17,17,1,21,1,4,0,1,11]

theorem envBound52681 : H12AffineFastState.Bounded env52681 := by
  intro p hp
  have h : env52681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52680_52681 : H12AffineEnvironment.transform 6 9 env52680 = env52681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52680 == env52681) = true)

theorem identity52681 : scanCanonicalize (H12AffineFastState.compose env52681 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound52681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52682 : List Nat := [2,4,6,16,0,17,7,4,4,20,0,17,7,1,0,2,16,0,20,1,1,0,17,2,6,16,0,17,17,1,21,1,4,0,1,5]

theorem envBound52682 : H12AffineFastState.Bounded env52682 := by
  intro p hp
  have h : env52682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52681_52682 : H12AffineEnvironment.transform 2 6 env52681 = env52682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env52681 == env52682) = true)

theorem identity52682 : scanCanonicalize (H12AffineFastState.compose env52682 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound52682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52683 : List Nat := [2,4,6,2,0,3,7,4,4,6,0,3,7,1,0,2,2,0,6,1,1,0,3,2,6,2,0,3,3,1,7,1,4,0,1,5]

theorem envBound52683 : H12AffineFastState.Bounded env52683 := by
  intro p hp
  have h : env52683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52682_52683 : H12AffineEnvironment.transform 3 2 env52682 = env52683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env52682 == env52683) = true)

def env52684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35325,1024,32769,45461,41341,41413,98780,8328,65,2185,46276,4097,10281,41993,41461,256,33,46212,99294]

theorem envBound52684 : H12AffineFastState.Bounded env52684 := by
  intro p hp
  have h : env52684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52669_52684 : H12AffineEnvironment.transform 13 5377 env52669 = env52684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52669 == env52684) = true)

theorem identity52684 : scanCanonicalize (H12AffineFastState.compose env52684 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52684 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,13388,10400,1024,8540,4296,32,152,73857,8328,65,2185,5529,4097,10281,1364,168,256,33,5593,74371]

theorem envBound52685 : H12AffineFastState.Bounded env52685 := by
  intro p hp
  have h : env52685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52684_52685 : H12AffineEnvironment.transform 14 8541 env52684 = env52685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52684 == env52685) = true)

theorem identity52685 : scanCanonicalize (H12AffineFastState.compose env52685 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound52685 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,13388,10400,1024,8540,4296,32,152,3,8328,65,2185,5529,4097,10281,1364,168,256,33,5593,513]

theorem envBound52686 : H12AffineFastState.Bounded env52686 := by
  intro p hp
  have h : env52686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52685_52686 : H12AffineEnvironment.transform 15 8322 env52685 = env52686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env52685 == env52686) = true)

theorem identity52686 : scanCanonicalize (H12AffineFastState.compose env52686 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound52686 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,217,262,5576,2340,1024,216,4296,32,152,3,268,65,2185,5529,4097,2477,1364,168,256,33,5593,513]

theorem envBound52687 : H12AffineFastState.Bounded env52687 := by
  intro p hp
  have h : env52687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52686_52687 : H12AffineEnvironment.transform 12 388 env52686 = env52687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env52686 == env52687) = true)

theorem identity52687 : scanCanonicalize (H12AffineFastState.compose env52687 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52687 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env52688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,262,5440,2340,1024,80,4160,32,16,3,268,65,2049,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound52688 : H12AffineFastState.Bounded env52688 := by
  intro p hp
  have h : env52688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52687_52688 : H12AffineEnvironment.transform 6 8 env52687 = env52688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52687 == env52688) = true)

theorem identity52688 : scanCanonicalize (H12AffineFastState.compose env52688 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound52688 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,821,4096,268,5377,81,262,5440,529,1024,80,4160,32,16,3,268,65,820,5393,4097,528,1364,32,256,33,5457,513]

theorem envBound52689 : H12AffineFastState.Bounded env52689 := by
  intro p hp
  have h : env52689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52688_52689 : H12AffineEnvironment.transform 10 821 env52688 = env52689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env52688 == env52689) = true)

theorem identity52689 : scanCanonicalize (H12AffineFastState.compose env52689 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52689 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52690 : List Nat := [2,4,8,16,32,64,8,5,512,1024,560,4096,9,5124,81,3,5189,529,1024,80,4160,32,16,3,9,65,561,5140,4097,528,1105,32,5,33,5204,513]

theorem envBound52690 : H12AffineFastState.Bounded env52690 := by
  intro p hp
  have h : env52690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52689_52690 : H12AffineEnvironment.transform 7 5 env52689 = env52690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52689 == env52690) = true)

theorem identity52690 : scanCanonicalize (H12AffineFastState.compose env52690 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52690 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52691 : List Nat := [2,4,8,16,16,64,8,5,512,1024,512,4096,9,5124,81,3,5189,529,1024,80,4160,16,16,3,9,65,513,5140,4097,528,1105,16,5,17,5204,513]

theorem envBound52691 : H12AffineFastState.Bounded env52691 := by
  intro p hp
  have h : env52691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52690_52691 : H12AffineEnvironment.transform 4 16 env52690 = env52691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52690 == env52691) = true)

theorem identity52691 : scanCanonicalize (H12AffineFastState.compose env52691 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound52691 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env52692 : List Nat := [2,4,8,16,16,64,8,5,512,69,512,4096,9,4161,81,3,4096,529,69,80,4160,16,16,3,9,65,513,4177,4097,528,20,16,5,17,4113,513]

theorem envBound52692 : H12AffineFastState.Bounded env52692 := by
  intro p hp
  have h : env52692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52691_52692 : H12AffineEnvironment.transform 9 69 env52691 = env52692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env52691 == env52692) = true)

theorem identity52692 : scanCanonicalize (H12AffineFastState.compose env52692 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound52692 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52693 : List Nat := [2,4,8,16,16,1,8,5,512,4,512,4096,9,4096,16,3,4096,529,4,17,4097,16,16,3,9,0,513,4112,4097,528,20,16,5,17,4113,513]

theorem envBound52693 : H12AffineFastState.Bounded env52693 := by
  intro p hp
  have h : env52693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52692_52693 : H12AffineEnvironment.transform 5 1 env52692 = env52693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env52692 == env52693) = true)

theorem identity52693 : scanCanonicalize (H12AffineFastState.compose env52693 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound52693 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env52694 : List Nat := [2,4,8,16,16,1,8,5,512,4,512,529,9,529,16,3,529,529,4,17,528,16,16,3,9,0,513,513,528,528,20,16,5,17,512,513]

theorem envBound52694 : H12AffineFastState.Bounded env52694 := by
  intro p hp
  have h : env52694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52693_52694 : H12AffineEnvironment.transform 11 529 env52693 = env52694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env52693 == env52694) = true)

def env52695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272513,441641,98780,8328,65,316532,436264,17664,32040,440549,156132,256,21792,46212,499506]

theorem envBound52695 : H12AffineFastState.Bounded env52695 := by
  intro p hp
  have h : env52695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52643_52695 : H12AffineEnvironment.transform 21 272513 env52643 = env52695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52643 == env52695) = true)

theorem identity52695 : scanCanonicalize (H12AffineFastState.compose env52695 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound52695 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416173,272513,412157,95496,8328,65,270496,417020,17664,32040,412721,156132,256,21792,16464,486374]

theorem envBound52696 : H12AffineFastState.Bounded env52696 := by
  intro p hp
  have h : env52696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52695_52696 : H12AffineEnvironment.transform 14 29908 env52695 = env52696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env52695 == env52696) = true)

def env52697 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272513,412077,95496,8328,17,270496,416940,17664,32040,412721,156084,256,21792,16384,486326]

theorem envBound52697 : H12AffineFastState.Bounded env52697 := by
  intro p hp
  have h : env52697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52696_52697 : H12AffineEnvironment.transform 5 16 env52696 = env52697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52696 == env52697) = true)

theorem identity52697 : scanCanonicalize (H12AffineFastState.compose env52697 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 70814) := by decide +kernel

theorem selectedBound52697 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env52698 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,262144,1024,29829,347443,272513,351539,95496,8328,17,270496,346162,17664,32040,350383,95530,256,21792,16384,294696]

theorem envBound52698 : H12AffineFastState.Bounded env52698 := by
  intro p hp
  have h : env52698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52697_52698 : H12AffineEnvironment.transform 16 70814 env52697 = env52698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70814 env52697 == env52698) = true)

theorem identity52698 : scanCanonicalize (H12AffineFastState.compose env52698 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound52698 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env52699 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,97326,1024,29829,12573,87215,8477,95496,8328,17,89230,13340,17664,32040,9345,95530,256,21792,16384,66310]

theorem envBound52699 : H12AffineFastState.Bounded env52699 := by
  intro p hp
  have h : env52699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52698_52699 : H12AffineEnvironment.transform 17 97326 env52698 = env52699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env52698 == env52699) = true)

theorem identity52699 : scanCanonicalize (H12AffineFastState.compose env52699 (packedSelected [0,1,3,4,7,17,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52699 : packedSelected [0,1,3,4,7,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env52700 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,13461,23589,1024,29829,12573,29860,8477,21763,8328,17,31877,13340,17664,32040,9345,21793,256,21792,16384,8973]

theorem envBound52700 : H12AffineFastState.Bounded env52700 := by
  intro p hp
  have h : env52700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52699_52700 : H12AffineEnvironment.transform 15 8203 env52699 = env52700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52699 == env52700) = true)

theorem identity52700 : scanCanonicalize (H12AffineFastState.compose env52700 (packedSelected [1,2,3,4,5,7,8,11,12,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 7700) := by decide +kernel

theorem selectedBound52700 : packedSelected [1,2,3,4,5,7,8,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52701 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,7700,10896,8203,13461,561,1024,10897,12573,10928,8477,2839,8328,17,8849,13340,6932,9020,9345,2869,256,2868,7700,8973]

theorem envBound52701 : H12AffineFastState.Bounded env52701 := by
  intro p hp
  have h : env52701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52700_52701 : H12AffineEnvironment.transform 13 7700 env52700 = env52701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7700 env52700 == env52701) = true)

theorem identity52701 : scanCanonicalize (H12AffineFastState.compose env52701 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52701 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52702 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,7700,2972,263,5529,561,1024,2973,4113,3004,17,2839,388,17,925,5392,6932,560,1421,2869,256,2868,7700,513]

theorem envBound52702 : H12AffineFastState.Bounded env52702 := by
  intro p hp
  have h : env52702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52701_52702 : H12AffineEnvironment.transform 12 268 env52701 = env52702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52701 == env52702) = true)

theorem identity52702 : scanCanonicalize (H12AffineFastState.compose env52702 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52702 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52703 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,268,7700,2869,263,5424,561,1024,2868,4113,2837,17,2839,301,17,820,5392,6932,560,1316,2869,256,2868,7700,513]

theorem envBound52703 : H12AffineFastState.Bounded env52703 := by
  intro p hp
  have h : env52703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52702_52703 : H12AffineEnvironment.transform 6 41 env52702 = env52703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52702 == env52703) = true)

theorem identity52703 : scanCanonicalize (H12AffineFastState.compose env52703 (packedSelected [1,2,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound52703 : packedSelected [1,2,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env52704 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,528,268,3076,2869,263,1824,561,1024,2868,513,2837,17,2839,301,17,820,1792,2308,560,1316,2869,256,2868,3076,513]

theorem envBound52704 : H12AffineFastState.Bounded env52704 := by
  intro p hp
  have h : env52704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52703_52704 : H12AffineEnvironment.transform 11 528 env52703 = env52704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env52703 == env52704) = true)

theorem identity52704 : scanCanonicalize (H12AffineFastState.compose env52704 (packedSelected [1,2,3,4,5,7,8,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52704 : packedSelected [1,2,3,4,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env52705 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,528,268,3076,2837,263,1792,529,1024,2836,513,2837,17,2839,269,17,788,1792,2308,528,1284,2837,256,2836,3076,513]

theorem envBound52705 : H12AffineFastState.Bounded env52705 := by
  intro p hp
  have h : env52705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52704_52705 : H12AffineEnvironment.transform 4 0 env52704 = env52705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52704 == env52705) = true)

theorem identity52705 : scanCanonicalize (H12AffineFastState.compose env52705 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound52705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52706 : List Nat := [2,4,8,16,0,16,9,256,512,1024,789,528,268,1809,0,263,1792,529,1024,1,513,0,17,2,269,17,788,1792,529,528,1284,0,256,1,1809,513]

theorem envBound52706 : H12AffineFastState.Bounded env52706 := by
  intro p hp
  have h : env52706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52705_52706 : H12AffineEnvironment.transform 10 789 env52705 = env52706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env52705 == env52706) = true)

theorem identity52706 : scanCanonicalize (H12AffineFastState.compose env52706 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52707 : List Nat := [2,4,8,16,0,16,9,256,0,1024,277,16,268,1297,0,263,1280,17,1024,1,1,0,17,2,269,17,276,1280,17,16,1284,0,256,1,1297,1]

theorem envBound52707 : H12AffineFastState.Bounded env52707 := by
  intro p hp
  have h : env52707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52706_52707 : H12AffineEnvironment.transform 8 0 env52706 = env52707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52706 == env52707) = true)

theorem identity52707 : scanCanonicalize (H12AffineFastState.compose env52707 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52708 : List Nat := [2,4,8,11,0,11,9,256,0,1024,270,11,268,1290,0,263,1280,10,1024,1,1,0,10,2,269,10,271,1280,10,11,1284,0,256,1,1290,1]

theorem envBound52708 : H12AffineFastState.Bounded env52708 := by
  intro p hp
  have h : env52708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52707_52708 : H12AffineEnvironment.transform 3 11 env52707 = env52708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52707 == env52708) = true)

theorem identity52708 : scanCanonicalize (H12AffineFastState.compose env52708 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound52708 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52709 : List Nat := [2,4,8,11,0,11,9,256,0,256,270,11,268,10,0,263,0,10,256,1,1,0,10,2,269,10,271,0,10,11,4,0,256,1,10,1]

theorem envBound52709 : H12AffineFastState.Bounded env52709 := by
  intro p hp
  have h : env52709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52708_52709 : H12AffineEnvironment.transform 9 256 env52708 = env52709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env52708 == env52709) = true)

theorem identity52709 : scanCanonicalize (H12AffineFastState.compose env52709 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound52709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52710 : List Nat := [2,4,6,5,0,5,7,256,0,256,256,5,258,4,0,263,0,4,256,1,1,0,4,2,259,4,257,0,4,5,4,0,256,1,4,1]

theorem envBound52710 : H12AffineFastState.Bounded env52710 := by
  intro p hp
  have h : env52710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52709_52710 : H12AffineEnvironment.transform 2 6 env52709 = env52710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env52709 == env52710) = true)

theorem identity52710 : scanCanonicalize (H12AffineFastState.compose env52710 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound52710 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52711 : List Nat := [2,4,6,5,0,5,7,0,0,0,0,5,2,4,0,7,0,4,0,1,1,0,4,2,3,4,1,0,4,5,4,0,0,1,4,1]

theorem envBound52711 : H12AffineFastState.Bounded env52711 := by
  intro p hp
  have h : env52711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52710_52711 : H12AffineEnvironment.transform 7 0 env52710 = env52711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env52710 == env52711) = true)

theorem identity52711 : scanCanonicalize (H12AffineFastState.compose env52711 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52712 : List Nat := [2,2,0,3,0,3,1,0,0,0,0,3,2,2,0,1,0,2,0,1,1,0,2,2,3,2,1,0,2,3,2,0,0,1,2,1]

theorem envBound52712 : H12AffineFastState.Bounded env52712 := by
  intro p hp
  have h : env52712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52711_52712 : H12AffineEnvironment.transform 1 2 env52711 = env52712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52711 == env52712) = true)

theorem identity52712 : scanCanonicalize (H12AffineFastState.compose env52712 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52712 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52713 : List Nat := [1,1,0,0,0,0,1,0,0,0,0,0,1,1,0,1,0,1,0,1,1,0,1,1,0,1,1,0,1,0,1,0,0,1,1,1]

theorem envBound52713 : H12AffineFastState.Bounded env52713 := by
  intro p hp
  have h : env52713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52712_52713 : H12AffineEnvironment.transform 0 1 env52712 = env52713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52712 == env52713) = true)

def env52714 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272513,412076,95496,8328,16,270496,416941,17664,32040,412721,156085,256,21792,16385,486327]

theorem envBound52714 : H12AffineFastState.Bounded env52714 := by
  intro p hp
  have h : env52714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52696_52714 : H12AffineEnvironment.transform 5 17 env52696 = env52714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52696 == env52714) = true)

theorem identity52714 : scanCanonicalize (H12AffineFastState.compose env52714 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound52714 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env52715 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149813,1024,29828,4248,156084,153,95496,8328,16,158101,5528,17664,32040,1284,156085,256,21792,16385,74370]

theorem envBound52715 : H12AffineFastState.Bounded env52715 := by
  intro p hp
  have h : env52715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52714_52715 : H12AffineEnvironment.transform 17 149813 env52714 = env52715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env52714 == env52715) = true)

theorem identity52715 : scanCanonicalize (H12AffineFastState.compose env52715 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound52715 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env52716 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21646,131072,149813,1024,29828,4248,156084,153,8582,8328,16,158101,5528,17664,32040,1284,156085,256,21792,16385,30220]

theorem envBound52716 : H12AffineFastState.Bounded env52716 := by
  intro p hp
  have h : env52716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52715_52716 : H12AffineEnvironment.transform 15 21646 env52715 = env52716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env52715 == env52716) = true)

theorem identity52716 : scanCanonicalize (H12AffineFastState.compose env52716 (packedSelected [0,1,4,7,10,19,22,28] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound52716 : packedSelected [0,1,4,7,10,19,22,28] rootPS < 2^1333 := by decide +kernel

def env52717 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21646,16537,2476,1024,29828,4248,8493,153,8582,8328,16,10508,5528,17664,32040,1284,8492,256,21792,16385,30220]

theorem envBound52717 : H12AffineFastState.Bounded env52717 := by
  intro p hp
  have h : env52717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52716_52717 : H12AffineEnvironment.transform 16 16537 env52716 = env52717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env52716 == env52717) = true)

theorem identity52717 : scanCanonicalize (H12AffineFastState.compose env52717 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52717 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52718 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,21511,16400,2341,1024,29709,4113,8493,16,8463,8193,16,10508,5393,17664,32040,1284,8492,256,21792,16385,30220]

theorem envBound52718 : H12AffineFastState.Bounded env52718 := by
  intro p hp
  have h : env52718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52717_52718 : H12AffineEnvironment.transform 6 9 env52717 = env52718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52717 == env52718) = true)

theorem identity52718 : scanCanonicalize (H12AffineFastState.compose env52718 (packedSelected [3,7,8,9,10,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound52718 : packedSelected [3,7,8,9,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52719 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,2563,16384,24079,21511,16400,2341,1024,24078,4113,2862,16,2828,2562,16,783,5393,17664,22315,1284,2863,256,21792,16385,23567]

theorem envBound52719 : H12AffineFastState.Bounded env52719 := by
  intro p hp
  have h : env52719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52718_52719 : H12AffineEnvironment.transform 12 2563 env52718 = env52719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env52718 == env52719) = true)

theorem identity52719 : scanCanonicalize (H12AffineFastState.compose env52719 (packedSelected [1,2,3,4,7,10,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound52719 : packedSelected [1,2,3,4,7,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env52720 : List Nat := [2,4,8,16,32,17,9,256,512,1024,814,4096,301,16384,21793,21511,16400,523,1024,21792,4113,0,16,34,300,16,783,5393,17664,22315,1284,1,256,21792,16385,22305]

theorem envBound52720 : H12AffineFastState.Bounded env52720 := by
  intro p hp
  have h : env52720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52719_52720 : H12AffineEnvironment.transform 10 814 env52719 = env52720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env52719 == env52720) = true)

def env52721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound52721 : H12AffineFastState.Bounded env52721 := by
  intro p hp
  have h : env52721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52475_52721 : H12AffineEnvironment.transform 18 1025 env52475 = env52721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env52475 == env52721) = true)

theorem identity52721 : scanCanonicalize (H12AffineFastState.compose env52721 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833400) := by decide +kernel

theorem selectedBound52721 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833400,8328,65,6458873,8702324,10507600,8830976,2410984,12855352,257,297301,289008,2485822]

theorem envBound52722 : H12AffineFastState.Bounded env52722 := by
  intro p hp
  have h : env52722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52721_52722 : H12AffineEnvironment.transform 23 10833400 env52721 = env52722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833400 env52721 == env52722) = true)

def env52723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458873,8393984,10507600,8526964,2102684,12645452,257,21793,46212,2175562]

theorem envBound52723 : H12AffineFastState.Bounded env52723 := by
  intro p hp
  have h : env52723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52722_52723 : H12AffineEnvironment.transform 17 56436 env52722 = env52723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env52722 == env52723) = true)

def env52724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,4194304,8388608,8487372,8328,65,4365753,8393984,8406288,8526964,1500,12645452,257,21793,46212,74250]

theorem envBound52724 : H12AffineFastState.Bounded env52724 := by
  intro p hp
  have h : env52724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52723_52724 : H12AffineEnvironment.transform 20 4160 env52723 = env52724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52723 == env52724) = true)

def env52725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,8388608,8487372,8328,65,171417,8393984,8406288,8526964,1500,8451180,257,21793,46212,74250]

theorem envBound52725 : H12AffineFastState.Bounded env52725 := by
  intro p hp
  have h : env52725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52724_52725 : H12AffineEnvironment.transform 21 32 env52724 = env52725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52724 == env52725) = true)

def env52726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,152,98644,8328,65,171417,5528,17800,138476,1500,62708,257,21793,46212,74250]

theorem envBound52726 : H12AffineFastState.Bounded env52726 := by
  intro p hp
  have h : env52726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52725_52726 : H12AffineEnvironment.transform 22 152 env52725 = env52726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env52725 == env52726) = true)

theorem identity52726 : scanCanonicalize (H12AffineFastState.compose env52726 (packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound52726 : packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46157,56436,1025,32769,4160,32,152,98644,8328,65,10708,5528,17800,43169,1500,62708,257,21793,46212,74250]

theorem envBound52727 : H12AffineFastState.Bounded env52727 := by
  intro p hp
  have h : env52727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52726_52727 : H12AffineEnvironment.transform 16 46157 env52726 = env52727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env52726 == env52727) = true)

def env52728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46157,35188,1025,32769,4160,32,152,98644,8328,65,10708,5528,4232,43169,1500,41460,257,33,46212,74250]

theorem envBound52728 : H12AffineFastState.Bounded env52728 := by
  intro p hp
  have h : env52728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52727_52728 : H12AffineEnvironment.transform 13 5376 env52727 = env52728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52727 == env52728) = true)

theorem identity52728 : scanCanonicalize (H12AffineFastState.compose env52728 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound52728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5528,10401,1025,8660,4160,32,152,73857,8328,65,10708,5528,4232,2420,1500,33,257,33,5457,74250]

theorem envBound52729 : H12AffineFastState.Bounded env52729 := by
  intro p hp
  have h : env52729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52728_52729 : H12AffineEnvironment.transform 14 8661 env52728 = env52729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env52728 == env52729) = true)

def env52730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,46157,35189,1025,32769,4160,32,152,98644,8328,65,10708,5528,4233,43169,1500,41461,257,32,46212,74250]

theorem envBound52730 : H12AffineFastState.Bounded env52730 := by
  intro p hp
  have h : env52730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52727_52730 : H12AffineEnvironment.transform 13 5377 env52727 = env52730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52727 == env52730) = true)

theorem identity52730 : scanCanonicalize (H12AffineFastState.compose env52730 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52730 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,5393,10281,1025,8541,4160,32,152,73736,8328,65,10708,5528,4233,2557,1500,169,257,32,5592,74250]

theorem envBound52731 : H12AffineFastState.Bounded env52731 := by
  intro p hp
  have h : env52731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52730_52731 : H12AffineEnvironment.transform 14 8540 env52730 = env52731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52730 == env52731) = true)

theorem identity52731 : scanCanonicalize (H12AffineFastState.compose env52731 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52731 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env52732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,65536,5393,2421,1025,1,4160,32,152,65876,468,65,2184,5528,4233,2557,1500,169,257,32,5592,66390]

theorem envBound52732 : H12AffineFastState.Bounded env52732 := by
  intro p hp
  have h : env52732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52731_52732 : H12AffineEnvironment.transform 12 348 env52731 = env52732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52731 == env52732) = true)

theorem identity52732 : scanCanonicalize (H12AffineFastState.compose env52732 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound52732 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env52733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,342,5393,2421,1025,1,4160,32,152,2,468,65,2184,5528,4233,2557,1500,169,257,32,5592,512]

theorem envBound52733 : H12AffineFastState.Bounded env52733 := by
  intro p hp
  have h : env52733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52732_52733 : H12AffineEnvironment.transform 15 342 env52732 = env52733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env52732 == env52733) = true)

theorem identity52733 : scanCanonicalize (H12AffineFastState.compose env52733 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52733 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5393,2421,1025,1,4160,32,16,2,348,65,2048,5392,4097,2421,1364,33,257,32,5456,512]

theorem envBound52734 : H12AffineFastState.Bounded env52734 := by
  intro p hp
  have h : env52734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52733_52734 : H12AffineEnvironment.transform 6 8 env52733 = env52734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52733 == env52734) = true)

theorem identity52734 : scanCanonicalize (H12AffineFastState.compose env52734 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound52734 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52735 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,4096,348,4372,0,342,4356,2421,20,1,4160,32,16,2,348,65,2048,4357,4097,2421,321,33,257,32,4421,512]

theorem envBound52735 : H12AffineFastState.Bounded env52735 := by
  intro p hp
  have h : env52735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52734_52735 : H12AffineEnvironment.transform 9 21 env52734 = env52735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52734 == env52735) = true)

theorem identity52735 : scanCanonicalize (H12AffineFastState.compose env52735 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound52735 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52736 : List Nat := [2,4,8,16,32,48,8,256,512,21,2048,4096,300,4372,0,294,4356,2309,20,1,4144,32,16,2,300,49,2048,4357,4097,2309,305,33,257,32,4405,512]

theorem envBound52736 : H12AffineFastState.Bounded env52736 := by
  intro p hp
  have h : env52736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52735_52736 : H12AffineEnvironment.transform 5 48 env52735 = env52736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env52735 == env52736) = true)

theorem identity52736 : scanCanonicalize (H12AffineFastState.compose env52736 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52736 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52737 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,268,4372,0,262,4356,2309,20,1,4112,0,16,2,268,17,2048,4357,4097,2309,273,1,257,0,4373,512]

theorem envBound52737 : H12AffineFastState.Bounded env52737 := by
  intro p hp
  have h : env52737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52736_52737 : H12AffineEnvironment.transform 4 0 env52736 = env52737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52736 == env52737) = true)

theorem identity52737 : scanCanonicalize (H12AffineFastState.compose env52737 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound52737 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52738 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,17,268,261,0,262,277,2309,20,1,1,0,16,2,268,17,2048,276,16,2309,273,1,257,0,260,512]

theorem envBound52738 : H12AffineFastState.Bounded env52738 := by
  intro p hp
  have h : env52738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52737_52738 : H12AffineEnvironment.transform 11 17 env52737 = env52738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env52737 == env52738) = true)

theorem identity52738 : scanCanonicalize (H12AffineFastState.compose env52738 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound52738 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52739 : List Nat := [2,4,8,16,0,16,8,256,512,21,261,17,268,261,0,262,277,0,20,1,1,0,16,2,268,17,261,276,16,0,273,1,257,0,260,512]

theorem envBound52739 : H12AffineFastState.Bounded env52739 := by
  intro p hp
  have h : env52739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52738_52739 : H12AffineEnvironment.transform 10 261 env52738 = env52739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env52738 == env52739) = true)

theorem identity52739 : scanCanonicalize (H12AffineFastState.compose env52739 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52739 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52740 : List Nat := [2,4,8,16,0,16,8,5,512,21,0,17,9,0,0,3,16,0,20,1,1,0,16,2,9,17,0,17,16,0,20,1,4,0,1,512]

theorem envBound52740 : H12AffineFastState.Bounded env52740 := by
  intro p hp
  have h : env52740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52739_52740 : H12AffineEnvironment.transform 7 5 env52739 = env52740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52739 == env52740) = true)

def env52741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,153,98645,8328,65,171417,5529,17801,138477,1500,62709,257,21793,46212,74250]

theorem envBound52741 : H12AffineFastState.Bounded env52741 := by
  intro p hp
  have h : env52741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52725_52741 : H12AffineEnvironment.transform 22 153 env52725 = env52741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env52725 == env52741) = true)

def env52742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1025,32769,4160,32,153,98645,8328,65,171417,5529,4233,138477,1500,41461,257,33,46212,74250]

theorem envBound52742 : H12AffineFastState.Bounded env52742 := by
  intro p hp
  have h : env52742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52741_52742 : H12AffineEnvironment.transform 13 5376 env52741 = env52742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52741 == env52742) = true)

theorem identity52742 : scanCanonicalize (H12AffineFastState.compose env52742 (packedSelected [5,8,11,18,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52742 : packedSelected [5,8,11,18,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env52743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,131072,35188,1025,32769,4160,32,153,41310,8328,65,171417,5529,4233,138477,1500,41461,257,33,46212,513]

theorem envBound52743 : H12AffineFastState.Bounded env52743 := by
  intro p hp
  have h : env52743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52742_52743 : H12AffineEnvironment.transform 15 8203 env52742 = env52743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52742 == env52743) = true)

theorem identity52743 : scanCanonicalize (H12AffineFastState.compose env52743 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound52743 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env52744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,38160,35188,1025,32769,4160,32,153,41310,8328,65,2185,5529,4233,35325,1500,41461,257,33,46212,513]

theorem envBound52744 : H12AffineFastState.Bounded env52744 := by
  intro p hp
  have h : env52744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52743_52744 : H12AffineEnvironment.transform 16 38160 env52743 = env52744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52743 == env52744) = true)

theorem identity52744 : scanCanonicalize (H12AffineFastState.compose env52744 (packedSelected [1,2,4,5,6,8,9,14,16,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52744 : packedSelected [1,2,4,5,6,8,9,14,16,24] rootPS < 2^1333 := by decide +kernel

def env52745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,32768,342,38160,35188,1025,32769,4160,32,153,32771,469,65,2185,5529,4233,35325,1500,32936,257,33,38361,513]

theorem envBound52745 : H12AffineFastState.Bounded env52745 := by
  intro p hp
  have h : env52745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52744_52745 : H12AffineEnvironment.transform 12 349 env52744 = env52745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52744 == env52745) = true)

theorem identity52745 : scanCanonicalize (H12AffineFastState.compose env52745 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52745 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1025,1,4160,32,153,3,469,65,2185,5529,4233,2557,1500,168,257,33,5593,513]

theorem envBound52746 : H12AffineFastState.Bounded env52746 := by
  intro p hp
  have h : env52746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52745_52746 : H12AffineEnvironment.transform 14 0 env52745 = env52746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52745 == env52746) = true)

theorem identity52746 : scanCanonicalize (H12AffineFastState.compose env52746 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52746 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1025,1,4160,32,17,3,349,65,2049,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound52747 : H12AffineFastState.Bounded env52747 := by
  intro p hp
  have h : env52747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52746_52747 : H12AffineEnvironment.transform 6 8 env52746 = env52747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52746 == env52747) = true)

theorem identity52747 : scanCanonicalize (H12AffineFastState.compose env52747 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52747 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52748 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,349,4404,0,342,4388,2420,53,1,4160,32,17,3,349,65,2049,4389,4097,2421,352,32,257,33,4453,513]

theorem envBound52748 : H12AffineFastState.Bounded env52748 := by
  intro p hp
  have h : env52748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52747_52748 : H12AffineEnvironment.transform 9 52 env52747 = env52748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52747 == env52748) = true)

theorem identity52748 : scanCanonicalize (H12AffineFastState.compose env52748 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52749 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,0,262,4388,2340,53,1,4112,32,17,3,269,17,2049,4389,4097,2341,304,32,257,33,4405,513]

theorem envBound52749 : H12AffineFastState.Bounded env52749 := by
  intro p hp
  have h : env52749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52748_52749 : H12AffineEnvironment.transform 5 16 env52748 = env52749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52748 == env52749) = true)

theorem identity52749 : scanCanonicalize (H12AffineFastState.compose env52749 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52749 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52750 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,4096,9,4144,0,2,4128,2080,53,1,4112,32,17,3,9,17,2049,4129,4097,2081,52,32,5,33,4145,513]

theorem envBound52750 : H12AffineFastState.Bounded env52750 := by
  intro p hp
  have h : env52750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52749_52750 : H12AffineEnvironment.transform 7 4 env52749 = env52750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52749 == env52750) = true)

theorem identity52750 : scanCanonicalize (H12AffineFastState.compose env52750 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound52750 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52751 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,2609,9,2561,0,2,2577,2080,53,1,2593,32,17,3,9,17,2049,2576,2608,2081,52,32,5,33,2560,513]

theorem envBound52751 : H12AffineFastState.Bounded env52751 := by
  intro p hp
  have h : env52751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52750_52751 : H12AffineEnvironment.transform 11 2609 env52750 = env52751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env52750 == env52751) = true)

theorem identity52751 : scanCanonicalize (H12AffineFastState.compose env52751 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound52751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52752 : List Nat := [2,4,8,16,32,16,8,4,48,52,2048,2049,9,2097,0,2,2081,2080,53,1,2065,32,17,3,9,17,2049,2080,2048,2081,52,32,5,33,2096,49]

theorem envBound52752 : H12AffineFastState.Bounded env52752 := by
  intro p hp
  have h : env52752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52751_52752 : H12AffineEnvironment.transform 8 48 env52751 = env52752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env52751 == env52752) = true)

theorem identity52752 : scanCanonicalize (H12AffineFastState.compose env52752 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound52752 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52753 : List Nat := [2,4,8,16,32,16,8,4,48,52,48,49,9,1,0,2,17,16,53,1,33,32,17,3,9,17,49,16,48,17,52,32,5,33,0,49]

theorem envBound52753 : H12AffineFastState.Bounded env52753 := by
  intro p hp
  have h : env52753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52752_52753 : H12AffineEnvironment.transform 10 48 env52752 = env52753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env52752 == env52753) = true)

theorem identity52753 : scanCanonicalize (H12AffineFastState.compose env52753 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52753 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52754 : List Nat := [2,4,8,16,1,16,8,4,17,21,17,16,9,1,0,2,17,16,20,1,0,1,17,3,9,17,16,16,17,17,21,1,5,0,0,16]

theorem envBound52754 : H12AffineFastState.Bounded env52754 := by
  intro p hp
  have h : env52754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52753_52754 : H12AffineEnvironment.transform 4 1 env52753 = env52754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52753 == env52754) = true)

theorem identity52754 : scanCanonicalize (H12AffineFastState.compose env52754 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52755 : List Nat := [2,4,8,11,1,11,8,4,10,14,10,11,9,1,0,2,10,11,15,1,0,1,10,3,9,10,11,11,10,10,14,1,5,0,0,11]

theorem envBound52755 : H12AffineFastState.Bounded env52755 := by
  intro p hp
  have h : env52755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52754_52755 : H12AffineEnvironment.transform 3 11 env52754 = env52755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52754 == env52755) = true)

def env52756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1025,32769,4160,32,153,98645,8328,65,171417,5529,4232,138477,1500,41460,257,32,46212,74250]

theorem envBound52756 : H12AffineFastState.Bounded env52756 := by
  intro p hp
  have h : env52756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52741_52756 : H12AffineEnvironment.transform 13 5377 env52741 = env52756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52741 == env52756) = true)

theorem identity52756 : scanCanonicalize (H12AffineFastState.compose env52756 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52756 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1025,32769,4160,32,17,98645,8192,65,171281,5393,4096,138341,1364,41340,257,32,46092,74250]

theorem envBound52757 : H12AffineFastState.Bounded env52757 := by
  intro p hp
  have h : env52757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52756_52757 : H12AffineEnvironment.transform 6 8 env52756 = env52757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52756 == env52757) = true)

theorem identity52757 : scanCanonicalize (H12AffineFastState.compose env52757 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52757 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35189,1025,32769,4160,32,17,41310,8192,65,171281,5393,4096,138341,1364,41340,257,32,46092,513]

theorem envBound52758 : H12AffineFastState.Bounded env52758 := by
  intro p hp
  have h : env52758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52757_52758 : H12AffineEnvironment.transform 15 8203 env52757 = env52758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52757 == env52758) = true)

theorem identity52758 : scanCanonicalize (H12AffineFastState.compose env52758 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound52758 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,46157,35189,1025,32769,4160,32,17,41310,8192,65,10588,5393,4096,43048,1364,41340,257,32,46092,513]

theorem envBound52759 : H12AffineFastState.Bounded env52759 := by
  intro p hp
  have h : env52759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52758_52759 : H12AffineEnvironment.transform 16 46157 env52758 = env52759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env52758 == env52759) = true)

theorem identity52759 : scanCanonicalize (H12AffineFastState.compose env52759 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52759 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10281,1025,8541,4160,32,17,2,8192,65,10588,5393,4096,2420,1364,32,257,32,5456,513]

theorem envBound52760 : H12AffineFastState.Bounded env52760 := by
  intro p hp
  have h : env52760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52759_52760 : H12AffineEnvironment.transform 14 8540 env52759 = env52760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52759 == env52760) = true)

theorem identity52760 : scanCanonicalize (H12AffineFastState.compose env52760 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52760 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52761 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,5393,10281,1025,8460,4113,32,17,2,8192,16,10509,5393,4096,2341,1285,32,257,32,5377,513]

theorem envBound52761 : H12AffineFastState.Bounded env52761 := by
  intro p hp
  have h : env52761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52760_52761 : H12AffineEnvironment.transform 5 17 env52760 = env52761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52760 == env52761) = true)

theorem identity52761 : scanCanonicalize (H12AffineFastState.compose env52761 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound52761 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52762 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5377,33,295,5393,2309,1025,32,4113,32,17,2,300,16,2081,5393,4096,2341,1285,32,257,32,5377,513]

theorem envBound52762 : H12AffineFastState.Bounded env52762 := by
  intro p hp
  have h : env52762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52761_52762 : H12AffineEnvironment.transform 12 300 env52761 = env52762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env52761 == env52762) = true)

theorem identity52762 : scanCanonicalize (H12AffineFastState.compose env52762 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52762 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52763 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5156,33,2,5172,2080,1025,32,4113,32,17,2,9,16,2081,5172,4096,2048,1056,32,36,32,5156,513]

theorem envBound52763 : H12AffineFastState.Bounded env52763 := by
  intro p hp
  have h : env52763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52762_52763 : H12AffineEnvironment.transform 7 37 env52762 = env52763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52762 == env52763) = true)

theorem identity52763 : scanCanonicalize (H12AffineFastState.compose env52763 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52763 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52764 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,4096,9,5156,33,2,5172,33,1025,32,4113,32,17,2,9,16,32,5172,4096,1,1056,32,36,32,5156,513]

theorem envBound52764 : H12AffineFastState.Bounded env52764 := by
  intro p hp
  have h : env52764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52763_52764 : H12AffineEnvironment.transform 10 1 env52763 = env52764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52763 == env52764) = true)

theorem identity52764 : scanCanonicalize (H12AffineFastState.compose env52764 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52764 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52765 : List Nat := [2,4,8,16,32,17,8,37,0,1024,1,4096,9,5156,33,2,5172,33,1025,32,4113,32,17,2,9,16,32,5172,4096,1,1056,32,36,32,5156,1]

theorem envBound52765 : H12AffineFastState.Bounded env52765 := by
  intro p hp
  have h : env52765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52764_52765 : H12AffineEnvironment.transform 8 0 env52764 = env52765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52764 == env52765) = true)

def env52766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,8388608,8487372,8328,65,171416,8393984,8406288,8526964,1500,8451181,257,21793,46212,74250]

theorem envBound52766 : H12AffineFastState.Bounded env52766 := by
  intro p hp
  have h : env52766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52724_52766 : H12AffineEnvironment.transform 21 33 env52724 = env52766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env52724 == env52766) = true)

theorem identity52766 : scanCanonicalize (H12AffineFastState.compose env52766 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound52766 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,17,98781,8328,65,171416,5393,17665,138341,1500,62588,257,21793,46212,74250]

theorem envBound52767 : H12AffineFastState.Bounded env52767 := by
  intro p hp
  have h : env52767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52766_52767 : H12AffineEnvironment.transform 22 17 env52766 = env52767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52766 == env52767) = true)

def env52768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,17,98645,8192,65,171280,5393,17665,138341,1364,62588,257,21793,46092,74250]

theorem envBound52768 : H12AffineFastState.Bounded env52768 := by
  intro p hp
  have h : env52768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52767_52768 : H12AffineEnvironment.transform 6 8 env52767 = env52768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52767 == env52768) = true)

theorem identity52768 : scanCanonicalize (H12AffineFastState.compose env52768 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52768 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env52769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4160,33,17,41310,8192,65,171280,5393,17665,138341,1364,62588,257,21793,46092,513]

theorem envBound52769 : H12AffineFastState.Bounded env52769 := by
  intro p hp
  have h : env52769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52768_52769 : H12AffineEnvironment.transform 15 8203 env52768 = env52769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52768 == env52769) = true)

theorem identity52769 : scanCanonicalize (H12AffineFastState.compose env52769 (packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52769 : packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,131072,23669,1025,0,4160,33,17,8543,8192,65,138513,5393,17665,138341,1364,29821,257,21793,13325,513]

theorem envBound52770 : H12AffineFastState.Bounded env52770 := by
  intro p hp
  have h : env52770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52769_52770 : H12AffineEnvironment.transform 14 1 env52769 = env52770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52769 == env52770) = true)

theorem identity52770 : scanCanonicalize (H12AffineFastState.compose env52770 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52770 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,131072,23669,1025,0,4160,33,17,2,349,65,138513,5393,17665,138341,1364,21792,257,21793,5456,513]

theorem envBound52771 : H12AffineFastState.Bounded env52771 := by
  intro p hp
  have h : env52771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52770_52771 : H12AffineEnvironment.transform 12 349 env52770 = env52771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52770 == env52771) = true)

theorem identity52771 : scanCanonicalize (H12AffineFastState.compose env52771 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound52771 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env52772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,5440,23669,1025,0,4160,33,17,2,349,65,2129,5393,17665,2341,1364,21792,257,21793,5456,513]

theorem envBound52772 : H12AffineFastState.Bounded env52772 := by
  intro p hp
  have h : env52772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52771_52772 : H12AffineEnvironment.transform 16 5440 env52771 = env52772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env52771 == env52772) = true)

theorem identity52772 : scanCanonicalize (H12AffineFastState.compose env52772 (packedSelected [2,6,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52772 : packedSelected [2,6,12,18] rootPS < 2^1333 := by decide +kernel

def env52773 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,5393,23588,1025,0,4113,33,17,2,268,16,2048,5393,17665,2341,1285,21792,257,21793,5377,513]

theorem envBound52773 : H12AffineFastState.Bounded env52773 := by
  intro p hp
  have h : env52773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52772_52773 : H12AffineEnvironment.transform 5 17 env52772 = env52773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52772 == env52773) = true)

theorem identity52773 : scanCanonicalize (H12AffineFastState.compose env52773 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52773 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env52774 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,34,5172,23588,1025,0,4113,33,17,2,41,16,2048,5172,17444,2048,1056,21509,36,21508,5156,513]

theorem envBound52774 : H12AffineFastState.Bounded env52774 := by
  intro p hp
  have h : env52774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52773_52774 : H12AffineEnvironment.transform 7 37 env52773 = env52774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52773 == env52774) = true)

theorem identity52774 : scanCanonicalize (H12AffineFastState.compose env52774 (packedSelected [2,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52774 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env52775 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5172,2048,1025,0,4113,33,17,2,41,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound52775 : H12AffineFastState.Bounded env52775 := by
  intro p hp
  have h : env52775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52774_52775 : H12AffineEnvironment.transform 13 5156 env52774 = env52775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52774 == env52775) = true)

def env52776 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,1,34,1028,2048,1025,0,33,33,17,2,41,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound52776 : H12AffineFastState.Bounded env52776 := by
  intro p hp
  have h : env52776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52775_52776 : H12AffineEnvironment.transform 11 48 env52775 = env52776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52775 == env52776) = true)

theorem identity52776 : scanCanonicalize (H12AffineFastState.compose env52776 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound52776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52777 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,41,1044,1,34,1028,1044,1025,0,33,33,17,2,41,16,1044,1028,48,1044,1056,33,36,32,1044,513]

theorem envBound52777 : H12AffineFastState.Bounded env52777 := by
  intro p hp
  have h : env52777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52776_52777 : H12AffineEnvironment.transform 10 1044 env52776 = env52777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env52776 == env52777) = true)

def env52778 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,32,1,34,48,32,53,0,33,33,17,2,41,16,32,48,48,32,20,33,36,32,32,513]

theorem envBound52778 : H12AffineFastState.Bounded env52778 := by
  intro p hp
  have h : env52778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52777_52778 : H12AffineEnvironment.transform 9 52 env52777 = env52778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52777 == env52778) = true)

theorem identity52778 : scanCanonicalize (H12AffineFastState.compose env52778 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52779 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,1,2,16,0,21,0,1,1,17,2,9,16,0,16,16,0,20,1,4,0,0,513]

theorem envBound52779 : H12AffineFastState.Bounded env52779 := by
  intro p hp
  have h : env52779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52778_52779 : H12AffineEnvironment.transform 4 0 env52778 = env52779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52778 == env52779) = true)

def leafEnv52779 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,1,2,16,0,21,0,1,1,17,2,21,9,1,16,0,16,16,0,20,1,4,0,5,2,0,513,1,1,0]

def active52779 : List Nat := [0,1,2,3,8]

def tree52779 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52779 : H12WitnessSearch.Good tree52779 := H12GlobalWitnessIndex.good

theorem leafIdentity52779 : H12AffineFastState.composeSystem env52779 rootObs = leafEnv52779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52779 rootObs == leafEnv52779) = true)

theorem terminalChecked52779 : H12PackedTerminal.terminalCheckFast leafEnv52779 active52779 tree52779 = true := by decide +kernel

def env52780 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,41,33,1,34,49,33,52,0,33,33,17,2,41,16,33,49,48,33,21,33,36,32,33,513]

theorem envBound52780 : H12AffineFastState.Bounded env52780 := by
  intro p hp
  have h : env52780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52777_52780 : H12AffineEnvironment.transform 9 53 env52777 = env52780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52777 == env52780) = true)

theorem identity52780 : scanCanonicalize (H12AffineFastState.compose env52780 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound52780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52781 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,41,33,1,34,49,33,52,0,33,33,17,2,41,16,33,49,48,33,21,33,36,32,33,11]

theorem envBound52781 : H12AffineFastState.Bounded env52781 := by
  intro p hp
  have h : env52781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52780_52781 : H12AffineEnvironment.transform 8 10 env52780 = env52781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env52780 == env52781) = true)

def leafEnv52781 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,41,33,1,34,49,33,52,0,33,33,17,2,20,41,1,16,33,49,48,33,21,33,36,32,5,34,33,11,1,33,0]

def active52781 : List Nat := [0,1,2,3,4]

def tree52781 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52781 : H12WitnessSearch.Good tree52781 := H12GlobalWitnessIndex.good

theorem leafIdentity52781 : H12AffineFastState.composeSystem env52781 rootObs = leafEnv52781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52781 rootObs == leafEnv52781) = true)

theorem terminalChecked52781 : H12PackedTerminal.terminalCheckFast leafEnv52781 active52781 tree52781 = true := by decide +kernel

def env52782 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,1,34,1029,2048,1025,0,32,33,17,2,41,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound52782 : H12AffineFastState.Bounded env52782 := by
  intro p hp
  have h : env52782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52775_52782 : H12AffineEnvironment.transform 11 49 env52775 = env52782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52775 == env52782) = true)

theorem identity52782 : scanCanonicalize (H12AffineFastState.compose env52782 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52783 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,41,1045,1,34,1029,32,1025,0,32,33,17,2,41,16,32,1029,49,32,1056,33,36,32,1045,513]

theorem envBound52783 : H12AffineFastState.Bounded env52783 := by
  intro p hp
  have h : env52783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52782_52783 : H12AffineEnvironment.transform 10 32 env52782 = env52783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52782 == env52783) = true)

def env52784 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,41,33,1,34,49,32,53,0,32,33,17,2,41,16,32,49,49,32,20,33,36,32,33,513]

theorem envBound52784 : H12AffineFastState.Bounded env52784 := by
  intro p hp
  have h : env52784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52783_52784 : H12AffineEnvironment.transform 9 52 env52783 = env52784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52783 == env52784) = true)

theorem identity52784 : scanCanonicalize (H12AffineFastState.compose env52784 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52785 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,1,2,17,0,21,0,0,1,17,2,9,16,0,17,17,0,20,1,4,0,1,513]

theorem envBound52785 : H12AffineFastState.Bounded env52785 := by
  intro p hp
  have h : env52785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52784_52785 : H12AffineEnvironment.transform 4 0 env52784 = env52785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52784 == env52785) = true)

def leafEnv52785 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,1,2,17,0,21,0,0,1,17,2,21,9,1,16,0,17,17,0,20,1,4,0,5,2,1,513,1,0,0]

def active52785 : List Nat := [0,1,2,3,8]

def tree52785 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52785 : H12WitnessSearch.Good tree52785 := H12GlobalWitnessIndex.good

theorem leafIdentity52785 : H12AffineFastState.composeSystem env52785 rootObs = leafEnv52785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52785 rootObs == leafEnv52785) = true)

theorem terminalChecked52785 : H12PackedTerminal.terminalCheckFast leafEnv52785 active52785 tree52785 = true := by decide +kernel

def env52786 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,32,1,34,48,32,52,0,32,33,17,2,41,16,32,48,49,32,21,33,36,32,32,513]

theorem envBound52786 : H12AffineFastState.Bounded env52786 := by
  intro p hp
  have h : env52786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52783_52786 : H12AffineEnvironment.transform 9 53 env52783 = env52786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52783 == env52786) = true)

theorem identity52786 : scanCanonicalize (H12AffineFastState.compose env52786 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound52786 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52787 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,41,32,1,34,48,32,52,0,32,33,17,2,41,16,32,48,49,32,21,33,36,32,32,10]

theorem envBound52787 : H12AffineFastState.Bounded env52787 := by
  intro p hp
  have h : env52787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52786_52787 : H12AffineEnvironment.transform 8 11 env52786 = env52787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env52786 == env52787) = true)

def leafEnv52787 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,41,32,1,34,48,32,52,0,32,33,17,2,20,41,1,16,32,48,49,32,21,33,36,32,5,34,32,10,1,32,0]

def active52787 : List Nat := [0,1,2,3,4]

def tree52787 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52787 : H12WitnessSearch.Good tree52787 := H12GlobalWitnessIndex.good

theorem leafIdentity52787 : H12AffineFastState.composeSystem env52787 rootObs = leafEnv52787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52787 rootObs == leafEnv52787) = true)

theorem terminalChecked52787 : H12PackedTerminal.terminalCheckFast leafEnv52787 active52787 tree52787 = true := by decide +kernel

def env52788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,17,98644,8193,65,171281,5393,17665,138341,1365,62588,257,21793,46093,74250]

theorem envBound52788 : H12AffineFastState.Bounded env52788 := by
  intro p hp
  have h : env52788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52767_52788 : H12AffineEnvironment.transform 6 9 env52767 = env52788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52767 == env52788) = true)

theorem identity52788 : scanCanonicalize (H12AffineFastState.compose env52788 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32040,1025,8541,4160,33,17,73736,8193,65,146509,5393,17665,138341,1365,21792,257,21793,5457,74250]

theorem envBound52789 : H12AffineFastState.Bounded env52789 := by
  intro p hp
  have h : env52789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52788_52789 : H12AffineEnvironment.transform 14 8540 env52788 = env52789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52788 == env52789) = true)

theorem identity52789 : scanCanonicalize (H12AffineFastState.compose env52789 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound52789 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,131072,32040,1025,8541,4160,33,17,21763,8193,65,146509,5393,17665,138341,1365,21792,257,21793,5457,22273]

theorem envBound52790 : H12AffineFastState.Bounded env52790 := by
  intro p hp
  have h : env52790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52789_52790 : H12AffineEnvironment.transform 15 29963 env52789 = env52790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env52789 == env52790) = true)

theorem identity52790 : scanCanonicalize (H12AffineFastState.compose env52790 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound52790 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,263,131072,2340,1025,8541,4160,33,17,8463,8193,65,146509,5393,12557,138341,1365,8492,257,8493,5457,8973]

theorem envBound52791 : H12AffineFastState.Bounded env52791 := by
  intro p hp
  have h : env52791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52790_52791 : H12AffineEnvironment.transform 13 13324 env52790 = env52791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env52790 == env52791) = true)

theorem identity52791 : scanCanonicalize (H12AffineFastState.compose env52791 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound52791 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,263,5441,2340,1025,8541,4160,33,17,8463,8193,65,10508,5393,12557,2340,1365,8492,257,8493,5457,8973]

theorem envBound52792 : H12AffineFastState.Bounded env52792 := by
  intro p hp
  have h : env52792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52791_52792 : H12AffineEnvironment.transform 16 5441 env52791 = env52792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env52791 == env52792) = true)

theorem identity52792 : scanCanonicalize (H12AffineFastState.compose env52792 (packedSelected [0,1,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52792 : packedSelected [0,1,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52793 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,13324,8312,35,5221,2048,1025,8313,4160,33,17,8235,8193,65,10280,5173,12329,2048,1137,8200,37,8201,5237,8745]

theorem envBound52793 : H12AffineFastState.Bounded env52793 := by
  intro p hp
  have h : env52793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52792_52793 : H12AffineEnvironment.transform 7 36 env52792 = env52793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52792 == env52793) = true)

theorem identity52793 : scanCanonicalize (H12AffineFastState.compose env52793 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound52793 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env52794 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,6249,3173,6161,35,5221,2048,1025,6160,4160,33,17,6210,6248,65,4161,5173,2112,2048,1137,6241,37,6240,5237,6720]

theorem envBound52794 : H12AffineFastState.Bounded env52794 := by
  intro p hp
  have h : env52794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52793_52794 : H12AffineEnvironment.transform 12 6249 env52793 = env52794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env52793 == env52794) = true)

theorem identity52794 : scanCanonicalize (H12AffineFastState.compose env52794 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound52794 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52795 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2113,40,3173,80,35,3108,2048,1025,81,2049,33,17,3,41,65,2048,3188,2112,2048,1137,32,37,33,3124,513]

theorem envBound52795 : H12AffineFastState.Bounded env52795 := by
  intro p hp
  have h : env52795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52794_52795 : H12AffineEnvironment.transform 11 2113 env52794 = env52795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env52794 == env52795) = true)

theorem identity52795 : scanCanonicalize (H12AffineFastState.compose env52795 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52795 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52796 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2113,40,2049,80,35,2112,2048,101,81,2049,33,17,3,41,65,2048,2064,2112,2048,21,32,37,33,2128,513]

theorem envBound52796 : H12AffineFastState.Bounded env52796 := by
  intro p hp
  have h : env52796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52795_52796 : H12AffineEnvironment.transform 9 100 env52795 = env52796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52795 == env52796) = true)

def env52797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,4194304,8388608,8487373,8328,65,4365752,8393984,8406289,8526964,1501,12645452,257,21793,46212,74251]

theorem envBound52797 : H12AffineFastState.Bounded env52797 := by
  intro p hp
  have h : env52797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52723_52797 : H12AffineEnvironment.transform 20 4161 env52723 = env52797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52723 == env52797) = true)

def env52798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,32,8388608,8487373,8328,65,171416,8393984,8406289,8526964,1501,8451180,257,21793,46212,74251]

theorem envBound52798 : H12AffineFastState.Bounded env52798 := by
  intro p hp
  have h : env52798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52797_52798 : H12AffineEnvironment.transform 21 32 env52797 = env52798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52797 == env52798) = true)

theorem identity52798 : scanCanonicalize (H12AffineFastState.compose env52798 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound52798 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1025,29908,4161,32,8388608,8484120,8328,65,158029,8393984,8406289,8526964,1501,8388793,257,21793,16465,74251]

theorem envBound52799 : H12AffineFastState.Bounded env52799 := by
  intro p hp
  have h : env52799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52798_52799 : H12AffineEnvironment.transform 14 29909 env52798 = env52799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env52798 == env52799) = true)

theorem identity52799 : scanCanonicalize (H12AffineFastState.compose env52799 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52799 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env52800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,10401,1025,29908,4161,32,8388608,8410386,8328,65,158029,8393984,8406289,8526964,1501,8388793,257,21793,16465,513]

theorem envBound52800 : H12AffineFastState.Bounded env52800 := by
  intro p hp
  have h : env52800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52799_52800 : H12AffineEnvironment.transform 15 8202 env52799 = env52800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52799 == env52800) = true)

def env52801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,131072,10401,1025,8660,4161,32,8388608,8388626,8328,65,146509,8393984,8392721,8526964,1501,8388793,257,33,5457,513]

theorem envBound52801 : H12AffineFastState.Bounded env52801 := by
  intro p hp
  have h : env52801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52800_52801 : H12AffineEnvironment.transform 13 5376 env52800 = env52801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52800 == env52801) = true)

theorem identity52801 : scanCanonicalize (H12AffineFastState.compose env52801 (packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 144396) := by decide +kernel

theorem selectedBound52801 : packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env52802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,131072,10401,1025,8660,4161,32,144396,144414,8328,65,146509,139532,140317,10360,1501,144565,257,33,5457,513]

theorem envBound52802 : H12AffineFastState.Bounded env52802 := by
  intro p hp
  have h : env52802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52801_52802 : H12AffineEnvironment.transform 22 144396 env52801 = env52802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 144396 env52801 == env52802) = true)

theorem identity52802 : scanCanonicalize (H12AffineFastState.compose env52802 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound52802 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env52803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,5441,10401,1025,8660,4161,32,8525,8543,8328,65,10508,13389,12636,10360,1501,8692,257,33,5457,513]

theorem envBound52803 : H12AffineFastState.Bounded env52803 := by
  intro p hp
  have h : env52803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52802_52803 : H12AffineEnvironment.transform 16 5441 env52802 = env52803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env52802 == env52803) = true)

theorem identity52803 : scanCanonicalize (H12AffineFastState.compose env52803 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound52803 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env52804 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8461,8202,5441,10361,1025,8460,4161,32,8525,8543,8272,65,10508,13389,12636,10360,1285,8492,257,33,5457,513]

theorem envBound52804 : H12AffineFastState.Bounded env52804 := by
  intro p hp
  have h : env52804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52803_52804 : H12AffineEnvironment.transform 6 88 env52803 = env52804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env52803 == env52804) = true)

def env52805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,131072,10401,1025,8661,4161,32,8388608,8388627,8328,65,146508,8393984,8392720,8526964,1501,8388793,257,32,5456,513]

theorem envBound52805 : H12AffineFastState.Bounded env52805 := by
  intro p hp
  have h : env52805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52800_52805 : H12AffineEnvironment.transform 13 5377 env52800 = env52805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52800 == env52805) = true)

theorem identity52805 : scanCanonicalize (H12AffineFastState.compose env52805 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52805 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10281,1025,8541,4161,32,8388608,8388627,8192,65,146508,8393984,8392720,8526964,1365,8388657,257,32,5456,513]

theorem envBound52806 : H12AffineFastState.Bounded env52806 := by
  intro p hp
  have h : env52806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52805_52806 : H12AffineEnvironment.transform 6 8 env52805 = env52806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52805 == env52806) = true)

theorem identity52806 : scanCanonicalize (H12AffineFastState.compose env52806 (packedSelected [0,1,4,7,8,9,10,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 136528) := by decide +kernel

theorem selectedBound52806 : packedSelected [0,1,4,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env52807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10281,1025,8541,4161,32,136528,136515,8192,65,146508,131152,132416,2340,1365,136545,257,32,5456,513]

theorem envBound52807 : H12AffineFastState.Bounded env52807 := by
  intro p hp
  have h : env52807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52806_52807 : H12AffineEnvironment.transform 22 136528 env52806 = env52807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136528 env52806 == env52807) = true)

theorem identity52807 : scanCanonicalize (H12AffineFastState.compose env52807 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52807 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env52808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,263,131072,2340,1025,80,4161,32,136528,136515,269,65,138561,131152,132416,2340,1365,136545,257,32,5456,513]

theorem envBound52808 : H12AffineFastState.Bounded env52808 := by
  intro p hp
  have h : env52808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52807_52808 : H12AffineEnvironment.transform 12 269 env52807 = env52808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52807 == env52808) = true)

theorem identity52808 : scanCanonicalize (H12AffineFastState.compose env52808 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52808 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52809 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,131072,2340,1025,0,4113,32,136448,136467,269,17,138513,131072,132368,2340,1285,136497,257,32,5376,513]

theorem envBound52809 : H12AffineFastState.Bounded env52809 := by
  intro p hp
  have h : env52809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52808_52809 : H12AffineEnvironment.transform 5 16 env52808 = env52809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52808 == env52809) = true)

theorem identity52809 : scanCanonicalize (H12AffineFastState.compose env52809 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(16+1) ^^^ 7440) := by decide +kernel

theorem selectedBound52809 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52810 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,7440,2340,1025,0,4113,32,2064,2051,269,17,1,7440,6144,2340,1285,2081,257,32,5376,513]

theorem envBound52810 : H12AffineFastState.Bounded env52810 := by
  intro p hp
  have h : env52810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52809_52810 : H12AffineEnvironment.transform 16 7440 env52809 = env52810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 7440 env52809 == env52810) = true)

theorem identity52810 : scanCanonicalize (H12AffineFastState.compose env52810 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound52810 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env52811 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2356,269,3125,1,263,1060,2340,1025,0,2341,32,2064,2051,269,17,1,1060,308,2340,1285,2081,257,32,3124,513]

theorem envBound52811 : H12AffineFastState.Bounded env52811 := by
  intro p hp
  have h : env52811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52810_52811 : H12AffineEnvironment.transform 11 2356 env52810 = env52811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env52810 == env52811) = true)

theorem identity52811 : scanCanonicalize (H12AffineFastState.compose env52811 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52811 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env52812 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,308,269,1077,1,263,1060,292,1025,0,293,32,16,3,269,17,1,1060,308,292,1285,33,257,32,1076,513]

theorem envBound52812 : H12AffineFastState.Bounded env52812 := by
  intro p hp
  have h : env52812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52811_52812 : H12AffineEnvironment.transform 10 0 env52811 = env52812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52811 == env52812) = true)

def env52813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,8388608,8487373,8328,65,171417,8393984,8406289,8526964,1501,8451181,257,21793,46212,74251]

theorem envBound52813 : H12AffineFastState.Bounded env52813 := by
  intro p hp
  have h : env52813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52797_52813 : H12AffineEnvironment.transform 21 33 env52797 = env52813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env52797 == env52813) = true)

theorem identity52813 : scanCanonicalize (H12AffineFastState.compose env52813 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62660) := by decide +kernel

theorem selectedBound52813 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,62660,95497,8328,65,171417,57796,45525,190640,1501,169,257,21793,46212,74251]

theorem envBound52814 : H12AffineFastState.Bounded env52814 := by
  intro p hp
  have h : env52814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52813_52814 : H12AffineEnvironment.transform 22 62660 env52813 = env52814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env52813 == env52814) = true)

def env52815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,62540,95497,8192,65,171281,57676,45405,190520,1365,33,257,21793,46092,74251]

theorem envBound52815 : H12AffineFastState.Bounded env52815 := by
  intro p hp
  have h : env52815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52814_52815 : H12AffineEnvironment.transform 6 8 env52814 = env52815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52814 == env52815) = true)

theorem identity52815 : scanCanonicalize (H12AffineFastState.compose env52815 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound52815 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,4161,33,17,95497,8192,65,158028,5393,17664,138341,1365,33,257,21793,16465,74251]

theorem envBound52816 : H12AffineFastState.Bounded env52816 := by
  intro p hp
  have h : env52816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52815_52816 : H12AffineEnvironment.transform 14 29789 env52815 = env52816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env52815 == env52816) = true)

theorem identity52816 : scanCanonicalize (H12AffineFastState.compose env52816 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52816 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,10281,1025,29788,4161,33,17,21763,8192,65,158028,5393,17664,138341,1365,33,257,21793,16465,513]

theorem envBound52817 : H12AffineFastState.Bounded env52817 := by
  intro p hp
  have h : env52817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52816_52817 : H12AffineEnvironment.transform 15 8202 env52816 = env52817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52816 == env52817) = true)

theorem identity52817 : scanCanonicalize (H12AffineFastState.compose env52817 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52817 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,131072,2420,1025,21761,4161,33,17,21763,349,65,149521,5393,17664,138341,1365,33,257,21793,16465,513]

theorem envBound52818 : H12AffineFastState.Bounded env52818 := by
  intro p hp
  have h : env52818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52817_52818 : H12AffineEnvironment.transform 12 349 env52817 = env52818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52817 == env52818) = true)

theorem identity52818 : scanCanonicalize (H12AffineFastState.compose env52818 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound52818 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,5392,2420,1025,21761,4161,33,17,21763,349,65,23809,5393,17664,2421,1365,33,257,21793,16465,513]

theorem envBound52819 : H12AffineFastState.Bounded env52819 := by
  intro p hp
  have h : env52819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52818_52819 : H12AffineEnvironment.transform 16 5392 env52818 = env52819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env52818 == env52819) = true)

theorem identity52819 : scanCanonicalize (H12AffineFastState.compose env52819 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52819 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5392,2420,1025,0,4161,33,17,2,349,65,2048,5393,4097,2421,1365,33,257,32,5456,513]

theorem envBound52820 : H12AffineFastState.Bounded env52820 := by
  intro p hp
  have h : env52820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52819_52820 : H12AffineEnvironment.transform 13 5377 env52819 = env52820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52819 == env52820) = true)

theorem identity52820 : scanCanonicalize (H12AffineFastState.compose env52820 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound52820 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,869,349,1636,1,343,1653,2420,1025,0,804,33,17,2,349,65,2048,1652,868,2421,1365,33,257,32,1589,513]

theorem envBound52821 : H12AffineFastState.Bounded env52821 := by
  intro p hp
  have h : env52821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52820_52821 : H12AffineEnvironment.transform 11 869 env52820 = env52821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env52820 == env52821) = true)

theorem identity52821 : scanCanonicalize (H12AffineFastState.compose env52821 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound52821 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,528,869,349,1636,1,343,1653,868,1025,0,804,33,17,2,349,65,528,1652,868,869,1365,33,257,32,1589,513]

theorem envBound52822 : H12AffineFastState.Bounded env52822 := by
  intro p hp
  have h : env52822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52821_52822 : H12AffineEnvironment.transform 10 528 env52821 = env52822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env52821 == env52822) = true)

theorem identity52822 : scanCanonicalize (H12AffineFastState.compose env52822 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52822 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env52823 : List Nat := [2,4,8,16,0,64,8,256,512,1024,528,837,349,1604,1,343,1621,836,1025,0,772,1,17,2,349,65,528,1620,836,837,1365,1,257,0,1557,513]

theorem envBound52823 : H12AffineFastState.Bounded env52823 := by
  intro p hp
  have h : env52823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52822_52823 : H12AffineEnvironment.transform 4 0 env52822 = env52823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52822 == env52823) = true)

theorem identity52823 : scanCanonicalize (H12AffineFastState.compose env52823 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52823 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env52824 : List Nat := [2,4,8,16,0,17,8,256,512,1024,528,788,268,1557,1,262,1540,789,1025,0,772,1,17,2,268,16,528,1541,789,788,1284,1,257,0,1557,513]

theorem envBound52824 : H12AffineFastState.Bounded env52824 := by
  intro p hp
  have h : env52824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52823_52824 : H12AffineEnvironment.transform 5 17 env52823 = env52824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52823 == env52824) = true)

theorem identity52824 : scanCanonicalize (H12AffineFastState.compose env52824 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52825 : List Nat := [2,4,8,16,0,17,8,256,512,5,528,788,268,528,1,262,513,789,4,0,772,1,17,2,268,16,528,512,789,788,257,1,257,0,528,513]

theorem envBound52825 : H12AffineFastState.Bounded env52825 := by
  intro p hp
  have h : env52825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52824_52825 : H12AffineEnvironment.transform 9 5 env52824 = env52825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52824 == env52825) = true)

theorem identity52825 : scanCanonicalize (H12AffineFastState.compose env52825 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52825 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52826 : List Nat := [2,4,8,16,0,17,8,4,512,5,528,528,8,528,1,2,513,529,4,0,512,1,17,2,8,16,528,512,529,528,5,1,5,0,528,513]

theorem envBound52826 : H12AffineFastState.Bounded env52826 := by
  intro p hp
  have h : env52826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52825_52826 : H12AffineEnvironment.transform 7 4 env52825 = env52826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52825 == env52826) = true)

def env52827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,62541,95497,8193,65,171280,57677,45404,190521,1364,32,257,21793,46093,74251]

theorem envBound52827 : H12AffineFastState.Bounded env52827 := by
  intro p hp
  have h : env52827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52814_52827 : H12AffineEnvironment.transform 6 9 env52814 = env52827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52814 == env52827) = true)

theorem identity52827 : scanCanonicalize (H12AffineFastState.compose env52827 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52827 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1025,32769,4161,33,41293,73737,8193,65,171280,46157,45404,179513,1364,32,257,33,46093,74251]

theorem envBound52828 : H12AffineFastState.Bounded env52828 := by
  intro p hp
  have h : env52828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52827_52828 : H12AffineEnvironment.transform 13 5376 env52827 = env52828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52827 == env52828) = true)

theorem identity52828 : scanCanonicalize (H12AffineFastState.compose env52828 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound52828 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env52829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,70679,35188,1025,32769,4161,33,41293,73737,8193,65,100615,46157,45404,108846,1364,32,257,33,46093,74251]

theorem envBound52829 : H12AffineFastState.Bounded env52829 := by
  intro p hp
  have h : env52829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52828_52829 : H12AffineEnvironment.transform 16 70679 env52828 = env52829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env52828 == env52829) = true)

theorem identity52829 : scanCanonicalize (H12AffineFastState.compose env52829 (packedSelected [0,3,4,7,9,10,11,12,14,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound52829 : packedSelected [0,3,4,7,9,10,11,12,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env52830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,65536,70679,35188,1025,32769,4161,33,33076,65648,120,65,100615,37940,37157,100695,1364,32,257,33,38004,66162]

theorem envBound52830 : H12AffineFastState.Bounded env52830 := by
  intro p hp
  have h : env52830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52829_52830 : H12AffineEnvironment.transform 12 121 env52829 = env52830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env52829 == env52830) = true)

theorem identity52830 : scanCanonicalize (H12AffineFastState.compose env52830 (packedSelected [2,4,6,9,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52830 : packedSelected [2,4,6,9,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env52831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,1,65536,70679,2421,1025,0,4161,33,309,65648,120,65,67846,5173,4388,67926,1364,32,257,33,5237,66162]

theorem envBound52831 : H12AffineFastState.Bounded env52831 := by
  intro p hp
  have h : env52831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52830_52831 : H12AffineEnvironment.transform 14 1 env52830 = env52831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52830 == env52831) = true)

theorem identity52831 : scanCanonicalize (H12AffineFastState.compose env52831 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52831 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env52832 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,1,65536,70679,2049,1025,0,4161,33,65,65648,120,65,67698,5173,4176,67618,1056,32,117,33,5237,66162]

theorem envBound52832 : H12AffineFastState.Bounded env52832 := by
  intro p hp
  have h : env52832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52831_52832 : H12AffineEnvironment.transform 7 116 env52831 = env52832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52831 == env52832) = true)

theorem identity52832 : scanCanonicalize (H12AffineFastState.compose env52832 (packedSelected [0,2,3,4,5,6,7,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound52832 : packedSelected [0,2,3,4,5,6,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env52833 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,1,115,5220,2049,1025,0,4161,33,65,3,120,65,2049,5173,4176,2129,1056,32,117,33,5237,513]

theorem envBound52833 : H12AffineFastState.Bounded env52833 := by
  intro p hp
  have h : env52833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52832_52833 : H12AffineEnvironment.transform 15 115 env52832 = env52833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env52832 == env52833) = true)

theorem identity52833 : scanCanonicalize (H12AffineFastState.compose env52833 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52833 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52834 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,1,34,5173,2049,1025,0,4112,33,16,3,41,16,2049,5173,4097,2048,1056,32,36,33,5156,513]

theorem envBound52834 : H12AffineFastState.Bounded env52834 := by
  intro p hp
  have h : env52834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52833_52834 : H12AffineEnvironment.transform 5 17 env52833 = env52834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52833 == env52834) = true)

theorem identity52834 : scanCanonicalize (H12AffineFastState.compose env52834 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound52834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52835 : List Nat := [2,4,8,16,32,17,9,37,512,36,2048,4096,40,4097,1,34,4113,2049,37,0,4112,33,16,3,41,16,2049,4113,4097,2048,4,32,36,33,4096,513]

theorem envBound52835 : H12AffineFastState.Bounded env52835 := by
  intro p hp
  have h : env52835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52834_52835 : H12AffineEnvironment.transform 9 36 env52834 = env52835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env52834 == env52835) = true)

theorem identity52835 : scanCanonicalize (H12AffineFastState.compose env52835 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound52835 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52836 : List Nat := [2,4,8,16,32,17,9,37,512,36,27,4096,40,4097,1,34,4113,26,37,0,4112,33,16,3,41,16,26,4113,4097,27,4,32,36,33,4096,513]

theorem envBound52836 : H12AffineFastState.Bounded env52836 := by
  intro p hp
  have h : env52836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52835_52836 : H12AffineEnvironment.transform 10 27 env52835 = env52836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env52835 == env52836) = true)

theorem identity52836 : scanCanonicalize (H12AffineFastState.compose env52836 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound52836 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52837 : List Nat := [2,4,8,16,27,17,9,30,512,31,27,4096,19,4097,1,25,4113,26,30,0,4112,26,16,3,18,16,26,4113,4097,27,4,27,31,26,4096,513]

theorem envBound52837 : H12AffineFastState.Bounded env52837 := by
  intro p hp
  have h : env52837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52836_52837 : H12AffineEnvironment.transform 4 27 env52836 = env52837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env52836 == env52837) = true)

theorem identity52837 : scanCanonicalize (H12AffineFastState.compose env52837 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52837 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52838 : List Nat := [2,4,8,16,27,17,9,30,512,31,27,0,19,1,1,25,17,26,30,0,16,26,16,3,18,16,26,17,1,27,4,27,31,26,0,513]

theorem envBound52838 : H12AffineFastState.Bounded env52838 := by
  intro p hp
  have h : env52838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52837_52838 : H12AffineEnvironment.transform 11 0 env52837 = env52838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52837 == env52838) = true)

theorem identity52838 : scanCanonicalize (H12AffineFastState.compose env52838 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52838 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52839 : List Nat := [2,4,2,16,17,17,3,20,512,21,17,0,19,1,1,19,17,16,20,0,16,16,16,3,18,16,16,17,1,17,4,17,21,16,0,513]

theorem envBound52839 : H12AffineFastState.Bounded env52839 := by
  intro p hp
  have h : env52839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52838_52839 : H12AffineEnvironment.transform 2 2 env52838 = env52839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52838 == env52839) = true)

theorem identity52839 : scanCanonicalize (H12AffineFastState.compose env52839 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound52839 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52840 : List Nat := [2,4,2,16,17,17,3,20,21,21,17,0,19,1,1,19,17,16,20,0,16,16,16,3,18,16,16,17,1,17,4,17,21,16,0,20]

theorem envBound52840 : H12AffineFastState.Bounded env52840 := by
  intro p hp
  have h : env52840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52839_52840 : H12AffineEnvironment.transform 8 21 env52839 = env52840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env52839 == env52840) = true)

def env52841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458873,8393985,10507600,8526965,2102685,12645453,257,21792,46213,2175563]

theorem envBound52841 : H12AffineFastState.Bounded env52841 := by
  intro p hp
  have h : env52841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52722_52841 : H12AffineEnvironment.transform 17 56437 env52722 = env52841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env52722 == env52841) = true)

def env52842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,8388608,8487373,8328,65,4365753,8393985,8406288,8526965,1501,12645453,257,21792,46213,74251]

theorem envBound52842 : H12AffineFastState.Bounded env52842 := by
  intro p hp
  have h : env52842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52841_52842 : H12AffineEnvironment.transform 20 4160 env52841 = env52842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52841 == env52842) = true)

def env52843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,8388608,8487373,8328,65,171417,8393985,8406288,8526965,1501,8451181,257,21792,46213,74251]

theorem envBound52843 : H12AffineFastState.Bounded env52843 := by
  intro p hp
  have h : env52843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52842_52843 : H12AffineEnvironment.transform 21 32 env52842 = env52843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52842 == env52843) = true)

theorem identity52843 : scanCanonicalize (H12AffineFastState.compose env52843 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound52843 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,56437,1025,32769,4160,32,8388608,8410387,8328,65,171417,8393985,8406288,8526965,1501,8451181,257,21792,46213,63189]

theorem envBound52844 : H12AffineFastState.Bounded env52844 := by
  intro p hp
  have h : env52844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52843_52844 : H12AffineEnvironment.transform 15 54494 env52843 = env52844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env52843 == env52844) = true)

def env52845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56437,1025,32769,4160,32,8388608,8410387,8192,65,171281,8393985,8406288,8526965,1365,8451181,257,21792,46093,63069]

theorem envBound52845 : H12AffineFastState.Bounded env52845 := by
  intro p hp
  have h : env52845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52844_52845 : H12AffineEnvironment.transform 6 8 env52844 = env52845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52844 == env52845) = true)

theorem identity52845 : scanCanonicalize (H12AffineFastState.compose env52845 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound52845 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46157,56437,1025,32769,4160,32,8388608,8410387,8192,65,10588,8393985,8406288,8431672,1365,8451181,257,21792,46093,63069]

theorem envBound52846 : H12AffineFastState.Bounded env52846 := by
  intro p hp
  have h : env52846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52845_52846 : H12AffineEnvironment.transform 16 46157 env52845 = env52846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env52845 == env52846) = true)

theorem identity52846 : scanCanonicalize (H12AffineFastState.compose env52846 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound52846 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env52847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16401,10281,1025,29789,4160,32,8388608,8410387,8192,65,10588,8393985,8406288,8412260,1365,8388657,257,21792,16465,513]

theorem envBound52847 : H12AffineFastState.Bounded env52847 := by
  intro p hp
  have h : env52847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52846_52847 : H12AffineEnvironment.transform 14 29788 env52846 = env52847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env52846 == env52847) = true)

theorem identity52847 : scanCanonicalize (H12AffineFastState.compose env52847 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound52847 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env52848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16401,10281,1025,29789,4160,32,17,21762,8192,65,10588,5392,17665,23669,1365,32,257,21792,16465,513]

theorem envBound52848 : H12AffineFastState.Bounded env52848 := by
  intro p hp
  have h : env52848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52847_52848 : H12AffineEnvironment.transform 22 17 env52847 = env52848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52847 == env52848) = true)

theorem identity52848 : scanCanonicalize (H12AffineFastState.compose env52848 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52848 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env52849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21840,262,16401,2341,1025,21841,4160,32,17,21762,268,65,2128,5392,17665,23669,1365,32,257,21792,16465,513]

theorem envBound52849 : H12AffineFastState.Bounded env52849 := by
  intro p hp
  have h : env52849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52848_52849 : H12AffineEnvironment.transform 12 268 env52848 = env52849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52848 == env52849) = true)

theorem identity52849 : scanCanonicalize (H12AffineFastState.compose env52849 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound52849 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,262,5441,2341,1025,1,4160,32,17,82,268,65,2128,5392,4177,2341,1365,32,257,112,5377,513]

theorem envBound52850 : H12AffineFastState.Bounded env52850 := by
  intro p hp
  have h : env52850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52849_52850 : H12AffineEnvironment.transform 13 5456 env52849 = env52850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env52849 == env52850) = true)

theorem identity52850 : scanCanonicalize (H12AffineFastState.compose env52850 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound52850 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env52851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1793,268,593,0,262,576,2341,1025,1,1857,32,17,82,268,65,2128,529,1872,2341,1365,32,257,112,512,513]

theorem envBound52851 : H12AffineFastState.Bounded env52851 := by
  intro p hp
  have h : env52851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52850_52851 : H12AffineEnvironment.transform 11 1793 env52850 = env52851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env52850 == env52851) = true)

def env52852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56437,1025,32769,4160,32,8388608,8410387,8193,65,171280,8393985,8406288,8526965,1364,8451181,257,21792,46092,63068]

theorem envBound52852 : H12AffineFastState.Bounded env52852 := by
  intro p hp
  have h : env52852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52844_52852 : H12AffineEnvironment.transform 6 9 env52844 = env52852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52844 == env52852) = true)

theorem identity52852 : scanCanonicalize (H12AffineFastState.compose env52852 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57401) := by decide +kernel

theorem selectedBound52852 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,57401,56437,1025,32769,4160,32,8388608,8410387,8193,65,32041,8393985,8406288,8453196,1364,8451181,257,21792,46092,63068]

theorem envBound52853 : H12AffineFastState.Bounded env52853 := by
  intro p hp
  have h : env52853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52852_52853 : H12AffineEnvironment.transform 16 57401 env52852 = env52853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57401 env52852 == env52853) = true)

theorem identity52853 : scanCanonicalize (H12AffineFastState.compose env52853 (packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound52853 : packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29823,16401,31837,1025,8233,4160,32,8388608,8410387,8193,65,32041,8393985,8406288,8412260,1364,8410181,257,21792,5156,22132]

theorem envBound52854 : H12AffineFastState.Bounded env52854 := by
  intro p hp
  have h : env52854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52853_52854 : H12AffineEnvironment.transform 14 8232 env52853 = env52854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env52853 == env52854) = true)

theorem identity52854 : scanCanonicalize (H12AffineFastState.compose env52854 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52854 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env52855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8232,8574,5392,10588,1025,8233,4160,32,8388608,8388626,8193,65,10280,8393985,8392721,8391013,1364,8388932,257,33,5156,885]

theorem envBound52855 : H12AffineFastState.Bounded env52855 := by
  intro p hp
  have h : env52855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52854_52855 : H12AffineEnvironment.transform 13 5377 env52854 = env52855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52854 == env52855) = true)

theorem identity52855 : scanCanonicalize (H12AffineFastState.compose env52855 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52855 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env52856 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8232,8202,5220,10280,1025,8233,4160,32,8388608,8388626,8193,65,10280,8393845,8392721,8390673,1056,8388656,117,33,5156,513]

theorem envBound52856 : H12AffineFastState.Bounded env52856 := by
  intro p hp
  have h : env52856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52855_52856 : H12AffineEnvironment.transform 7 116 env52855 = env52856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52855 == env52856) = true)

theorem identity52856 : scanCanonicalize (H12AffineFastState.compose env52856 (packedSelected [3,5,10] rootPS)) = affineNative (2^(22+1) ^^^ 1141) := by decide +kernel

theorem selectedBound52856 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52857 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8232,8202,5220,10280,1025,8233,4160,32,1141,1127,8193,65,10280,4096,5220,3172,1056,1093,117,33,5156,513]

theorem envBound52857 : H12AffineFastState.Bounded env52857 := by
  intro p hp
  have h : env52857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52856_52857 : H12AffineEnvironment.transform 22 1141 env52856 = env52857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1141 env52856 == env52857) = true)

theorem identity52857 : scanCanonicalize (H12AffineFastState.compose env52857 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound52857 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env52858 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,6200,5237,6160,6194,5220,4112,1025,6161,4160,32,1141,1127,6201,65,4112,4096,5220,3172,1056,1093,117,33,5156,513]

theorem envBound52858 : H12AffineFastState.Bounded env52858 := by
  intro p hp
  have h : env52858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52857_52858 : H12AffineEnvironment.transform 12 6200 env52857 = env52858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env52857 == env52858) = true)

theorem identity52858 : scanCanonicalize (H12AffineFastState.compose env52858 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52858 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52859 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,6200,4161,6160,6194,4176,4112,53,6161,4160,32,65,83,6201,65,4112,4096,4176,2128,20,113,117,33,4112,513]

theorem envBound52859 : H12AffineFastState.Bounded env52859 := by
  intro p hp
  have h : env52859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52858_52859 : H12AffineEnvironment.transform 9 52 env52858 = env52859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52858 == env52859) = true)

theorem identity52859 : scanCanonicalize (H12AffineFastState.compose env52859 (packedSelected [0,2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2673) := by decide +kernel

theorem selectedBound52859 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env52860 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2673,585,2608,609,579,2593,2657,53,608,2609,32,65,83,584,65,2657,2673,2593,2128,20,113,117,33,2657,513]

theorem envBound52860 : H12AffineFastState.Bounded env52860 := by
  intro p hp
  have h : env52860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52859_52860 : H12AffineEnvironment.transform 11 2673 env52859 = env52860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2673 env52859 == env52860) = true)

theorem identity52860 : scanCanonicalize (H12AffineFastState.compose env52860 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound52860 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env52861 : List Nat := [2,4,8,16,32,64,9,116,512,52,65,560,585,625,609,579,608,544,53,608,624,32,65,83,584,65,544,560,608,17,20,113,117,33,544,513]

theorem envBound52861 : H12AffineFastState.Bounded env52861 := by
  intro p hp
  have h : env52861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52860_52861 : H12AffineEnvironment.transform 10 65 env52860 = env52861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env52860 == env52861) = true)

theorem identity52861 : scanCanonicalize (H12AffineFastState.compose env52861 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52862 : List Nat := [2,4,8,1,32,64,9,101,512,37,65,545,585,608,609,579,608,544,36,608,609,32,65,66,584,65,544,545,608,0,5,96,100,33,544,513]

theorem envBound52862 : H12AffineFastState.Bounded env52862 := by
  intro p hp
  have h : env52862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52861_52862 : H12AffineEnvironment.transform 3 1 env52861 = env52862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52861 == env52862) = true)

theorem identity52862 : scanCanonicalize (H12AffineFastState.compose env52862 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52862 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52863 : List Nat := [2,4,8,1,32,64,9,101,32,37,65,1,105,64,65,99,64,0,36,64,65,32,65,66,104,65,0,1,64,0,5,96,100,33,0,33]

theorem envBound52863 : H12AffineFastState.Bounded env52863 := by
  intro p hp
  have h : env52863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52862_52863 : H12AffineEnvironment.transform 8 32 env52862 = env52863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52862 == env52863) = true)

theorem identity52863 : scanCanonicalize (H12AffineFastState.compose env52863 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52864 : List Nat := [2,4,8,1,32,0,9,37,32,37,1,1,41,0,1,35,0,0,36,0,1,32,1,2,40,1,0,1,0,0,5,32,36,33,0,33]

theorem envBound52864 : H12AffineFastState.Bounded env52864 := by
  intro p hp
  have h : env52864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52863_52864 : H12AffineEnvironment.transform 5 0 env52863 = env52864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52863 == env52864) = true)

def env52865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,8388608,8487373,8328,65,171416,8393985,8406288,8526965,1501,8451180,257,21792,46213,74251]

theorem envBound52865 : H12AffineFastState.Bounded env52865 := by
  intro p hp
  have h : env52865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52842_52865 : H12AffineEnvironment.transform 21 33 env52842 = env52865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env52842 == env52865) = true)

theorem identity52865 : scanCanonicalize (H12AffineFastState.compose env52865 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound52865 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,120015,21762,8328,65,171416,115150,102879,247994,1501,73891,257,21792,46213,74251]

theorem envBound52866 : H12AffineFastState.Bounded env52866 := by
  intro p hp
  have h : env52866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52865_52866 : H12AffineEnvironment.transform 22 120015 env52865 = env52866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env52865 == env52866) = true)

def env52867 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56357,1025,32769,4112,33,119967,21762,8328,17,171416,115102,102799,247994,1421,73891,257,21792,46213,74251]

theorem envBound52867 : H12AffineFastState.Bounded env52867 := by
  intro p hp
  have h : env52867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52866_52867 : H12AffineEnvironment.transform 5 16 env52866 = env52867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52866 == env52867) = true)

theorem identity52867 : scanCanonicalize (H12AffineFastState.compose env52867 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound52867 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env52868 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,114966,56357,1025,32769,4112,33,119967,21762,8328,17,89230,115102,102799,2476,1421,73891,257,21792,46213,74251]

theorem envBound52868 : H12AffineFastState.Bounded env52868 := by
  intro p hp
  have h : env52868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52867_52868 : H12AffineEnvironment.transform 16 114966 env52867 = env52868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env52867 == env52868) = true)

theorem identity52868 : scanCanonicalize (H12AffineFastState.compose env52868 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound52868 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env52869 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8322,57748,56357,1025,32769,4112,33,62493,21762,8328,17,31756,57628,45325,2476,1421,33,257,21792,46213,649]

theorem envBound52869 : H12AffineFastState.Bounded env52869 := by
  intro p hp
  have h : env52869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52868_52869 : H12AffineEnvironment.transform 15 8322 env52868 = env52869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env52868 == env52869) = true)

theorem identity52869 : scanCanonicalize (H12AffineFastState.compose env52869 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52869 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env52870 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,8322,13460,2341,1025,21761,4112,33,8477,21762,8328,17,31756,13340,25613,2476,1421,33,257,21792,24965,649]

theorem envBound52870 : H12AffineFastState.Bounded env52870 := by
  intro p hp
  have h : env52870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52869_52870 : H12AffineEnvironment.transform 14 21760 env52869 = env52870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52869 == env52870) = true)

theorem identity52870 : scanCanonicalize (H12AffineFastState.compose env52870 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52870 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52871 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,8202,13340,2341,1025,21761,4112,33,8477,21762,8192,17,31756,13340,25613,2340,1285,33,257,21792,24845,513]

theorem envBound52871 : H12AffineFastState.Bounded env52871 := by
  intro p hp
  have h : env52871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52870_52871 : H12AffineEnvironment.transform 6 8 env52870 = env52871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52870 == env52871) = true)

theorem identity52871 : scanCanonicalize (H12AffineFastState.compose env52871 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52871 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52872 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,1,8202,13340,2341,1025,0,4112,33,8477,3,8192,17,10509,13340,12556,2340,1285,33,257,33,13324,513]

theorem envBound52872 : H12AffineFastState.Bounded env52872 := by
  intro p hp
  have h : env52872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52871_52872 : H12AffineEnvironment.transform 13 5377 env52871 = env52872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52871 == env52872) = true)

theorem identity52872 : scanCanonicalize (H12AffineFastState.compose env52872 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound52872 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52873 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,4096,8192,4388,1,8202,12345,2341,36,0,4112,33,8477,3,8192,17,10509,12345,12556,2340,288,33,257,33,12329,513]

theorem envBound52873 : H12AffineFastState.Bounded env52873 := by
  intro p hp
  have h : env52873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52872_52873 : H12AffineEnvironment.transform 9 37 env52872 = env52873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env52872 == env52873) = true)

theorem identity52873 : scanCanonicalize (H12AffineFastState.compose env52873 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound52873 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env52874 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,49,8192,277,1,8202,8200,2341,36,0,33,33,8477,3,8192,17,10509,8200,8509,2340,288,33,257,33,8216,513]

theorem envBound52874 : H12AffineFastState.Bounded env52874 := by
  intro p hp
  have h : env52874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52873_52874 : H12AffineEnvironment.transform 11 49 env52873 = env52874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52873 == env52874) = true)

theorem identity52874 : scanCanonicalize (H12AffineFastState.compose env52874 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound52874 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52875 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,49,2349,277,1,2343,2341,2341,36,0,33,33,2096,3,2349,17,32,2341,2064,2340,288,33,257,33,2357,513]

theorem envBound52875 : H12AffineFastState.Bounded env52875 := by
  intro p hp
  have h : env52875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52874_52875 : H12AffineEnvironment.transform 12 2349 env52874 = env52875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env52874 == env52875) = true)

theorem identity52875 : scanCanonicalize (H12AffineFastState.compose env52875 (packedSelected [2,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound52875 : packedSelected [2,10,15] rootPS < 2^1333 := by decide +kernel

def env52876 : List Nat := [2,4,8,16,32,16,8,256,512,37,33,49,268,277,1,262,260,260,36,0,33,33,17,3,268,17,32,260,49,261,288,33,257,33,276,513]

theorem envBound52876 : H12AffineFastState.Bounded env52876 := by
  intro p hp
  have h : env52876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52875_52876 : H12AffineEnvironment.transform 10 33 env52875 = env52876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env52875 == env52876) = true)

theorem identity52876 : scanCanonicalize (H12AffineFastState.compose env52876 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52877 : List Nat := [2,4,8,16,32,16,8,4,512,37,33,49,8,17,1,2,0,0,36,0,33,33,17,3,8,17,32,0,49,1,36,33,5,33,16,513]

theorem envBound52877 : H12AffineFastState.Bounded env52877 := by
  intro p hp
  have h : env52877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52876_52877 : H12AffineEnvironment.transform 7 4 env52876 = env52877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52876 == env52877) = true)

theorem identity52877 : scanCanonicalize (H12AffineFastState.compose env52877 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52877 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52878 : List Nat := [2,4,8,16,32,16,8,4,1,37,33,49,8,17,1,2,0,0,36,0,33,33,17,3,8,17,32,0,49,1,36,33,5,33,16,0]

theorem envBound52878 : H12AffineFastState.Bounded env52878 := by
  intro p hp
  have h : env52878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52877_52878 : H12AffineEnvironment.transform 8 1 env52877 = env52878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52877 == env52878) = true)

theorem identity52878 : scanCanonicalize (H12AffineFastState.compose env52878 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52878 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52879 : List Nat := [2,4,8,1,32,1,8,4,1,37,33,32,8,0,1,2,0,0,36,0,33,33,0,3,8,0,32,0,32,1,36,33,5,33,1,0]

theorem envBound52879 : H12AffineFastState.Bounded env52879 := by
  intro p hp
  have h : env52879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52878_52879 : H12AffineEnvironment.transform 3 1 env52878 = env52879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52878 == env52879) = true)

theorem identity52879 : scanCanonicalize (H12AffineFastState.compose env52879 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52880 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,1,8,0,1,2,0,0,5,0,0,0,0,3,8,0,1,0,1,1,5,0,5,0,1,0]

theorem envBound52880 : H12AffineFastState.Bounded env52880 := by
  intro p hp
  have h : env52880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52879_52880 : H12AffineEnvironment.transform 4 1 env52879 = env52880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52879 == env52880) = true)

theorem identity52880 : scanCanonicalize (H12AffineFastState.compose env52880 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52881 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,2,0,1,2,0,0,5,0,0,0,0,3,2,0,1,0,1,1,5,0,5,0,1,0]

theorem envBound52881 : H12AffineFastState.Bounded env52881 := by
  intro p hp
  have h : env52881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52880_52881 : H12AffineEnvironment.transform 2 2 env52880 = env52881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52880 == env52881) = true)

def env52882 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56356,1025,32769,4113,33,119966,21762,8328,16,171416,115103,102798,247994,1420,73891,257,21792,46213,74251]

theorem envBound52882 : H12AffineFastState.Bounded env52882 := by
  intro p hp
  have h : env52882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52866_52882 : H12AffineEnvironment.transform 5 17 env52866 = env52882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52866 == env52882) = true)

theorem identity52882 : scanCanonicalize (H12AffineFastState.compose env52882 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound52882 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env52883 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,57629,56356,1025,32769,4113,33,119966,21762,8328,16,31877,115103,102798,76199,1420,73891,257,21792,46213,74251]

theorem envBound52883 : H12AffineFastState.Bounded env52883 := by
  intro p hp
  have h : env52883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52882_52883 : H12AffineEnvironment.transform 16 57629 env52882 = env52883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env52882 == env52883) = true)

theorem identity52883 : scanCanonicalize (H12AffineFastState.compose env52883 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound52883 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env52884 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,65536,5392,10281,1025,29708,4113,33,73875,21762,8328,16,31877,79250,91523,76199,1420,73891,257,21792,16520,74251]

theorem envBound52884 : H12AffineFastState.Bounded env52884 := by
  intro p hp
  have h : env52884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52883_52884 : H12AffineEnvironment.transform 14 29709 env52883 = env52884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env52883 == env52884) = true)

theorem identity52884 : scanCanonicalize (H12AffineFastState.compose env52884 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52884 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env52885 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8461,65536,5392,10281,1025,8460,4113,33,73875,2,8328,16,10629,79250,77955,76199,1420,73891,257,32,5512,74251]

theorem envBound52885 : H12AffineFastState.Bounded env52885 := by
  intro p hp
  have h : env52885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52884_52885 : H12AffineEnvironment.transform 13 5376 env52884 = env52885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52884 == env52885) = true)

theorem identity52885 : scanCanonicalize (H12AffineFastState.compose env52885 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52885 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52886 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,0,65536,5392,2340,1025,1,4113,33,65950,2,389,16,2184,70815,70030,67754,1420,65966,257,32,5512,66310]

theorem envBound52886 : H12AffineFastState.Bounded env52886 := by
  intro p hp
  have h : env52886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52885_52886 : H12AffineEnvironment.transform 12 269 env52885 = env52886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52885 == env52886) = true)

theorem identity52886 : scanCanonicalize (H12AffineFastState.compose env52886 (packedSelected [1,3,5,8,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound52886 : packedSelected [1,3,5,8,14,16,17] rootPS < 2^1333 := by decide +kernel

def env52887 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,33,152,2,389,16,2184,5529,4232,2476,1420,168,257,32,5512,512]

theorem envBound52887 : H12AffineFastState.Bounded env52887 := by
  intro p hp
  have h : env52887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52886_52887 : H12AffineEnvironment.transform 15 262 env52886 = env52887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env52886 == env52887) = true)

theorem identity52887 : scanCanonicalize (H12AffineFastState.compose env52887 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52887 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52888 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,33,49,2,300,16,2081,5424,4129,2309,1317,1,257,32,5409,512]

theorem envBound52888 : H12AffineFastState.Bounded env52888 := by
  intro p hp
  have h : env52888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52887_52888 : H12AffineEnvironment.transform 6 41 env52887 = env52888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52887 == env52888) = true)

theorem identity52888 : scanCanonicalize (H12AffineFastState.compose env52888 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound52888 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52889 : List Nat := [2,4,8,16,32,17,41,256,512,305,2048,4096,269,4145,0,262,4129,2340,304,1,4113,33,49,2,300,16,2081,4097,4129,2309,20,1,257,32,4112,512]

theorem envBound52889 : H12AffineFastState.Bounded env52889 := by
  intro p hp
  have h : env52889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52888_52889 : H12AffineEnvironment.transform 9 305 env52888 = env52889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env52888 == env52889) = true)

theorem identity52889 : scanCanonicalize (H12AffineFastState.compose env52889 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound52889 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52890 : List Nat := [2,4,8,16,32,17,41,256,512,305,523,4096,269,4145,0,262,4129,815,304,1,4113,33,49,2,300,16,554,4097,4129,782,20,1,257,32,4112,512]

theorem envBound52890 : H12AffineFastState.Bounded env52890 := by
  intro p hp
  have h : env52890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52889_52890 : H12AffineEnvironment.transform 10 523 env52889 = env52890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env52889 == env52890) = true)

theorem identity52890 : scanCanonicalize (H12AffineFastState.compose env52890 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52890 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env52891 : List Nat := [2,4,8,16,32,17,41,37,512,20,523,4096,40,4145,0,35,4129,522,21,1,4113,33,49,2,9,16,554,4097,4129,555,20,1,36,32,4112,512]

theorem envBound52891 : H12AffineFastState.Bounded env52891 := by
  intro p hp
  have h : env52891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52890_52891 : H12AffineEnvironment.transform 7 37 env52890 = env52891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52890 == env52891) = true)

theorem identity52891 : scanCanonicalize (H12AffineFastState.compose env52891 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound52891 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52892 : List Nat := [2,4,8,16,32,17,41,37,29,20,22,4096,40,4145,0,35,4129,23,21,1,4113,33,49,2,9,16,55,4097,4129,54,20,1,36,32,4112,29]

theorem envBound52892 : H12AffineFastState.Bounded env52892 := by
  intro p hp
  have h : env52892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52891_52892 : H12AffineEnvironment.transform 8 29 env52891 = env52892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env52891 == env52892) = true)

theorem identity52892 : scanCanonicalize (H12AffineFastState.compose env52892 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound52892 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env52893 : List Nat := [2,4,8,16,31,17,22,26,29,20,22,4096,23,4110,0,28,4126,23,21,1,4113,30,14,2,9,16,8,4097,4126,9,20,1,27,31,4112,29]

theorem envBound52893 : H12AffineFastState.Bounded env52893 := by
  intro p hp
  have h : env52893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52892_52893 : H12AffineEnvironment.transform 4 31 env52892 = env52893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env52892 == env52893) = true)

def env52894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,8388608,8487372,8328,65,4365752,8393985,8406289,8526965,1500,12645453,257,21792,46213,74250]

theorem envBound52894 : H12AffineFastState.Bounded env52894 := by
  intro p hp
  have h : env52894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52841_52894 : H12AffineEnvironment.transform 20 4161 env52841 = env52894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52841 == env52894) = true)

def env52895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,8388608,8487372,8328,65,171416,8393985,8406289,8526965,1500,8451181,257,21792,46213,74250]

theorem envBound52895 : H12AffineFastState.Bounded env52895 := by
  intro p hp
  have h : env52895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52894_52895 : H12AffineEnvironment.transform 21 32 env52894 = env52895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52894 == env52895) = true)

theorem identity52895 : scanCanonicalize (H12AffineFastState.compose env52895 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52895 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4161,32,8388608,8430023,8328,65,171416,8393985,8406289,8526965,1500,8451181,257,21792,46213,513]

theorem envBound52896 : H12AffineFastState.Bounded env52896 := by
  intro p hp
  have h : env52896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52895_52896 : H12AffineEnvironment.transform 15 8203 env52895 = env52896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52895 == env52896) = true)

def env52897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4161,32,8388608,8430023,8328,65,56712,8393985,8406289,8412261,1500,8451181,257,21792,46213,513]

theorem envBound52897 : H12AffineFastState.Bounded env52897 := by
  intro p hp
  have h : env52897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52896_52897 : H12AffineEnvironment.transform 16 16400 env52896 = env52897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52896 == env52897) = true)

def env52898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4161,32,20480,61895,8328,65,56712,17665,5393,3173,1500,42093,257,21792,46213,513]

theorem envBound52898 : H12AffineFastState.Bounded env52898 := by
  intro p hp
  have h : env52898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52897_52898 : H12AffineEnvironment.transform 22 20480 env52897 = env52898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env52897 == env52898) = true)

theorem identity52898 : scanCanonicalize (H12AffineFastState.compose env52898 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9365) := by decide +kernel

theorem selectedBound52898 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9365,8203,16400,30944,1025,9364,4161,32,20480,21842,8328,65,31005,17665,5393,3173,1500,248,257,21792,4112,513]

theorem envBound52899 : H12AffineFastState.Bounded env52899 := by
  intro p hp
  have h : env52899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52898_52899 : H12AffineEnvironment.transform 14 9365 env52898 = env52899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9365 env52898 == env52899) = true)

theorem identity52899 : scanCanonicalize (H12AffineFastState.compose env52899 (packedSelected [0,1,3,7,20,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound52899 : packedSelected [0,1,3,7,20,24,28] rootPS < 2^1333 := by decide +kernel

def env52900 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,8661,8203,16400,30944,321,8660,4161,32,20480,20498,8328,65,31005,16449,4177,2341,156,248,257,20576,4112,513]

theorem envBound52900 : H12AffineFastState.Bounded env52900 := by
  intro p hp
  have h : env52900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52899_52900 : H12AffineEnvironment.transform 9 320 env52899 = env52900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52899 == env52900) = true)

theorem identity52900 : scanCanonicalize (H12AffineFastState.compose env52900 (packedSelected [0,1,5,7,8,18,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound52900 : packedSelected [0,1,5,7,8,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52901 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,8192,16384,8461,8203,16400,30776,321,8460,4161,32,20480,20498,8272,65,31005,16449,4177,2341,68,32,257,20576,4112,513]

theorem envBound52901 : H12AffineFastState.Bounded env52901 := by
  intro p hp
  have h : env52901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52900_52901 : H12AffineEnvironment.transform 6 88 env52900 = env52901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env52900 == env52901) = true)

theorem identity52901 : scanCanonicalize (H12AffineFastState.compose env52901 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound52901 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52902 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,8192,12620,8461,8203,12636,2420,321,8460,4161,32,8524,8542,8272,65,2129,12557,4177,2341,68,32,257,8492,4112,513]

theorem envBound52902 : H12AffineFastState.Bounded env52902 := by
  intro p hp
  have h : env52902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52901_52902 : H12AffineEnvironment.transform 13 12620 env52901 = env52902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env52901 == env52902) = true)

theorem identity52902 : scanCanonicalize (H12AffineFastState.compose env52902 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52902 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52903 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,349,4113,80,342,4097,2420,321,81,4161,32,17,3,269,65,2129,4176,4177,2341,68,32,257,113,4112,513]

theorem envBound52903 : H12AffineFastState.Bounded env52903 := by
  intro p hp
  have h : env52903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52902_52903 : H12AffineEnvironment.transform 12 349 env52902 = env52903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52902 == env52903) = true)

theorem identity52903 : scanCanonicalize (H12AffineFastState.compose env52903 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52903 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env52904 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,4096,41,4113,80,34,4097,2048,53,81,4161,32,17,3,121,65,2129,4176,4177,2129,68,32,117,113,4112,513]

theorem envBound52904 : H12AffineFastState.Bounded env52904 := by
  intro p hp
  have h : env52904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52903_52904 : H12AffineEnvironment.transform 7 116 env52903 = env52904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52903 == env52904) = true)

theorem identity52904 : scanCanonicalize (H12AffineFastState.compose env52904 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52904 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52905 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,1,34,4097,2048,53,0,4112,32,17,3,40,16,2048,4097,4096,2048,21,32,36,32,4112,513]

theorem envBound52905 : H12AffineFastState.Bounded env52905 := by
  intro p hp
  have h : env52905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52904_52905 : H12AffineEnvironment.transform 5 17 env52904 = env52905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52904 == env52905) = true)

theorem identity52905 : scanCanonicalize (H12AffineFastState.compose env52905 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound52905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52906 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,4096,41,4113,1,34,4097,529,53,0,4112,32,17,3,40,16,529,4097,4096,529,21,32,36,32,4112,513]

theorem envBound52906 : H12AffineFastState.Bounded env52906 := by
  intro p hp
  have h : env52906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52905_52906 : H12AffineEnvironment.transform 10 529 env52905 = env52906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env52905 == env52906) = true)

theorem identity52906 : scanCanonicalize (H12AffineFastState.compose env52906 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound52906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52907 : List Nat := [2,4,8,16,32,17,9,37,11,52,26,4096,41,4113,1,34,4097,26,53,0,4112,32,17,3,40,16,26,4097,4096,26,21,32,36,32,4112,10]

theorem envBound52907 : H12AffineFastState.Bounded env52907 := by
  intro p hp
  have h : env52907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52906_52907 : H12AffineEnvironment.transform 8 11 env52906 = env52907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env52906 == env52907) = true)

def env52908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4161,32,20481,61894,8328,65,56712,17664,5392,3172,1500,42092,257,21792,46213,513]

theorem envBound52908 : H12AffineFastState.Bounded env52908 := by
  intro p hp
  have h : env52908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52897_52908 : H12AffineEnvironment.transform 22 20481 env52897 = env52908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env52897 == env52908) = true)

theorem identity52908 : scanCanonicalize (H12AffineFastState.compose env52908 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound52908 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env52909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9244,8203,16400,30825,1025,9245,4161,32,20481,21978,8328,65,31124,17664,5392,3172,1500,112,257,21792,4249,513]

theorem envBound52909 : H12AffineFastState.Bounded env52909 := by
  intro p hp
  have h : env52909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52908_52909 : H12AffineEnvironment.transform 14 9244 env52908 = env52909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env52908 == env52909) = true)

theorem identity52909 : scanCanonicalize (H12AffineFastState.compose env52909 (packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52909 : packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0