import H12CloudChart0Data087

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity22241 : scanCanonicalize (H12AffineFastState.compose env22241 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22242 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,269,16384,0,262,16401,2341,20,1,16645,32,17,3,269,17,2048,16401,4096,2341,273,33,257,32,16385,513]

theorem envBound22242 : H12AffineFastState.Bounded env22242 := by
  intro p hp
  have h : env22242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22241_22242 : H12AffineEnvironment.transform 9 21 env22241 = env22242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22241 == env22242) = true)

theorem identity22242 : scanCanonicalize (H12AffineFastState.compose env22242 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound22242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22243 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,269,4372,0,262,4357,2341,20,1,4113,32,17,3,269,17,2048,4357,4096,2341,273,33,257,32,4373,513]

theorem envBound22243 : H12AffineFastState.Bounded env22243 := by
  intro p hp
  have h : env22243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22242_22243 : H12AffineEnvironment.transform 13 4372 env22242 = env22243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env22242 == env22243) = true)

theorem identity22243 : scanCanonicalize (H12AffineFastState.compose env22243 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound22243 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22244 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,561,269,805,0,262,820,2341,20,1,544,32,17,3,269,17,2048,820,561,2341,273,33,257,32,804,513]

theorem envBound22244 : H12AffineFastState.Bounded env22244 := by
  intro p hp
  have h : env22244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22243_22244 : H12AffineEnvironment.transform 11 561 env22243 = env22244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env22243 == env22244) = true)

theorem identity22244 : scanCanonicalize (H12AffineFastState.compose env22244 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound22244 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22245 : List Nat := [2,4,8,16,32,16,8,256,512,21,821,561,269,805,0,262,820,528,20,1,544,32,17,3,269,17,821,820,561,528,273,33,257,32,804,513]

theorem envBound22245 : H12AffineFastState.Bounded env22245 := by
  intro p hp
  have h : env22245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22244_22245 : H12AffineEnvironment.transform 10 821 env22244 = env22245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env22244 == env22245) = true)

theorem identity22245 : scanCanonicalize (H12AffineFastState.compose env22245 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22245 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22246 : List Nat := [2,4,8,16,32,16,8,37,512,21,528,561,40,512,0,35,529,528,20,1,544,32,17,3,40,17,528,529,561,528,52,33,36,32,513,513]

theorem envBound22246 : H12AffineFastState.Bounded env22246 := by
  intro p hp
  have h : env22246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22245_22246 : H12AffineEnvironment.transform 7 37 env22245 = env22246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22245 == env22246) = true)

theorem identity22246 : scanCanonicalize (H12AffineFastState.compose env22246 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22246 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22247 : List Nat := [2,4,8,16,0,16,8,5,512,21,528,529,8,512,0,3,529,528,20,1,512,0,17,3,8,17,528,529,529,528,20,1,4,0,513,513]

theorem envBound22247 : H12AffineFastState.Bounded env22247 := by
  intro p hp
  have h : env22247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22246_22247 : H12AffineEnvironment.transform 4 0 env22246 = env22247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22246 == env22247) = true)

theorem identity22247 : scanCanonicalize (H12AffineFastState.compose env22247 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22248 : List Nat := [2,4,8,1,0,1,8,5,512,4,513,512,8,512,0,3,512,513,5,1,512,0,0,3,8,0,513,512,512,513,5,1,4,0,513,513]

theorem envBound22248 : H12AffineFastState.Bounded env22248 := by
  intro p hp
  have h : env22248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22247_22248 : H12AffineEnvironment.transform 3 1 env22247 = env22248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22247 == env22248) = true)

def env22249 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114834,8192,16,215318,114966,45324,2231332,75022,73770,257,2188602,2196502,513]

theorem envBound22249 : H12AffineFastState.Bounded env22249 := by
  intro p hp
  have h : env22249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22235_22249 : H12AffineEnvironment.transform 5 17 env22235 = env22249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22235 == env22249) = true)

theorem identity22249 : scanCanonicalize (H12AffineFastState.compose env22249 (packedSelected [14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound22249 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env22250 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33030,131072,10280,1025,32769,2097152,32,2155532,2114834,8192,16,182288,16400,45324,2231332,41992,41260,257,2155580,2098448,513]

theorem envBound22250 : H12AffineFastState.Bounded env22250 := by
  intro p hp
  have h : env22250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22249_22250 : H12AffineEnvironment.transform 15 33030 env22249 = env22250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env22249 == env22250) = true)

theorem identity22250 : scanCanonicalize (H12AffineFastState.compose env22250 (packedSelected [11,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22250 : packedSelected [11,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22251 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33030,131072,2341,1025,32769,2097152,32,2147585,2114834,269,16,182288,16400,36865,2231332,34053,32801,257,2147633,2098448,513]

theorem envBound22251 : H12AffineFastState.Bounded env22251 := by
  intro p hp
  have h : env22251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22250_22251 : H12AffineEnvironment.transform 12 269 env22250 = env22251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22250 == env22251) = true)

theorem identity22251 : scanCanonicalize (H12AffineFastState.compose env22251 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22251 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22252 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,131072,2341,1025,1,2097152,32,2114817,2114834,269,16,149520,16400,4097,2231332,1285,33,257,2114865,2098448,513]

theorem envBound22252 : H12AffineFastState.Bounded env22252 := by
  intro p hp
  have h : env22252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22251_22252 : H12AffineEnvironment.transform 14 0 env22251 = env22252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22251 == env22252) = true)

def env22253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155532,2114883,8192,65,215366,115015,45405,2231332,75103,73771,257,2188651,2196551,513]

theorem envBound22253 : H12AffineFastState.Bounded env22253 := by
  intro p hp
  have h : env22253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22234_22253 : H12AffineEnvironment.transform 21 33 env22234 = env22253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22234 == env22253) = true)

theorem identity22253 : scanCanonicalize (H12AffineFastState.compose env22253 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound22253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58397,33,17,41310,8192,65,215366,115015,45405,190521,75103,73771,257,98678,90202,513]

theorem envBound22254 : H12AffineFastState.Bounded env22254 := by
  intro p hp
  have h : env22254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22253_22254 : H12AffineEnvironment.transform 20 58397 env22253 = env22254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env22253 == env22254) = true)

theorem identity22254 : scanCanonicalize (H12AffineFastState.compose env22254 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22254 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env22255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,33,17,41310,8192,65,67927,115015,45405,43048,75103,73771,257,98678,90202,513]

theorem envBound22255 : H12AffineFastState.Bounded env22255 := by
  intro p hp
  have h : env22255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22254_22255 : H12AffineEnvironment.transform 16 16401 env22254 = env22255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22254 == env22255) = true)

theorem identity22255 : scanCanonicalize (H12AffineFastState.compose env22255 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound22255 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env22256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8283,16401,10280,1025,32769,58397,33,17,41310,8192,65,10508,57628,45405,43048,1284,112,257,41261,16385,513]

theorem envBound22256 : H12AffineFastState.Bounded env22256 := by
  intro p hp
  have h : env22256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22255_22256 : H12AffineEnvironment.transform 15 8283 env22255 = env22256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env22255 == env22256) = true)

theorem identity22256 : scanCanonicalize (H12AffineFastState.compose env22256 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound22256 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8283,16401,10280,1025,80,25676,33,17,8463,8192,65,10508,24909,12556,10361,1284,112,257,8572,16385,513]

theorem envBound22257 : H12AffineFastState.Bounded env22257 := by
  intro p hp
  have h : env22257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22256_22257 : H12AffineEnvironment.transform 14 81 env22256 = env22257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env22256 == env22257) = true)

theorem identity22257 : scanCanonicalize (H12AffineFastState.compose env22257 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22257 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,81,263,16401,2420,1025,80,17680,33,17,83,348,65,2128,16401,4176,2341,1284,112,257,32,16385,513]

theorem envBound22258 : H12AffineFastState.Bounded env22258 := by
  intro p hp
  have h : env22258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22257_22258 : H12AffineEnvironment.transform 12 348 env22257 = env22258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22257 == env22258) = true)

def env22259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155533,2114882,8192,65,4409703,115014,45404,2231333,75103,4268043,257,2188651,2196551,513]

theorem envBound22259 : H12AffineFastState.Bounded env22259 := by
  intro p hp
  have h : env22259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22233_22259 : H12AffineEnvironment.transform 22 2155533 env22233 = env22259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env22233 == env22259) = true)

def env22260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114882,8192,65,215367,115014,45404,2231333,75103,73771,257,2188651,2196551,513]

theorem envBound22260 : H12AffineFastState.Bounded env22260 := by
  intro p hp
  have h : env22260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22259_22260 : H12AffineEnvironment.transform 21 32 env22259 = env22260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22259 == env22260) = true)

theorem identity22260 : scanCanonicalize (H12AffineFastState.compose env22260 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound22260 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,73754,98645,8192,65,215367,115014,45404,247858,75103,73771,257,41340,16464,513]

theorem envBound22261 : H12AffineFastState.Bounded env22261 := by
  intro p hp
  have h : env22261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22260_22261 : H12AffineEnvironment.transform 20 115735 env22260 = env22261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env22260 == env22261) = true)

theorem identity22261 : scanCanonicalize (H12AffineFastState.compose env22261 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22261 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env22262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115735,32,73754,98645,8192,65,67926,115014,45404,100387,75103,73771,257,41340,16464,513]

theorem envBound22262 : H12AffineFastState.Bounded env22262 := by
  intro p hp
  have h : env22262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22261_22262 : H12AffineEnvironment.transform 16 16401 env22261 = env22262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22261 == env22262) = true)

theorem identity22262 : scanCanonicalize (H12AffineFastState.compose env22262 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22262 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,58396,32,17,41310,8192,65,10589,57677,45404,43048,1364,32,257,41340,16464,513]

theorem envBound22263 : H12AffineFastState.Bounded env22263 := by
  intro p hp
  have h : env22263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22262_22263 : H12AffineEnvironment.transform 15 8203 env22262 = env22263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22262 == env22263) = true)

theorem identity22263 : scanCanonicalize (H12AffineFastState.compose env22263 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound22263 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8203,16401,10280,1025,80,25677,32,17,8463,8192,65,10589,24860,12557,10361,1364,32,257,8493,16464,513]

theorem envBound22264 : H12AffineFastState.Bounded env22264 := by
  intro p hp
  have h : env22264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22263_22264 : H12AffineEnvironment.transform 14 81 env22263 = env22264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env22263 == env22264) = true)

theorem identity22264 : scanCanonicalize (H12AffineFastState.compose env22264 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22264 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,81,343,16401,2420,1025,80,17681,32,17,83,348,65,2049,16448,4177,2341,1364,32,257,113,16464,513]

theorem envBound22265 : H12AffineFastState.Bounded env22265 := by
  intro p hp
  have h : env22265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22264_22265 : H12AffineEnvironment.transform 12 348 env22264 = env22265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22264 == env22265) = true)

theorem identity22265 : scanCanonicalize (H12AffineFastState.compose env22265 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22265 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22266 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1025,1,17681,32,17,2,269,16,2049,16401,4096,2341,1285,32,257,32,16385,513]

theorem envBound22266 : H12AffineFastState.Bounded env22266 := by
  intro p hp
  have h : env22266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22265_22266 : H12AffineEnvironment.transform 5 17 env22265 = env22266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22265 == env22266) = true)

theorem identity22266 : scanCanonicalize (H12AffineFastState.compose env22266 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22267 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2309,1025,1,17681,0,17,2,269,16,2049,16401,4096,2309,1285,0,257,0,16385,513]

theorem envBound22267 : H12AffineFastState.Bounded env22267 := by
  intro p hp
  have h : env22267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22266_22267 : H12AffineEnvironment.transform 4 0 env22266 = env22267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22266 == env22267) = true)

theorem identity22267 : scanCanonicalize (H12AffineFastState.compose env22267 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22267 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22268 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,16,269,16384,0,262,16401,2309,1025,1,17681,0,17,2,269,16,2049,16401,16,2309,1285,0,257,0,16385,513]

theorem envBound22268 : H12AffineFastState.Bounded env22268 := by
  intro p hp
  have h : env22268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22267_22268 : H12AffineEnvironment.transform 11 16 env22267 = env22268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22267 == env22268) = true)

theorem identity22268 : scanCanonicalize (H12AffineFastState.compose env22268 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound22268 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22269 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,16,269,1809,0,262,1792,2309,1025,1,512,0,17,2,269,16,2049,1792,16,2309,1285,0,257,0,1808,513]

theorem envBound22269 : H12AffineFastState.Bounded env22269 := by
  intro p hp
  have h : env22269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22268_22269 : H12AffineEnvironment.transform 13 1809 env22268 = env22269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env22268 == env22269) = true)

theorem identity22269 : scanCanonicalize (H12AffineFastState.compose env22269 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound22269 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22270 : List Nat := [2,4,8,16,0,17,8,256,512,1024,528,16,269,1809,0,262,1792,789,1025,1,512,0,17,2,269,16,529,1792,16,789,1285,0,257,0,1808,513]

theorem envBound22270 : H12AffineFastState.Bounded env22270 := by
  intro p hp
  have h : env22270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22269_22270 : H12AffineEnvironment.transform 10 528 env22269 = env22270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env22269 == env22270) = true)

theorem identity22270 : scanCanonicalize (H12AffineFastState.compose env22270 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound22270 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22271 : List Nat := [2,4,8,16,0,17,8,256,512,257,528,16,269,528,0,262,513,789,256,1,512,0,17,2,269,16,529,513,16,789,4,0,257,0,529,513]

theorem envBound22271 : H12AffineFastState.Bounded env22271 := by
  intro p hp
  have h : env22271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22270_22271 : H12AffineEnvironment.transform 9 257 env22270 = env22271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env22270 == env22271) = true)

theorem identity22271 : scanCanonicalize (H12AffineFastState.compose env22271 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound22271 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22272 : List Nat := [2,4,8,16,0,17,8,256,261,257,277,16,269,277,0,262,260,16,256,1,261,0,17,2,269,16,276,260,16,16,4,0,257,0,276,260]

theorem envBound22272 : H12AffineFastState.Bounded env22272 := by
  intro p hp
  have h : env22272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22271_22272 : H12AffineEnvironment.transform 8 261 env22271 = env22272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env22271 == env22272) = true)

def env22273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155533,2114882,8192,65,215366,115014,45404,2231333,75103,73770,257,2188651,2196551,513]

theorem envBound22273 : H12AffineFastState.Bounded env22273 := by
  intro p hp
  have h : env22273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22259_22273 : H12AffineEnvironment.transform 21 33 env22259 = env22273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22259 == env22273) = true)

theorem identity22273 : scanCanonicalize (H12AffineFastState.compose env22273 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22273 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,2097152,33,2155533,2114882,8192,65,158029,57677,45404,2231333,1364,33,257,2114912,2139212,513]

theorem envBound22274 : H12AffineFastState.Bounded env22274 := by
  intro p hp
  have h : env22274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22273_22274 : H12AffineEnvironment.transform 15 8203 env22273 = env22274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22273 == env22274) = true)

theorem identity22274 : scanCanonicalize (H12AffineFastState.compose env22274 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 173148) := by decide +kernel

theorem selectedBound22274 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env22275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,173148,33,147537,188702,8192,65,158029,57677,45404,43129,1364,33,257,188732,131088,513]

theorem envBound22275 : H12AffineFastState.Bounded env22275 := by
  intro p hp
  have h : env22275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22274_22275 : H12AffineEnvironment.transform 20 173148 env22274 = env22275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173148 env22274 == env22275) = true)

theorem identity22275 : scanCanonicalize (H12AffineFastState.compose env22275 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound22275 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env22276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10280,1025,32769,50448,33,8477,32850,8192,65,2049,57677,45404,43129,1364,33,257,32880,24924,513]

theorem envBound22276 : H12AffineFastState.Bounded env22276 := by
  intro p hp
  have h : env22276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22275_22276 : H12AffineEnvironment.transform 16 24908 env22275 = env22276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env22275 == env22276) = true)

theorem identity22276 : scanCanonicalize (H12AffineFastState.compose env22276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16448,2340,1025,32769,50448,33,17,32850,268,65,2049,49217,36944,35189,1364,33,257,32880,16464,513]

theorem envBound22277 : H12AffineFastState.Bounded env22277 := by
  intro p hp
  have h : env22277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22276_22277 : H12AffineEnvironment.transform 12 268 env22276 = env22277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22276 == env22277) = true)

theorem identity22277 : scanCanonicalize (H12AffineFastState.compose env22277 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22277 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,0,263,16448,2340,1025,1,17680,33,17,82,268,65,2049,16449,4176,2421,1364,33,257,112,16464,513]

theorem envBound22278 : H12AffineFastState.Bounded env22278 := by
  intro p hp
  have h : env22278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22277_22278 : H12AffineEnvironment.transform 14 0 env22277 = env22278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22277 == env22278) = true)

theorem identity22278 : scanCanonicalize (H12AffineFastState.compose env22278 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22278 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22279 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16401,2340,1025,1,17680,33,17,3,268,16,2049,16400,4097,2340,1285,33,257,33,16385,513]

theorem envBound22279 : H12AffineFastState.Bounded env22279 := by
  intro p hp
  have h : env22279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22278_22279 : H12AffineEnvironment.transform 5 17 env22278 = env22279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22278 == env22279) = true)

theorem identity22279 : scanCanonicalize (H12AffineFastState.compose env22279 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound22279 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22280 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,0,263,4096,2340,1025,1,5377,33,17,3,268,16,2049,4097,4097,2340,1285,33,257,33,4112,513]

theorem envBound22280 : H12AffineFastState.Bounded env22280 := by
  intro p hp
  have h : env22280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22279_22280 : H12AffineEnvironment.transform 13 4113 env22279 = env22280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env22279 == env22280) = true)

theorem identity22280 : scanCanonicalize (H12AffineFastState.compose env22280 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound22280 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22281 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,309,268,292,0,263,309,2340,1025,1,1076,33,17,3,268,16,2049,308,308,2340,1285,33,257,33,293,513]

theorem envBound22281 : H12AffineFastState.Bounded env22281 := by
  intro p hp
  have h : env22281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22280_22281 : H12AffineEnvironment.transform 11 309 env22280 = env22281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env22280 == env22281) = true)

theorem identity22281 : scanCanonicalize (H12AffineFastState.compose env22281 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22281 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22282 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,17,40,0,0,35,17,2048,1025,1,1076,33,17,3,40,16,2049,16,16,2048,1057,33,37,33,1,513]

theorem envBound22282 : H12AffineFastState.Bounded env22282 := by
  intro p hp
  have h : env22282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22281_22282 : H12AffineEnvironment.transform 7 36 env22281 = env22282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22281 == env22282) = true)

theorem identity22282 : scanCanonicalize (H12AffineFastState.compose env22282 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound22282 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22283 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,17,40,0,0,35,17,1077,1025,1,1076,33,17,3,40,16,1076,16,16,1077,1057,33,37,33,1,513]

theorem envBound22283 : H12AffineFastState.Bounded env22283 := by
  intro p hp
  have h : env22283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22282_22283 : H12AffineEnvironment.transform 10 1077 env22282 = env22283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env22282 == env22283) = true)

theorem identity22283 : scanCanonicalize (H12AffineFastState.compose env22283 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22283 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22284 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,17,40,0,0,35,17,1,53,1,0,33,17,3,40,16,0,16,16,1,21,33,37,33,1,513]

theorem envBound22284 : H12AffineFastState.Bounded env22284 := by
  intro p hp
  have h : env22284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22283_22284 : H12AffineEnvironment.transform 9 52 env22283 = env22284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22283 == env22284) = true)

theorem identity22284 : scanCanonicalize (H12AffineFastState.compose env22284 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound22284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22285 : List Nat := [2,4,8,16,32,17,8,36,33,52,1,17,40,0,0,35,17,1,53,1,0,33,17,3,40,16,0,16,16,1,21,33,37,33,1,32]

theorem envBound22285 : H12AffineFastState.Bounded env22285 := by
  intro p hp
  have h : env22285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22284_22285 : H12AffineEnvironment.transform 8 33 env22284 = env22285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env22284 == env22285) = true)

theorem identity22285 : scanCanonicalize (H12AffineFastState.compose env22285 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22286 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,17,9,0,0,2,17,1,20,1,0,0,17,3,9,16,0,16,16,1,21,0,4,0,1,1]

theorem envBound22286 : H12AffineFastState.Bounded env22286 := by
  intro p hp
  have h : env22286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22285_22286 : H12AffineEnvironment.transform 4 1 env22285 = env22286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22285 == env22286) = true)

def env22287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616169,18973701,10507601,8579113,25265168,23160136,257,27378725,27337992,25207631]

theorem envBound22287 : H12AffineFastState.Bounded env22287 := by
  intro p hp
  have h : env22287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22231_22287 : H12AffineEnvironment.transform 6 9 env22231 = env22287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22231 == env22287) = true)

theorem identity22287 : scanCanonicalize (H12AffineFastState.compose env22287 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound22287 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,8388626,8193,65,4450363,10585111,10507601,8579113,99330,14771546,257,2212919,2172186,41821]

theorem envBound22288 : H12AffineFastState.Bounded env22288 := by
  intro p hp
  have h : env22288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22287_22288 : H12AffineEnvironment.transform 23 8388626 env22287 = env22288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env22287 == env22288) = true)

theorem identity22288 : scanCanonicalize (H12AffineFastState.compose env22288 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound22288 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env22289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,2097152,4194304,8388608,8388626,8193,65,4229153,10585111,10507601,8489011,99330,14771546,257,2212919,2172186,41821]

theorem envBound22289 : H12AffineFastState.Bounded env22289 := by
  intro p hp
  have h : env22289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22288_22289 : H12AffineEnvironment.transform 16 90138 env22288 = env22289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env22288 == env22289) = true)

theorem identity22289 : scanCanonicalize (H12AffineFastState.compose env22289 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound22289 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,2097152,4194304,4194352,4194338,8193,65,4229153,6390823,6313313,4294659,99330,2188650,257,2212919,2172186,41821]

theorem envBound22290 : H12AffineFastState.Bounded env22290 := by
  intro p hp
  have h : env22290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22289_22290 : H12AffineEnvironment.transform 22 4194352 env22289 = env22290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env22289 == env22290) = true)

theorem identity22290 : scanCanonicalize (H12AffineFastState.compose env22290 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound22290 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1025,8541,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6313313,4270431,75102,2188650,257,2188651,2172186,513]

theorem envBound22291 : H12AffineFastState.Bounded env22291 := by
  intro p hp
  have h : env22291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22290_22291 : H12AffineEnvironment.transform 14 8540 env22290 = env22291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env22290 == env22291) = true)

theorem identity22291 : scanCanonicalize (H12AffineFastState.compose env22291 (packedSelected [2,4,6,9,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 19525) := by decide +kernel

theorem selectedBound22291 : packedSelected [2,4,6,9,17,18] rootPS < 2^1333 := by decide +kernel

def env22292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1025,8541,2097152,19525,19573,19559,8193,65,25912,2189630,2103588,91418,75102,2188650,257,2188651,2172186,513]

theorem envBound22292 : H12AffineFastState.Bounded env22292 := by
  intro p hp
  have h : env22292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22291_22292 : H12AffineEnvironment.transform 21 19525 env22291 = env22292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 19525 env22291 == env22292) = true)

theorem identity22292 : scanCanonicalize (H12AffineFastState.compose env22292 (packedSelected [3,5,10,11,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound22292 : packedSelected [3,5,10,11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env22293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28699,4097,10281,1025,8541,2097152,19525,19573,19559,8193,65,25912,2103589,2103588,5377,21829,2102641,257,2102640,2118913,513]

theorem envBound22293 : H12AffineFastState.Bounded env22293 := by
  intro p hp
  have h : env22293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22292_22293 : H12AffineEnvironment.transform 15 28699 env22292 = env22293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env22292 == env22293) = true)

theorem identity22293 : scanCanonicalize (H12AffineFastState.compose env22293 (packedSelected [0,3,5,8,9,10,12,14,17,24] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound22293 : packedSelected [0,3,5,8,9,10,12,14,17,24] rootPS < 2^1333 := by decide +kernel

def env22294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28699,4097,10281,1025,8541,5456,19525,19573,19559,8193,65,25912,3189,3188,5377,21829,33,257,32,16465,513]

theorem envBound22294 : H12AffineFastState.Bounded env22294 := by
  intro p hp
  have h : env22294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22293_22294 : H12AffineEnvironment.transform 20 5456 env22293 = env22294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env22293 == env22294) = true)

theorem identity22294 : scanCanonicalize (H12AffineFastState.compose env22294 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound22294 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4097,10281,1025,8541,5456,7253,7269,7287,8193,65,13608,3189,3188,5377,1365,33,257,32,4161,513]

theorem envBound22295 : H12AffineFastState.Bounded env22295 := by
  intro p hp
  have h : env22295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22294_22295 : H12AffineEnvironment.transform 13 4112 env22294 = env22295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env22294 == env22295) = true)

theorem identity22295 : scanCanonicalize (H12AffineFastState.compose env22295 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22295 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1,342,4097,2420,1025,0,5456,7253,7269,7287,348,65,5237,3189,3188,5377,1365,33,257,32,4161,513]

theorem envBound22296 : H12AffineFastState.Bounded env22296 := by
  intro p hp
  have h : env22296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22295_22296 : H12AffineEnvironment.transform 12 349 env22295 = env22296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22295 == env22296) = true)

theorem identity22296 : scanCanonicalize (H12AffineFastState.compose env22296 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound22296 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,349,2128,1,342,2113,2420,1025,0,3344,1045,1061,1079,348,65,3125,3189,3188,3393,1365,33,257,32,2049,513]

theorem envBound22297 : H12AffineFastState.Bounded env22297 := by
  intro p hp
  have h : env22297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22296_22297 : H12AffineEnvironment.transform 11 2112 env22296 = env22297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env22296 == env22297) = true)

theorem identity22297 : scanCanonicalize (H12AffineFastState.compose env22297 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22297 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22298 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,269,2048,1,262,2065,2340,1025,0,3344,1045,1061,1079,268,17,3125,3109,3108,3345,1285,33,257,32,2049,513]

theorem envBound22298 : H12AffineFastState.Bounded env22298 := by
  intro p hp
  have h : env22298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22297_22298 : H12AffineEnvironment.transform 5 16 env22297 = env22298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22297 == env22298) = true)

theorem identity22298 : scanCanonicalize (H12AffineFastState.compose env22298 (packedSelected [1,4,5,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22298 : packedSelected [1,4,5,7,15] rootPS < 2^1333 := by decide +kernel

def env22299 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,269,2048,1,262,2065,2340,53,0,2340,33,17,3,268,17,2049,2065,2064,2341,305,33,257,32,2049,513]

theorem envBound22299 : H12AffineFastState.Bounded env22299 := by
  intro p hp
  have h : env22299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22298_22299 : H12AffineEnvironment.transform 9 52 env22298 = env22299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22298 == env22299) = true)

theorem identity22299 : scanCanonicalize (H12AffineFastState.compose env22299 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound22299 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22300 : List Nat := [2,4,8,16,32,16,9,256,512,52,303,319,269,303,1,262,318,11,53,0,11,33,17,3,268,17,302,318,319,10,305,33,257,32,302,513]

theorem envBound22300 : H12AffineFastState.Bounded env22300 := by
  intro p hp
  have h : env22300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22299_22300 : H12AffineEnvironment.transform 10 303 env22299 = env22300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env22299 == env22300) = true)

def env22301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound22301 : H12AffineFastState.Bounded env22301 := by
  intro p hp
  have h : env22301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20773_22301 : H12AffineEnvironment.transform 29 155254785 env20773 = env22301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env20773 == env22301) = true)

def env22302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound22302 : H12AffineFastState.Bounded env22302 := by
  intro p hp
  have h : env22302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22301_22302 : H12AffineEnvironment.transform 25 64 env22301 = env22302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env22301 == env22302) = true)

def env22303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound22303 : H12AffineFastState.Bounded env22303 := by
  intro p hp
  have h : env22303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22302_22303 : H12AffineEnvironment.transform 26 30393344 env22302 = env22303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env22302 == env22303) = true)

def env22304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound22304 : H12AffineFastState.Bounded env22304 := by
  intro p hp
  have h : env22304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22303_22304 : H12AffineEnvironment.transform 18 1024 env22303 = env22304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22303 == env22304) = true)

theorem identity22304 : scanCanonicalize (H12AffineFastState.compose env22304 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577360) := by decide +kernel

theorem selectedBound22304 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577360,8328,64,6727120,8446301,10507600,8830977,2154945,12582928,256,41340,16600,2213399]

theorem envBound22305 : H12AffineFastState.Bounded env22305 := by
  intro p hp
  have h : env22305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22304_22305 : H12AffineEnvironment.transform 23 10577360 env22304 = env22305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577360 env22304 == env22305) = true)

def env22306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,8388608,10577360,8328,64,6705548,8393985,10507600,8795229,2102685,12582928,256,21792,16600,2175563]

theorem envBound22306 : H12AffineFastState.Bounded env22306 := by
  intro p hp
  have h : env22306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22305_22306 : H12AffineEnvironment.transform 14 29788 env22305 = env22306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env22305 == env22306) = true)

def env22307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114896,73856,8328,64,6705548,2117713,4096,2519309,2102685,6309184,256,21792,16600,2175563]

theorem envBound22307 : H12AffineFastState.Bounded env22307 := by
  intro p hp
  have h : env22307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22306_22307 : H12AffineEnvironment.transform 22 2114896 env22306 = env22307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env22306 == env22307) = true)

def env22308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73856,8328,64,4592844,5393,4096,406605,20701,4194304,256,21792,16600,96011]

theorem envBound22308 : H12AffineFastState.Bounded env22308 := by
  intro p hp
  have h : env22308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22307_22308 : H12AffineEnvironment.transform 20 17728 env22307 = env22308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env22307 == env22308) = true)

theorem identity22308 : scanCanonicalize (H12AffineFastState.compose env22308 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22308 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73736,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,96011]

theorem envBound22309 : H12AffineFastState.Bounded env22309 := by
  intro p hp
  have h : env22309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22308_22309 : H12AffineEnvironment.transform 6 8 env22308 = env22309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22308 == env22309) = true)

theorem identity22309 : scanCanonicalize (H12AffineFastState.compose env22309 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound22309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound22310 : H12AffineFastState.Bounded env22310 := by
  intro p hp
  have h : env22310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22309_22310 : H12AffineEnvironment.transform 15 29962 env22309 = env22310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env22309 == env22310) = true)

def env22311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29788,29962,131072,262144,1024,29789,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound22311 : H12AffineFastState.Bounded env22311 := by
  intro p hp
  have h : env22311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22310_22311 : H12AffineEnvironment.transform 10 0 env22310 = env22311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22310 == env22311) = true)

theorem identity22311 : scanCanonicalize (H12AffineFastState.compose env22311 (packedSelected [4,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 147765) := by decide +kernel

theorem selectedBound22311 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29788,29962,131072,147765,1024,29789,17728,4194304,16,21762,8192,64,4216177,5393,4096,30072,20565,4194304,256,21792,16464,513]

theorem envBound22312 : H12AffineFastState.Bounded env22312 := by
  intro p hp
  have h : env22312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22311_22312 : H12AffineEnvironment.transform 17 147765 env22311 = env22312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 147765 env22311 == env22312) = true)

theorem identity22312 : scanCanonicalize (H12AffineFastState.compose env22312 (packedSelected [0,1,2,3,6,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22312 : packedSelected [0,1,2,3,6,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env22313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29788,29962,5392,21541,1024,29789,17728,4194304,16,21762,8192,64,4216177,5393,4096,30072,20565,4194304,256,21792,16464,513]

theorem envBound22313 : H12AffineFastState.Bounded env22313 := by
  intro p hp
  have h : env22313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22312_22313 : H12AffineEnvironment.transform 16 5392 env22312 = env22313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22312 == env22313) = true)

theorem identity22313 : scanCanonicalize (H12AffineFastState.compose env22313 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound22313 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,13324,80,262,5392,8233,1024,81,12620,4194304,16,8462,8192,64,4202877,5393,4096,372,9305,4194304,256,8492,13404,513]

theorem envBound22314 : H12AffineFastState.Bounded env22314 := by
  intro p hp
  have h : env22314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22313_22314 : H12AffineEnvironment.transform 13 13324 env22313 = env22314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env22313 == env22314) = true)

theorem identity22314 : scanCanonicalize (H12AffineFastState.compose env22314 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound22314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,13324,80,262,5392,8233,1024,81,12620,8492,16,8462,8192,64,81,5393,4096,372,9305,8492,256,8492,13404,513]

theorem envBound22315 : H12AffineFastState.Bounded env22315 := by
  intro p hp
  have h : env22315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22314_22315 : H12AffineEnvironment.transform 21 8492 env22314 = env22315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env22314 == env22315) = true)

theorem identity22315 : scanCanonicalize (H12AffineFastState.compose env22315 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound22315 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,41,5157,80,262,5392,0,1024,81,4453,261,16,295,41,64,81,5393,4096,372,1136,261,256,261,5237,513]

theorem envBound22316 : H12AffineFastState.Bounded env22316 := by
  intro p hp
  have h : env22316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22315_22316 : H12AffineEnvironment.transform 12 41 env22315 = env22316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env22315 == env22316) = true)

theorem identity22316 : scanCanonicalize (H12AffineFastState.compose env22316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22317 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,41,5157,80,115,5221,0,1024,81,4112,112,16,82,41,64,81,5220,4096,1,1136,112,117,112,5237,513]

theorem envBound22317 : H12AffineFastState.Bounded env22317 := by
  intro p hp
  have h : env22317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22316_22317 : H12AffineEnvironment.transform 7 117 env22316 = env22317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22316 == env22317) = true)

theorem identity22317 : scanCanonicalize (H12AffineFastState.compose env22317 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound22317 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env22318 : List Nat := [2,4,8,16,32,64,8,117,512,69,0,4096,41,4192,80,115,4128,0,69,81,4112,112,16,82,41,64,81,4129,4096,1,53,112,117,112,4144,513]

theorem envBound22318 : H12AffineFastState.Bounded env22318 := by
  intro p hp
  have h : env22318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22317_22318 : H12AffineEnvironment.transform 9 69 env22317 = env22318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env22317 == env22318) = true)

theorem identity22318 : scanCanonicalize (H12AffineFastState.compose env22318 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound22318 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env22319 : List Nat := [2,4,8,16,32,64,8,117,512,69,0,48,41,80,80,115,16,0,69,81,32,112,16,82,41,64,81,17,48,1,53,112,117,112,0,513]

theorem envBound22319 : H12AffineFastState.Bounded env22319 := by
  intro p hp
  have h : env22319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22318_22319 : H12AffineEnvironment.transform 11 48 env22318 = env22319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env22318 == env22319) = true)

theorem identity22319 : scanCanonicalize (H12AffineFastState.compose env22319 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound22319 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env22320 : List Nat := [2,4,8,16,32,31,8,42,512,26,0,48,41,15,15,44,16,0,26,14,32,47,16,13,41,31,14,17,48,1,53,47,42,47,0,513]

theorem envBound22320 : H12AffineFastState.Bounded env22320 := by
  intro p hp
  have h : env22320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22319_22320 : H12AffineEnvironment.transform 5 31 env22319 = env22320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env22319 == env22320) = true)

theorem identity22320 : scanCanonicalize (H12AffineFastState.compose env22320 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound22320 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22321 : List Nat := [2,4,8,16,14,31,8,4,512,26,0,30,7,15,15,2,16,0,26,14,14,1,16,13,7,31,14,17,30,1,27,1,4,1,0,513]

theorem envBound22321 : H12AffineFastState.Bounded env22321 := by
  intro p hp
  have h : env22321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22320_22321 : H12AffineEnvironment.transform 4 14 env22320 = env22321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env22320 == env22321) = true)

def env22322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29788,29962,131072,262144,1024,29789,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound22322 : H12AffineFastState.Bounded env22322 := by
  intro p hp
  have h : env22322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22310_22322 : H12AffineEnvironment.transform 10 1 env22310 = env22322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22310 == env22322) = true)

theorem identity22322 : scanCanonicalize (H12AffineFastState.compose env22322 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound22322 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29788,29962,24860,262144,1024,29789,17728,4194304,16,21762,8192,64,4486488,5393,4096,283985,20565,4194304,256,21792,16464,513]

theorem envBound22323 : H12AffineFastState.Bounded env22323 := by
  intro p hp
  have h : env22323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22322_22323 : H12AffineEnvironment.transform 16 24860 env22322 = env22323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env22322 == env22323) = true)

theorem identity22323 : scanCanonicalize (H12AffineFastState.compose env22323 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound22323 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29788,29962,24860,262144,1024,29789,17728,21792,16,21762,8192,64,270456,5393,4096,283985,20565,21792,256,21792,16464,513]

theorem envBound22324 : H12AffineFastState.Bounded env22324 := by
  intro p hp
  have h : env22324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22323_22324 : H12AffineEnvironment.transform 21 21792 env22323 = env22324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env22323 == env22324) = true)

theorem identity22324 : scanCanonicalize (H12AffineFastState.compose env22324 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 30072) := by decide +kernel

theorem selectedBound22324 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29788,29962,24860,30072,1024,29789,17728,21792,16,21762,8192,64,21760,5393,4096,8233,20565,21792,256,21792,16464,513]

theorem envBound22325 : H12AffineFastState.Bounded env22325 := by
  intro p hp
  have h : env22325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22324_22325 : H12AffineEnvironment.transform 17 30072 env22324 = env22325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30072 env22324 == env22325) = true)

theorem identity22325 : scanCanonicalize (H12AffineFastState.compose env22325 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22325 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env22326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,349,16384,21761,21591,16449,21541,1024,21760,17728,21792,16,21762,349,64,21760,5393,4096,372,20565,21792,256,21792,16464,513]

theorem envBound22326 : H12AffineFastState.Bounded env22326 := by
  intro p hp
  have h : env22326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22325_22326 : H12AffineEnvironment.transform 12 349 env22325 = env22326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22325 == env22326) = true)

def env22327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,17,73856,8328,64,4592845,5392,4096,406604,20700,4194305,256,21792,16600,96010]

theorem envBound22327 : H12AffineFastState.Bounded env22327 := by
  intro p hp
  have h : env22327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22307_22327 : H12AffineEnvironment.transform 20 17729 env22307 = env22327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env22307 == env22327) = true)

theorem identity22327 : scanCanonicalize (H12AffineFastState.compose env22327 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound22327 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,168,17,73856,8328,64,398437,5392,4096,406604,20700,169,256,21792,16600,96010]

theorem envBound22328 : H12AffineFastState.Bounded env22328 := by
  intro p hp
  have h : env22328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22327_22328 : H12AffineEnvironment.transform 21 168 env22327 = env22328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env22327 == env22328) = true)

theorem identity22328 : scanCanonicalize (H12AffineFastState.compose env22328 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound22328 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env22329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,17729,168,17,73856,8328,64,357502,5392,4096,349271,20700,169,256,21792,16600,96010]

theorem envBound22329 : H12AffineFastState.Bounded env22329 := by
  intro p hp
  have h : env22329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22328_22329 : H12AffineEnvironment.transform 16 90139 env22328 = env22329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env22328 == env22329) = true)

theorem identity22329 : scanCanonicalize (H12AffineFastState.compose env22329 (packedSelected [1,3,4,5,7,8,9,10,11,14,16,18,19,20,21,23,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22329 : packedSelected [1,3,4,5,7,8,9,10,11,14,16,18,19,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env22330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,17729,32,17,73736,8192,64,357502,5392,4096,349271,20564,33,256,21792,16464,96010]

theorem envBound22330 : H12AffineFastState.Bounded env22330 := by
  intro p hp
  have h : env22330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22329_22330 : H12AffineEnvironment.transform 6 8 env22329 = env22330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22329 == env22330) = true)

theorem identity22330 : scanCanonicalize (H12AffineFastState.compose env22330 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound22330 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,89378,1024,29789,17729,32,17,73736,8192,64,10588,5392,4096,2421,20564,33,256,21792,16464,96010]

theorem envBound22331 : H12AffineFastState.Bounded env22331 := by
  intro p hp
  have h : env22331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22330_22331 : H12AffineEnvironment.transform 17 89378 env22330 = env22331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env22330 == env22331) = true)

theorem identity22331 : scanCanonicalize (H12AffineFastState.compose env22331 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound22331 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env22332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8283,16448,32121,1024,29789,17729,32,17,83,8192,64,10588,5392,4096,2421,20564,33,256,21792,16464,22353]

theorem envBound22332 : H12AffineFastState.Bounded env22332 := by
  intro p hp
  have h : env22332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22331_22332 : H12AffineEnvironment.transform 15 8283 env22331 = env22332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env22331 == env22332) = true)

theorem identity22332 : scanCanonicalize (H12AffineFastState.compose env22332 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound22332 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8283,5392,10281,1024,8461,4113,32,17,83,8192,64,10588,5392,4096,2421,1284,33,256,112,5376,513]

theorem envBound22333 : H12AffineFastState.Bounded env22333 := by
  intro p hp
  have h : env22333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22332_22333 : H12AffineEnvironment.transform 13 5456 env22332 = env22333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env22332 == env22333) = true)

theorem identity22333 : scanCanonicalize (H12AffineFastState.compose env22333 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22333 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,80,263,5392,2421,1024,81,4113,32,17,83,348,64,2048,5392,4096,2421,1284,33,256,112,5376,513]

theorem envBound22334 : H12AffineFastState.Bounded env22334 := by
  intro p hp
  have h : env22334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22333_22334 : H12AffineEnvironment.transform 12 348 env22333 = env22334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22333 == env22334) = true)

def env22335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114897,73857,8328,64,6705548,2117712,4097,2519308,2102685,6309185,256,21792,16600,2175563]

theorem envBound22335 : H12AffineFastState.Bounded env22335 := by
  intro p hp
  have h : env22335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22306_22335 : H12AffineEnvironment.transform 22 2114897 env22306 = env22335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env22306 == env22335) = true)

def env22336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,17,73857,8328,64,4592844,5392,4097,406604,20701,4194305,256,21792,16600,96011]

theorem envBound22336 : H12AffineFastState.Bounded env22336 := by
  intro p hp
  have h : env22336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22335_22336 : H12AffineEnvironment.transform 20 17728 env22335 = env22336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env22335 == env22336) = true)

theorem identity22336 : scanCanonicalize (H12AffineFastState.compose env22336 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound22336 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,32,17,73857,8328,64,398572,5392,4097,406604,20701,33,256,21792,16600,96011]

theorem envBound22337 : H12AffineFastState.Bounded env22337 := by
  intro p hp
  have h : env22337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22336_22337 : H12AffineEnvironment.transform 21 32 env22336 = env22337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22336 == env22337) = true)

def env22338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,32,17,73857,8328,64,398572,5392,4097,406604,1501,33,256,32,5592,74251]

theorem envBound22338 : H12AffineFastState.Bounded env22338 := by
  intro p hp
  have h : env22338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22337_22338 : H12AffineEnvironment.transform 13 5376 env22337 = env22338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22337 == env22338) = true)

theorem identity22338 : scanCanonicalize (H12AffineFastState.compose env22338 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound22338 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67755,1024,8541,4160,32,17,73857,8328,64,203847,5392,4097,212199,1501,33,256,32,5592,74251]

theorem envBound22339 : H12AffineFastState.Bounded env22339 := by
  intro p hp
  have h : env22339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22338_22339 : H12AffineEnvironment.transform 17 67755 env22338 = env22339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env22338 == env22339) = true)

theorem identity22339 : scanCanonicalize (H12AffineFastState.compose env22339 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound22339 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,10281,1024,8541,4160,32,17,3,8328,64,146629,5392,4097,138341,1501,33,256,32,5592,649]

theorem envBound22340 : H12AffineFastState.Bounded env22340 := by
  intro p hp
  have h : env22340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22339_22340 : H12AffineEnvironment.transform 15 8322 env22339 = env22340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env22339 == env22340) = true)

theorem identity22340 : scanCanonicalize (H12AffineFastState.compose env22340 (packedSelected [0,2,7,11,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound22340 : packedSelected [0,2,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env22341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5577,10281,1024,8541,4160,32,17,3,8328,64,10508,5392,4097,2476,1501,33,256,32,5592,649]

theorem envBound22341 : H12AffineFastState.Bounded env22341 := by
  intro p hp
  have h : env22341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22340_22341 : H12AffineEnvironment.transform 16 5577 env22340 = env22341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env22340 == env22341) = true)

theorem identity22341 : scanCanonicalize (H12AffineFastState.compose env22341 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22341 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,81,399,5577,2340,1024,80,4160,32,17,3,389,64,2049,5392,4097,2476,1501,33,256,32,5592,649]

theorem envBound22342 : H12AffineFastState.Bounded env22342 := by
  intro p hp
  have h : env22342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22341_22342 : H12AffineEnvironment.transform 12 269 env22341 = env22342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22341 == env22342) = true)

theorem identity22342 : scanCanonicalize (H12AffineFastState.compose env22342 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22342 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,262,5440,2340,1024,80,4160,32,17,3,268,64,2049,5392,4097,2341,1364,33,256,32,5457,512]

theorem envBound22343 : H12AffineFastState.Bounded env22343 := by
  intro p hp
  have h : env22343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22342_22343 : H12AffineEnvironment.transform 6 9 env22342 = env22343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22342 == env22343) = true)

theorem identity22343 : scanCanonicalize (H12AffineFastState.compose env22343 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound22343 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22344 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,5205,81,83,5141,2161,1024,80,4160,32,17,3,89,64,2049,5189,4097,2160,1025,33,85,32,5124,512]

theorem envBound22344 : H12AffineFastState.Bounded env22344 := by
  intro p hp
  have h : env22344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22343_22344 : H12AffineEnvironment.transform 7 85 env22343 = env22344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env22343 == env22344) = true)

theorem identity22344 : scanCanonicalize (H12AffineFastState.compose env22344 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22344 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22345 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5125,1,3,5141,2081,1024,0,4112,32,17,3,9,16,2049,5141,4097,2080,1025,33,5,32,5124,512]

theorem envBound22345 : H12AffineFastState.Bounded env22345 := by
  intro p hp
  have h : env22345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22344_22345 : H12AffineEnvironment.transform 5 16 env22344 = env22345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22344 == env22345) = true)

theorem identity22345 : scanCanonicalize (H12AffineFastState.compose env22345 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22346 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5125,1,3,5141,2048,1024,0,4112,1,17,3,9,16,2049,5141,4097,2049,1025,0,5,1,5124,512]

theorem envBound22346 : H12AffineFastState.Bounded env22346 := by
  intro p hp
  have h : env22346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22345_22346 : H12AffineEnvironment.transform 4 1 env22345 = env22346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22345 == env22346) = true)

theorem identity22346 : scanCanonicalize (H12AffineFastState.compose env22346 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound22346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22347 : List Nat := [2,4,8,16,1,16,9,5,512,1024,522,4096,8,5125,1,3,5141,522,1024,0,4112,1,17,3,9,16,523,5141,4097,523,1025,0,5,1,5124,512]

theorem envBound22347 : H12AffineFastState.Bounded env22347 := by
  intro p hp
  have h : env22347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22346_22347 : H12AffineEnvironment.transform 10 522 env22346 = env22347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env22346 == env22347) = true)

def env22348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4161,32,17,73857,8328,64,398572,5392,4097,406604,1500,33,256,33,5593,74250]

theorem envBound22348 : H12AffineFastState.Bounded env22348 := by
  intro p hp
  have h : env22348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22337_22348 : H12AffineEnvironment.transform 13 5377 env22337 = env22348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22337 == env22348) = true)

theorem identity22348 : scanCanonicalize (H12AffineFastState.compose env22348 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound22348 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,67618,1024,8540,4161,32,17,73857,8328,64,203982,5392,4097,212078,1500,33,256,33,5593,74250]

theorem envBound22349 : H12AffineFastState.Bounded env22349 := by
  intro p hp
  have h : env22349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22348_22349 : H12AffineEnvironment.transform 17 67618 env22348 = env22349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env22348 == env22349) = true)

theorem identity22349 : scanCanonicalize (H12AffineFastState.compose env22349 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound22349 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env22350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,5441,67618,1024,8540,4161,32,17,73857,8328,64,67983,5392,4097,76079,1500,33,256,33,5593,74250]

theorem envBound22350 : H12AffineFastState.Bounded env22350 := by
  intro p hp
  have h : env22350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22349_22350 : H12AffineEnvironment.transform 16 5441 env22349 = env22350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env22349 == env22350) = true)

theorem identity22350 : scanCanonicalize (H12AffineFastState.compose env22350 (packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22350 : packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS < 2^1333 := by decide +kernel

def env22351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,65536,5441,67618,1024,0,4161,32,17,66013,468,64,67983,5392,4097,67699,1500,33,256,33,5593,66390]

theorem envBound22351 : H12AffineFastState.Bounded env22351 := by
  intro p hp
  have h : env22351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22350_22351 : H12AffineEnvironment.transform 12 348 env22350 = env22351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22350 == env22351) = true)

theorem identity22351 : scanCanonicalize (H12AffineFastState.compose env22351 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound22351 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,263,5441,2341,1024,0,4161,32,17,218,468,64,2184,5392,4097,2420,1500,33,256,33,5593,593]

theorem envBound22352 : H12AffineFastState.Bounded env22352 := by
  intro p hp
  have h : env22352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22351_22352 : H12AffineEnvironment.transform 15 263 env22351 = env22352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env22351 == env22352) = true)

theorem identity22352 : scanCanonicalize (H12AffineFastState.compose env22352 (packedSelected [0,1,3,4,5,7,8,9,11,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1417) := by decide +kernel

theorem selectedBound22352 : packedSelected [0,1,3,4,5,7,8,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env22353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1417,348,136,1,263,200,2341,1024,0,1480,32,17,218,468,64,2184,153,1416,2420,1500,33,256,33,80,593]

theorem envBound22353 : H12AffineFastState.Bounded env22353 := by
  intro p hp
  have h : env22353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22352_22353 : H12AffineEnvironment.transform 11 1417 env22352 = env22353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1417 env22352 == env22353) = true)

theorem identity22353 : scanCanonicalize (H12AffineFastState.compose env22353 (packedSelected [2,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound22353 : packedSelected [2,6,14] rootPS < 2^1333 := by decide +kernel

def env22354 : List Nat := [2,4,8,16,32,64,128,256,512,173,2048,292,348,136,1,263,200,2341,173,0,357,32,17,218,468,64,2184,153,293,2420,369,33,256,33,80,593]

theorem envBound22354 : H12AffineFastState.Bounded env22354 := by
  intro p hp
  have h : env22354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22353_22354 : H12AffineEnvironment.transform 9 173 env22353 = env22354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env22353 == env22354) = true)

theorem identity22354 : scanCanonicalize (H12AffineFastState.compose env22354 (packedSelected [0,2,3,5,6,7,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound22354 : packedSelected [0,2,3,5,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env22355 : List Nat := [2,4,8,16,32,64,128,256,512,173,428,292,348,136,1,263,200,137,173,0,357,32,17,218,468,64,292,153,293,216,369,33,256,33,80,593]

theorem envBound22355 : H12AffineFastState.Bounded env22355 := by
  intro p hp
  have h : env22355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22354_22355 : H12AffineEnvironment.transform 10 428 env22354 = env22355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env22354 == env22355) = true)

theorem identity22355 : scanCanonicalize (H12AffineFastState.compose env22355 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22355 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env22356 : List Nat := [2,4,8,16,32,17,128,256,512,173,428,292,269,136,1,263,153,137,173,0,308,32,17,139,389,17,292,153,293,137,288,33,256,33,1,512]

theorem envBound22356 : H12AffineFastState.Bounded env22356 := by
  intro p hp
  have h : env22356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22355_22356 : H12AffineEnvironment.transform 5 17 env22355 = env22356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22355 == env22356) = true)

theorem identity22356 : scanCanonicalize (H12AffineFastState.compose env22356 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound22356 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22357 : List Nat := [2,4,8,16,32,17,128,150,512,173,58,178,155,136,1,145,153,137,173,0,162,32,17,139,19,17,178,153,179,137,182,33,150,33,1,512]

theorem envBound22357 : H12AffineFastState.Bounded env22357 := by
  intro p hp
  have h : env22357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22356_22357 : H12AffineEnvironment.transform 7 150 env22356 = env22357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env22356 == env22357) = true)

theorem identity22357 : scanCanonicalize (H12AffineFastState.compose env22357 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22357 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22358 : List Nat := [2,4,8,16,0,17,128,150,512,141,26,146,155,136,1,145,153,137,141,0,130,0,17,139,19,17,146,153,147,137,150,1,150,1,1,512]

theorem envBound22358 : H12AffineFastState.Bounded env22358 := by
  intro p hp
  have h : env22358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22357_22358 : H12AffineEnvironment.transform 4 0 env22357 = env22358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22357 == env22358) = true)

theorem identity22358 : scanCanonicalize (H12AffineFastState.compose env22358 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22358 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22359 : List Nat := [2,4,8,16,0,17,2,20,512,15,26,16,25,10,1,19,27,11,15,0,0,0,17,9,19,17,16,27,17,11,20,1,20,1,1,512]

theorem envBound22359 : H12AffineFastState.Bounded env22359 := by
  intro p hp
  have h : env22359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22358_22359 : H12AffineEnvironment.transform 6 2 env22358 = env22359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22358 == env22359) = true)

theorem identity22359 : scanCanonicalize (H12AffineFastState.compose env22359 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound22359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22360 : List Nat := [2,2,8,16,0,17,2,18,512,9,26,16,25,10,1,19,27,11,9,0,0,0,17,9,19,17,16,27,17,11,18,1,18,1,1,512]

theorem envBound22360 : H12AffineFastState.Bounded env22360 := by
  intro p hp
  have h : env22360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22359_22360 : H12AffineEnvironment.transform 1 2 env22359 = env22360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env22359 == env22360) = true)

theorem identity22360 : scanCanonicalize (H12AffineFastState.compose env22360 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22361 : List Nat := [2,2,8,11,0,10,2,9,512,9,1,11,2,10,1,8,0,11,9,0,0,0,10,9,8,10,11,0,10,11,9,1,9,1,1,512]

theorem envBound22361 : H12AffineFastState.Bounded env22361 := by
  intro p hp
  have h : env22361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22360_22361 : H12AffineEnvironment.transform 3 11 env22360 = env22361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22360 == env22361) = true)

theorem identity22361 : scanCanonicalize (H12AffineFastState.compose env22361 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound22361 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22362 : List Nat := [2,2,8,11,0,10,2,9,3,9,1,11,2,10,1,8,0,11,9,0,0,0,10,9,8,10,11,0,10,11,9,1,9,1,1,3]

theorem envBound22362 : H12AffineFastState.Bounded env22362 := by
  intro p hp
  have h : env22362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22361_22362 : H12AffineEnvironment.transform 8 3 env22361 = env22362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env22361 == env22362) = true)

theorem identity22362 : scanCanonicalize (H12AffineFastState.compose env22362 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22362 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22363 : List Nat := [2,2,2,1,0,0,2,3,3,3,1,1,2,0,1,2,0,1,3,0,0,0,0,3,2,0,1,0,0,1,3,1,3,1,1,3]

theorem envBound22363 : H12AffineFastState.Bounded env22363 := by
  intro p hp
  have h : env22363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22362_22363 : H12AffineEnvironment.transform 2 2 env22362 = env22363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22362 == env22363) = true)

theorem identity22363 : scanCanonicalize (H12AffineFastState.compose env22363 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22364 : List Nat := [1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,1,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,0,1,1,0]

theorem envBound22364 : H12AffineFastState.Bounded env22364 := by
  intro p hp
  have h : env22364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22363_22364 : H12AffineEnvironment.transform 0 1 env22363 = env22364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22363 == env22364) = true)

def env22365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,16,73857,8328,64,4592845,5393,4097,406605,20700,4194304,256,21792,16600,96010]

theorem envBound22365 : H12AffineFastState.Bounded env22365 := by
  intro p hp
  have h : env22365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22335_22365 : H12AffineEnvironment.transform 20 17729 env22335 = env22365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env22335 == env22365) = true)

def env22366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4161,4194304,16,73857,8328,64,4592845,5393,4097,406605,1500,4194304,256,32,5592,74250]

theorem envBound22366 : H12AffineFastState.Bounded env22366 := by
  intro p hp
  have h : env22366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22365_22366 : H12AffineEnvironment.transform 13 5376 env22365 = env22366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22365 == env22366) = true)

theorem identity22366 : scanCanonicalize (H12AffineFastState.compose env22366 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22366 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4161,4194304,16,138,8328,64,4592845,5393,4097,406605,1500,4194304,256,32,5592,513]

theorem envBound22367 : H12AffineFastState.Bounded env22367 := by
  intro p hp
  have h : env22367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22366_22367 : H12AffineEnvironment.transform 15 8203 env22366 = env22367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22366 == env22367) = true)

theorem identity22367 : scanCanonicalize (H12AffineFastState.compose env22367 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146912) := by decide +kernel

theorem selectedBound22367 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146912,1024,8541,4161,4194304,16,138,8328,64,4204845,5393,4097,2477,1500,4194304,256,32,5592,513]

theorem envBound22368 : H12AffineFastState.Bounded env22368 := by
  intro p hp
  have h : env22368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22367_22368 : H12AffineEnvironment.transform 17 146912 env22367 = env22368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env22367 == env22368) = true)

theorem identity22368 : scanCanonicalize (H12AffineFastState.compose env22368 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound22368 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env22369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146912,1024,8541,4161,136496,16,138,8328,64,146461,5393,4097,2477,1500,136496,256,32,5592,513]

theorem envBound22369 : H12AffineFastState.Bounded env22369 := by
  intro p hp
  have h : env22369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22368_22369 : H12AffineEnvironment.transform 21 136496 env22368 = env22369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env22368 == env22369) = true)

theorem identity22369 : scanCanonicalize (H12AffineFastState.compose env22369 (packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound22369 : packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS < 2^1333 := by decide +kernel

def env22370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,13460,2420,1024,8541,4161,8612,16,138,8328,64,2185,5393,4097,2477,1500,8612,256,32,5592,513]

theorem envBound22370 : H12AffineFastState.Bounded env22370 := by
  intro p hp
  have h : env22370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22369_22370 : H12AffineEnvironment.transform 16 13460 env22369 = env22370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env22369 == env22370) = true)

theorem identity22370 : scanCanonicalize (H12AffineFastState.compose env22370 (packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound22370 : packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env22371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,399,5392,2420,1024,217,4161,32,16,138,268,64,2185,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound22371 : H12AffineFastState.Bounded env22371 := by
  intro p hp
  have h : env22371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22370_22371 : H12AffineEnvironment.transform 12 388 env22370 = env22371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env22370 == env22371) = true)

theorem identity22371 : scanCanonicalize (H12AffineFastState.compose env22371 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound22371 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env22372 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,216,35,5308,2264,1024,217,4161,32,16,138,160,64,2185,5309,4097,2049,1136,32,172,32,5236,513]

theorem envBound22372 : H12AffineFastState.Bounded env22372 := by
  intro p hp
  have h : env22372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22371_22372 : H12AffineEnvironment.transform 7 172 env22371 = env22372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env22371 == env22372) = true)

theorem identity22372 : scanCanonicalize (H12AffineFastState.compose env22372 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22372 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env22373 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3108,40,2184,216,35,2200,2264,1024,217,3173,32,16,138,160,64,2185,2201,3109,2049,1136,32,172,32,2128,513]

theorem envBound22373 : H12AffineFastState.Bounded env22373 := by
  intro p hp
  have h : env22373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22372_22373 : H12AffineEnvironment.transform 11 3108 env22372 = env22373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env22372 == env22373) = true)

theorem identity22373 : scanCanonicalize (H12AffineFastState.compose env22373 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound22373 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env22374 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1260,200,40,1124,216,35,1140,1076,1024,217,137,32,16,138,160,64,1125,1141,201,1261,1136,32,172,32,1212,513]

theorem envBound22374 : H12AffineFastState.Bounded env22374 := by
  intro p hp
  have h : env22374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22373_22374 : H12AffineEnvironment.transform 10 1260 env22373 = env22374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env22373 == env22374) = true)

def env22375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,4194304,16,73857,8328,64,4592845,5393,4097,406605,1501,4194304,256,33,5593,74251]

theorem envBound22375 : H12AffineFastState.Bounded env22375 := by
  intro p hp
  have h : env22375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22365_22375 : H12AffineEnvironment.transform 13 5377 env22365 = env22375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22365 == env22375) = true)

theorem identity22375 : scanCanonicalize (H12AffineFastState.compose env22375 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound22375 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,262144,1024,8540,4160,4194304,16,3,8328,64,4592845,5393,4097,406605,1501,4194304,256,33,5593,649]

theorem envBound22376 : H12AffineFastState.Bounded env22376 := by
  intro p hp
  have h : env22376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22375_22376 : H12AffineEnvironment.transform 15 8322 env22375 = env22376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env22375 == env22376) = true)

theorem identity22376 : scanCanonicalize (H12AffineFastState.compose env22376 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22376 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env22377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,10281,1024,8540,4160,4194304,16,3,8328,64,4340964,5393,4097,138340,1501,4194304,256,33,5593,649]

theorem envBound22377 : H12AffineFastState.Bounded env22377 := by
  intro p hp
  have h : env22377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22376_22377 : H12AffineEnvironment.transform 17 10281 env22376 = env22377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22376 == env22377) = true)

theorem identity22377 : scanCanonicalize (H12AffineFastState.compose env22377 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound22377 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env22378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,136,343,131072,2556,1024,137,4160,4194304,16,3,349,64,4332849,5393,4097,138340,1501,4194304,256,33,5593,649]

theorem envBound22378 : H12AffineFastState.Bounded env22378 := by
  intro p hp
  have h : env22378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22377_22378 : H12AffineEnvironment.transform 12 469 env22377 = env22378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env22377 == env22378) = true)

theorem identity22378 : scanCanonicalize (H12AffineFastState.compose env22378 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22378 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,136,343,5392,2556,1024,137,4160,4194304,16,3,349,64,4196385,5393,4097,2420,1501,4194304,256,33,5593,649]

theorem envBound22379 : H12AffineFastState.Bounded env22379 := by
  intro p hp
  have h : env22379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22378_22379 : H12AffineEnvironment.transform 16 5392 env22378 = env22379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22378 == env22379) = true)

theorem identity22379 : scanCanonicalize (H12AffineFastState.compose env22379 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound22379 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,136,343,5392,2556,1024,137,4160,32,16,3,349,64,2049,5393,4097,2420,1501,32,256,33,5593,649]

theorem envBound22380 : H12AffineFastState.Bounded env22380 := by
  intro p hp
  have h : env22380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22379_22380 : H12AffineEnvironment.transform 21 32 env22379 = env22380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22379 == env22380) = true)

theorem identity22380 : scanCanonicalize (H12AffineFastState.compose env22380 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22380 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env22381 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,136,262,5392,2477,1024,137,4113,32,16,3,268,17,2049,5393,4097,2341,1420,32,256,33,5512,649]

theorem envBound22381 : H12AffineFastState.Bounded env22381 := by
  intro p hp
  have h : env22381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22380_22381 : H12AffineEnvironment.transform 5 17 env22380 = env22381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22380 == env22381) = true)

theorem identity22381 : scanCanonicalize (H12AffineFastState.compose env22381 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22381 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env22382 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1024,0,4113,32,16,3,268,17,2049,5393,4097,2341,1285,32,256,33,5377,512]

theorem envBound22382 : H12AffineFastState.Bounded env22382 := by
  intro p hp
  have h : env22382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22381_22382 : H12AffineEnvironment.transform 6 9 env22381 = env22382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22381 == env22382) = true)

theorem identity22382 : scanCanonicalize (H12AffineFastState.compose env22382 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22383 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,1,262,5392,2309,1024,0,4113,1,16,3,268,17,2049,5393,4097,2308,1285,1,256,0,5377,512]

theorem envBound22383 : H12AffineFastState.Bounded env22383 := by
  intro p hp
  have h : env22383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22382_22383 : H12AffineEnvironment.transform 4 1 env22382 = env22383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22382 == env22383) = true)

theorem identity22383 : scanCanonicalize (H12AffineFastState.compose env22383 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22383 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22384 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,1,3,5141,2048,1024,0,4113,1,16,3,9,17,2049,5140,4097,2049,1024,1,5,0,5124,512]

theorem envBound22384 : H12AffineFastState.Bounded env22384 := by
  intro p hp
  have h : env22384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22383_22384 : H12AffineEnvironment.transform 7 5 env22383 = env22384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22383 == env22384) = true)

def env22385 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,1,3,1029,2048,1024,0,1,1,16,3,9,17,2049,1028,17,2049,1024,1,5,0,1044,512]

theorem envBound22385 : H12AffineFastState.Bounded env22385 := by
  intro p hp
  have h : env22385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22384_22385 : H12AffineEnvironment.transform 11 16 env22384 = env22385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22384 == env22385) = true)

def env22386 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,0,1,3,17,2048,20,0,1,1,16,3,9,17,2049,16,17,2049,20,1,5,0,0,512]

theorem envBound22386 : H12AffineFastState.Bounded env22386 := by
  intro p hp
  have h : env22386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22385_22386 : H12AffineEnvironment.transform 9 20 env22385 = env22386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22385 == env22386) = true)

theorem identity22386 : scanCanonicalize (H12AffineFastState.compose env22386 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound22386 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22387 : List Nat := [2,4,8,16,1,17,9,5,31,20,2048,16,8,0,1,3,17,2048,20,0,1,1,16,3,9,17,2049,16,17,2049,20,1,5,0,0,31]

theorem envBound22387 : H12AffineFastState.Bounded env22387 := by
  intro p hp
  have h : env22387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22386_22387 : H12AffineEnvironment.transform 8 31 env22386 = env22387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env22386 == env22387) = true)

def leafEnv22387 : List Nat := [2,4,8,16,1,17,9,5,31,20,2048,16,8,0,1,3,17,2048,20,0,1,1,16,3,20,9,1,17,2049,16,17,2049,20,1,5,0,4,2,0,31,1,1,0]

def active22387 : List Nat := [0,1,2,3,10]

def tree22387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22387 : H12WitnessSearch.Good tree22387 := H12GlobalWitnessIndex.good

theorem leafIdentity22387 : H12AffineFastState.composeSystem env22387 rootObs = leafEnv22387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22387 rootObs == leafEnv22387) = true)

theorem terminalChecked22387 : H12PackedTerminal.terminalCheckFast leafEnv22387 active22387 tree22387 = true := by decide +kernel

def env22388 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,1,3,16,2048,21,0,1,1,16,3,9,17,2049,17,17,2049,21,1,5,0,1,512]

theorem envBound22388 : H12AffineFastState.Bounded env22388 := by
  intro p hp
  have h : env22388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22385_22388 : H12AffineEnvironment.transform 9 21 env22385 = env22388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22385 == env22388) = true)

theorem identity22388 : scanCanonicalize (H12AffineFastState.compose env22388 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22389 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,4,8,1,1,3,4,2048,1,0,1,1,4,3,9,5,2049,5,5,2049,1,1,5,0,1,512]

theorem envBound22389 : H12AffineFastState.Bounded env22389 := by
  intro p hp
  have h : env22389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22388_22389 : H12AffineEnvironment.transform 3 4 env22388 = env22389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22388 == env22389) = true)

def leafEnv22389 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,4,8,1,1,3,4,2048,1,0,1,1,4,3,1,9,1,5,2049,5,5,2049,1,1,5,0,4,2,1,512,1,1,0]

def active22389 : List Nat := [0,1,2,8,10]

def tree22389 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22389 : H12WitnessSearch.Good tree22389 := H12GlobalWitnessIndex.good

theorem leafIdentity22389 : H12AffineFastState.composeSystem env22389 rootObs = leafEnv22389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22389 rootObs == leafEnv22389) = true)

theorem terminalChecked22389 : H12PackedTerminal.terminalCheckFast leafEnv22389 active22389 tree22389 = true := by decide +kernel

def env22390 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,1,3,1028,2048,1024,0,0,1,16,3,9,17,2049,1029,16,2049,1024,1,5,0,1045,512]

theorem envBound22390 : H12AffineFastState.Bounded env22390 := by
  intro p hp
  have h : env22390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22384_22390 : H12AffineEnvironment.transform 11 17 env22384 = env22390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22384 == env22390) = true)

theorem identity22390 : scanCanonicalize (H12AffineFastState.compose env22390 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22391 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,1,1,3,16,2048,20,0,0,1,16,3,9,17,2049,17,16,2049,20,1,5,0,1,512]

theorem envBound22391 : H12AffineFastState.Bounded env22391 := by
  intro p hp
  have h : env22391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22390_22391 : H12AffineEnvironment.transform 9 20 env22390 = env22391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22390 == env22391) = true)

theorem identity22391 : scanCanonicalize (H12AffineFastState.compose env22391 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound22391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22392 : List Nat := [2,4,8,16,1,17,9,5,30,20,2048,17,8,1,1,3,16,2048,20,0,0,1,16,3,9,17,2049,17,16,2049,20,1,5,0,1,30]

theorem envBound22392 : H12AffineFastState.Bounded env22392 := by
  intro p hp
  have h : env22392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22391_22392 : H12AffineEnvironment.transform 8 30 env22391 = env22392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env22391 == env22392) = true)

def leafEnv22392 : List Nat := [2,4,8,16,1,17,9,5,30,20,2048,17,8,1,1,3,16,2048,20,0,0,1,16,3,20,9,1,17,2049,17,16,2049,20,1,5,0,4,2,1,30,1,0,0]

def active22392 : List Nat := [0,1,2,3,10]

def tree22392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22392 : H12WitnessSearch.Good tree22392 := H12GlobalWitnessIndex.good

theorem leafIdentity22392 : H12AffineFastState.composeSystem env22392 rootObs = leafEnv22392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22392 rootObs == leafEnv22392) = true)

theorem terminalChecked22392 : H12PackedTerminal.terminalCheckFast leafEnv22392 active22392 tree22392 = true := by decide +kernel

def env22393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,8388608,10577360,8328,64,6705549,8393984,10507600,8795228,2102684,12582928,256,21793,16600,2175562]

theorem envBound22393 : H12AffineFastState.Bounded env22393 := by
  intro p hp
  have h : env22393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22305_22393 : H12AffineEnvironment.transform 14 29789 env22305 = env22393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env22305 == env22393) = true)

def env22394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114896,73856,8328,64,6705549,2117712,4096,2519308,2102684,6309184,256,21793,16600,2175562]

theorem envBound22394 : H12AffineFastState.Bounded env22394 := by
  intro p hp
  have h : env22394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22393_22394 : H12AffineEnvironment.transform 22 2114896 env22393 = env22394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env22393 == env22394) = true)

def env22395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73856,8328,64,4592845,5392,4096,406604,20700,4194304,256,21793,16600,96010]

theorem envBound22395 : H12AffineFastState.Bounded env22395 := by
  intro p hp
  have h : env22395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22394_22395 : H12AffineEnvironment.transform 20 17728 env22394 = env22395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env22394 == env22395) = true)

theorem identity22395 : scanCanonicalize (H12AffineFastState.compose env22395 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound22395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,30083,131072,262144,1024,29788,17728,4194304,16,21763,8328,64,4592845,5392,4096,406604,20700,4194304,256,21793,16600,649]

theorem envBound22396 : H12AffineFastState.Bounded env22396 := by
  intro p hp
  have h : env22396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22395_22396 : H12AffineEnvironment.transform 15 30083 env22395 = env22396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env22395 == env22396) = true)

def env22397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8323,131072,262144,1024,8540,4160,4194304,16,3,8328,64,4592845,5392,4096,406604,1500,4194304,256,33,5592,649]

theorem envBound22397 : H12AffineFastState.Bounded env22397 := by
  intro p hp
  have h : env22397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22396_22397 : H12AffineEnvironment.transform 13 5376 env22396 = env22397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22396 == env22397) = true)

theorem identity22397 : scanCanonicalize (H12AffineFastState.compose env22397 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22397 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env22398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,4194304,16,3,8192,64,4592709,5392,4096,406604,1364,4194304,256,33,5456,513]

theorem envBound22398 : H12AffineFastState.Bounded env22398 := by
  intro p hp
  have h : env22398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22397_22398 : H12AffineEnvironment.transform 6 8 env22397 = env22398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22397 == env22398) = true)

theorem identity22398 : scanCanonicalize (H12AffineFastState.compose env22398 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 144445) := by decide +kernel

theorem selectedBound22398 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,144445,16,3,8192,64,270456,5392,4096,406604,1364,144445,256,33,5456,513]

theorem envBound22399 : H12AffineFastState.Bounded env22399 := by
  intro p hp
  have h : env22399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22398_22399 : H12AffineEnvironment.transform 21 144445 env22398 = env22399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144445 env22398 == env22399) = true)

theorem identity22399 : scanCanonicalize (H12AffineFastState.compose env22399 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound22399 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env22400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,138341,1024,8540,4160,144445,16,3,8192,64,146461,5392,4096,10281,1364,144445,256,33,5456,513]

theorem envBound22400 : H12AffineFastState.Bounded env22400 := by
  intro p hp
  have h : env22400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22399_22400 : H12AffineEnvironment.transform 17 138341 env22399 = env22400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env22399 == env22400) = true)

theorem identity22400 : scanCanonicalize (H12AffineFastState.compose env22400 (packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound22400 : packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env22401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10280,1024,8540,4160,112,16,3,8192,64,2128,5392,4096,10281,1364,112,256,33,5456,513]

theorem envBound22401 : H12AffineFastState.Bounded env22401 := by
  intro p hp
  have h : env22401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22400_22401 : H12AffineEnvironment.transform 16 13389 env22400 = env22401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env22400 == env22401) = true)

theorem identity22401 : scanCanonicalize (H12AffineFastState.compose env22401 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22401 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22402 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,8203,12637,10280,272,8540,4160,112,16,3,8192,64,2128,4096,4096,10281,68,112,256,33,4160,513]

theorem envBound22402 : H12AffineFastState.Bounded env22402 := by
  intro p hp
  have h : env22402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22401_22402 : H12AffineEnvironment.transform 9 272 env22401 = env22402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22401 == env22402) = true)

theorem identity22402 : scanCanonicalize (H12AffineFastState.compose env22402 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22402 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22403 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,8192,4112,8541,8203,12637,8312,272,8540,4160,112,16,3,8192,64,0,4096,4096,8313,68,112,256,33,4160,513]

theorem envBound22403 : H12AffineFastState.Bounded env22403 := by
  intro p hp
  have h : env22403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22402_22403 : H12AffineEnvironment.transform 10 80 env22402 = env22403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22402 == env22403) = true)

theorem identity22403 : scanCanonicalize (H12AffineFastState.compose env22403 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22403 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22404 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,4096,8192,4112,8461,8203,12557,8232,272,8460,4112,32,16,3,8192,16,0,4096,4096,8233,20,32,256,33,4112,513]

theorem envBound22404 : H12AffineFastState.Bounded env22404 := by
  intro p hp
  have h : env22404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22403_22404 : H12AffineEnvironment.transform 5 16 env22403 = env22404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22403 == env22404) = true)

theorem identity22404 : scanCanonicalize (H12AffineFastState.compose env22404 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound22404 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22405 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,4096,41,4112,292,34,4388,1,272,293,4112,32,16,3,41,16,0,4096,4096,0,20,32,256,33,4112,513]

theorem envBound22405 : H12AffineFastState.Bounded env22405 := by
  intro p hp
  have h : env22405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22404_22405 : H12AffineEnvironment.transform 12 41 env22404 = env22405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env22404 == env22405) = true)

theorem identity22405 : scanCanonicalize (H12AffineFastState.compose env22405 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound22405 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env22406 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,308,41,292,292,34,16,1,272,293,292,32,16,3,41,16,0,308,308,0,20,32,256,33,292,513]

theorem envBound22406 : H12AffineFastState.Bounded env22406 := by
  intro p hp
  have h : env22406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22405_22406 : H12AffineEnvironment.transform 11 308 env22405 = env22406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env22405 == env22406) = true)

theorem identity22406 : scanCanonicalize (H12AffineFastState.compose env22406 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22406 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22407 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,17,41,1,1,34,16,1,53,0,1,32,16,3,41,16,0,17,17,0,20,32,37,33,1,513]

theorem envBound22407 : H12AffineFastState.Bounded env22407 := by
  intro p hp
  have h : env22407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22406_22407 : H12AffineEnvironment.transform 7 37 env22406 = env22407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22406 == env22407) = true)

theorem identity22407 : scanCanonicalize (H12AffineFastState.compose env22407 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound22407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22408 : List Nat := [2,4,8,16,32,16,8,37,20,53,0,17,41,1,1,34,16,1,53,0,1,32,16,3,41,16,0,17,17,0,20,32,37,33,1,21]

theorem envBound22408 : H12AffineFastState.Bounded env22408 := by
  intro p hp
  have h : env22408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22407_22408 : H12AffineEnvironment.transform 8 20 env22407 = env22408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env22407 == env22408) = true)

theorem identity22408 : scanCanonicalize (H12AffineFastState.compose env22408 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound22408 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22409 : List Nat := [2,4,8,16,3,16,8,6,20,22,0,17,10,1,1,1,16,1,22,0,1,3,16,3,10,16,0,17,17,0,20,3,6,2,1,21]

theorem envBound22409 : H12AffineFastState.Bounded env22409 := by
  intro p hp
  have h : env22409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22408_22409 : H12AffineEnvironment.transform 4 3 env22408 = env22409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env22408 == env22409) = true)

theorem identity22409 : scanCanonicalize (H12AffineFastState.compose env22409 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22409 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22410 : List Nat := [2,4,8,1,3,1,8,6,5,7,0,0,10,1,1,1,1,1,7,0,1,3,1,3,10,1,0,0,0,0,5,3,6,2,1,4]

theorem envBound22410 : H12AffineFastState.Bounded env22410 := by
  intro p hp
  have h : env22410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22409_22410 : H12AffineEnvironment.transform 3 1 env22409 = env22410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22409 == env22410) = true)

theorem identity22410 : scanCanonicalize (H12AffineFastState.compose env22410 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22410 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22411 : List Nat := [2,4,2,1,3,1,2,6,5,7,0,0,0,1,1,1,1,1,7,0,1,3,1,3,0,1,0,0,0,0,5,3,6,2,1,4]

theorem envBound22411 : H12AffineFastState.Bounded env22411 := by
  intro p hp
  have h : env22411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22410_22411 : H12AffineEnvironment.transform 2 2 env22410 = env22411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22410 == env22411) = true)

theorem identity22411 : scanCanonicalize (H12AffineFastState.compose env22411 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22411 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22412 : List Nat := [0,4,0,1,1,1,0,4,5,5,0,0,0,1,1,1,1,1,5,0,1,1,1,1,0,1,0,0,0,0,5,1,4,0,1,4]

theorem envBound22412 : H12AffineFastState.Bounded env22412 := by
  intro p hp
  have h : env22412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22411_22412 : H12AffineEnvironment.transform 0 0 env22411 = env22412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22411 == env22412) = true)

def env22413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,262144,1024,8541,4161,4194304,16,2,8328,64,4592845,5392,4096,406604,1501,4194304,256,32,5593,649]

theorem envBound22413 : H12AffineFastState.Bounded env22413 := by
  intro p hp
  have h : env22413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22396_22413 : H12AffineEnvironment.transform 13 5377 env22396 = env22413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22396 == env22413) = true)

theorem identity22413 : scanCanonicalize (H12AffineFastState.compose env22413 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22413 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,4194304,16,2,8192,64,4592709,5392,4096,406604,1365,4194304,256,32,5457,513]

theorem envBound22414 : H12AffineFastState.Bounded env22414 := by
  intro p hp
  have h : env22414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22413_22414 : H12AffineEnvironment.transform 6 8 env22413 = env22414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22413 == env22414) = true)

theorem identity22414 : scanCanonicalize (H12AffineFastState.compose env22414 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound22414 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,2,8192,64,398437,5392,4096,406604,1365,32,256,32,5457,513]

theorem envBound22415 : H12AffineFastState.Bounded env22415 := by
  intro p hp
  have h : env22415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22414_22415 : H12AffineEnvironment.transform 21 32 env22414 = env22415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22414 == env22415) = true)

theorem identity22415 : scanCanonicalize (H12AffineFastState.compose env22415 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22415 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5392,262144,1024,8541,4161,32,16,2,8192,64,262517,5392,4096,270684,1365,32,256,32,5457,513]

theorem envBound22416 : H12AffineFastState.Bounded env22416 := by
  intro p hp
  have h : env22416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22415_22416 : H12AffineEnvironment.transform 16 5392 env22415 = env22416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22415 == env22416) = true)

def env22417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,17,73856,8328,64,4592844,5393,4096,406605,20701,4194305,256,21793,16600,96011]

theorem envBound22417 : H12AffineFastState.Bounded env22417 := by
  intro p hp
  have h : env22417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22394_22417 : H12AffineEnvironment.transform 20 17729 env22394 = env22417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env22394 == env22417) = true)

theorem identity22417 : scanCanonicalize (H12AffineFastState.compose env22417 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound22417 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,95650,17,73856,8328,64,483694,5393,4096,406605,20701,95651,256,21793,16600,96011]

theorem envBound22418 : H12AffineFastState.Bounded env22418 := by
  intro p hp
  have h : env22418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22417_22418 : H12AffineEnvironment.transform 21 95650 env22417 = env22418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env22417 == env22418) = true)

theorem identity22418 : scanCanonicalize (H12AffineFastState.compose env22418 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound22418 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env22419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,17729,95650,17,73856,8328,64,262517,5393,4096,349270,20701,95651,256,21793,16600,96011]

theorem envBound22419 : H12AffineFastState.Bounded env22419 := by
  intro p hp
  have h : env22419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22418_22419 : H12AffineEnvironment.transform 16 90139 env22418 = env22419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env22418 == env22419) = true)

theorem identity22419 : scanCanonicalize (H12AffineFastState.compose env22419 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound22419 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,29962,5393,262144,1024,29788,17729,168,17,21898,8328,64,262517,5393,4096,270684,20701,169,256,21793,16600,513]

theorem envBound22420 : H12AffineFastState.Bounded env22420 := by
  intro p hp
  have h : env22420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22419_22420 : H12AffineEnvironment.transform 15 29962 env22419 = env22420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env22419 == env22420) = true)

theorem identity22420 : scanCanonicalize (H12AffineFastState.compose env22420 (packedSelected [11,18,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22420 : packedSelected [11,18,21,23,32] rootPS < 2^1333 := by decide +kernel

def env22421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5393,262144,1024,29788,17729,32,17,21762,8192,64,262517,5393,4096,270684,20565,33,256,21793,16464,513]

theorem envBound22421 : H12AffineFastState.Bounded env22421 := by
  intro p hp
  have h : env22421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22420_22421 : H12AffineEnvironment.transform 6 8 env22420 = env22421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22420 == env22421) = true)

theorem identity22421 : scanCanonicalize (H12AffineFastState.compose env22421 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22421 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,5393,262144,1024,21760,17729,32,17,21762,348,64,262517,5393,4096,262144,20565,33,256,21793,16464,513]

theorem envBound22422 : H12AffineFastState.Bounded env22422 := by
  intro p hp
  have h : env22422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22421_22422 : H12AffineEnvironment.transform 12 348 env22421 = env22422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22421 == env22422) = true)

theorem identity22422 : scanCanonicalize (H12AffineFastState.compose env22422 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound22422 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,5393,2421,1024,21760,17729,32,17,21762,348,64,2048,5393,4096,2421,20565,33,256,21793,16464,513]

theorem envBound22423 : H12AffineFastState.Bounded env22423 := by
  intro p hp
  have h : env22423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22422_22423 : H12AffineEnvironment.transform 17 2421 env22422 = env22423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env22422 == env22423) = true)

theorem identity22423 : scanCanonicalize (H12AffineFastState.compose env22423 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22423 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env22424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,80,263,5393,2421,1024,81,4112,32,17,83,348,64,2048,5393,4096,2421,1284,33,256,112,5377,513]

theorem envBound22424 : H12AffineFastState.Bounded env22424 := by
  intro p hp
  have h : env22424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22423_22424 : H12AffineEnvironment.transform 13 5457 env22423 = env22424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22423 == env22424) = true)

def env22425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114897,73857,8328,64,6705549,2117713,4097,2519309,2102684,6309185,256,21793,16600,2175562]

theorem envBound22425 : H12AffineFastState.Bounded env22425 := by
  intro p hp
  have h : env22425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22393_22425 : H12AffineEnvironment.transform 22 2114897 env22393 = env22425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env22393 == env22425) = true)

def env22426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,17,73857,8328,64,4592845,5393,4097,406605,20700,4194305,256,21793,16600,96010]

theorem envBound22426 : H12AffineFastState.Bounded env22426 := by
  intro p hp
  have h : env22426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22425_22426 : H12AffineEnvironment.transform 20 17728 env22425 = env22426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env22425 == env22426) = true)

theorem identity22426 : scanCanonicalize (H12AffineFastState.compose env22426 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound22426 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,95531,17,73857,8328,64,483814,5393,4097,406605,20700,95530,256,21793,16600,96010]

theorem envBound22427 : H12AffineFastState.Bounded env22427 := by
  intro p hp
  have h : env22427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22426_22427 : H12AffineEnvironment.transform 21 95531 env22426 = env22427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env22426 == env22427) = true)

def env22428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,73771,17,73857,8328,64,472294,5393,4097,406605,1500,73770,256,33,5592,74250]

theorem envBound22428 : H12AffineFastState.Bounded env22428 := by
  intro p hp
  have h : env22428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22427_22428 : H12AffineEnvironment.transform 13 5376 env22427 = env22428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22427 == env22428) = true)

theorem identity22428 : scanCanonicalize (H12AffineFastState.compose env22428 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound22428 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67618,1024,8540,4160,73771,17,73857,8328,64,146628,5393,4097,212079,1500,73770,256,33,5592,74250]

theorem envBound22429 : H12AffineFastState.Bounded env22429 := by
  intro p hp
  have h : env22429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22428_22429 : H12AffineEnvironment.transform 17 67618 env22428 = env22429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env22428 == env22429) = true)

theorem identity22429 : scanCanonicalize (H12AffineFastState.compose env22429 (packedSelected [1,10,16,18,20,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound22429 : packedSelected [1,10,16,18,20,23,26,28] rootPS < 2^1333 := by decide +kernel

def env22430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,67618,1024,8540,4160,73771,17,73857,8328,64,10709,5393,4097,76158,1500,73770,256,33,5592,74250]

theorem envBound22430 : H12AffineFastState.Bounded env22430 := by
  intro p hp
  have h : env22430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22429_22430 : H12AffineEnvironment.transform 16 5393 env22429 = env22430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env22429 == env22430) = true)

theorem identity22430 : scanCanonicalize (H12AffineFastState.compose env22430 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22430 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,5393,67618,1024,8540,4160,73771,17,73736,8193,64,10588,5393,4097,76158,1365,73770,256,33,5457,74250]

theorem envBound22431 : H12AffineFastState.Bounded env22431 := by
  intro p hp
  have h : env22431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22430_22431 : H12AffineEnvironment.transform 6 9 env22430 = env22431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22430 == env22431) = true)

theorem identity22431 : scanCanonicalize (H12AffineFastState.compose env22431 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound22431 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,293,65536,5393,67618,1024,292,4160,65619,17,65648,121,64,2340,5393,4097,67846,1365,65618,256,33,5457,66162]

theorem envBound22432 : H12AffineFastState.Bounded env22432 := by
  intro p hp
  have h : env22432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22431_22432 : H12AffineEnvironment.transform 12 120 env22431 = env22432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env22431 == env22432) = true)

theorem identity22432 : scanCanonicalize (H12AffineFastState.compose env22432 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22432 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env22433 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4112,293,65536,4097,67618,272,292,4160,65619,17,65648,121,64,2340,4097,4097,67846,69,65618,256,33,4161,66162]

theorem envBound22433 : H12AffineFastState.Bounded env22433 := by
  intro p hp
  have h : env22433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22432_22433 : H12AffineEnvironment.transform 9 272 env22432 = env22433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22432 == env22433) = true)

theorem identity22433 : scanCanonicalize (H12AffineFastState.compose env22433 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22433 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22434 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,1,65536,4097,67618,52,0,4160,65619,17,65648,121,64,2048,4097,4097,67618,69,65618,36,33,4161,66162]

theorem envBound22434 : H12AffineFastState.Bounded env22434 := by
  intro p hp
  have h : env22434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22433_22434 : H12AffineEnvironment.transform 7 36 env22433 = env22434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22433 == env22434) = true)

theorem identity22434 : scanCanonicalize (H12AffineFastState.compose env22434 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 4146) := by decide +kernel

theorem selectedBound22434 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env22435 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,1,4146,4097,6160,52,0,4160,4193,17,4162,121,64,2048,4097,4097,6160,69,4192,36,33,4161,4672]

theorem envBound22435 : H12AffineFastState.Bounded env22435 := by
  intro p hp
  have h : env22435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22434_22435 : H12AffineEnvironment.transform 15 4146 env22434 = env22435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4146 env22434 == env22435) = true)

theorem identity22435 : scanCanonicalize (H12AffineFastState.compose env22435 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 634) := by decide +kernel

theorem selectedBound22435 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env22436 : List Nat := [2,4,8,16,32,64,9,36,512,52,634,4096,120,4112,1,4146,4097,4714,52,0,4160,4193,17,4162,121,64,634,4097,4097,4714,69,4192,36,33,4161,4672]

theorem envBound22436 : H12AffineFastState.Bounded env22436 := by
  intro p hp
  have h : env22436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22435_22436 : H12AffineEnvironment.transform 10 634 env22435 = env22436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 634 env22435 == env22436) = true)

theorem identity22436 : scanCanonicalize (H12AffineFastState.compose env22436 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22436 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env22437 : List Nat := [2,4,8,16,32,17,9,36,512,52,555,4096,41,4112,1,4146,4097,4667,52,0,4113,4144,17,4115,40,17,555,4097,4097,4667,20,4145,36,33,4112,4625]

theorem envBound22437 : H12AffineFastState.Bounded env22437 := by
  intro p hp
  have h : env22437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22436_22437 : H12AffineEnvironment.transform 5 17 env22436 = env22437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22436 == env22437) = true)

theorem identity22437 : scanCanonicalize (H12AffineFastState.compose env22437 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound22437 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22438 : List Nat := [2,4,8,16,32,17,9,36,10,52,33,4096,41,4112,1,4146,4097,4145,52,0,4113,4144,17,4115,40,17,33,4097,4097,4145,20,4145,36,33,4112,4123]

theorem envBound22438 : H12AffineFastState.Bounded env22438 := by
  intro p hp
  have h : env22438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22437_22438 : H12AffineEnvironment.transform 8 10 env22437 = env22438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env22437 == env22438) = true)

theorem identity22438 : scanCanonicalize (H12AffineFastState.compose env22438 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 47) := by decide +kernel

theorem selectedBound22438 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env22439 : List Nat := [2,4,8,16,32,17,9,36,10,52,33,47,41,63,1,29,46,30,52,0,62,31,17,60,40,17,33,46,46,30,20,30,36,33,63,52]

theorem envBound22439 : H12AffineFastState.Bounded env22439 := by
  intro p hp
  have h : env22439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22438_22439 : H12AffineEnvironment.transform 11 47 env22438 = env22439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 47 env22438 == env22439) = true)

theorem identity22439 : scanCanonicalize (H12AffineFastState.compose env22439 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22439 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env22440 : List Nat := [0,4,8,16,32,17,9,36,8,52,33,45,41,61,1,29,44,28,52,0,60,29,17,60,40,17,33,44,44,28,20,28,36,33,61,52]

theorem envBound22440 : H12AffineFastState.Bounded env22440 := by
  intro p hp
  have h : env22440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22439_22440 : H12AffineEnvironment.transform 0 0 env22439 = env22440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22439 == env22440) = true)

theorem identity22440 : scanCanonicalize (H12AffineFastState.compose env22440 (packedSelected [1,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound22440 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env22441 : List Nat := [0,4,8,16,29,17,9,25,8,9,28,16,20,0,1,29,17,28,9,0,1,29,17,1,21,17,28,17,17,28,20,28,25,28,0,9]

theorem envBound22441 : H12AffineFastState.Bounded env22441 := by
  intro p hp
  have h : env22441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22440_22441 : H12AffineEnvironment.transform 4 29 env22440 = env22441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env22440 == env22441) = true)

theorem identity22441 : scanCanonicalize (H12AffineFastState.compose env22441 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound22441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22442 : List Nat := [0,4,8,12,1,13,9,5,8,9,0,12,8,0,1,1,13,0,9,0,1,1,13,1,9,13,0,13,13,0,8,0,5,0,0,9]

theorem envBound22442 : H12AffineFastState.Bounded env22442 := by
  intro p hp
  have h : env22442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22441_22442 : H12AffineEnvironment.transform 3 12 env22441 = env22442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env22441 == env22442) = true)

def env22443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4161,73770,17,73857,8328,64,472295,5393,4097,406605,1501,73771,256,32,5593,74251]

theorem envBound22443 : H12AffineFastState.Bounded env22443 := by
  intro p hp
  have h : env22443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22427_22443 : H12AffineEnvironment.transform 13 5377 env22427 = env22443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22427 == env22443) = true)

theorem identity22443 : scanCanonicalize (H12AffineFastState.compose env22443 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound22443 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,67755,1024,8541,4161,73770,17,73857,8328,64,146508,5393,4097,212198,1501,73771,256,32,5593,74251]

theorem envBound22444 : H12AffineFastState.Bounded env22444 := by
  intro p hp
  have h : env22444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22443_22444 : H12AffineEnvironment.transform 17 67755 env22443 = env22444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env22443 == env22444) = true)

theorem identity22444 : scanCanonicalize (H12AffineFastState.compose env22444 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22444 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,5392,67755,1024,8541,4161,73770,17,73857,8328,64,10588,5393,4097,76278,1501,73771,256,32,5593,74251]

theorem envBound22445 : H12AffineFastState.Bounded env22445 := by
  intro p hp
  have h : env22445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22444_22445 : H12AffineEnvironment.transform 16 5392 env22444 = env22445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22444 == env22445) = true)

def env22446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,16,73857,8328,64,4592844,5392,4097,406604,20701,4194304,256,21793,16600,96011]

theorem envBound22446 : H12AffineFastState.Bounded env22446 := by
  intro p hp
  have h : env22446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22425_22446 : H12AffineEnvironment.transform 20 17729 env22425 = env22446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env22425 == env22446) = true)

theorem identity22446 : scanCanonicalize (H12AffineFastState.compose env22446 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound22446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,17729,4194304,16,21899,8328,64,4592844,5392,4097,406604,20701,4194304,256,21793,16600,513]

theorem envBound22447 : H12AffineFastState.Bounded env22447 := by
  intro p hp
  have h : env22447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22446_22447 : H12AffineEnvironment.transform 15 29962 env22446 = env22447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env22446 == env22447) = true)

def env22448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,131072,262144,1024,8540,4161,4194304,16,139,8328,64,4592844,5392,4097,406604,1501,4194304,256,33,5592,513]

theorem envBound22448 : H12AffineFastState.Bounded env22448 := by
  intro p hp
  have h : env22448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22447_22448 : H12AffineEnvironment.transform 13 5376 env22447 = env22448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22447 == env22448) = true)

theorem identity22448 : scanCanonicalize (H12AffineFastState.compose env22448 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound22448 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,131072,2556,1024,8540,4161,4194304,16,139,8328,64,4332848,5392,4097,146864,1501,4194304,256,33,5592,513]

theorem envBound22449 : H12AffineFastState.Bounded env22449 := by
  intro p hp
  have h : env22449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22448_22449 : H12AffineEnvironment.transform 17 2556 env22448 = env22449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env22448 == env22449) = true)

theorem identity22449 : scanCanonicalize (H12AffineFastState.compose env22449 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22449 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,2420,1024,8540,4161,4194304,16,3,8192,64,4332848,5392,4097,146744,1365,4194304,256,33,5456,513]

theorem envBound22450 : H12AffineFastState.Bounded env22450 := by
  intro p hp
  have h : env22450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22449_22450 : H12AffineEnvironment.transform 6 8 env22449 = env22450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22449 == env22450) = true)

theorem identity22450 : scanCanonicalize (H12AffineFastState.compose env22450 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound22450 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env22451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,2420,1024,8540,4161,144492,16,3,8192,64,10588,5392,4097,146744,1365,144492,256,33,5456,513]

theorem envBound22451 : H12AffineFastState.Bounded env22451 := by
  intro p hp
  have h : env22451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22450_22451 : H12AffineEnvironment.transform 21 144492 env22450 = env22451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env22450 == env22451) = true)

theorem identity22451 : scanCanonicalize (H12AffineFastState.compose env22451 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22451 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env22452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,131072,2420,1024,1,4161,136497,16,3,349,64,2049,5392,4097,138341,1365,136497,256,33,5456,513]

theorem envBound22452 : H12AffineFastState.Bounded env22452 := by
  intro p hp
  have h : env22452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22451_22452 : H12AffineEnvironment.transform 12 349 env22451 = env22452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22451 == env22452) = true)

theorem identity22452 : scanCanonicalize (H12AffineFastState.compose env22452 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound22452 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2420,1024,1,4161,32,16,3,349,64,2049,5392,4097,2420,1365,32,256,33,5456,513]

theorem envBound22453 : H12AffineFastState.Bounded env22453 := by
  intro p hp
  have h : env22453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22452_22453 : H12AffineEnvironment.transform 16 5393 env22452 = env22453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env22452 == env22453) = true)

theorem identity22453 : scanCanonicalize (H12AffineFastState.compose env22453 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound22453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1573,349,805,0,343,820,2420,1024,1,1636,32,16,3,349,64,2049,821,1572,2420,1365,32,256,33,885,513]

theorem envBound22454 : H12AffineFastState.Bounded env22454 := by
  intro p hp
  have h : env22454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22453_22454 : H12AffineEnvironment.transform 11 1573 env22453 = env22454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env22453 == env22454) = true)

theorem identity22454 : scanCanonicalize (H12AffineFastState.compose env22454 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound22454 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1572,1573,349,805,0,343,820,1872,1024,1,1636,32,16,3,349,64,1573,821,1572,1872,1365,32,256,33,885,513]

theorem envBound22455 : H12AffineFastState.Bounded env22455 := by
  intro p hp
  have h : env22455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22454_22455 : H12AffineEnvironment.transform 10 1572 env22454 = env22455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env22454 == env22455) = true)

def env22456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4160,4194304,16,138,8328,64,4592844,5392,4097,406604,1500,4194304,256,32,5593,513]

theorem envBound22456 : H12AffineFastState.Bounded env22456 := by
  intro p hp
  have h : env22456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22447_22456 : H12AffineEnvironment.transform 13 5377 env22447 = env22456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22447 == env22456) = true)

theorem identity22456 : scanCanonicalize (H12AffineFastState.compose env22456 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound22456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146913,1024,8541,4160,4194304,16,138,8328,64,4204845,5392,4097,2477,1500,4194304,256,32,5593,513]

theorem envBound22457 : H12AffineFastState.Bounded env22457 := by
  intro p hp
  have h : env22457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22456_22457 : H12AffineEnvironment.transform 17 146913 env22456 = env22457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env22456 == env22457) = true)

theorem identity22457 : scanCanonicalize (H12AffineFastState.compose env22457 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound22457 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env22458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146913,1024,8541,4160,136497,16,138,8328,64,146460,5392,4097,2477,1500,136497,256,32,5593,513]

theorem envBound22458 : H12AffineFastState.Bounded env22458 := by
  intro p hp
  have h : env22458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22457_22458 : H12AffineEnvironment.transform 21 136497 env22457 = env22458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env22457 == env22458) = true)

theorem identity22458 : scanCanonicalize (H12AffineFastState.compose env22458 (packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound22458 : packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS < 2^1333 := by decide +kernel

def env22459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,13461,2420,1024,8541,4160,8612,16,138,8328,64,2185,5392,4097,2477,1500,8612,256,32,5593,513]

theorem envBound22459 : H12AffineFastState.Bounded env22459 := by
  intro p hp
  have h : env22459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22458_22459 : H12AffineEnvironment.transform 16 13461 env22458 = env22459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env22458 == env22459) = true)

theorem identity22459 : scanCanonicalize (H12AffineFastState.compose env22459 (packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound22459 : packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env22460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,216,399,5393,2420,1024,217,4160,32,16,138,268,64,2185,5392,4097,2477,1500,32,256,32,5593,513]

theorem envBound22460 : H12AffineFastState.Bounded env22460 := by
  intro p hp
  have h : env22460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22459_22460 : H12AffineEnvironment.transform 12 388 env22459 = env22460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env22459 == env22460) = true)

theorem identity22460 : scanCanonicalize (H12AffineFastState.compose env22460 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22460 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env22461 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,5236,216,250,5220,2049,1024,217,4160,32,16,138,121,64,2185,5221,4097,2264,1193,32,117,32,5292,513]

theorem envBound22461 : H12AffineFastState.Bounded env22461 := by
  intro p hp
  have h : env22461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22460_22461 : H12AffineEnvironment.transform 7 117 env22460 = env22461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22460 == env22461) = true)

theorem identity22461 : scanCanonicalize (H12AffineFastState.compose env22461 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound22461 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env22462 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3189,241,2049,216,250,2065,2049,1024,217,3125,32,16,138,121,64,2185,2064,3188,2264,1193,32,117,32,2265,513]

theorem envBound22462 : H12AffineFastState.Bounded env22462 := by
  intro p hp
  have h : env22462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22461_22462 : H12AffineEnvironment.transform 11 3189 env22461 = env22462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env22461 == env22462) = true)

theorem identity22462 : scanCanonicalize (H12AffineFastState.compose env22462 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound22462 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env22463 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1076,65,241,1077,216,250,1061,1077,1024,217,1,32,16,138,121,64,1213,1060,64,1260,1193,32,117,32,1261,513]

theorem envBound22463 : H12AffineFastState.Bounded env22463 := by
  intro p hp
  have h : env22463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22462_22463 : H12AffineEnvironment.transform 10 1076 env22462 = env22463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env22462 == env22463) = true)

theorem identity22463 : scanCanonicalize (H12AffineFastState.compose env22463 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound22463 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22464 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1076,65,40,1077,1,35,1061,1077,1024,0,1,32,16,83,121,64,1124,1060,64,1077,1136,32,117,32,1076,513]

theorem envBound22464 : H12AffineFastState.Bounded env22464 := by
  intro p hp
  have h : env22464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22463_22464 : H12AffineEnvironment.transform 6 89 env22463 = env22464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env22463 == env22464) = true)

def env22465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound22465 : H12AffineFastState.Bounded env22465 := by
  intro p hp
  have h : env22465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22303_22465 : H12AffineEnvironment.transform 18 1025 env22303 = env22465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22303 == env22465) = true)

theorem identity22465 : scanCanonicalize (H12AffineFastState.compose env22465 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165200) := by decide +kernel

theorem selectedBound22465 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,16777216,8328,64,29868033,16974300,8572928,8830976,25265169,21225616,257,25379325,25403480,25207750]

theorem envBound22466 : H12AffineFastState.Bounded env22466 := by
  intro p hp
  have h : env22466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22465_22466 : H12AffineEnvironment.transform 20 165200 env22465 = env22466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env22465 == env22466) = true)

def env22467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,8590556,8328,64,4510941,8393984,8572928,8830976,168141,12645452,257,21793,46212,243482]

theorem envBound22467 : H12AffineFastState.Bounded env22467 := by
  intro p hp
  have h : env22467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22466_22467 : H12AffineEnvironment.transform 23 8590556 env22466 = env22467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590556 env22466 == env22467) = true)

def env22468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169216,98780,8328,64,4510941,163840,17664,283904,168141,4350284,257,21793,46212,243482]

theorem envBound22468 : H12AffineFastState.Bounded env22468 := by
  intro p hp
  have h : env22468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22467_22468 : H12AffineEnvironment.transform 22 169216 env22467 = env22468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env22467 == env22468) = true)

def env22469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169216,98780,8328,64,64605,163840,17664,283904,168141,412108,257,21793,46212,243482]

theorem envBound22469 : H12AffineFastState.Bounded env22469 := by
  intro p hp
  have h : env22469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22468_22469 : H12AffineEnvironment.transform 21 272512 env22468 = env22469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22468 == env22469) = true)

theorem identity22469 : scanCanonicalize (H12AffineFastState.compose env22469 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound22469 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,165200,272512,169216,21763,8328,64,64605,163840,17664,283904,168141,412108,257,21793,46212,156613]

theorem envBound22470 : H12AffineFastState.Bounded env22470 := by
  intro p hp
  have h : env22470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22469_22470 : H12AffineEnvironment.transform 15 54495 env22469 = env22470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env22469 == env22470) = true)

def env22471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272392,169216,21763,8192,64,64605,163840,17664,283904,168005,411972,257,21793,46092,156493]

theorem envBound22471 : H12AffineFastState.Bounded env22471 := by
  intro p hp
  have h : env22471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22470_22471 : H12AffineEnvironment.transform 6 8 env22470 = env22471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22470 == env22471) = true)

theorem identity22471 : scanCanonicalize (H12AffineFastState.compose env22471 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound22471 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env22472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157753,1025,32769,165200,147505,169216,21763,8192,64,64605,163840,17664,146745,168005,8573,257,21793,46092,156493]

theorem envBound22472 : H12AffineFastState.Bounded env22472 := by
  intro p hp
  have h : env22472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22471_22472 : H12AffineEnvironment.transform 17 157753 env22471 = env22472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env22471 == env22472) = true)

theorem identity22472 : scanCanonicalize (H12AffineFastState.compose env22472 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound22472 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43048,1025,32769,17729,32800,21777,21763,8192,64,64605,16401,17664,64808,20564,8573,257,21793,46092,41820]

theorem envBound22473 : H12AffineFastState.Bounded env22473 := by
  intro p hp
  have h : env22473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22472_22473 : H12AffineEnvironment.transform 16 49169 env22472 = env22473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env22472 == env22473) = true)

theorem identity22473 : scanCanonicalize (H12AffineFastState.compose env22473 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound22473 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env22474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,46156,43048,1025,32769,12572,32800,8524,8542,8192,64,34816,13388,12637,35189,9225,8573,257,8572,46092,41820]

theorem envBound22474 : H12AffineFastState.Bounded env22474 := by
  intro p hp
  have h : env22474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22473_22474 : H12AffineEnvironment.transform 13 13405 env22473 = env22474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env22473 == env22474) = true)

theorem identity22474 : scanCanonicalize (H12AffineFastState.compose env22474 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22474 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,343,5393,2421,1025,8540,12572,8573,8524,8542,8192,64,10589,13388,12637,10280,9225,8573,257,8572,5457,513]

theorem envBound22475 : H12AffineFastState.Bounded env22475 := by
  intro p hp
  have h : env22475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22474_22475 : H12AffineEnvironment.transform 14 8541 env22474 = env22475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22474 == env22475) = true)

theorem identity22475 : scanCanonicalize (H12AffineFastState.compose env22475 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22475 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22476 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,8461,263,5393,2341,1025,8460,12572,8493,8476,8462,8192,16,10509,13340,12557,10280,9225,8493,257,8492,5377,513]

theorem envBound22476 : H12AffineFastState.Bounded env22476 := by
  intro p hp
  have h : env22476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22475_22476 : H12AffineEnvironment.transform 5 16 env22475 = env22476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22475 == env22476) = true)

theorem identity22476 : scanCanonicalize (H12AffineFastState.compose env22476 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1849) := by decide +kernel

theorem selectedBound22476 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22477 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1849,4916,1588,263,5393,2341,1025,1589,5669,1556,1573,1591,1849,16,3636,4901,5684,3857,816,1556,257,1557,5377,513]

theorem envBound22477 : H12AffineFastState.Bounded env22477 := by
  intro p hp
  have h : env22477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22476_22477 : H12AffineEnvironment.transform 12 1849 env22476 = env22477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1849 env22476 == env22477) = true)

theorem identity22477 : scanCanonicalize (H12AffineFastState.compose env22477 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound22477 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env22478 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,1849,1588,1588,263,17,2341,1025,1589,805,1556,1573,1591,1849,16,3636,1573,820,3857,816,1556,257,1557,1,513]

theorem envBound22478 : H12AffineFastState.Bounded env22478 := by
  intro p hp
  have h : env22478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22477_22478 : H12AffineEnvironment.transform 11 1280 env22477 = env22478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env22477 == env22478) = true)

theorem identity22478 : scanCanonicalize (H12AffineFastState.compose env22478 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound22478 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22479 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,1077,1548,1588,1588,50,17,2064,1025,1589,528,1556,1573,1591,1548,16,3636,1573,513,3620,517,1556,52,1557,1,513]

theorem envBound22479 : H12AffineFastState.Bounded env22479 := by
  intro p hp
  have h : env22479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22478_22479 : H12AffineEnvironment.transform 7 53 env22478 = env22479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env22478 == env22479) = true)

theorem identity22479 : scanCanonicalize (H12AffineFastState.compose env22479 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound22479 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22480 : List Nat := [2,4,8,16,32,16,8,53,512,1024,1572,1077,1548,1588,1588,50,17,1588,1025,1589,528,1556,1573,1591,1548,16,16,1573,513,0,517,1556,52,1557,1,513]

theorem envBound22480 : H12AffineFastState.Bounded env22480 := by
  intro p hp
  have h : env22480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22479_22480 : H12AffineEnvironment.transform 10 1572 env22479 = env22480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env22479 == env22480) = true)

theorem identity22480 : scanCanonicalize (H12AffineFastState.compose env22480 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22480 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env22481 : List Nat := [2,4,8,16,32,16,8,53,0,1024,1060,1077,1036,1076,1076,50,17,1076,1025,1077,16,1044,1061,1079,1036,16,16,1061,1,0,5,1044,52,1045,1,1]

theorem envBound22481 : H12AffineFastState.Bounded env22481 := by
  intro p hp
  have h : env22481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22480_22481 : H12AffineEnvironment.transform 8 0 env22480 = env22481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22480 == env22481) = true)

theorem identity22481 : scanCanonicalize (H12AffineFastState.compose env22481 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22481 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22482 : List Nat := [2,4,8,1,32,1,8,36,0,1024,1060,1060,1036,1061,1061,35,0,1061,1025,1060,1,1029,1061,1062,1036,1,1,1061,1,0,5,1029,37,1028,1,1]

theorem envBound22482 : H12AffineFastState.Bounded env22482 := by
  intro p hp
  have h : env22482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22481_22482 : H12AffineEnvironment.transform 3 1 env22481 = env22482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22481 == env22482) = true)

theorem identity22482 : scanCanonicalize (H12AffineFastState.compose env22482 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound22482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22483 : List Nat := [2,4,8,1,32,1,8,36,0,36,0,0,40,1,1,35,0,1,37,0,1,33,1,2,40,1,1,1,1,0,5,33,37,32,1,1]

theorem envBound22483 : H12AffineFastState.Bounded env22483 := by
  intro p hp
  have h : env22483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22482_22483 : H12AffineEnvironment.transform 9 36 env22482 = env22483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env22482 == env22483) = true)

theorem identity22483 : scanCanonicalize (H12AffineFastState.compose env22483 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22484 : List Nat := [2,4,2,1,32,1,2,36,0,36,0,0,34,1,1,35,0,1,37,0,1,33,1,2,34,1,1,1,1,0,5,33,37,32,1,1]

theorem envBound22484 : H12AffineFastState.Bounded env22484 := by
  intro p hp
  have h : env22484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22483_22484 : H12AffineEnvironment.transform 2 2 env22483 = env22484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22483 == env22484) = true)

def env22485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165200,272393,169216,21763,8193,64,64605,163840,17664,283904,168004,411973,257,21793,46093,156492]

theorem envBound22485 : H12AffineFastState.Bounded env22485 := by
  intro p hp
  have h : env22485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22470_22485 : H12AffineEnvironment.transform 6 9 env22470 = env22485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22470 == env22485) = true)

theorem identity22485 : scanCanonicalize (H12AffineFastState.compose env22485 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound22485 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env22486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149860,1025,32769,165200,156013,169216,21763,8193,64,64605,163840,17664,138340,168004,33,257,21793,46093,156492]

theorem envBound22486 : H12AffineFastState.Bounded env22486 := by
  intro p hp
  have h : env22486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22485_22486 : H12AffineEnvironment.transform 17 149860 env22485 = env22486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env22485 == env22486) = true)

theorem identity22486 : scanCanonicalize (H12AffineFastState.compose env22486 (packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound22486 : packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS < 2^1333 := by decide +kernel

def env22487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49216,35108,1025,32769,17680,41261,21824,21763,8193,64,64605,16448,17664,56356,20484,33,257,21793,46093,41740]

theorem envBound22487 : H12AffineFastState.Bounded env22487 := by
  intro p hp
  have h : env22487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22486_22487 : H12AffineEnvironment.transform 16 49216 env22486 = env22487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env22486 == env22487) = true)

theorem identity22487 : scanCanonicalize (H12AffineFastState.compose env22487 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound22487 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13340,32120,1025,29789,17680,21873,21824,21763,8193,64,2049,16448,17664,10360,20484,33,257,21793,16465,22352]

theorem envBound22488 : H12AffineFastState.Bounded env22488 := by
  intro p hp
  have h : env22488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22487_22488 : H12AffineEnvironment.transform 14 29788 env22487 = env22488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env22487 == env22488) = true)

theorem identity22488 : scanCanonicalize (H12AffineFastState.compose env22488 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22488 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8461,8202,13340,10281,1025,8460,4161,32,17,82,8193,64,2049,5393,4177,10360,1365,33,257,112,5376,513]

theorem envBound22489 : H12AffineFastState.Bounded env22489 := by
  intro p hp
  have h : env22489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22488_22489 : H12AffineEnvironment.transform 13 5457 env22488 = env22489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22488 == env22489) = true)

theorem identity22489 : scanCanonicalize (H12AffineFastState.compose env22489 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22489 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,1,262,5392,2341,1025,0,4161,32,17,82,269,64,2049,5393,4177,2420,1365,33,257,112,5376,513]

theorem envBound22490 : H12AffineFastState.Bounded env22490 := by
  intro p hp
  have h : env22490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22489_22490 : H12AffineEnvironment.transform 12 268 env22489 = env22490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22489 == env22490) = true)

theorem identity22490 : scanCanonicalize (H12AffineFastState.compose env22490 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22490 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22491 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1025,0,4112,32,17,3,269,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound22491 : H12AffineFastState.Bounded env22491 := by
  intro p hp
  have h : env22491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22490_22491 : H12AffineEnvironment.transform 5 17 env22490 = env22491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22490 == env22491) = true)

theorem identity22491 : scanCanonicalize (H12AffineFastState.compose env22491 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22492 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2309,1025,0,4112,0,17,3,269,17,2049,5393,4096,2309,1284,1,257,1,5376,513]

theorem envBound22492 : H12AffineFastState.Bounded env22492 := by
  intro p hp
  have h : env22492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22491_22492 : H12AffineEnvironment.transform 4 0 env22491 = env22492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22491 == env22492) = true)

theorem identity22492 : scanCanonicalize (H12AffineFastState.compose env22492 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2847) := by decide +kernel

theorem selectedBound22492 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22493 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,2847,268,3615,1,262,3599,2309,1025,0,2831,0,17,3,269,17,2049,3598,2847,2309,1284,1,257,1,3615,513]

theorem envBound22493 : H12AffineFastState.Bounded env22493 := by
  intro p hp
  have h : env22493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22492_22493 : H12AffineEnvironment.transform 11 2847 env22492 = env22493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2847 env22492 == env22493) = true)

theorem identity22493 : scanCanonicalize (H12AffineFastState.compose env22493 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound22493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22494 : List Nat := [2,4,8,16,0,17,9,256,512,1024,10,789,268,1557,1,262,1541,271,1025,0,773,0,17,3,269,17,11,1540,789,271,1284,1,257,1,1557,513]

theorem envBound22494 : H12AffineFastState.Bounded env22494 := by
  intro p hp
  have h : env22494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22493_22494 : H12AffineEnvironment.transform 10 10 env22493 = env22494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env22493 == env22494) = true)

theorem identity22494 : scanCanonicalize (H12AffineFastState.compose env22494 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22494 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22495 : List Nat := [2,4,8,11,0,10,9,256,512,1024,10,782,268,1550,1,262,1541,271,1025,0,773,0,10,3,269,10,11,1540,782,271,1284,1,257,1,1550,513]

theorem envBound22495 : H12AffineFastState.Bounded env22495 := by
  intro p hp
  have h : env22495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22494_22495 : H12AffineEnvironment.transform 3 11 env22494 = env22495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22494 == env22495) = true)

theorem identity22495 : scanCanonicalize (H12AffineFastState.compose env22495 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound22495 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22496 : List Nat := [2,4,8,11,0,10,9,256,512,256,10,782,268,782,1,262,773,271,257,0,773,0,10,3,269,10,11,772,782,271,4,1,257,1,782,513]

theorem envBound22496 : H12AffineFastState.Bounded env22496 := by
  intro p hp
  have h : env22496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0