import H12CloudChart0Data078

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound19930 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19931 : List Nat := [2,4,8,16,32,17,8,256,292,1024,2048,260,268,1028,0,263,1044,2341,1025,1,277,32,17,3,268,17,2048,1044,260,2341,1284,32,257,33,1029,293]

theorem envBound19931 : H12AffineFastState.Bounded env19931 := by
  intro p hp
  have h : env19931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19930_19931 : H12AffineEnvironment.transform 8 292 env19930 = env19931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env19930 == env19931) = true)

theorem identity19931 : scanCanonicalize (H12AffineFastState.compose env19931 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound19931 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19932 : List Nat := [2,4,8,16,32,17,8,256,292,5,2048,260,268,1,0,263,17,2341,4,1,277,32,17,3,268,17,2048,17,260,2341,257,32,257,33,0,293]

theorem envBound19932 : H12AffineFastState.Bounded env19932 := by
  intro p hp
  have h : env19932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19931_19932 : H12AffineEnvironment.transform 9 5 env19931 = env19932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env19931 == env19932) = true)

theorem identity19932 : scanCanonicalize (H12AffineFastState.compose env19932 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound19932 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19933 : List Nat := [2,4,8,16,32,17,8,256,292,5,308,260,268,1,0,263,17,17,4,1,277,32,17,3,268,17,308,17,260,17,257,32,257,33,0,293]

theorem envBound19933 : H12AffineFastState.Bounded env19933 := by
  intro p hp
  have h : env19933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19932_19933 : H12AffineEnvironment.transform 10 308 env19932 = env19933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env19932 == env19933) = true)

theorem identity19933 : scanCanonicalize (H12AffineFastState.compose env19933 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19933 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19934 : List Nat := [2,4,8,16,0,17,8,256,260,5,276,260,268,1,0,263,17,17,4,1,277,0,17,3,268,17,276,17,260,17,257,0,257,1,0,261]

theorem envBound19934 : H12AffineFastState.Bounded env19934 := by
  intro p hp
  have h : env19934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19933_19934 : H12AffineEnvironment.transform 4 0 env19933 = env19934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19933 == env19934) = true)

theorem identity19934 : scanCanonicalize (H12AffineFastState.compose env19934 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound19934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19935 : List Nat := [2,4,8,16,0,17,8,21,17,5,1,17,25,1,0,18,17,17,4,1,0,0,17,3,25,17,1,17,17,17,20,0,20,1,0,16]

theorem envBound19935 : H12AffineFastState.Bounded env19935 := by
  intro p hp
  have h : env19935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19934_19935 : H12AffineEnvironment.transform 7 21 env19934 = env19935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env19934 == env19935) = true)

def env19936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664598,8393984,10507601,8724506,2102684,12645453,257,21792,46212,2175563]

theorem envBound19936 : H12AffineFastState.Bounded env19936 := by
  intro p hp
  have h : env19936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19837_19936 : H12AffineEnvironment.transform 23 10588557 env19837 = env19936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env19837 == env19936) = true)

def env19937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664598,2098512,17665,2437194,2102684,6349853,257,21792,46212,2175563]

theorem envBound19937 : H12AffineFastState.Bounded env19937 := by
  intro p hp
  have h : env19937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19936_19937 : H12AffineEnvironment.transform 22 2101328 env19936 = env19937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19936 == env19937) = true)

def env19938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2201878,2098512,17665,2437194,2102684,2411677,257,21792,46212,2175563]

theorem envBound19938 : H12AffineFastState.Bounded env19938 := by
  intro p hp
  have h : env19938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19937_19938 : H12AffineEnvironment.transform 21 272512 env19937 = env19938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19937 == env19938) = true)

theorem identity19938 : scanCanonicalize (H12AffineFastState.compose env19938 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound19938 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115870,272512,120014,98781,8328,64,23944,115150,17665,324820,119042,329731,257,21792,46212,63189]

theorem envBound19939 : H12AffineFastState.Bounded env19939 := by
  intro p hp
  have h : env19939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19938_19939 : H12AffineEnvironment.transform 20 115870 env19938 = env19939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env19938 == env19939) = true)

def env19940 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115870,272512,119966,98701,8328,16,23944,115102,17665,324740,119042,329731,257,21792,46212,63109]

theorem envBound19940 : H12AffineFastState.Bounded env19940 := by
  intro p hp
  have h : env19940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19939_19940 : H12AffineEnvironment.transform 5 16 env19939 = env19940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19939 == env19940) = true)

theorem identity19940 : scanCanonicalize (H12AffineFastState.compose env19940 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound19940 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env19941 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,122146,1025,32769,115870,128418,119966,98701,8328,16,23944,115102,17665,76198,119042,54561,257,21792,46212,63109]

theorem envBound19941 : H12AffineFastState.Bounded env19941 := by
  intro p hp
  have h : env19941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19940_19941 : H12AffineEnvironment.transform 17 122146 env19940 = env19941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env19940 == env19941) = true)

theorem identity19941 : scanCanonicalize (H12AffineFastState.compose env19941 (packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound19941 : packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62731,5392,10281,1025,32769,12693,169,8597,29830,8328,16,23944,13461,17665,56493,9225,54561,257,21792,46212,63109]

theorem envBound19942 : H12AffineFastState.Bounded env19942 := by
  intro p hp
  have h : env19942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19941_19942 : H12AffineEnvironment.transform 15 62731 env19941 = env19942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env19941 == env19942) = true)

theorem identity19942 : scanCanonicalize (H12AffineFastState.compose env19942 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19942 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env19943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,54415,5392,2477,1025,32769,4113,169,17,21762,268,16,23944,5393,17665,56493,1421,54561,257,21792,38144,55041]

theorem envBound19943 : H12AffineFastState.Bounded env19943 := by
  intro p hp
  have h : env19943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19942_19943 : H12AffineEnvironment.transform 12 388 env19942 = env19943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19942 == env19943) = true)

theorem identity19943 : scanCanonicalize (H12AffineFastState.compose env19943 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19943 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19944 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,0,21647,5392,2477,1025,1,4113,169,17,21762,268,16,23944,5393,17665,23725,1421,21793,257,21792,5376,22273]

theorem envBound19944 : H12AffineFastState.Bounded env19944 := by
  intro p hp
  have h : env19944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19943_19944 : H12AffineEnvironment.transform 14 0 env19943 = env19944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19943 == env19944) = true)

theorem identity19944 : scanCanonicalize (H12AffineFastState.compose env19944 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19944 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19945 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,0,263,5392,2477,1025,1,4113,169,17,138,268,16,2048,5393,4233,2341,1421,169,257,168,5376,649]

theorem envBound19945 : H12AffineFastState.Bounded env19945 := by
  intro p hp
  have h : env19945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19944_19945 : H12AffineEnvironment.transform 13 5512 env19944 = env19945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19944 == env19945) = true)

theorem identity19945 : scanCanonicalize (H12AffineFastState.compose env19945 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound19945 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19946 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,388,4113,0,263,4233,2477,408,1,4113,169,17,138,268,16,2048,4232,4233,2341,20,169,257,168,4249,649]

theorem envBound19946 : H12AffineFastState.Bounded env19946 := by
  intro p hp
  have h : env19946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19945_19946 : H12AffineEnvironment.transform 9 409 env19945 = env19946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env19945 == env19946) = true)

theorem identity19946 : scanCanonicalize (H12AffineFastState.compose env19946 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19946 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env19947 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,0,263,4096,2340,273,1,4113,32,17,3,268,16,2048,4097,4096,2341,20,32,257,33,4112,512]

theorem envBound19947 : H12AffineFastState.Bounded env19947 := by
  intro p hp
  have h : env19947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19946_19947 : H12AffineEnvironment.transform 6 9 env19946 = env19947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19946 == env19947) = true)

theorem identity19947 : scanCanonicalize (H12AffineFastState.compose env19947 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19948 : List Nat := [2,4,8,0,32,0,9,256,512,256,2048,4096,269,4097,0,263,4096,2340,257,1,4097,32,1,3,268,0,2048,4097,4096,2341,4,32,257,33,4096,512]

theorem envBound19948 : H12AffineFastState.Bounded env19948 := by
  intro p hp
  have h : env19948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19947_19948 : H12AffineEnvironment.transform 3 0 env19947 = env19948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19947 == env19948) = true)

theorem identity19948 : scanCanonicalize (H12AffineFastState.compose env19948 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound19948 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19949 : List Nat := [2,4,8,0,32,0,9,256,13,256,2048,4096,269,4097,0,263,4096,2340,257,1,4097,32,1,3,268,0,2048,4097,4096,2341,4,32,257,33,4096,13]

theorem envBound19949 : H12AffineFastState.Bounded env19949 := by
  intro p hp
  have h : env19949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19948_19949 : H12AffineEnvironment.transform 8 13 env19948 = env19949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env19948 == env19949) = true)

theorem identity19949 : scanCanonicalize (H12AffineFastState.compose env19949 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound19949 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19950 : List Nat := [2,4,8,0,32,0,9,256,13,256,2048,2090,269,2091,0,263,2090,2340,257,1,2091,32,1,3,268,0,2048,2091,2090,2341,4,32,257,33,2090,13]

theorem envBound19950 : H12AffineFastState.Bounded env19950 := by
  intro p hp
  have h : env19950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19949_19950 : H12AffineEnvironment.transform 11 2090 env19949 = env19950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env19949 == env19950) = true)

theorem identity19950 : scanCanonicalize (H12AffineFastState.compose env19950 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound19950 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19951 : List Nat := [2,4,8,0,32,0,9,41,13,41,2048,2090,36,2091,0,46,2090,2061,40,1,2091,32,1,3,37,0,2048,2091,2090,2060,4,32,40,33,2090,13]

theorem envBound19951 : H12AffineFastState.Bounded env19951 := by
  intro p hp
  have h : env19951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19950_19951 : H12AffineEnvironment.transform 7 41 env19950 = env19951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env19950 == env19951) = true)

theorem identity19951 : scanCanonicalize (H12AffineFastState.compose env19951 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound19951 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19952 : List Nat := [2,4,8,0,32,0,9,41,13,41,44,6,36,7,0,46,6,33,40,1,7,32,1,3,37,0,44,7,6,32,4,32,40,33,6,13]

theorem envBound19952 : H12AffineFastState.Bounded env19952 := by
  intro p hp
  have h : env19952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19951_19952 : H12AffineEnvironment.transform 10 44 env19951 = env19952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env19951 == env19952) = true)

theorem identity19952 : scanCanonicalize (H12AffineFastState.compose env19952 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19952 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19953 : List Nat := [2,4,8,0,0,0,9,9,13,9,12,6,4,7,0,14,6,1,8,1,7,0,1,3,5,0,12,7,6,0,4,0,8,1,6,13]

theorem envBound19953 : H12AffineFastState.Bounded env19953 := by
  intro p hp
  have h : env19953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19952_19953 : H12AffineEnvironment.transform 4 0 env19952 = env19953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19952 == env19953) = true)

theorem identity19953 : scanCanonicalize (H12AffineFastState.compose env19953 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound19953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19954 : List Nat := [2,4,6,0,0,0,7,7,3,7,2,6,4,7,0,0,6,1,6,1,7,0,1,3,5,0,2,7,6,0,4,0,6,1,6,3]

theorem envBound19954 : H12AffineFastState.Bounded env19954 := by
  intro p hp
  have h : env19954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19953_19954 : H12AffineEnvironment.transform 2 6 env19953 = env19954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env19953 == env19954) = true)

theorem identity19954 : scanCanonicalize (H12AffineFastState.compose env19954 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound19954 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env19955 : List Nat := [2,2,0,0,0,0,1,1,3,1,2,0,2,1,0,0,0,1,0,1,1,0,1,3,3,0,2,1,0,0,2,0,0,1,0,3]

theorem envBound19955 : H12AffineFastState.Bounded env19955 := by
  intro p hp
  have h : env19955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19954_19955 : H12AffineEnvironment.transform 1 2 env19954 = env19955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env19954 == env19955) = true)

theorem identity19955 : scanCanonicalize (H12AffineFastState.compose env19955 (packedSelected [14] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound19955 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env19956 : List Nat := [1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,1,0,1,1,0,1,0,0,0,1,1,0,0,1,0,0,1,0,0]

theorem envBound19956 : H12AffineFastState.Bounded env19956 := by
  intro p hp
  have h : env19956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19955_19956 : H12AffineEnvironment.transform 0 1 env19955 = env19956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env19955 == env19956) = true)

def env19957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115870,272512,119967,98700,8328,17,23944,115103,17665,324741,119042,329731,257,21792,46212,63108]

theorem envBound19957 : H12AffineFastState.Bounded env19957 := by
  intro p hp
  have h : env19957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19939_19957 : H12AffineEnvironment.transform 5 17 env19939 = env19957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19939 == env19957) = true)

theorem identity19957 : scanCanonicalize (H12AffineFastState.compose env19957 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound19957 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env19958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,64808,1025,32769,115870,54696,119967,98700,8328,17,23944,115103,17665,2477,119042,128299,257,21792,46212,63108]

theorem envBound19958 : H12AffineFastState.Bounded env19958 := by
  intro p hp
  have h : env19958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19957_19958 : H12AffineEnvironment.transform 17 64808 env19957 = env19958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env19957 == env19958) = true)

theorem identity19958 : scanCanonicalize (H12AffineFastState.compose env19958 (packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound19958 : packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19959 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,16401,64808,1025,32769,25748,54696,29845,8582,8328,17,23944,24981,17665,2477,28936,21793,257,21792,46212,63108]

theorem envBound19959 : H12AffineFastState.Bounded env19959 := by
  intro p hp
  have h : env19959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19958_19959 : H12AffineEnvironment.transform 15 40970 env19958 = env19959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env19958 == env19959) = true)

theorem identity19959 : scanCanonicalize (H12AffineFastState.compose env19959 (packedSelected [19,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19959 : packedSelected [19,26] rootPS < 2^1333 := by decide +kernel

def env19960 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,32768,33030,16401,56356,1025,32769,17816,54696,21913,138,388,17,23944,16537,17665,2477,20484,21793,257,21792,38280,55176]

theorem envBound19960 : H12AffineFastState.Bounded env19960 := by
  intro p hp
  have h : env19960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19959_19960 : H12AffineEnvironment.transform 12 268 env19959 = env19960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19959 == env19960) = true)

theorem identity19960 : scanCanonicalize (H12AffineFastState.compose env19960 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19960 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env19961 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33030,16401,56356,1025,32769,17681,54561,21776,3,269,17,23809,16400,17665,2340,20484,21793,257,21792,38145,55041]

theorem envBound19961 : H12AffineFastState.Bounded env19961 := by
  intro p hp
  have h : env19961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19960_19961 : H12AffineEnvironment.transform 6 9 env19960 = env19961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19960 == env19961) = true)

theorem identity19961 : scanCanonicalize (H12AffineFastState.compose env19961 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound19961 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19962 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21541,21795,16401,2049,1025,21540,17681,260,21776,3,269,17,23809,16400,17665,2340,20484,21793,257,21792,16676,804]

theorem envBound19962 : H12AffineFastState.Bounded env19962 := by
  intro p hp
  have h : env19962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19961_19962 : H12AffineEnvironment.transform 14 21541 env19961 = env19962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env19961 == env19962) = true)

theorem identity19962 : scanCanonicalize (H12AffineFastState.compose env19962 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19962 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env19963 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,293,35,5393,2049,1025,292,4113,260,16,3,269,17,2049,5392,4097,2340,1284,33,257,32,5156,804]

theorem envBound19963 : H12AffineFastState.Bounded env19963 := by
  intro p hp
  have h : env19963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19962_19963 : H12AffineEnvironment.transform 13 5376 env19962 = env19963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19962 == env19963) = true)

theorem identity19963 : scanCanonicalize (H12AffineFastState.compose env19963 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19963 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19964 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5172,2049,1025,1,4113,33,16,3,40,17,2049,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound19964 : H12AffineFastState.Bounded env19964 := by
  intro p hp
  have h : env19964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19963_19964 : H12AffineEnvironment.transform 7 37 env19963 = env19964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19963 == env19964) = true)

theorem identity19964 : scanCanonicalize (H12AffineFastState.compose env19964 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound19964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19965 : List Nat := [2,4,8,16,32,17,9,37,512,4,2048,4096,41,4129,0,35,4144,2049,5,1,4113,33,16,3,40,17,2049,4145,4097,2049,37,33,36,32,4128,513]

theorem envBound19965 : H12AffineFastState.Bounded env19965 := by
  intro p hp
  have h : env19965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19964_19965 : H12AffineEnvironment.transform 9 4 env19964 = env19965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env19964 == env19965) = true)

theorem identity19965 : scanCanonicalize (H12AffineFastState.compose env19965 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound19965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19966 : List Nat := [2,4,8,16,32,17,9,37,512,4,2048,529,41,560,0,35,545,2049,5,1,512,33,16,3,40,17,2049,544,528,2049,37,33,36,32,561,513]

theorem envBound19966 : H12AffineFastState.Bounded env19966 := by
  intro p hp
  have h : env19966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19965_19966 : H12AffineEnvironment.transform 11 529 env19965 = env19966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env19965 == env19966) = true)

theorem identity19966 : scanCanonicalize (H12AffineFastState.compose env19966 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19966 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19967 : List Nat := [2,4,8,16,1,17,9,4,512,4,2048,529,8,529,0,2,512,2049,5,1,512,0,16,3,9,17,2049,513,528,2049,4,0,5,1,528,513]

theorem envBound19967 : H12AffineFastState.Bounded env19967 := by
  intro p hp
  have h : env19967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19966_19967 : H12AffineEnvironment.transform 4 1 env19966 = env19967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19966 == env19967) = true)

theorem identity19967 : scanCanonicalize (H12AffineFastState.compose env19967 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound19967 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19968 : List Nat := [2,4,8,16,1,17,9,4,512,4,512,529,8,529,0,2,512,513,5,1,512,0,16,3,9,17,513,513,528,513,4,0,5,1,528,513]

theorem envBound19968 : H12AffineFastState.Bounded env19968 := by
  intro p hp
  have h : env19968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19967_19968 : H12AffineEnvironment.transform 10 512 env19967 = env19968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env19967 == env19968) = true)

theorem identity19968 : scanCanonicalize (H12AffineFastState.compose env19968 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19968 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env19969 : List Nat := [2,4,8,1,1,0,9,4,512,4,512,512,8,512,0,2,512,513,5,1,512,0,1,3,9,0,513,513,513,513,4,0,5,1,513,513]

theorem envBound19969 : H12AffineFastState.Bounded env19969 := by
  intro p hp
  have h : env19969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19968_19969 : H12AffineEnvironment.transform 3 1 env19968 = env19969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19968 == env19969) = true)

theorem identity19969 : scanCanonicalize (H12AffineFastState.compose env19969 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19970 : List Nat := [2,4,8,1,1,0,9,4,1,4,1,1,8,1,0,2,1,0,5,1,1,0,1,3,9,0,0,0,0,0,4,0,5,1,0,0]

theorem envBound19970 : H12AffineFastState.Bounded env19970 := by
  intro p hp
  have h : env19970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19969_19970 : H12AffineEnvironment.transform 8 1 env19969 = env19970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19969 == env19970) = true)

theorem identity19970 : scanCanonicalize (H12AffineFastState.compose env19970 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19971 : List Nat := [2,4,3,1,1,0,2,4,1,4,1,1,3,1,0,2,1,0,5,1,1,0,1,3,2,0,0,0,0,0,4,0,5,1,0,0]

theorem envBound19971 : H12AffineFastState.Bounded env19971 := by
  intro p hp
  have h : env19971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19970_19971 : H12AffineEnvironment.transform 2 3 env19970 = env19971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19970 == env19971) = true)

def env19972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2201879,2098512,17665,2437194,2102684,2411676,257,21792,46212,2175563]

theorem envBound19972 : H12AffineFastState.Bounded env19972 := by
  intro p hp
  have h : env19972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19937_19972 : H12AffineEnvironment.transform 21 272513 env19937 = env19972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19937 == env19972) = true)

theorem identity19972 : scanCanonicalize (H12AffineFastState.compose env19972 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound19972 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13508,262144,1025,32769,2097152,272513,2101328,21762,8328,64,2117064,2098512,17665,2417813,2102684,2411676,257,21792,46212,2156180]

theorem envBound19973 : H12AffineFastState.Bounded env19973 := by
  intro p hp
  have h : env19973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19972_19973 : H12AffineEnvironment.transform 15 54495 env19972 = env19973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env19972 == env19973) = true)

def env19974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,262144,1025,32769,2097152,272393,2101328,21762,8192,64,2116928,2098512,17665,2417693,2102548,2411540,257,21792,46092,2156060]

theorem envBound19974 : H12AffineFastState.Bounded env19974 := by
  intro p hp
  have h : env19974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19973_19974 : H12AffineEnvironment.transform 6 8 env19973 = env19974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19973 == env19974) = true)

theorem identity19974 : scanCanonicalize (H12AffineFastState.compose env19974 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 314420) := by decide +kernel

theorem selectedBound19974 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env19975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,262144,1025,32769,314420,272393,318564,21762,8192,64,295284,313700,17665,10281,317728,32,257,21792,46092,272936]

theorem envBound19975 : H12AffineFastState.Bounded env19975 := by
  intro p hp
  have h : env19975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19974_19975 : H12AffineEnvironment.transform 20 314420 env19974 = env19975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314420 env19974 == env19975) = true)

theorem identity19975 : scanCanonicalize (H12AffineFastState.compose env19975 (packedSelected [2,3,4,6,9,11,15,16,18,19,20,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound19975 : packedSelected [2,3,4,6,9,11,15,16,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56356,1025,32769,4112,62509,64,21762,8192,64,23888,5440,17665,10281,1284,32,257,21792,46092,62988]

theorem envBound19976 : H12AffineFastState.Bounded env19976 := by
  intro p hp
  have h : env19976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19975_19976 : H12AffineEnvironment.transform 17 56356 env19975 = env19976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env19975 == env19976) = true)

theorem identity19976 : scanCanonicalize (H12AffineFastState.compose env19976 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19976 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env19977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30042,13388,32041,1025,8460,4112,21792,64,21762,8192,64,23888,5440,17665,10281,1284,32,257,21792,5377,22273]

theorem envBound19977 : H12AffineFastState.Bounded env19977 := by
  intro p hp
  have h : env19977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19976_19977 : H12AffineEnvironment.transform 14 8461 env19976 = env19977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19976 == env19977) = true)

theorem identity19977 : scanCanonicalize (H12AffineFastState.compose env19977 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19977 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env19978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8202,13388,10361,1025,8460,4112,112,64,82,8192,64,2048,5440,4177,10281,1284,32,257,112,5377,593]

theorem envBound19978 : H12AffineFastState.Bounded env19978 := by
  intro p hp
  have h : env19978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19977_19978 : H12AffineEnvironment.transform 13 5456 env19977 = env19978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19977 == env19978) = true)

theorem identity19978 : scanCanonicalize (H12AffineFastState.compose env19978 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound19978 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env19979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,8192,3173,8461,8202,11641,10361,1025,8460,2341,112,64,82,8192,64,2048,3189,2404,10281,1284,32,257,112,3124,593]

theorem envBound19979 : H12AffineFastState.Bounded env19979 := by
  intro p hp
  have h : env19979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19978_19979 : H12AffineEnvironment.transform 11 2357 env19978 = env19979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env19978 == env19979) = true)

theorem identity19979 : scanCanonicalize (H12AffineFastState.compose env19979 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19979 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19980 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,8192,3125,8461,8202,11561,10281,1025,8460,2341,32,16,2,8192,16,2048,3109,2356,10281,1284,32,257,32,3124,513]

theorem envBound19980 : H12AffineFastState.Bounded env19980 := by
  intro p hp
  have h : env19980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19979_19980 : H12AffineEnvironment.transform 5 16 env19979 = env19980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19979 == env19980) = true)

theorem identity19980 : scanCanonicalize (H12AffineFastState.compose env19980 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19980 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19981 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,268,3125,1,262,3109,2341,1025,0,2341,32,16,2,268,16,2048,3109,2356,2341,1284,32,257,32,3124,513]

theorem envBound19981 : H12AffineFastState.Bounded env19981 := by
  intro p hp
  have h : env19981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19980_19981 : H12AffineEnvironment.transform 12 268 env19980 = env19981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19980 == env19981) = true)

theorem identity19981 : scanCanonicalize (H12AffineFastState.compose env19981 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound19981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19982 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,1280,268,0,1,262,16,1296,1025,0,1296,32,16,2,268,16,1077,16,1281,1296,1284,32,257,32,1,513]

theorem envBound19982 : H12AffineFastState.Bounded env19982 := by
  intro p hp
  have h : env19982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19981_19982 : H12AffineEnvironment.transform 10 1077 env19981 = env19982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env19981 == env19982) = true)

theorem identity19982 : scanCanonicalize (H12AffineFastState.compose env19982 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound19982 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19983 : List Nat := [2,4,8,16,32,16,8,256,11,1024,1077,1280,268,0,1,262,16,1296,1025,0,1296,32,16,2,268,16,1077,16,1281,1296,1284,32,257,32,1,10]

theorem envBound19983 : H12AffineFastState.Bounded env19983 := by
  intro p hp
  have h : env19983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19982_19983 : H12AffineEnvironment.transform 8 11 env19982 = env19983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env19982 == env19983) = true)

theorem identity19983 : scanCanonicalize (H12AffineFastState.compose env19983 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19984 : List Nat := [2,4,8,16,0,16,8,256,11,1024,1045,1280,268,0,1,262,16,1296,1025,0,1296,0,16,2,268,16,1045,16,1281,1296,1284,0,257,0,1,10]

theorem envBound19984 : H12AffineFastState.Bounded env19984 := by
  intro p hp
  have h : env19984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19983_19984 : H12AffineEnvironment.transform 4 0 env19983 = env19984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19983 == env19984) = true)

def env19985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,262144,1025,32769,2097152,272392,2101328,21762,8193,64,2116929,2098512,17665,2417692,2102549,2411541,257,21792,46093,2156061]

theorem envBound19985 : H12AffineFastState.Bounded env19985 := by
  intro p hp
  have h : env19985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19973_19985 : H12AffineEnvironment.transform 6 9 env19973 = env19985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19973 == env19985) = true)

theorem identity19985 : scanCanonicalize (H12AffineFastState.compose env19985 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound19985 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env19986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,23669,1025,32769,2097152,29821,2101328,21762,8193,64,2116929,2098512,17665,2144361,2102549,2134112,257,21792,46093,2156061]

theorem envBound19986 : H12AffineFastState.Bounded env19986 := by
  intro p hp
  have h : env19986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19985_19986 : H12AffineEnvironment.transform 17 23669 env19985 = env19986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env19985 == env19986) = true)

theorem identity19986 : scanCanonicalize (H12AffineFastState.compose env19986 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound19986 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env19987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,23669,1025,32769,17729,29821,21777,21762,8193,64,2048,16401,17665,64808,20564,54561,257,21792,46093,41820]

theorem envBound19987 : H12AffineFastState.Bounded env19987 := by
  intro p hp
  have h : env19987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19986_19987 : H12AffineEnvironment.transform 20 17729 env19986 = env19987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env19986 == env19987) = true)

theorem identity19987 : scanCanonicalize (H12AffineFastState.compose env19987 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19987 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env19988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,13389,23669,1025,1,17729,29821,21777,21762,8193,64,2048,16401,17665,32040,20564,21793,257,21792,13325,9052]

theorem envBound19988 : H12AffineFastState.Bounded env19988 := by
  intro p hp
  have h : env19988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19987_19988 : H12AffineEnvironment.transform 14 0 env19987 = env19988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19987 == env19988) = true)

theorem identity19988 : scanCanonicalize (H12AffineFastState.compose env19988 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19988 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env19989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,343,13389,2420,1025,1,4160,8572,16,3,8193,64,2048,5392,4096,10281,1365,32,257,33,13325,9052]

theorem envBound19989 : H12AffineFastState.Bounded env19989 := by
  intro p hp
  have h : env19989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19988_19989 : H12AffineEnvironment.transform 13 5377 env19988 = env19989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19988 == env19989) = true)

theorem identity19989 : scanCanonicalize (H12AffineFastState.compose env19989 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound19989 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,5377,0,343,2404,2420,1025,1,4160,7253,16,3,7464,64,2048,5392,4096,5376,1365,32,257,33,2340,7797]

theorem envBound19990 : H12AffineFastState.Bounded env19990 := by
  intro p hp
  have h : env19990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19989_19990 : H12AffineEnvironment.transform 12 7465 env19989 = env19990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env19989 == env19990) = true)

theorem identity19990 : scanCanonicalize (H12AffineFastState.compose env19990 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound19990 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env19991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,2089,1,0,343,2404,2420,1025,1,1344,2389,16,3,2088,64,2048,16,1280,0,1365,32,257,33,2340,2933]

theorem envBound19991 : H12AffineFastState.Bounded env19991 := by
  intro p hp
  have h : env19991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19990_19991 : H12AffineEnvironment.transform 11 1280 env19990 = env19991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env19990 == env19991) = true)

theorem identity19991 : scanCanonicalize (H12AffineFastState.compose env19991 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound19991 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env19992 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,1124,2089,1,0,51,2048,2064,1025,1,1060,2097,16,3,2088,64,2048,16,1124,0,1073,32,101,33,2112,2577]

theorem envBound19992 : H12AffineFastState.Bounded env19992 := by
  intro p hp
  have h : env19992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19991_19992 : H12AffineEnvironment.transform 7 100 env19991 = env19992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env19991 == env19992) = true)

theorem identity19992 : scanCanonicalize (H12AffineFastState.compose env19992 (packedSelected [0,1,2,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound19992 : packedSelected [0,1,2,7,8,14] rootPS < 2^1333 := by decide +kernel

def env19993 : List Nat := [2,4,8,16,32,64,9,100,512,1024,1077,1124,1052,1,0,51,1077,1061,1025,1,1060,1028,16,3,1053,64,1077,16,1124,0,1073,32,101,33,1141,1572]

theorem envBound19993 : H12AffineFastState.Bounded env19993 := by
  intro p hp
  have h : env19993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19992_19993 : H12AffineEnvironment.transform 10 1077 env19992 = env19993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env19992 == env19993) = true)

theorem identity19993 : scanCanonicalize (H12AffineFastState.compose env19993 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound19993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19994 : List Nat := [2,4,8,16,32,64,9,100,512,37,16,65,57,1,0,51,16,0,36,1,1,33,16,3,56,64,16,16,65,0,20,32,101,33,80,513]

theorem envBound19994 : H12AffineFastState.Bounded env19994 := by
  intro p hp
  have h : env19994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19993_19994 : H12AffineEnvironment.transform 9 37 env19993 = env19994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env19993 == env19994) = true)

theorem identity19994 : scanCanonicalize (H12AffineFastState.compose env19994 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19994 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19995 : List Nat := [2,4,8,16,32,64,9,100,1,37,16,65,57,1,0,51,16,0,36,1,1,33,16,3,56,64,16,16,65,0,20,32,101,33,80,0]

theorem envBound19995 : H12AffineFastState.Bounded env19995 := by
  intro p hp
  have h : env19995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19994_19995 : H12AffineEnvironment.transform 8 1 env19994 = env19995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19994 == env19995) = true)

theorem identity19995 : scanCanonicalize (H12AffineFastState.compose env19995 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19995 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19996 : List Nat := [2,4,8,0,32,64,9,100,1,37,0,65,41,1,0,35,0,0,36,1,1,33,0,3,40,64,0,0,65,0,4,32,101,33,64,0]

theorem envBound19996 : H12AffineFastState.Bounded env19996 := by
  intro p hp
  have h : env19996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19995_19996 : H12AffineEnvironment.transform 3 0 env19995 = env19996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19995 == env19996) = true)

theorem identity19996 : scanCanonicalize (H12AffineFastState.compose env19996 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound19996 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19997 : List Nat := [2,4,8,0,32,0,9,36,1,37,0,1,41,1,0,35,0,0,36,1,1,33,0,3,40,0,0,0,1,0,4,32,37,33,0,0]

theorem envBound19997 : H12AffineFastState.Bounded env19997 := by
  intro p hp
  have h : env19997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19996_19997 : H12AffineEnvironment.transform 5 0 env19996 = env19997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env19996 == env19997) = true)

theorem identity19997 : scanCanonicalize (H12AffineFastState.compose env19997 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19998 : List Nat := [2,4,8,0,1,0,9,5,1,4,0,1,8,1,0,2,0,0,5,1,1,0,0,3,9,0,0,0,1,0,4,1,4,0,0,0]

theorem envBound19998 : H12AffineFastState.Bounded env19998 := by
  intro p hp
  have h : env19998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19997_19998 : H12AffineEnvironment.transform 4 1 env19997 = env19998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19997 == env19998) = true)

def env19999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664598,2098513,17664,2437195,2102684,6349852,257,21792,46212,2175563]

theorem envBound19999 : H12AffineFastState.Bounded env19999 := by
  intro p hp
  have h : env19999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19936_19999 : H12AffineEnvironment.transform 22 2101329 env19936 = env19999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19936 == env19999) = true)

def env20000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2201878,2098513,17664,2437195,2102684,2411676,257,21792,46212,2175563]

theorem envBound20000 : H12AffineFastState.Bounded env20000 := by
  intro p hp
  have h : env20000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19999_20000 : H12AffineEnvironment.transform 21 272512 env19999 = env20000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19999 == env20000) = true)

theorem identity20000 : scanCanonicalize (H12AffineFastState.compose env20000 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound20000 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272512,73755,98780,8328,64,43356,79131,17664,262145,75222,392406,257,21792,46212,513]

theorem envBound20001 : H12AffineFastState.Bounded env20001 := by
  intro p hp
  have h : env20001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20000_20001 : H12AffineEnvironment.transform 20 77898 env20000 = env20001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env20000 == env20001) = true)

theorem identity20001 : scanCanonicalize (H12AffineFastState.compose env20001 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound20001 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env20002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77898,73891,73755,98780,8328,64,43356,79131,17664,67618,75222,62709,257,21792,46212,513]

theorem envBound20002 : H12AffineFastState.Bounded env20002 := by
  intro p hp
  have h : env20002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20001_20002 : H12AffineEnvironment.transform 17 67619 env20001 = env20002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env20001 == env20002) = true)

theorem identity20002 : scanCanonicalize (H12AffineFastState.compose env20002 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20002 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env20003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73891,73755,66012,8328,64,10588,79131,17664,67618,75222,29941,257,21792,13444,513]

theorem envBound20003 : H12AffineFastState.Bounded env20003 := by
  intro p hp
  have h : env20003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20002_20003 : H12AffineEnvironment.transform 14 0 env20002 = env20003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20002 == env20003) = true)

def env20004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73771,73755,65876,8192,64,10588,79131,17664,67618,75102,29821,257,21792,13324,513]

theorem envBound20004 : H12AffineFastState.Bounded env20004 := by
  intro p hp
  have h : env20004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20003_20004 : H12AffineEnvironment.transform 6 8 env20003 = env20004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20003 == env20004) = true)

theorem identity20004 : scanCanonicalize (H12AffineFastState.compose env20004 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound20004 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21590,13389,23669,1025,1,25628,29821,29773,21762,8192,64,10588,24909,17664,23668,28936,29821,257,21792,13324,513]

theorem envBound20005 : H12AffineFastState.Bounded env20005 := by
  intro p hp
  have h : env20005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20004_20005 : H12AffineEnvironment.transform 15 21590 env20004 = env20005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env20004 == env20005) = true)

theorem identity20005 : scanCanonicalize (H12AffineFastState.compose env20005 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20005 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21590,5393,23669,1025,1,17728,21793,21777,21762,348,64,2048,16401,17664,23668,20564,21793,257,21792,5456,513]

theorem envBound20006 : H12AffineFastState.Bounded env20006 := by
  intro p hp
  have h : env20006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20005_20006 : H12AffineEnvironment.transform 12 348 env20005 = env20006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20005 == env20006) = true)

theorem identity20006 : scanCanonicalize (H12AffineFastState.compose env20006 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20006 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1025,1,4160,33,17,2,348,64,2048,5393,4096,2420,1364,33,257,32,5456,513]

theorem envBound20007 : H12AffineFastState.Bounded env20007 := by
  intro p hp
  have h : env20007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20006_20007 : H12AffineEnvironment.transform 13 5376 env20006 = env20007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20006 == env20007) = true)

theorem identity20007 : scanCanonicalize (H12AffineFastState.compose env20007 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound20007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,348,1125,0,342,1140,2421,1025,1,293,33,17,2,348,64,2048,1140,357,2420,1364,33,257,32,1077,513]

theorem envBound20008 : H12AffineFastState.Bounded env20008 := by
  intro p hp
  have h : env20008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20007_20008 : H12AffineEnvironment.transform 11 357 env20007 = env20008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env20007 == env20008) = true)

theorem identity20008 : scanCanonicalize (H12AffineFastState.compose env20008 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound20008 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,357,348,1125,0,342,1140,1296,1025,1,293,33,17,2,348,64,1125,1140,357,1297,1364,33,257,32,1077,513]

theorem envBound20009 : H12AffineFastState.Bounded env20009 := by
  intro p hp
  have h : env20009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20008_20009 : H12AffineEnvironment.transform 10 1125 env20008 = env20009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env20008 == env20009) = true)

theorem identity20009 : scanCanonicalize (H12AffineFastState.compose env20009 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound20009 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20010 : List Nat := [2,4,8,16,32,64,8,256,309,1024,1125,357,348,1125,0,342,1140,1296,1025,1,293,33,17,2,348,64,1125,1140,357,1297,1364,33,257,32,1077,308]

theorem envBound20010 : H12AffineFastState.Bounded env20010 := by
  intro p hp
  have h : env20010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20009_20010 : H12AffineEnvironment.transform 8 309 env20009 = env20010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env20009 == env20010) = true)

theorem identity20010 : scanCanonicalize (H12AffineFastState.compose env20010 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound20010 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env20011 : List Nat := [2,4,8,16,32,33,8,256,309,1024,1028,260,317,1028,0,311,1045,1296,1025,1,293,33,17,2,317,33,1028,1045,260,1297,1333,33,257,32,1077,308]

theorem envBound20011 : H12AffineFastState.Bounded env20011 := by
  intro p hp
  have h : env20011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20010_20011 : H12AffineEnvironment.transform 5 33 env20010 = env20011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env20010 == env20011) = true)

theorem identity20011 : scanCanonicalize (H12AffineFastState.compose env20011 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20011 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20012 : List Nat := [2,4,8,16,0,1,8,256,277,1024,1028,260,285,1028,0,279,1045,1296,1025,1,261,1,17,2,285,1,1028,1045,260,1297,1301,1,257,0,1045,276]

theorem envBound20012 : H12AffineFastState.Bounded env20012 := by
  intro p hp
  have h : env20012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20011_20012 : H12AffineEnvironment.transform 4 0 env20011 = env20012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20011 == env20012) = true)

theorem identity20012 : scanCanonicalize (H12AffineFastState.compose env20012 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20012 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env20013 : List Nat := [2,4,8,1,0,1,8,256,260,1024,1028,260,268,1028,0,262,1028,1281,1025,1,261,1,0,2,268,1,1028,1028,260,1280,1284,1,257,0,1028,261]

theorem envBound20013 : H12AffineFastState.Bounded env20013 := by
  intro p hp
  have h : env20013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20012_20013 : H12AffineEnvironment.transform 3 1 env20012 = env20013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20012 == env20013) = true)

theorem identity20013 : scanCanonicalize (H12AffineFastState.compose env20013 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound20013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20014 : List Nat := [2,4,8,1,0,1,8,256,260,256,260,260,268,260,0,262,260,1,257,1,261,1,0,2,268,1,260,260,260,0,4,1,257,0,260,261]

theorem envBound20014 : H12AffineFastState.Bounded env20014 := by
  intro p hp
  have h : env20014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20013_20014 : H12AffineEnvironment.transform 9 256 env20013 = env20014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20013 == env20014) = true)

theorem identity20014 : scanCanonicalize (H12AffineFastState.compose env20014 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20014 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20015 : List Nat := [2,4,8,1,0,1,8,4,0,4,0,0,8,0,0,2,0,1,5,1,1,1,0,2,8,1,0,0,0,0,4,1,5,0,0,1]

theorem envBound20015 : H12AffineFastState.Bounded env20015 := by
  intro p hp
  have h : env20015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20014_20015 : H12AffineEnvironment.transform 7 4 env20014 = env20015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20014 == env20015) = true)

def env20016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,67619,1025,1,77898,73770,73755,65877,8193,64,10588,79131,17664,67618,75103,29820,257,21792,13325,513]

theorem envBound20016 : H12AffineFastState.Bounded env20016 := by
  intro p hp
  have h : env20016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20003_20016 : H12AffineEnvironment.transform 6 9 env20003 = env20016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20003 == env20016) = true)

theorem identity20016 : scanCanonicalize (H12AffineFastState.compose env20016 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound20016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,342,24909,2421,1025,1,12572,8572,8525,3,8193,64,10588,13389,17664,2420,9225,29820,257,21792,13325,513]

theorem envBound20017 : H12AffineFastState.Bounded env20017 := by
  intro p hp
  have h : env20017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20016_20017 : H12AffineEnvironment.transform 15 342 env20016 = env20017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env20016 == env20017) = true)

def env20018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2201879,2098513,17664,2437195,2102684,2411677,257,21792,46212,2175563]

theorem envBound20018 : H12AffineFastState.Bounded env20018 := by
  intro p hp
  have h : env20018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19999_20018 : H12AffineEnvironment.transform 21 272513 env19999 = env20018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19999 == env20018) = true)

theorem identity20018 : scanCanonicalize (H12AffineFastState.compose env20018 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20018 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272513,2101329,41430,8328,64,2144541,2098513,17664,2363457,2102684,2411677,257,21792,46212,2101825]

theorem envBound20019 : H12AffineFastState.Bounded env20019 := by
  intro p hp
  have h : env20019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20018_20019 : H12AffineEnvironment.transform 15 8202 env20018 = env20019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20018 == env20019) = true)

theorem identity20019 : scanCanonicalize (H12AffineFastState.compose env20019 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309473) := by decide +kernel

theorem selectedBound20019 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env20020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,309473,272513,305328,41430,8328,64,262652,310704,17664,43168,306557,29820,257,21792,46212,305824]

theorem envBound20020 : H12AffineFastState.Bounded env20020 := by
  intro p hp
  have h : env20020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20019_20020 : H12AffineEnvironment.transform 20 309473 env20019 = env20020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309473 env20019 == env20020) = true)

theorem identity20020 : scanCanonicalize (H12AffineFastState.compose env20020 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound20020 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10400,1025,32769,36929,33,32784,41430,8328,64,10588,38160,17664,43168,34269,29820,257,21792,46212,33280]

theorem envBound20021 : H12AffineFastState.Bounded env20021 := by
  intro p hp
  have h : env20021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20020_20021 : H12AffineEnvironment.transform 17 10400 env20020 = env20021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20020 == env20021) = true)

theorem identity20021 : scanCanonicalize (H12AffineFastState.compose env20021 (packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound20021 : packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env20022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,13341,10400,1025,29709,25677,33,29724,21978,8328,64,10588,24860,17664,23724,29137,29820,257,21792,16520,30220]

theorem envBound20022 : H12AffineFastState.Bounded env20022 := by
  intro p hp
  have h : env20022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20021_20022 : H12AffineEnvironment.transform 14 29708 env20021 = env20022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env20021 == env20022) = true)

theorem identity20022 : scanCanonicalize (H12AffineFastState.compose env20022 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound20022 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env20023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,372,8202,13341,10400,1025,373,4405,33,356,8354,8328,64,10588,5220,12408,10708,1193,260,257,8280,13808,884]

theorem envBound20023 : H12AffineFastState.Bounded env20023 := by
  intro p hp
  have h : env20023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20022_20023 : H12AffineEnvironment.transform 13 13688 env20022 = env20023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env20022 == env20023) = true)

theorem identity20023 : scanCanonicalize (H12AffineFastState.compose env20023 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound20023 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env20024 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,13525,217,8202,13341,10400,1025,216,4248,33,201,8354,8328,64,10481,5220,12408,10361,1193,169,172,8280,13405,729]

theorem envBound20024 : H12AffineFastState.Bounded env20024 := by
  intro p hp
  have h : env20024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20023_20024 : H12AffineEnvironment.transform 7 173 env20023 = env20024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env20023 == env20024) = true)

theorem identity20024 : scanCanonicalize (H12AffineFastState.compose env20024 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20024 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20025 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,13444,136,8202,13341,10400,1025,137,4248,33,152,8354,8328,17,10400,5173,12329,10280,1193,169,172,8201,13324,648]

theorem envBound20025 : H12AffineFastState.Bounded env20025 := by
  intro p hp
  have h : env20025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20024_20025 : H12AffineEnvironment.transform 5 17 env20024 = env20025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20024 == env20025) = true)

theorem identity20025 : scanCanonicalize (H12AffineFastState.compose env20025 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound20025 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20026 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5157,136,171,5308,2049,1025,137,4248,33,152,3,41,17,2049,5173,4232,2185,1193,169,172,168,5293,648]

theorem envBound20026 : H12AffineFastState.Bounded env20026 := by
  intro p hp
  have h : env20026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20025_20026 : H12AffineEnvironment.transform 12 161 env20025 = env20026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20025 == env20026) = true)

theorem identity20026 : scanCanonicalize (H12AffineFastState.compose env20026 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20026 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env20027 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,9,5157,32,3,5140,2049,1025,33,4144,33,48,3,41,17,2049,5173,4128,2081,1025,1,4,0,5125,544]

theorem envBound20027 : H12AffineFastState.Bounded env20027 := by
  intro p hp
  have h : env20027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20026_20027 : H12AffineEnvironment.transform 6 40 env20026 = env20027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20026 == env20027) = true)

theorem identity20027 : scanCanonicalize (H12AffineFastState.compose env20027 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20027 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env20028 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,4096,9,4112,32,3,4129,2049,52,33,4144,33,48,3,41,17,2049,4096,4128,2081,52,1,4,0,4144,544]

theorem envBound20028 : H12AffineFastState.Bounded env20028 := by
  intro p hp
  have h : env20028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20027_20028 : H12AffineEnvironment.transform 9 53 env20027 = env20028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20027 == env20028) = true)

theorem identity20028 : scanCanonicalize (H12AffineFastState.compose env20028 (packedSelected [0,1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2623) := by decide +kernel

theorem selectedBound20028 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env20029 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,2623,9,2607,32,3,2590,2049,52,33,2575,33,48,3,41,17,2049,2623,2591,2081,52,1,4,0,2575,544]

theorem envBound20029 : H12AffineFastState.Bounded env20029 := by
  intro p hp
  have h : env20029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20028_20029 : H12AffineEnvironment.transform 11 2623 env20028 = env20029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2623 env20028 == env20029) = true)

def env20030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound20030 : H12AffineFastState.Bounded env20030 := by
  intro p hp
  have h : env20030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19335_20030 : H12AffineEnvironment.transform 25 65 env19335 = env20030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env19335 == env20030) = true)

def env20031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound20031 : H12AffineFastState.Bounded env20031 := by
  intro p hp
  have h : env20031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20030_20031 : H12AffineEnvironment.transform 26 30393344 env20030 = env20031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env20030 == env20031) = true)

def env20032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound20032 : H12AffineFastState.Bounded env20032 := by
  intro p hp
  have h : env20032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20031_20032 : H12AffineEnvironment.transform 18 1024 env20031 = env20032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20031 == env20032) = true)

theorem identity20032 : scanCanonicalize (H12AffineFastState.compose env20032 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534778) := by decide +kernel

theorem selectedBound20032 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534778,8328,65,14773626,469494,10507600,8830977,10955114,4704443,256,8874455,8882291,10882749]

theorem envBound20033 : H12AffineFastState.Bounded env20033 := by
  intro p hp
  have h : env20033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20032_20033 : H12AffineEnvironment.transform 23 2534778 env20032 = env20033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534778 env20032 == env20033) = true)

def env20034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773626,115150,10507600,8398905,10600786,4268163,256,8487407,8478795,10544773]

theorem envBound20034 : H12AffineFastState.Bounded env20034 := by
  intro p hp
  have h : env20034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20033_20034 : H12AffineEnvironment.transform 17 190520 env20033 = env20034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env20033 == env20034) = true)

def env20035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,2114882,8328,65,4291882,115150,17664,2111593,119042,4268163,256,2199999,2191387,63189]

theorem envBound20035 : H12AffineFastState.Bounded env20035 := by
  intro p hp
  have h : env20035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20034_20035 : H12AffineEnvironment.transform 22 2101328 env20034 = env20035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env20034 == env20035) = true)

def env20036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21762,8328,65,4291882,115150,17664,10281,119042,4268163,256,98815,90203,63189]

theorem envBound20036 : H12AffineFastState.Bounded env20036 := by
  intro p hp
  have h : env20036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20035_20036 : H12AffineEnvironment.transform 20 4160 env20035 = env20036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20035 == env20036) = true)

theorem identity20036 : scanCanonicalize (H12AffineFastState.compose env20036 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138476,1024,29909,4160,4194304,16,21762,8328,65,4291882,79130,17664,10281,75222,4268163,256,95531,90203,513]

theorem envBound20037 : H12AffineFastState.Bounded env20037 := by
  intro p hp
  have h : env20037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20036_20037 : H12AffineEnvironment.transform 14 29908 env20036 = env20037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20036 == env20037) = true)

def env20038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138476,1024,8661,4160,4194304,16,2,8328,65,4270122,79130,4096,10281,75222,4268163,256,73771,79195,513]

theorem envBound20038 : H12AffineFastState.Bounded env20038 := by
  intro p hp
  have h : env20038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20037_20038 : H12AffineEnvironment.transform 13 5376 env20037 = env20038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20037 == env20038) = true)

theorem identity20038 : scanCanonicalize (H12AffineFastState.compose env20038 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound20038 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10401,1024,8661,4160,4194304,16,2,8328,65,4270122,79130,4096,10281,75222,4268163,256,73771,79195,513]

theorem envBound20039 : H12AffineFastState.Bounded env20039 := by
  intro p hp
  have h : env20039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20038_20039 : H12AffineEnvironment.transform 16 13389 env20038 = env20039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env20038 == env20039) = true)

theorem identity20039 : scanCanonicalize (H12AffineFastState.compose env20039 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound20039 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env20040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10401,1024,8661,4160,8573,16,2,8328,65,67927,79130,4096,10281,75222,66046,256,73771,79195,513]

theorem envBound20040 : H12AffineFastState.Bounded env20040 := by
  intro p hp
  have h : env20040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20039_20040 : H12AffineEnvironment.transform 21 8573 env20039 = env20040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env20039 == env20040) = true)

theorem identity20040 : scanCanonicalize (H12AffineFastState.compose env20040 (packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20040 : packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env20041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,65536,5392,2556,1024,136,4160,32,16,2,469,65,67927,70727,4096,2420,66699,66046,256,65910,70662,513]

theorem envBound20041 : H12AffineFastState.Bounded env20041 := by
  intro p hp
  have h : env20041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20040_20041 : H12AffineEnvironment.transform 12 349 env20040 = env20041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20040 == env20041) = true)

theorem identity20041 : scanCanonicalize (H12AffineFastState.compose env20041 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound20041 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,343,5392,2556,1024,136,4160,32,16,2,469,65,2048,5392,4096,2420,1500,169,256,33,5457,513]

theorem envBound20042 : H12AffineFastState.Bounded env20042 := by
  intro p hp
  have h : env20042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20041_20042 : H12AffineEnvironment.transform 15 343 env20041 = env20042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env20041 == env20042) = true)

theorem identity20042 : scanCanonicalize (H12AffineFastState.compose env20042 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20042 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4160,32,16,2,348,65,2048,5392,4096,2420,1365,32,256,33,5457,513]

theorem envBound20043 : H12AffineFastState.Bounded env20043 := by
  intro p hp
  have h : env20043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20042_20043 : H12AffineEnvironment.transform 6 9 env20042 = env20043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20042 == env20043) = true)

theorem identity20043 : scanCanonicalize (H12AffineFastState.compose env20043 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound20043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,349,372,0,343,356,2421,1024,1,1076,32,16,2,348,65,2048,356,1140,2420,1365,32,256,33,293,513]

theorem envBound20044 : H12AffineFastState.Bounded env20044 := by
  intro p hp
  have h : env20044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20043_20044 : H12AffineEnvironment.transform 11 1140 env20043 = env20044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env20043 == env20044) = true)

theorem identity20044 : scanCanonicalize (H12AffineFastState.compose env20044 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound20044 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1140,349,372,0,343,356,0,1024,1,1076,32,16,2,348,65,373,356,1140,1,1365,32,256,33,293,513]

theorem envBound20045 : H12AffineFastState.Bounded env20045 := by
  intro p hp
  have h : env20045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20044_20045 : H12AffineEnvironment.transform 10 373 env20044 = env20045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env20044 == env20045) = true)

theorem identity20045 : scanCanonicalize (H12AffineFastState.compose env20045 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20045 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20046 : List Nat := [2,4,8,16,32,64,9,256,512,273,373,357,349,372,0,343,356,0,273,1,293,32,16,2,348,65,373,356,357,1,68,32,256,33,293,513]

theorem envBound20046 : H12AffineFastState.Bounded env20046 := by
  intro p hp
  have h : env20046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20045_20046 : H12AffineEnvironment.transform 9 273 env20045 = env20046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20045 == env20046) = true)

theorem identity20046 : scanCanonicalize (H12AffineFastState.compose env20046 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20046 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20047 : List Nat := [2,4,8,16,32,64,9,37,512,52,80,64,120,81,0,114,65,0,52,1,0,32,16,2,121,65,80,65,64,1,68,32,37,33,0,513]

theorem envBound20047 : H12AffineFastState.Bounded env20047 := by
  intro p hp
  have h : env20047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20046_20047 : H12AffineEnvironment.transform 7 37 env20046 = env20047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20046 == env20047) = true)

def env20048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138476,1024,8660,4160,4194304,16,3,8328,65,4270123,79130,4097,10281,75222,4268163,256,73770,79194,513]

theorem envBound20048 : H12AffineFastState.Bounded env20048 := by
  intro p hp
  have h : env20048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20037_20048 : H12AffineEnvironment.transform 13 5377 env20037 = env20048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20037 == env20048) = true)

theorem identity20048 : scanCanonicalize (H12AffineFastState.compose env20048 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound20048 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,10281,1024,8660,4160,4194304,16,3,8328,65,4270123,79130,4097,10281,75222,4268163,256,73770,79194,513]

theorem envBound20049 : H12AffineFastState.Bounded env20049 := by
  intro p hp
  have h : env20049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20048_20049 : H12AffineEnvironment.transform 16 13509 env20048 = env20049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env20048 == env20049) = true)

def env20050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,21763,8328,65,4291882,115150,17664,10280,119042,4268163,256,98814,90202,63189]

theorem envBound20050 : H12AffineFastState.Bounded env20050 := by
  intro p hp
  have h : env20050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20035_20050 : H12AffineEnvironment.transform 20 4161 env20035 = env20050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20035 == env20050) = true)

theorem identity20050 : scanCanonicalize (H12AffineFastState.compose env20050 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound20050 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,21763,8328,65,215366,115150,17664,10280,119042,201967,256,98814,90202,63189]

theorem envBound20051 : H12AffineFastState.Bounded env20051 := by
  intro p hp
  have h : env20051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20050_20051 : H12AffineEnvironment.transform 21 144492 env20050 = env20051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env20050 == env20051) = true)

def env20052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,21763,8192,65,215366,115014,17664,10280,119042,201831,256,98678,90202,63069]

theorem envBound20052 : H12AffineFastState.Bounded env20052 := by
  intro p hp
  have h : env20052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20051_20052 : H12AffineEnvironment.transform 6 8 env20051 = env20052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20051 == env20052) = true)

theorem identity20052 : scanCanonicalize (H12AffineFastState.compose env20052 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound20052 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138340,1024,29789,4161,144492,17,21763,8192,65,215366,79130,17664,10280,75102,201831,256,95530,90202,513]

theorem envBound20053 : H12AffineFastState.Bounded env20053 := by
  intro p hp
  have h : env20053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20052_20053 : H12AffineEnvironment.transform 14 29788 env20052 = env20053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env20052 == env20053) = true)

theorem identity20053 : scanCanonicalize (H12AffineFastState.compose env20053 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20053 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97406,1024,29789,4161,87158,17,21763,8192,65,10588,79130,17664,10280,75102,29821,256,95530,90202,513]

theorem envBound20054 : H12AffineFastState.Bounded env20054 := by
  intro p hp
  have h : env20054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20053_20054 : H12AffineEnvironment.transform 16 90138 env20053 = env20054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20053 == env20054) = true)

theorem identity20054 : scanCanonicalize (H12AffineFastState.compose env20054 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound20054 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,5393,2421,1024,29789,4161,8573,17,21763,8192,65,10588,16401,17664,10280,20565,29821,256,33,5457,513]

theorem envBound20055 : H12AffineFastState.Bounded env20055 := by
  intro p hp
  have h : env20055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20054_20055 : H12AffineEnvironment.transform 15 29963 env20054 = env20055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env20054 == env20055) = true)

theorem identity20055 : scanCanonicalize (H12AffineFastState.compose env20055 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20055 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,5393,2421,1024,21760,4161,32,17,21763,349,65,2049,16401,17664,2421,20565,21792,256,33,5457,513]

theorem envBound20056 : H12AffineFastState.Bounded env20056 := by
  intro p hp
  have h : env20056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20055_20056 : H12AffineEnvironment.transform 12 349 env20055 = env20056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20055 == env20056) = true)

theorem identity20056 : scanCanonicalize (H12AffineFastState.compose env20056 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20056 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1296,1095,5393,2421,1024,1297,4161,32,17,1298,349,65,2049,4096,5393,2421,68,1329,256,33,5457,513]

theorem envBound20057 : H12AffineFastState.Bounded env20057 := by
  intro p hp
  have h : env20057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20056_20057 : H12AffineEnvironment.transform 13 4113 env20056 = env20057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20056 == env20057) = true)

theorem identity20057 : scanCanonicalize (H12AffineFastState.compose env20057 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20057 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,349,4113,1296,1095,5393,1076,1024,1297,4161,32,17,1298,349,65,1344,4096,5393,1076,68,1329,256,33,5457,513]

theorem envBound20058 : H12AffineFastState.Bounded env20058 := by
  intro p hp
  have h : env20058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20057_20058 : H12AffineEnvironment.transform 10 1345 env20057 = env20058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env20057 == env20058) = true)

theorem identity20058 : scanCanonicalize (H12AffineFastState.compose env20058 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound20058 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env20059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1280,349,1297,1296,1095,17,1076,1024,1297,1345,32,17,1298,349,65,1344,1280,17,1076,68,1329,256,33,81,513]

theorem envBound20059 : H12AffineFastState.Bounded env20059 := by
  intro p hp
  have h : env20059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20058_20059 : H12AffineEnvironment.transform 11 1280 env20058 = env20059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env20058 == env20059) = true)

theorem identity20059 : scanCanonicalize (H12AffineFastState.compose env20059 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20059 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env20060 : List Nat := [2,4,8,16,32,64,8,256,512,52,373,308,349,293,292,115,17,0,52,293,373,32,17,294,349,65,372,308,17,0,68,261,256,33,81,513]

theorem envBound20060 : H12AffineFastState.Bounded env20060 := by
  intro p hp
  have h : env20060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20059_20060 : H12AffineEnvironment.transform 9 52 env20059 = env20060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20059 == env20060) = true)

theorem identity20060 : scanCanonicalize (H12AffineFastState.compose env20060 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20060 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env20061 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,308,268,293,292,34,17,0,52,293,292,32,17,294,268,16,293,308,17,0,21,261,256,33,0,513]

theorem envBound20061 : H12AffineFastState.Bounded env20061 := by
  intro p hp
  have h : env20061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20060_20061 : H12AffineEnvironment.transform 5 17 env20060 = env20061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20060 == env20061) = true)

def env20062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,21763,8193,65,215366,115015,17664,10280,119042,201830,256,98679,90202,63068]

theorem envBound20062 : H12AffineFastState.Bounded env20062 := by
  intro p hp
  have h : env20062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20051_20062 : H12AffineEnvironment.transform 6 9 env20051 = env20062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20051 == env20062) = true)

theorem identity20062 : scanCanonicalize (H12AffineFastState.compose env20062 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20062 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179512,1024,32769,4161,144492,17,3,8193,65,203846,103495,4096,10280,99330,201830,256,98679,79194,41820]

theorem envBound20063 : H12AffineFastState.Bounded env20063 := by
  intro p hp
  have h : env20063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20062_20063 : H12AffineEnvironment.transform 13 5376 env20062 = env20063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20062 == env20063) = true)

theorem identity20063 : scanCanonicalize (H12AffineFastState.compose env20063 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 37988) := by decide +kernel

theorem selectedBound20063 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env20064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,37988,10588,1024,32769,4161,40968,17,3,8193,65,100386,103495,4096,10280,99330,98306,256,98679,79194,41820]

theorem envBound20064 : H12AffineFastState.Bounded env20064 := by
  intro p hp
  have h : env20064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20063_20064 : H12AffineEnvironment.transform 16 37988 env20063 = env20064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37988 env20063 == env20064) = true)

theorem identity20064 : scanCanonicalize (H12AffineFastState.compose env20064 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,19,20,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20064 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,19,20,26] rootPS < 2^1333 := by decide +kernel

def env20065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,37988,2048,1024,32769,4161,33108,17,3,349,65,100386,103495,4096,2420,99330,98306,256,98679,70662,33280]

theorem envBound20065 : H12AffineFastState.Bounded env20065 := by
  intro p hp
  have h : env20065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20064_20065 : H12AffineEnvironment.transform 12 348 env20064 = env20065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20064 == env20065) = true)

theorem identity20065 : scanCanonicalize (H12AffineFastState.compose env20065 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20065 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,5221,2048,1024,0,4161,341,17,3,349,65,67619,70726,4096,2420,66563,65539,256,65910,70662,513]

theorem envBound20066 : H12AffineFastState.Bounded env20066 := by
  intro p hp
  have h : env20066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20065_20066 : H12AffineEnvironment.transform 14 1 env20065 = env20066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20065 == env20066) = true)

theorem identity20066 : scanCanonicalize (H12AffineFastState.compose env20066 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound20066 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,35,5221,2048,1024,0,4161,341,17,3,349,65,2048,5221,4096,2420,1056,32,256,341,5157,513]

theorem envBound20067 : H12AffineFastState.Bounded env20067 := by
  intro p hp
  have h : env20067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20066_20067 : H12AffineEnvironment.transform 15 35 env20066 = env20067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env20066 == env20067) = true)

theorem identity20067 : scanCanonicalize (H12AffineFastState.compose env20067 (packedSelected [3,4,5,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20067 : packedSelected [3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20068 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5157,1,35,5221,2048,1024,0,4161,112,17,3,120,65,2048,5221,4096,2129,1056,32,37,112,5157,513]

theorem envBound20068 : H12AffineFastState.Bounded env20068 := by
  intro p hp
  have h : env20068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20067_20068 : H12AffineEnvironment.transform 7 37 env20067 = env20068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20067 == env20068) = true)

def env20069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,2114882,8328,65,4291883,115150,17665,2111592,119043,4268163,256,2199998,2191386,63188]

theorem envBound20069 : H12AffineFastState.Bounded env20069 := by
  intro p hp
  have h : env20069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20034_20069 : H12AffineEnvironment.transform 22 2101329 env20034 = env20069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env20034 == env20069) = true)

def env20070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,21762,8328,65,4291883,115150,17665,10280,119043,4268163,256,98814,90202,63188]

theorem envBound20070 : H12AffineFastState.Bounded env20070 := by
  intro p hp
  have h : env20070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20069_20070 : H12AffineEnvironment.transform 20 4160 env20069 = env20070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20069 == env20070) = true)

theorem identity20070 : scanCanonicalize (H12AffineFastState.compose env20070 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound20070 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180408,17,21762,8328,65,245139,115150,17665,10280,119043,254011,256,98814,90202,63188]

theorem envBound20071 : H12AffineFastState.Bounded env20071 := by
  intro p hp
  have h : env20071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20070_20071 : H12AffineEnvironment.transform 21 180408 env20070 = env20071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env20070 == env20071) = true)

def env20072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180272,17,21762,8192,65,245019,115014,17665,10280,119043,254011,256,98678,90202,63068]

theorem envBound20072 : H12AffineFastState.Bounded env20072 := by
  intro p hp
  have h : env20072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20071_20072 : H12AffineEnvironment.transform 6 8 env20071 = env20072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20071 == env20072) = true)

theorem identity20072 : scanCanonicalize (H12AffineFastState.compose env20072 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20072 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138341,1024,29788,4160,144493,17,21762,8192,65,215366,79131,17665,10280,75102,201830,256,95531,90202,513]

theorem envBound20073 : H12AffineFastState.Bounded env20073 := by
  intro p hp
  have h : env20073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20072_20073 : H12AffineEnvironment.transform 14 29789 env20072 = env20073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20072 == env20073) = true)

theorem identity20073 : scanCanonicalize (H12AffineFastState.compose env20073 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20073 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97407,1024,29788,4160,87159,17,21762,8192,65,10588,79131,17665,10280,75102,29820,256,95531,90202,513]

theorem envBound20074 : H12AffineFastState.Bounded env20074 := by
  intro p hp
  have h : env20074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20073_20074 : H12AffineEnvironment.transform 16 90138 env20073 = env20074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20073 == env20074) = true)

theorem identity20074 : scanCanonicalize (H12AffineFastState.compose env20074 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20074 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2421,1024,29788,4160,8573,17,21762,8192,65,10588,16401,17665,10280,20564,29820,256,33,5456,513]

theorem envBound20075 : H12AffineFastState.Bounded env20075 := by
  intro p hp
  have h : env20075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20074_20075 : H12AffineEnvironment.transform 15 29962 env20074 = env20075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20074 == env20075) = true)

theorem identity20075 : scanCanonicalize (H12AffineFastState.compose env20075 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20075 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21591,5392,2421,1024,21761,4160,32,17,21762,349,65,2049,16401,17665,2421,20564,21793,256,33,5456,513]

theorem envBound20076 : H12AffineFastState.Bounded env20076 := by
  intro p hp
  have h : env20076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20075_20076 : H12AffineEnvironment.transform 12 349 env20075 = env20076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20075 == env20076) = true)

theorem identity20076 : scanCanonicalize (H12AffineFastState.compose env20076 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20076 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1297,1094,5392,2421,1024,1296,4160,32,17,1299,349,65,2049,4096,5392,2421,69,1328,256,33,5456,513]

theorem envBound20077 : H12AffineFastState.Bounded env20077 := by
  intro p hp
  have h : env20077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20076_20077 : H12AffineEnvironment.transform 13 4113 env20076 = env20077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20076 == env20077) = true)

theorem identity20077 : scanCanonicalize (H12AffineFastState.compose env20077 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound20077 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,349,4113,1297,1094,5392,1077,1024,1296,4160,32,17,1299,349,65,1345,4096,5392,1077,69,1328,256,33,5456,513]

theorem envBound20078 : H12AffineFastState.Bounded env20078 := by
  intro p hp
  have h : env20078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20077_20078 : H12AffineEnvironment.transform 10 1344 env20077 = env20078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env20077 == env20078) = true)

theorem identity20078 : scanCanonicalize (H12AffineFastState.compose env20078 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20078 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env20079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,17,349,0,1297,1094,1281,1077,1024,1296,81,32,17,1299,349,65,1345,17,1281,1077,69,1328,256,33,1345,513]

theorem envBound20079 : H12AffineFastState.Bounded env20079 := by
  intro p hp
  have h : env20079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20078_20079 : H12AffineEnvironment.transform 11 17 env20078 = env20079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20078 == env20079) = true)

theorem identity20079 : scanCanonicalize (H12AffineFastState.compose env20079 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20079 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env20080 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,17,349,0,373,34,357,81,100,372,81,32,17,375,349,65,293,17,357,81,69,340,256,33,293,513]

theorem envBound20080 : H12AffineFastState.Bounded env20080 := by
  intro p hp
  have h : env20080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20079_20080 : H12AffineEnvironment.transform 9 100 env20079 = env20080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20079 == env20080) = true)

theorem identity20080 : scanCanonicalize (H12AffineFastState.compose env20080 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound20080 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env20081 : List Nat := [2,4,8,16,32,64,8,53,512,100,17,17,104,0,64,34,80,81,100,65,81,32,17,66,104,65,16,17,80,81,69,97,53,33,16,513]

theorem envBound20081 : H12AffineFastState.Bounded env20081 := by
  intro p hp
  have h : env20081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20080_20081 : H12AffineEnvironment.transform 7 53 env20080 = env20081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env20080 == env20081) = true)

theorem identity20081 : scanCanonicalize (H12AffineFastState.compose env20081 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20081 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20082 : List Nat := [2,4,8,16,32,17,8,53,512,53,17,17,57,0,17,34,1,0,53,16,0,32,17,19,57,16,16,17,1,0,20,48,53,33,16,513]

theorem envBound20082 : H12AffineFastState.Bounded env20082 := by
  intro p hp
  have h : env20082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20081_20082 : H12AffineEnvironment.transform 5 17 env20081 = env20082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20081 == env20082) = true)

theorem identity20082 : scanCanonicalize (H12AffineFastState.compose env20082 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20082 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env20083 : List Nat := [2,4,8,1,32,0,8,36,512,36,0,0,40,0,0,34,1,0,36,1,0,32,0,2,40,1,1,0,1,0,5,33,36,33,1,513]

theorem envBound20083 : H12AffineFastState.Bounded env20083 := by
  intro p hp
  have h : env20083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20082_20083 : H12AffineEnvironment.transform 3 1 env20082 = env20083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20082 == env20083) = true)

theorem identity20083 : scanCanonicalize (H12AffineFastState.compose env20083 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound20083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20084 : List Nat := [2,4,8,1,32,0,8,36,32,36,0,0,40,0,0,34,1,0,36,1,0,32,0,2,40,1,1,0,1,0,5,33,36,33,1,33]

theorem envBound20084 : H12AffineFastState.Bounded env20084 := by
  intro p hp
  have h : env20084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20083_20084 : H12AffineEnvironment.transform 8 32 env20083 = env20084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env20083 == env20084) = true)

def env20085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180273,17,21762,8193,65,245018,115015,17665,10280,119043,254011,256,98679,90202,63069]

theorem envBound20085 : H12AffineFastState.Bounded env20085 := by
  intro p hp
  have h : env20085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20071_20085 : H12AffineEnvironment.transform 6 9 env20071 = env20085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20071 == env20085) = true)

theorem identity20085 : scanCanonicalize (H12AffineFastState.compose env20085 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20085 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179513,1024,32769,4160,169264,17,3,8193,65,245018,103494,4096,10280,99330,243002,256,98679,79195,41820]

theorem envBound20086 : H12AffineFastState.Bounded env20086 := by
  intro p hp
  have h : env20086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20085_20086 : H12AffineEnvironment.transform 13 5377 env20085 = env20086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20085 == env20086) = true)

theorem identity20086 : scanCanonicalize (H12AffineFastState.compose env20086 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20086 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env20087 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179513,1024,32769,4113,169264,17,3,8193,16,245018,103447,4096,10280,99330,243002,256,98598,79114,41741]

theorem envBound20087 : H12AffineFastState.Bounded env20087 := by
  intro p hp
  have h : env20087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20086_20087 : H12AffineEnvironment.transform 5 17 env20086 = env20087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20086 == env20087) = true)

theorem identity20087 : scanCanonicalize (H12AffineFastState.compose env20087 (packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound20087 : packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env20088 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10281,1024,32769,4113,32,17,3,8193,16,75786,103447,4096,10280,99330,73770,256,98598,79114,41741]

theorem envBound20088 : H12AffineFastState.Bounded env20088 := by
  intro p hp
  have h : env20088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20087_20088 : H12AffineEnvironment.transform 16 38160 env20087 = env20088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env20087 == env20088) = true)

theorem identity20088 : scanCanonicalize (H12AffineFastState.compose env20088 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound20088 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20089 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,32802,38160,10281,1024,32769,4113,32,17,3,8193,16,43048,5173,4096,10280,1056,40968,256,260,46376,41741]

theorem envBound20089 : H12AffineFastState.Bounded env20089 := by
  intro p hp
  have h : env20089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20088_20089 : H12AffineEnvironment.transform 15 32802 env20088 = env20089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env20088 == env20089) = true)

theorem identity20089 : scanCanonicalize (H12AffineFastState.compose env20089 (packedSelected [1,4,8,9,10,11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20089 : packedSelected [1,4,8,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env20090 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,35,5393,10281,1024,0,4113,32,17,3,8193,16,10281,5173,4096,10280,1056,8201,256,260,13609,8972]

theorem envBound20090 : H12AffineFastState.Bounded env20090 := by
  intro p hp
  have h : env20090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20089_20090 : H12AffineEnvironment.transform 14 1 env20089 = env20090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20089 == env20090) = true)

theorem identity20090 : scanCanonicalize (H12AffineFastState.compose env20090 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20090 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env20091 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,35,5393,2341,1024,0,4113,32,17,3,269,16,2341,5173,4096,2340,1056,261,256,260,5157,512]

theorem envBound20091 : H12AffineFastState.Bounded env20091 := by
  intro p hp
  have h : env20091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20090_20091 : H12AffineEnvironment.transform 12 268 env20090 = env20091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20090 == env20091) = true)

theorem identity20091 : scanCanonicalize (H12AffineFastState.compose env20091 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20091 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20092 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,5125,1,35,5141,2081,1024,0,4113,32,17,3,9,16,2081,5173,4096,2080,1056,1,4,0,5157,512]

theorem envBound20092 : H12AffineFastState.Bounded env20092 := by
  intro p hp
  have h : env20092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20091_20092 : H12AffineEnvironment.transform 7 4 env20091 = env20092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20091 == env20092) = true)

theorem identity20092 : scanCanonicalize (H12AffineFastState.compose env20092 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20092 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20093 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5125,1,3,5141,2049,1024,0,4113,0,17,3,9,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound20093 : H12AffineFastState.Bounded env20093 := by
  intro p hp
  have h : env20093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20092_20093 : H12AffineEnvironment.transform 4 0 env20092 = env20093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20092 == env20093) = true)

def env20094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21763,8328,65,4291883,115150,17665,10281,119043,4268163,256,98815,90203,63188]

theorem envBound20094 : H12AffineFastState.Bounded env20094 := by
  intro p hp
  have h : env20094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20069_20094 : H12AffineEnvironment.transform 20 4161 env20069 = env20094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20069 == env20094) = true)

def env20095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21763,8192,65,4291883,115014,17665,10281,119043,4268043,256,98679,90203,63068]

theorem envBound20095 : H12AffineFastState.Bounded env20095 := by
  intro p hp
  have h : env20095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20094_20095 : H12AffineEnvironment.transform 6 8 env20094 = env20095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20094 == env20095) = true)

theorem identity20095 : scanCanonicalize (H12AffineFastState.compose env20095 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound20095 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56436,1024,32769,4161,4194304,16,21763,8192,65,4291883,115014,17665,10281,119043,4268043,256,98679,90203,63068]

theorem envBound20096 : H12AffineFastState.Bounded env20096 := by
  intro p hp
  have h : env20096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20095_20096 : H12AffineEnvironment.transform 16 13388 env20095 = env20096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env20095 == env20096) = true)

theorem identity20096 : scanCanonicalize (H12AffineFastState.compose env20096 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(21+1) ^^^ 87159) := by decide +kernel

theorem selectedBound20096 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env20097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56436,1024,32769,4161,87159,16,21763,8192,65,10588,115014,17665,10281,119043,29820,256,98679,90203,63068]

theorem envBound20097 : H12AffineFastState.Bounded env20097 := by
  intro p hp
  have h : env20097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20096_20097 : H12AffineEnvironment.transform 21 87159 env20096 = env20097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87159 env20096 == env20097) = true)

theorem identity20097 : scanCanonicalize (H12AffineFastState.compose env20097 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20097 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env20098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,13388,23669,1024,0,4161,87159,16,21763,8192,65,10588,82247,17665,10281,86274,29820,256,65910,90203,30301]

theorem envBound20098 : H12AffineFastState.Bounded env20098 := by
  intro p hp
  have h : env20098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20097_20098 : H12AffineEnvironment.transform 14 1 env20097 = env20098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20097 == env20098) = true)

theorem identity20098 : scanCanonicalize (H12AffineFastState.compose env20098 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20098 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env20099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,65536,5393,23669,1024,0,4161,87159,16,21763,349,65,2049,82247,17665,2420,86274,21793,256,65910,82182,22272]

theorem envBound20099 : H12AffineFastState.Bounded env20099 := by
  intro p hp
  have h : env20099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20098_20099 : H12AffineEnvironment.transform 12 349 env20098 = env20099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20098 == env20099) = true)

theorem identity20099 : scanCanonicalize (H12AffineFastState.compose env20099 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound20099 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21590,5393,23669,1024,0,4161,33,16,21763,349,65,2049,5393,17665,2420,1364,21793,256,21792,5456,22272]

theorem envBound20100 : H12AffineFastState.Bounded env20100 := by
  intro p hp
  have h : env20100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20099_20100 : H12AffineEnvironment.transform 15 21590 env20099 = env20100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env20099 == env20100) = true)

theorem identity20100 : scanCanonicalize (H12AffineFastState.compose env20100 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound20100 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env20101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5408,1,374,5393,2389,1024,0,4161,33,16,35,349,65,2049,5393,4129,2420,1364,1,256,0,5456,544]

theorem envBound20101 : H12AffineFastState.Bounded env20101 := by
  intro p hp
  have h : env20101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20100_20101 : H12AffineEnvironment.transform 13 5408 env20100 = env20101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env20100 == env20101) = true)

theorem identity20101 : scanCanonicalize (H12AffineFastState.compose env20101 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20101 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20102 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5408,1,295,5393,2308,1024,0,4112,33,16,35,268,16,2049,5393,4129,2341,1285,1,256,0,5377,544]

theorem envBound20102 : H12AffineFastState.Bounded env20102 := by
  intro p hp
  have h : env20102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20101_20102 : H12AffineEnvironment.transform 5 17 env20101 = env20102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20101 == env20102) = true)

theorem identity20102 : scanCanonicalize (H12AffineFastState.compose env20102 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20102 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20103 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,1,263,5393,2308,1024,0,4112,1,16,3,268,16,2049,5393,4097,2309,1285,1,256,0,5377,512]

theorem envBound20103 : H12AffineFastState.Bounded env20103 := by
  intro p hp
  have h : env20103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20102_20103 : H12AffineEnvironment.transform 4 0 env20102 = env20103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20102 == env20103) = true)

theorem identity20103 : scanCanonicalize (H12AffineFastState.compose env20103 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound20103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20104 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,4096,268,4373,1,263,4356,2308,21,0,4112,1,16,3,268,16,2049,4356,4097,2309,272,1,256,0,4372,512]

theorem envBound20104 : H12AffineFastState.Bounded env20104 := by
  intro p hp
  have h : env20104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20103_20104 : H12AffineEnvironment.transform 9 21 env20103 = env20104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20103 == env20104) = true)

theorem identity20104 : scanCanonicalize (H12AffineFastState.compose env20104 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound20104 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20105 : List Nat := [2,4,8,16,0,17,8,256,512,21,522,4096,268,4373,1,263,4356,782,21,0,4112,1,16,3,268,16,523,4356,4097,783,272,1,256,0,4372,512]

theorem envBound20105 : H12AffineFastState.Bounded env20105 := by
  intro p hp
  have h : env20105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20104_20105 : H12AffineEnvironment.transform 10 522 env20104 = env20105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env20104 == env20105) = true)

theorem identity20105 : scanCanonicalize (H12AffineFastState.compose env20105 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound20105 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20106 : List Nat := [2,4,8,16,0,17,8,256,260,21,270,4096,268,4373,1,263,4356,10,21,0,4112,1,16,3,268,16,271,4356,4097,11,272,1,256,0,4372,260]

theorem envBound20106 : H12AffineFastState.Bounded env20106 := by
  intro p hp
  have h : env20106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20105_20106 : H12AffineEnvironment.transform 8 260 env20105 = env20106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env20105 == env20106) = true)

theorem identity20106 : scanCanonicalize (H12AffineFastState.compose env20106 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound20106 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20107 : List Nat := [2,4,8,16,0,17,8,256,260,21,270,261,268,16,1,263,1,10,21,0,277,1,16,3,268,16,271,1,260,11,272,1,256,0,17,260]

theorem envBound20107 : H12AffineFastState.Bounded env20107 := by
  intro p hp
  have h : env20107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20106_20107 : H12AffineEnvironment.transform 11 261 env20106 = env20107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env20106 == env20107) = true)

theorem identity20107 : scanCanonicalize (H12AffineFastState.compose env20107 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 23) := by decide +kernel

theorem selectedBound20107 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20108 : List Nat := [2,4,8,16,0,17,8,23,19,21,25,18,27,16,1,16,1,10,21,0,2,1,16,3,27,16,24,1,19,11,7,1,23,0,17,19]

theorem envBound20108 : H12AffineFastState.Bounded env20108 := by
  intro p hp
  have h : env20108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20107_20108 : H12AffineEnvironment.transform 7 23 env20107 = env20108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 23 env20107 == env20108) = true)

theorem identity20108 : scanCanonicalize (H12AffineFastState.compose env20108 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound20108 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20109 : List Nat := [2,4,8,3,0,2,8,4,0,6,10,1,8,3,1,3,1,10,6,0,2,1,3,3,8,3,11,1,0,11,7,1,4,0,2,0]

theorem envBound20109 : H12AffineFastState.Bounded env20109 := by
  intro p hp
  have h : env20109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20108_20109 : H12AffineEnvironment.transform 3 3 env20108 = env20109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env20108 == env20109) = true)

theorem identity20109 : scanCanonicalize (H12AffineFastState.compose env20109 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound20109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20110 : List Nat := [2,2,8,3,0,2,8,2,0,0,10,1,8,3,1,3,1,10,0,0,2,1,3,3,8,3,11,1,0,11,1,1,2,0,2,0]

theorem envBound20110 : H12AffineFastState.Bounded env20110 := by
  intro p hp
  have h : env20110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20109_20110 : H12AffineEnvironment.transform 1 2 env20109 = env20110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env20109 == env20110) = true)

def env20111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21763,8193,65,4291883,115015,17665,10281,119043,4268042,256,98678,90203,63069]

theorem envBound20111 : H12AffineFastState.Bounded env20111 := by
  intro p hp
  have h : env20111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20094_20111 : H12AffineEnvironment.transform 6 9 env20094 = env20111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20094 == env20111) = true)

theorem identity20111 : scanCanonicalize (H12AffineFastState.compose env20111 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound20111 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,32041,1024,32769,4161,4194304,16,21763,8193,65,4291883,115015,17665,10281,119043,4268042,256,98678,90203,63069]

theorem envBound20112 : H12AffineFastState.Bounded env20112 := by
  intro p hp
  have h : env20112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20111_20112 : H12AffineEnvironment.transform 16 38161 env20111 = env20112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env20111 == env20112) = true)

theorem identity20112 : scanCanonicalize (H12AffineFastState.compose env20112 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound20112 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env20113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,32041,1024,32769,4161,4194304,16,21763,8193,65,4229152,13388,17665,10281,9224,4248833,256,29821,38224,63069]

theorem envBound20113 : H12AffineFastState.Bounded env20113 := by
  intro p hp
  have h : env20113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20112_20113 : H12AffineEnvironment.transform 15 62731 env20112 = env20113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env20112 == env20113) = true)

theorem identity20113 : scanCanonicalize (H12AffineFastState.compose env20113 (packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS)) = affineNative (2^(21+1) ^^^ 62728) := by decide +kernel

theorem selectedBound20113 : packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS < 2^1333 := by decide +kernel

def env20114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,32041,1024,32769,4161,62728,16,21763,8193,65,32040,13388,17665,10281,9224,8201,256,29821,38224,63069]

theorem envBound20114 : H12AffineFastState.Bounded env20114 := by
  intro p hp
  have h : env20114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20113_20114 : H12AffineEnvironment.transform 21 62728 env20113 = env20114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62728 env20113 == env20114) = true)

theorem identity20114 : scanCanonicalize (H12AffineFastState.compose env20114 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound20114 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env20115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,24909,32041,1024,29789,4161,340,16,21763,8193,65,32040,13388,17665,10281,9224,8201,256,29821,24844,513]

theorem envBound20115 : H12AffineFastState.Bounded env20115 := by
  intro p hp
  have h : env20115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20114_20115 : H12AffineEnvironment.transform 14 29788 env20114 = env20115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env20114 == env20115) = true)

theorem identity20115 : scanCanonicalize (H12AffineFastState.compose env20115 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20115 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,9293,343,12636,11576,1024,9292,4161,340,16,1298,8193,65,11577,13388,5392,10281,9224,8201,256,9324,12573,513]

theorem envBound20116 : H12AffineFastState.Bounded env20116 := by
  intro p hp
  have h : env20116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20115_20116 : H12AffineEnvironment.transform 13 4113 env20115 = env20116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20115 == env20116) = true)

theorem identity20116 : scanCanonicalize (H12AffineFastState.compose env20116 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20116 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1297,343,4096,3172,1024,1296,4161,340,16,1298,349,65,3173,5392,5392,2421,1364,341,256,1328,4161,513]

theorem envBound20117 : H12AffineFastState.Bounded env20117 := by
  intro p hp
  have h : env20117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20116_20117 : H12AffineEnvironment.transform 12 348 env20116 = env20117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20116 == env20117) = true)

theorem identity20117 : scanCanonicalize (H12AffineFastState.compose env20117 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound20117 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,0,348,17,1297,343,0,3172,1024,1296,65,340,16,1298,349,65,3173,1296,1296,2421,1364,341,256,1328,65,513]

theorem envBound20118 : H12AffineFastState.Bounded env20118 := by
  intro p hp
  have h : env20118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20117_20118 : H12AffineEnvironment.transform 11 0 env20117 = env20118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env20117 == env20118) = true)

theorem identity20118 : scanCanonicalize (H12AffineFastState.compose env20118 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20118 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20119 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,0,120,17,1077,115,0,3172,1024,1076,65,112,16,1078,121,65,3173,1076,1076,2129,1136,113,36,1044,65,513]

theorem envBound20119 : H12AffineFastState.Bounded env20119 := by
  intro p hp
  have h : env20119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20118_20119 : H12AffineEnvironment.transform 7 36 env20118 = env20119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20118 == env20119) = true)

theorem identity20119 : scanCanonicalize (H12AffineFastState.compose env20119 (packedSelected [1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound20119 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env20120 : List Nat := [2,4,8,16,32,64,9,36,512,533,2048,0,120,17,544,115,0,2673,533,545,65,112,16,547,121,65,2672,545,545,2129,613,113,36,513,65,513]

theorem envBound20120 : H12AffineFastState.Bounded env20120 := by
  intro p hp
  have h : env20120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20119_20120 : H12AffineEnvironment.transform 9 533 env20119 = env20120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env20119 == env20120) = true)

theorem identity20120 : scanCanonicalize (H12AffineFastState.compose env20120 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20120 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20121 : List Nat := [2,4,8,16,32,64,9,36,0,21,2048,0,120,17,32,115,0,2161,21,33,65,112,16,35,121,65,2160,33,33,2129,101,113,36,1,65,1]

theorem envBound20121 : H12AffineFastState.Bounded env20121 := by
  intro p hp
  have h : env20121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20120_20121 : H12AffineEnvironment.transform 8 0 env20120 = env20121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20120 == env20121) = true)

theorem identity20121 : scanCanonicalize (H12AffineFastState.compose env20121 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20122 : List Nat := [2,4,8,16,1,64,9,5,0,21,2048,0,89,17,1,82,0,2128,21,0,65,81,16,2,88,65,2129,0,0,2129,68,80,5,1,65,1]

theorem envBound20122 : H12AffineFastState.Bounded env20122 := by
  intro p hp
  have h : env20122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20121_20122 : H12AffineEnvironment.transform 4 1 env20121 = env20122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20121 == env20122) = true)

def env20123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773626,115151,10507600,8398904,10600787,4268162,256,8487406,8478794,10544772]

theorem envBound20123 : H12AffineFastState.Bounded env20123 := by
  intro p hp
  have h : env20123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20033_20123 : H12AffineEnvironment.transform 17 190521 env20033 = env20123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env20033 == env20123) = true)

def env20124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,2114883,8328,65,4291882,115151,17664,2111592,119043,4268162,256,2199998,2191386,63188]

theorem envBound20124 : H12AffineFastState.Bounded env20124 := by
  intro p hp
  have h : env20124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20123_20124 : H12AffineEnvironment.transform 22 2101328 env20123 = env20124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env20123 == env20124) = true)

def env20125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21763,8328,65,4291882,115151,17664,10280,119043,4268162,256,98814,90202,63188]

theorem envBound20125 : H12AffineFastState.Bounded env20125 := by
  intro p hp
  have h : env20125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20124_20125 : H12AffineEnvironment.transform 20 4160 env20124 = env20125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20124 == env20125) = true)

theorem identity20125 : scanCanonicalize (H12AffineFastState.compose env20125 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20125 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,4194304,16,21763,8328,65,4218144,57797,17664,10280,61705,4194440,256,41460,16464,63188]

theorem envBound20126 : H12AffineFastState.Bounded env20126 := by
  intro p hp
  have h : env20126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20125_20126 : H12AffineEnvironment.transform 15 8202 env20125 = env20126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20125 == env20126) = true)

def env20127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,4194304,16,21763,8192,65,4218144,57677,17664,10280,61705,4194304,256,41340,16464,63068]

theorem envBound20127 : H12AffineFastState.Bounded env20127 := by
  intro p hp
  have h : env20127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20127 : H12AffineEnvironment.transform 6 8 env20126 = env20127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20126 == env20127) = true)

theorem identity20127 : scanCanonicalize (H12AffineFastState.compose env20127 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound20127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,56436,1024,32769,4160,4194304,16,21763,8192,65,4218144,57677,17664,10280,61705,4194304,256,41340,16464,63068]

theorem envBound20128 : H12AffineFastState.Bounded env20128 := by
  intro p hp
  have h : env20128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20127_20128 : H12AffineEnvironment.transform 16 13389 env20127 = env20128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env20127 == env20128) = true)

theorem identity20128 : scanCanonicalize (H12AffineFastState.compose env20128 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound20128 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,56436,1024,32769,4160,29820,16,21763,8192,65,10588,57677,17664,10280,61705,29820,256,41340,16464,63068]

theorem envBound20129 : H12AffineFastState.Bounded env20129 := by
  intro p hp
  have h : env20129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20128_20129 : H12AffineEnvironment.transform 21 29820 env20128 = env20129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env20128 == env20129) = true)

theorem identity20129 : scanCanonicalize (H12AffineFastState.compose env20129 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound20129 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env20130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8202,13389,23589,1024,80,4160,29820,16,21763,8192,65,10588,24860,17664,10280,29016,29820,256,8493,16464,30221]

theorem envBound20130 : H12AffineFastState.Bounded env20130 := by
  intro p hp
  have h : env20130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20129_20130 : H12AffineEnvironment.transform 14 81 env20129 = env20130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env20129 == env20130) = true)

theorem identity20130 : scanCanonicalize (H12AffineFastState.compose env20130 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20130 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env20131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,262,5441,23589,1024,80,4160,21872,16,21763,268,65,2128,16400,17664,2340,20564,21872,256,33,16464,22273]

theorem envBound20131 : H12AffineFastState.Bounded env20131 := by
  intro p hp
  have h : env20131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20130_20131 : H12AffineEnvironment.transform 12 268 env20130 = env20131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20130 == env20131) = true)

theorem identity20131 : scanCanonicalize (H12AffineFastState.compose env20131 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20131 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,262,5441,2340,1024,80,4160,113,16,2,268,65,2128,5393,4097,2340,1365,113,256,33,5457,512]

theorem envBound20132 : H12AffineFastState.Bounded env20132 := by
  intro p hp
  have h : env20132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20131_20132 : H12AffineEnvironment.transform 13 5377 env20131 = env20132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20131 == env20132) = true)

theorem identity20132 : scanCanonicalize (H12AffineFastState.compose env20132 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20132 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20133 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,268,5377,33,262,5425,2340,1024,32,4144,1,16,2,268,49,2080,5393,4097,2340,1317,1,256,33,5409,512]

theorem envBound20133 : H12AffineFastState.Bounded env20133 := by
  intro p hp
  have h : env20133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20132_20133 : H12AffineEnvironment.transform 5 48 env20132 = env20133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20132 == env20133) = true)

theorem identity20133 : scanCanonicalize (H12AffineFastState.compose env20133 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound20133 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20134 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,4096,268,4144,33,262,4096,2340,305,32,4144,1,16,2,268,49,2080,4128,4097,2340,20,1,256,33,4112,512]

theorem envBound20134 : H12AffineFastState.Bounded env20134 := by
  intro p hp
  have h : env20134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20133_20134 : H12AffineEnvironment.transform 9 305 env20133 = env20134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env20133 == env20134) = true)

theorem identity20134 : scanCanonicalize (H12AffineFastState.compose env20134 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound20134 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20135 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,2341,268,2325,33,262,2341,2340,305,32,2325,1,16,2,268,49,2080,2309,2340,2340,20,1,256,33,2357,512]

theorem envBound20135 : H12AffineFastState.Bounded env20135 := by
  intro p hp
  have h : env20135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20134_20135 : H12AffineEnvironment.transform 11 2341 env20134 = env20135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env20134 == env20135) = true)

theorem identity20135 : scanCanonicalize (H12AffineFastState.compose env20135 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound20135 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20136 : List Nat := [2,4,8,16,32,48,8,256,512,305,32,261,268,309,33,262,261,260,305,32,309,1,16,2,268,49,0,293,260,260,20,1,256,33,277,512]

theorem envBound20136 : H12AffineFastState.Bounded env20136 := by
  intro p hp
  have h : env20136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20135_20136 : H12AffineEnvironment.transform 10 32 env20135 = env20136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env20135 == env20136) = true)

theorem identity20136 : scanCanonicalize (H12AffineFastState.compose env20136 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20137 : List Nat := [2,4,8,16,16,0,8,256,512,257,16,261,268,261,17,262,261,260,257,16,261,1,16,2,268,1,0,277,260,260,20,1,256,17,277,512]

theorem envBound20137 : H12AffineFastState.Bounded env20137 := by
  intro p hp
  have h : env20137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20136_20137 : H12AffineEnvironment.transform 4 16 env20136 = env20137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20136 == env20137) = true)

theorem identity20137 : scanCanonicalize (H12AffineFastState.compose env20137 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20137 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20138 : List Nat := [2,4,8,1,1,0,8,256,512,257,1,261,268,261,0,262,261,260,257,1,261,1,1,2,268,1,0,260,260,260,5,1,256,0,260,512]

theorem envBound20138 : H12AffineFastState.Bounded env20138 := by
  intro p hp
  have h : env20138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20137_20138 : H12AffineEnvironment.transform 3 1 env20137 = env20138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20137 == env20138) = true)

theorem identity20138 : scanCanonicalize (H12AffineFastState.compose env20138 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20139 : List Nat := [2,1,8,1,1,0,8,256,512,257,1,256,265,256,0,259,256,257,257,1,256,1,1,2,265,1,0,257,257,257,0,1,256,0,257,512]

theorem envBound20139 : H12AffineFastState.Bounded env20139 := by
  intro p hp
  have h : env20139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20138_20139 : H12AffineEnvironment.transform 1 1 env20138 = env20139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20138 == env20139) = true)

def env20140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,4194304,16,21763,8193,65,4218144,57676,17664,10280,61705,4194305,256,41341,16464,63069]

theorem envBound20140 : H12AffineFastState.Bounded env20140 := by
  intro p hp
  have h : env20140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20140 : H12AffineEnvironment.transform 6 9 env20126 = env20140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20126 == env20140) = true)

theorem identity20140 : scanCanonicalize (H12AffineFastState.compose env20140 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound20140 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,32041,1024,32769,4160,4194304,16,21763,8193,65,4218144,57676,17664,10280,61705,4194305,256,41341,16464,63069]

theorem envBound20141 : H12AffineFastState.Bounded env20141 := by
  intro p hp
  have h : env20141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20140_20141 : H12AffineEnvironment.transform 16 38160 env20140 = env20141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env20140 == env20141) = true)

theorem identity20141 : scanCanonicalize (H12AffineFastState.compose env20141 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound20141 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,32041,1024,32769,4160,41340,16,21763,8193,65,64604,57676,17664,10280,61705,41341,256,41341,16464,63069]

theorem envBound20142 : H12AffineFastState.Bounded env20142 := by
  intro p hp
  have h : env20142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20141_20142 : H12AffineEnvironment.transform 21 41340 env20141 = env20142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env20141 == env20142) = true)

theorem identity20142 : scanCanonicalize (H12AffineFastState.compose env20142 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20142 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,38160,23668,1024,32769,4160,32801,16,21763,348,65,56577,49169,17664,2421,53332,32800,256,32800,16464,55040]

theorem envBound20143 : H12AffineFastState.Bounded env20143 := by
  intro p hp
  have h : env20143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20142_20143 : H12AffineEnvironment.transform 12 349 env20142 = env20143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20142 == env20143) = true)

theorem identity20143 : scanCanonicalize (H12AffineFastState.compose env20143 (packedSelected [2,3,4,6,8,9,10,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 7499) := by decide +kernel

theorem selectedBound20143 : packedSelected [2,3,4,6,8,9,10,15,16,18] rootPS < 2^1333 := by decide +kernel

def env20144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,7499,343,2139,23668,1024,7498,4160,7530,16,21763,348,65,16458,23898,17664,2421,19743,7531,256,7531,16464,19019]

theorem envBound20144 : H12AffineFastState.Bounded env20144 := by
  intro p hp
  have h : env20144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20143_20144 : H12AffineEnvironment.transform 14 7499 env20143 = env20144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7499 env20143 == env20144) = true)

theorem identity20144 : scanCanonicalize (H12AffineFastState.compose env20144 (packedSelected [1,2,5,11,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound20144 : packedSelected [1,2,5,11,15,19] rootPS < 2^1333 := by decide +kernel

def env20145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5204,7499,343,2139,2080,1024,7498,4160,7530,16,343,348,65,5150,2318,4436,2421,6475,7531,256,7531,5124,7711]

theorem envBound20145 : H12AffineFastState.Bounded env20145 := by
  intro p hp
  have h : env20145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20144_20145 : H12AffineEnvironment.transform 13 5204 env20144 = env20145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env20144 == env20145) = true)

theorem identity20145 : scanCanonicalize (H12AffineFastState.compose env20145 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound20145 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3102,349,2122,341,343,2139,2080,1024,340,3166,372,16,343,348,65,2048,2318,3402,2421,1365,373,256,373,2074,513]

theorem envBound20146 : H12AffineFastState.Bounded env20146 := by
  intro p hp
  have h : env20146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20145_20146 : H12AffineEnvironment.transform 11 3102 env20145 = env20146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env20145 == env20146) = true)

theorem identity20146 : scanCanonicalize (H12AffineFastState.compose env20146 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20146 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20147 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3102,301,2106,293,295,2091,2080,1024,292,3118,260,16,295,300,49,2048,2318,3386,2309,1317,261,256,261,2074,513]

theorem envBound20147 : H12AffineFastState.Bounded env20147 := by
  intro p hp
  have h : env20147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20146_20147 : H12AffineEnvironment.transform 5 48 env20146 = env20147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20146 == env20147) = true)

theorem identity20147 : scanCanonicalize (H12AffineFastState.compose env20147 (packedSelected [3,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound20147 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env20148 : List Nat := [2,4,8,16,32,48,9,14,512,1024,2048,3102,35,2106,43,41,2091,2080,1024,42,3118,10,16,41,34,49,2048,2048,3124,2059,1067,11,14,11,2074,513]

theorem envBound20148 : H12AffineFastState.Bounded env20148 := by
  intro p hp
  have h : env20148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20147_20148 : H12AffineEnvironment.transform 7 14 env20147 = env20148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env20147 == env20148) = true)

theorem identity20148 : scanCanonicalize (H12AffineFastState.compose env20148 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound20148 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env20149 : List Nat := [2,4,8,16,32,48,9,14,512,1024,16,1038,35,42,43,41,59,48,1024,42,1086,10,16,41,34,49,16,16,1060,27,1067,11,14,11,10,513]

theorem envBound20149 : H12AffineFastState.Bounded env20149 := by
  intro p hp
  have h : env20149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20148_20149 : H12AffineEnvironment.transform 10 16 env20148 = env20149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env20148 == env20149) = true)

theorem identity20149 : scanCanonicalize (H12AffineFastState.compose env20149 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound20149 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env20150 : List Nat := [2,4,8,16,32,48,9,14,512,575,16,561,35,42,43,41,59,48,575,42,513,10,16,41,34,49,16,16,539,27,532,11,14,11,10,513]

theorem envBound20150 : H12AffineFastState.Bounded env20150 := by
  intro p hp
  have h : env20150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20149_20150 : H12AffineEnvironment.transform 9 575 env20149 = env20150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env20149 == env20150) = true)

theorem identity20150 : scanCanonicalize (H12AffineFastState.compose env20150 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound20150 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env20151 : List Nat := [2,4,8,16,32,48,9,14,24,39,16,41,35,42,43,41,59,48,39,42,25,10,16,41,34,49,16,16,3,27,12,11,14,11,10,25]

theorem envBound20151 : H12AffineFastState.Bounded env20151 := by
  intro p hp
  have h : env20151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20150_20151 : H12AffineEnvironment.transform 8 24 env20150 = env20151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env20150 == env20151) = true)

theorem identity20151 : scanCanonicalize (H12AffineFastState.compose env20151 (packedSelected [0,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound20151 : packedSelected [0,2,3,8] rootPS < 2^1333 := by decide +kernel

def env20152 : List Nat := [2,4,8,12,32,44,9,14,4,39,12,41,35,42,43,41,39,44,39,42,5,10,12,41,34,45,12,12,3,7,12,11,14,11,10,5]

theorem envBound20152 : H12AffineFastState.Bounded env20152 := by
  intro p hp
  have h : env20152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20151_20152 : H12AffineEnvironment.transform 3 12 env20151 = env20152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env20151 == env20152) = true)

theorem identity20152 : scanCanonicalize (H12AffineFastState.compose env20152 (packedSelected [0,2,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound20152 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env20153 : List Nat := [2,4,5,1,32,33,4,3,4,39,1,36,35,39,38,36,39,33,39,39,5,7,1,36,34,32,1,1,3,7,1,6,3,6,7,5]

theorem envBound20153 : H12AffineFastState.Bounded env20153 := by
  intro p hp
  have h : env20153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20152_20153 : H12AffineEnvironment.transform 2 5 env20152 = env20153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env20152 == env20153) = true)

theorem identity20153 : scanCanonicalize (H12AffineFastState.compose env20153 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound20153 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env20154 : List Nat := [2,2,3,1,32,33,2,3,2,33,1,34,35,33,32,34,33,33,33,33,3,1,1,34,34,32,1,1,3,1,1,0,3,0,1,3]

theorem envBound20154 : H12AffineFastState.Bounded env20154 := by
  intro p hp
  have h : env20154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20153_20154 : H12AffineEnvironment.transform 1 2 env20153 = env20154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env20153 == env20154) = true)

theorem identity20154 : scanCanonicalize (H12AffineFastState.compose env20154 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20154 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20155 : List Nat := [2,2,3,1,1,0,2,3,2,0,1,3,2,0,1,3,0,0,0,0,3,1,1,3,3,1,1,1,3,1,1,0,3,0,1,3]

theorem envBound20155 : H12AffineFastState.Bounded env20155 := by
  intro p hp
  have h : env20155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20154_20155 : H12AffineEnvironment.transform 4 1 env20154 = env20155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20154 == env20155) = true)

def env20156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,21762,8328,65,4291882,115151,17664,10281,119043,4268162,256,98815,90203,63188]

theorem envBound20156 : H12AffineFastState.Bounded env20156 := by
  intro p hp
  have h : env20156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20124_20156 : H12AffineEnvironment.transform 20 4161 env20124 = env20156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20124 == env20156) = true)

theorem identity20156 : scanCanonicalize (H12AffineFastState.compose env20156 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254130) := by decide +kernel

theorem selectedBound20156 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254130,17,21762,8328,65,171416,115151,17664,10281,119043,180272,256,98815,90203,63188]

theorem envBound20157 : H12AffineFastState.Bounded env20157 := by
  intro p hp
  have h : env20157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20156_20157 : H12AffineEnvironment.transform 21 254130 env20156 = env20157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254130 env20156 == env20157) = true)

def env20158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254010,17,21762,8192,65,171280,115015,17664,10281,119043,180272,256,98679,90203,63068]

theorem envBound20158 : H12AffineFastState.Bounded env20158 := by
  intro p hp
  have h : env20158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20157_20158 : H12AffineEnvironment.transform 6 8 env20157 = env20158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20157 == env20158) = true)

theorem identity20158 : scanCanonicalize (H12AffineFastState.compose env20158 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138340,1024,29788,4161,201831,17,21762,8192,65,158029,79130,17664,10281,75102,144493,256,95530,90203,513]

theorem envBound20159 : H12AffineFastState.Bounded env20159 := by
  intro p hp
  have h : env20159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20158_20159 : H12AffineEnvironment.transform 14 29789 env20158 = env20159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20158 == env20159) = true)

theorem identity20159 : scanCanonicalize (H12AffineFastState.compose env20159 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20159 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97406,1024,29788,4161,29821,17,21762,8192,65,67927,79130,17664,10281,75102,87159,256,95530,90203,513]

theorem envBound20160 : H12AffineFastState.Bounded env20160 := by
  intro p hp
  have h : env20160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20159_20160 : H12AffineEnvironment.transform 16 90138 env20159 = env20160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20159 == env20160) = true)

theorem identity20160 : scanCanonicalize (H12AffineFastState.compose env20160 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20160 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2420,1024,29788,4161,29821,17,21762,8192,65,31837,16400,17664,10281,20564,8573,256,32,5457,513]

theorem envBound20161 : H12AffineFastState.Bounded env20161 := by
  intro p hp
  have h : env20161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20160_20161 : H12AffineEnvironment.transform 15 29962 env20160 = env20161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20160 == env20161) = true)

theorem identity20161 : scanCanonicalize (H12AffineFastState.compose env20161 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20161 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env20162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21541,21874,5392,2420,1024,21540,4161,21509,17,21762,120,65,23589,16400,17664,2129,20564,261,256,32,5457,513]

theorem envBound20162 : H12AffineFastState.Bounded env20162 := by
  intro p hp
  have h : env20162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20161_20162 : H12AffineEnvironment.transform 12 120 env20161 = env20162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20161 == env20162) = true)

theorem identity20162 : scanCanonicalize (H12AffineFastState.compose env20162 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound20162 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env20163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5157,0,343,5392,2420,1024,1,4161,32,17,295,120,65,2048,5173,4389,2129,1137,261,256,32,5457,513]

theorem envBound20163 : H12AffineFastState.Bounded env20163 := by
  intro p hp
  have h : env20163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20162_20163 : H12AffineEnvironment.transform 13 5157 env20162 = env20163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env20162 == env20163) = true)

theorem identity20163 : scanCanonicalize (H12AffineFastState.compose env20163 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound20163 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env20164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,120,5157,0,343,5392,292,1024,1,4161,32,17,295,120,65,80,5173,4389,1,1137,261,256,32,5457,513]

theorem envBound20164 : H12AffineFastState.Bounded env20164 := by
  intro p hp
  have h : env20164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20163_20164 : H12AffineEnvironment.transform 10 80 env20163 = env20164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env20163 == env20164) = true)

theorem identity20164 : scanCanonicalize (H12AffineFastState.compose env20164 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20164 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env20165 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,120,4405,0,343,4096,292,272,1,4161,32,17,295,120,65,80,4389,4389,1,353,261,256,32,4161,513]

theorem envBound20165 : H12AffineFastState.Bounded env20165 := by
  intro p hp
  have h : env20165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20164_20165 : H12AffineEnvironment.transform 9 272 env20164 = env20165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20164 == env20165) = true)

theorem identity20165 : scanCanonicalize (H12AffineFastState.compose env20165 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound20165 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env20166 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,308,120,1,0,343,308,292,272,1,373,32,17,295,120,65,80,17,17,1,353,261,256,32,373,513]

theorem envBound20166 : H12AffineFastState.Bounded env20166 := by
  intro p hp
  have h : env20166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20165_20166 : H12AffineEnvironment.transform 11 308 env20165 = env20166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env20165 == env20166) = true)

theorem identity20166 : scanCanonicalize (H12AffineFastState.compose env20166 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20166 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20167 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,308,41,1,0,262,308,292,272,1,292,32,17,295,41,16,1,17,17,1,304,261,256,32,292,513]

theorem envBound20167 : H12AffineFastState.Bounded env20167 := by
  intro p hp
  have h : env20167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20166_20167 : H12AffineEnvironment.transform 5 17 env20166 = env20167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20166 == env20167) = true)

theorem identity20167 : scanCanonicalize (H12AffineFastState.compose env20167 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound20167 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env20168 : List Nat := [2,4,8,16,32,17,8,256,319,272,1,308,41,1,0,262,308,292,272,1,292,32,17,295,41,16,1,17,17,1,304,261,256,32,292,318]

theorem envBound20168 : H12AffineFastState.Bounded env20168 := by
  intro p hp
  have h : env20168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20167_20168 : H12AffineEnvironment.transform 8 319 env20167 = env20168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env20167 == env20168) = true)

theorem identity20168 : scanCanonicalize (H12AffineFastState.compose env20168 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound20168 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env20169 : List Nat := [2,4,8,16,32,17,8,46,17,62,1,26,41,1,0,40,26,10,62,1,10,32,17,9,41,16,1,17,17,1,30,43,46,32,10,16]

theorem envBound20169 : H12AffineFastState.Bounded env20169 := by
  intro p hp
  have h : env20169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20168_20169 : H12AffineEnvironment.transform 7 46 env20168 = env20169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env20168 == env20169) = true)

def env20170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254011,17,21762,8193,65,171281,115014,17664,10281,119043,180272,256,98678,90203,63069]

theorem envBound20170 : H12AffineFastState.Bounded env20170 := by
  intro p hp
  have h : env20170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20157_20170 : H12AffineEnvironment.transform 6 9 env20157 = env20170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20157 == env20170) = true)

theorem identity20170 : scanCanonicalize (H12AffineFastState.compose env20170 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20170 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179512,1024,32769,4161,243002,17,3,8193,65,171281,103495,4097,10281,99330,169265,256,98678,79194,41820]

theorem envBound20171 : H12AffineFastState.Bounded env20171 := by
  intro p hp
  have h : env20171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20170_20171 : H12AffineEnvironment.transform 13 5377 env20170 = env20171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20170 == env20171) = true)

theorem identity20171 : scanCanonicalize (H12AffineFastState.compose env20171 (packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound20171 : packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env20172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13673,34897,1024,32769,4161,98387,17,3,8193,65,43128,103495,4097,10281,99330,41048,256,98678,79194,41820]

theorem envBound20172 : H12AffineFastState.Bounded env20172 := by
  intro p hp
  have h : env20172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20171_20172 : H12AffineEnvironment.transform 16 13673 env20171 = env20172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env20171 == env20172) = true)

theorem identity20172 : scanCanonicalize (H12AffineFastState.compose env20172 (packedSelected [1,2,5,8,11,14,16,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20172 : packedSelected [1,2,5,8,11,14,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,65536,5220,34897,1024,32769,4161,98387,17,3,268,65,35189,103495,4097,2340,99330,33109,256,98678,70743,33361]

theorem envBound20173 : H12AffineFastState.Bounded env20173 := by
  intro p hp
  have h : env20173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20172_20173 : H12AffineEnvironment.transform 12 269 env20172 = env20173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20172 == env20173) = true)

theorem identity20173 : scanCanonicalize (H12AffineFastState.compose env20173 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound20173 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env20174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,35,5220,34897,1024,32769,4161,32880,17,3,268,65,35189,37988,4097,2340,33825,33109,256,33109,5236,33361]

theorem envBound20174 : H12AffineFastState.Bounded env20174 := by
  intro p hp
  have h : env20174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20173_20174 : H12AffineEnvironment.transform 15 35 env20173 = env20174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env20173 == env20174) = true)

theorem identity20174 : scanCanonicalize (H12AffineFastState.compose env20174 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20174 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,35,5220,2128,1024,0,4161,113,17,3,268,65,2420,5221,4097,2340,1056,340,256,340,5236,592]

theorem envBound20175 : H12AffineFastState.Bounded env20175 := by
  intro p hp
  have h : env20175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20174_20175 : H12AffineEnvironment.transform 14 1 env20174 = env20175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20174 == env20175) = true)

theorem identity20175 : scanCanonicalize (H12AffineFastState.compose env20175 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound20175 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env20176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,269,0,1,35,357,2128,1024,0,1344,113,17,3,268,65,2420,356,1280,2340,1056,340,256,340,373,592]

theorem envBound20176 : H12AffineFastState.Bounded env20176 := by
  intro p hp
  have h : env20176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20175_20176 : H12AffineEnvironment.transform 11 1281 env20175 = env20176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env20175 == env20176) = true)

theorem identity20176 : scanCanonicalize (H12AffineFastState.compose env20176 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20176 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20177 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1281,269,0,1,35,309,2048,1024,0,1296,33,17,3,268,17,2340,308,1280,2340,1056,260,256,260,293,512]

theorem envBound20177 : H12AffineFastState.Bounded env20177 := by
  intro p hp
  have h : env20177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20176_20177 : H12AffineEnvironment.transform 5 16 env20176 = env20177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20176 == env20177) = true)

theorem identity20177 : scanCanonicalize (H12AffineFastState.compose env20177 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20177 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20178 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,308,269,0,1,35,309,2048,53,0,293,33,17,3,268,17,2340,308,309,2340,21,260,256,260,293,512]

theorem envBound20178 : H12AffineFastState.Bounded env20178 := by
  intro p hp
  have h : env20178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20177_20178 : H12AffineEnvironment.transform 9 53 env20177 = env20178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20177 == env20178) = true)

theorem identity20178 : scanCanonicalize (H12AffineFastState.compose env20178 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20178 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20179 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,49,8,0,1,35,48,2048,53,0,32,33,17,3,9,17,2081,49,48,2081,21,1,5,1,32,512]

theorem envBound20179 : H12AffineFastState.Bounded env20179 := by
  intro p hp
  have h : env20179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20178_20179 : H12AffineEnvironment.transform 7 5 env20178 = env20179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20178 == env20179) = true)

theorem identity20179 : scanCanonicalize (H12AffineFastState.compose env20179 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound20179 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env20180 : List Nat := [2,4,8,16,32,16,9,5,512,53,21,49,8,0,1,35,48,21,53,0,32,33,17,3,9,17,52,49,48,52,21,1,5,1,32,512]

theorem envBound20180 : H12AffineFastState.Bounded env20180 := by
  intro p hp
  have h : env20180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20179_20180 : H12AffineEnvironment.transform 10 21 env20179 = env20180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env20179 == env20180) = true)

def env20181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,2114883,8328,65,4291883,115151,17665,2111593,119042,4268162,256,2199999,2191387,63189]

theorem envBound20181 : H12AffineFastState.Bounded env20181 := by
  intro p hp
  have h : env20181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20123_20181 : H12AffineEnvironment.transform 22 2101329 env20123 = env20181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env20123 == env20181) = true)

def env20182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,21763,8328,65,4291883,115151,17665,10281,119042,4268162,256,98815,90203,63189]

theorem envBound20182 : H12AffineFastState.Bounded env20182 := by
  intro p hp
  have h : env20182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20181_20182 : H12AffineEnvironment.transform 20 4160 env20181 = env20182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20181 == env20182) = true)

theorem identity20182 : scanCanonicalize (H12AffineFastState.compose env20182 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201830) := by decide +kernel

theorem selectedBound20182 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,201830,17,21763,8328,65,158029,115151,17665,10281,119042,144612,256,98815,90203,63189]

theorem envBound20183 : H12AffineFastState.Bounded env20183 := by
  intro p hp
  have h : env20183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20182_20183 : H12AffineEnvironment.transform 21 201830 env20182 = env20183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201830 env20182 == env20183) = true)

theorem identity20183 : scanCanonicalize (H12AffineFastState.compose env20183 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20183 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138477,1024,29909,4160,201830,17,21763,8328,65,158029,79131,17665,10281,75222,144612,256,95531,90203,513]

theorem envBound20184 : H12AffineFastState.Bounded env20184 := by
  intro p hp
  have h : env20184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20183_20184 : H12AffineEnvironment.transform 14 29908 env20183 = env20184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20183 == env20184) = true)

theorem identity20184 : scanCanonicalize (H12AffineFastState.compose env20184 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20184 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,97527,1024,29909,4160,29820,17,21763,8328,65,67927,79131,17665,10281,75222,87294,256,95531,90203,513]

theorem envBound20185 : H12AffineFastState.Bounded env20185 := by
  intro p hp
  have h : env20185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20184_20185 : H12AffineEnvironment.transform 16 90138 env20184 = env20185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20184 == env20185) = true)

theorem identity20185 : scanCanonicalize (H12AffineFastState.compose env20185 (packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound20185 : packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS < 2^1333 := by decide +kernel

def env20186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,5528,2421,1024,29909,4160,29820,17,21763,8328,65,31957,16537,17665,10281,20564,8572,256,169,5593,513]

theorem envBound20186 : H12AffineFastState.Bounded env20186 := by
  intro p hp
  have h : env20186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20185_20186 : H12AffineEnvironment.transform 15 30082 env20185 = env20186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env20185 == env20186) = true)

theorem identity20186 : scanCanonicalize (H12AffineFastState.compose env20186 (packedSelected [0,1,3,4,6,7,8,9,10,12,15,17,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20186 : packedSelected [0,1,3,4,6,7,8,9,10,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env20187 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29708,30042,5440,2421,1024,29709,4160,29820,17,21763,8272,65,31757,16449,17665,10281,20564,8572,256,113,5377,513]

end H12CloudChart0