import H12CloudChart0Data124

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound31718 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31719 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4113,1297,34,5392,2340,1024,1296,4112,32,17,1078,269,16,3344,5393,5393,2341,1284,33,256,1328,4112,805]

theorem envBound31719 : H12AffineFastState.Bounded env31719 := by
  intro p hp
  have h : env31719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31718_31719 : H12AffineEnvironment.transform 13 4113 env31718 = env31719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31718 == env31719) = true)

theorem identity31719 : scanCanonicalize (H12AffineFastState.compose env31719 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31719 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31720 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,4113,1077,34,5172,2048,1024,1076,4112,32,17,1078,41,16,3124,5173,5173,2049,1056,33,36,1044,4112,513]

theorem envBound31720 : H12AffineFastState.Bounded env31720 := by
  intro p hp
  have h : env31720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31719_31720 : H12AffineEnvironment.transform 7 36 env31719 = env31720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31719 == env31720) = true)

def env31721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound31721 : H12AffineFastState.Bounded env31721 := by
  intro p hp
  have h : env31721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31579_31721 : H12AffineEnvironment.transform 18 1025 env31579 = env31721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31579 == env31721) = true)

theorem identity31721 : scanCanonicalize (H12AffineFastState.compose env31721 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound31721 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575541,18973836,10507600,8538484,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound31722 : H12AffineFastState.Bounded env31722 := by
  intro p hp
  have h : env31722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31721_31722 : H12AffineEnvironment.transform 17 35189 env31721 = env31722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env31721 == env31722) = true)

def env31723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575541,18973700,10507600,8538484,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound31723 : H12AffineFastState.Bounded env31723 := by
  intro p hp
  have h : env31723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31722_31723 : H12AffineEnvironment.transform 6 8 env31722 = env31723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31722 == env31723) = true)

theorem identity31723 : scanCanonicalize (H12AffineFastState.compose env31723 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound31723 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env31724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29370734,18973700,10507600,8464751,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound31724 : H12AffineFastState.Bounded env31724 := by
  intro p hp
  have h : env31724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31723_31724 : H12AffineEnvironment.transform 16 90139 env31723 = env31724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env31723 == env31724) = true)

def env31725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,8388608,98644,8192,65,12691514,2098512,10507600,8464751,8389956,6349852,257,10503537,10527837,8462874]

theorem envBound31725 : H12AffineFastState.Bounded env31725 := by
  intro p hp
  have h : env31725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31724_31725 : H12AffineEnvironment.transform 23 98644 env31724 = env31725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98644 env31724 == env31725) = true)

theorem identity31725 : scanCanonicalize (H12AffineFastState.compose env31725 (packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound31725 : packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env31726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,98678,8388608,98644,8192,65,8399180,2098512,10507600,8464751,8389956,2188650,257,10503537,10527837,8462874]

theorem envBound31726 : H12AffineFastState.Bounded env31726 := by
  intro p hp
  have h : env31726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31725_31726 : H12AffineEnvironment.transform 21 98678 env31725 = env31726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env31725 == env31726) = true)

def env31727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,4160,98678,8388608,98644,8192,65,8399180,5392,8406288,8464751,8389956,95530,257,8410417,8434717,8462874]

theorem envBound31727 : H12AffineFastState.Bounded env31727 := by
  intro p hp
  have h : env31727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31726_31727 : H12AffineEnvironment.transform 20 4160 env31726 = env31727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31726 == env31727) = true)

def env31728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,4160,98678,16,98644,8192,65,10588,5392,17664,76159,1364,95530,257,21793,46093,74250]

theorem envBound31728 : H12AffineFastState.Bounded env31728 := by
  intro p hp
  have h : env31728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31727_31728 : H12AffineEnvironment.transform 22 16 env31727 = env31728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31727 == env31728) = true)

theorem identity31728 : scanCanonicalize (H12AffineFastState.compose env31728 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,4160,41340,16,41310,8192,65,10588,5392,17664,2421,1364,21792,257,21793,46093,512]

theorem envBound31729 : H12AffineFastState.Bounded env31729 := by
  intro p hp
  have h : env31729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31728_31729 : H12AffineEnvironment.transform 15 8202 env31728 = env31729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31728 == env31729) = true)

theorem identity31729 : scanCanonicalize (H12AffineFastState.compose env31729 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound31729 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,8202,13625,35189,1025,32769,4160,41340,16,41310,8192,65,10588,5392,12328,2421,1364,8200,257,8201,46093,512]

theorem envBound31730 : H12AffineFastState.Bounded env31730 := by
  intro p hp
  have h : env31730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31729_31730 : H12AffineEnvironment.transform 13 13608 env31729 = env31730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env31729 == env31730) = true)

theorem identity31730 : scanCanonicalize (H12AffineFastState.compose env31730 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31730 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5157,32768,263,5172,35189,1025,32769,4160,32881,16,32851,269,65,2129,5392,4389,2421,1364,261,257,260,38144,512]

theorem envBound31731 : H12AffineFastState.Bounded env31731 := by
  intro p hp
  have h : env31731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31730_31731 : H12AffineEnvironment.transform 12 269 env31730 = env31731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31730 == env31731) = true)

theorem identity31731 : scanCanonicalize (H12AffineFastState.compose env31731 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31731 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env31732 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,32768,263,5172,35109,1025,32769,4112,32801,16,32771,269,17,2049,5392,4389,2341,1284,261,257,260,38144,512]

theorem envBound31732 : H12AffineFastState.Bounded env31732 := by
  intro p hp
  have h : env31732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31731_31732 : H12AffineEnvironment.transform 5 16 env31731 = env31732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31731 == env31732) = true)

theorem identity31732 : scanCanonicalize (H12AffineFastState.compose env31732 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31732 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31733 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5124,32768,263,5141,35076,1025,32769,4112,32768,16,32771,269,17,2049,5392,4356,2308,1284,261,257,260,38144,512]

theorem envBound31733 : H12AffineFastState.Bounded env31733 := by
  intro p hp
  have h : env31733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31732_31733 : H12AffineEnvironment.transform 4 1 env31732 = env31733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31732 == env31733) = true)

theorem identity31733 : scanCanonicalize (H12AffineFastState.compose env31733 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound31733 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env31734 : List Nat := [2,4,8,16,1,16,8,256,512,1024,782,4096,269,5124,32768,263,5141,33290,1025,32769,4112,32768,16,32771,269,17,783,5392,4356,522,1284,261,257,260,38144,512]

theorem envBound31734 : H12AffineFastState.Bounded env31734 := by
  intro p hp
  have h : env31734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31733_31734 : H12AffineEnvironment.transform 10 782 env31733 = env31734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env31733 == env31734) = true)

theorem identity31734 : scanCanonicalize (H12AffineFastState.compose env31734 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31734 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env31735 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,4096,8,5124,32768,2,5141,33290,1025,32769,4112,32768,16,32771,8,17,522,5141,4097,522,1025,0,4,1,37893,512]

theorem envBound31735 : H12AffineFastState.Bounded env31735 := by
  intro p hp
  have h : env31735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31734_31735 : H12AffineEnvironment.transform 7 5 env31734 = env31735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31734 == env31735) = true)

theorem identity31735 : scanCanonicalize (H12AffineFastState.compose env31735 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 1044) := by decide +kernel

theorem selectedBound31735 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31736 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,4096,8,5124,1044,2,5141,1566,1025,1045,4112,1044,16,1047,8,17,522,5141,4097,522,1025,0,4,1,4113,512]

theorem envBound31736 : H12AffineFastState.Bounded env31736 := by
  intro p hp
  have h : env31736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31735_31736 : H12AffineEnvironment.transform 14 1044 env31735 = env31736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1044 env31735 == env31736) = true)

theorem identity31736 : scanCanonicalize (H12AffineFastState.compose env31736 (packedSelected [3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1052) := by decide +kernel

theorem selectedBound31736 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env31737 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,1052,8,24,1044,2,9,1566,1025,1045,1036,1044,16,1047,8,17,522,9,1053,522,1025,0,4,1,1037,512]

theorem envBound31737 : H12AffineFastState.Bounded env31737 := by
  intro p hp
  have h : env31737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31736_31737 : H12AffineEnvironment.transform 11 1052 env31736 = env31737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1052 env31736 == env31737) = true)

theorem identity31737 : scanCanonicalize (H12AffineFastState.compose env31737 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 519) := by decide +kernel

theorem selectedBound31737 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env31738 : List Nat := [2,4,8,16,1,16,8,5,512,519,523,539,8,24,531,2,9,25,518,530,523,531,16,528,8,17,522,9,538,522,518,0,4,1,522,512]

theorem envBound31738 : H12AffineFastState.Bounded env31738 := by
  intro p hp
  have h : env31738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31737_31738 : H12AffineEnvironment.transform 9 519 env31737 = env31738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 519 env31737 == env31738) = true)

theorem identity31738 : scanCanonicalize (H12AffineFastState.compose env31738 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound31738 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env31739 : List Nat := [2,4,8,16,1,16,8,5,11,12,0,16,8,24,24,2,9,25,13,25,0,24,16,27,8,17,1,9,17,1,13,0,4,1,1,11]

theorem envBound31739 : H12AffineFastState.Bounded env31739 := by
  intro p hp
  have h : env31739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31738_31739 : H12AffineEnvironment.transform 8 11 env31738 = env31739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env31738 == env31739) = true)

theorem identity31739 : scanCanonicalize (H12AffineFastState.compose env31739 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound31739 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31740 : List Nat := [2,4,8,9,1,9,8,5,11,12,0,9,8,1,1,2,9,0,13,0,0,1,9,2,8,8,1,9,8,1,13,0,4,1,1,11]

theorem envBound31740 : H12AffineFastState.Bounded env31740 := by
  intro p hp
  have h : env31740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31739_31740 : H12AffineEnvironment.transform 3 9 env31739 = env31740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env31739 == env31740) = true)

theorem identity31740 : scanCanonicalize (H12AffineFastState.compose env31740 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31741 : List Nat := [2,2,8,9,1,9,8,3,11,10,0,9,8,1,1,2,9,0,11,0,0,1,9,2,8,8,1,9,8,1,11,0,2,1,1,11]

theorem envBound31741 : H12AffineFastState.Bounded env31741 := by
  intro p hp
  have h : env31741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31740_31741 : H12AffineEnvironment.transform 1 2 env31740 = env31741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31740 == env31741) = true)

def env31742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,4160,98678,17,98644,8192,65,10589,5392,17665,76158,1365,95530,257,21792,46092,74251]

theorem envBound31742 : H12AffineFastState.Bounded env31742 := by
  intro p hp
  have h : env31742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31727_31742 : H12AffineEnvironment.transform 22 17 env31727 = env31742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31727 == env31742) = true)

theorem identity31742 : scanCanonicalize (H12AffineFastState.compose env31742 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1025,32769,4160,32,17,2,8192,65,10589,5392,17665,43048,1365,62588,257,21792,46092,41821]

theorem envBound31743 : H12AffineFastState.Bounded env31743 := by
  intro p hp
  have h : env31743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31742_31743 : H12AffineEnvironment.transform 15 33110 env31742 = env31743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31742 == env31743) = true)

theorem identity31743 : scanCanonicalize (H12AffineFastState.compose env31743 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31743 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31744 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,57629,35109,1025,32769,4112,32,17,2,8192,17,10509,5392,17665,43048,1285,62508,257,21792,46092,41741]

theorem envBound31744 : H12AffineFastState.Bounded env31744 := by
  intro p hp
  have h : env31744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31743_31744 : H12AffineEnvironment.transform 5 16 env31743 = env31744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31743 == env31744) = true)

theorem identity31744 : scanCanonicalize (H12AffineFastState.compose env31744 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound31744 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31745 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13609,32768,33030,37940,35109,1025,32769,4112,32,17,2,8192,17,10509,5392,12328,43048,1285,33029,257,8201,46092,41741]

theorem envBound31745 : H12AffineFastState.Bounded env31745 := by
  intro p hp
  have h : env31745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31744_31745 : H12AffineEnvironment.transform 13 13609 env31744 = env31745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env31744 == env31745) = true)

theorem identity31745 : scanCanonicalize (H12AffineFastState.compose env31745 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound31745 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env31746 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,4405,32768,33030,37940,35109,1025,32769,4112,32,17,2,1052,17,3345,5392,5172,35892,1285,33029,257,1045,36880,34577]

theorem envBound31746 : H12AffineFastState.Bounded env31746 := by
  intro p hp
  have h : env31746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31745_31746 : H12AffineEnvironment.transform 12 1052 env31745 = env31746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env31745 == env31746) = true)

theorem identity31746 : scanCanonicalize (H12AffineFastState.compose env31746 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31746 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env31747 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,4405,4112,4374,1060,6453,1025,4113,4112,32,17,2,1052,17,3345,5392,5172,7204,1285,4373,257,1045,0,5889]

theorem envBound31747 : H12AffineFastState.Bounded env31747 := by
  intro p hp
  have h : env31747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31746_31747 : H12AffineEnvironment.transform 14 4112 env31746 = env31747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env31746 == env31747) = true)

theorem identity31747 : scanCanonicalize (H12AffineFastState.compose env31747 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31747 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env31748 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,4096,1052,4405,4112,4374,1060,4404,1025,4113,4112,32,17,2,1052,17,1296,5392,5172,5157,1285,4373,257,1045,0,5889]

theorem envBound31748 : H12AffineFastState.Bounded env31748 := by
  intro p hp
  have h : env31748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31747_31748 : H12AffineEnvironment.transform 10 1 env31747 = env31748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31747 == env31748) = true)

theorem identity31748 : scanCanonicalize (H12AffineFastState.compose env31748 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound31748 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31749 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,1280,1052,1077,1296,1046,1060,1076,1025,1297,1296,32,17,2,1052,17,1296,16,308,293,1285,1045,257,1045,0,513]

theorem envBound31749 : H12AffineFastState.Bounded env31749 := by
  intro p hp
  have h : env31749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31748_31749 : H12AffineEnvironment.transform 11 1280 env31748 = env31749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env31748 == env31749) = true)

theorem identity31749 : scanCanonicalize (H12AffineFastState.compose env31749 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31749 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31750 : List Nat := [2,4,8,16,32,16,8,256,512,53,1,309,41,0,293,35,17,1,52,292,293,32,17,2,41,17,293,16,308,293,304,32,257,32,0,513]

theorem envBound31750 : H12AffineFastState.Bounded env31750 := by
  intro p hp
  have h : env31750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31749_31750 : H12AffineEnvironment.transform 9 53 env31749 = env31750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31749 == env31750) = true)

theorem identity31750 : scanCanonicalize (H12AffineFastState.compose env31750 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31751 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,17,41,0,1,35,17,1,52,0,1,32,17,2,41,17,1,16,16,1,20,32,37,32,0,513]

theorem envBound31751 : H12AffineFastState.Bounded env31751 := by
  intro p hp
  have h : env31751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31750_31751 : H12AffineEnvironment.transform 7 36 env31750 = env31751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31750 == env31751) = true)

theorem identity31751 : scanCanonicalize (H12AffineFastState.compose env31751 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31752 : List Nat := [2,4,8,16,1,16,8,5,512,20,1,17,8,0,1,2,17,1,21,0,1,1,17,2,8,17,1,16,16,1,20,1,4,1,0,513]

theorem envBound31752 : H12AffineFastState.Bounded env31752 := by
  intro p hp
  have h : env31752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31751_31752 : H12AffineEnvironment.transform 4 1 env31751 = env31752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31751 == env31752) = true)

theorem identity31752 : scanCanonicalize (H12AffineFastState.compose env31752 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31753 : List Nat := [2,4,8,1,1,1,8,5,512,5,1,0,8,0,1,2,0,1,4,0,1,1,0,2,8,0,1,1,1,1,5,1,4,1,0,513]

theorem envBound31753 : H12AffineFastState.Bounded env31753 := by
  intro p hp
  have h : env31753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31752_31753 : H12AffineEnvironment.transform 3 1 env31752 = env31753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31752 == env31753) = true)

def env31754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,4161,98678,8388608,98644,8192,65,8399180,5393,8406289,8464751,8389956,95531,257,8410416,8434716,8462874]

theorem envBound31754 : H12AffineFastState.Bounded env31754 := by
  intro p hp
  have h : env31754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31726_31754 : H12AffineEnvironment.transform 20 4161 env31726 = env31754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31726 == env31754) = true)

theorem identity31754 : scanCanonicalize (H12AffineFastState.compose env31754 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound31754 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,4161,98678,73755,98644,8192,65,67927,5393,91402,2420,75103,95531,257,95531,103431,513]

theorem envBound31755 : H12AffineFastState.Bounded env31755 := by
  intro p hp
  have h : env31755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31754_31755 : H12AffineEnvironment.transform 22 73755 env31754 = env31755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env31754 == env31755) = true)

theorem identity31755 : scanCanonicalize (H12AffineFastState.compose env31755 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 61514) := by decide +kernel

theorem selectedBound31755 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env31756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,61514,36945,35189,1025,32769,4161,28988,53329,28958,8192,65,63773,5393,38208,2420,54549,34145,257,34145,25677,513]

theorem envBound31756 : H12AffineFastState.Bounded env31756 := by
  intro p hp
  have h : env31756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31755_31756 : H12AffineEnvironment.transform 15 61514 env31755 = env31756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61514 env31755 == env31756) = true)

theorem identity31756 : scanCanonicalize (H12AffineFastState.compose env31756 (packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound31756 : packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env31757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,29039,4468,2128,1025,292,4161,28988,20852,28958,8192,65,30776,5393,5221,2420,21552,1092,257,1092,25677,513]

theorem envBound31757 : H12AffineFastState.Bounded env31757 := by
  intro p hp
  have h : env31757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31756_31757 : H12AffineEnvironment.transform 14 293 env31756 = env31757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env31756 == env31757) = true)

theorem identity31757 : scanCanonicalize (H12AffineFastState.compose env31757 (packedSelected [0,2,5,6,7,8,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound31757 : packedSelected [0,2,5,6,7,8,14,18,20] rootPS < 2^1333 := by decide +kernel

def env31758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4200,16384,293,16647,4468,2128,1025,292,4161,16724,20852,16758,4200,65,18512,5393,5221,2420,21552,1092,257,1092,21541,513]

theorem envBound31758 : H12AffineFastState.Bounded env31758 := by
  intro p hp
  have h : env31758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31757_31758 : H12AffineEnvironment.transform 12 4200 env31757 = env31758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env31757 == env31758) = true)

theorem identity31758 : scanCanonicalize (H12AffineFastState.compose env31758 (packedSelected [1,2,6,12,15,18,24] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31758 : packedSelected [1,2,6,12,15,18,24] rootPS < 2^1333 := by decide +kernel

def env31759 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,4200,16384,293,16647,4468,2128,52,292,4161,16724,20852,16758,4200,65,18512,4388,4176,2420,20485,113,257,113,20496,513]

theorem envBound31759 : H12AffineFastState.Bounded env31759 := by
  intro p hp
  have h : env31759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31758_31759 : H12AffineEnvironment.transform 9 53 env31758 = env31759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31758 == env31759) = true)

theorem identity31759 : scanCanonicalize (H12AffineFastState.compose env31759 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 6500) := by decide +kernel

theorem selectedBound31759 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env31760 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,4200,6500,293,6243,4468,2128,52,292,4161,6192,2064,6162,4200,65,4404,4388,4176,2420,2401,113,257,113,2420,513]

theorem envBound31760 : H12AffineFastState.Bounded env31760 := by
  intro p hp
  have h : env31760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31759_31760 : H12AffineEnvironment.transform 13 6500 env31759 = env31760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6500 env31759 == env31760) = true)

theorem identity31760 : scanCanonicalize (H12AffineFastState.compose env31760 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound31760 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31761 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,65,41,2341,293,2082,309,2128,52,292,0,2161,2064,2131,41,65,373,357,17,2420,2401,113,257,113,2420,513]

theorem envBound31761 : H12AffineFastState.Bounded env31761 := by
  intro p hp
  have h : env31761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31760_31761 : H12AffineEnvironment.transform 11 65 env31760 = env31761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env31760 == env31761) = true)

theorem identity31761 : scanCanonicalize (H12AffineFastState.compose env31761 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31761 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31762 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,41,2341,293,2082,309,2048,52,292,0,2081,2064,2051,41,17,293,309,17,2340,2353,33,257,33,2340,513]

theorem envBound31762 : H12AffineFastState.Bounded env31762 := by
  intro p hp
  have h : env31762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31761_31762 : H12AffineEnvironment.transform 5 16 env31761 = env31762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31761 == env31762) = true)

theorem identity31762 : scanCanonicalize (H12AffineFastState.compose env31762 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31762 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31763 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,17,41,293,293,34,309,0,52,292,0,33,16,3,41,17,293,309,17,292,305,33,257,33,292,513]

theorem envBound31763 : H12AffineFastState.Bounded env31763 := by
  intro p hp
  have h : env31763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31762_31763 : H12AffineEnvironment.transform 10 0 env31762 = env31763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31762 == env31763) = true)

theorem identity31763 : scanCanonicalize (H12AffineFastState.compose env31763 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31763 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31764 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,41,1,1,34,17,0,52,0,0,33,16,3,41,17,1,17,17,0,21,33,37,33,0,513]

theorem envBound31764 : H12AffineFastState.Bounded env31764 := by
  intro p hp
  have h : env31764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31763_31764 : H12AffineEnvironment.transform 7 36 env31763 = env31764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31763 == env31764) = true)

theorem identity31764 : scanCanonicalize (H12AffineFastState.compose env31764 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31764 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31765 : List Nat := [2,4,8,16,32,16,8,36,1,53,0,17,41,1,1,34,17,0,52,0,0,33,16,3,41,17,1,17,17,0,21,33,37,33,0,0]

theorem envBound31765 : H12AffineFastState.Bounded env31765 := by
  intro p hp
  have h : env31765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31764_31765 : H12AffineEnvironment.transform 8 1 env31764 = env31765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31764 == env31765) = true)

theorem identity31765 : scanCanonicalize (H12AffineFastState.compose env31765 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31766 : List Nat := [2,4,8,16,10,16,8,14,1,31,0,17,3,1,1,8,17,0,30,0,0,11,16,3,3,17,1,17,17,0,21,11,15,11,0,0]

theorem envBound31766 : H12AffineFastState.Bounded env31766 := by
  intro p hp
  have h : env31766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31765_31766 : H12AffineEnvironment.transform 4 10 env31765 = env31766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31765 == env31766) = true)

def env31767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,8388608,98645,8192,65,12691515,2098513,10507600,8464751,8389957,6349853,257,10503536,10527836,8462875]

theorem envBound31767 : H12AffineFastState.Bounded env31767 := by
  intro p hp
  have h : env31767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31724_31767 : H12AffineEnvironment.transform 23 98645 env31724 = env31767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env31724 == env31767) = true)

theorem identity31767 : scanCanonicalize (H12AffineFastState.compose env31767 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound31767 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,73754,98645,8192,65,4229153,2098513,2192714,2421,75103,6349853,257,2188650,2196550,513]

theorem envBound31768 : H12AffineFastState.Bounded env31768 := by
  intro p hp
  have h : env31768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31767_31768 : H12AffineEnvironment.transform 22 73754 env31767 = env31768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env31767 == env31768) = true)

theorem identity31768 : scanCanonicalize (H12AffineFastState.compose env31768 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound31768 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env31769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,73770,73754,98645,8192,65,108555,2098513,2192714,2421,75103,2212919,257,2188650,2196550,513]

theorem envBound31769 : H12AffineFastState.Bounded env31769 := by
  intro p hp
  have h : env31769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31768_31769 : H12AffineEnvironment.transform 21 73770 env31768 = env31769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env31768 == env31769) = true)

theorem identity31769 : scanCanonicalize (H12AffineFastState.compose env31769 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound31769 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,91466,73770,73754,98645,8192,65,108555,90139,4096,2421,75103,41341,257,32,57612,513]

theorem envBound31770 : H12AffineFastState.Bounded env31770 := by
  intro p hp
  have h : env31770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31769_31770 : H12AffineEnvironment.transform 20 91466 env31769 = env31770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env31769 == env31770) = true)

theorem identity31770 : scanCanonicalize (H12AffineFastState.compose env31770 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 53575) := by decide +kernel

theorem selectedBound31770 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,53575,45404,35189,1025,32769,46093,61805,61789,20498,8192,65,31052,45404,4096,2421,62488,41341,257,32,57612,513]

theorem envBound31771 : H12AffineFastState.Bounded env31771 := by
  intro p hp
  have h : env31771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31770_31771 : H12AffineEnvironment.transform 15 53575 env31770 = env31771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53575 env31770 == env31771) = true)

theorem identity31771 : scanCanonicalize (H12AffineFastState.compose env31771 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound31771 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env31772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30777,1025,29005,17729,33,17,20498,8192,65,31052,16400,4096,2421,1364,20529,257,32,4160,513]

theorem envBound31772 : H12AffineFastState.Bounded env31772 := by
  intro p hp
  have h : env31772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31771_31772 : H12AffineEnvironment.transform 14 29004 env31771 = env31772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env31771 == env31772) = true)

theorem identity31772 : scanCanonicalize (H12AffineFastState.compose env31772 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31772 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,8203,4096,10281,1025,8541,5457,33,17,2,8192,65,10588,4096,4096,2421,1364,33,257,32,4160,513]

theorem envBound31773 : H12AffineFastState.Bounded env31773 := by
  intro p hp
  have h : env31773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31772_31773 : H12AffineEnvironment.transform 13 4112 env31772 = env31773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31772 == env31773) = true)

def env31774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575541,18973701,10507600,8538484,25265168,23160137,257,27378724,27337993,25207631]

theorem envBound31774 : H12AffineFastState.Bounded env31774 := by
  intro p hp
  have h : env31774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31722_31774 : H12AffineEnvironment.transform 6 9 env31722 = env31774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31722 == env31774) = true)

def env31775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,16777216,8193,65,21039477,18973701,2233680,2420,17024016,23160137,257,19104804,19096841,16966479]

theorem envBound31775 : H12AffineFastState.Bounded env31775 := by
  intro p hp
  have h : env31775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31774_31775 : H12AffineEnvironment.transform 22 147456 env31774 = env31775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env31774 == env31775) = true)

theorem identity31775 : scanCanonicalize (H12AffineFastState.compose env31775 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound31775 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,188750,8193,65,4450363,2319691,2233680,2420,75102,6521863,257,2188650,2196551,513]

theorem envBound31776 : H12AffineFastState.Bounded env31776 := by
  intro p hp
  have h : env31776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31775_31776 : H12AffineEnvironment.transform 23 188750 env31775 = env31776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env31775 == env31776) = true)

def env31777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41310,8193,65,4302891,2172251,2118976,2420,75102,6407191,257,2188650,2196551,513]

theorem envBound31777 : H12AffineFastState.Bounded env31777 := by
  intro p hp
  have h : env31777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31776_31777 : H12AffineEnvironment.transform 16 16400 env31776 = env31777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31776 == env31777) = true)

theorem identity31777 : scanCanonicalize (H12AffineFastState.compose env31777 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31777 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2098512,2118976,2420,1365,6349852,257,2114913,2139212,513]

theorem envBound31778 : H12AffineFastState.Bounded env31778 := by
  intro p hp
  have h : env31778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31777_31778 : H12AffineEnvironment.transform 15 8203 env31777 = env31778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31777 == env31778) = true)

theorem identity31778 : scanCanonicalize (H12AffineFastState.compose env31778 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,32,16,41310,8193,65,34816,2098512,2118976,2420,1365,2155580,257,2114913,2139212,513]

theorem envBound31779 : H12AffineFastState.Bounded env31779 := by
  intro p hp
  have h : env31779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31778_31779 : H12AffineEnvironment.transform 21 32 env31778 = env31779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31778 == env31779) = true)

theorem identity31779 : scanCanonicalize (H12AffineFastState.compose env31779 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31779 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1025,8540,2097152,32,16,3,8193,65,10589,2098512,2118976,2420,1365,2114913,257,2114913,2098449,513]

theorem envBound31780 : H12AffineFastState.Bounded env31780 := by
  intro p hp
  have h : env31780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31779_31780 : H12AffineEnvironment.transform 14 8541 env31779 = env31780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31779 == env31780) = true)

theorem identity31780 : scanCanonicalize (H12AffineFastState.compose env31780 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31780 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31781 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,10280,1025,8461,2097152,32,16,3,8193,16,10508,2098433,2118929,2341,1284,2114864,257,2114864,2098449,513]

theorem envBound31781 : H12AffineFastState.Bounded env31781 := by
  intro p hp
  have h : env31781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31780_31781 : H12AffineEnvironment.transform 5 17 env31780 = env31781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31780 == env31781) = true)

theorem identity31781 : scanCanonicalize (H12AffineFastState.compose env31781 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 26664) := by decide +kernel

theorem selectedBound31781 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31782 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,10280,1025,8461,26664,32,16,3,8193,16,10508,27945,15673,2341,1284,11544,257,11544,27961,513]

theorem envBound31782 : H12AffineFastState.Bounded env31782 := by
  intro p hp
  have h : env31782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31781_31782 : H12AffineEnvironment.transform 20 26664 env31781 = env31782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26664 env31781 == env31782) = true)

theorem identity31782 : scanCanonicalize (H12AffineFastState.compose env31782 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 6420) := by decide +kernel

theorem selectedBound31782 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31783 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,6420,8460,8203,6404,10280,1025,8461,12604,32,16,3,8193,16,10508,13373,15673,2341,1284,11544,257,11544,13357,513]

theorem envBound31783 : H12AffineFastState.Bounded env31783 := by
  intro p hp
  have h : env31783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31782_31783 : H12AffineEnvironment.transform 13 6420 env31782 = env31783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6420 env31782 == env31783) = true)

theorem identity31783 : scanCanonicalize (H12AffineFastState.compose env31783 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound31783 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31784 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,4096,8192,4113,8460,8203,4097,8493,1025,8461,12604,32,16,3,8193,16,8201,13373,13372,32,1284,9245,257,9245,13357,513]

theorem envBound31784 : H12AffineFastState.Bounded env31784 := by
  intro p hp
  have h : env31784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31783_31784 : H12AffineEnvironment.transform 10 261 env31783 = env31784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env31783 == env31784) = true)

theorem identity31784 : scanCanonicalize (H12AffineFastState.compose env31784 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound31784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31785 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,1061,8192,1076,8460,8203,1060,8493,1025,8461,9497,32,16,3,8193,16,8201,8216,8217,32,1284,9245,257,9245,8200,513]

theorem envBound31785 : H12AffineFastState.Bounded env31785 := by
  intro p hp
  have h : env31785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31784_31785 : H12AffineEnvironment.transform 11 1061 env31784 = env31785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env31784 == env31785) = true)

theorem identity31785 : scanCanonicalize (H12AffineFastState.compose env31785 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound31785 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env31786 : List Nat := [2,4,8,16,32,17,9,256,16,1024,261,1061,8192,1076,8460,8203,1060,8493,1025,8461,9497,32,16,3,8193,16,8201,8216,8217,32,1284,9245,257,9245,8200,17]

theorem envBound31786 : H12AffineFastState.Bounded env31786 := by
  intro p hp
  have h : env31786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31785_31786 : H12AffineEnvironment.transform 8 16 env31785 = env31786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env31785 == env31786) = true)

theorem identity31786 : scanCanonicalize (H12AffineFastState.compose env31786 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound31786 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31787 : List Nat := [2,4,8,16,32,17,9,256,16,1024,261,1061,1037,1076,1281,1030,1060,1312,1025,1280,276,32,16,3,1036,16,1028,1045,1044,32,1284,16,257,16,1029,17]

theorem envBound31787 : H12AffineFastState.Bounded env31787 := by
  intro p hp
  have h : env31787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31786_31787 : H12AffineEnvironment.transform 12 1037 env31786 = env31787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env31786 == env31787) = true)

theorem identity31787 : scanCanonicalize (H12AffineFastState.compose env31787 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31787 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env31788 : List Nat := [2,4,8,16,32,17,9,256,16,52,261,17,57,0,309,50,16,276,53,308,276,32,16,3,56,16,48,33,32,32,304,16,257,16,49,17]

theorem envBound31788 : H12AffineFastState.Bounded env31788 := by
  intro p hp
  have h : env31788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31787_31788 : H12AffineEnvironment.transform 9 52 env31787 = env31788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31787 == env31788) = true)

theorem identity31788 : scanCanonicalize (H12AffineFastState.compose env31788 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31788 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env31789 : List Nat := [2,4,8,16,32,17,9,36,16,52,33,17,57,0,17,50,16,48,53,16,48,32,16,3,56,16,48,33,32,32,20,16,37,16,49,17]

theorem envBound31789 : H12AffineFastState.Bounded env31789 := by
  intro p hp
  have h : env31789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31788_31789 : H12AffineEnvironment.transform 7 36 env31788 = env31789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31788 == env31789) = true)

theorem identity31789 : scanCanonicalize (H12AffineFastState.compose env31789 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31790 : List Nat := [2,4,8,16,0,17,9,4,16,20,1,17,25,0,17,18,16,16,21,16,16,0,16,3,24,16,16,1,0,0,20,16,5,16,17,17]

theorem envBound31790 : H12AffineFastState.Bounded env31790 := by
  intro p hp
  have h : env31790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31789_31790 : H12AffineEnvironment.transform 4 0 env31789 = env31790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31789 == env31790) = true)

theorem identity31790 : scanCanonicalize (H12AffineFastState.compose env31790 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31790 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31791 : List Nat := [2,4,8,1,0,0,9,4,1,5,1,0,8,0,0,3,1,1,4,1,1,0,1,3,9,1,1,1,0,0,5,1,5,1,0,0]

theorem envBound31791 : H12AffineFastState.Bounded env31791 := by
  intro p hp
  have h : env31791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31790_31791 : H12AffineEnvironment.transform 3 1 env31790 = env31791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31790 == env31791) = true)

def env31792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41311,8193,65,4302890,2172250,2118977,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound31792 : H12AffineFastState.Bounded env31792 := by
  intro p hp
  have h : env31792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31776_31792 : H12AffineEnvironment.transform 16 16401 env31776 = env31792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31776 == env31792) = true)

theorem identity31792 : scanCanonicalize (H12AffineFastState.compose env31792 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound31792 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115735,4194304,17,41311,8193,65,4302890,57677,102742,2420,75102,4194305,257,41341,16464,513]

theorem envBound31793 : H12AffineFastState.Bounded env31793 := by
  intro p hp
  have h : env31793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31792_31793 : H12AffineEnvironment.transform 20 115735 env31792 = env31793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env31792 == env31793) = true)

def env31794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91199,4194304,17,375,8193,65,4261890,16741,78206,2420,75102,4194305,257,341,16464,513]

theorem envBound31794 : H12AffineFastState.Bounded env31794 := by
  intro p hp
  have h : env31794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31793_31794 : H12AffineEnvironment.transform 14 8232 env31793 = env31794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env31793 == env31794) = true)

theorem identity31794 : scanCanonicalize (H12AffineFastState.compose env31794 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound31794 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env31795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91199,65911,17,375,8193,65,2421,16741,78206,2420,75102,65910,257,341,16464,513]

theorem envBound31795 : H12AffineFastState.Bounded env31795 := by
  intro p hp
  have h : env31795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31794_31795 : H12AffineEnvironment.transform 21 65911 env31794 = env31795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env31794 == env31795) = true)

theorem identity31795 : scanCanonicalize (H12AffineFastState.compose env31795 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31795 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env31796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,343,16401,10589,1025,8233,25960,32,17,375,8193,65,2421,16741,12329,2420,9225,33,257,341,16464,513]

theorem envBound31796 : H12AffineFastState.Bounded env31796 := by
  intro p hp
  have h : env31796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31795_31796 : H12AffineEnvironment.transform 15 343 env31795 = env31796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31795 == env31796) = true)

theorem identity31796 : scanCanonicalize (H12AffineFastState.compose env31796 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31796 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31797 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,35,16401,10281,1025,8233,25628,32,17,3,8193,65,2049,16401,12329,2048,9225,33,117,33,16464,513]

theorem envBound31797 : H12AffineFastState.Bounded env31797 := by
  intro p hp
  have h : env31797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31796_31797 : H12AffineEnvironment.transform 7 116 env31796 = env31797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31796 == env31797) = true)

theorem identity31797 : scanCanonicalize (H12AffineFastState.compose env31797 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31797 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31798 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,81,35,16401,2128,1025,80,17509,32,17,3,120,65,2049,16401,4176,2048,1136,33,117,33,16464,513]

theorem envBound31798 : H12AffineFastState.Bounded env31798 := by
  intro p hp
  have h : env31798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31797_31798 : H12AffineEnvironment.transform 12 121 env31797 = env31798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31797 == env31798) = true)

theorem identity31798 : scanCanonicalize (H12AffineFastState.compose env31798 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31798 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31799 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,16384,0,35,16401,2049,1025,1,17460,32,17,3,41,16,2049,16401,4097,2048,1057,33,36,33,16385,513]

theorem envBound31799 : H12AffineFastState.Bounded env31799 := by
  intro p hp
  have h : env31799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31798_31799 : H12AffineEnvironment.transform 5 17 env31798 = env31799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31798 == env31799) = true)

theorem identity31799 : scanCanonicalize (H12AffineFastState.compose env31799 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound31799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31800 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,1,0,35,16,2049,1025,1,1077,32,17,3,41,16,2049,16,4097,2048,1057,33,36,33,0,513]

theorem envBound31800 : H12AffineFastState.Bounded env31800 := by
  intro p hp
  have h : env31800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31799_31800 : H12AffineEnvironment.transform 13 1 env31799 = env31800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env31799 == env31800) = true)

theorem identity31800 : scanCanonicalize (H12AffineFastState.compose env31800 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound31800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31801 : List Nat := [2,4,8,16,32,17,9,37,512,1024,523,4096,40,1,0,35,16,522,1025,1,1077,32,17,3,41,16,522,16,4097,523,1057,33,36,33,0,513]

theorem envBound31801 : H12AffineFastState.Bounded env31801 := by
  intro p hp
  have h : env31801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31800_31801 : H12AffineEnvironment.transform 10 523 env31800 = env31801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env31800 == env31801) = true)

theorem identity31801 : scanCanonicalize (H12AffineFastState.compose env31801 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound31801 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31802 : List Nat := [2,4,8,16,32,17,9,37,512,1024,523,1550,40,1,0,35,16,522,1025,1,1077,32,17,3,41,16,522,16,1551,523,1057,33,36,33,0,513]

theorem envBound31802 : H12AffineFastState.Bounded env31802 := by
  intro p hp
  have h : env31802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31801_31802 : H12AffineEnvironment.transform 11 1550 env31801 = env31802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env31801 == env31802) = true)

theorem identity31802 : scanCanonicalize (H12AffineFastState.compose env31802 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31802 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31803 : List Nat := [2,4,8,16,32,17,9,37,512,52,523,570,40,1,0,35,16,522,53,1,1,32,17,3,41,16,522,16,571,523,21,33,36,33,0,513]

theorem envBound31803 : H12AffineFastState.Bounded env31803 := by
  intro p hp
  have h : env31803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31802_31803 : H12AffineEnvironment.transform 9 52 env31802 = env31803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31802 == env31803) = true)

theorem identity31803 : scanCanonicalize (H12AffineFastState.compose env31803 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound31803 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31804 : List Nat := [2,4,8,16,32,17,9,37,43,52,32,17,40,1,0,35,16,33,53,1,1,32,17,3,41,16,33,16,16,32,21,33,36,33,0,42]

theorem envBound31804 : H12AffineFastState.Bounded env31804 := by
  intro p hp
  have h : env31804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31803_31804 : H12AffineEnvironment.transform 8 43 env31803 = env31804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env31803 == env31804) = true)

theorem identity31804 : scanCanonicalize (H12AffineFastState.compose env31804 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound31804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31805 : List Nat := [2,4,8,14,32,15,9,37,43,42,32,15,40,1,0,35,14,33,43,1,1,32,15,3,41,14,33,14,14,32,11,33,36,33,0,42]

theorem envBound31805 : H12AffineFastState.Bounded env31805 := by
  intro p hp
  have h : env31805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31804_31805 : H12AffineEnvironment.transform 3 14 env31804 = env31805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env31804 == env31805) = true)

theorem identity31805 : scanCanonicalize (H12AffineFastState.compose env31805 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound31805 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31806 : List Nat := [2,4,8,14,8,15,9,13,3,2,8,15,0,1,0,11,14,9,3,1,1,8,15,3,1,14,9,14,14,8,11,9,12,9,0,2]

theorem envBound31806 : H12AffineFastState.Bounded env31806 := by
  intro p hp
  have h : env31806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31805_31806 : H12AffineEnvironment.transform 4 8 env31805 = env31806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env31805 == env31806) = true)

theorem identity31806 : scanCanonicalize (H12AffineFastState.compose env31806 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31806 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env31807 : List Nat := [2,4,0,6,0,7,1,5,3,2,0,7,0,1,0,3,6,1,3,1,1,0,7,3,1,6,1,6,6,0,3,1,4,1,0,2]

theorem envBound31807 : H12AffineFastState.Bounded env31807 := by
  intro p hp
  have h : env31807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31806_31807 : H12AffineEnvironment.transform 2 0 env31806 = env31807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31806 == env31807) = true)

def env31808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91198,4194304,17,374,8193,65,4261891,16740,78207,2420,75102,4194305,257,340,16464,513]

theorem envBound31808 : H12AffineFastState.Bounded env31808 := by
  intro p hp
  have h : env31808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31793_31808 : H12AffineEnvironment.transform 14 8233 env31793 = env31808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env31793 == env31808) = true)

theorem identity31808 : scanCanonicalize (H12AffineFastState.compose env31808 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound31808 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env31809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91198,65538,17,374,8193,65,2049,16740,78207,2420,75102,65539,257,340,16464,513]

theorem envBound31809 : H12AffineFastState.Bounded env31809 := by
  intro p hp
  have h : env31809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31808_31809 : H12AffineEnvironment.transform 21 65538 env31808 = env31809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env31808 == env31809) = true)

theorem identity31809 : scanCanonicalize (H12AffineFastState.compose env31809 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound31809 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,34,16401,10588,1025,8232,25628,32,17,374,8193,65,2049,16740,12637,2420,9596,33,257,340,16464,513]

theorem envBound31810 : H12AffineFastState.Bounded env31810 := by
  intro p hp
  have h : env31810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31809_31810 : H12AffineEnvironment.transform 15 34 env31809 = env31810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env31809 == env31810) = true)

theorem identity31810 : scanCanonicalize (H12AffineFastState.compose env31810 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31810 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env31811 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,34,16401,10281,1025,8232,25628,32,17,3,8193,65,2049,16401,12328,2049,9225,33,116,33,16464,513]

theorem envBound31811 : H12AffineFastState.Bounded env31811 := by
  intro p hp
  have h : env31811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31810_31811 : H12AffineEnvironment.transform 7 117 env31810 = env31811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31810 == env31811) = true)

theorem identity31811 : scanCanonicalize (H12AffineFastState.compose env31811 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31811 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31812 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,16384,81,34,16401,2129,1025,80,17508,32,17,3,121,65,2049,16401,4176,2049,1137,33,116,33,16464,513]

theorem envBound31812 : H12AffineFastState.Bounded env31812 := by
  intro p hp
  have h : env31812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31811_31812 : H12AffineEnvironment.transform 12 120 env31811 = env31812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31811 == env31812) = true)

theorem identity31812 : scanCanonicalize (H12AffineFastState.compose env31812 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31812 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31813 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,16384,0,34,16401,2048,1025,1,17461,32,17,3,40,16,2049,16401,4097,2049,1056,33,37,33,16385,513]

theorem envBound31813 : H12AffineFastState.Bounded env31813 := by
  intro p hp
  have h : env31813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31812_31813 : H12AffineEnvironment.transform 5 17 env31812 = env31813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31812 == env31813) = true)

theorem identity31813 : scanCanonicalize (H12AffineFastState.compose env31813 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound31813 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31814 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,1,0,34,16,2048,1025,1,1076,32,17,3,40,16,2049,16,4097,2049,1056,33,37,33,0,513]

theorem envBound31814 : H12AffineFastState.Bounded env31814 := by
  intro p hp
  have h : env31814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31813_31814 : H12AffineEnvironment.transform 13 1 env31813 = env31814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env31813 == env31814) = true)

theorem identity31814 : scanCanonicalize (H12AffineFastState.compose env31814 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound31814 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31815 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,41,1,0,34,16,522,1025,1,1076,32,17,3,40,16,523,16,4097,523,1056,33,37,33,0,513]

theorem envBound31815 : H12AffineFastState.Bounded env31815 := by
  intro p hp
  have h : env31815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31814_31815 : H12AffineEnvironment.transform 10 522 env31814 = env31815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env31814 == env31815) = true)

theorem identity31815 : scanCanonicalize (H12AffineFastState.compose env31815 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound31815 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31816 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,1550,41,1,0,34,16,522,1025,1,1076,32,17,3,40,16,523,16,1551,523,1056,33,37,33,0,513]

theorem envBound31816 : H12AffineFastState.Bounded env31816 := by
  intro p hp
  have h : env31816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31815_31816 : H12AffineEnvironment.transform 11 1550 env31815 = env31816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env31815 == env31816) = true)

theorem identity31816 : scanCanonicalize (H12AffineFastState.compose env31816 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31816 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31817 : List Nat := [2,4,8,16,32,17,9,36,512,52,522,570,41,1,0,34,16,522,53,1,0,32,17,3,40,16,523,16,571,523,20,33,37,33,0,513]

theorem envBound31817 : H12AffineFastState.Bounded env31817 := by
  intro p hp
  have h : env31817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31816_31817 : H12AffineEnvironment.transform 9 52 env31816 = env31817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31816 == env31817) = true)

theorem identity31817 : scanCanonicalize (H12AffineFastState.compose env31817 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound31817 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31818 : List Nat := [2,4,8,16,32,17,9,36,43,52,33,17,41,1,0,34,16,33,53,1,0,32,17,3,40,16,32,16,16,32,20,33,37,33,0,42]

theorem envBound31818 : H12AffineFastState.Bounded env31818 := by
  intro p hp
  have h : env31818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31817_31818 : H12AffineEnvironment.transform 8 43 env31817 = env31818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env31817 == env31818) = true)

theorem identity31818 : scanCanonicalize (H12AffineFastState.compose env31818 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31819 : List Nat := [2,1,8,16,32,17,9,33,43,49,33,17,41,1,0,34,16,33,48,1,0,32,17,3,40,16,32,16,16,32,17,33,32,33,0,42]

theorem envBound31819 : H12AffineFastState.Bounded env31819 := by
  intro p hp
  have h : env31819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31818_31819 : H12AffineEnvironment.transform 1 1 env31818 = env31819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31818 == env31819) = true)

theorem identity31819 : scanCanonicalize (H12AffineFastState.compose env31819 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound31819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31820 : List Nat := [2,1,8,16,19,17,9,18,24,2,18,17,26,1,0,17,16,18,3,1,0,19,17,3,27,16,19,16,16,19,17,18,19,18,0,25]

theorem envBound31820 : H12AffineFastState.Bounded env31820 := by
  intro p hp
  have h : env31820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31819_31820 : H12AffineEnvironment.transform 4 19 env31819 = env31820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env31819 == env31820) = true)

theorem identity31820 : scanCanonicalize (H12AffineFastState.compose env31820 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound31820 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env31821 : List Nat := [2,1,8,2,1,3,9,0,10,2,0,3,8,1,0,3,2,0,3,1,0,1,3,3,9,2,1,2,2,1,3,0,1,0,0,11]

theorem envBound31821 : H12AffineFastState.Bounded env31821 := by
  intro p hp
  have h : env31821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31820_31821 : H12AffineEnvironment.transform 3 2 env31820 = env31821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env31820 == env31821) = true)

def env31822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,16777216,8193,65,21039476,18973701,2233681,2421,17024017,23160137,257,19104805,19096840,16966478]

theorem envBound31822 : H12AffineFastState.Bounded env31822 := by
  intro p hp
  have h : env31822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31774_31822 : H12AffineEnvironment.transform 22 147457 env31774 = env31822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env31774 == env31822) = true)

def env31823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,16777216,8193,65,21039476,18973701,2118977,2421,16876545,23160137,257,18990133,18949400,16819038]

theorem envBound31823 : H12AffineFastState.Bounded env31823 := by
  intro p hp
  have h : env31823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31822_31823 : H12AffineEnvironment.transform 16 16400 env31822 = env31823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31822 == env31823) = true)

theorem identity31823 : scanCanonicalize (H12AffineFastState.compose env31823 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound31823 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41311,8193,65,4302891,2172250,2118977,2421,75102,6407190,257,2188650,2196551,513]

theorem envBound31824 : H12AffineFastState.Bounded env31824 := by
  intro p hp
  have h : env31824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31823_31824 : H12AffineEnvironment.transform 23 41311 env31823 = env31824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env31823 == env31824) = true)

theorem identity31824 : scanCanonicalize (H12AffineFastState.compose env31824 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound31824 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env31825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115735,4194304,17,41311,8193,65,4302891,57677,102742,2421,75102,4194305,257,41341,16464,513]

theorem envBound31825 : H12AffineFastState.Bounded env31825 := by
  intro p hp
  have h : env31825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31824_31825 : H12AffineEnvironment.transform 20 115735 env31824 = env31825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env31824 == env31825) = true)

theorem identity31825 : scanCanonicalize (H12AffineFastState.compose env31825 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31825 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env31826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,91467,4194304,17,3,8193,65,4262263,16401,77834,2421,75102,4194305,257,33,16464,513]

theorem envBound31826 : H12AffineFastState.Bounded env31826 := by
  intro p hp
  have h : env31826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31825_31826 : H12AffineEnvironment.transform 14 8540 env31825 = env31826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31825 == env31826) = true)

theorem identity31826 : scanCanonicalize (H12AffineFastState.compose env31826 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound31826 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,91467,8572,17,3,8193,65,75787,16401,77834,2421,75102,8573,257,33,16464,513]

theorem envBound31827 : H12AffineFastState.Bounded env31827 := by
  intro p hp
  have h : env31827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31826_31827 : H12AffineEnvironment.transform 21 8572 env31826 = env31827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env31826 == env31827) = true)

def env31828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,16777216,8193,65,21039476,18973701,2118976,2421,16876544,23160137,257,18990132,18949401,16819039]

theorem envBound31828 : H12AffineFastState.Bounded env31828 := by
  intro p hp
  have h : env31828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31822_31828 : H12AffineEnvironment.transform 16 16401 env31822 = env31828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31822 == env31828) = true)

theorem identity31828 : scanCanonicalize (H12AffineFastState.compose env31828 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound31828 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,2,8193,65,4262262,2196487,2118976,2421,99330,6382923,257,2212918,2172187,41821]

theorem envBound31829 : H12AffineFastState.Bounded env31829 := by
  intro p hp
  have h : env31829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31828_31829 : H12AffineEnvironment.transform 23 2 env31828 = env31829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env31828 == env31829) = true)

def env31830 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35109,1025,32769,2097152,4194304,16,2,8193,17,4262182,2196487,2118928,2341,99330,6382875,257,2212918,2172187,41741]

theorem envBound31830 : H12AffineFastState.Bounded env31830 := by
  intro p hp
  have h : env31830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31829_31830 : H12AffineEnvironment.transform 5 16 env31829 = env31830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31829 == env31830) = true)

theorem identity31830 : scanCanonicalize (H12AffineFastState.compose env31830 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound31830 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31831 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33031,16401,35109,1025,32769,2097152,4194304,16,2,8193,17,4229153,2098432,2118928,2341,1285,6349852,257,2114865,2139164,41741]

theorem envBound31831 : H12AffineFastState.Bounded env31831 := by
  intro p hp
  have h : env31831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31830_31831 : H12AffineEnvironment.transform 15 33031 env31830 = env31831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env31830 == env31831) = true)

theorem identity31831 : scanCanonicalize (H12AffineFastState.compose env31831 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound31831 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env31832 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33031,16401,35109,1025,32769,50449,4194304,16,2,8193,17,4229153,49169,36865,2341,1285,4202765,257,32800,24845,41741]

theorem envBound31832 : H12AffineFastState.Bounded env31832 := by
  intro p hp
  have h : env31832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31831_31832 : H12AffineEnvironment.transform 20 50449 env31831 = env31832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env31831 == env31832) = true)

def env31833 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35108,1025,32769,2097152,4194304,16,2,8193,16,4262183,2196487,2118929,2340,99330,6382874,257,2212918,2172187,41740]

theorem envBound31833 : H12AffineFastState.Bounded env31833 := by
  intro p hp
  have h : env31833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31829_31833 : H12AffineEnvironment.transform 5 17 env31829 = env31833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31829 == env31833) = true)

theorem identity31833 : scanCanonicalize (H12AffineFastState.compose env31833 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound31833 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31834 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35108,1025,32769,2097152,73771,16,2,8193,16,10508,2196487,2118929,2340,99330,2114865,257,2212918,2172187,41740]

theorem envBound31834 : H12AffineFastState.Bounded env31834 := by
  intro p hp
  have h : env31834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31833_31834 : H12AffineEnvironment.transform 21 73771 env31833 = env31834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env31833 == env31834) = true)

theorem identity31834 : scanCanonicalize (H12AffineFastState.compose env31834 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31834 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env31835 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16401,35108,1025,32769,2097152,65831,16,2,269,16,2048,2196487,2118929,2340,99330,2114865,257,2212918,2163735,33280]

theorem envBound31835 : H12AffineFastState.Bounded env31835 := by
  intro p hp
  have h : env31835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31834_31835 : H12AffineEnvironment.transform 12 268 env31834 = env31835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31834 == env31835) = true)

theorem identity31835 : scanCanonicalize (H12AffineFastState.compose env31835 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound31835 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31836 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16401,35108,1025,32769,82967,65831,16,2,269,16,2048,49168,69894,2340,99330,65830,257,32801,16384,33280]

theorem envBound31836 : H12AffineFastState.Bounded env31836 := by
  intro p hp
  have h : env31836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31835_31836 : H12AffineEnvironment.transform 20 82967 env31835 = env31836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env31835 == env31836) = true)

theorem identity31836 : scanCanonicalize (H12AffineFastState.compose env31836 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound31836 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env31837 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33031,16401,35108,1025,32769,50448,32800,16,2,269,16,2048,49168,36865,2340,1285,32801,257,32801,16384,33280]

theorem envBound31837 : H12AffineFastState.Bounded env31837 := by
  intro p hp
  have h : env31837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31836_31837 : H12AffineEnvironment.transform 15 33031 env31836 = env31837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env31836 == env31837) = true)

theorem identity31837 : scanCanonicalize (H12AffineFastState.compose env31837 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3621) := by decide +kernel

theorem selectedBound31837 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31838 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,3621,32768,33031,3636,35108,1025,32769,35637,32800,16,2,269,16,2048,36405,36865,2340,1285,32801,257,32801,3621,33280]

theorem envBound31838 : H12AffineFastState.Bounded env31838 := by
  intro p hp
  have h : env31838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31837_31838 : H12AffineEnvironment.transform 13 3621 env31837 = env31838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3621 env31837 == env31838) = true)

theorem identity31838 : scanCanonicalize (H12AffineFastState.compose env31838 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound31838 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31839 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,268,3621,32768,33031,3636,35108,1025,32769,35637,32800,16,2,269,16,2048,36405,35877,2340,1285,32801,257,32801,3621,33280]

theorem envBound31839 : H12AffineFastState.Bounded env31839 := by
  intro p hp
  have h : env31839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31838_31839 : H12AffineEnvironment.transform 11 3108 env31838 = env31839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env31838 == env31839) = true)

theorem identity31839 : scanCanonicalize (H12AffineFastState.compose env31839 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound31839 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env31840 : List Nat := [2,4,8,16,32,17,9,53,512,1024,2048,3108,57,3621,32768,32818,3636,34833,1025,32769,35328,32800,16,2,56,16,2048,36405,35877,2065,1072,32801,52,32801,3621,33280]

theorem envBound31840 : H12AffineFastState.Bounded env31840 := by
  intro p hp
  have h : env31840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31839_31840 : H12AffineEnvironment.transform 7 53 env31839 = env31840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env31839 == env31840) = true)

theorem identity31840 : scanCanonicalize (H12AffineFastState.compose env31840 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound31840 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31841 : List Nat := [2,4,8,16,32,17,9,53,512,1024,2048,3108,57,3621,512,562,3636,2577,1025,513,2048,544,16,2,56,16,2048,3125,3621,2065,1072,545,52,545,3621,0]

theorem envBound31841 : H12AffineFastState.Bounded env31841 := by
  intro p hp
  have h : env31841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31840_31841 : H12AffineEnvironment.transform 14 512 env31840 = env31841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env31840 == env31841) = true)

theorem identity31841 : scanCanonicalize (H12AffineFastState.compose env31841 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound31841 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31842 : List Nat := [2,4,8,16,32,17,9,53,512,1024,1077,17,57,528,512,562,513,1572,1025,513,1077,544,16,2,56,16,1077,0,528,1060,1072,545,52,545,528,0]

theorem envBound31842 : H12AffineFastState.Bounded env31842 := by
  intro p hp
  have h : env31842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31841_31842 : H12AffineEnvironment.transform 10 1077 env31841 = env31842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env31841 == env31842) = true)

theorem identity31842 : scanCanonicalize (H12AffineFastState.compose env31842 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound31842 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31843 : List Nat := [2,4,8,16,32,17,9,53,512,564,513,17,57,528,512,562,513,16,565,513,513,544,16,2,56,16,513,0,528,528,516,545,52,545,528,0]

theorem envBound31843 : H12AffineFastState.Bounded env31843 := by
  intro p hp
  have h : env31843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31842_31843 : H12AffineEnvironment.transform 9 564 env31842 = env31843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env31842 == env31843) = true)

theorem identity31843 : scanCanonicalize (H12AffineFastState.compose env31843 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound31843 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31844 : List Nat := [2,4,8,16,32,17,9,53,16,36,17,17,57,0,16,34,17,16,37,17,17,48,16,2,56,16,17,0,0,0,20,49,52,49,0,0]

theorem envBound31844 : H12AffineFastState.Bounded env31844 := by
  intro p hp
  have h : env31844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31843_31844 : H12AffineEnvironment.transform 8 16 env31843 = env31844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env31843 == env31844) = true)

def env31845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374097,4294967296,525568,4308116844,620851225,25733063]

theorem envBound31845 : H12AffineFastState.Bounded env31845 := by
  intro p hp
  have h : env31845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9854_31845 : H12AffineEnvironment.transform 34 620851225 env9854 = env31845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 620851225 env9854 == env31845) = true)

def env31846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,536870912,1073741824,92374097,4294967296,525568,4308116844,620851225,25733063]

theorem envBound31846 : H12AffineFastState.Bounded env31846 := by
  intro p hp
  have h : env31846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31845_31846 : H12AffineEnvironment.transform 27 19497100 env31845 = env31846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497100 env31845 == env31846) = true)

def env31847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,4294967296,525568,4308116844,27337993,25733063]

theorem envBound31847 : H12AffineFastState.Bounded env31847 := by
  intro p hp
  have h : env31847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31846_31847 : H12AffineEnvironment.transform 28 77616400 env31846 = env31847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env31846 == env31847) = true)

def env31848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound31848 : H12AffineFastState.Bounded env31848 := by
  intro p hp
  have h : env31848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31847_31848 : H12AffineEnvironment.transform 31 145662400 env31847 = env31848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env31847 == env31848) = true)

def env31849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound31849 : H12AffineFastState.Bounded env31849 := by
  intro p hp
  have h : env31849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31848_31849 : H12AffineEnvironment.transform 29 155254784 env31848 = env31849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env31848 == env31849) = true)

def env31850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound31850 : H12AffineFastState.Bounded env31850 := by
  intro p hp
  have h : env31850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31849_31850 : H12AffineEnvironment.transform 25 64 env31849 = env31850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env31849 == env31850) = true)

def env31851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound31851 : H12AffineFastState.Bounded env31851 := by
  intro p hp
  have h : env31851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31850_31851 : H12AffineEnvironment.transform 26 30393344 env31850 = env31851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env31850 == env31851) = true)

def env31852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound31852 : H12AffineFastState.Bounded env31852 := by
  intro p hp
  have h : env31852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31851_31852 : H12AffineEnvironment.transform 18 1024 env31851 = env31852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31851 == env31852) = true)

theorem identity31852 : scanCanonicalize (H12AffineFastState.compose env31852 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound31852 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,138,8328,64,13090954,2196486,10507600,8830976,8488091,6382922,256,10601510,10560899,8430413]

theorem envBound31853 : H12AffineFastState.Bounded env31853 := by
  intro p hp
  have h : env31853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31852_31853 : H12AffineEnvironment.transform 23 138 env31852 = env31853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env31852 == env31853) = true)

def env31854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,138,8328,64,4554754,2196486,2233816,295048,246803,6382922,256,2327726,2319627,189381]

theorem envBound31854 : H12AffineFastState.Bounded env31854 := by
  intro p hp
  have h : env31854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31853_31854 : H12AffineEnvironment.transform 22 147592 env31853 = env31854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env31853 == env31854) = true)

def env31855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,138,8328,64,4450482,2196486,2233816,190520,246803,6382922,256,2327726,2319627,189381]

theorem envBound31855 : H12AffineFastState.Bounded env31855 := by
  intro p hp
  have h : env31855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31854_31855 : H12AffineEnvironment.transform 17 157872 env31854 = env31855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env31854 == env31855) = true)

theorem identity31855 : scanCanonicalize (H12AffineFastState.compose env31855 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound31855 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10280,1024,32769,2097152,4194304,16,138,8328,64,4302890,2196486,2118976,43168,99467,6382922,256,2212918,2172307,41821]

theorem envBound31856 : H12AffineFastState.Bounded env31856 := by
  intro p hp
  have h : env31856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31855_31856 : H12AffineEnvironment.transform 16 16536 env31855 = env31856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env31855 == env31856) = true)

def env31857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302890,2196486,2118976,43048,99331,6382922,256,2212918,2172187,41821]

theorem envBound31857 : H12AffineFastState.Bounded env31857 := by
  intro p hp
  have h : env31857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31856_31857 : H12AffineEnvironment.transform 6 8 env31856 = env31857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31856 == env31857) = true)

theorem identity31857 : scanCanonicalize (H12AffineFastState.compose env31857 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31857 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,2,8192,64,4262262,2172250,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound31858 : H12AffineFastState.Bounded env31858 := by
  intro p hp
  have h : env31858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31857_31858 : H12AffineEnvironment.transform 14 8540 env31857 = env31858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31857 == env31858) = true)

theorem identity31858 : scanCanonicalize (H12AffineFastState.compose env31858 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 79194) := by decide +kernel

theorem selectedBound31858 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,79194,4194304,16,2,8192,64,4262262,4096,90138,2420,75103,4214800,256,20528,4161,513]

theorem envBound31859 : H12AffineFastState.Bounded env31859 := by
  intro p hp
  have h : env31859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31858_31859 : H12AffineEnvironment.transform 20 79194 env31858 = env31859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79194 env31858 == env31859) = true)

theorem identity31859 : scanCanonicalize (H12AffineFastState.compose env31859 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31859 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env31860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1024,8541,5456,4194304,16,2,8192,64,4204924,4096,16400,2420,1365,4214800,256,20528,4161,513]

theorem envBound31860 : H12AffineFastState.Bounded env31860 := by
  intro p hp
  have h : env31860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31859_31860 : H12AffineEnvironment.transform 15 8202 env31859 = env31860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31859 == env31860) = true)

theorem identity31860 : scanCanonicalize (H12AffineFastState.compose env31860 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 4145) := by decide +kernel

theorem selectedBound31860 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1024,8541,5456,4145,16,2,8192,64,14669,4096,16400,2420,1365,16417,256,20528,4161,513]

theorem envBound31861 : H12AffineFastState.Bounded env31861 := by
  intro p hp
  have h : env31861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31860_31861 : H12AffineEnvironment.transform 21 4145 env31860 = env31861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4145 env31860 == env31861) = true)

theorem identity31861 : scanCanonicalize (H12AffineFastState.compose env31861 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound31861 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env31862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1297,1095,16400,3173,1024,1296,5456,4145,16,2,1101,64,7424,4096,16400,2420,1365,16417,256,20528,4161,513]

theorem envBound31862 : H12AffineFastState.Bounded env31862 := by
  intro p hp
  have h : env31862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31861_31862 : H12AffineEnvironment.transform 12 1101 env31861 = env31862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env31861 == env31862) = true)

theorem identity31862 : scanCanonicalize (H12AffineFastState.compose env31862 (packedSelected [4,9,23] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31862 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env31863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,1101,16384,1297,1095,16400,3173,1024,1296,1345,32,16,2,1101,64,3345,17,16400,2420,1365,16417,256,16417,80,513]

theorem envBound31863 : H12AffineFastState.Bounded env31863 := by
  intro p hp
  have h : env31863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31862_31863 : H12AffineEnvironment.transform 11 17 env31862 = env31863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31862 == env31863) = true)

theorem identity31863 : scanCanonicalize (H12AffineFastState.compose env31863 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound31863 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,1101,80,1297,1095,64,3173,1024,1296,1345,32,16,2,1101,64,3345,17,64,2420,1365,113,256,113,80,513]

theorem envBound31864 : H12AffineFastState.Bounded env31864 := by
  intro p hp
  have h : env31864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31863_31864 : H12AffineEnvironment.transform 13 80 env31863 = env31864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env31863 == env31864) = true)

theorem identity31864 : scanCanonicalize (H12AffineFastState.compose env31864 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31864 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31865 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,17,1101,80,1125,1095,64,3173,1024,1124,1077,32,16,2,1101,64,3173,17,64,2048,1057,113,116,113,80,513]

theorem envBound31865 : H12AffineFastState.Bounded env31865 := by
  intro p hp
  have h : env31865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31864_31865 : H12AffineEnvironment.transform 7 116 env31864 = env31865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31864 == env31865) = true)

theorem identity31865 : scanCanonicalize (H12AffineFastState.compose env31865 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31865 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31866 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,17,1052,1,1076,1046,17,3124,1024,1077,1077,32,16,2,1052,17,3124,17,17,2048,1057,32,37,32,1,513]

theorem envBound31866 : H12AffineFastState.Bounded env31866 := by
  intro p hp
  have h : env31866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31865_31866 : H12AffineEnvironment.transform 5 17 env31865 = env31866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31865 == env31866) = true)

def env31867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4302890,2196486,2118976,43049,99330,6382922,256,2212918,2172186,41821]

theorem envBound31867 : H12AffineFastState.Bounded env31867 := by
  intro p hp
  have h : env31867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31856_31867 : H12AffineEnvironment.transform 6 9 env31856 = env31867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31856 == env31867) = true)

theorem identity31867 : scanCanonicalize (H12AffineFastState.compose env31867 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31867 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env31868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4237692,2131280,2118976,43049,34132,6317084,256,2147680,2106444,41821]

theorem envBound31868 : H12AffineFastState.Bounded env31868 := by
  intro p hp
  have h : env31868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31867_31868 : H12AffineEnvironment.transform 15 342 env31867 = env31868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31867 == env31868) = true)

theorem identity31868 : scanCanonicalize (H12AffineFastState.compose env31868 (packedSelected [1,2,4,5,6,8,11,16,17,18,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 50496) := by decide +kernel

theorem selectedBound31868 : packedSelected [1,2,4,5,6,8,11,16,17,18,22,24] rootPS < 2^1333 := by decide +kernel

def env31869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10280,1024,32769,50496,4194304,16,3,8193,64,4237692,16400,36864,43049,34132,4235612,256,32,57612,41821]

theorem envBound31869 : H12AffineFastState.Bounded env31869 := by
  intro p hp
  have h : env31869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31868_31869 : H12AffineEnvironment.transform 20 50496 env31868 = env31869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50496 env31868 == env31869) = true)

theorem identity31869 : scanCanonicalize (H12AffineFastState.compose env31869 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31869 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env31870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16401,10280,1024,8540,25629,4194304,16,3,8193,64,4196385,16400,12637,2420,9225,4194305,256,32,16465,512]

theorem envBound31870 : H12AffineFastState.Bounded env31870 := by
  intro p hp
  have h : env31870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31869_31870 : H12AffineEnvironment.transform 14 8541 env31869 = env31870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31869 == env31870) = true)

theorem identity31870 : scanCanonicalize (H12AffineFastState.compose env31870 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31870 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,5392,10280,1024,8540,12572,4194304,16,3,8193,64,4196385,5393,12637,2420,9225,4194305,256,32,5456,512]

theorem envBound31871 : H12AffineFastState.Bounded env31871 := by
  intro p hp
  have h : env31871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31870_31871 : H12AffineEnvironment.transform 13 5377 env31870 = env31871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31870 == env31871) = true)

theorem identity31871 : scanCanonicalize (H12AffineFastState.compose env31871 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 13436) := by decide +kernel

theorem selectedBound31871 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,5392,10280,1024,8540,12572,13436,16,3,8193,64,15453,5393,12637,2420,9225,13437,256,32,5456,512]

theorem envBound31872 : H12AffineFastState.Bounded env31872 := by
  intro p hp
  have h : env31872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31871_31872 : H12AffineEnvironment.transform 21 13436 env31871 = env31872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 13436 env31871 == env31872) = true)

theorem identity31872 : scanCanonicalize (H12AffineFastState.compose env31872 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 2429) := by decide +kernel

theorem selectedBound31872 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env31873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2429,5377,2080,342,5392,341,1024,2081,6241,7425,16,3,2428,64,5408,5393,6176,2420,3444,7424,256,32,5456,512]

theorem envBound31873 : H12AffineFastState.Bounded env31873 := by
  intro p hp
  have h : env31873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31872_31873 : H12AffineEnvironment.transform 12 2429 env31872 = env31873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2429 env31872 == env31873) = true)

theorem identity31873 : scanCanonicalize (H12AffineFastState.compose env31873 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31873 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env31874 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,2056,5236,2080,35,5221,32,1024,2081,6241,7284,16,3,2057,64,5205,5220,6176,2049,3073,7285,117,32,5157,512]

theorem envBound31874 : H12AffineFastState.Bounded env31874 := by
  intro p hp
  have h : env31874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31873_31874 : H12AffineEnvironment.transform 7 117 env31873 = env31874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31873 == env31874) = true)

def env31875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,138,8328,64,4450483,2196486,2233816,190521,246803,6382922,256,2327726,2319627,189381]

theorem envBound31875 : H12AffineFastState.Bounded env31875 := by
  intro p hp
  have h : env31875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31854_31875 : H12AffineEnvironment.transform 17 157873 env31854 = env31875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env31854 == env31875) = true)

def env31876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450363,2196486,2233680,190521,246803,6382922,256,2327590,2319627,189261]

theorem envBound31876 : H12AffineFastState.Bounded env31876 := by
  intro p hp
  have h : env31876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31875_31876 : H12AffineEnvironment.transform 6 8 env31875 = env31876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31875 == env31876) = true)

theorem identity31876 : scanCanonicalize (H12AffineFastState.compose env31876 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound31876 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35189,1024,32769,2097152,4194304,41292,2,8192,64,4262263,2196486,2159644,2421,75103,6382922,256,2188650,2196551,513]

theorem envBound31877 : H12AffineFastState.Bounded env31877 := by
  intro p hp
  have h : env31877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31876_31877 : H12AffineEnvironment.transform 16 57676 env31876 = env31877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env31876 == env31877) = true)

theorem identity31877 : scanCanonicalize (H12AffineFastState.compose env31877 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31877 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,35189,1024,32769,2097152,4194304,41292,2,8192,64,4229153,2098512,2159644,2421,41993,6349852,256,2155580,2098449,513]

theorem envBound31878 : H12AffineFastState.Bounded env31878 := by
  intro p hp
  have h : env31878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31877_31878 : H12AffineEnvironment.transform 15 33110 env31877 = env31878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31877 == env31878) = true)

theorem identity31878 : scanCanonicalize (H12AffineFastState.compose env31878 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound31878 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env31879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,35189,1024,32769,2097152,41341,41292,2,8192,64,10588,2098512,2159644,2421,41993,2114913,256,2155580,2098449,513]

theorem envBound31879 : H12AffineFastState.Bounded env31879 := by
  intro p hp
  have h : env31879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31878_31879 : H12AffineEnvironment.transform 21 41341 env31878 = env31879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env31878 == env31879) = true)

theorem identity31879 : scanCanonicalize (H12AffineFastState.compose env31879 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound31879 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,8282,16448,10361,1024,8461,2097152,113,64,2,8192,64,10588,2098512,2118928,2421,1285,2114913,256,2114864,2098449,513]

theorem envBound31880 : H12AffineFastState.Bounded env31880 := by
  intro p hp
  have h : env31880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31879_31880 : H12AffineEnvironment.transform 14 8460 env31879 = env31880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env31879 == env31880) = true)

theorem identity31880 : scanCanonicalize (H12AffineFastState.compose env31880 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31880 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31881 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10281,1024,8461,2097152,33,16,2,8192,16,10508,2098432,2118928,2341,1285,2114865,256,2114864,2098449,513]

theorem envBound31881 : H12AffineFastState.Bounded env31881 := by
  intro p hp
  have h : env31881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31880_31881 : H12AffineEnvironment.transform 5 16 env31880 = env31881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31880 == env31881) = true)

theorem identity31881 : scanCanonicalize (H12AffineFastState.compose env31881 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 16676) := by decide +kernel

theorem selectedBound31881 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31882 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10281,1024,8461,16676,33,16,2,8192,16,10508,17444,5172,2341,1285,1045,256,1044,17461,513]

theorem envBound31882 : H12AffineFastState.Bounded env31882 := by
  intro p hp
  have h : env31882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31881_31882 : H12AffineEnvironment.transform 20 16676 env31881 = env31882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16676 env31881 == env31882) = true)

theorem identity31882 : scanCanonicalize (H12AffineFastState.compose env31882 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31882 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env31883 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8192,16384,8460,8202,16400,10281,273,8461,16676,33,16,2,8192,16,10508,16693,4389,2341,20,260,256,261,16676,513]

theorem envBound31883 : H12AffineFastState.Bounded env31883 := by
  intro p hp
  have h : env31883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31882_31883 : H12AffineEnvironment.transform 9 273 env31882 = env31883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31882 == env31883) = true)

theorem identity31883 : scanCanonicalize (H12AffineFastState.compose env31883 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound31883 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env31884 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,40,16384,292,34,16400,2049,273,293,16676,33,16,2,40,16,2340,16693,4389,2341,20,260,256,261,16676,513]

theorem envBound31884 : H12AffineFastState.Bounded env31884 := by
  intro p hp
  have h : env31884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31883_31884 : H12AffineEnvironment.transform 12 40 env31883 = env31884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env31883 == env31884) = true)

theorem identity31884 : scanCanonicalize (H12AffineFastState.compose env31884 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31884 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31885 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,1,34,16400,2049,52,0,16385,33,16,2,40,16,2049,16400,4096,2048,20,33,37,32,16385,513]

theorem envBound31885 : H12AffineFastState.Bounded env31885 := by
  intro p hp
  have h : env31885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31884_31885 : H12AffineEnvironment.transform 7 37 env31884 = env31885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31884 == env31885) = true)

theorem identity31885 : scanCanonicalize (H12AffineFastState.compose env31885 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound31885 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31886 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,16384,1,34,16400,2049,52,0,16385,33,16,2,40,16,2049,16400,2064,2048,20,33,37,32,16385,513]

theorem envBound31886 : H12AffineFastState.Bounded env31886 := by
  intro p hp
  have h : env31886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31885_31886 : H12AffineEnvironment.transform 11 2064 env31885 = env31886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env31885 == env31886) = true)

theorem identity31886 : scanCanonicalize (H12AffineFastState.compose env31886 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound31886 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env31887 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,2048,1,34,2064,2049,52,0,2049,33,16,2,40,16,2049,2064,2064,2048,20,33,37,32,2049,513]

theorem envBound31887 : H12AffineFastState.Bounded env31887 := by
  intro p hp
  have h : env31887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31886_31887 : H12AffineEnvironment.transform 13 2048 env31886 = env31887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env31886 == env31887) = true)

theorem identity31887 : scanCanonicalize (H12AffineFastState.compose env31887 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31888 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,1,34,33,48,52,0,48,33,16,2,40,16,48,33,33,49,20,33,37,32,48,513]

theorem envBound31888 : H12AffineFastState.Bounded env31888 := by
  intro p hp
  have h : env31888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31887_31888 : H12AffineEnvironment.transform 10 49 env31887 = env31888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31887 == env31888) = true)

def leafEnv31888 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,1,34,33,48,52,0,48,33,16,2,20,40,1,16,48,33,33,49,20,33,37,32,4,34,48,513,1,49,0]

def active31888 : List Nat := [0,1,2,3,4,8]

def tree31888 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31888 : H12WitnessSearch.Good tree31888 := H12GlobalWitnessIndex.good

theorem leafIdentity31888 : H12AffineFastState.composeSystem env31888 rootObs = leafEnv31888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31888 rootObs == leafEnv31888) = true)

theorem terminalChecked31888 : H12PackedTerminal.terminalCheckFast leafEnv31888 active31888 tree31888 = true := by decide +kernel

def env31889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,64,4450362,2196486,2233681,190521,246803,6382922,256,2327591,2319627,189260]

theorem envBound31889 : H12AffineFastState.Bounded env31889 := by
  intro p hp
  have h : env31889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31875_31889 : H12AffineEnvironment.transform 6 9 env31875 = env31889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31875 == env31889) = true)

def env31890 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,16,4450362,2196486,2233601,190521,246803,6382874,256,2327591,2319627,189212]

theorem envBound31890 : H12AffineFastState.Bounded env31890 := by
  intro p hp
  have h : env31890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31889_31890 : H12AffineEnvironment.transform 5 16 env31889 = env31890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31889 == env31890) = true)

def env31891 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,4194304,147457,3,8193,16,4450362,2195766,2232369,190521,246051,6381610,256,2326807,2318395,189212]

theorem envBound31891 : H12AffineFastState.Bounded env31891 := by
  intro p hp
  have h : env31891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31890_31891 : H12AffineEnvironment.transform 9 304 env31890 = env31891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env31890 == env31891) = true)

theorem identity31891 : scanCanonicalize (H12AffineFastState.compose env31891 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound31891 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env31892 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,246070,147457,3,8193,16,10508,2195766,2232369,190521,246051,2269468,256,2326807,2318395,189212]

theorem envBound31892 : H12AffineFastState.Bounded env31892 := by
  intro p hp
  have h : env31892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31891_31892 : H12AffineEnvironment.transform 21 246070 env31891 = env31892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env31891 == env31892) = true)

theorem identity31892 : scanCanonicalize (H12AffineFastState.compose env31892 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound31892 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env31893 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,8461,65536,131072,157752,304,8460,2097152,221243,147457,3,8193,16,10508,2170939,2232369,149812,221230,2228241,256,2301978,2318395,147985]

theorem envBound31893 : H12AffineFastState.Bounded env31893 := by
  intro p hp
  have h : env31893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31892_31893 : H12AffineEnvironment.transform 14 8461 env31892 = env31893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env31892 == env31893) = true)

theorem identity31893 : scanCanonicalize (H12AffineFastState.compose env31893 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound31893 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31894 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,8461,65536,131072,157752,304,8460,82215,221243,147457,3,8193,16,10508,24860,217366,149812,221230,213302,256,155965,139548,147985]

theorem envBound31894 : H12AffineFastState.Bounded env31894 := by
  intro p hp
  have h : env31894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31893_31894 : H12AffineEnvironment.transform 20 82215 env31893 = env31894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env31893 == env31894) = true)

theorem identity31894 : scanCanonicalize (H12AffineFastState.compose env31894 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31894 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env31895 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,16384,1,65536,131072,149812,304,0,82215,213303,147457,3,269,16,2048,16400,217366,149812,213282,213302,256,147505,131088,147985]

theorem envBound31895 : H12AffineFastState.Bounded env31895 := by
  intro p hp
  have h : env31895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31894_31895 : H12AffineEnvironment.transform 12 268 env31894 = env31895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31894 == env31895) = true)

theorem identity31895 : scanCanonicalize (H12AffineFastState.compose env31895 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound31895 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31896 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,4113,1,65536,131072,137509,304,0,69942,200998,135184,3,269,16,2048,4097,196871,137509,201011,200999,256,135200,131088,135680]

theorem envBound31896 : H12AffineFastState.Bounded env31896 := by
  intro p hp
  have h : env31896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31895_31896 : H12AffineEnvironment.transform 13 4113 env31895 = env31896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31895 == env31896) = true)

theorem identity31896 : scanCanonicalize (H12AffineFastState.compose env31896 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound31896 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env31897 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,4113,1,65536,69894,67619,304,0,69942,32,65814,3,269,16,2048,4097,4097,67619,53,33,256,65830,69910,66310]

theorem envBound31897 : H12AffineFastState.Bounded env31897 := by
  intro p hp
  have h : env31897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31896_31897 : H12AffineEnvironment.transform 16 69894 env31896 = env31897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env31896 == env31897) = true)

theorem identity31897 : scanCanonicalize (H12AffineFastState.compose env31897 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound31897 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env31898 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,2325,268,2308,1,65536,67603,67619,304,0,67619,32,65814,3,269,16,2048,2324,2324,67619,53,33,256,65830,67587,66310]

theorem envBound31898 : H12AffineFastState.Bounded env31898 := by
  intro p hp
  have h : env31898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31897_31898 : H12AffineEnvironment.transform 11 2325 env31897 = env31898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env31897 == env31898) = true)

theorem identity31898 : scanCanonicalize (H12AffineFastState.compose env31898 (packedSelected [4,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31898 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env31899 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,2064,9,2049,1,65536,67603,67619,53,0,67619,32,65555,3,8,16,2048,2065,2065,67619,53,33,5,65571,67587,66051]

theorem envBound31899 : H12AffineFastState.Bounded env31899 := by
  intro p hp
  have h : env31899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31898_31899 : H12AffineEnvironment.transform 7 5 env31898 = env31899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31898 == env31899) = true)

theorem identity31899 : scanCanonicalize (H12AffineFastState.compose env31899 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound31899 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env31900 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,2064,9,2049,1,3,2064,2080,53,0,2080,32,16,3,8,16,2048,2065,2065,2080,53,33,5,32,2048,512]

theorem envBound31900 : H12AffineFastState.Bounded env31900 := by
  intro p hp
  have h : env31900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31899_31900 : H12AffineEnvironment.transform 15 3 env31899 = env31900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env31899 == env31900) = true)

theorem identity31900 : scanCanonicalize (H12AffineFastState.compose env31900 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound31900 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31901 : List Nat := [2,4,8,16,32,16,9,5,20,53,2048,2064,9,2049,1,3,2064,2080,53,0,2080,32,16,3,8,16,2048,2065,2065,2080,53,33,5,32,2048,20]

theorem envBound31901 : H12AffineFastState.Bounded env31901 := by
  intro p hp
  have h : env31901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31900_31901 : H12AffineEnvironment.transform 8 20 env31900 = env31901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env31900 == env31901) = true)

theorem identity31901 : scanCanonicalize (H12AffineFastState.compose env31901 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31902 : List Nat := [2,4,8,16,0,16,9,5,20,21,2048,2064,9,2049,1,3,2064,2048,21,0,2048,0,16,3,8,16,2048,2065,2065,2048,21,1,5,0,2048,20]

theorem envBound31902 : H12AffineFastState.Bounded env31902 := by
  intro p hp
  have h : env31902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31901_31902 : H12AffineEnvironment.transform 4 0 env31901 = env31902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31901 == env31902) = true)

theorem identity31902 : scanCanonicalize (H12AffineFastState.compose env31902 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound31902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31903 : List Nat := [2,4,8,5,0,5,9,5,1,0,2048,2053,9,2049,1,3,2053,2048,0,0,2048,0,5,3,8,5,2048,2052,2052,2048,0,1,5,0,2048,1]

theorem envBound31903 : H12AffineFastState.Bounded env31903 := by
  intro p hp
  have h : env31903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31902_31903 : H12AffineEnvironment.transform 3 5 env31902 = env31903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env31902 == env31903) = true)

def leafEnv31903 : List Nat := [2,4,8,5,0,5,9,5,1,0,2048,2053,9,2049,1,3,2053,2048,0,0,2048,0,5,3,0,8,1,5,2048,2052,2052,2048,0,1,5,0,4,2,2048,1,1,2049,0]

def active31903 : List Nat := [0,1,2,10]

def tree31903 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31903 : H12WitnessSearch.Good tree31903 := H12GlobalWitnessIndex.good

theorem leafIdentity31903 : H12AffineFastState.composeSystem env31903 rootObs = leafEnv31903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31903 rootObs == leafEnv31903) = true)

theorem terminalChecked31903 : H12PackedTerminal.terminalCheckFast leafEnv31903 active31903 tree31903 = true := by decide +kernel

def env31904 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,4194304,147457,3,8193,16,4450362,2195767,2232368,190521,246050,6381611,256,2326806,2318394,189212]

theorem envBound31904 : H12AffineFastState.Bounded env31904 := by
  intro p hp
  have h : env31904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31890_31904 : H12AffineEnvironment.transform 9 305 env31890 = env31904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env31890 == env31904) = true)

theorem identity31904 : scanCanonicalize (H12AffineFastState.compose env31904 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound31904 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env31905 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,73771,147457,3,8193,16,182289,2195767,2232368,190521,246050,2113536,256,2326806,2318394,189212]

theorem envBound31905 : H12AffineFastState.Bounded env31905 := by
  intro p hp
  have h : env31905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31904_31905 : H12AffineEnvironment.transform 21 73771 env31904 = env31905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env31904 == env31905) = true)

theorem identity31905 : scanCanonicalize (H12AffineFastState.compose env31905 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(20+1) ^^^ 49184) := by decide +kernel

theorem selectedBound31905 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env31906 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,49184,73771,147457,3,8193,16,182289,82199,184336,190521,246050,32800,256,213302,237594,189212]

theorem envBound31906 : H12AffineFastState.Bounded env31906 := by
  intro p hp
  have h : env31906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31905_31906 : H12AffineEnvironment.transform 20 49184 env31905 = env31906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49184 env31905 == env31906) = true)

theorem identity31906 : scanCanonicalize (H12AffineFastState.compose env31906 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31906 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env31907 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,1,65536,131072,157752,305,0,16417,73771,147457,3,8193,16,149520,82199,151569,157752,213283,33,256,213302,204827,156445]

theorem envBound31907 : H12AffineFastState.Bounded env31907 := by
  intro p hp
  have h : env31907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31906_31907 : H12AffineEnvironment.transform 14 1 env31906 = env31907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31906 == env31907) = true)

theorem identity31907 : scanCanonicalize (H12AffineFastState.compose env31907 (packedSelected [1,3,4,5,8,10,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound31907 : packedSelected [1,3,4,5,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env31908 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,1,263,131072,157752,305,0,16417,8492,147457,3,8193,16,149520,16400,151569,157752,147492,33,256,147505,139548,156445]

theorem envBound31908 : H12AffineFastState.Bounded env31908 := by
  intro p hp
  have h : env31908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31907_31908 : H12AffineEnvironment.transform 15 263 env31907 = env31908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env31907 == env31908) = true)

theorem identity31908 : scanCanonicalize (H12AffineFastState.compose env31908 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 12296) := by decide +kernel

theorem selectedBound31908 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31909 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,1,263,12296,22576,305,0,16417,8492,28681,3,8193,16,30744,16400,24601,22576,28716,33,256,28729,4372,21269]

theorem envBound31909 : H12AffineFastState.Bounded env31909 := by
  intro p hp
  have h : env31909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31908_31909 : H12AffineEnvironment.transform 16 12296 env31908 = env31909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12296 env31908 == env31909) = true)

theorem identity31909 : scanCanonicalize (H12AffineFastState.compose env31909 (packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound31909 : packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env31910 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,4373,1,263,12296,2341,305,0,4404,8492,8476,3,8193,16,10509,4357,12556,2341,8505,33,256,8492,4372,512]

theorem envBound31910 : H12AffineFastState.Bounded env31910 := by
  intro p hp
  have h : env31910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31909_31910 : H12AffineEnvironment.transform 13 4373 env31909 = env31910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env31909 == env31910) = true)

theorem identity31910 : scanCanonicalize (H12AffineFastState.compose env31910 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound31910 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31911 : List Nat := [2,4,8,16,32,16,9,256,512,305,782,4096,8192,4373,1,263,12296,555,305,0,4404,8492,8476,3,8193,16,8707,4357,12556,555,8505,33,256,8492,4372,512]

theorem envBound31911 : H12AffineFastState.Bounded env31911 := by
  intro p hp
  have h : env31911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31910_31911 : H12AffineEnvironment.transform 10 782 env31910 = env31911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env31910 == env31911) = true)

theorem identity31911 : scanCanonicalize (H12AffineFastState.compose env31911 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31911 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31912 : List Nat := [2,4,8,16,1,16,9,256,512,272,782,4096,8192,4373,1,263,12296,522,272,0,4373,8461,8476,3,8193,16,8707,4357,12556,522,8472,0,256,8461,4372,512]

theorem envBound31912 : H12AffineFastState.Bounded env31912 := by
  intro p hp
  have h : env31912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31911_31912 : H12AffineEnvironment.transform 4 1 env31911 = env31912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31911 == env31912) = true)

theorem identity31912 : scanCanonicalize (H12AffineFastState.compose env31912 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31912 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31913 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,4096,8192,4112,1,2,12296,522,21,0,4112,8200,8217,3,8193,16,8707,4096,12297,522,8221,0,5,8200,4113,512]

theorem envBound31913 : H12AffineFastState.Bounded env31913 := by
  intro p hp
  have h : env31913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31912_31913 : H12AffineEnvironment.transform 7 5 env31912 = env31913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31912 == env31913) = true)

theorem identity31913 : scanCanonicalize (H12AffineFastState.compose env31913 (packedSelected [0,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound31913 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env31914 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,4096,4,4112,1,2,4108,522,21,0,4112,12,29,3,5,16,519,4096,4109,522,25,0,5,12,4113,512]

theorem envBound31914 : H12AffineFastState.Bounded env31914 := by
  intro p hp
  have h : env31914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31913_31914 : H12AffineEnvironment.transform 12 4 env31913 = env31914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env31913 == env31914) = true)

theorem identity31914 : scanCanonicalize (H12AffineFastState.compose env31914 (packedSelected [1,7] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound31914 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env31915 : List Nat := [2,4,8,16,1,16,9,5,3,21,8,4096,4,4112,1,2,4108,9,21,0,4112,12,29,3,5,16,4,4096,4109,9,25,0,5,12,4113,3]

theorem envBound31915 : H12AffineFastState.Bounded env31915 := by
  intro p hp
  have h : env31915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31914_31915 : H12AffineEnvironment.transform 8 3 env31914 = env31915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env31914 == env31915) = true)

theorem identity31915 : scanCanonicalize (H12AffineFastState.compose env31915 (packedSelected [2,11] rootPS)) = affineNative (2^(11+1) ^^^ 29) := by decide +kernel

theorem selectedBound31915 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env31916 : List Nat := [2,4,8,16,1,16,9,5,3,21,8,29,4,13,1,2,17,9,21,0,13,12,29,3,5,16,4,29,16,9,25,0,5,12,12,3]

theorem envBound31916 : H12AffineFastState.Bounded env31916 := by
  intro p hp
  have h : env31916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31915_31916 : H12AffineEnvironment.transform 11 29 env31915 = env31916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 29 env31915 == env31916) = true)

theorem identity31916 : scanCanonicalize (H12AffineFastState.compose env31916 (packedSelected [0,1,12] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31916 : packedSelected [0,1,12] rootPS < 2^1333 := by decide +kernel

def env31917 : List Nat := [2,4,0,16,1,16,1,5,3,21,0,21,4,5,1,2,17,1,21,0,5,4,21,3,5,16,4,21,16,1,17,0,5,4,4,3]

theorem envBound31917 : H12AffineFastState.Bounded env31917 := by
  intro p hp
  have h : env31917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31916_31917 : H12AffineEnvironment.transform 2 0 env31916 = env31917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31916 == env31917) = true)

theorem identity31917 : scanCanonicalize (H12AffineFastState.compose env31917 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31917 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31918 : List Nat := [2,0,0,16,1,16,1,1,3,17,0,17,0,1,1,2,17,1,17,0,1,0,17,3,1,16,0,17,16,1,17,0,1,0,0,3]

theorem envBound31918 : H12AffineFastState.Bounded env31918 := by
  intro p hp
  have h : env31918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31917_31918 : H12AffineEnvironment.transform 1 0 env31917 = env31918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31917 == env31918) = true)

def env31919 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,17,4450362,2196486,2233600,190521,246803,6382875,256,2327591,2319627,189213]

theorem envBound31919 : H12AffineFastState.Bounded env31919 := by
  intro p hp
  have h : env31919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31889_31919 : H12AffineEnvironment.transform 5 17 env31889 = env31919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31889 == env31919) = true)

def env31920 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,4194304,147457,3,8193,17,4450362,2195766,2232368,190521,246051,6381611,256,2326807,2318395,189213]

theorem envBound31920 : H12AffineFastState.Bounded env31920 := by
  intro p hp
  have h : env31920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31920 : H12AffineEnvironment.transform 9 304 env31919 = env31920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env31919 == env31920) = true)

theorem identity31920 : scanCanonicalize (H12AffineFastState.compose env31920 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 188732) := by decide +kernel

theorem selectedBound31920 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env31921 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,188732,147457,3,8193,17,67846,2195766,2232368,190521,246051,2326807,256,2326807,2318395,189213]

theorem envBound31921 : H12AffineFastState.Bounded env31921 := by
  intro p hp
  have h : env31921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31920_31921 : H12AffineEnvironment.transform 21 188732 env31920 = env31921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188732 env31920 == env31921) = true)

theorem identity31921 : scanCanonicalize (H12AffineFastState.compose env31921 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound31921 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env31922 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,114967,108847,304,32769,2097152,73771,98582,3,8193,17,67846,2195766,2216231,76078,52,2113536,256,2113536,2138412,74250]

theorem envBound31922 : H12AffineFastState.Bounded env31922 := by
  intro p hp
  have h : env31922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31921_31922 : H12AffineEnvironment.transform 16 114967 env31921 = env31922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env31921 == env31922) = true)

theorem identity31922 : scanCanonicalize (H12AffineFastState.compose env31922 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 16417) := by decide +kernel

theorem selectedBound31922 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env31923 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,114967,108847,304,32769,16417,73771,98582,3,8193,17,67846,114967,102662,76078,52,33,256,33,57613,74250]

theorem envBound31923 : H12AffineFastState.Bounded env31923 := by
  intro p hp
  have h : env31923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31922_31923 : H12AffineEnvironment.transform 20 16417 env31922 = env31923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16417 env31922 == env31923) = true)

theorem identity31923 : scanCanonicalize (H12AffineFastState.compose env31923 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound31923 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31924 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,40970,24861,2341,304,32769,16417,32801,8476,3,8193,17,43276,24861,12556,35108,52,33,256,33,57613,33280]

theorem envBound31924 : H12AffineFastState.Bounded env31924 := by
  intro p hp
  have h : env31924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31923_31924 : H12AffineEnvironment.transform 15 40970 env31923 = env31924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env31923 == env31924) = true)

theorem identity31924 : scanCanonicalize (H12AffineFastState.compose env31924 (packedSelected [0,6,7,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 31036) := by decide +kernel

theorem selectedBound31924 : packedSelected [0,6,7,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31925 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,31036,22838,24861,2341,304,31037,16417,31005,8476,3,8193,17,20528,24861,12556,28696,52,33,256,33,6193,31548]

theorem envBound31925 : H12AffineFastState.Bounded env31925 := by
  intro p hp
  have h : env31925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31924_31925 : H12AffineEnvironment.transform 14 31036 env31924 = env31925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 31036 env31924 == env31925) = true)

theorem identity31925 : scanCanonicalize (H12AffineFastState.compose env31925 (packedSelected [6,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31925 : packedSelected [6,14,15,17] rootPS < 2^1333 := by decide +kernel

def env31926 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,269,16384,22577,22838,16400,2341,304,22576,16417,22544,17,3,268,17,20528,16400,4097,20757,52,33,256,33,6193,23089]

theorem envBound31926 : H12AffineFastState.Bounded env31926 := by
  intro p hp
  have h : env31926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31925_31926 : H12AffineEnvironment.transform 12 269 env31925 = env31926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31925 == env31926) = true)

theorem identity31926 : scanCanonicalize (H12AffineFastState.compose env31926 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31926 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31927 : List Nat := [2,4,8,16,32,17,9,256,512,304,1,4096,269,16384,20528,20791,16400,292,304,20529,16417,20497,17,3,268,17,20528,16400,4097,20757,52,33,256,33,4144,21040]

theorem envBound31927 : H12AffineFastState.Bounded env31927 := by
  intro p hp
  have h : env31927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31926_31927 : H12AffineEnvironment.transform 10 1 env31926 = env31927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31926 == env31927) = true)

theorem identity31927 : scanCanonicalize (H12AffineFastState.compose env31927 (packedSelected [2,4,7] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound31927 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env31928 : List Nat := [2,4,8,16,32,17,9,256,512,304,1,4096,269,292,4372,4115,308,292,304,4373,261,4405,17,3,268,17,4372,308,4097,4145,52,33,256,33,4144,4884]

theorem envBound31928 : H12AffineFastState.Bounded env31928 := by
  intro p hp
  have h : env31928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31927_31928 : H12AffineEnvironment.transform 13 292 env31927 = env31928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env31927 == env31928) = true)

theorem identity31928 : scanCanonicalize (H12AffineFastState.compose env31928 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31928 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31929 : List Nat := [2,4,8,16,32,17,9,37,512,21,1,4096,40,1,4145,4115,17,1,21,4144,32,4112,17,3,41,17,4145,17,4097,4145,52,33,37,33,4144,4657]

theorem envBound31929 : H12AffineFastState.Bounded env31929 := by
  intro p hp
  have h : env31929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31928_31929 : H12AffineEnvironment.transform 7 37 env31928 = env31929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31928 == env31929) = true)

theorem identity31929 : scanCanonicalize (H12AffineFastState.compose env31929 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 542) := by decide +kernel

theorem selectedBound31929 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env31930 : List Nat := [2,4,8,16,32,17,9,37,512,21,1,542,40,1,559,525,17,1,21,558,32,526,17,3,41,17,559,17,543,559,52,33,37,33,558,47]

theorem envBound31930 : H12AffineFastState.Bounded env31930 := by
  intro p hp
  have h : env31930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31929_31930 : H12AffineEnvironment.transform 11 542 env31929 = env31930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 542 env31929 == env31930) = true)

theorem identity31930 : scanCanonicalize (H12AffineFastState.compose env31930 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound31930 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31931 : List Nat := [2,4,8,16,32,17,9,37,47,21,1,49,40,1,0,34,17,1,21,1,32,33,17,3,41,17,0,17,48,0,52,33,37,33,1,47]

theorem envBound31931 : H12AffineFastState.Bounded env31931 := by
  intro p hp
  have h : env31931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31930_31931 : H12AffineEnvironment.transform 8 47 env31930 = env31931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env31930 == env31931) = true)

theorem identity31931 : scanCanonicalize (H12AffineFastState.compose env31931 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31932 : List Nat := [2,1,8,16,32,17,9,32,42,16,1,49,40,1,0,34,17,1,16,1,32,33,17,3,41,17,0,17,48,0,49,33,32,33,1,42]

theorem envBound31932 : H12AffineFastState.Bounded env31932 := by
  intro p hp
  have h : env31932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31931_31932 : H12AffineEnvironment.transform 1 1 env31931 = env31932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31931 == env31932) = true)

theorem identity31932 : scanCanonicalize (H12AffineFastState.compose env31932 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound31932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31933 : List Nat := [2,1,8,16,8,17,9,8,2,16,1,25,0,1,0,10,17,1,16,1,8,9,17,3,1,17,0,17,24,0,25,9,8,9,1,2]

theorem envBound31933 : H12AffineFastState.Bounded env31933 := by
  intro p hp
  have h : env31933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31932_31933 : H12AffineEnvironment.transform 4 8 env31932 = env31933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env31932 == env31933) = true)

theorem identity31933 : scanCanonicalize (H12AffineFastState.compose env31933 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound31933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31934 : List Nat := [2,1,1,16,1,17,0,1,2,16,1,16,0,1,0,3,17,1,16,1,1,0,17,3,1,17,0,17,17,0,16,0,1,0,1,2]

theorem envBound31934 : H12AffineFastState.Bounded env31934 := by
  intro p hp
  have h : env31934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31933_31934 : H12AffineEnvironment.transform 2 1 env31933 = env31934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env31933 == env31934) = true)

def env31935 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,4194304,147457,3,8193,17,4450362,2195767,2232369,190521,246050,6381610,256,2326806,2318394,189213]

theorem envBound31935 : H12AffineFastState.Bounded env31935 := by
  intro p hp
  have h : env31935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31935 : H12AffineEnvironment.transform 9 305 env31919 = env31935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env31919 == env31935) = true)

theorem identity31935 : scanCanonicalize (H12AffineFastState.compose env31935 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31935 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env31936 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,32,147457,3,8193,17,256026,2195767,2232369,190521,246050,2187274,256,2326806,2318394,189213]

theorem envBound31936 : H12AffineFastState.Bounded env31936 := by
  intro p hp
  have h : env31936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31935_31936 : H12AffineEnvironment.transform 21 32 env31935 = env31936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31935 == env31936) = true)

theorem identity31936 : scanCanonicalize (H12AffineFastState.compose env31936 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound31936 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31937 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,8460,65536,131072,157752,305,8461,2097152,32,147457,3,8193,17,215318,2170939,2232369,149813,221230,2187274,256,2301978,2318394,147985]

theorem envBound31937 : H12AffineFastState.Bounded env31937 := by
  intro p hp
  have h : env31937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31936_31937 : H12AffineEnvironment.transform 14 8460 env31936 = env31937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env31936 == env31937) = true)

theorem identity31937 : scanCanonicalize (H12AffineFastState.compose env31937 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31937 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env31938 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,0,65536,131072,149812,305,1,2097152,32,147457,3,269,17,215318,2162999,2232369,149813,213282,2179334,256,2294038,2310454,147985]

theorem envBound31938 : H12AffineFastState.Bounded env31938 := by
  intro p hp
  have h : env31938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31937_31938 : H12AffineEnvironment.transform 12 268 env31937 = env31938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31937 == env31938) = true)

theorem identity31938 : scanCanonicalize (H12AffineFastState.compose env31938 (packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 196918) := by decide +kernel

theorem selectedBound31938 : packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS < 2^1333 := by decide +kernel

def env31939 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,0,65536,131072,149812,305,1,196918,32,147457,3,269,17,215318,131073,69895,149813,213282,147504,256,32,16384,147985]

theorem envBound31939 : H12AffineFastState.Bounded env31939 := by
  intro p hp
  have h : env31939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31938_31939 : H12AffineEnvironment.transform 20 196918 env31938 = env31939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 196918 env31938 == env31939) = true)

theorem identity31939 : scanCanonicalize (H12AffineFastState.compose env31939 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound31939 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env31940 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,0,65536,82199,67619,305,1,16417,32,65814,3,269,17,2049,82198,69895,67618,53,65831,256,32,16384,66310]

theorem envBound31940 : H12AffineFastState.Bounded env31940 := by
  intro p hp
  have h : env31940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31939_31940 : H12AffineEnvironment.transform 16 82199 env31939 = env31940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env31939 == env31940) = true)

theorem identity31940 : scanCanonicalize (H12AffineFastState.compose env31940 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound31940 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31941 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,4405,0,65536,69666,67619,305,1,4372,32,65814,3,269,17,2049,69667,69895,67618,53,65831,256,32,4405,66310]

theorem envBound31941 : H12AffineFastState.Bounded env31941 := by
  intro p hp
  have h : env31941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31940_31941 : H12AffineEnvironment.transform 13 4405 env31940 = env31941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env31940 == env31941) = true)

theorem identity31941 : scanCanonicalize (H12AffineFastState.compose env31941 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound31941 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env31942 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,4405,0,295,4357,2308,305,1,4372,32,49,3,269,17,2049,4356,4128,2309,53,0,256,32,4405,545]

theorem envBound31942 : H12AffineFastState.Bounded env31942 := by
  intro p hp
  have h : env31942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31941_31942 : H12AffineEnvironment.transform 15 295 env31941 = env31942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env31941 == env31942) = true)

theorem identity31942 : scanCanonicalize (H12AffineFastState.compose env31942 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31942 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31943 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,268,4372,0,262,4357,2308,272,1,4372,1,16,3,269,17,2049,4356,4097,2309,20,0,256,1,4372,512]

theorem envBound31943 : H12AffineFastState.Bounded env31943 := by
  intro p hp
  have h : env31943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31942_31943 : H12AffineEnvironment.transform 4 1 env31942 = env31943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31942 == env31943) = true)

theorem identity31943 : scanCanonicalize (H12AffineFastState.compose env31943 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31943 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31944 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4113,0,3,4096,2049,21,1,4113,1,16,3,8,17,2049,4097,4097,2048,20,0,5,1,4113,512]

theorem envBound31944 : H12AffineFastState.Bounded env31944 := by
  intro p hp
  have h : env31944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31943_31944 : H12AffineEnvironment.transform 7 5 env31943 = env31944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31943 == env31944) = true)

theorem identity31944 : scanCanonicalize (H12AffineFastState.compose env31944 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31945 : List Nat := [2,4,8,16,1,17,9,5,512,21,513,4096,9,4113,0,3,4096,512,21,1,4113,1,16,3,8,17,512,4097,4097,513,20,0,5,1,4113,512]

theorem envBound31945 : H12AffineFastState.Bounded env31945 := by
  intro p hp
  have h : env31945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31944_31945 : H12AffineEnvironment.transform 10 513 env31944 = env31945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31944 == env31945) = true)

theorem identity31945 : scanCanonicalize (H12AffineFastState.compose env31945 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound31945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31946 : List Nat := [2,4,8,5,1,4,9,5,512,0,513,4096,9,4100,0,3,4096,512,0,1,4100,1,5,3,8,4,512,4097,4097,513,1,0,5,1,4100,512]

theorem envBound31946 : H12AffineFastState.Bounded env31946 := by
  intro p hp
  have h : env31946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31945_31946 : H12AffineEnvironment.transform 3 5 env31945 = env31946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env31945 == env31946) = true)

def env31947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,138,8328,64,4554755,2196486,2233817,295049,246802,6382922,256,2327727,2319626,189380]

theorem envBound31947 : H12AffineFastState.Bounded env31947 := by
  intro p hp
  have h : env31947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31853_31947 : H12AffineEnvironment.transform 22 147593 env31853 = env31947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env31853 == env31947) = true)

def env31948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,138,8328,64,4450483,2196486,2233817,190521,246802,6382922,256,2327727,2319626,189380]

theorem envBound31948 : H12AffineFastState.Bounded env31948 := by
  intro p hp
  have h : env31948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31947_31948 : H12AffineEnvironment.transform 17 157872 env31947 = env31948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env31947 == env31948) = true)

theorem identity31948 : scanCanonicalize (H12AffineFastState.compose env31948 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound31948 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,4194304,41292,138,8328,64,4262262,2196486,2159644,2556,75223,6382922,256,2188650,2196687,513]

theorem envBound31949 : H12AffineFastState.Bounded env31949 := by
  intro p hp
  have h : env31949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31948_31949 : H12AffineEnvironment.transform 16 57797 env31948 = env31949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env31948 == env31949) = true)

theorem identity31949 : scanCanonicalize (H12AffineFastState.compose env31949 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound31949 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,57797,35189,1024,32769,2097152,4194304,41292,138,8328,64,4229289,2098649,2159644,2556,41992,6349973,256,2155701,2098448,513]

theorem envBound31950 : H12AffineFastState.Bounded env31950 := by
  intro p hp
  have h : env31950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31949_31950 : H12AffineEnvironment.transform 15 33247 env31949 = env31950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env31949 == env31950) = true)

def env31951 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,57749,35109,1024,32769,2097152,4194304,41244,138,8328,16,4229289,2098569,2159644,2476,41992,6349973,256,2155701,2098448,513]

theorem envBound31951 : H12AffineFastState.Bounded env31951 := by
  intro p hp
  have h : env31951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31950_31951 : H12AffineEnvironment.transform 5 16 env31950 = env31951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31950 == env31951) = true)

theorem identity31951 : scanCanonicalize (H12AffineFastState.compose env31951 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound31951 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env31952 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,57749,35109,1024,32769,2097152,8612,41244,138,8328,16,43277,2098569,2159644,2476,41992,2147633,256,2155701,2098448,513]

theorem envBound31952 : H12AffineFastState.Bounded env31952 := by
  intro p hp
  have h : env31952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31951_31952 : H12AffineEnvironment.transform 21 8612 env31951 = env31952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env31951 == env31952) = true)

theorem identity31952 : scanCanonicalize (H12AffineFastState.compose env31952 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31952 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env31953 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,33167,49304,35109,1024,32769,2097152,169,32785,138,389,16,34816,2098569,2151697,2476,34053,2147633,256,2147768,2098448,513]

theorem envBound31953 : H12AffineFastState.Bounded env31953 := by
  intro p hp
  have h : env31953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31952_31953 : H12AffineEnvironment.transform 12 269 env31952 = env31953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31952 == env31953) = true)

theorem identity31953 : scanCanonicalize (H12AffineFastState.compose env31953 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31953 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env31954 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,1,398,16537,2340,1024,0,2097152,169,16,138,389,16,2049,2098569,2118928,2476,1284,2114864,256,2115001,2098448,513]

theorem envBound31954 : H12AffineFastState.Bounded env31954 := by
  intro p hp
  have h : env31954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31953_31954 : H12AffineEnvironment.transform 14 1 env31953 = env31954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31953 == env31954) = true)

theorem identity31954 : scanCanonicalize (H12AffineFastState.compose env31954 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound31954 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31955 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,4249,1,398,4096,2340,1024,0,2097152,169,16,138,389,16,2049,2098569,2098569,2476,1284,2102697,256,2102560,2098448,513]

theorem envBound31955 : H12AffineFastState.Bounded env31955 := by
  intro p hp
  have h : env31955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31954_31955 : H12AffineEnvironment.transform 13 4249 env31954 = env31955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env31954 == env31955) = true)

theorem identity31955 : scanCanonicalize (H12AffineFastState.compose env31955 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31955 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31956 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4113,1,262,4096,2340,1024,0,2097152,33,16,2,269,16,2049,2098433,2098433,2340,1284,2102561,256,2102560,2098448,513]

theorem envBound31956 : H12AffineFastState.Bounded env31956 := by
  intro p hp
  have h : env31956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31955_31956 : H12AffineEnvironment.transform 6 8 env31955 = env31956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31955 == env31956) = true)

theorem identity31956 : scanCanonicalize (H12AffineFastState.compose env31956 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 4129) := by decide +kernel

theorem selectedBound31956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31957 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4113,1,262,4096,2340,1024,0,4129,33,16,2,269,16,2049,5408,5408,2340,1284,1280,256,1281,5425,513]

theorem envBound31957 : H12AffineFastState.Bounded env31957 := by
  intro p hp
  have h : env31957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31956_31957 : H12AffineEnvironment.transform 20 4129 env31956 = env31957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4129 env31956 == env31957) = true)

theorem identity31957 : scanCanonicalize (H12AffineFastState.compose env31957 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound31957 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31958 : List Nat := [2,4,8,16,32,16,8,256,512,1024,561,4096,269,4113,1,262,4096,789,1024,0,4129,33,16,2,269,16,560,5408,5408,789,1284,1280,256,1281,5425,513]

theorem envBound31958 : H12AffineFastState.Bounded env31958 := by
  intro p hp
  have h : env31958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31957_31958 : H12AffineEnvironment.transform 10 561 env31957 = env31958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env31957 == env31958) = true)

theorem identity31958 : scanCanonicalize (H12AffineFastState.compose env31958 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound31958 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31959 : List Nat := [2,4,8,16,32,16,8,256,512,20,561,4096,269,4113,1,262,4096,789,20,0,4129,33,16,2,269,16,560,4404,4404,789,272,276,256,277,4389,513]

theorem envBound31959 : H12AffineFastState.Bounded env31959 := by
  intro p hp
  have h : env31959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31958_31959 : H12AffineEnvironment.transform 9 20 env31958 = env31959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31958 == env31959) = true)

theorem identity31959 : scanCanonicalize (H12AffineFastState.compose env31959 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31959 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env31960 : List Nat := [2,4,8,16,1,16,8,256,512,20,528,4096,269,4113,1,262,4096,789,20,0,4096,0,16,2,269,16,529,4373,4373,789,272,276,256,277,4356,513]

theorem envBound31960 : H12AffineFastState.Bounded env31960 := by
  intro p hp
  have h : env31960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31959_31960 : H12AffineEnvironment.transform 4 1 env31959 = env31960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31959 == env31960) = true)

theorem identity31960 : scanCanonicalize (H12AffineFastState.compose env31960 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound31960 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31961 : List Nat := [2,4,8,16,1,16,8,256,512,20,528,528,269,513,1,262,528,789,20,0,528,0,16,2,269,16,529,773,773,789,272,276,256,277,788,513]

theorem envBound31961 : H12AffineFastState.Bounded env31961 := by
  intro p hp
  have h : env31961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31960_31961 : H12AffineEnvironment.transform 11 528 env31960 = env31961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env31960 == env31961) = true)

theorem identity31961 : scanCanonicalize (H12AffineFastState.compose env31961 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31961 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31962 : List Nat := [2,4,8,1,1,1,8,256,512,5,513,513,269,513,1,262,513,772,5,0,513,0,1,2,269,1,512,773,773,772,257,261,256,260,773,513]

theorem envBound31962 : H12AffineFastState.Bounded env31962 := by
  intro p hp
  have h : env31962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31961_31962 : H12AffineEnvironment.transform 3 1 env31961 = env31962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31961 == env31962) = true)

theorem identity31962 : scanCanonicalize (H12AffineFastState.compose env31962 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31962 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env31963 : List Nat := [2,4,8,1,1,1,8,4,512,5,513,513,9,513,1,2,513,512,5,0,513,0,1,2,9,1,512,513,513,512,5,1,4,0,513,513]

theorem envBound31963 : H12AffineFastState.Bounded env31963 := by
  intro p hp
  have h : env31963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31962_31963 : H12AffineEnvironment.transform 7 4 env31962 = env31963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31962 == env31963) = true)

theorem identity31963 : scanCanonicalize (H12AffineFastState.compose env31963 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31964 : List Nat := [2,4,8,1,1,1,8,4,1,5,0,0,9,0,1,2,0,1,5,0,0,0,1,2,9,1,1,0,0,1,5,1,4,0,0,0]

theorem envBound31964 : H12AffineFastState.Bounded env31964 := by
  intro p hp
  have h : env31964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31963_31964 : H12AffineEnvironment.transform 8 1 env31963 = env31964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31963 == env31964) = true)

def env31965 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57748,35108,1024,32769,2097152,4194304,41245,138,8328,17,4229289,2098568,2159644,2477,41992,6349973,256,2155701,2098448,513]

theorem envBound31965 : H12AffineFastState.Bounded env31965 := by
  intro p hp
  have h : env31965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31950_31965 : H12AffineEnvironment.transform 5 17 env31950 = env31965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31950 == env31965) = true)

theorem identity31965 : scanCanonicalize (H12AffineFastState.compose env31965 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound31965 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env31966 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,262,24860,2476,1024,137,2097152,4194304,8597,138,8328,17,4196385,2098568,2126996,2477,9344,6317085,256,2122813,2098448,513]

theorem envBound31966 : H12AffineFastState.Bounded env31966 := by
  intro p hp
  have h : env31966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31965_31966 : H12AffineEnvironment.transform 14 136 env31965 = env31966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env31965 == env31966) = true)

theorem identity31966 : scanCanonicalize (H12AffineFastState.compose env31966 (packedSelected [7,14,18,20,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound31966 : packedSelected [7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env31967 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,262,24860,2476,1024,137,2097152,8492,8597,138,8328,17,10509,2098568,2126996,2477,9344,2114865,256,2122813,2098448,513]

theorem envBound31967 : H12AffineFastState.Bounded env31967 := by
  intro p hp
  have h : env31967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31966_31967 : H12AffineEnvironment.transform 21 8492 env31966 = env31967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env31966 == env31967) = true)

theorem identity31967 : scanCanonicalize (H12AffineFastState.compose env31967 (packedSelected [2,6,17] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound31967 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env31968 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,262,24860,2476,1024,137,17680,8492,8597,138,8328,17,10509,16536,12676,2477,9344,33,256,8493,16384,513]

theorem envBound31968 : H12AffineFastState.Bounded env31968 := by
  intro p hp
  have h : env31968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31967_31968 : H12AffineEnvironment.transform 20 17680 env31967 = env31968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env31967 == env31968) = true)

theorem identity31968 : scanCanonicalize (H12AffineFastState.compose env31968 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound31968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31969 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,262,16537,2476,1024,137,17680,169,16,138,269,17,2184,16536,4097,2477,1285,33,256,168,16384,513]

theorem envBound31969 : H12AffineFastState.Bounded env31969 := by
  intro p hp
  have h : env31969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31968_31969 : H12AffineEnvironment.transform 12 389 env31968 = env31969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env31968 == env31969) = true)

theorem identity31969 : scanCanonicalize (H12AffineFastState.compose env31969 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound31969 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31970 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,4249,136,262,4096,2476,1024,137,5513,169,16,138,269,17,2184,4097,4097,2477,1285,33,256,168,4249,513]

theorem envBound31970 : H12AffineFastState.Bounded env31970 := by
  intro p hp
  have h : env31970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31969_31970 : H12AffineEnvironment.transform 13 4249 env31969 = env31970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env31969 == env31970) = true)

theorem identity31970 : scanCanonicalize (H12AffineFastState.compose env31970 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31970 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env31971 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4112,1,262,4096,2341,1024,0,5376,32,16,3,269,17,2049,4097,4097,2340,1285,33,256,33,4112,513]

theorem envBound31971 : H12AffineFastState.Bounded env31971 := by
  intro p hp
  have h : env31971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31970_31971 : H12AffineEnvironment.transform 6 9 env31970 = env31971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31970 == env31971) = true)

theorem identity31971 : scanCanonicalize (H12AffineFastState.compose env31971 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31971 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31972 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4112,1,262,4096,2341,52,0,4404,32,16,3,269,17,2049,4097,4097,2340,305,33,256,33,4112,513]

theorem envBound31972 : H12AffineFastState.Bounded env31972 := by
  intro p hp
  have h : env31972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31971_31972 : H12AffineEnvironment.transform 9 52 env31971 = env31972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31971 == env31972) = true)

theorem identity31972 : scanCanonicalize (H12AffineFastState.compose env31972 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2852) := by decide +kernel

theorem selectedBound31972 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31973 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2852,268,2868,1,262,2852,2341,52,0,2576,32,16,3,269,17,2049,2853,2853,2340,305,33,256,33,2868,513]

theorem envBound31973 : H12AffineFastState.Bounded env31973 := by
  intro p hp
  have h : env31973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31972_31973 : H12AffineEnvironment.transform 11 2852 env31972 = env31973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2852 env31972 == env31973) = true)

theorem identity31973 : scanCanonicalize (H12AffineFastState.compose env31973 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31973 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0