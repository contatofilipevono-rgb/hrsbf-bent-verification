import H12CloudChart0Data004

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity1197 : scanCanonicalize (H12AffineFastState.compose env1197 (packedSelected [1,11] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound1197 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env1198 : List Nat := [2,4,8,16,3,19,8,4,9,5,2,17,10,2,3,0,3,0,5,3,18,3,18,3,10,17,2,3,16,0,5,1,4,1,2,8]

theorem envBound1198 : H12AffineFastState.Bounded env1198 := by
  intro p hp
  have h : env1198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1197_1198 : H12AffineEnvironment.transform 4 3 env1197 = env1198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env1197 == env1198) = true)

theorem identity1198 : scanCanonicalize (H12AffineFastState.compose env1198 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound1198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1199 : List Nat := [1,4,8,16,0,16,8,4,9,5,1,17,9,1,0,0,0,0,5,0,17,0,17,0,9,17,1,0,16,0,5,1,4,1,1,8]

theorem envBound1199 : H12AffineFastState.Bounded env1199 := by
  intro p hp
  have h : env1199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1198_1199 : H12AffineEnvironment.transform 0 1 env1198 = env1199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env1198 == env1199) = true)

theorem identity1199 : scanCanonicalize (H12AffineFastState.compose env1199 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1199 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1200 : List Nat := [1,4,8,12,0,12,8,4,9,5,1,13,9,1,0,0,0,0,5,0,13,0,13,0,9,13,1,0,12,0,5,1,4,1,1,8]

theorem envBound1200 : H12AffineFastState.Bounded env1200 := by
  intro p hp
  have h : env1200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1199_1200 : H12AffineEnvironment.transform 3 12 env1199 = env1200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1199 == env1200) = true)

theorem identity1200 : scanCanonicalize (H12AffineFastState.compose env1200 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1200 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env1201 : List Nat := [1,4,5,1,0,1,5,4,4,5,1,0,4,1,0,0,0,0,5,0,0,0,0,0,4,0,1,0,1,0,5,1,4,1,1,5]

theorem envBound1201 : H12AffineFastState.Bounded env1201 := by
  intro p hp
  have h : env1201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1200_1201 : H12AffineEnvironment.transform 2 5 env1200 = env1201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1200 == env1201) = true)

def env1202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2081,16852468,4341977,257,1,34359738368,16925298]

theorem envBound1202 : H12AffineFastState.Bounded env1202 := by
  intro p hp
  have h : env1202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1156_1202 : H12AffineEnvironment.transform 18 1025 env1156 = env1202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1156 == env1202) = true)

def env1203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2081,16852468,4341977,257,1,131072,16925298]

theorem envBound1203 : H12AffineFastState.Bounded env1203 := by
  intro p hp
  have h : env1203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1202_1203 : H12AffineEnvironment.transform 34 131072 env1202 = env1203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1202 == env1203) = true)

theorem identity1203 : scanCanonicalize (H12AffineFastState.compose env1203 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2229388) := by decide +kernel

theorem selectedBound1203 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2229388,147520,16777216,8328,147473,409817,16385,151552,2081,16852468,2114645,257,1,131072,16925298]

theorem envBound1204 : H12AffineFastState.Bounded env1204 := by
  intro p hp
  have h : env1204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1203_1204 : H12AffineEnvironment.transform 21 2229388 env1203 = env1204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2229388 env1203 == env1204) = true)

theorem identity1204 : scanCanonicalize (H12AffineFastState.compose env1204 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound1204 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2229388,147520,138,8328,147473,409817,16385,151552,2081,75134,2114645,257,1,131072,148216]

theorem envBound1205 : H12AffineFastState.Bounded env1205 := by
  intro p hp
  have h : env1205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1204_1205 : H12AffineEnvironment.transform 23 138 env1204 = env1205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env1204 == env1205) = true)

theorem identity1205 : scanCanonicalize (H12AffineFastState.compose env1205 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 17832) := by decide +kernel

theorem selectedBound1205 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env1206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,17832,147748,147520,138,8328,147473,409817,16385,151552,2081,75134,509,257,1,131072,148216]

theorem envBound1206 : H12AffineFastState.Bounded env1206 := by
  intro p hp
  have h : env1206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1205_1206 : H12AffineEnvironment.transform 20 17832 env1205 = env1206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17832 env1205 == env1206) = true)

theorem identity1206 : scanCanonicalize (H12AffineFastState.compose env1206 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1206 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env1207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1025,8693,17832,147748,147520,138,8328,147473,409817,16385,151552,2081,1024,509,257,1,131072,148216]

theorem envBound1207 : H12AffineFastState.Bounded env1207 := by
  intro p hp
  have h : env1207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1206_1207 : H12AffineEnvironment.transform 15 8574 env1206 = env1207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1206 == env1207) = true)

def env1208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1025,8693,17832,476,184,138,8328,233,262177,16385,4344,2081,1024,509,257,1,16632,512]

theorem envBound1208 : H12AffineFastState.Bounded env1208 := by
  intro p hp
  have h : env1208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1207_1208 : H12AffineEnvironment.transform 16 16632 env1207 = env1208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1207 == env1208) = true)

theorem identity1208 : scanCanonicalize (H12AffineFastState.compose env1208 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound1208 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,10281,1025,8693,17832,476,184,138,8328,233,10248,16385,4344,2081,1024,509,257,1,16632,512]

theorem envBound1209 : H12AffineFastState.Bounded env1209 := by
  intro p hp
  have h : env1209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1208_1209 : H12AffineEnvironment.transform 17 10281 env1208 = env1209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env1208 == env1209) = true)

theorem identity1209 : scanCanonicalize (H12AffineFastState.compose env1209 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound1209 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env1210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,16384,80,219,16632,2444,1025,80,17832,476,184,138,301,233,2477,16385,4344,2081,1024,509,257,1,16632,512]

theorem envBound1210 : H12AffineFastState.Bounded env1210 := by
  intro p hp
  have h : env1210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1209_1210 : H12AffineEnvironment.transform 12 421 env1209 = env1210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env1209 == env1210) = true)

theorem identity1210 : scanCanonicalize (H12AffineFastState.compose env1210 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound1210 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1211 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,225,16384,80,219,16632,2248,1025,80,17644,152,184,138,105,233,2281,16385,4344,2081,1024,185,69,1,16632,512]

theorem envBound1211 : H12AffineFastState.Bounded env1211 := by
  intro p hp
  have h : env1211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1210_1211 : H12AffineEnvironment.transform 7 68 env1210 = env1211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env1210 == env1211) = true)

def env1212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1025,8693,17832,477,185,138,8328,232,262176,16385,4345,2081,1024,509,257,1,16633,513]

theorem envBound1212 : H12AffineFastState.Bounded env1212 := by
  intro p hp
  have h : env1212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1207_1212 : H12AffineEnvironment.transform 16 16633 env1207 = env1212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1207 == env1212) = true)

theorem identity1212 : scanCanonicalize (H12AffineFastState.compose env1212 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound1212 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8693,8574,13557,262144,1025,8693,12708,477,185,138,8328,232,262176,13325,4345,2081,1024,509,257,1,13557,513]

theorem envBound1213 : H12AffineFastState.Bounded env1213 := by
  intro p hp
  have h : env1213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1212_1213 : H12AffineEnvironment.transform 13 13324 env1212 = env1213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env1212 == env1213) = true)

theorem identity1213 : scanCanonicalize (H12AffineFastState.compose env1213 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound1213 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,9,5125,508,375,5372,262144,1025,508,4525,477,185,138,129,232,262176,5124,4345,2081,1024,509,257,1,5372,513]

theorem envBound1214 : H12AffineFastState.Bounded env1214 := by
  intro p hp
  have h : env1214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1213_1214 : H12AffineEnvironment.transform 12 9 env1213 = env1214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env1213 == env1214) = true)

theorem identity1214 : scanCanonicalize (H12AffineFastState.compose env1214 (packedSelected [4,6,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound1214 : packedSelected [4,6,9,20] rootPS < 2^1333 := by decide +kernel

def env1215 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,4096,9,5125,277,375,5141,262144,1025,277,4420,308,80,99,104,1,262176,5124,4112,2081,1024,276,257,1,5141,513]

theorem envBound1215 : H12AffineFastState.Bounded env1215 := by
  intro p hp
  have h : env1215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1214_1215 : H12AffineEnvironment.transform 6 105 env1214 = env1215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env1214 == env1215) = true)

theorem identity1215 : scanCanonicalize (H12AffineFastState.compose env1215 (packedSelected [0,2,6,7,11,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2096) := by decide +kernel

theorem selectedBound1215 : packedSelected [0,2,6,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env1216 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,4096,9,5125,277,375,5141,2096,1025,277,4420,308,80,99,104,1,2064,5124,4112,2081,1024,276,257,1,5141,513]

theorem envBound1216 : H12AffineFastState.Bounded env1216 := by
  intro p hp
  have h : env1216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1215_1216 : H12AffineEnvironment.transform 17 2096 env1215 = env1216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2096 env1215 == env1216) = true)

theorem identity1216 : scanCanonicalize (H12AffineFastState.compose env1216 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound1216 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env1217 : List Nat := [2,4,8,16,32,64,105,69,512,1024,2048,4096,9,5125,80,50,5141,2096,1025,80,4097,113,80,99,104,1,2064,5124,4112,2081,1024,81,68,1,5141,513]

theorem envBound1217 : H12AffineFastState.Bounded env1217 := by
  intro p hp
  have h : env1217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1216_1217 : H12AffineEnvironment.transform 7 69 env1216 = env1217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env1216 == env1217) = true)

def env1218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2081,16852468,4341977,257,1,131073,16925298]

theorem envBound1218 : H12AffineFastState.Bounded env1218 := by
  intro p hp
  have h : env1218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1202_1218 : H12AffineEnvironment.transform 34 131073 env1202 = env1218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1202 == env1218) = true)

theorem identity1218 : scanCanonicalize (H12AffineFastState.compose env1218 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 136333) := by decide +kernel

theorem selectedBound1218 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,136333,147520,16777216,8328,147473,409817,16385,151552,2081,16852468,21588,257,1,131073,16925298]

theorem envBound1219 : H12AffineFastState.Bounded env1219 := by
  intro p hp
  have h : env1219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1218_1219 : H12AffineEnvironment.transform 21 136333 env1218 = env1219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136333 env1218 == env1219) = true)

theorem identity1219 : scanCanonicalize (H12AffineFastState.compose env1219 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 210265) := by decide +kernel

theorem selectedBound1219 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,136333,147520,210265,8328,147473,409817,16385,151552,2081,135341,21588,257,1,131073,96043]

theorem envBound1220 : H12AffineFastState.Bounded env1220 := by
  intro p hp
  have h : env1220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1219_1220 : H12AffineEnvironment.transform 23 210265 env1219 = env1220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 210265 env1219 == env1220) = true)

theorem identity1220 : scanCanonicalize (H12AffineFastState.compose env1220 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1220 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1025,8693,2097152,136333,147520,136231,8328,147473,409817,16385,151552,2081,135341,21588,257,1,131073,22101]

theorem envBound1221 : H12AffineFastState.Bounded env1221 := by
  intro p hp
  have h : env1221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1220_1221 : H12AffineEnvironment.transform 15 8574 env1220 = env1221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1220 == env1221) = true)

def env1222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5560,8693,8574,131072,262144,1025,8693,2097152,136333,136696,136231,8328,136617,398689,5561,132536,2081,135341,492,257,1,131073,1005]

theorem envBound1222 : H12AffineFastState.Bounded env1222 := by
  intro p hp
  have h : env1222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1221_1222 : H12AffineEnvironment.transform 13 5560 env1221 = env1222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5560 env1221 == env1222) = true)

theorem identity1222 : scanCanonicalize (H12AffineFastState.compose env1222 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound1222 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env1223 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,8192,5204,8217,8338,131072,262144,1025,8217,2097152,136333,136212,136231,8328,136261,398477,5205,132180,2081,135341,0,237,1,131073,513]

theorem envBound1223 : H12AffineFastState.Bounded env1223 := by
  intro p hp
  have h : env1223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1222_1223 : H12AffineEnvironment.transform 7 236 env1222 = env1223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env1222 == env1223) = true)

theorem identity1223 : scanCanonicalize (H12AffineFastState.compose env1223 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 132349) := by decide +kernel

theorem selectedBound1223 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1224 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,8192,5204,8217,8338,131072,262144,1025,8217,132349,136333,136212,136231,8328,136261,398477,5205,132180,2081,135341,0,237,1,131073,513]

theorem envBound1224 : H12AffineFastState.Bounded env1224 := by
  intro p hp
  have h : env1224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1223_1224 : H12AffineEnvironment.transform 20 132349 env1223 = env1224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132349 env1223 == env1224) = true)

theorem identity1224 : scanCanonicalize (H12AffineFastState.compose env1224 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5204) := by decide +kernel

theorem selectedBound1224 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env1225 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,8192,5204,8217,8338,5204,262144,1025,8217,4265,217,64,115,8328,17,262361,5205,4096,2081,1273,0,237,1,5205,513]

theorem envBound1225 : H12AffineFastState.Bounded env1225 := by
  intro p hp
  have h : env1225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1224_1225 : H12AffineEnvironment.transform 16 5204 env1224 = env1225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5204 env1224 == env1225) = true)

theorem identity1225 : scanCanonicalize (H12AffineFastState.compose env1225 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1225 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env1226 : List Nat := [2,4,8,1,32,64,128,236,512,1024,2048,4096,8192,5189,8200,8323,5189,262144,1025,8200,4265,200,64,98,8328,0,262344,5188,4096,2081,1256,0,237,1,5188,513]

theorem envBound1226 : H12AffineFastState.Bounded env1226 := by
  intro p hp
  have h : env1226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1225_1226 : H12AffineEnvironment.transform 3 1 env1225 = env1226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1225 == env1226) = true)

theorem identity1226 : scanCanonicalize (H12AffineFastState.compose env1226 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound1226 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env1227 : List Nat := [2,4,8,1,32,64,104,4,512,1024,2048,4096,8192,5189,8200,8299,5189,262144,1025,8200,4161,32,64,98,8288,0,262176,5188,4096,2081,1024,0,5,1,5188,513]

theorem envBound1227 : H12AffineFastState.Bounded env1227 := by
  intro p hp
  have h : env1227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1226_1227 : H12AffineEnvironment.transform 6 104 env1226 = env1227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env1226 == env1227) = true)

theorem identity1227 : scanCanonicalize (H12AffineFastState.compose env1227 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound1227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1228 : List Nat := [2,4,8,1,32,64,104,4,512,1024,2048,4096,8,5189,0,99,5189,262144,1025,0,4161,32,64,98,104,0,262176,5188,4096,2081,1024,0,5,1,5188,513]

theorem envBound1228 : H12AffineFastState.Bounded env1228 := by
  intro p hp
  have h : env1228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1227_1228 : H12AffineEnvironment.transform 12 8 env1227 = env1228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env1227 == env1228) = true)

theorem identity1228 : scanCanonicalize (H12AffineFastState.compose env1228 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound1228 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env1229 : List Nat := [2,4,8,1,32,64,104,4,512,1024,2048,4096,8,5189,0,99,5189,554,1025,0,4161,32,64,98,104,0,522,5188,4096,2081,1024,0,5,1,5188,513]

theorem envBound1229 : H12AffineFastState.Bounded env1229 := by
  intro p hp
  have h : env1229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1228_1229 : H12AffineEnvironment.transform 17 554 env1228 = env1229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env1228 == env1229) = true)

def env1230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5561,8693,8574,131072,262144,1025,8693,2097152,136333,136697,136231,8328,136616,398688,5560,132537,2081,135341,493,257,1,131073,1004]

theorem envBound1230 : H12AffineFastState.Bounded env1230 := by
  intro p hp
  have h : env1230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1221_1230 : H12AffineEnvironment.transform 13 5561 env1221 = env1230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5561 env1221 == env1230) = true)

def env1231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147521,16777216,8328,672785,935129,16385,151552,2081,17375733,4867289,525568,1,34359738368,17450610]

theorem envBound1231 : H12AffineFastState.Bounded env1231 := by
  intro p hp
  have h : env1231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1155_1231 : H12AffineEnvironment.transform 22 147521 env1155 = env1231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env1155 == env1231) = true)

def env1232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2081,16852469,4341977,256,1,34359738368,16925298]

theorem envBound1232 : H12AffineFastState.Bounded env1232 := by
  intro p hp
  have h : env1232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1231_1232 : H12AffineEnvironment.transform 18 1024 env1231 = env1232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1231 == env1232) = true)

def env1233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2081,16852469,4341977,256,1,131072,16925298]

theorem envBound1233 : H12AffineFastState.Bounded env1233 := by
  intro p hp
  have h : env1233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1232_1233 : H12AffineEnvironment.transform 34 131072 env1232 = env1233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1232 == env1233) = true)

theorem identity1233 : scanCanonicalize (H12AffineFastState.compose env1233 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2118045) := by decide +kernel

theorem selectedBound1233 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2118045,147521,16777216,8328,147473,409817,16385,151552,2081,16852469,2232644,256,1,131072,16925298]

theorem envBound1234 : H12AffineFastState.Bounded env1234 := by
  intro p hp
  have h : env1234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1233_1234 : H12AffineEnvironment.transform 21 2118045 env1233 = env1234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2118045 env1233 == env1234) = true)

theorem identity1234 : scanCanonicalize (H12AffineFastState.compose env1234 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1234 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,2097152,2118045,147521,16777216,8328,147473,409817,16385,151552,2081,16778638,2232644,256,1,131072,16925298]

theorem envBound1235 : H12AffineFastState.Bounded env1235 := by
  intro p hp
  have h : env1235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1234_1235 : H12AffineEnvironment.transform 15 8315 env1234 = env1235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1234 == env1235) = true)

def env1236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,135492,147673,147521,16777216,8328,147473,409817,16385,151552,2081,16778638,0,256,1,131072,16925298]

theorem envBound1236 : H12AffineFastState.Bounded env1236 := by
  intro p hp
  have h : env1236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1235_1236 : H12AffineEnvironment.transform 20 135492 env1235 = env1236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135492 env1235 == env1236) = true)

theorem identity1236 : scanCanonicalize (H12AffineFastState.compose env1236 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1236 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1237 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,131072,262144,1024,8433,135232,147673,147521,16777216,8328,147473,409817,16385,151552,2081,16778378,0,4,1,131072,16925298]

theorem envBound1237 : H12AffineFastState.Bounded env1237 := by
  intro p hp
  have h : env1237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1236_1237 : H12AffineEnvironment.transform 7 4 env1236 = env1237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1236 == env1237) = true)

def env1238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,135493,147672,147521,16777216,8328,147473,409817,16385,151552,2081,16778638,1,256,1,131072,16925298]

theorem envBound1238 : H12AffineFastState.Bounded env1238 := by
  intro p hp
  have h : env1238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1235_1238 : H12AffineEnvironment.transform 20 135493 env1235 = env1238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135493 env1235 == env1238) = true)

theorem identity1238 : scanCanonicalize (H12AffineFastState.compose env1238 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147830) := by decide +kernel

theorem selectedBound1238 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,135493,147672,147521,147830,8328,147473,409817,16385,151552,2081,148728,1,256,1,131072,772]

theorem envBound1239 : H12AffineFastState.Bounded env1239 := by
  intro p hp
  have h : env1239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1238_1239 : H12AffineEnvironment.transform 23 147830 env1238 = env1239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147830 env1238 == env1239) = true)

theorem identity1239 : scanCanonicalize (H12AffineFastState.compose env1239 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1239 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,2525,1024,8693,135493,147672,147521,147830,8328,147473,149764,16385,151552,2081,148728,1,256,1,131072,772]

theorem envBound1240 : H12AffineFastState.Bounded env1240 := by
  intro p hp
  have h : env1240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1239_1240 : H12AffineEnvironment.transform 17 2525 env1239 = env1240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1239 == env1240) = true)

theorem identity1240 : scanCanonicalize (H12AffineFastState.compose env1240 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound1240 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env1241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16632,2525,1024,8693,20925,32,185,398,8328,233,2556,16385,4344,2081,1024,1,256,1,16632,772]

theorem envBound1241 : H12AffineFastState.Bounded env1241 := by
  intro p hp
  have h : env1241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1240_1241 : H12AffineEnvironment.transform 16 16632 env1240 = env1241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1240 == env1241) = true)

theorem identity1241 : scanCanonicalize (H12AffineFastState.compose env1241 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1241 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env1242 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8315,16632,2264,1024,8432,20664,32,185,139,8328,233,2297,16385,4344,2081,1024,1,5,1,16632,513]

theorem envBound1242 : H12AffineFastState.Bounded env1242 := by
  intro p hp
  have h : env1242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1241_1242 : H12AffineEnvironment.transform 7 5 env1241 = env1242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1241 == env1242) = true)

theorem identity1242 : scanCanonicalize (H12AffineFastState.compose env1242 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1242 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1243 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,3767,8432,8315,3663,2264,1024,8432,7695,32,185,139,8328,233,2297,3766,4344,2081,1024,1,5,1,3663,513]

theorem envBound1243 : H12AffineFastState.Bounded env1243 := by
  intro p hp
  have h : env1243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1242_1243 : H12AffineEnvironment.transform 13 3767 env1242 = env1243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3767 env1242 == env1243) = true)

theorem identity1243 : scanCanonicalize (H12AffineFastState.compose env1243 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1243 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1244 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,4096,8192,97,8432,8315,153,1550,1024,8432,4313,32,185,139,8328,233,1583,96,4344,1783,1024,1,5,1,153,513]

theorem envBound1244 : H12AffineFastState.Bounded env1244 := by
  intro p hp
  have h : env1244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1243_1244 : H12AffineEnvironment.transform 10 1750 env1243 = env1244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1750 env1243 == env1244) = true)

theorem identity1244 : scanCanonicalize (H12AffineFastState.compose env1244 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1157) := by decide +kernel

theorem selectedBound1244 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1245 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,4096,1157,97,1141,1278,153,1550,1024,1141,4313,32,185,139,1037,233,1583,96,4344,1783,1024,1,5,1,153,513]

theorem envBound1245 : H12AffineFastState.Bounded env1245 := by
  intro p hp
  have h : env1245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1244_1245 : H12AffineEnvironment.transform 12 1157 env1244 = env1245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1157 env1244 == env1245) = true)

theorem identity1245 : scanCanonicalize (H12AffineFastState.compose env1245 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1245 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1246 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,1750,1157,97,1141,1278,153,1550,1024,1141,1551,32,185,139,1037,233,1583,96,1582,1783,1024,1,5,1,153,513]

theorem envBound1246 : H12AffineFastState.Bounded env1246 := by
  intro p hp
  have h : env1246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1245_1246 : H12AffineEnvironment.transform 11 1750 env1245 = env1246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1750 env1245 == env1246) = true)

theorem identity1246 : scanCanonicalize (H12AffineFastState.compose env1246 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound1246 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1247 : List Nat := [2,4,8,16,32,64,128,5,512,646,80,80,515,97,755,632,153,136,646,755,137,32,185,139,651,233,169,96,168,113,646,1,5,1,153,513]

theorem envBound1247 : H12AffineFastState.Bounded env1247 := by
  intro p hp
  have h : env1247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1246_1247 : H12AffineEnvironment.transform 9 646 env1246 = env1247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env1246 == env1247) = true)

theorem identity1247 : scanCanonicalize (H12AffineFastState.compose env1247 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1247 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1248 : List Nat := [2,4,8,16,32,64,120,5,512,638,80,80,515,97,523,632,97,112,638,523,113,32,65,115,627,17,81,96,80,113,638,1,5,1,97,513]

theorem envBound1248 : H12AffineFastState.Bounded env1248 := by
  intro p hp
  have h : env1248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1247_1248 : H12AffineEnvironment.transform 6 120 env1247 = env1248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1247 == env1248) = true)

theorem identity1248 : scanCanonicalize (H12AffineFastState.compose env1248 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound1248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1249 : List Nat := [2,4,8,16,32,64,120,5,107,21,80,80,104,97,96,19,97,112,21,96,113,32,65,115,24,17,81,96,80,113,21,1,5,1,97,106]

theorem envBound1249 : H12AffineFastState.Bounded env1249 := by
  intro p hp
  have h : env1249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1248_1249 : H12AffineEnvironment.transform 8 107 env1248 = env1249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env1248 == env1249) = true)

theorem identity1249 : scanCanonicalize (H12AffineFastState.compose env1249 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1249 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1250 : List Nat := [2,4,8,1,32,64,105,5,107,4,65,65,104,97,96,2,97,97,4,96,96,32,65,98,9,0,64,96,65,96,4,1,5,1,97,106]

theorem envBound1250 : H12AffineFastState.Bounded env1250 := by
  intro p hp
  have h : env1250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1249_1250 : H12AffineEnvironment.transform 3 1 env1249 = env1250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1249 == env1250) = true)

theorem identity1250 : scanCanonicalize (H12AffineFastState.compose env1250 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound1250 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1251 : List Nat := [2,4,8,1,32,33,8,5,10,4,32,32,9,0,1,2,0,0,4,1,1,32,32,3,9,0,33,1,32,1,4,1,5,1,0,11]

theorem envBound1251 : H12AffineFastState.Bounded env1251 := by
  intro p hp
  have h : env1251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1250_1251 : H12AffineEnvironment.transform 5 33 env1250 = env1251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env1250 == env1251) = true)

theorem identity1251 : scanCanonicalize (H12AffineFastState.compose env1251 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound1251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1252 : List Nat := [1,4,8,1,32,33,8,5,9,4,32,32,9,0,1,1,0,0,4,1,1,32,32,0,9,0,33,1,32,1,4,1,5,1,0,8]

theorem envBound1252 : H12AffineFastState.Bounded env1252 := by
  intro p hp
  have h : env1252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1251_1252 : H12AffineEnvironment.transform 0 1 env1251 = env1252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env1251 == env1252) = true)

theorem identity1252 : scanCanonicalize (H12AffineFastState.compose env1252 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1252 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1253 : List Nat := [1,4,8,1,1,0,8,5,9,4,1,1,9,0,1,1,0,0,4,1,1,1,1,0,9,0,0,1,1,1,4,1,5,1,0,8]

theorem envBound1253 : H12AffineFastState.Bounded env1253 := by
  intro p hp
  have h : env1253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1252_1253 : H12AffineEnvironment.transform 4 1 env1252 = env1253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1252 == env1253) = true)

theorem identity1253 : scanCanonicalize (H12AffineFastState.compose env1253 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound1253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1254 : List Nat := [1,0,8,1,1,0,8,1,9,0,1,1,9,0,1,1,0,0,0,1,1,1,1,0,9,0,0,1,1,1,0,1,1,1,0,8]

theorem envBound1254 : H12AffineFastState.Bounded env1254 := by
  intro p hp
  have h : env1254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1253_1254 : H12AffineEnvironment.transform 1 0 env1253 = env1254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env1253 == env1254) = true)

def env1255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2081,16852469,4341977,256,1,131073,16925298]

theorem envBound1255 : H12AffineFastState.Bounded env1255 := by
  intro p hp
  have h : env1255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1232_1255 : H12AffineEnvironment.transform 34 131073 env1232 = env1255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1232 == env1255) = true)

theorem identity1255 : scanCanonicalize (H12AffineFastState.compose env1255 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 16796) := by decide +kernel

theorem selectedBound1255 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,16796,147521,16777216,8328,147473,409817,16385,151552,2081,16852469,131397,256,1,131073,16925298]

theorem envBound1256 : H12AffineFastState.Bounded env1256 := by
  intro p hp
  have h : env1256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1255_1256 : H12AffineEnvironment.transform 21 16796 env1255 = env1256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16796 env1255 == env1256) = true)

theorem identity1256 : scanCanonicalize (H12AffineFastState.compose env1256 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound1256 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,131072,262144,1024,8693,2097152,292,131321,16777216,8328,131241,393313,185,135352,2081,16852469,131397,256,1,131073,16909002]

theorem envBound1257 : H12AffineFastState.Bounded env1257 := by
  intro p hp
  have h : env1257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1256_1257 : H12AffineEnvironment.transform 13 184 env1256 = env1257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env1256 == env1257) = true)

def env1258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,324,262144,1024,8693,2097152,292,445,16777216,8328,493,262437,185,4604,2081,16852469,1,256,1,325,16778126]

theorem envBound1258 : H12AffineFastState.Bounded env1258 := by
  intro p hp
  have h : env1258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1257_1258 : H12AffineEnvironment.transform 16 324 env1257 = env1258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 324 env1257 == env1258) = true)

theorem identity1258 : scanCanonicalize (H12AffineFastState.compose env1258 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 73969) := by decide +kernel

theorem selectedBound1258 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,324,262144,1024,8693,2097152,292,445,73969,8328,493,262437,185,4604,2081,1284,1,256,1,325,74623]

theorem envBound1259 : H12AffineFastState.Bounded env1259 := by
  intro p hp
  have h : env1259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1258_1259 : H12AffineEnvironment.transform 23 73969 env1258 = env1259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73969 env1258 == env1259) = true)

theorem identity1259 : scanCanonicalize (H12AffineFastState.compose env1259 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1259 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,324,2264,1024,8693,2097152,292,445,73969,8328,493,2557,185,4604,2081,1284,1,256,1,325,74623]

theorem envBound1260 : H12AffineFastState.Bounded env1260 := by
  intro p hp
  have h : env1260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1259_1260 : H12AffineEnvironment.transform 17 2264 env1259 = env1260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1259 == env1260) = true)

theorem identity1260 : scanCanonicalize (H12AffineFastState.compose env1260 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1260 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,8315,324,2264,1024,8693,2097152,292,445,138,8328,493,2557,185,4604,2081,1284,1,256,1,325,772]

theorem envBound1261 : H12AffineFastState.Bounded env1261 := by
  intro p hp
  have h : env1261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1260_1261 : H12AffineEnvironment.transform 15 8315 env1260 = env1261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1260 == env1261) = true)

theorem identity1261 : scanCanonicalize (H12AffineFastState.compose env1261 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11690) := by decide +kernel

theorem selectedBound1261 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,8315,324,2264,1024,8693,11690,292,445,138,8328,493,2557,185,4604,2081,1284,1,256,1,325,772]

theorem envBound1262 : H12AffineFastState.Bounded env1262 := by
  intro p hp
  have h : env1262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1261_1262 : H12AffineEnvironment.transform 20 11690 env1261 = env1262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11690 env1261 == env1262) = true)

theorem identity1262 : scanCanonicalize (H12AffineFastState.compose env1262 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3369) := by decide +kernel

theorem selectedBound1262 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3369,184,3292,3410,324,2264,1024,3292,131,292,445,138,3489,493,2557,185,4604,2081,1284,1,256,1,325,772]

theorem envBound1263 : H12AffineFastState.Bounded env1263 := by
  intro p hp
  have h : env1263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1262_1263 : H12AffineEnvironment.transform 12 3369 env1262 = env1263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3369 env1262 == env1263) = true)

theorem identity1263 : scanCanonicalize (H12AffineFastState.compose env1263 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1263 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env1264 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,3116,184,3292,3159,65,2264,1024,3292,131,33,184,138,3236,232,2296,185,4345,2081,1025,1,5,1,64,513]

theorem envBound1264 : H12AffineFastState.Bounded env1264 := by
  intro p hp
  have h : env1264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1263_1264 : H12AffineEnvironment.transform 7 5 env1263 = env1264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1263 == env1264) = true)

theorem identity1264 : scanCanonicalize (H12AffineFastState.compose env1264 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1709) := by decide +kernel

theorem selectedBound1264 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env1265 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1709,4096,641,184,625,762,65,1653,1024,625,131,33,184,138,521,232,1621,185,4345,1676,1025,1,5,1,64,513]

theorem envBound1265 : H12AffineFastState.Bounded env1265 := by
  intro p hp
  have h : env1265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1264_1265 : H12AffineEnvironment.transform 10 1709 env1264 = env1265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1709 env1264 == env1265) = true)

theorem identity1265 : scanCanonicalize (H12AffineFastState.compose env1265 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound1265 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1266 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1709,1676,641,184,625,762,65,1653,1024,625,131,33,184,138,521,232,1621,185,1653,1676,1025,1,5,1,64,513]

theorem envBound1266 : H12AffineFastState.Bounded env1266 := by
  intro p hp
  have h : env1266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1265_1266 : H12AffineEnvironment.transform 11 1676 env1265 = env1266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env1265 == env1266) = true)

theorem identity1266 : scanCanonicalize (H12AffineFastState.compose env1266 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound1266 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1267 : List Nat := [2,4,8,16,32,64,25,5,512,1024,1588,1557,536,33,625,611,65,1653,1024,625,26,33,33,19,521,113,1621,32,1653,1557,1025,1,5,1,64,513]

theorem envBound1267 : H12AffineFastState.Bounded env1267 := by
  intro p hp
  have h : env1267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1266_1267 : H12AffineEnvironment.transform 6 25 env1266 = env1267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env1266 == env1267) = true)

theorem identity1267 : scanCanonicalize (H12AffineFastState.compose env1267 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound1267 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1268 : List Nat := [2,4,8,16,32,64,25,5,512,622,90,123,536,33,625,611,65,27,622,625,26,33,33,19,521,113,59,32,27,123,623,1,5,1,64,513]

theorem envBound1268 : H12AffineFastState.Bounded env1268 := by
  intro p hp
  have h : env1268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1267_1268 : H12AffineEnvironment.transform 9 622 env1267 = env1268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env1267 == env1268) = true)

theorem identity1268 : scanCanonicalize (H12AffineFastState.compose env1268 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound1268 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env1269 : List Nat := [2,4,8,16,32,59,25,5,512,533,33,0,536,33,522,536,58,27,533,522,26,33,33,19,521,10,59,32,27,0,532,1,5,1,59,513]

theorem envBound1269 : H12AffineFastState.Bounded env1269 := by
  intro p hp
  have h : env1269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1268_1269 : H12AffineEnvironment.transform 5 59 env1268 = env1269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env1268 == env1269) = true)

theorem identity1269 : scanCanonicalize (H12AffineFastState.compose env1269 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound1269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1270 : List Nat := [2,4,8,16,32,59,25,5,58,47,33,0,34,33,48,34,58,27,47,48,26,33,33,19,51,10,59,32,27,0,46,1,5,1,59,59]

theorem envBound1270 : H12AffineFastState.Bounded env1270 := by
  intro p hp
  have h : env1270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1269_1270 : H12AffineEnvironment.transform 8 58 env1269 = env1270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env1269 == env1270) = true)

theorem identity1270 : scanCanonicalize (H12AffineFastState.compose env1270 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound1270 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1271 : List Nat := [2,4,8,16,30,5,25,5,4,17,31,0,28,31,14,28,4,27,17,14,26,31,31,19,13,10,5,30,27,0,16,1,5,1,5,5]

theorem envBound1271 : H12AffineFastState.Bounded env1271 := by
  intro p hp
  have h : env1271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1270_1271 : H12AffineEnvironment.transform 4 30 env1270 = env1271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env1270 == env1271) = true)

def env1272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,325,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,185,4605,2081,16852469,0,256,1,324,16778127]

theorem envBound1272 : H12AffineFastState.Bounded env1272 := by
  intro p hp
  have h : env1272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1257_1272 : H12AffineEnvironment.transform 16 325 env1257 = env1272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 325 env1257 == env1272) = true)

theorem identity1272 : scanCanonicalize (H12AffineFastState.compose env1272 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1272 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,8575,325,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,185,4605,2081,16778378,0,256,1,324,16778127]

theorem envBound1273 : H12AffineFastState.Bounded env1273 := by
  intro p hp
  have h : env1273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1272_1273 : H12AffineEnvironment.transform 15 8575 env1272 = env1273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1272 == env1273) = true)

def env1274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,4341976,257,1,34359738368,16925299]

theorem envBound1274 : H12AffineFastState.Bounded env1274 := by
  intro p hp
  have h : env1274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1231_1274 : H12AffineEnvironment.transform 18 1025 env1231 = env1274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1231 == env1274) = true)

def env1275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,4341976,257,1,131072,16925299]

theorem envBound1275 : H12AffineFastState.Bounded env1275 := by
  intro p hp
  have h : env1275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1274_1275 : H12AffineEnvironment.transform 34 131072 env1274 = env1275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1274 == env1275) = true)

theorem identity1275 : scanCanonicalize (H12AffineFastState.compose env1275 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2249949) := by decide +kernel

theorem selectedBound1275 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2249949,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,2102277,257,1,131072,16925299]

theorem envBound1276 : H12AffineFastState.Bounded env1276 := by
  intro p hp
  have h : env1276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1275_1276 : H12AffineEnvironment.transform 21 2249949 env1275 = env1276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2249949 env1275 == env1276) = true)

theorem identity1276 : scanCanonicalize (H12AffineFastState.compose env1276 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 139) := by decide +kernel

theorem selectedBound1276 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2249949,147521,139,8328,147472,409816,16385,151552,2081,75135,2102277,257,1,131072,148216]

theorem envBound1277 : H12AffineFastState.Bounded env1277 := by
  intro p hp
  have h : env1277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1276_1277 : H12AffineEnvironment.transform 23 139 env1276 = env1277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 139 env1276 == env1277) = true)

def env1278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1025,8693,2097152,2102309,185,139,8328,232,262176,16385,4344,2081,75135,2102277,257,1,16632,512]

theorem envBound1278 : H12AffineFastState.Bounded env1278 := by
  intro p hp
  have h : env1278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1277_1278 : H12AffineEnvironment.transform 16 16632 env1277 = env1278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1277 == env1278) = true)

theorem identity1278 : scanCanonicalize (H12AffineFastState.compose env1278 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 5124) := by decide +kernel

theorem selectedBound1278 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1025,8693,5124,33,185,139,8328,232,262176,16385,4344,2081,75135,1,257,1,16632,512]

theorem envBound1279 : H12AffineFastState.Bounded env1279 := by
  intro p hp
  have h : env1279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1278_1279 : H12AffineEnvironment.transform 20 5124 env1278 = env1279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5124 env1278 == env1279) = true)

theorem identity1279 : scanCanonicalize (H12AffineFastState.compose env1279 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1279 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env1280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1025,8693,5124,33,185,139,8328,232,262176,16385,4344,2081,1025,1,257,1,16632,512]

theorem envBound1280 : H12AffineFastState.Bounded env1280 := by
  intro p hp
  have h : env1280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1279_1280 : H12AffineEnvironment.transform 15 8574 env1279 = env1280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1279 == env1280) = true)

def env1281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1025,8693,2097152,2102308,184,139,8328,233,262177,16385,4345,2081,75135,2102277,257,1,16633,513]

theorem envBound1281 : H12AffineFastState.Bounded env1281 := by
  intro p hp
  have h : env1281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1277_1281 : H12AffineEnvironment.transform 16 16633 env1277 = env1281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1277 == env1281) = true)

theorem identity1281 : scanCanonicalize (H12AffineFastState.compose env1281 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1281 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1282 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,8192,16384,8693,65536,16633,262144,85,8693,2097152,2101360,184,139,8328,233,262177,16385,4345,2081,74027,2101329,257,1,16633,513]

theorem envBound1282 : H12AffineFastState.Bounded env1282 := by
  intro p hp
  have h : env1282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1281_1282 : H12AffineEnvironment.transform 9 84 env1281 = env1282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1281 == env1282) = true)

theorem identity1282 : scanCanonicalize (H12AffineFastState.compose env1282 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 4265) := by decide +kernel

theorem selectedBound1282 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env1283 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,8192,16384,8693,65536,16633,262144,85,8693,4265,217,184,139,8328,233,262177,16385,4345,2081,74027,248,257,1,16633,513]

theorem envBound1283 : H12AffineFastState.Bounded env1283 := by
  intro p hp
  have h : env1283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1282_1283 : H12AffineEnvironment.transform 20 4265 env1282 = env1283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4265 env1282 == env1283) = true)

theorem identity1283 : scanCanonicalize (H12AffineFastState.compose env1283 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound1283 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1284 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,8192,16384,8693,8582,16633,262144,85,8693,4265,217,184,139,8328,233,262177,16385,4345,2081,173,248,257,1,16633,513]

theorem envBound1284 : H12AffineFastState.Bounded env1284 := by
  intro p hp
  have h : env1284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1283_1284 : H12AffineEnvironment.transform 15 8582 env1283 = env1284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env1283 == env1284) = true)

theorem identity1284 : scanCanonicalize (H12AffineFastState.compose env1284 (packedSelected [13,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1284 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1285 : List Nat := [2,4,8,16,32,64,41,256,512,84,2048,4096,8192,16384,8540,8495,16464,262144,85,8540,4096,112,17,34,8225,64,262177,16385,4176,2081,4,81,257,1,16464,513]

theorem envBound1285 : H12AffineFastState.Bounded env1285 := by
  intro p hp
  have h : env1285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1284_1285 : H12AffineEnvironment.transform 6 41 env1284 = env1285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1284 == env1285) = true)

theorem identity1285 : scanCanonicalize (H12AffineFastState.compose env1285 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 22641) := by decide +kernel

theorem selectedBound1285 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env1286 : List Nat := [2,4,8,16,32,64,41,256,512,84,2048,4096,8192,16384,8540,8495,16464,22641,85,8540,4096,112,17,34,8225,64,22608,16385,4176,2081,4,81,257,1,16464,513]

theorem envBound1286 : H12AffineFastState.Bounded env1286 := by
  intro p hp
  have h : env1286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1285_1286 : H12AffineEnvironment.transform 17 22641 env1285 = env1286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22641 env1285 == env1286) = true)

theorem identity1286 : scanCanonicalize (H12AffineFastState.compose env1286 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2422) := by decide +kernel

theorem selectedBound1286 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env1287 : List Nat := [2,4,8,16,32,64,41,256,512,84,2048,4096,2422,16384,2090,2137,16464,22641,85,2090,4096,112,17,34,2391,64,22608,16385,4176,2081,4,81,257,1,16464,513]

theorem envBound1287 : H12AffineFastState.Bounded env1287 := by
  intro p hp
  have h : env1287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1286_1287 : H12AffineEnvironment.transform 12 2422 env1286 = env1287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2422 env1286 == env1287) = true)

theorem identity1287 : scanCanonicalize (H12AffineFastState.compose env1287 (packedSelected [1,2,3,5,6,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound1287 : packedSelected [1,2,3,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env1288 : List Nat := [2,4,8,16,32,64,41,256,512,84,2048,4096,2422,6161,2090,2137,6209,96,85,2090,4096,112,17,34,2391,64,65,6160,4176,2081,4,81,257,1,6209,513]

theorem envBound1288 : H12AffineFastState.Bounded env1288 := by
  intro p hp
  have h : env1288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1287_1288 : H12AffineEnvironment.transform 13 6161 env1287 = env1288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env1287 == env1288) = true)

theorem identity1288 : scanCanonicalize (H12AffineFastState.compose env1288 (packedSelected [2,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound1288 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env1289 : List Nat := [2,4,8,16,32,0,41,256,512,20,2048,4096,2358,6161,2090,2073,6145,32,21,2090,4096,48,17,34,2327,0,1,6160,4112,2081,4,17,257,1,6145,513]

theorem envBound1289 : H12AffineFastState.Bounded env1289 := by
  intro p hp
  have h : env1289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1288_1289 : H12AffineEnvironment.transform 5 0 env1288 = env1289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1288 == env1289) = true)

theorem identity1289 : scanCanonicalize (H12AffineFastState.compose env1289 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound1289 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env1290 : List Nat := [2,4,8,16,32,0,41,256,512,20,16,4096,294,4097,58,9,4113,32,21,58,4096,48,17,34,263,0,1,4096,4112,49,4,17,257,1,4113,513]

theorem envBound1290 : H12AffineFastState.Bounded env1290 := by
  intro p hp
  have h : env1290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1289_1290 : H12AffineEnvironment.transform 10 16 env1289 = env1290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env1289 == env1290) = true)

theorem identity1290 : scanCanonicalize (H12AffineFastState.compose env1290 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound1290 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env1291 : List Nat := [2,4,8,16,32,0,41,256,512,20,16,260,294,261,58,9,277,32,21,58,260,48,17,34,263,0,1,260,276,49,4,17,257,1,277,513]

theorem envBound1291 : H12AffineFastState.Bounded env1291 := by
  intro p hp
  have h : env1291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1290_1291 : H12AffineEnvironment.transform 11 260 env1290 = env1291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env1290 == env1291) = true)

theorem identity1291 : scanCanonicalize (H12AffineFastState.compose env1291 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound1291 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env1292 : List Nat := [2,4,8,16,32,0,41,63,512,20,16,59,25,58,58,9,42,32,21,58,59,48,17,34,56,0,1,59,43,49,4,17,62,1,42,513]

theorem envBound1292 : H12AffineFastState.Bounded env1292 := by
  intro p hp
  have h : env1292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1291_1292 : H12AffineEnvironment.transform 7 63 env1291 = env1292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env1291 == env1292) = true)

theorem identity1292 : scanCanonicalize (H12AffineFastState.compose env1292 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound1292 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1293 : List Nat := [2,4,8,16,32,0,41,63,49,20,16,59,25,58,58,9,42,32,21,58,59,48,17,34,56,0,1,59,43,49,4,17,62,1,42,48]

theorem envBound1293 : H12AffineFastState.Bounded env1293 := by
  intro p hp
  have h : env1293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1292_1293 : H12AffineEnvironment.transform 8 49 env1292 = env1293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env1292 == env1293) = true)

theorem identity1293 : scanCanonicalize (H12AffineFastState.compose env1293 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound1293 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env1294 : List Nat := [2,4,8,16,24,0,17,7,9,20,16,3,25,2,2,9,18,24,21,2,3,8,17,26,0,0,1,3,19,9,4,17,6,1,18,8]

theorem envBound1294 : H12AffineFastState.Bounded env1294 := by
  intro p hp
  have h : env1294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1293_1294 : H12AffineEnvironment.transform 4 24 env1293 = env1294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env1293 == env1294) = true)

theorem identity1294 : scanCanonicalize (H12AffineFastState.compose env1294 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1294 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1295 : List Nat := [2,4,3,16,19,0,17,7,2,20,16,3,18,2,2,2,18,19,21,2,3,3,17,17,0,0,1,3,19,2,4,17,6,1,18,3]

theorem envBound1295 : H12AffineFastState.Bounded env1295 := by
  intro p hp
  have h : env1295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1294_1295 : H12AffineEnvironment.transform 2 3 env1294 = env1295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1294 == env1295) = true)

theorem identity1295 : scanCanonicalize (H12AffineFastState.compose env1295 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound1295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1296 : List Nat := [2,4,3,7,4,0,6,7,2,3,7,3,5,2,2,2,5,4,2,2,3,3,6,6,0,0,1,3,4,2,4,6,6,1,5,3]

theorem envBound1296 : H12AffineFastState.Bounded env1296 := by
  intro p hp
  have h : env1296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1295_1296 : H12AffineEnvironment.transform 3 7 env1295 = env1296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env1295 == env1296) = true)

theorem identity1296 : scanCanonicalize (H12AffineFastState.compose env1296 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound1296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1297 : List Nat := [2,1,3,2,1,0,3,2,2,3,2,3,0,2,2,2,0,1,2,2,3,3,3,3,0,0,1,3,1,2,1,3,3,1,0,3]

theorem envBound1297 : H12AffineFastState.Bounded env1297 := by
  intro p hp
  have h : env1297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1296_1297 : H12AffineEnvironment.transform 1 1 env1296 = env1297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env1296 == env1297) = true)

def env1298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,4341976,257,1,131073,16925299]

theorem envBound1298 : H12AffineFastState.Bounded env1298 := by
  intro p hp
  have h : env1298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1274_1298 : H12AffineEnvironment.transform 34 131073 env1274 = env1298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1274 == env1298) = true)

theorem identity1298 : scanCanonicalize (H12AffineFastState.compose env1298 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 148700) := by decide +kernel

theorem selectedBound1298 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,148700,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,1028,257,1,131073,16925299]

theorem envBound1299 : H12AffineFastState.Bounded env1299 := by
  intro p hp
  have h : env1299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1298_1299 : H12AffineEnvironment.transform 21 148700 env1298 = env1299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 148700 env1298 == env1299) = true)

theorem identity1299 : scanCanonicalize (H12AffineFastState.compose env1299 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 222473) := by decide +kernel

theorem selectedBound1299 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,148700,147521,222473,8328,147472,409816,16385,151552,2081,147709,1028,257,1,131073,75642]

theorem envBound1300 : H12AffineFastState.Bounded env1300 := by
  intro p hp
  have h : env1300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1299_1300 : H12AffineEnvironment.transform 23 222473 env1299 = env1300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 222473 env1299 == env1300) = true)

theorem identity1300 : scanCanonicalize (H12AffineFastState.compose env1300 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 9594) := by decide +kernel

theorem selectedBound1300 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9594,131072,262144,1025,8693,2097152,148700,147521,147571,8328,147472,409816,16385,151552,2081,147709,1028,257,1,131073,512]

theorem envBound1301 : H12AffineFastState.Bounded env1301 := by
  intro p hp
  have h : env1301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1300_1301 : H12AffineEnvironment.transform 15 9594 env1300 = env1301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9594 env1300 == env1301) = true)

theorem identity1301 : scanCanonicalize (H12AffineFastState.compose env1301 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 17661) := by decide +kernel

theorem selectedBound1301 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9594,17661,262144,1025,8693,2097152,33,1212,1166,8328,1261,263205,16385,5373,2081,1024,1028,257,1,17660,512]

theorem envBound1302 : H12AffineFastState.Bounded env1302 := by
  intro p hp
  have h : env1302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1301_1302 : H12AffineEnvironment.transform 16 17661 env1301 = env1302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17661 env1301 == env1302) = true)

theorem identity1302 : scanCanonicalize (H12AffineFastState.compose env1302 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1302 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1303 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16633,262144,5,8693,2097152,33,184,138,8328,233,262177,16385,4345,2081,4,0,257,1,16632,512]

theorem envBound1303 : H12AffineFastState.Bounded env1303 := by
  intro p hp
  have h : env1303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1302_1303 : H12AffineEnvironment.transform 9 4 env1302 = env1303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1302 == env1303) = true)

theorem identity1303 : scanCanonicalize (H12AffineFastState.compose env1303 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound1303 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1304 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16633,2081,5,8693,2097152,33,184,138,8328,233,2048,16385,4345,2081,4,0,257,1,16632,512]

theorem envBound1304 : H12AffineFastState.Bounded env1304 := by
  intro p hp
  have h : env1304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1303_1304 : H12AffineEnvironment.transform 17 2081 env1303 = env1304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env1303 == env1304) = true)

theorem identity1304 : scanCanonicalize (H12AffineFastState.compose env1304 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1304 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1305 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16633,2081,5,8201,2097152,33,184,138,8328,233,2048,16385,4345,2081,4,0,253,1,16632,512]

theorem envBound1305 : H12AffineFastState.Bounded env1305 := by
  intro p hp
  have h : env1305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1304_1305 : H12AffineEnvironment.transform 7 252 env1304 = env1305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1304 == env1305) = true)

theorem identity1305 : scanCanonicalize (H12AffineFastState.compose env1305 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26827) := by decide +kernel

theorem selectedBound1305 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1306 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16633,2081,5,8201,26827,33,184,138,8328,233,2048,16385,4345,2081,4,0,253,1,16632,512]

theorem envBound1306 : H12AffineFastState.Bounded env1306 := by
  intro p hp
  have h : env1306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1305_1306 : H12AffineEnvironment.transform 20 26827 env1305 = env1306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26827 env1305 == env1306) = true)

theorem identity1306 : scanCanonicalize (H12AffineFastState.compose env1306 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound1306 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1307 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12496,8201,8322,12329,2081,5,8201,6171,33,184,138,8328,233,2048,12497,4345,2081,4,0,253,1,12328,512]

theorem envBound1307 : H12AffineFastState.Bounded env1307 := by
  intro p hp
  have h : env1307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1306_1307 : H12AffineEnvironment.transform 13 12496 env1306 = env1307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env1306 == env1307) = true)

theorem identity1307 : scanCanonicalize (H12AffineFastState.compose env1307 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound1307 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1308 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2282,6202,2275,2152,6339,2081,5,2275,6171,33,184,138,2146,233,2048,6203,4345,2081,4,0,253,1,6338,512]

theorem envBound1308 : H12AffineFastState.Bounded env1308 := by
  intro p hp
  have h : env1308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1307_1308 : H12AffineEnvironment.transform 12 2282 env1307 = env1308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env1307 == env1308) = true)

theorem identity1308 : scanCanonicalize (H12AffineFastState.compose env1308 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound1308 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1309 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2216,2282,146,2275,2152,107,2081,5,2275,179,33,184,138,2146,233,2048,147,2129,2081,4,0,253,1,106,512]

theorem envBound1309 : H12AffineFastState.Bounded env1309 := by
  intro p hp
  have h : env1309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1308_1309 : H12AffineEnvironment.transform 11 2216 env1308 = env1309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env1308 == env1309) = true)

theorem identity1309 : scanCanonicalize (H12AffineFastState.compose env1309 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound1309 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1310 : List Nat := [2,4,8,16,32,64,128,252,512,4,59,147,209,146,216,83,107,26,5,216,179,33,184,138,89,233,59,147,106,26,4,0,253,1,106,512]

theorem envBound1310 : H12AffineFastState.Bounded env1310 := by
  intro p hp
  have h : env1310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1309_1310 : H12AffineEnvironment.transform 10 59 env1309 = env1310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env1309 == env1310) = true)

theorem identity1310 : scanCanonicalize (H12AffineFastState.compose env1310 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound1310 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1311 : List Nat := [2,4,8,16,32,43,128,151,512,4,59,147,186,146,179,56,0,26,5,179,179,33,184,138,50,130,59,147,1,26,4,0,150,1,1,512]

theorem envBound1311 : H12AffineFastState.Bounded env1311 := by
  intro p hp
  have h : env1311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1310_1311 : H12AffineEnvironment.transform 5 43 env1310 = env1311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env1310 == env1311) = true)

theorem identity1311 : scanCanonicalize (H12AffineFastState.compose env1311 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound1311 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1312 : List Nat := [2,4,8,16,32,43,18,5,512,4,59,1,40,0,33,56,0,26,5,33,33,33,42,24,50,16,59,1,1,26,4,0,4,1,1,512]

theorem envBound1312 : H12AffineFastState.Bounded env1312 := by
  intro p hp
  have h : env1312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1311_1312 : H12AffineEnvironment.transform 6 18 env1311 = env1312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env1311 == env1312) = true)

theorem identity1312 : scanCanonicalize (H12AffineFastState.compose env1312 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound1312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1313 : List Nat := [2,4,8,16,10,1,18,5,512,4,17,1,2,0,11,18,0,26,5,11,11,11,0,24,24,16,17,1,1,26,4,0,4,1,1,512]

theorem envBound1313 : H12AffineFastState.Bounded env1313 := by
  intro p hp
  have h : env1313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1312_1313 : H12AffineEnvironment.transform 4 10 env1312 = env1313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env1312 == env1313) = true)

theorem identity1313 : scanCanonicalize (H12AffineFastState.compose env1313 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound1313 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1314 : List Nat := [2,4,8,11,10,1,9,5,512,4,10,1,2,0,11,9,0,1,5,11,11,11,0,3,3,11,10,1,1,1,4,0,4,1,1,512]

theorem envBound1314 : H12AffineFastState.Bounded env1314 := by
  intro p hp
  have h : env1314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1313_1314 : H12AffineEnvironment.transform 3 11 env1313 = env1314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env1313 == env1314) = true)

theorem identity1314 : scanCanonicalize (H12AffineFastState.compose env1314 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1314 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1315 : List Nat := [2,4,3,0,1,1,2,5,512,4,1,1,2,0,0,2,0,1,5,0,0,0,0,3,3,0,1,1,1,1,4,0,4,1,1,512]

theorem envBound1315 : H12AffineFastState.Bounded env1315 := by
  intro p hp
  have h : env1315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1314_1315 : H12AffineEnvironment.transform 2 3 env1314 = env1315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1314 == env1315) = true)

theorem identity1315 : scanCanonicalize (H12AffineFastState.compose env1315 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1316 : List Nat := [2,4,3,0,1,1,2,5,7,4,1,1,2,0,0,2,0,1,5,0,0,0,0,3,3,0,1,1,1,1,4,0,4,1,1,7]

theorem envBound1316 : H12AffineFastState.Bounded env1316 := by
  intro p hp
  have h : env1316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1315_1316 : H12AffineEnvironment.transform 8 7 env1315 = env1316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1315 == env1316) = true)

def env1317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,268435456,268570625,268453920,17399809,281601388,525568,268451840,34359738368,25733062]

theorem envBound1317 : H12AffineFastState.Bounded env1317 := by
  intro p hp
  have h : env1317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans781_1317 : H12AffineEnvironment.transform 25 8914001 env781 = env1317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env781 == env1317) = true)

def env1318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17399809,13149548,525568,0,34359738368,25733062]

theorem envBound1318 : H12AffineFastState.Bounded env1318 := by
  intro p hp
  have h : env1318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1317_1318 : H12AffineEnvironment.transform 27 16384 env1317 = env1318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env1317 == env1318) = true)

def env1319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17375733,13108376,525568,0,34359738368,25691698]

theorem envBound1319 : H12AffineFastState.Bounded env1319 := by
  intro p hp
  have h : env1319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1318_1319 : H12AffineEnvironment.transform 14 8692 env1318 = env1319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1318 == env1319) = true)

def env1320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147520,16777216,8328,672785,935128,16384,151553,2080,17375733,4867288,525568,0,34359738368,17450610]

theorem envBound1320 : H12AffineFastState.Bounded env1320 := by
  intro p hp
  have h : env1320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1319_1320 : H12AffineEnvironment.transform 22 147520 env1319 = env1320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1319 == env1320) = true)

def env1321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,34359738368,16925298]

theorem envBound1321 : H12AffineFastState.Bounded env1321 := by
  intro p hp
  have h : env1321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1320_1321 : H12AffineEnvironment.transform 18 1024 env1320 = env1321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1320 == env1321) = true)

def env1322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131072,16925298]

theorem envBound1322 : H12AffineFastState.Bounded env1322 := by
  intro p hp
  have h : env1322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1321_1322 : H12AffineEnvironment.transform 34 131072 env1321 = env1322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1321 == env1322) = true)

theorem identity1322 : scanCanonicalize (H12AffineFastState.compose env1322 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound1322 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1323 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,131072,262144,257,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16851188,4341976,256,0,131072,16925298]

theorem envBound1323 : H12AffineFastState.Bounded env1323 := by
  intro p hp
  have h : env1323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1322_1323 : H12AffineEnvironment.transform 9 257 env1322 = env1323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env1322 == env1323) = true)

theorem identity1323 : scanCanonicalize (H12AffineFastState.compose env1323 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268501) := by decide +kernel

theorem selectedBound1323 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1324 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,131072,262144,257,8692,2097152,4194304,147520,4268501,8328,147473,409816,16384,151553,2080,4194593,4341976,256,0,131072,4416423]

theorem envBound1324 : H12AffineFastState.Bounded env1324 := by
  intro p hp
  have h : env1324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1323_1324 : H12AffineEnvironment.transform 23 4268501 env1323 = env1324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4268501 env1323 == env1324) = true)

theorem identity1324 : scanCanonicalize (H12AffineFastState.compose env1324 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 221607) := by decide +kernel

theorem selectedBound1324 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1325 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,131072,262144,257,8692,2097152,221607,147520,147570,8328,147473,409816,16384,151553,2080,221318,74111,256,0,131072,512]

theorem envBound1325 : H12AffineFastState.Bounded env1325 := by
  intro p hp
  have h : env1325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1324_1325 : H12AffineEnvironment.transform 21 221607 env1324 = env1325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 221607 env1324 == env1325) = true)

theorem identity1325 : scanCanonicalize (H12AffineFastState.compose env1325 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound1325 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1326 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,90502,262144,257,8692,2097152,33,74182,74228,8328,74135,336222,16384,78215,2080,256,74111,256,0,90502,512]

theorem envBound1326 : H12AffineFastState.Bounded env1326 := by
  intro p hp
  have h : env1326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1325_1326 : H12AffineEnvironment.transform 16 90502 env1325 = env1326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env1325 == env1326) = true)

theorem identity1326 : scanCanonicalize (H12AffineFastState.compose env1326 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1326 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1327 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,8574,16632,262144,257,8692,2097152,33,184,138,8328,233,262176,16384,4345,2080,256,1,256,0,16632,512]

theorem envBound1327 : H12AffineFastState.Bounded env1327 := by
  intro p hp
  have h : env1327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1326_1327 : H12AffineEnvironment.transform 15 8574 env1326 = env1327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1326 == env1327) = true)

theorem identity1327 : scanCanonicalize (H12AffineFastState.compose env1327 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound1327 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1328 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,8574,16632,2080,257,8692,2097152,33,184,138,8328,233,2048,16384,4345,2080,256,1,256,0,16632,512]

theorem envBound1328 : H12AffineFastState.Bounded env1328 := by
  intro p hp
  have h : env1328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1327_1328 : H12AffineEnvironment.transform 17 2080 env1327 = env1328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env1327 == env1328) = true)

theorem identity1328 : scanCanonicalize (H12AffineFastState.compose env1328 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1328 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1329 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8200,8322,16632,2080,253,8200,2097152,33,184,138,8328,233,2048,16384,4345,2080,252,1,252,0,16632,512]

theorem envBound1329 : H12AffineFastState.Bounded env1329 := by
  intro p hp
  have h : env1329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1328_1329 : H12AffineEnvironment.transform 7 252 env1328 = env1329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1328 == env1329) = true)

theorem identity1329 : scanCanonicalize (H12AffineFastState.compose env1329 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound1329 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1330 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8200,8322,16632,2080,253,8200,26674,33,184,138,8328,233,2048,16384,4345,2080,252,1,252,0,16632,512]

theorem envBound1330 : H12AffineFastState.Bounded env1330 := by
  intro p hp
  have h : env1330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1329_1330 : H12AffineEnvironment.transform 20 26674 env1329 = env1330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env1329 == env1330) = true)

theorem identity1330 : scanCanonicalize (H12AffineFastState.compose env1330 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound1330 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1331 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,12496,8200,8322,12328,2080,253,8200,6370,33,184,138,8328,233,2048,12496,4345,2080,252,1,252,0,12328,512]

theorem envBound1331 : H12AffineFastState.Bounded env1331 := by
  intro p hp
  have h : env1331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1330_1331 : H12AffineEnvironment.transform 13 12496 env1330 = env1331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env1330 == env1331) = true)

theorem identity1331 : scanCanonicalize (H12AffineFastState.compose env1331 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound1331 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1332 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,2282,6202,2274,2152,6338,2080,253,2274,6370,33,184,138,2146,233,2048,6202,4345,2080,252,1,252,0,6338,512]

theorem envBound1332 : H12AffineFastState.Bounded env1332 := by
  intro p hp
  have h : env1332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1331_1332 : H12AffineEnvironment.transform 12 2282 env1331 = env1332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env1331 == env1332) = true)

theorem identity1332 : scanCanonicalize (H12AffineFastState.compose env1332 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound1332 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1333 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,2128,2282,106,2274,2152,146,2080,253,2274,178,33,184,138,2146,233,2048,106,2217,2080,252,1,252,0,146,512]

theorem envBound1333 : H12AffineFastState.Bounded env1333 := by
  intro p hp
  have h : env1333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1332_1333 : H12AffineEnvironment.transform 11 2128 env1332 = env1333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env1332 == env1333) = true)

theorem identity1333 : scanCanonicalize (H12AffineFastState.compose env1333 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound1333 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1334 : List Nat := [2,4,8,16,32,64,128,252,512,253,194,146,40,106,32,170,146,226,253,32,178,33,184,138,160,233,194,106,107,226,252,1,252,0,146,512]

theorem envBound1334 : H12AffineFastState.Bounded env1334 := by
  intro p hp
  have h : env1334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1333_1334 : H12AffineEnvironment.transform 10 194 env1333 = env1334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env1333 == env1334) = true)

theorem identity1334 : scanCanonicalize (H12AffineFastState.compose env1334 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound1334 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1335 : List Nat := [2,4,8,16,32,64,19,111,512,110,81,1,40,106,32,57,1,113,110,32,33,33,43,25,51,122,81,106,107,113,111,1,111,0,1,512]

theorem envBound1335 : H12AffineFastState.Bounded env1335 := by
  intro p hp
  have h : env1335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1334_1335 : H12AffineEnvironment.transform 6 19 env1334 = env1335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env1334 == env1335) = true)

theorem identity1335 : scanCanonicalize (H12AffineFastState.compose env1335 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound1335 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1336 : List Nat := [2,4,8,16,32,43,19,4,512,5,58,1,40,1,32,57,1,26,5,32,33,33,43,25,51,17,58,1,0,26,4,1,4,0,1,512]

theorem envBound1336 : H12AffineFastState.Bounded env1336 := by
  intro p hp
  have h : env1336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1335_1336 : H12AffineEnvironment.transform 5 43 env1335 = env1336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env1335 == env1336) = true)

theorem identity1336 : scanCanonicalize (H12AffineFastState.compose env1336 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1337 : List Nat := [2,4,8,16,1,10,19,4,512,5,27,1,9,1,1,24,1,26,5,1,0,0,10,25,18,17,27,1,0,26,4,1,4,0,1,512]

theorem envBound1337 : H12AffineFastState.Bounded env1337 := by
  intro p hp
  have h : env1337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1336_1337 : H12AffineEnvironment.transform 4 1 env1336 = env1337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1336 == env1337) = true)

theorem identity1337 : scanCanonicalize (H12AffineFastState.compose env1337 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1338 : List Nat := [2,4,5,16,1,7,19,4,512,5,22,1,4,1,1,21,1,23,5,1,0,0,7,20,18,17,22,1,0,23,4,1,4,0,1,512]

theorem envBound1338 : H12AffineFastState.Bounded env1338 := by
  intro p hp
  have h : env1338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1337_1338 : H12AffineEnvironment.transform 2 5 env1337 = env1338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1337 == env1338) = true)

theorem identity1338 : scanCanonicalize (H12AffineFastState.compose env1338 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound1338 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env1339 : List Nat := [2,4,5,0,1,7,3,4,512,5,6,1,4,1,1,5,1,7,5,1,0,0,7,4,2,1,6,1,0,7,4,1,4,0,1,512]

theorem envBound1339 : H12AffineFastState.Bounded env1339 := by
  intro p hp
  have h : env1339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1338_1339 : H12AffineEnvironment.transform 3 0 env1338 = env1339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env1338 == env1339) = true)

theorem identity1339 : scanCanonicalize (H12AffineFastState.compose env1339 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1339 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1340 : List Nat := [2,3,2,0,1,0,3,3,512,2,1,1,3,1,1,2,1,0,2,1,0,0,0,3,2,1,1,1,0,0,3,1,3,0,1,512]

theorem envBound1340 : H12AffineFastState.Bounded env1340 := by
  intro p hp
  have h : env1340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1339_1340 : H12AffineEnvironment.transform 1 3 env1339 = env1340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1339 == env1340) = true)

def env1341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound1341 : H12AffineFastState.Bounded env1341 := by
  intro p hp
  have h : env1341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1321_1341 : H12AffineEnvironment.transform 34 131073 env1321 = env1341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1321 == env1341) = true)

theorem identity1341 : scanCanonicalize (H12AffineFastState.compose env1341 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 5377) := by decide +kernel

theorem selectedBound1341 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,5377,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound1342 : H12AffineFastState.Bounded env1342 := by
  intro p hp
  have h : env1342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1341_1342 : H12AffineEnvironment.transform 20 5377 env1341 = env1342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5377 env1341 == env1342) = true)

theorem identity1342 : scanCanonicalize (H12AffineFastState.compose env1342 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 139) := by decide +kernel

theorem selectedBound1342 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,5377,4194304,147520,139,8328,147473,409816,16384,151553,2080,75134,4341976,256,0,131073,148217]

theorem envBound1343 : H12AffineFastState.Bounded env1343 := by
  intro p hp
  have h : env1343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1342_1343 : H12AffineEnvironment.transform 23 139 env1342 = env1343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 139 env1342 == env1343) = true)

def env1344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,5377,32,147520,139,8328,147473,409816,16384,151553,2080,75134,147704,256,0,131073,148217]

theorem envBound1344 : H12AffineFastState.Bounded env1344 := by
  intro p hp
  have h : env1344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1343_1344 : H12AffineEnvironment.transform 21 32 env1343 = env1344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env1343 == env1344) = true)

theorem identity1344 : scanCanonicalize (H12AffineFastState.compose env1344 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90503) := by decide +kernel

theorem selectedBound1344 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,90503,262144,1024,8692,5377,32,74183,139,8328,74134,336223,16384,78214,2080,75134,74111,256,0,90502,74622]

theorem envBound1345 : H12AffineFastState.Bounded env1345 := by
  intro p hp
  have h : env1345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1344_1345 : H12AffineEnvironment.transform 16 90503 env1344 = env1345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90503 env1344 == env1345) = true)

theorem identity1345 : scanCanonicalize (H12AffineFastState.compose env1345 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound1345 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env1346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8663,16464,262144,1024,8692,5377,32,16,139,8328,65,262280,16384,4177,2080,1193,168,256,0,16465,681]

theorem envBound1346 : H12AffineFastState.Bounded env1346 := by
  intro p hp
  have h : env1346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1345_1346 : H12AffineEnvironment.transform 15 8663 env1345 = env1346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env1345 == env1346) = true)

theorem identity1346 : scanCanonicalize (H12AffineFastState.compose env1346 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12465) := by decide +kernel

theorem selectedBound1346 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env1347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12465,8692,8663,12513,262144,1024,8692,5377,32,16,139,8328,65,262280,12465,4177,2080,1193,168,256,0,12512,681]

theorem envBound1347 : H12AffineFastState.Bounded env1347 := by
  intro p hp
  have h : env1347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1346_1347 : H12AffineEnvironment.transform 13 12465 env1346 = env1347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12465 env1346 == env1347) = true)

theorem identity1347 : scanCanonicalize (H12AffineFastState.compose env1347 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1347 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1348 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,12312,8541,8574,12360,262144,1024,8541,5377,32,16,34,8225,65,262177,12312,4177,2080,1024,1,256,0,12361,512]

theorem envBound1348 : H12AffineFastState.Bounded env1348 := by
  intro p hp
  have h : env1348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1347_1348 : H12AffineEnvironment.transform 6 41 env1347 = env1348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1347 == env1348) = true)

theorem identity1348 : scanCanonicalize (H12AffineFastState.compose env1348 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound1348 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1349 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,12312,8460,8495,12313,262144,1024,8460,5377,32,16,34,8225,16,262177,12312,4096,2080,1024,1,256,0,12312,512]

theorem envBound1349 : H12AffineFastState.Bounded env1349 := by
  intro p hp
  have h : env1349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1348_1349 : H12AffineEnvironment.transform 5 17 env1348 = env1349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env1348 == env1349) = true)

theorem identity1349 : scanCanonicalize (H12AffineFastState.compose env1349 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8983) := by decide +kernel

theorem selectedBound1349 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1350 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,12312,8460,8495,12313,8983,1024,8460,5377,32,16,34,8225,16,9014,12312,4096,2080,1024,1,256,0,12312,512]

theorem envBound1350 : H12AffineFastState.Bounded env1350 := by
  intro p hp
  have h : env1350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1349_1350 : H12AffineEnvironment.transform 17 8983 env1349 = env1350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8983 env1349 == env1350) = true)

theorem identity1350 : scanCanonicalize (H12AffineFastState.compose env1350 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2870) := by decide +kernel

theorem selectedBound1350 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env1351 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,2870,6958,2618,2585,6959,2081,1024,2618,5377,32,16,34,2839,16,2048,6958,4096,2080,1024,1,256,0,6958,512]

theorem envBound1351 : H12AffineFastState.Bounded env1351 := by
  intro p hp
  have h : env1351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1350_1351 : H12AffineEnvironment.transform 12 2870 env1350 = env1351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2870 env1350 == env1351) = true)

theorem identity1351 : scanCanonicalize (H12AffineFastState.compose env1351 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound1351 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env1352 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1086,4096,1800,5904,1540,1575,5905,1055,1024,1540,5377,32,16,34,1833,16,1086,5904,4096,1054,1024,1,256,0,5904,512]

theorem envBound1352 : H12AffineFastState.Bounded env1352 := by
  intro p hp
  have h : env1352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1351_1352 : H12AffineEnvironment.transform 10 1086 env1351 = env1352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env1351 == env1352) = true)

theorem identity1352 : scanCanonicalize (H12AffineFastState.compose env1352 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1055) := by decide +kernel

theorem selectedBound1352 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env1353 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1086,1055,1800,783,1540,1575,782,1055,1024,1540,286,32,16,34,1833,16,1086,783,1055,1054,1024,1,256,0,783,512]

theorem envBound1353 : H12AffineFastState.Bounded env1353 := by
  intro p hp
  have h : env1353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1352_1353 : H12AffineEnvironment.transform 11 1055 env1352 = env1353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1055 env1352 == env1353) = true)

theorem identity1353 : scanCanonicalize (H12AffineFastState.compose env1353 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound1353 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env1354 : List Nat := [2,4,8,16,32,17,41,256,512,816,782,815,56,783,308,279,782,815,816,308,286,32,16,34,25,16,782,783,815,814,816,1,256,0,783,512]

theorem envBound1354 : H12AffineFastState.Bounded env1354 := by
  intro p hp
  have h : env1354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1353_1354 : H12AffineEnvironment.transform 9 816 env1353 = env1354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env1353 == env1354) = true)

theorem identity1354 : scanCanonicalize (H12AffineFastState.compose env1354 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound1354 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1355 : List Nat := [2,4,8,16,32,17,41,256,270,62,0,33,56,1,308,279,0,33,62,308,286,32,16,34,25,16,0,1,33,32,62,1,256,0,1,270]

theorem envBound1355 : H12AffineFastState.Bounded env1355 := by
  intro p hp
  have h : env1355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1354_1355 : H12AffineEnvironment.transform 8 270 env1354 = env1355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env1354 == env1355) = true)

theorem identity1355 : scanCanonicalize (H12AffineFastState.compose env1355 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1355 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env1356 : List Nat := [2,4,8,16,32,17,41,4,10,62,0,33,56,1,48,19,0,33,62,48,26,32,16,34,25,16,0,1,33,32,62,1,4,0,1,10]

theorem envBound1356 : H12AffineFastState.Bounded env1356 := by
  intro p hp
  have h : env1356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1355_1356 : H12AffineEnvironment.transform 7 4 env1355 = env1356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1355 == env1356) = true)

theorem identity1356 : scanCanonicalize (H12AffineFastState.compose env1356 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound1356 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1357 : List Nat := [2,4,8,16,17,17,24,4,10,15,0,16,9,1,1,19,0,16,15,1,26,17,16,19,25,16,0,1,16,17,15,1,4,0,1,10]

theorem envBound1357 : H12AffineFastState.Bounded env1357 := by
  intro p hp
  have h : env1357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1356_1357 : H12AffineEnvironment.transform 4 17 env1356 = env1357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1356 == env1357) = true)

theorem identity1357 : scanCanonicalize (H12AffineFastState.compose env1357 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1358 : List Nat := [2,4,4,16,17,17,20,4,6,3,0,16,5,1,1,19,0,16,3,1,22,17,16,19,21,16,0,1,16,17,3,1,4,0,1,6]

theorem envBound1358 : H12AffineFastState.Bounded env1358 := by
  intro p hp
  have h : env1358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1357_1358 : H12AffineEnvironment.transform 2 4 env1357 = env1358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1357 == env1358) = true)

def env1359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,5377,33,147520,139,8328,147473,409816,16384,151553,2080,75134,147705,256,0,131073,148217]

theorem envBound1359 : H12AffineFastState.Bounded env1359 := by
  intro p hp
  have h : env1359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1343_1359 : H12AffineEnvironment.transform 21 33 env1343 = env1359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env1343 == env1359) = true)

theorem identity1359 : scanCanonicalize (H12AffineFastState.compose env1359 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1359 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1024,8692,5377,33,147520,139,8328,147473,409816,16384,151553,2080,1024,147705,256,0,131073,148217]

theorem envBound1360 : H12AffineFastState.Bounded env1360 := by
  intro p hp
  have h : env1360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1359_1360 : H12AffineEnvironment.transform 15 8574 env1359 = env1360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1359 == env1360) = true)

theorem identity1360 : scanCanonicalize (H12AffineFastState.compose env1360 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1360 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1024,8692,5377,33,185,139,8328,232,262177,16384,4344,2080,1024,0,256,0,16632,512]

theorem envBound1361 : H12AffineFastState.Bounded env1361 := by
  intro p hp
  have h : env1361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1360_1361 : H12AffineEnvironment.transform 16 16633 env1360 = env1361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1360 == env1361) = true)

def env1362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,34359738368,16925299]

theorem envBound1362 : H12AffineFastState.Bounded env1362 := by
  intro p hp
  have h : env1362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1320_1362 : H12AffineEnvironment.transform 18 1025 env1320 = env1362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1320 == env1362) = true)

def env1363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,131072,16925299]

theorem envBound1363 : H12AffineFastState.Bounded env1363 := by
  intro p hp
  have h : env1363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1362_1363 : H12AffineEnvironment.transform 34 131072 env1362 = env1363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1362 == env1363) = true)

theorem identity1363 : scanCanonicalize (H12AffineFastState.compose env1363 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 64) := by decide +kernel

theorem selectedBound1363 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,64,262144,1025,8692,2097152,4194304,16384,16777216,8328,16464,278681,16384,20545,2080,16852468,4210841,257,0,64,16794163]

theorem envBound1364 : H12AffineFastState.Bounded env1364 := by
  intro p hp
  have h : env1364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1363_1364 : H12AffineEnvironment.transform 16 64 env1363 = env1364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 64 env1363 == env1364) = true)

theorem identity1364 : scanCanonicalize (H12AffineFastState.compose env1364 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 292) := by decide +kernel

theorem selectedBound1364 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,64,262144,1025,8692,2097152,292,16384,16777216,8328,16464,278681,16384,20545,2080,16852468,16829,257,0,64,16794163]

theorem envBound1365 : H12AffineFastState.Bounded env1365 := by
  intro p hp
  have h : env1365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1364_1365 : H12AffineEnvironment.transform 21 292 env1364 = env1365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292 env1364 == env1365) = true)

def env1366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,8692,65536,64,262144,1025,8692,2097152,292,444,16777216,8328,492,262437,444,4605,2080,16852468,1,257,0,64,16778127]

theorem envBound1366 : H12AffineFastState.Bounded env1366 := by
  intro p hp
  have h : env1366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1365_1366 : H12AffineEnvironment.transform 13 444 env1365 = env1366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env1365 == env1366) = true)

theorem identity1366 : scanCanonicalize (H12AffineFastState.compose env1366 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1366 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,8692,8575,64,262144,1025,8692,2097152,292,444,16777216,8328,492,262437,444,4605,2080,16778379,1,257,0,64,16778127]

theorem envBound1367 : H12AffineFastState.Bounded env1367 := by
  intro p hp
  have h : env1367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1366_1367 : H12AffineEnvironment.transform 15 8575 env1366 = env1367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1366 == env1367) = true)

def env1368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,65536,64,262144,1025,8692,2097152,292,445,16777216,8328,493,262436,445,4604,2080,16852468,0,257,0,64,16778126]

theorem envBound1368 : H12AffineFastState.Bounded env1368 := by
  intro p hp
  have h : env1368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1365_1368 : H12AffineEnvironment.transform 13 445 env1365 = env1368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env1365 == env1368) = true)

theorem identity1368 : scanCanonicalize (H12AffineFastState.compose env1368 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 73969) := by decide +kernel

theorem selectedBound1368 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,65536,64,262144,1025,8692,2097152,292,445,73969,8328,493,262436,445,4604,2080,1285,0,257,0,64,74623]

theorem envBound1369 : H12AffineFastState.Bounded env1369 := by
  intro p hp
  have h : env1369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1368_1369 : H12AffineEnvironment.transform 23 73969 env1368 = env1369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73969 env1368 == env1369) = true)

theorem identity1369 : scanCanonicalize (H12AffineFastState.compose env1369 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound1369 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,65536,64,2265,1025,8692,2097152,292,445,73969,8328,493,2557,445,4604,2080,1285,0,257,0,64,74623]

theorem envBound1370 : H12AffineFastState.Bounded env1370 := by
  intro p hp
  have h : env1370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1369_1370 : H12AffineEnvironment.transform 17 2265 env1369 = env1370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env1369 == env1370) = true)

theorem identity1370 : scanCanonicalize (H12AffineFastState.compose env1370 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1370 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,8315,64,2265,1025,8692,2097152,292,445,138,8328,493,2557,445,4604,2080,1285,0,257,0,64,772]

theorem envBound1371 : H12AffineFastState.Bounded env1371 := by
  intro p hp
  have h : env1371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1370_1371 : H12AffineEnvironment.transform 15 8315 env1370 = env1371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1370 == env1371) = true)

theorem identity1371 : scanCanonicalize (H12AffineFastState.compose env1371 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11438) := by decide +kernel

theorem selectedBound1371 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8692,8315,64,2265,1025,8692,11438,292,445,138,8328,493,2557,445,4604,2080,1285,0,257,0,64,772]

theorem envBound1372 : H12AffineFastState.Bounded env1372 := by
  intro p hp
  have h : env1372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1371_1372 : H12AffineEnvironment.transform 20 11438 env1371 = env1372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11438 env1371 == env1372) = true)

theorem identity1372 : scanCanonicalize (H12AffineFastState.compose env1372 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3116) := by decide +kernel

theorem selectedBound1372 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3116,445,3544,3159,64,2265,1025,3544,130,292,445,138,3236,493,2557,445,4604,2080,1285,0,257,0,64,772]

theorem envBound1373 : H12AffineFastState.Bounded env1373 := by
  intro p hp
  have h : env1373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1372_1373 : H12AffineEnvironment.transform 12 3116 env1372 = env1373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3116 env1372 == env1373) = true)

theorem identity1373 : scanCanonicalize (H12AffineFastState.compose env1373 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1373 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env1374 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,3116,184,3293,3159,64,2265,1025,3293,130,33,184,138,3236,232,2296,184,4345,2080,1024,0,4,0,64,513]

theorem envBound1374 : H12AffineFastState.Bounded env1374 := by
  intro p hp
  have h : env1374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1373_1374 : H12AffineEnvironment.transform 7 5 env1373 = env1374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1373 == env1374) = true)

theorem identity1374 : scanCanonicalize (H12AffineFastState.compose env1374 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1708) := by decide +kernel

theorem selectedBound1374 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env1375 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1708,4096,640,184,625,763,64,1653,1025,625,130,33,184,138,520,232,1620,184,4345,1676,1024,0,4,0,64,513]

theorem envBound1375 : H12AffineFastState.Bounded env1375 := by
  intro p hp
  have h : env1375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1374_1375 : H12AffineEnvironment.transform 10 1708 env1374 = env1375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1708 env1374 == env1375) = true)

theorem identity1375 : scanCanonicalize (H12AffineFastState.compose env1375 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound1375 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1376 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1708,1676,640,184,625,763,64,1653,1025,625,130,33,184,138,520,232,1620,184,1653,1676,1024,0,4,0,64,513]

theorem envBound1376 : H12AffineFastState.Bounded env1376 := by
  intro p hp
  have h : env1376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1375_1376 : H12AffineEnvironment.transform 11 1676 env1375 = env1376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env1375 == env1376) = true)

theorem identity1376 : scanCanonicalize (H12AffineFastState.compose env1376 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound1376 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1377 : List Nat := [2,4,8,16,32,64,25,5,512,1024,1589,1557,537,33,625,610,64,1653,1025,625,27,33,33,19,520,113,1620,33,1653,1557,1024,0,4,0,64,513]

theorem envBound1377 : H12AffineFastState.Bounded env1377 := by
  intro p hp
  have h : env1377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1376_1377 : H12AffineEnvironment.transform 6 25 env1376 = env1377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env1376 == env1377) = true)

theorem identity1377 : scanCanonicalize (H12AffineFastState.compose env1377 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound1377 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1378 : List Nat := [2,4,8,16,32,64,25,5,512,623,90,122,537,33,625,610,64,26,622,625,27,33,33,19,520,113,59,33,26,122,623,0,4,0,64,513]

theorem envBound1378 : H12AffineFastState.Bounded env1378 := by
  intro p hp
  have h : env1378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1377_1378 : H12AffineEnvironment.transform 9 623 env1377 = env1378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env1377 == env1378) = true)

theorem identity1378 : scanCanonicalize (H12AffineFastState.compose env1378 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound1378 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env1379 : List Nat := [2,4,8,16,32,59,25,5,512,532,33,1,537,33,522,537,59,26,533,522,27,33,33,19,520,10,59,33,26,1,532,0,4,0,59,513]

theorem envBound1379 : H12AffineFastState.Bounded env1379 := by
  intro p hp
  have h : env1379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1378_1379 : H12AffineEnvironment.transform 5 59 env1378 = env1379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env1378 == env1379) = true)

theorem identity1379 : scanCanonicalize (H12AffineFastState.compose env1379 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound1379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1380 : List Nat := [2,4,8,16,32,59,25,5,59,47,33,1,34,33,49,34,59,26,46,49,27,33,33,19,51,10,59,33,26,1,47,0,4,0,59,58]

theorem envBound1380 : H12AffineFastState.Bounded env1380 := by
  intro p hp
  have h : env1380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1379_1380 : H12AffineEnvironment.transform 8 59 env1379 = env1380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env1379 == env1380) = true)

theorem identity1380 : scanCanonicalize (H12AffineFastState.compose env1380 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound1380 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1381 : List Nat := [2,4,8,16,20,15,25,5,15,27,21,1,22,21,5,22,15,26,26,5,27,21,21,19,7,10,15,21,26,1,27,0,4,0,15,14]

theorem envBound1381 : H12AffineFastState.Bounded env1381 := by
  intro p hp
  have h : env1381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1380_1381 : H12AffineEnvironment.transform 4 20 env1380 = env1381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env1380 == env1381) = true)

def env1382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,131073,16925299]

theorem envBound1382 : H12AffineFastState.Bounded env1382 := by
  intro p hp
  have h : env1382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1362_1382 : H12AffineEnvironment.transform 34 131073 env1362 = env1382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1362 == env1382) = true)

theorem identity1382 : scanCanonicalize (H12AffineFastState.compose env1382 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 135232) := by decide +kernel

theorem selectedBound1382 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,135232,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,131073,16925299]

theorem envBound1383 : H12AffineFastState.Bounded env1383 := by
  intro p hp
  have h : env1383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1382_1383 : H12AffineEnvironment.transform 20 135232 env1382 = env1383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135232 env1382 == env1383) = true)

theorem identity1383 : scanCanonicalize (H12AffineFastState.compose env1383 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1383 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,135232,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16778639,4341977,257,0,131073,16925299]

theorem envBound1384 : H12AffineFastState.Bounded env1384 := by
  intro p hp
  have h : env1384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1383_1384 : H12AffineEnvironment.transform 15 8315 env1383 = env1384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1383 == env1384) = true)

def env1385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,135232,147672,147520,16777216,8328,147472,409817,16384,151553,2080,16778639,1,257,0,131073,16925299]

theorem envBound1385 : H12AffineFastState.Bounded env1385 := by
  intro p hp
  have h : env1385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1384_1385 : H12AffineEnvironment.transform 21 147672 env1384 = env1385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1384 == env1385) = true)

theorem identity1385 : scanCanonicalize (H12AffineFastState.compose env1385 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1385 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1386 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8432,8315,131072,262144,1025,8432,135232,147672,147520,16777216,8328,147472,409817,16384,151553,2080,16778379,1,5,0,131073,16925299]

theorem envBound1386 : H12AffineFastState.Bounded env1386 := by
  intro p hp
  have h : env1386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1385_1386 : H12AffineEnvironment.transform 7 4 env1385 = env1386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1385 == env1386) = true)

def env1387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,135232,147673,147520,16777216,8328,147472,409817,16384,151553,2080,16778639,0,257,0,131073,16925299]

theorem envBound1387 : H12AffineFastState.Bounded env1387 := by
  intro p hp
  have h : env1387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1384_1387 : H12AffineEnvironment.transform 21 147673 env1384 = env1387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1384 == env1387) = true)

theorem identity1387 : scanCanonicalize (H12AffineFastState.compose env1387 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147831) := by decide +kernel

theorem selectedBound1387 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,135232,147673,147520,147831,8328,147472,409817,16384,151553,2080,148728,0,257,0,131073,772]

theorem envBound1388 : H12AffineFastState.Bounded env1388 := by
  intro p hp
  have h : env1388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1387_1388 : H12AffineEnvironment.transform 23 147831 env1387 = env1388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147831 env1387 == env1388) = true)

theorem identity1388 : scanCanonicalize (H12AffineFastState.compose env1388 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound1388 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,2524,1025,8692,135232,147673,147520,147831,8328,147472,149765,16384,151553,2080,148728,0,257,0,131073,772]

theorem envBound1389 : H12AffineFastState.Bounded env1389 := by
  intro p hp
  have h : env1389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1388_1389 : H12AffineEnvironment.transform 17 2524 env1388 = env1389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env1388 == env1389) = true)

theorem identity1389 : scanCanonicalize (H12AffineFastState.compose env1389 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1389 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env1390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16633,2524,1025,8692,20665,32,185,398,8328,233,2556,16384,4344,2080,1025,0,257,0,16632,772]

theorem envBound1390 : H12AffineFastState.Bounded env1390 := by
  intro p hp
  have h : env1390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1389_1390 : H12AffineEnvironment.transform 16 16633 env1389 = env1390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1389 == env1390) = true)

theorem identity1390 : scanCanonicalize (H12AffineFastState.compose env1390 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1390 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env1391 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8315,16633,2265,1025,8433,20665,32,185,139,8328,233,2297,16384,4344,2080,1025,0,4,0,16632,513]

theorem envBound1391 : H12AffineFastState.Bounded env1391 := by
  intro p hp
  have h : env1391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1390_1391 : H12AffineEnvironment.transform 7 5 env1390 = env1391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1390 == env1391) = true)

theorem identity1391 : scanCanonicalize (H12AffineFastState.compose env1391 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1391 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1392 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,3767,8433,8315,3662,2265,1025,8433,7694,32,185,139,8328,233,2297,3767,4344,2080,1025,0,4,0,3663,513]

theorem envBound1392 : H12AffineFastState.Bounded env1392 := by
  intro p hp
  have h : env1392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1391_1392 : H12AffineEnvironment.transform 13 3767 env1391 = env1392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3767 env1391 == env1392) = true)

theorem identity1392 : scanCanonicalize (H12AffineFastState.compose env1392 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1751) := by decide +kernel

theorem selectedBound1392 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1393 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,8192,96,8433,8315,153,1550,1025,8433,4313,32,185,139,8328,233,1582,96,4344,1783,1025,0,4,0,152,513]

theorem envBound1393 : H12AffineFastState.Bounded env1393 := by
  intro p hp
  have h : env1393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1392_1393 : H12AffineEnvironment.transform 10 1751 env1392 = env1393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1751 env1392 == env1393) = true)

theorem identity1393 : scanCanonicalize (H12AffineFastState.compose env1393 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound1393 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1394 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,1156,96,1141,1279,153,1550,1025,1141,4313,32,185,139,1036,233,1582,96,4344,1783,1025,0,4,0,152,513]

theorem envBound1394 : H12AffineFastState.Bounded env1394 := by
  intro p hp
  have h : env1394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1393_1394 : H12AffineEnvironment.transform 12 1156 env1393 = env1394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env1393 == env1394) = true)

theorem identity1394 : scanCanonicalize (H12AffineFastState.compose env1394 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1394 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1395 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,1750,1156,96,1141,1279,153,1550,1025,1141,1551,32,185,139,1036,233,1582,96,1582,1783,1025,0,4,0,152,513]

theorem envBound1395 : H12AffineFastState.Bounded env1395 := by
  intro p hp
  have h : env1395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1394_1395 : H12AffineEnvironment.transform 11 1750 env1394 = env1395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1750 env1394 == env1395) = true)

theorem identity1395 : scanCanonicalize (H12AffineFastState.compose env1395 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound1395 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1396 : List Nat := [2,4,8,16,32,64,128,5,512,647,80,81,515,96,754,632,153,137,646,754,136,32,185,139,651,233,169,96,169,112,646,0,4,0,152,513]

theorem envBound1396 : H12AffineFastState.Bounded env1396 := by
  intro p hp
  have h : env1396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1395_1396 : H12AffineEnvironment.transform 9 647 env1395 = env1396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env1395 == env1396) = true)

theorem identity1396 : scanCanonicalize (H12AffineFastState.compose env1396 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1396 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1397 : List Nat := [2,4,8,16,32,64,121,5,512,638,80,81,515,96,523,632,96,112,639,523,113,32,64,114,626,16,80,96,80,112,639,0,4,0,97,513]

theorem envBound1397 : H12AffineFastState.Bounded env1397 := by
  intro p hp
  have h : env1397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1396_1397 : H12AffineEnvironment.transform 6 121 env1396 = env1397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1396 == env1397) = true)

theorem identity1397 : scanCanonicalize (H12AffineFastState.compose env1397 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound1397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1398 : List Nat := [2,4,8,16,32,64,121,5,122,4,80,81,121,96,113,2,96,112,5,113,113,32,64,114,8,16,80,96,80,112,5,0,4,0,97,123]

theorem envBound1398 : H12AffineFastState.Bounded env1398 := by
  intro p hp
  have h : env1398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1397_1398 : H12AffineEnvironment.transform 8 122 env1397 = env1398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env1397 == env1398) = true)

theorem identity1398 : scanCanonicalize (H12AffineFastState.compose env1398 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound1398 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1399 : List Nat := [2,4,8,16,32,49,8,5,11,4,33,32,8,17,0,2,17,1,5,0,0,32,49,3,8,16,33,17,33,1,5,0,4,0,16,10]

theorem envBound1399 : H12AffineFastState.Bounded env1399 := by
  intro p hp
  have h : env1399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1398_1399 : H12AffineEnvironment.transform 5 49 env1398 = env1399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env1398 == env1399) = true)

theorem identity1399 : scanCanonicalize (H12AffineFastState.compose env1399 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1399 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1400 : List Nat := [2,4,8,16,1,16,8,5,11,4,0,1,8,17,0,2,17,1,5,0,0,1,16,3,8,16,0,17,0,1,5,0,4,0,16,10]

theorem envBound1400 : H12AffineFastState.Bounded env1400 := by
  intro p hp
  have h : env1400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1399_1400 : H12AffineEnvironment.transform 4 1 env1399 = env1400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1399 == env1400) = true)

theorem identity1400 : scanCanonicalize (H12AffineFastState.compose env1400 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1401 : List Nat := [2,4,5,16,1,16,5,5,6,4,0,1,5,17,0,2,17,1,5,0,0,1,16,3,5,16,0,17,0,1,5,0,4,0,16,7]

theorem envBound1401 : H12AffineFastState.Bounded env1401 := by
  intro p hp
  have h : env1401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1400_1401 : H12AffineEnvironment.transform 2 5 env1400 = env1401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1400 == env1401) = true)

theorem identity1401 : scanCanonicalize (H12AffineFastState.compose env1401 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound1401 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1402 : List Nat := [0,4,5,16,1,16,5,5,4,4,0,1,5,17,0,0,17,1,5,0,0,1,16,1,5,16,0,17,0,1,5,0,4,0,16,5]

theorem envBound1402 : H12AffineFastState.Bounded env1402 := by
  intro p hp
  have h : env1402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1401_1402 : H12AffineEnvironment.transform 0 0 env1401 = env1402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env1401 == env1402) = true)

def env1403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147521,16777216,8328,672784,935129,16384,151553,2080,17375733,4867289,525568,0,34359738368,17450611]

theorem envBound1403 : H12AffineFastState.Bounded env1403 := by
  intro p hp
  have h : env1403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1319_1403 : H12AffineEnvironment.transform 22 147521 env1319 = env1403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env1319 == env1403) = true)

def env1404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2080,16852469,4341977,256,0,34359738368,16925299]

theorem envBound1404 : H12AffineFastState.Bounded env1404 := by
  intro p hp
  have h : env1404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1403_1404 : H12AffineEnvironment.transform 18 1024 env1403 = env1404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1403 == env1404) = true)

def env1405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2080,16852469,4341977,256,0,131072,16925299]

theorem envBound1405 : H12AffineFastState.Bounded env1405 := by
  intro p hp
  have h : env1405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1404_1405 : H12AffineEnvironment.transform 34 131072 env1404 = env1405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1404 == env1405) = true)

theorem identity1405 : scanCanonicalize (H12AffineFastState.compose env1405 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound1405 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,65536,131072,262144,1024,8692,2097152,4194304,136465,16777216,8328,136512,398729,5456,132433,2080,16852469,4330889,256,0,131072,16914211]

theorem envBound1406 : H12AffineFastState.Bounded env1406 := by
  intro p hp
  have h : env1406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1405_1406 : H12AffineEnvironment.transform 13 5456 env1405 = env1406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env1405 == env1406) = true)

theorem identity1406 : scanCanonicalize (H12AffineFastState.compose env1406 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268500) := by decide +kernel

theorem selectedBound1406 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,65536,131072,262144,1024,8692,2097152,4194304,136465,4268500,8328,136512,398729,5456,132433,2080,4195361,4330889,256,0,131072,4404983]

theorem envBound1407 : H12AffineFastState.Bounded env1407 := by
  intro p hp
  have h : env1407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1406_1407 : H12AffineEnvironment.transform 23 4268500 env1406 = env1407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4268500 env1406 == env1407) = true)

theorem identity1407 : scanCanonicalize (H12AffineFastState.compose env1407 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1407 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,131072,262144,1024,8692,2097152,4194304,136465,4194474,8328,136512,398729,5456,132433,2080,4195361,4330889,256,0,131072,4331401]

theorem envBound1408 : H12AffineFastState.Bounded env1408 := by
  intro p hp
  have h : env1408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1407_1408 : H12AffineEnvironment.transform 15 8574 env1407 = env1408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1407 == env1408) = true)

def env1409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5376,262144,1024,8692,2097152,4194304,17,4194474,8328,64,262281,5456,4177,2080,4195361,4194441,256,0,5376,4194953]

theorem envBound1409 : H12AffineFastState.Bounded env1409 := by
  intro p hp
  have h : env1409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1408_1409 : H12AffineEnvironment.transform 16 5376 env1408 = env1409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5376 env1408 == env1409) = true)

theorem identity1409 : scanCanonicalize (H12AffineFastState.compose env1409 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound1409 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5376,262144,1024,8692,2097152,136,17,34,8328,64,262281,5456,4177,2080,1193,1,256,0,5376,513]

theorem envBound1410 : H12AffineFastState.Bounded env1410 := by
  intro p hp
  have h : env1410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1409_1410 : H12AffineEnvironment.transform 21 136 env1409 = env1410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env1409 == env1410) = true)

theorem identity1410 : scanCanonicalize (H12AffineFastState.compose env1410 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4345) := by decide +kernel

theorem selectedBound1410 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5376,262144,1024,8692,4345,136,17,34,8328,64,262281,5456,4177,2080,1193,1,256,0,5376,513]

theorem envBound1411 : H12AffineFastState.Bounded env1411 := by
  intro p hp
  have h : env1411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1410_1411 : H12AffineEnvironment.transform 20 4345 env1410 = env1411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4345 env1410 == env1411) = true)

theorem identity1411 : scanCanonicalize (H12AffineFastState.compose env1411 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound1411 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1412 : List Nat := [2,4,8,16,32,64,128,188,512,1024,2048,4096,8192,5356,8264,8386,5308,262144,1024,8264,4345,136,17,34,8328,64,262281,5356,4177,2080,1193,1,188,0,5308,513]

theorem envBound1412 : H12AffineFastState.Bounded env1412 := by
  intro p hp
  have h : env1412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1411_1412 : H12AffineEnvironment.transform 7 188 env1411 = env1412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env1411 == env1412) = true)

theorem identity1412 : scanCanonicalize (H12AffineFastState.compose env1412 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound1412 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env1413 : List Nat := [2,4,8,16,32,1,128,188,512,1024,2048,4096,8192,5293,8201,8323,5308,262144,1024,8201,4280,136,17,34,8328,1,262281,5293,4112,2080,1193,1,188,0,5308,513]

theorem envBound1413 : H12AffineFastState.Bounded env1413 := by
  intro p hp
  have h : env1413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1412_1413 : H12AffineEnvironment.transform 5 1 env1412 = env1413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1412 == env1413) = true)

theorem identity1413 : scanCanonicalize (H12AffineFastState.compose env1413 (packedSelected [2,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 10368) := by decide +kernel

theorem selectedBound1413 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env1414 : List Nat := [2,4,8,16,32,1,128,188,512,1024,2048,4096,8192,5293,8201,8323,5308,10368,1024,8201,4280,136,17,34,8328,1,10249,5293,4112,2080,1193,1,188,0,5308,513]

theorem envBound1414 : H12AffineFastState.Bounded env1414 := by
  intro p hp
  have h : env1414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1413_1414 : H12AffineEnvironment.transform 17 10368 env1413 = env1414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10368 env1413 == env1414) = true)

theorem identity1414 : scanCanonicalize (H12AffineFastState.compose env1414 (packedSelected [1,2,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound1414 : packedSelected [1,2,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env1415 : List Nat := [2,4,8,16,32,1,56,4,512,1024,2048,4096,8192,5141,8201,8251,5124,10296,1024,8201,4096,48,17,34,8240,1,10249,5141,4112,2080,1041,1,4,0,5124,513]

theorem envBound1415 : H12AffineFastState.Bounded env1415 := by
  intro p hp
  have h : env1415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1414_1415 : H12AffineEnvironment.transform 6 56 env1414 = env1415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env1414 == env1415) = true)

theorem identity1415 : scanCanonicalize (H12AffineFastState.compose env1415 (packedSelected [0,2,4,7,9,13] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1415 : packedSelected [0,2,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env1416 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,5124,8201,8234,5124,10281,1024,8201,4096,33,0,34,8225,1,10249,5124,4097,2080,1024,1,4,0,5124,513]

theorem envBound1416 : H12AffineFastState.Bounded env1416 := by
  intro p hp
  have h : env1416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1415_1416 : H12AffineEnvironment.transform 3 1 env1415 = env1416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1415 == env1416) = true)

theorem identity1416 : scanCanonicalize (H12AffineFastState.compose env1416 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound1416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1417 : List Nat := [2,4,8,1,32,1,41,4,512,36,2048,4096,8192,4128,8201,8234,4128,10281,36,8201,4096,33,0,34,8225,1,10249,4128,4097,2080,36,1,4,0,4128,513]

theorem envBound1417 : H12AffineFastState.Bounded env1417 := by
  intro p hp
  have h : env1417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1416_1417 : H12AffineEnvironment.transform 9 36 env1416 = env1417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env1416 == env1417) = true)

theorem identity1417 : scanCanonicalize (H12AffineFastState.compose env1417 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound1417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1418 : List Nat := [2,4,8,1,32,1,41,4,512,36,2048,4096,40,4128,33,2,4128,2049,36,33,4096,33,0,34,9,1,2081,4128,4097,2080,36,1,4,0,4128,513]

theorem envBound1418 : H12AffineFastState.Bounded env1418 := by
  intro p hp
  have h : env1418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1417_1418 : H12AffineEnvironment.transform 12 40 env1417 = env1418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env1417 == env1418) = true)

theorem identity1418 : scanCanonicalize (H12AffineFastState.compose env1418 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound1418 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1419 : List Nat := [2,4,8,1,32,1,41,4,512,36,10,4096,40,4128,33,2,4128,11,36,33,4096,33,0,34,9,1,43,4128,4097,42,36,1,4,0,4128,513]

theorem envBound1419 : H12AffineFastState.Bounded env1419 := by
  intro p hp
  have h : env1419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1418_1419 : H12AffineEnvironment.transform 10 10 env1418 = env1419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env1418 == env1419) = true)

theorem identity1419 : scanCanonicalize (H12AffineFastState.compose env1419 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound1419 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env1420 : List Nat := [2,4,8,1,7,1,14,4,512,3,10,4096,15,4103,6,2,4103,11,3,6,4096,6,0,5,9,1,12,4103,4097,13,3,1,4,0,4103,513]

theorem envBound1420 : H12AffineFastState.Bounded env1420 := by
  intro p hp
  have h : env1420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1419_1420 : H12AffineEnvironment.transform 4 7 env1419 = env1420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env1419 == env1420) = true)

theorem identity1420 : scanCanonicalize (H12AffineFastState.compose env1420 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound1420 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1421 : List Nat := [2,4,8,1,7,1,14,4,512,3,10,6,15,1,6,2,1,11,3,6,6,6,0,5,9,1,12,1,7,13,3,1,4,0,1,513]

theorem envBound1421 : H12AffineFastState.Bounded env1421 := by
  intro p hp
  have h : env1421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1420_1421 : H12AffineEnvironment.transform 11 6 env1420 = env1421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env1420 == env1421) = true)

theorem identity1421 : scanCanonicalize (H12AffineFastState.compose env1421 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1421 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env1422 : List Nat := [2,3,8,1,0,1,9,3,512,3,10,1,8,1,1,2,1,11,3,1,1,1,0,2,9,1,11,1,0,10,3,1,3,0,1,513]

theorem envBound1422 : H12AffineFastState.Bounded env1422 := by
  intro p hp
  have h : env1422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1421_1422 : H12AffineEnvironment.transform 1 3 env1421 = env1422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1421 == env1422) = true)

theorem identity1422 : scanCanonicalize (H12AffineFastState.compose env1422 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound1422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1423 : List Nat := [2,3,8,1,0,1,9,3,11,3,10,1,8,1,1,2,1,11,3,1,1,1,0,2,9,1,11,1,0,10,3,1,3,0,1,10]

theorem envBound1423 : H12AffineFastState.Bounded env1423 := by
  intro p hp
  have h : env1423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1422_1423 : H12AffineEnvironment.transform 8 11 env1422 = env1423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env1422 == env1423) = true)

theorem identity1423 : scanCanonicalize (H12AffineFastState.compose env1423 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound1423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1424 : List Nat := [2,3,1,1,0,1,0,3,2,3,3,1,1,1,1,2,1,2,3,1,1,1,0,2,0,1,2,1,0,3,3,1,3,0,1,3]

theorem envBound1424 : H12AffineFastState.Bounded env1424 := by
  intro p hp
  have h : env1424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1423_1424 : H12AffineEnvironment.transform 2 1 env1423 = env1424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env1423 == env1424) = true)

theorem identity1424 : scanCanonicalize (H12AffineFastState.compose env1424 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound1424 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env1425 : List Nat := [1,0,1,1,0,1,0,0,1,0,0,1,1,1,1,1,1,1,0,1,1,1,0,1,0,1,1,1,0,0,0,1,0,0,1,0]

theorem envBound1425 : H12AffineFastState.Bounded env1425 := by
  intro p hp
  have h : env1425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1424_1425 : H12AffineEnvironment.transform 0 1 env1424 = env1425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env1424 == env1425) = true)

def env1426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5377,262144,1024,8692,2097152,4194304,16,4194474,8328,65,262280,5456,4176,2080,4195361,4194440,256,0,5377,4194952]

theorem envBound1426 : H12AffineFastState.Bounded env1426 := by
  intro p hp
  have h : env1426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1408_1426 : H12AffineEnvironment.transform 16 5377 env1408 = env1426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5377 env1408 == env1426) = true)

theorem identity1426 : scanCanonicalize (H12AffineFastState.compose env1426 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound1426 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5377,262144,1024,8692,2097152,32,16,138,8328,65,262280,5456,4176,2080,1025,168,256,0,5377,680]

theorem envBound1427 : H12AffineFastState.Bounded env1427 := by
  intro p hp
  have h : env1427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1426_1427 : H12AffineEnvironment.transform 21 32 env1426 = env1427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env1426 == env1427) = true)

theorem identity1427 : scanCanonicalize (H12AffineFastState.compose env1427 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound1427 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env1428 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8352,8234,5205,262144,1024,8352,2097152,32,16,138,8328,65,262280,5124,4176,2080,1025,168,84,0,5205,680]

theorem envBound1428 : H12AffineFastState.Bounded env1428 := by
  intro p hp
  have h : env1428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1427_1428 : H12AffineEnvironment.transform 7 84 env1427 = env1428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env1427 == env1428) = true)

theorem identity1428 : scanCanonicalize (H12AffineFastState.compose env1428 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound1428 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env1429 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8352,8234,5205,262144,1024,8352,4161,32,16,138,8328,65,262280,5124,4176,2080,1025,168,84,0,5205,680]

theorem envBound1429 : H12AffineFastState.Bounded env1429 := by
  intro p hp
  have h : env1429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1428_1429 : H12AffineEnvironment.transform 20 4161 env1428 = env1429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env1428 == env1429) = true)

theorem identity1429 : scanCanonicalize (H12AffineFastState.compose env1429 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound1429 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env1430 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,89,5124,249,115,5205,262144,1024,249,4161,32,16,138,209,65,262280,5124,4176,2080,1025,168,84,0,5205,680]

theorem envBound1430 : H12AffineFastState.Bounded env1430 := by
  intro p hp
  have h : env1430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1429_1430 : H12AffineEnvironment.transform 12 89 env1429 = env1430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env1429 == env1430) = true)

theorem identity1430 : scanCanonicalize (H12AffineFastState.compose env1430 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound1430 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env1431 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,9,5124,169,35,5125,262144,1024,169,4113,32,16,138,129,17,262280,5124,4096,2080,1025,168,4,0,5125,680]

theorem envBound1431 : H12AffineFastState.Bounded env1431 := by
  intro p hp
  have h : env1431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1430_1431 : H12AffineEnvironment.transform 5 16 env1430 = env1431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env1430 == env1431) = true)

theorem identity1431 : scanCanonicalize (H12AffineFastState.compose env1431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env1432 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,0,35,5125,262144,1024,0,4113,32,16,35,40,17,262177,5124,4096,2080,1025,1,4,0,5125,513]

theorem envBound1432 : H12AffineFastState.Bounded env1432 := by
  intro p hp
  have h : env1432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1431_1432 : H12AffineEnvironment.transform 6 41 env1431 = env1432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1431 == env1432) = true)

theorem identity1432 : scanCanonicalize (H12AffineFastState.compose env1432 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 571) := by decide +kernel

theorem selectedBound1432 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env1433 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,0,35,5125,571,1024,0,4113,32,16,35,40,17,538,5124,4096,2080,1025,1,4,0,5125,513]

theorem envBound1433 : H12AffineFastState.Bounded env1433 := by
  intro p hp
  have h : env1433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1432_1433 : H12AffineEnvironment.transform 17 571 env1432 = env1433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 571 env1432 == env1433) = true)

def env1434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2080,16852469,4341977,256,0,131073,16925299]

theorem envBound1434 : H12AffineFastState.Bounded env1434 := by
  intro p hp
  have h : env1434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1404_1434 : H12AffineEnvironment.transform 34 131073 env1404 = env1434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1404 == env1434) = true)

theorem identity1434 : scanCanonicalize (H12AffineFastState.compose env1434 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 17744) := by decide +kernel

theorem selectedBound1434 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,17744,4194304,147521,16777216,8328,147472,409817,16384,151553,2080,16852469,4341977,256,0,131073,16925299]

theorem envBound1435 : H12AffineFastState.Bounded env1435 := by
  intro p hp
  have h : env1435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1434_1435 : H12AffineEnvironment.transform 20 17744 env1434 = env1435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17744 env1434 == env1435) = true)

theorem identity1435 : scanCanonicalize (H12AffineFastState.compose env1435 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound1435 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,17744,4194304,147521,138,8328,147472,409817,16384,151553,2080,75135,4341977,256,0,131073,148217]

theorem envBound1436 : H12AffineFastState.Bounded env1436 := by
  intro p hp
  have h : env1436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1435_1436 : H12AffineEnvironment.transform 23 138 env1435 = env1436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env1435 == env1436) = true)

theorem identity1436 : scanCanonicalize (H12AffineFastState.compose env1436 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 147749) := by decide +kernel

theorem selectedBound1436 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env1437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,17744,147749,147521,138,8328,147472,409817,16384,151553,2080,75135,508,256,0,131073,148217]

theorem envBound1437 : H12AffineFastState.Bounded env1437 := by
  intro p hp
  have h : env1437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1436_1437 : H12AffineEnvironment.transform 21 147749 env1436 = env1437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147749 env1436 == env1437) = true)

theorem identity1437 : scanCanonicalize (H12AffineFastState.compose env1437 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1437 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env1438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1024,8692,17744,147749,147521,138,8328,147472,409817,16384,151553,2080,1025,508,256,0,131073,148217]

theorem envBound1438 : H12AffineFastState.Bounded env1438 := by
  intro p hp
  have h : env1438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1437_1438 : H12AffineEnvironment.transform 15 8574 env1437 = env1438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1437 == env1438) = true)

def env1439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1024,8692,17744,477,185,138,8328,232,262177,16384,4345,2080,1025,508,256,0,16633,513]

theorem envBound1439 : H12AffineFastState.Bounded env1439 := by
  intro p hp
  have h : env1439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1438_1439 : H12AffineEnvironment.transform 16 16632 env1438 = env1439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1438 == env1439) = true)

theorem identity1439 : scanCanonicalize (H12AffineFastState.compose env1439 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound1439 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,8692,8574,13324,262144,1024,8692,12708,477,185,138,8328,232,262177,13556,4345,2080,1025,508,256,0,13325,513]

theorem envBound1440 : H12AffineFastState.Bounded env1440 := by
  intro p hp
  have h : env1440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1439_1440 : H12AffineEnvironment.transform 13 13556 env1439 = env1440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env1439 == env1440) = true)

theorem identity1440 : scanCanonicalize (H12AffineFastState.compose env1440 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound1440 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5372,508,374,5124,262144,1024,508,4524,477,185,138,128,232,262177,5372,4345,2080,1025,508,256,0,5125,513]

theorem envBound1441 : H12AffineFastState.Bounded env1441 := by
  intro p hp
  have h : env1441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1440_1441 : H12AffineEnvironment.transform 12 8 env1440 = env1441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env1440 == env1441) = true)

theorem identity1441 : scanCanonicalize (H12AffineFastState.compose env1441 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound1441 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1442 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,8,5372,232,98,5124,262144,1024,232,4280,201,185,138,128,232,262177,5372,4345,2080,1025,232,20,0,5125,513]

theorem envBound1442 : H12AffineFastState.Bounded env1442 := by
  intro p hp
  have h : env1442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1441_1442 : H12AffineEnvironment.transform 7 20 env1441 = env1442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env1441 == env1442) = true)

theorem identity1442 : scanCanonicalize (H12AffineFastState.compose env1442 (packedSelected [0,1,2,3,5,7,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound1442 : packedSelected [0,1,2,3,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env1443 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,8,5292,184,50,5124,262144,1024,184,4280,153,185,138,128,184,262177,5292,4265,2080,1025,184,20,0,5125,513]

theorem envBound1443 : H12AffineFastState.Bounded env1443 := by
  intro p hp
  have h : env1443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1442_1443 : H12AffineEnvironment.transform 5 16 env1442 = env1443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env1442 == env1443) = true)

theorem identity1443 : scanCanonicalize (H12AffineFastState.compose env1443 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound1443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1444 : List Nat := [2,4,8,16,32,16,56,20,512,1024,2048,4096,8,5140,0,50,5124,262144,1024,0,4096,33,1,50,56,0,262177,5140,4113,2080,1025,0,20,0,5125,513]

theorem envBound1444 : H12AffineFastState.Bounded env1444 := by
  intro p hp
  have h : env1444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1443_1444 : H12AffineEnvironment.transform 6 56 env1443 = env1444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env1443 == env1444) = true)

theorem identity1444 : scanCanonicalize (H12AffineFastState.compose env1444 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1444 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1445 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8,5125,0,35,5124,262144,1024,0,4096,33,1,35,41,0,262177,5125,4096,2080,1025,0,5,0,5125,513]

theorem envBound1445 : H12AffineFastState.Bounded env1445 := by
  intro p hp
  have h : env1445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1444_1445 : H12AffineEnvironment.transform 3 1 env1444 = env1445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1444 == env1445) = true)

theorem identity1445 : scanCanonicalize (H12AffineFastState.compose env1445 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3119) := by decide +kernel

theorem selectedBound1445 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env1446 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8,5125,0,35,5124,3119,1024,0,4096,33,1,35,41,0,3086,5125,4096,2080,1025,0,5,0,5125,513]

theorem envBound1446 : H12AffineFastState.Bounded env1446 := by
  intro p hp
  have h : env1446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1445_1446 : H12AffineEnvironment.transform 17 3119 env1445 = env1446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3119 env1445 == env1446) = true)

def env1447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1024,8692,17744,476,184,138,8328,233,262176,16384,4344,2080,1025,508,256,0,16632,512]

theorem envBound1447 : H12AffineFastState.Bounded env1447 := by
  intro p hp
  have h : env1447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1438_1447 : H12AffineEnvironment.transform 16 16633 env1438 = env1447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1438 == env1447) = true)

theorem identity1447 : scanCanonicalize (H12AffineFastState.compose env1447 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound1447 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,10281,1024,8692,17744,476,184,138,8328,233,10249,16384,4344,2080,1025,508,256,0,16632,512]

theorem envBound1448 : H12AffineFastState.Bounded env1448 := by
  intro p hp
  have h : env1448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1447_1448 : H12AffineEnvironment.transform 17 10281 env1447 = env1448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env1447 == env1448) = true)

theorem identity1448 : scanCanonicalize (H12AffineFastState.compose env1448 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound1448 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env1449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,16384,81,219,16633,2444,1024,81,17744,476,184,138,301,233,2476,16384,4344,2080,1025,508,256,0,16632,512]

theorem envBound1449 : H12AffineFastState.Bounded env1449 := by
  intro p hp
  have h : env1449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1448_1449 : H12AffineEnvironment.transform 12 421 env1448 = env1449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env1448 == env1449) = true)

theorem identity1449 : scanCanonicalize (H12AffineFastState.compose env1449 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound1449 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1450 : List Nat := [2,4,8,16,32,64,128,189,512,1024,2048,4096,24,16384,81,219,16633,2097,1024,81,17645,97,184,138,144,233,2065,16384,4344,2080,1025,65,189,0,16632,512]

theorem envBound1450 : H12AffineFastState.Bounded env1450 := by
  intro p hp
  have h : env1450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1449_1450 : H12AffineEnvironment.transform 7 189 env1449 = env1450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env1449 == env1450) = true)

def env1451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2080,16852468,4341976,257,0,34359738368,16925298]

theorem envBound1451 : H12AffineFastState.Bounded env1451 := by
  intro p hp
  have h : env1451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1403_1451 : H12AffineEnvironment.transform 18 1025 env1403 = env1451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1403 == env1451) = true)

def env1452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2080,16852468,4341976,257,0,131072,16925298]

theorem envBound1452 : H12AffineFastState.Bounded env1452 := by
  intro p hp
  have h : env1452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1451_1452 : H12AffineEnvironment.transform 34 131072 env1451 = env1452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1451 == env1452) = true)

theorem identity1452 : scanCanonicalize (H12AffineFastState.compose env1452 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 20497) := by decide +kernel

theorem selectedBound1452 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,20497,262144,1025,8692,2097152,4194304,4176,16777216,8328,4096,266441,16384,16,2080,16852468,4198601,257,0,20497,16781923]

theorem envBound1453 : H12AffineFastState.Bounded env1453 := by
  intro p hp
  have h : env1453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1452_1453 : H12AffineEnvironment.transform 16 20497 env1452 = env1453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 20497 env1452 == env1453) = true)

theorem identity1453 : scanCanonicalize (H12AffineFastState.compose env1453 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 292) := by decide +kernel

theorem selectedBound1453 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,20497,262144,1025,8692,2097152,292,4176,16777216,8328,4096,266441,16384,16,2080,16852468,4589,257,0,20497,16781923]

theorem envBound1454 : H12AffineFastState.Bounded env1454 := by
  intro p hp
  have h : env1454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1453_1454 : H12AffineEnvironment.transform 21 292 env1453 = env1454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292 env1453 == env1454) = true)

def env1455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,8692,65536,16893,262144,1025,8692,2097152,292,444,16777216,8328,492,262437,16384,16,2080,16852468,1,257,0,16893,16778127]

theorem envBound1455 : H12AffineFastState.Bounded env1455 := by
  intro p hp
  have h : env1455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1454_1455 : H12AffineEnvironment.transform 11 492 env1454 = env1455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env1454 == env1455) = true)

theorem identity1455 : scanCanonicalize (H12AffineFastState.compose env1455 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1455 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,8692,8575,16893,262144,1025,8692,2097152,292,444,16777216,8328,492,262437,16384,16,2080,16778379,1,257,0,16893,16778127]

theorem envBound1456 : H12AffineFastState.Bounded env1456 := by
  intro p hp
  have h : env1456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0