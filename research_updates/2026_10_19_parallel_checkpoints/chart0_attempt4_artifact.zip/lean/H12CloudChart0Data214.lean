import H12CloudChart0Data213

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1360,348,0,80,342,16,1125,1025,81,1296,32,16,82,349,64,1297,65,1281,1077,1365,33,257,112,80,513]

theorem envBound54182 : H12AffineFastState.Bounded env54182 := by
  intro p hp
  have h : env54182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54181_54182 : H12AffineEnvironment.transform 11 1360 env54181 = env54182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env54181 == env54182) = true)

theorem identity54182 : scanCanonicalize (H12AffineFastState.compose env54182 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54182 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54183 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1077,1141,121,0,80,115,16,1125,1025,81,1077,32,16,82,120,64,1076,65,1060,1077,1136,33,36,112,80,513]

theorem envBound54183 : H12AffineFastState.Bounded env54183 := by
  intro p hp
  have h : env54183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54182_54183 : H12AffineEnvironment.transform 7 37 env54182 = env54183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54182 == env54183) = true)

theorem identity54183 : scanCanonicalize (H12AffineFastState.compose env54183 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54184 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,65,121,0,80,115,16,81,53,81,1,32,16,82,120,64,0,65,16,1,68,33,36,112,80,513]

theorem envBound54184 : H12AffineFastState.Bounded env54184 := by
  intro p hp
  have h : env54184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54183_54184 : H12AffineEnvironment.transform 9 52 env54183 = env54184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54183 == env54184) = true)

theorem identity54184 : scanCanonicalize (H12AffineFastState.compose env54184 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54184 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env54185 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,17,41,0,0,35,16,1,53,1,1,32,16,2,40,16,0,17,16,1,20,33,36,32,0,513]

theorem envBound54185 : H12AffineFastState.Bounded env54185 := by
  intro p hp
  have h : env54185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54184_54185 : H12AffineEnvironment.transform 5 16 env54184 = env54185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54184 == env54185) = true)

theorem identity54185 : scanCanonicalize (H12AffineFastState.compose env54185 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54186 : List Nat := [2,4,8,16,17,16,9,20,512,5,1,17,24,0,0,18,16,1,4,1,1,17,16,2,25,16,0,17,16,1,20,16,21,17,0,513]

theorem envBound54186 : H12AffineFastState.Bounded env54186 := by
  intro p hp
  have h : env54186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54185_54186 : H12AffineEnvironment.transform 4 17 env54185 = env54186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54185 == env54186) = true)

def env54187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157596,2098513,17665,2377024,2102684,2411676,257,21792,46213,2175563]

theorem envBound54187 : H12AffineFastState.Bounded env54187 := by
  intro p hp
  have h : env54187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54143_54187 : H12AffineEnvironment.transform 21 272513 env54143 = env54187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54143 == env54187) = true)

theorem identity54187 : scanCanonicalize (H12AffineFastState.compose env54187 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54187 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272513,2101328,41430,8328,64,2157596,2098513,17665,2377024,2102684,2411676,257,21792,46213,2101824]

theorem envBound54188 : H12AffineFastState.Bounded env54188 := by
  intro p hp
  have h : env54188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54187_54188 : H12AffineEnvironment.transform 15 8203 env54187 = env54188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54187 == env54188) = true)

def env54189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272393,2101328,41310,8192,64,2157596,2098513,17665,2377024,2102548,2411540,257,21792,46093,2101824]

theorem envBound54189 : H12AffineFastState.Bounded env54189 := by
  intro p hp
  have h : env54189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54188_54189 : H12AffineEnvironment.transform 6 8 env54188 = env54189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54188 == env54189) = true)

theorem identity54189 : scanCanonicalize (H12AffineFastState.compose env54189 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound54189 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,301364,272393,297316,41310,8192,64,292136,302181,17665,56436,298016,21792,257,21792,46093,297844]

theorem envBound54190 : H12AffineFastState.Bounded env54190 := by
  intro p hp
  have h : env54190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54189_54190 : H12AffineEnvironment.transform 20 301364 env54189 = env54190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env54189 == env54190) = true)

theorem identity54190 : scanCanonicalize (H12AffineFastState.compose env54190 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound54190 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,34816,1025,32769,4404,40969,356,41310,8192,64,64808,5221,17665,56436,1056,21792,257,21792,46093,884]

theorem envBound54191 : H12AffineFastState.Bounded env54191 := by
  intro p hp
  have h : env54191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54190_54191 : H12AffineEnvironment.transform 17 34816 env54190 = env54191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env54190 == env54191) = true)

theorem identity54191 : scanCanonicalize (H12AffineFastState.compose env54191 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54191 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env54192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,13388,10588,1025,8541,4404,341,356,2,8192,64,23668,5221,17665,32040,1056,21792,257,21792,5457,884]

theorem envBound54192 : H12AffineFastState.Bounded env54192 := by
  intro p hp
  have h : env54192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54191_54192 : H12AffineEnvironment.transform 14 8540 env54191 = env54192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54191 == env54192) = true)

theorem identity54192 : scanCanonicalize (H12AffineFastState.compose env54192 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound54192 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env54193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8540,8203,13388,10588,1025,8541,4404,341,356,2,8192,64,10589,5221,12328,2049,1056,8201,257,8201,5457,884]

theorem envBound54193 : H12AffineFastState.Bounded env54193 := by
  intro p hp
  have h : env54193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54192_54193 : H12AffineEnvironment.transform 13 13609 env54192 = env54193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env54192 == env54193) = true)

theorem identity54193 : scanCanonicalize (H12AffineFastState.compose env54193 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54193 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5157,80,263,5440,2128,1025,81,4404,341,356,2,268,64,2129,5221,4388,2049,1056,261,257,261,5457,884]

theorem envBound54194 : H12AffineFastState.Bounded env54194 := by
  intro p hp
  have h : env54194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54193_54194 : H12AffineEnvironment.transform 12 268 env54193 = env54194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54193 == env54194) = true)

theorem identity54194 : scanCanonicalize (H12AffineFastState.compose env54194 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound54194 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env54195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,268,372,80,263,17,2128,1025,81,1125,341,356,2,268,64,2129,308,1141,2049,1056,261,257,261,0,884]

theorem envBound54195 : H12AffineFastState.Bounded env54195 := by
  intro p hp
  have h : env54195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54194_54195 : H12AffineEnvironment.transform 11 1361 env54194 = env54195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env54194 == env54195) = true)

theorem identity54195 : scanCanonicalize (H12AffineFastState.compose env54195 (packedSelected [2,3,5,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound54195 : packedSelected [2,3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env54196 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,96,268,372,80,263,17,2128,304,81,340,341,356,2,268,64,2129,308,324,2049,273,261,257,261,0,884]

theorem envBound54196 : H12AffineFastState.Bounded env54196 := by
  intro p hp
  have h : env54196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54195_54196 : H12AffineEnvironment.transform 9 305 env54195 = env54196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env54195 == env54196) = true)

theorem identity54196 : scanCanonicalize (H12AffineFastState.compose env54196 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54196 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env54197 : List Nat := [2,4,8,16,32,64,8,4,512,53,2048,96,8,112,80,3,17,2128,52,81,80,81,96,2,8,64,2129,48,64,2049,21,1,5,1,0,624]

theorem envBound54197 : H12AffineFastState.Bounded env54197 := by
  intro p hp
  have h : env54197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54196_54197 : H12AffineEnvironment.transform 7 4 env54196 = env54197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54196 == env54197) = true)

theorem identity54197 : scanCanonicalize (H12AffineFastState.compose env54197 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound54197 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env54198 : List Nat := [2,4,8,16,32,64,8,4,512,53,112,96,8,112,80,3,17,32,52,81,80,81,96,2,8,64,33,48,64,113,21,1,5,1,0,624]

theorem envBound54198 : H12AffineFastState.Bounded env54198 := by
  intro p hp
  have h : env54198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54197_54198 : H12AffineEnvironment.transform 10 112 env54197 = env54198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env54197 == env54198) = true)

theorem identity54198 : scanCanonicalize (H12AffineFastState.compose env54198 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound54198 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54199 : List Nat := [2,4,8,16,32,48,8,4,512,53,0,16,8,0,32,3,17,32,52,33,32,33,16,2,8,48,33,48,48,1,21,1,5,1,0,512]

theorem envBound54199 : H12AffineFastState.Bounded env54199 := by
  intro p hp
  have h : env54199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54198_54199 : H12AffineEnvironment.transform 5 48 env54198 = env54199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env54198 == env54199) = true)

def env54200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272392,2101328,41311,8193,64,2157596,2098513,17665,2377024,2102549,2411541,257,21792,46092,2101824]

theorem envBound54200 : H12AffineFastState.Bounded env54200 := by
  intro p hp
  have h : env54200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54188_54200 : H12AffineEnvironment.transform 6 9 env54188 = env54200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54188 == env54200) = true)

theorem identity54200 : scanCanonicalize (H12AffineFastState.compose env54200 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound54200 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,276584,272392,272440,41311,8193,64,316532,277817,17665,32040,273789,62589,257,21792,46092,272936]

theorem envBound54201 : H12AffineFastState.Bounded env54201 := by
  intro p hp
  have h : env54201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54200_54201 : H12AffineEnvironment.transform 20 276584 env54200 = env54201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env54200 == env54201) = true)

theorem identity54201 : scanCanonicalize (H12AffineFastState.compose env54201 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54201 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10280,1025,32769,4160,32,16,41311,8193,64,64604,5393,17665,32040,1365,62589,257,21792,46092,512]

theorem envBound54202 : H12AffineFastState.Bounded env54202 := by
  intro p hp
  have h : env54202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54201_54202 : H12AffineEnvironment.transform 17 10280 env54201 = env54202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54201 == env54202) = true)

theorem identity54202 : scanCanonicalize (H12AffineFastState.compose env54202 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 12621) := by decide +kernel

theorem selectedBound54202 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,12621,8203,9309,10280,1025,12620,4160,32,16,4114,8193,64,19729,5393,17665,32040,1365,17712,257,21792,1345,512]

theorem envBound54203 : H12AffineFastState.Bounded env54203 := by
  intro p hp
  have h : env54203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54202_54203 : H12AffineEnvironment.transform 14 12621 env54202 = env54203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12621 env54202 == env54203) = true)

theorem identity54203 : scanCanonicalize (H12AffineFastState.compose env54203 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound54203 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1125,12621,8203,9309,10280,1025,12620,4160,32,16,4114,8193,64,2420,5393,356,14669,1365,341,257,4421,1345,512]

theorem envBound54204 : H12AffineFastState.Bounded env54204 := by
  intro p hp
  have h : env54204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54203_54204 : H12AffineEnvironment.transform 13 1125 env54203 = env54204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env54203 == env54204) = true)

theorem identity54204 : scanCanonicalize (H12AffineFastState.compose env54204 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound54204 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4168,1125,261,4163,5141,6240,1025,260,4160,32,16,4114,4169,64,2420,5393,356,2309,1365,341,257,4421,1345,512]

theorem envBound54205 : H12AffineFastState.Bounded env54205 := by
  intro p hp
  have h : env54205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54204_54205 : H12AffineEnvironment.transform 12 4168 env54204 = env54205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env54204 == env54205) = true)

def env54206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603932,2098512,17664,2377024,2102684,6349852,257,21792,46213,2175563]

theorem envBound54206 : H12AffineFastState.Bounded env54206 := by
  intro p hp
  have h : env54206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54142_54206 : H12AffineEnvironment.transform 16 38161 env54142 = env54206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54142 == env54206) = true)

def env54207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157596,2098512,17664,2377024,2102684,2411676,257,21792,46213,2175563]

theorem envBound54207 : H12AffineFastState.Bounded env54207 := by
  intro p hp
  have h : env54207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54206_54207 : H12AffineEnvironment.transform 21 272512 env54206 = env54207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54206 == env54207) = true)

theorem identity54207 : scanCanonicalize (H12AffineFastState.compose env54207 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound54207 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,120015,98780,8328,64,75906,115150,17664,360926,119042,329730,257,21792,46213,63189]

theorem envBound54208 : H12AffineFastState.Bounded env54208 := by
  intro p hp
  have h : env54208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54207_54208 : H12AffineEnvironment.transform 20 115870 env54207 = env54208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env54207 == env54208) = true)

def env54209 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,119967,98700,8328,16,75906,115102,17664,360846,119042,329730,257,21792,46213,63109]

theorem envBound54209 : H12AffineFastState.Bounded env54209 := by
  intro p hp
  have h : env54209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54208_54209 : H12AffineEnvironment.transform 5 16 env54208 = env54209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54208 == env54209) = true)

def env54210 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115734,272392,119831,98564,8192,16,75786,114966,17664,360710,119042,329730,257,21792,46093,62989]

theorem envBound54210 : H12AffineFastState.Bounded env54210 := by
  intro p hp
  have h : env54210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54209_54210 : H12AffineEnvironment.transform 6 8 env54209 = env54210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54209 == env54210) = true)

theorem identity54210 : scanCanonicalize (H12AffineFastState.compose env54210 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 31756) := by decide +kernel

theorem selectedBound54210 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54211 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,31756,1025,32769,115734,21508,119831,98564,8192,16,75786,114966,17664,130314,119042,95246,257,21792,46093,62989]

theorem envBound54211 : H12AffineFastState.Bounded env54211 := by
  intro p hp
  have h : env54211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54210_54211 : H12AffineEnvironment.transform 17 31756 env54210 = env54211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31756 env54210 == env54211) = true)

theorem identity54211 : scanCanonicalize (H12AffineFastState.compose env54211 (packedSelected [1,2,3,5,6,8,9,10,11,14,16,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54211 : packedSelected [1,2,3,5,6,8,9,10,11,14,16,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54212 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,65536,38161,23809,1025,32769,115734,21508,119831,98564,269,16,67847,114966,17664,121863,119042,87299,257,21792,38144,55040]

theorem envBound54212 : H12AffineFastState.Bounded env54212 := by
  intro p hp
  have h : env54212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54211_54212 : H12AffineEnvironment.transform 12 269 env54211 = env54212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54211 == env54212) = true)

theorem identity54212 : scanCanonicalize (H12AffineFastState.compose env54212 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54212 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54213 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,32768,65536,37940,23588,1025,32769,115734,21508,119831,98337,40,16,67618,114739,17445,121863,118823,87078,36,21509,37925,54821]

theorem envBound54213 : H12AffineFastState.Bounded env54213 := by
  intro p hp
  have h : env54213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54212_54213 : H12AffineEnvironment.transform 7 37 env54212 = env54213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54212 == env54213) = true)

theorem identity54213 : scanCanonicalize (H12AffineFastState.compose env54213 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound54213 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env54214 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,32768,54279,37940,23588,1025,32769,4113,21508,16,21542,40,16,56357,5172,17445,2048,1056,32801,36,21509,37925,54821]

theorem envBound54214 : H12AffineFastState.Bounded env54214 := by
  intro p hp
  have h : env54214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54213_54214 : H12AffineEnvironment.transform 15 54279 env54213 = env54214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env54213 == env54214) = true)

theorem identity54214 : scanCanonicalize (H12AffineFastState.compose env54214 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound54214 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54215 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5124,32768,32771,37940,2080,1025,32769,4113,0,16,34,40,16,34849,5172,4129,2048,1056,32801,36,1,37925,33313]

theorem envBound54215 : H12AffineFastState.Bounded env54215 := by
  intro p hp
  have h : env54215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54214_54215 : H12AffineEnvironment.transform 13 5124 env54214 = env54215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env54214 == env54215) = true)

theorem identity54215 : scanCanonicalize (H12AffineFastState.compose env54215 (packedSelected [2,3,5,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54215 : packedSelected [2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env54216 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,32768,32771,37908,2048,1025,32769,4113,0,16,2,8,16,34817,5140,4097,2048,1024,32769,4,1,37893,33281]

theorem envBound54216 : H12AffineFastState.Bounded env54216 := by
  intro p hp
  have h : env54216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54215_54216 : H12AffineEnvironment.transform 4 0 env54215 = env54216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54215 == env54216) = true)

theorem identity54216 : scanCanonicalize (H12AffineFastState.compose env54216 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54216 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54217 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,1,2,5141,2048,1025,0,4113,0,16,2,8,16,2048,5140,4097,2048,1024,0,4,1,5124,512]

theorem envBound54217 : H12AffineFastState.Bounded env54217 := by
  intro p hp
  have h : env54217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54216_54217 : H12AffineEnvironment.transform 14 1 env54216 = env54217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54216 == env54217) = true)

theorem identity54217 : scanCanonicalize (H12AffineFastState.compose env54217 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound54217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54218 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,4096,8,4113,1,2,4096,2048,20,0,4113,0,16,2,8,16,2048,4097,4097,2048,21,0,4,1,4113,512]

theorem envBound54218 : H12AffineFastState.Bounded env54218 := by
  intro p hp
  have h : env54218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54217_54218 : H12AffineEnvironment.transform 9 21 env54217 = env54218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54217 == env54218) = true)

theorem identity54218 : scanCanonicalize (H12AffineFastState.compose env54218 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound54218 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54219 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,2049,8,2064,1,2,2049,2048,20,0,2064,0,16,2,8,16,2048,2048,2048,2048,21,0,4,1,2064,512]

theorem envBound54219 : H12AffineFastState.Bounded env54219 := by
  intro p hp
  have h : env54219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54218_54219 : H12AffineEnvironment.transform 11 2049 env54218 = env54219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env54218 == env54219) = true)

theorem identity54219 : scanCanonicalize (H12AffineFastState.compose env54219 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 527) := by decide +kernel

theorem selectedBound54219 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54220 : List Nat := [2,4,8,16,0,16,8,5,512,21,527,526,8,543,1,2,526,527,20,0,543,0,16,2,8,16,527,527,527,527,21,0,4,1,543,512]

theorem envBound54220 : H12AffineFastState.Bounded env54220 := by
  intro p hp
  have h : env54220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54219_54220 : H12AffineEnvironment.transform 10 527 env54219 = env54220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 527 env54219 == env54220) = true)

theorem identity54220 : scanCanonicalize (H12AffineFastState.compose env54220 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound54220 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54221 : List Nat := [2,4,8,16,0,16,8,5,14,21,1,0,8,17,1,2,0,1,20,0,17,0,16,2,8,16,1,1,1,1,21,0,4,1,17,14]

theorem envBound54221 : H12AffineFastState.Bounded env54221 := by
  intro p hp
  have h : env54221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54220_54221 : H12AffineEnvironment.transform 8 14 env54220 = env54221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env54220 == env54221) = true)

theorem identity54221 : scanCanonicalize (H12AffineFastState.compose env54221 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54221 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54222 : List Nat := [2,4,8,0,0,0,8,5,14,5,1,0,8,1,1,2,0,1,4,0,1,0,0,2,8,0,1,1,1,1,5,0,4,1,1,14]

theorem envBound54222 : H12AffineFastState.Bounded env54222 := by
  intro p hp
  have h : env54222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54221_54222 : H12AffineEnvironment.transform 3 0 env54221 = env54222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54221 == env54222) = true)

def env54223 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115735,272393,119830,98565,8193,16,75787,114967,17664,360711,119042,329730,257,21792,46092,62988]

theorem envBound54223 : H12AffineFastState.Bounded env54223 := by
  intro p hp
  have h : env54223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54209_54223 : H12AffineEnvironment.transform 6 9 env54209 = env54223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54209 == env54223) = true)

theorem identity54223 : scanCanonicalize (H12AffineFastState.compose env54223 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound54223 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54224 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67619,1025,32769,115735,73770,119830,98565,8193,16,75787,114967,17664,35108,119042,33,257,21792,46092,62988]

theorem envBound54224 : H12AffineFastState.Bounded env54224 := by
  intro p hp
  have h : env54224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54223_54224 : H12AffineEnvironment.transform 17 67619 env54223 = env54224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env54223 == env54224) = true)

theorem identity54224 : scanCanonicalize (H12AffineFastState.compose env54224 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54224 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54225 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,67619,1025,21761,69911,73770,65814,87045,8193,16,75787,70679,17664,23588,66562,33,257,21792,24844,8972]

theorem envBound54225 : H12AffineFastState.Bounded env54225 := by
  intro p hp
  have h : env54225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54224_54225 : H12AffineEnvironment.transform 14 21760 env54224 = env54225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54224 == env54225) = true)

theorem identity54225 : scanCanonicalize (H12AffineFastState.compose env54225 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound54225 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env54226 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,262,16401,2341,1025,21761,4113,8492,16,21763,8193,16,10509,5393,17664,23588,1284,33,257,21792,24844,8972]

theorem envBound54226 : H12AffineFastState.Bounded env54226 := by
  intro p hp
  have h : env54226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54225_54226 : H12AffineEnvironment.transform 15 262 env54225 = env54226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env54225 == env54226) = true)

theorem identity54226 : scanCanonicalize (H12AffineFastState.compose env54226 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54226 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env54227 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,262,13341,2341,1025,8461,4113,8492,16,8463,8193,16,10509,5393,12556,10280,1284,33,257,8492,5376,8972]

theorem envBound54227 : H12AffineFastState.Bounded env54227 := by
  intro p hp
  have h : env54227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54226_54227 : H12AffineEnvironment.transform 13 13324 env54226 = env54227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54226 == env54227) = true)

theorem identity54227 : scanCanonicalize (H12AffineFastState.compose env54227 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound54227 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54228 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1336,4404,1076,262,4389,2341,1025,1077,4113,1044,16,1079,1337,16,3125,5393,5172,3344,1284,33,257,1044,5376,1588]

theorem envBound54228 : H12AffineFastState.Bounded env54228 := by
  intro p hp
  have h : env54228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54227_54228 : H12AffineEnvironment.transform 12 1336 env54227 = env54228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env54227 == env54228) = true)

theorem identity54228 : scanCanonicalize (H12AffineFastState.compose env54228 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54228 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54229 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,1084,4144,1076,2,4129,2081,1025,1077,4113,1044,16,1079,1085,16,3125,5141,5172,3092,1024,33,5,1044,5124,1588]

theorem envBound54229 : H12AffineFastState.Bounded env54229 := by
  intro p hp
  have h : env54229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54228_54229 : H12AffineEnvironment.transform 7 4 env54228 = env54229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54228 == env54229) = true)

theorem identity54229 : scanCanonicalize (H12AffineFastState.compose env54229 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54229 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env54230 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,8,4144,0,2,4129,2081,53,1,4113,32,16,3,9,16,2049,4129,4096,2080,52,33,5,32,4144,512]

theorem envBound54230 : H12AffineFastState.Bounded env54230 := by
  intro p hp
  have h : env54230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54229_54230 : H12AffineEnvironment.transform 9 52 env54229 = env54230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54229 == env54230) = true)

theorem identity54230 : scanCanonicalize (H12AffineFastState.compose env54230 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54231 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,4096,8,4112,0,2,4097,2049,21,1,4113,0,16,3,9,16,2049,4097,4096,2048,20,1,5,0,4112,512]

theorem envBound54231 : H12AffineFastState.Bounded env54231 := by
  intro p hp
  have h : env54231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54230_54231 : H12AffineEnvironment.transform 4 0 env54230 = env54231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54230 == env54231) = true)

theorem identity54231 : scanCanonicalize (H12AffineFastState.compose env54231 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound54231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54232 : List Nat := [2,4,8,16,0,16,9,4,512,20,512,4096,8,4112,0,2,4097,513,21,1,4113,0,16,3,9,16,513,4097,4096,512,20,1,5,0,4112,512]

theorem envBound54232 : H12AffineFastState.Bounded env54232 := by
  intro p hp
  have h : env54232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54231_54232 : H12AffineEnvironment.transform 10 512 env54231 = env54232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env54231 == env54232) = true)

theorem identity54232 : scanCanonicalize (H12AffineFastState.compose env54232 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound54232 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54233 : List Nat := [2,4,8,5,0,5,9,4,512,1,512,4096,8,4101,0,2,4097,513,0,1,4100,0,5,3,9,5,513,4097,4096,512,1,1,5,0,4101,512]

theorem envBound54233 : H12AffineFastState.Bounded env54233 := by
  intro p hp
  have h : env54233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54232_54233 : H12AffineEnvironment.transform 3 5 env54232 = env54233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env54232 == env54233) = true)

def env54234 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,119966,98701,8328,17,75906,115103,17664,360847,119042,329730,257,21792,46213,63108]

theorem envBound54234 : H12AffineFastState.Bounded env54234 := by
  intro p hp
  have h : env54234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54208_54234 : H12AffineEnvironment.transform 5 17 env54208 = env54234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54208 == env54234) = true)

theorem identity54234 : scanCanonicalize (H12AffineFastState.compose env54234 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54234 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env54235 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,115870,168,119966,98701,8328,17,75906,115103,17664,108967,119042,73770,257,21792,46213,63108]

theorem envBound54235 : H12AffineFastState.Bounded env54235 := by
  intro p hp
  have h : env54235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54234_54235 : H12AffineEnvironment.transform 17 10280 env54234 = env54235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54234 == env54235) = true)

theorem identity54235 : scanCanonicalize (H12AffineFastState.compose env54235 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound54235 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54236 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,65536,5528,10280,1025,136,82967,168,87063,65796,8328,17,75906,82198,17664,76078,86411,73770,257,21792,13324,30221]

theorem envBound54236 : H12AffineFastState.Bounded env54236 := by
  intro p hp
  have h : env54236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54235_54236 : H12AffineEnvironment.transform 14 137 env54235 = env54236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env54235 == env54236) = true)

theorem identity54236 : scanCanonicalize (H12AffineFastState.compose env54236 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54236 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env54237 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,65536,5528,10280,1025,136,77851,168,73755,65796,8328,17,75906,79130,12556,76078,75143,73770,257,8492,13324,513]

theorem envBound54237 : H12AffineFastState.Bounded env54237 := by
  intro p hp
  have h : env54237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54236_54237 : H12AffineEnvironment.transform 13 13324 env54236 = env54237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54236 == env54237) = true)

theorem identity54237 : scanCanonicalize (H12AffineFastState.compose env54237 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54237 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,8202,5528,10280,1025,136,4113,168,17,8462,8328,17,2184,5392,12556,2340,1421,32,257,8492,13324,513]

theorem envBound54238 : H12AffineFastState.Bounded env54238 := by
  intro p hp
  have h : env54238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54237_54238 : H12AffineEnvironment.transform 15 8202 env54237 = env54238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54237 == env54238) = true)

theorem identity54238 : scanCanonicalize (H12AffineFastState.compose env54238 (packedSelected [3,4,5,7,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound54238 : packedSelected [3,4,5,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env54239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2493,8192,11697,137,8202,3109,10280,1025,136,2476,168,17,8462,8328,17,2184,3245,10417,2340,1421,32,257,8492,11697,513]

theorem envBound54239 : H12AffineFastState.Bounded env54239 := by
  intro p hp
  have h : env54239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54238_54239 : H12AffineEnvironment.transform 11 2493 env54238 = env54239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env54238 == env54239) = true)

theorem identity54239 : scanCanonicalize (H12AffineFastState.compose env54239 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54239 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54240 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,2200,8192,11412,137,8202,3109,10280,1025,136,2185,168,17,8235,8328,17,2184,3245,10417,2049,1192,32,36,8201,11412,513]

theorem envBound54240 : H12AffineFastState.Bounded env54240 := by
  intro p hp
  have h : env54240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54239_54240 : H12AffineEnvironment.transform 7 37 env54239 = env54240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54239 == env54240) = true)

def env54241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157597,2098512,17664,2377024,2102684,2411677,257,21792,46213,2175563]

theorem envBound54241 : H12AffineFastState.Bounded env54241 := by
  intro p hp
  have h : env54241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54206_54241 : H12AffineEnvironment.transform 21 272513 env54206 = env54241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54206 == env54241) = true)

theorem identity54241 : scanCanonicalize (H12AffineFastState.compose env54241 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound54241 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38161,262144,1025,32769,2097152,272513,2101329,21762,8328,64,2157597,2098512,17664,2377024,2102684,2411677,257,21792,46213,2156181]

theorem envBound54242 : H12AffineFastState.Bounded env54242 := by
  intro p hp
  have h : env54242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54241_54242 : H12AffineEnvironment.transform 15 54494 env54241 = env54242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env54241 == env54242) = true)

def env54243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,2097152,272393,2101329,21762,8192,64,2157597,2098512,17664,2377024,2102548,2411541,257,21792,46093,2156061]

theorem envBound54243 : H12AffineFastState.Bounded env54243 := by
  intro p hp
  have h : env54243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54242_54243 : H12AffineEnvironment.transform 6 8 env54242 = env54243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54242 == env54243) = true)

theorem identity54243 : scanCanonicalize (H12AffineFastState.compose env54243 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 322588) := by decide +kernel

theorem selectedBound54243 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env54244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,322588,272393,326733,21762,8192,64,262145,321868,17664,43356,325896,8201,257,21792,46093,264705]

theorem envBound54244 : H12AffineFastState.Bounded env54244 := by
  intro p hp
  have h : env54244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54243_54244 : H12AffineEnvironment.transform 20 322588 env54243 = env54244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322588 env54243 == env54244) = true)

theorem identity54244 : scanCanonicalize (H12AffineFastState.compose env54244 (packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54244 : packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,54358,38161,262144,1025,32769,314420,264225,318565,21762,40,64,262145,313700,17664,35188,317728,33,257,21792,37925,264705]

theorem envBound54245 : H12AffineFastState.Bounded env54245 := by
  intro p hp
  have h : env54245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54244_54245 : H12AffineEnvironment.transform 12 40 env54244 = env54245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54244 == env54245) = true)

theorem identity54245 : scanCanonicalize (H12AffineFastState.compose env54245 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound54245 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env54246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,372,21794,5221,262144,1025,373,281920,264225,285969,21762,40,64,262145,280592,17664,2048,284756,33,257,21792,5457,264705]

theorem envBound54246 : H12AffineFastState.Bounded env54246 := by
  intro p hp
  have h : env54246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54245_54246 : H12AffineEnvironment.transform 14 372 env54245 = env54246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env54245 == env54246) = true)

theorem identity54246 : scanCanonicalize (H12AffineFastState.compose env54246 (packedSelected [0,2,6,7,12,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 3344) := by decide +kernel

theorem selectedBound54246 : packedSelected [0,2,6,7,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env54247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,372,21794,5221,3344,1025,373,16464,1329,20481,21762,40,64,3345,17664,17664,2048,21828,33,257,21792,5457,1809]

theorem envBound54247 : H12AffineFastState.Bounded env54247 := by
  intro p hp
  have h : env54247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54246_54247 : H12AffineEnvironment.transform 17 3344 env54246 = env54247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3344 env54246 == env54247) = true)

theorem identity54247 : scanCanonicalize (H12AffineFastState.compose env54247 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound54247 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env54248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,40,16384,372,19763,3188,3344,1025,373,16464,1329,18448,19731,40,64,3345,17664,17664,2048,19797,33,257,19761,3392,1809]

theorem envBound54248 : H12AffineFastState.Bounded env54248 := by
  intro p hp
  have h : env54248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54247_54248 : H12AffineEnvironment.transform 11 2065 env54247 = env54248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env54247 == env54248) = true)

theorem identity54248 : scanCanonicalize (H12AffineFastState.compose env54248 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound54248 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,40,293,372,3094,3188,3344,1025,373,373,1329,2357,3126,40,64,3345,1061,1061,2048,3184,33,257,3092,3392,1809]

theorem envBound54249 : H12AffineFastState.Bounded env54249 := by
  intro p hp
  have h : env54249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54248_54249 : H12AffineEnvironment.transform 13 293 env54248 = env54249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env54248 == env54249) = true)

theorem identity54249 : scanCanonicalize (H12AffineFastState.compose env54249 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound54249 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env54250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1281,40,293,372,262,356,0,1025,373,373,1329,1061,294,40,64,1,1061,1061,1296,352,33,257,260,80,1809]

theorem envBound54250 : H12AffineFastState.Bounded env54250 := by
  intro p hp
  have h : env54250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54249_54250 : H12AffineEnvironment.transform 10 1296 env54249 = env54250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env54249 == env54250) = true)

theorem identity54250 : scanCanonicalize (H12AffineFastState.compose env54250 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound54250 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env54251 : List Nat := [2,4,8,16,32,64,8,256,512,321,81,64,40,293,372,262,356,0,320,373,373,112,356,294,40,64,1,356,356,81,352,33,257,260,80,592]

theorem envBound54251 : H12AffineFastState.Bounded env54251 := by
  intro p hp
  have h : env54251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54250_54251 : H12AffineEnvironment.transform 9 321 env54250 = env54251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env54250 == env54251) = true)

theorem identity54251 : scanCanonicalize (H12AffineFastState.compose env54251 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54251 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54252 : List Nat := [2,4,8,16,32,64,8,37,512,100,81,64,40,0,81,35,65,0,101,80,80,112,65,3,40,64,1,65,65,81,69,33,36,33,80,592]

theorem envBound54252 : H12AffineFastState.Bounded env54252 := by
  intro p hp
  have h : env54252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54251_54252 : H12AffineEnvironment.transform 7 37 env54251 = env54252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54251 == env54252) = true)

theorem identity54252 : scanCanonicalize (H12AffineFastState.compose env54252 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound54252 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54253 : List Nat := [2,4,8,16,32,64,8,37,37,100,81,64,40,0,81,35,65,0,101,80,80,112,65,3,40,64,1,65,65,81,69,33,36,33,80,117]

theorem envBound54253 : H12AffineFastState.Bounded env54253 := by
  intro p hp
  have h : env54253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54252_54253 : H12AffineEnvironment.transform 8 37 env54252 = env54253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env54252 == env54253) = true)

theorem identity54253 : scanCanonicalize (H12AffineFastState.compose env54253 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound54253 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54254 : List Nat := [2,4,8,16,32,49,8,37,37,21,32,49,40,0,32,35,48,0,20,33,33,1,48,3,40,49,1,48,48,32,52,33,36,33,33,4]

theorem envBound54254 : H12AffineFastState.Bounded env54254 := by
  intro p hp
  have h : env54254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54253_54254 : H12AffineEnvironment.transform 5 49 env54253 = env54254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env54253 == env54254) = true)

theorem identity54254 : scanCanonicalize (H12AffineFastState.compose env54254 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54254 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54255 : List Nat := [2,4,8,16,0,17,8,5,5,21,0,17,8,0,0,3,16,0,20,1,1,1,16,3,8,17,1,16,16,0,20,1,4,1,1,4]

theorem envBound54255 : H12AffineFastState.Bounded env54255 := by
  intro p hp
  have h : env54255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54254_54255 : H12AffineEnvironment.transform 4 0 env54254 = env54255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54254 == env54255) = true)

theorem identity54255 : scanCanonicalize (H12AffineFastState.compose env54255 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound54255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54256 : List Nat := [2,4,1,16,0,17,1,5,5,21,0,17,1,0,0,3,16,0,20,1,1,1,16,3,1,17,1,16,16,0,20,1,4,1,1,4]

theorem envBound54256 : H12AffineFastState.Bounded env54256 := by
  intro p hp
  have h : env54256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54255_54256 : H12AffineEnvironment.transform 2 1 env54255 = env54256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env54255 == env54256) = true)

theorem identity54256 : scanCanonicalize (H12AffineFastState.compose env54256 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54256 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54257 : List Nat := [2,3,1,16,0,17,1,2,2,18,0,17,1,0,0,3,16,0,19,1,1,1,16,3,1,17,1,16,16,0,19,1,3,1,1,3]

theorem envBound54257 : H12AffineFastState.Bounded env54257 := by
  intro p hp
  have h : env54257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54256_54257 : H12AffineEnvironment.transform 1 3 env54256 = env54257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54256 == env54257) = true)

def env54258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,2097152,272392,2101329,21762,8193,64,2157597,2098512,17664,2377024,2102549,2411540,257,21792,46092,2156060]

theorem envBound54258 : H12AffineFastState.Bounded env54258 := by
  intro p hp
  have h : env54258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54242_54258 : H12AffineEnvironment.transform 6 9 env54242 = env54258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54242 == env54258) = true)

theorem identity54258 : scanCanonicalize (H12AffineFastState.compose env54258 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound54258 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env54259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,17728,272392,21777,21762,8193,64,43357,16400,17664,262144,20565,297300,257,21792,46092,41820]

theorem envBound54259 : H12AffineFastState.Bounded env54259 := by
  intro p hp
  have h : env54259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54258_54259 : H12AffineEnvironment.transform 20 17728 env54258 = env54259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env54258 == env54259) = true)

theorem identity54259 : scanCanonicalize (H12AffineFastState.compose env54259 (packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound54259 : packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env54260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,2420,1025,32769,17728,8572,21777,21762,8193,64,43357,16400,17664,2420,20565,32800,257,21792,46092,41820]

theorem envBound54260 : H12AffineFastState.Bounded env54260 := by
  intro p hp
  have h : env54260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54259_54260 : H12AffineEnvironment.transform 17 2420 env54259 = env54260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env54259 == env54260) = true)

theorem identity54260 : scanCanonicalize (H12AffineFastState.compose env54260 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54260 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env54261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40971,38161,2420,1025,32769,12572,8572,8525,8542,8193,64,43357,13388,12636,2420,9225,32800,257,8572,46092,41820]

theorem envBound54261 : H12AffineFastState.Bounded env54261 := by
  intro p hp
  have h : env54261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54260_54261 : H12AffineEnvironment.transform 13 13404 env54260 = env54261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54260 == env54261) = true)

theorem identity54261 : scanCanonicalize (H12AffineFastState.compose env54261 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54261 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env54262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,5392,2420,1025,0,12572,8572,8525,8542,8193,64,10588,13388,12636,2420,9225,33,257,8572,13325,9053]

theorem envBound54262 : H12AffineFastState.Bounded env54262 := by
  intro p hp
  have h : env54262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54261_54262 : H12AffineEnvironment.transform 14 1 env54261 = env54262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54261 == env54262) = true)

theorem identity54262 : scanCanonicalize (H12AffineFastState.compose env54262 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound54262 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5489,1,295,5392,2420,1025,0,4145,81,96,115,300,64,2161,5473,4209,2420,1316,33,257,81,5408,624]

theorem envBound54263 : H12AffineFastState.Bounded env54263 := by
  intro p hp
  have h : env54263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54262_54263 : H12AffineEnvironment.transform 12 301 env54262 = env54263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env54262 == env54263) = true)

theorem identity54263 : scanCanonicalize (H12AffineFastState.compose env54263 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54263 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54264 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,301,5409,1,295,5392,2340,1025,0,4145,1,48,35,300,16,2081,5425,4129,2340,1316,33,257,1,5408,544]

theorem envBound54264 : H12AffineFastState.Bounded env54264 := by
  intro p hp
  have h : env54264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54263_54264 : H12AffineEnvironment.transform 5 16 env54263 = env54264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54263 == env54264) = true)

theorem identity54264 : scanCanonicalize (H12AffineFastState.compose env54264 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound54264 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env54265 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,821,301,1556,1,295,1573,2340,1025,0,772,1,48,35,300,16,2081,1540,788,2340,1316,33,257,1,1557,544]

theorem envBound54265 : H12AffineFastState.Bounded env54265 := by
  intro p hp
  have h : env54265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54264_54265 : H12AffineEnvironment.transform 11 821 env54264 = env54265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env54264 == env54265) = true)

theorem identity54265 : scanCanonicalize (H12AffineFastState.compose env54265 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound54265 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54266 : List Nat := [2,4,8,16,32,16,9,256,293,1024,2048,16,301,1329,1,295,1280,2340,1025,0,33,1,48,35,300,16,2081,1313,49,2340,1316,33,257,1,1328,261]

theorem envBound54266 : H12AffineFastState.Bounded env54266 := by
  intro p hp
  have h : env54266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54265_54266 : H12AffineEnvironment.transform 8 293 env54265 = env54266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env54265 == env54266) = true)

theorem identity54266 : scanCanonicalize (H12AffineFastState.compose env54266 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54266 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54267 : List Nat := [2,4,8,16,32,16,9,256,293,52,2048,16,301,261,1,295,308,2340,53,0,33,1,48,35,300,16,2081,277,49,2340,272,33,257,1,260,261]

theorem envBound54267 : H12AffineFastState.Bounded env54267 := by
  intro p hp
  have h : env54267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54266_54267 : H12AffineEnvironment.transform 9 52 env54266 = env54267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54266 == env54267) = true)

theorem identity54267 : scanCanonicalize (H12AffineFastState.compose env54267 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54267 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env54268 : List Nat := [2,4,8,16,32,16,9,256,293,52,48,16,301,261,1,295,308,276,53,0,33,1,48,35,300,16,17,277,49,276,272,33,257,1,260,261]

theorem envBound54268 : H12AffineFastState.Bounded env54268 := by
  intro p hp
  have h : env54268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54267_54268 : H12AffineEnvironment.transform 10 48 env54267 = env54268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54267 == env54268) = true)

theorem identity54268 : scanCanonicalize (H12AffineFastState.compose env54268 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54268 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54269 : List Nat := [2,4,8,16,17,16,9,256,276,5,1,16,284,261,1,278,261,276,4,0,16,1,1,18,285,16,17,277,0,276,272,16,257,1,260,261]

theorem envBound54269 : H12AffineFastState.Bounded env54269 := by
  intro p hp
  have h : env54269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54268_54269 : H12AffineEnvironment.transform 4 17 env54268 = env54269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54268 == env54269) = true)

theorem identity54269 : scanCanonicalize (H12AffineFastState.compose env54269 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54270 : List Nat := [2,4,8,16,17,16,9,5,17,5,1,16,25,0,1,19,0,17,4,0,16,1,1,18,24,16,17,16,0,17,21,16,4,1,1,0]

theorem envBound54270 : H12AffineFastState.Bounded env54270 := by
  intro p hp
  have h : env54270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54269_54270 : H12AffineEnvironment.transform 7 5 env54269 = env54270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54269 == env54270) = true)

theorem identity54270 : scanCanonicalize (H12AffineFastState.compose env54270 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54270 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54271 : List Nat := [2,4,8,0,1,0,9,5,1,5,1,0,9,0,1,3,0,1,4,0,0,1,1,2,8,0,1,0,0,1,5,0,4,1,1,0]

theorem envBound54271 : H12AffineFastState.Bounded env54271 := by
  intro p hp
  have h : env54271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54270_54271 : H12AffineEnvironment.transform 3 0 env54270 = env54271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54270 == env54271) = true)

def env54272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound54272 : H12AffineFastState.Bounded env54272 := by
  intro p hp
  have h : env54272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53270_54272 : H12AffineEnvironment.transform 25 65 env53270 = env54272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env53270 == env54272) = true)

def env54273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound54273 : H12AffineFastState.Bounded env54273 := by
  intro p hp
  have h : env54273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54272_54273 : H12AffineEnvironment.transform 26 30393344 env54272 = env54273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env54272 == env54273) = true)

def env54274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound54274 : H12AffineFastState.Bounded env54274 := by
  intro p hp
  have h : env54274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54273_54274 : H12AffineEnvironment.transform 18 1024 env54273 = env54274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env54273 == env54274) = true)

theorem identity54274 : scanCanonicalize (H12AffineFastState.compose env54274 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898592) := by decide +kernel

theorem selectedBound54274 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898592,8328,65,4196384,10898605,10507600,8830976,412720,15117793,256,2493581,2551080,486375]

theorem envBound54275 : H12AffineFastState.Bounded env54275 := by
  intro p hp
  have h : env54275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54274_54275 : H12AffineEnvironment.transform 23 8898592 env54274 = env54275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898592 env54274 == env54275) = true)

def env54276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,8388608,8898592,8328,65,4196384,8393985,8785148,8830976,412720,12645453,256,21793,46212,486375]

theorem envBound54276 : H12AffineFastState.Bounded env54276 := by
  intro p hp
  have h : env54276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54275_54276 : H12AffineEnvironment.transform 20 416172 env54275 = env54276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416172 env54275 == env54276) = true)

def env54277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441640,95496,8328,65,4196384,436265,45524,32040,412720,4606309,256,21793,46212,486375]

theorem envBound54277 : H12AffineFastState.Bounded env54277 := by
  intro p hp
  have h : env54277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54276_54277 : H12AffineEnvironment.transform 22 441640 env54276 = env54277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env54276 == env54277) = true)

def env54278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441640,95496,8328,65,270496,436265,45524,32040,412720,156133,256,21793,46212,486375]

theorem envBound54278 : H12AffineFastState.Bounded env54278 := by
  intro p hp
  have h : env54278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54277_54278 : H12AffineEnvironment.transform 21 272512 env54277 = env54278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54277 == env54278) = true)

theorem identity54278 : scanCanonicalize (H12AffineFastState.compose env54278 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound54278 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,115871,243123,73755,95496,8328,65,245139,79130,45524,32040,119043,156133,256,21793,46212,63188]

theorem envBound54279 : H12AffineFastState.Bounded env54279 := by
  intro p hp
  have h : env54279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54278_54279 : H12AffineEnvironment.transform 17 236851 env54278 = env54279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env54278 == env54279) = true)

def env54280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,67755,1024,32769,115871,73771,73755,95496,8328,65,75787,79130,45524,32040,119043,62589,256,21793,46212,63188]

theorem envBound54280 : H12AffineFastState.Bounded env54280 := by
  intro p hp
  have h : env54280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54279_54280 : H12AffineEnvironment.transform 16 38296 env54279 = env54280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env54279 == env54280) = true)

theorem identity54280 : scanCanonicalize (H12AffineFastState.compose env54280 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound54280 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env54281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38296,64928,1024,32769,12692,54560,54544,32771,8328,65,56576,49169,45524,32040,9224,62589,256,21793,46212,63188]

theorem envBound54281 : H12AffineFastState.Bounded env54281 := by
  intro p hp
  have h : env54281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54280_54281 : H12AffineEnvironment.transform 15 62731 env54280 = env54281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env54280 == env54281) = true)

theorem identity54281 : scanCanonicalize (H12AffineFastState.compose env54281 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54281 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env54282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,64808,1024,32769,12572,54560,54544,32771,8192,65,56576,49169,45404,32040,9224,62589,256,21793,46092,63068]

theorem envBound54282 : H12AffineFastState.Bounded env54282 := by
  intro p hp
  have h : env54282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54281_54282 : H12AffineEnvironment.transform 6 8 env54281 = env54282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54281 == env54282) = true)

theorem identity54282 : scanCanonicalize (H12AffineFastState.compose env54282 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54282 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,33111,38160,35188,1024,32769,12572,41340,41292,32771,8192,65,43356,46157,45404,2420,9224,32801,256,8573,46092,33280]

theorem envBound54283 : H12AffineFastState.Bounded env54283 := by
  intro p hp
  have h : env54283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54282_54283 : H12AffineEnvironment.transform 13 13404 env54282 = env54283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54282 == env54283) = true)

theorem identity54283 : scanCanonicalize (H12AffineFastState.compose env54283 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54283 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env54284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,38160,35188,1024,32769,4160,32800,32784,32771,348,65,34816,38161,36864,2420,1364,32801,256,33,38224,33280]

theorem envBound54284 : H12AffineFastState.Bounded env54284 := by
  intro p hp
  have h : env54284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54283_54284 : H12AffineEnvironment.transform 12 348 env54283 = env54284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54283 == env54284) = true)

theorem identity54284 : scanCanonicalize (H12AffineFastState.compose env54284 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound54284 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,372,35,5220,2048,1024,373,4160,340,356,375,348,65,2420,5221,4468,2420,1364,341,256,33,5156,884]

theorem envBound54285 : H12AffineFastState.Bounded env54285 := by
  intro p hp
  have h : env54285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54284_54285 : H12AffineEnvironment.transform 14 372 env54284 = env54285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env54284 == env54285) = true)

theorem identity54285 : scanCanonicalize (H12AffineFastState.compose env54285 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54285 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env54286 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,0,35,5220,2048,1024,1,4160,32,16,3,40,65,2048,5221,4096,2048,1056,33,116,33,5156,512]

theorem envBound54286 : H12AffineFastState.Bounded env54286 := by
  intro p hp
  have h : env54286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54285_54286 : H12AffineEnvironment.transform 7 116 env54285 = env54286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54285 == env54286) = true)

theorem identity54286 : scanCanonicalize (H12AffineFastState.compose env54286 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound54286 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54287 : List Nat := [2,4,8,16,32,64,8,116,512,1024,122,4096,40,5236,0,35,5220,122,1024,1,4160,32,16,3,40,65,122,5221,4096,122,1056,33,116,33,5156,512]

theorem envBound54287 : H12AffineFastState.Bounded env54287 := by
  intro p hp
  have h : env54287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54286_54287 : H12AffineEnvironment.transform 10 122 env54286 = env54287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env54286 == env54287) = true)

theorem identity54287 : scanCanonicalize (H12AffineFastState.compose env54287 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54288 : List Nat := [2,4,8,16,0,64,8,84,512,1024,90,4096,8,5204,0,3,5188,90,1024,1,4160,0,16,3,8,65,90,5189,4096,90,1024,1,84,1,5124,512]

theorem envBound54288 : H12AffineFastState.Bounded env54288 := by
  intro p hp
  have h : env54288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54287_54288 : H12AffineEnvironment.transform 4 0 env54287 = env54288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54287 == env54288) = true)

theorem identity54288 : scanCanonicalize (H12AffineFastState.compose env54288 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound54288 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54289 : List Nat := [2,4,8,16,0,64,8,84,512,1024,90,0,8,1108,0,3,1092,90,1024,1,64,0,16,3,8,65,90,1093,0,90,1024,1,84,1,1028,512]

theorem envBound54289 : H12AffineFastState.Bounded env54289 := by
  intro p hp
  have h : env54289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54288_54289 : H12AffineEnvironment.transform 11 0 env54288 = env54289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env54288 == env54289) = true)

theorem identity54289 : scanCanonicalize (H12AffineFastState.compose env54289 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54289 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54290 : List Nat := [2,4,2,16,0,64,2,84,512,1024,80,0,2,1108,0,3,1092,80,1024,1,64,0,16,3,2,65,80,1093,0,80,1024,1,84,1,1028,512]

theorem envBound54290 : H12AffineFastState.Bounded env54290 := by
  intro p hp
  have h : env54290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54289_54290 : H12AffineEnvironment.transform 2 2 env54289 = env54290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54289 == env54290) = true)

theorem identity54290 : scanCanonicalize (H12AffineFastState.compose env54290 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54290 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54291 : List Nat := [2,4,2,16,0,64,2,84,512,4,80,0,2,80,0,3,64,80,4,1,64,0,16,3,2,65,80,65,0,80,4,1,84,1,0,512]

theorem envBound54291 : H12AffineFastState.Bounded env54291 := by
  intro p hp
  have h : env54291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54290_54291 : H12AffineEnvironment.transform 9 4 env54290 = env54291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54290 == env54291) = true)

theorem identity54291 : scanCanonicalize (H12AffineFastState.compose env54291 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54291 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54292 : List Nat := [2,0,2,16,0,64,2,80,512,0,80,0,2,80,0,3,64,80,0,1,64,0,16,3,2,65,80,65,0,80,0,1,80,1,0,512]

theorem envBound54292 : H12AffineFastState.Bounded env54292 := by
  intro p hp
  have h : env54292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54291_54292 : H12AffineEnvironment.transform 1 0 env54291 = env54292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54291 == env54292) = true)

theorem identity54292 : scanCanonicalize (H12AffineFastState.compose env54292 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54292 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54293 : List Nat := [2,0,2,16,0,64,2,80,16,0,80,0,2,80,0,3,64,80,0,1,64,0,16,3,2,65,80,65,0,80,0,1,80,1,0,16]

theorem envBound54293 : H12AffineFastState.Bounded env54293 := by
  intro p hp
  have h : env54293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54292_54293 : H12AffineEnvironment.transform 8 16 env54292 = env54293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54292 == env54293) = true)

theorem identity54293 : scanCanonicalize (H12AffineFastState.compose env54293 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound54293 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54294 : List Nat := [2,0,2,16,0,2,2,18,16,0,18,0,2,18,0,3,2,18,0,1,2,0,16,3,2,3,18,3,0,18,0,1,18,1,0,16]

theorem envBound54294 : H12AffineFastState.Bounded env54294 := by
  intro p hp
  have h : env54294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54293_54294 : H12AffineEnvironment.transform 5 2 env54293 = env54294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env54293 == env54294) = true)

def env54295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,67754,1024,32769,115871,73770,73755,95496,8328,65,75786,79130,45524,32040,119043,62588,256,21793,46212,63188]

theorem envBound54295 : H12AffineFastState.Bounded env54295 := by
  intro p hp
  have h : env54295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54279_54295 : H12AffineEnvironment.transform 16 38297 env54279 = env54295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env54279 == env54295) = true)

theorem identity54295 : scanCanonicalize (H12AffineFastState.compose env54295 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound54295 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env54296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,38297,56573,1024,32769,4296,62589,62540,41311,8328,65,64605,57677,45524,32040,1364,62588,256,21793,46212,63188]

theorem envBound54296 : H12AffineFastState.Bounded env54296 := by
  intro p hp
  have h : env54296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54295_54296 : H12AffineEnvironment.transform 15 54359 env54295 = env54296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env54295 == env54296) = true)

theorem identity54296 : scanCanonicalize (H12AffineFastState.compose env54296 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54296 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,343,16537,2557,1024,21761,4296,8573,8524,29791,8328,65,10589,13389,25812,32040,1364,8572,256,21793,24964,9172]

theorem envBound54297 : H12AffineFastState.Bounded env54297 := by
  intro p hp
  have h : env54297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54296_54297 : H12AffineEnvironment.transform 14 21760 env54296 = env54297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54296 == env54297) = true)

theorem identity54297 : scanCanonicalize (H12AffineFastState.compose env54297 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,18,19,35] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound54297 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,18,19,35] rootPS < 2^1333 := by decide +kernel

def env54298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8660,343,13389,2557,1024,8661,4296,8573,8524,139,8328,65,10589,13389,4096,2556,1364,8572,256,8693,5456,9172]

theorem envBound54298 : H12AffineFastState.Bounded env54298 := by
  intro p hp
  have h : env54298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54297_54298 : H12AffineEnvironment.transform 13 13524 env54297 = env54298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env54297 == env54298) = true)

theorem identity54298 : scanCanonicalize (H12AffineFastState.compose env54298 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54298 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,343,13389,2420,1024,8540,4161,8573,8524,2,8193,65,10589,13389,4096,2421,1364,8572,256,8572,5456,9053]

theorem envBound54299 : H12AffineFastState.Bounded env54299 := by
  intro p hp
  have h : env54299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54298_54299 : H12AffineEnvironment.transform 6 9 env54298 = env54299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54298 == env54299) = true)

theorem identity54299 : scanCanonicalize (H12AffineFastState.compose env54299 (packedSelected [1,2,5,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound54299 : packedSelected [1,2,5,10,11] rootPS < 2^1333 := by decide +kernel

def env54300 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,8192,12604,8541,343,12588,2420,353,8540,4161,8573,8524,2,8193,65,10589,12588,4096,2421,53,8572,256,8572,4145,9053]

theorem envBound54300 : H12AffineFastState.Bounded env54300 := by
  intro p hp
  have h : env54300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54299_54300 : H12AffineEnvironment.transform 9 353 env54299 = env54300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env54299 == env54300) = true)

theorem identity54300 : scanCanonicalize (H12AffineFastState.compose env54300 (packedSelected [0,2,5,6,7,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound54300 : packedSelected [0,2,5,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54301 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,88,4452,261,343,4468,2420,353,260,4161,293,276,2,89,65,2309,4468,4096,2421,53,292,256,292,4145,773]

theorem envBound54301 : H12AffineFastState.Bounded env54301 := by
  intro p hp
  have h : env54301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54300_54301 : H12AffineEnvironment.transform 12 88 env54300 = env54301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env54300 == env54301) = true)

theorem identity54301 : scanCanonicalize (H12AffineFastState.compose env54301 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound54301 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54302 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,2144,88,2308,261,343,2324,2420,353,260,2081,293,276,2,89,65,2309,2324,2144,2421,53,292,256,292,2129,773]

theorem envBound54302 : H12AffineFastState.Bounded env54302 := by
  intro p hp
  have h : env54302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54301_54302 : H12AffineEnvironment.transform 11 2144 env54301 = env54302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env54301 == env54302) = true)

theorem identity54302 : scanCanonicalize (H12AffineFastState.compose env54302 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound54302 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54303 : List Nat := [2,4,8,16,32,64,9,85,512,52,2048,2144,88,2129,80,2,2113,2081,52,81,2081,112,65,2,89,65,2128,2113,2144,2080,53,113,85,113,2129,592]

theorem envBound54303 : H12AffineFastState.Bounded env54303 := by
  intro p hp
  have h : env54303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54302_54303 : H12AffineEnvironment.transform 7 85 env54302 = env54303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env54302 == env54303) = true)

theorem identity54303 : scanCanonicalize (H12AffineFastState.compose env54303 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54303 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env54304 : List Nat := [2,4,8,16,32,64,9,85,512,52,0,96,88,81,80,2,65,33,52,81,33,112,65,2,89,65,80,65,96,32,53,113,85,113,81,592]

theorem envBound54304 : H12AffineFastState.Bounded env54304 := by
  intro p hp
  have h : env54304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54303_54304 : H12AffineEnvironment.transform 10 0 env54303 = env54304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54303 == env54304) = true)

theorem identity54304 : scanCanonicalize (H12AffineFastState.compose env54304 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound54304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54305 : List Nat := [2,4,8,16,32,49,9,36,512,52,0,17,41,32,33,2,48,33,52,32,33,1,48,2,40,48,33,48,17,32,53,0,36,0,32,545]

theorem envBound54305 : H12AffineFastState.Bounded env54305 := by
  intro p hp
  have h : env54305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54304_54305 : H12AffineEnvironment.transform 5 49 env54304 = env54305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env54304 == env54305) = true)

theorem identity54305 : scanCanonicalize (H12AffineFastState.compose env54305 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound54305 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env54306 : List Nat := [2,4,8,16,32,49,9,36,17,52,0,17,41,32,33,2,48,33,52,32,33,1,48,2,40,48,33,48,17,32,53,0,36,0,32,48]

theorem envBound54306 : H12AffineFastState.Bounded env54306 := by
  intro p hp
  have h : env54306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54305_54306 : H12AffineEnvironment.transform 8 17 env54305 = env54306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env54305 == env54306) = true)

def env54307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441640,95496,8328,65,270497,436265,45524,32040,412720,156132,256,21793,46212,486375]

theorem envBound54307 : H12AffineFastState.Bounded env54307 := by
  intro p hp
  have h : env54307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54277_54307 : H12AffineEnvironment.transform 21 272513 env54277 = env54307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54277 == env54307) = true)

theorem identity54307 : scanCanonicalize (H12AffineFastState.compose env54307 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54307 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416172,272513,441640,21763,8328,65,270497,436265,45524,32040,412720,156132,256,21793,46212,412652]

theorem envBound54308 : H12AffineFastState.Bounded env54308 := by
  intro p hp
  have h : env54308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54307_54308 : H12AffineEnvironment.transform 15 8203 env54307 = env54308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54307 == env54308) = true)

def env54309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416036,272393,441640,21763,8192,65,270377,436265,45404,32040,412720,156012,256,21793,46092,412516]

theorem envBound54309 : H12AffineFastState.Bounded env54309 := by
  intro p hp
  have h : env54309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54308_54309 : H12AffineEnvironment.transform 6 8 env54308 = env54309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54308 == env54309) = true)

theorem identity54309 : scanCanonicalize (H12AffineFastState.compose env54309 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54309 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env54310 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,415825,272393,441437,21622,8192,65,270377,436265,45097,31837,412720,155673,117,21588,46092,412177]

theorem envBound54310 : H12AffineFastState.Bounded env54310 := by
  intro p hp
  have h : env54310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54309_54310 : H12AffineEnvironment.transform 7 117 env54309 = env54310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54309 == env54310) = true)

theorem identity54310 : scanCanonicalize (H12AffineFastState.compose env54310 (packedSelected [2,3,5,7,10,11,12,15,19,20,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound54310 : packedSelected [2,3,5,7,10,11,12,15,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env54311 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,23669,1024,32769,132132,29820,188456,21622,8192,65,31836,193628,45097,31837,135237,155673,117,21588,46092,136804]

theorem envBound54311 : H12AffineFastState.Bounded env54311 := by
  intro p hp
  have h : env54311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54310_54311 : H12AffineEnvironment.transform 17 23669 env54310 = env54311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env54310 == env54311) = true)

theorem identity54311 : scanCanonicalize (H12AffineFastState.compose env54311 (packedSelected [0,1,3,4,5,6,7,8,9,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound54311 : packedSelected [0,1,3,4,5,6,7,8,9,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env54312 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,8203,131072,23669,1024,8233,132132,29820,147456,21622,8192,65,31836,152692,4097,31837,135237,155673,117,21588,5156,136804]

theorem envBound54312 : H12AffineFastState.Bounded env54312 := by
  intro p hp
  have h : env54312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54311_54312 : H12AffineEnvironment.transform 14 8232 env54311 = env54312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env54311 == env54312) = true)

theorem identity54312 : scanCanonicalize (H12AffineFastState.compose env54312 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54312 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env54313 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,35,131072,23669,1024,1,132132,21588,147456,21622,40,65,23668,152692,4097,23669,135237,147505,117,21588,5156,136804]

theorem envBound54313 : H12AffineFastState.Bounded env54313 := by
  intro p hp
  have h : env54313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54312_54313 : H12AffineEnvironment.transform 12 40 env54312 = env54313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54312 == env54313) = true)

theorem identity54313 : scanCanonicalize (H12AffineFastState.compose env54313 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound54313 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54314 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,35,131072,2048,1024,1,132132,33,136309,3,40,65,2049,131073,4097,2048,135237,136260,117,33,5156,136804]

theorem envBound54314 : H12AffineFastState.Bounded env54314 := by
  intro p hp
  have h : env54314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54313_54314 : H12AffineEnvironment.transform 13 5237 env54313 = env54314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env54313 == env54314) = true)

theorem identity54314 : scanCanonicalize (H12AffineFastState.compose env54314 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(16+1) ^^^ 3108) := by decide +kernel

theorem selectedBound54314 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env54315 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,35,3108,2048,1024,1,2048,33,6225,3,40,65,2049,3109,4097,2048,7265,6240,117,33,5156,6720]

theorem envBound54315 : H12AffineFastState.Bounded env54315 := by
  intro p hp
  have h : env54315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54314_54315 : H12AffineEnvironment.transform 16 3108 env54314 = env54315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3108 env54314 == env54315) = true)

theorem identity54315 : scanCanonicalize (H12AffineFastState.compose env54315 (packedSelected [0,1,4,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound54315 : packedSelected [0,1,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env54316 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,40,2049,0,35,3108,2048,1024,1,2048,33,1061,3,40,65,2049,3109,3189,2048,21,1044,117,33,2128,1588]

theorem envBound54316 : H12AffineFastState.Bounded env54316 := by
  intro p hp
  have h : env54316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54315_54316 : H12AffineEnvironment.transform 11 3188 env54315 = env54316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env54315 == env54316) = true)

theorem identity54316 : scanCanonicalize (H12AffineFastState.compose env54316 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54316 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env54317 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2113,40,2049,0,35,2065,2048,53,1,2048,33,16,3,40,65,2049,2064,2112,2048,21,33,117,33,2128,513]

theorem envBound54317 : H12AffineFastState.Bounded env54317 := by
  intro p hp
  have h : env54317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54316_54317 : H12AffineEnvironment.transform 9 53 env54316 = env54317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54316 == env54317) = true)

theorem identity54317 : scanCanonicalize (H12AffineFastState.compose env54317 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound54317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54318 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,17,40,81,0,35,65,80,53,1,80,33,16,3,40,65,81,64,16,80,21,33,117,33,0,513]

theorem envBound54318 : H12AffineFastState.Bounded env54318 := by
  intro p hp
  have h : env54318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54317_54318 : H12AffineEnvironment.transform 10 80 env54317 = env54318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env54317 == env54318) = true)

theorem identity54318 : scanCanonicalize (H12AffineFastState.compose env54318 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54318 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54319 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,17,40,1,0,35,17,0,53,1,0,33,16,3,40,17,1,16,16,0,21,33,37,33,0,513]

theorem envBound54319 : H12AffineFastState.Bounded env54319 := by
  intro p hp
  have h : env54319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54318_54319 : H12AffineEnvironment.transform 5 16 env54318 = env54319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54318 == env54319) = true)

theorem identity54319 : scanCanonicalize (H12AffineFastState.compose env54319 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54320 : List Nat := [2,4,8,16,32,16,8,37,48,53,0,17,40,1,0,35,17,0,53,1,0,33,16,3,40,17,1,16,16,0,21,33,37,33,0,49]

theorem envBound54320 : H12AffineFastState.Bounded env54320 := by
  intro p hp
  have h : env54320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54319_54320 : H12AffineEnvironment.transform 8 48 env54319 = env54320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54319 == env54320) = true)

theorem identity54320 : scanCanonicalize (H12AffineFastState.compose env54320 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54321 : List Nat := [2,4,8,0,32,0,8,37,32,37,0,1,40,1,0,35,1,0,37,1,0,33,0,3,40,1,1,0,0,0,5,33,37,33,0,33]

theorem envBound54321 : H12AffineFastState.Bounded env54321 := by
  intro p hp
  have h : env54321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54320_54321 : H12AffineEnvironment.transform 3 0 env54320 = env54321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54320 == env54321) = true)

def env54322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416037,272392,441640,21763,8193,65,270376,436265,45405,32040,412720,156013,256,21793,46093,412517]

theorem envBound54322 : H12AffineFastState.Bounded env54322 := by
  intro p hp
  have h : env54322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54308_54322 : H12AffineEnvironment.transform 6 9 env54308 = env54322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54308 == env54322) = true)

theorem identity54322 : scanCanonicalize (H12AffineFastState.compose env54322 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound54322 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env54323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,171109,1024,32769,50496,177261,8525,21763,8193,65,179277,13388,45405,32040,53333,156013,256,21793,46093,55040]

theorem envBound54323 : H12AffineFastState.Bounded env54323 := by
  intro p hp
  have h : env54323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54322_54323 : H12AffineEnvironment.transform 17 171109 env54322 = env54323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env54322 == env54323) = true)

theorem identity54323 : scanCanonicalize (H12AffineFastState.compose env54323 (packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound54323 : packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env54324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,5393,35188,1024,32769,50496,41340,8525,21763,8193,65,43356,13388,45405,32040,53333,29820,256,21793,46093,55040]

theorem envBound54324 : H12AffineFastState.Bounded env54324 := by
  intro p hp
  have h : env54324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54323_54324 : H12AffineEnvironment.transform 16 5393 env54323 = env54324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env54323 == env54324) = true)

theorem identity54324 : scanCanonicalize (H12AffineFastState.compose env54324 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound54324 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env54325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,5393,23669,1024,21760,4161,29821,8525,21763,8193,65,31837,13388,25692,32040,1364,29820,256,21793,24844,513]

theorem envBound54325 : H12AffineFastState.Bounded env54325 := by
  intro p hp
  have h : env54325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54324_54325 : H12AffineEnvironment.transform 14 21761 env54324 = env54325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env54324 == env54325) = true)

theorem identity54325 : scanCanonicalize (H12AffineFastState.compose env54325 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54325 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,5393,10281,1024,8540,4161,33,8525,8543,8193,65,2049,13388,4096,2420,1364,32,256,8573,5456,513]

theorem envBound54326 : H12AffineFastState.Bounded env54326 := by
  intro p hp
  have h : env54326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54325_54326 : H12AffineEnvironment.transform 13 13404 env54325 = env54326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54325 == env54326) = true)

theorem identity54326 : scanCanonicalize (H12AffineFastState.compose env54326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54327 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12621,8541,8203,4096,10281,273,8540,4161,33,8525,8543,8193,65,2049,12637,4096,2420,69,32,256,8573,4161,513]

theorem envBound54327 : H12AffineFastState.Bounded env54327 := by
  intro p hp
  have h : env54327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54326_54327 : H12AffineEnvironment.transform 9 273 env54326 = env54327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54326 == env54327) = true)

theorem identity54327 : scanCanonicalize (H12AffineFastState.compose env54327 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound54327 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54328 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,4201,292,4404,4194,4096,6208,273,4405,4161,33,4388,4406,4200,65,2049,308,4096,2420,69,32,256,4372,4161,513]

theorem envBound54328 : H12AffineFastState.Bounded env54328 := by
  intro p hp
  have h : env54328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54327_54328 : H12AffineEnvironment.transform 12 4201 env54327 = env54328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env54327 == env54328) = true)

theorem identity54328 : scanCanonicalize (H12AffineFastState.compose env54328 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54328 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env54329 : List Nat := [2,4,8,16,32,64,9,256,512,273,0,4096,4201,292,4404,4194,4096,4160,273,4405,4161,33,4388,4406,4200,65,1,308,4096,372,69,32,256,4372,4161,513]

theorem envBound54329 : H12AffineFastState.Bounded env54329 := by
  intro p hp
  have h : env54329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54328_54329 : H12AffineEnvironment.transform 10 0 env54328 = env54329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54328 == env54329) = true)

theorem identity54329 : scanCanonicalize (H12AffineFastState.compose env54329 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound54329 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env54330 : List Nat := [2,4,8,16,32,64,9,256,512,273,0,309,348,292,1,343,309,373,273,0,372,33,17,3,349,65,1,308,309,372,69,32,256,33,372,513]

theorem envBound54330 : H12AffineFastState.Bounded env54330 := by
  intro p hp
  have h : env54330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54329_54330 : H12AffineEnvironment.transform 11 309 env54329 = env54330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env54329 == env54330) = true)

theorem identity54330 : scanCanonicalize (H12AffineFastState.compose env54330 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54330 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54331 : List Nat := [2,4,8,16,32,64,9,117,512,100,0,64,41,81,1,34,64,0,100,0,1,33,17,3,40,65,1,65,64,1,69,32,117,33,1,513]

theorem envBound54331 : H12AffineFastState.Bounded env54331 := by
  intro p hp
  have h : env54331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54330_54331 : H12AffineEnvironment.transform 7 117 env54330 = env54331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54330 == env54331) = true)

theorem identity54331 : scanCanonicalize (H12AffineFastState.compose env54331 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound54331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54332 : List Nat := [2,4,8,16,32,20,9,33,512,48,0,20,41,5,1,34,20,0,48,0,1,33,17,3,40,21,1,21,20,1,17,32,33,33,1,513]

theorem envBound54332 : H12AffineFastState.Bounded env54332 := by
  intro p hp
  have h : env54332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54331_54332 : H12AffineEnvironment.transform 5 20 env54331 = env54332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env54331 == env54332) = true)

theorem identity54332 : scanCanonicalize (H12AffineFastState.compose env54332 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound54332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54333 : List Nat := [2,4,8,16,32,20,9,33,18,48,0,20,41,5,1,34,20,0,48,0,1,33,17,3,40,21,1,21,20,1,17,32,33,33,1,19]

theorem envBound54333 : H12AffineFastState.Bounded env54333 := by
  intro p hp
  have h : env54333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54332_54333 : H12AffineEnvironment.transform 8 18 env54332 = env54333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env54332 == env54333) = true)

theorem identity54333 : scanCanonicalize (H12AffineFastState.compose env54333 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54333 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54334 : List Nat := [2,4,8,13,32,9,9,33,15,45,0,9,41,5,1,34,9,0,45,0,1,33,12,3,40,8,1,8,9,1,12,32,33,33,1,14]

theorem envBound54334 : H12AffineFastState.Bounded env54334 := by
  intro p hp
  have h : env54334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54333_54334 : H12AffineEnvironment.transform 3 13 env54333 = env54334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54333 == env54334) = true)

theorem identity54334 : scanCanonicalize (H12AffineFastState.compose env54334 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound54334 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54335 : List Nat := [2,4,8,13,5,9,9,4,15,8,0,9,12,5,1,7,9,0,8,0,1,4,12,3,13,8,1,8,9,1,12,5,4,4,1,14]

theorem envBound54335 : H12AffineFastState.Bounded env54335 := by
  intro p hp
  have h : env54335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54334_54335 : H12AffineEnvironment.transform 4 5 env54334 = env54335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env54334 == env54335) = true)

def env54336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441641,95497,8328,65,4196384,436264,45525,32041,412720,4606308,256,21793,46212,486375]

theorem envBound54336 : H12AffineFastState.Bounded env54336 := by
  intro p hp
  have h : env54336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54276_54336 : H12AffineEnvironment.transform 22 441641 env54276 = env54336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env54276 == env54336) = true)

def env54337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441641,95497,8328,65,270496,436264,45525,32041,412720,156132,256,21793,46212,486375]

theorem envBound54337 : H12AffineFastState.Bounded env54337 := by
  intro p hp
  have h : env54337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54336_54337 : H12AffineEnvironment.transform 21 272512 env54336 = env54337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54336 == env54337) = true)

theorem identity54337 : scanCanonicalize (H12AffineFastState.compose env54337 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound54337 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,77898,213350,120015,95497,8328,65,215366,115150,45525,32041,75222,156132,256,21793,46212,513]

theorem envBound54338 : H12AffineFastState.Bounded env54338 := by
  intro p hp
  have h : env54338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54337_54338 : H12AffineEnvironment.transform 17 223718 env54337 = env54338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env54337 == env54338) = true)

def env54339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77898,213350,119879,95497,8192,65,215366,115014,45405,32041,75102,156012,256,21793,46092,513]

theorem envBound54339 : H12AffineFastState.Bounded env54339 := by
  intro p hp
  have h : env54339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54338_54339 : H12AffineEnvironment.transform 6 8 env54338 = env54339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54338 == env54339) = true)

theorem identity54339 : scanCanonicalize (H12AffineFastState.compose env54339 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54339 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2421,1024,32769,77898,8573,119879,95497,8192,65,10589,115014,45405,32041,75102,65911,256,21793,46092,513]

theorem envBound54340 : H12AffineFastState.Bounded env54340 := by
  intro p hp
  have h : env54340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54339_54340 : H12AffineEnvironment.transform 16 90139 env54339 = env54340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54339 == env54340) = true)

theorem identity54340 : scanCanonicalize (H12AffineFastState.compose env54340 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound54340 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env54341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,90139,2421,1024,29708,77898,8573,73802,95497,8192,65,10589,79179,17744,32041,75102,65911,256,21793,16385,513]

theorem envBound54341 : H12AffineFastState.Bounded env54341 := by
  intro p hp
  have h : env54341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54340_54341 : H12AffineEnvironment.transform 14 29709 env54340 = env54341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env54340 == env54341) = true)

theorem identity54341 : scanCanonicalize (H12AffineFastState.compose env54341 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound54341 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,29963,5392,2421,1024,29708,17729,8573,21825,2,8192,65,10589,16448,17744,32041,20565,29820,256,21793,16385,513]

theorem envBound54342 : H12AffineFastState.Bounded env54342 := by
  intro p hp
  have h : env54342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54341_54342 : H12AffineEnvironment.transform 15 29963 env54341 = env54342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env54341 == env54342) = true)

theorem identity54342 : scanCanonicalize (H12AffineFastState.compose env54342 (packedSelected [2,3,5,6,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound54342 : packedSelected [2,3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21620,21874,5392,2421,1024,21621,17729,260,21825,2,121,65,2340,16448,17744,23888,20565,21509,256,21793,16385,513]

theorem envBound54343 : H12AffineFastState.Bounded env54343 := by
  intro p hp
  have h : env54343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54342_54343 : H12AffineEnvironment.transform 12 121 env54342 = env54343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env54342 == env54343) = true)

theorem identity54343 : scanCanonicalize (H12AffineFastState.compose env54343 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54343 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54344 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,16384,21541,21795,5392,2340,1024,21540,17680,260,21776,2,40,16,2340,16401,17665,23809,20484,21509,256,21793,16385,513]

theorem envBound54344 : H12AffineFastState.Bounded env54344 := by
  intro p hp
  have h : env54344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54343_54344 : H12AffineEnvironment.transform 5 17 env54343 = env54344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54343 == env54344) = true)

theorem identity54344 : scanCanonicalize (H12AffineFastState.compose env54344 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound54344 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54345 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5156,1,263,5392,2340,1024,0,4404,260,308,2,40,16,2340,5173,4389,2341,1056,33,256,261,5157,513]

theorem envBound54345 : H12AffineFastState.Bounded env54345 := by
  intro p hp
  have h : env54345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54344_54345 : H12AffineEnvironment.transform 13 5156 env54344 = env54345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env54344 == env54345) = true)

theorem identity54345 : scanCanonicalize (H12AffineFastState.compose env54345 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound54345 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54346 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,40,2048,1,263,2356,2340,1024,0,3344,260,308,2,40,16,2340,2065,3329,2341,1056,33,256,261,2049,513]

theorem envBound54346 : H12AffineFastState.Bounded env54346 := by
  intro p hp
  have h : env54346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54345_54346 : H12AffineEnvironment.transform 11 3108 env54345 = env54346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env54345 == env54346) = true)

theorem identity54346 : scanCanonicalize (H12AffineFastState.compose env54346 (packedSelected [1,3,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54346 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env54347 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,40,2048,1,34,2065,2049,1024,0,3125,33,17,2,40,16,2049,2065,3108,2048,1056,33,37,32,2049,513]

theorem envBound54347 : H12AffineFastState.Bounded env54347 := by
  intro p hp
  have h : env54347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54346_54347 : H12AffineEnvironment.transform 7 37 env54346 = env54347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54346 == env54347) = true)

theorem identity54347 : scanCanonicalize (H12AffineFastState.compose env54347 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54348 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2065,40,2048,1,34,2065,2049,53,0,2048,33,17,2,40,16,2049,2065,2065,2048,21,33,37,32,2049,513]

theorem envBound54348 : H12AffineFastState.Bounded env54348 := by
  intro p hp
  have h : env54348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54347_54348 : H12AffineEnvironment.transform 9 53 env54347 = env54348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54347 == env54348) = true)

theorem identity54348 : scanCanonicalize (H12AffineFastState.compose env54348 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound54348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54349 : List Nat := [2,4,8,16,32,17,8,37,512,53,17,0,40,17,1,34,0,16,53,0,17,33,17,2,40,16,16,0,0,17,21,33,37,32,16,513]

theorem envBound54349 : H12AffineFastState.Bounded env54349 := by
  intro p hp
  have h : env54349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54348_54349 : H12AffineEnvironment.transform 10 17 env54348 = env54349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env54348 == env54349) = true)

theorem identity54349 : scanCanonicalize (H12AffineFastState.compose env54349 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound54349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54350 : List Nat := [2,4,8,16,32,17,8,37,27,53,17,0,40,17,1,34,0,16,53,0,17,33,17,2,40,16,16,0,0,17,21,33,37,32,16,26]

theorem envBound54350 : H12AffineFastState.Bounded env54350 := by
  intro p hp
  have h : env54350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54349_54350 : H12AffineEnvironment.transform 8 27 env54349 = env54350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env54349 == env54350) = true)

def env54351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213350,119878,95497,8193,65,215366,115015,45404,32041,75103,156013,256,21793,46093,513]

theorem envBound54351 : H12AffineFastState.Bounded env54351 := by
  intro p hp
  have h : env54351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54338_54351 : H12AffineEnvironment.transform 6 9 env54338 = env54351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54338 == env54351) = true)

theorem identity54351 : scanCanonicalize (H12AffineFastState.compose env54351 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound54351 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env54352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,77898,33,119878,95497,8193,65,2049,115015,45404,32041,75103,73770,256,21793,46093,513]

theorem envBound54352 : H12AffineFastState.Bounded env54352 := by
  intro p hp
  have h : env54352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54351_54352 : H12AffineEnvironment.transform 16 82247 env54351 = env54352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env54351 == env54352) = true)

theorem identity54352 : scanCanonicalize (H12AffineFastState.compose env54352 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54352 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env54353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,82247,10280,1024,0,77898,33,87111,95497,8193,65,2049,82246,12637,32041,75103,73770,256,21793,13324,513]

theorem envBound54353 : H12AffineFastState.Bounded env54353 := by
  intro p hp
  have h : env54353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54352_54353 : H12AffineEnvironment.transform 14 1 env54352 = env54353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54352 == env54353) = true)

theorem identity54353 : scanCanonicalize (H12AffineFastState.compose env54353 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54353 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,65536,82247,2421,1024,0,69911,33,87111,87124,348,65,2049,82246,4096,23668,66562,65911,256,21793,5457,513]

theorem envBound54354 : H12AffineFastState.Bounded env54354 := by
  intro p hp
  have h : env54354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54353_54354 : H12AffineEnvironment.transform 12 349 env54353 = env54354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54353 == env54354) = true)

theorem identity54354 : scanCanonicalize (H12AffineFastState.compose env54354 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound54354 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,21510,5441,2421,1024,0,17681,33,65,82,348,65,2049,5440,4096,23668,20484,21873,256,21793,5457,513]

theorem envBound54355 : H12AffineFastState.Bounded env54355 := by
  intro p hp
  have h : env54355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54354_54355 : H12AffineEnvironment.transform 15 21510 env54354 = env54355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env54354 == env54355) = true)

theorem identity54355 : scanCanonicalize (H12AffineFastState.compose env54355 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54355 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,262,5441,2421,1024,0,4113,33,65,82,348,65,2049,5440,4096,2420,1284,113,256,33,5457,513]

theorem envBound54356 : H12AffineFastState.Bounded env54356 := by
  intro p hp
  have h : env54356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54355_54356 : H12AffineEnvironment.transform 13 5376 env54355 = env54356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54355 == env54356) = true)

theorem identity54356 : scanCanonicalize (H12AffineFastState.compose env54356 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54356 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1024,0,4113,33,16,3,269,16,2049,5393,4096,2341,1284,32,256,33,5376,513]

theorem envBound54357 : H12AffineFastState.Bounded env54357 := by
  intro p hp
  have h : env54357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54356_54357 : H12AffineEnvironment.transform 5 17 env54356 = env54357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54356 == env54357) = true)

theorem identity54357 : scanCanonicalize (H12AffineFastState.compose env54357 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54358 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,1,262,4388,2340,52,0,4113,33,16,3,269,16,2049,4389,4096,2341,304,32,256,33,4404,513]

theorem envBound54358 : H12AffineFastState.Bounded env54358 := by
  intro p hp
  have h : env54358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54357_54358 : H12AffineEnvironment.transform 9 52 env54357 = env54358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54357 == env54358) = true)

theorem identity54358 : scanCanonicalize (H12AffineFastState.compose env54358 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound54358 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54359 : List Nat := [2,4,8,16,32,17,9,256,512,52,523,4096,268,4404,1,262,4388,815,52,0,4113,33,16,3,269,16,522,4389,4096,814,304,32,256,33,4404,513]

theorem envBound54359 : H12AffineFastState.Bounded env54359 := by
  intro p hp
  have h : env54359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54358_54359 : H12AffineEnvironment.transform 10 523 env54358 = env54359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env54358 == env54359) = true)

theorem identity54359 : scanCanonicalize (H12AffineFastState.compose env54359 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound54359 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54360 : List Nat := [2,4,8,16,32,17,9,256,512,52,523,798,268,554,1,262,570,815,52,0,783,33,16,3,269,16,522,571,798,814,304,32,256,33,554,513]

theorem envBound54360 : H12AffineFastState.Bounded env54360 := by
  intro p hp
  have h : env54360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54359_54360 : H12AffineEnvironment.transform 11 798 env54359 = env54360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env54359 == env54360) = true)

def env54361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441641,95497,8328,65,270497,436264,45525,32041,412720,156133,256,21793,46212,486375]

theorem envBound54361 : H12AffineFastState.Bounded env54361 := by
  intro p hp
  have h : env54361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54336_54361 : H12AffineEnvironment.transform 21 272513 env54336 = env54361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54336 == env54361) = true)

theorem identity54361 : scanCanonicalize (H12AffineFastState.compose env54361 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound54361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,416172,272513,441641,41430,8328,65,270497,436264,45525,32041,412720,156133,256,21793,46212,442168]

theorem envBound54362 : H12AffineFastState.Bounded env54362 := by
  intro p hp
  have h : env54362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54361_54362 : H12AffineEnvironment.transform 15 54495 env54361 = env54362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env54361 == env54362) = true)

def env54363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416036,272393,441641,41310,8192,65,270377,436264,45405,32041,412720,156013,256,21793,46092,442168]

theorem envBound54363 : H12AffineFastState.Bounded env54363 := by
  intro p hp
  have h : env54363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54362_54363 : H12AffineEnvironment.transform 6 8 env54362 = env54363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54362 == env54363) = true)

theorem identity54363 : scanCanonicalize (H12AffineFastState.compose env54363 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 149521) := by decide +kernel

theorem selectedBound54363 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env54364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149521,1024,32769,4405,155672,62776,41310,8192,65,157752,57401,45405,32041,1057,156013,256,21793,46092,63273]

theorem envBound54364 : H12AffineFastState.Bounded env54364 := by
  intro p hp
  have h : env54364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54363_54364 : H12AffineEnvironment.transform 17 149521 env54363 = env54364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149521 env54363 == env54364) = true)

theorem identity54364 : scanCanonicalize (H12AffineFastState.compose env54364 (packedSelected [7,17,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound54364 : packedSelected [7,17,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,31836,1024,32769,4405,21589,62776,41310,8192,65,23669,57401,45405,32041,1057,21792,256,21793,46092,63273]

theorem envBound54365 : H12AffineFastState.Bounded env54365 := by
  intro p hp
  have h : env54365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54364_54365 : H12AffineEnvironment.transform 16 13389 env54364 = env54365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env54364 == env54365) = true)

theorem identity54365 : scanCanonicalize (H12AffineFastState.compose env54365 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54365 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env54366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,13389,10588,1024,32769,4405,341,41016,41310,8192,65,2421,46393,45405,10281,1057,32,256,33,46092,41513]

theorem envBound54366 : H12AffineFastState.Bounded env54366 := by
  intro p hp
  have h : env54366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54365_54366 : H12AffineEnvironment.transform 13 5376 env54365 = env54366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54365 == env54366) = true)

theorem identity54366 : scanCanonicalize (H12AffineFastState.compose env54366 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound54366 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8232,8575,13389,10588,1024,8233,4405,341,16,374,8192,65,2421,5393,4469,10281,1057,32,256,33,5156,513]

theorem envBound54367 : H12AffineFastState.Bounded env54367 := by
  intro p hp
  have h : env54367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54366_54367 : H12AffineEnvironment.transform 14 8232 env54366 = env54367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env54366 == env54367) = true)

theorem identity54367 : scanCanonicalize (H12AffineFastState.compose env54367 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54367 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,0,343,5221,2420,1024,1,4405,341,16,374,40,65,2421,5393,4469,2049,1057,32,256,33,5156,513]

theorem envBound54368 : H12AffineFastState.Bounded env54368 := by
  intro p hp
  have h : env54368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54367_54368 : H12AffineEnvironment.transform 12 40 env54367 = env54368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54367 == env54368) = true)

theorem identity54368 : scanCanonicalize (H12AffineFastState.compose env54368 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound54368 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,40,3172,0,343,3329,2420,1024,1,2129,341,16,374,40,65,2421,3189,2065,2049,1057,32,256,33,3392,513]

theorem envBound54369 : H12AffineFastState.Bounded env54369 := by
  intro p hp
  have h : env54369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54368_54369 : H12AffineEnvironment.transform 11 2404 env54368 = env54369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env54368 == env54369) = true)

theorem identity54369 : scanCanonicalize (H12AffineFastState.compose env54369 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 347) := by decide +kernel

theorem selectedBound54369 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54370 : List Nat := [2,4,8,16,32,64,8,256,512,347,2048,2404,40,2367,0,343,2138,2420,347,1,2129,341,16,374,40,65,2421,2350,2065,2049,378,32,256,33,2075,513]

theorem envBound54370 : H12AffineFastState.Bounded env54370 := by
  intro p hp
  have h : env54370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54369_54370 : H12AffineEnvironment.transform 9 347 env54369 = env54370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 347 env54369 == env54370) = true)

theorem identity54370 : scanCanonicalize (H12AffineFastState.compose env54370 (packedSelected [2,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound54370 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env54371 : List Nat := [2,4,8,16,32,10,8,256,512,273,2048,2350,40,2367,0,285,2064,2366,273,1,2075,287,16,316,40,11,2367,2350,2065,2049,304,32,256,33,2075,513]

theorem envBound54371 : H12AffineFastState.Bounded env54371 := by
  intro p hp
  have h : env54371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54370_54371 : H12AffineEnvironment.transform 5 10 env54370 = env54371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env54370 == env54371) = true)

theorem identity54371 : scanCanonicalize (H12AffineFastState.compose env54371 (packedSelected [5,6] rootPS)) = affineNative (2^(10+1) ^^^ 536) := by decide +kernel

theorem selectedBound54371 : packedSelected [5,6] rootPS < 2^1333 := by decide +kernel

def env54372 : List Nat := [2,4,8,16,32,10,8,256,512,273,536,822,40,807,0,285,520,806,273,1,515,287,16,316,40,11,807,822,521,537,304,32,256,33,515,513]

theorem envBound54372 : H12AffineFastState.Bounded env54372 := by
  intro p hp
  have h : env54372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54371_54372 : H12AffineEnvironment.transform 10 536 env54371 = env54372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 536 env54371 == env54372) = true)

theorem identity54372 : scanCanonicalize (H12AffineFastState.compose env54372 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54372 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54373 : List Nat := [2,4,8,12,32,10,8,256,512,269,516,810,40,807,0,257,520,806,269,1,515,259,12,288,40,11,807,810,521,517,300,32,256,33,515,513]

theorem envBound54373 : H12AffineFastState.Bounded env54373 := by
  intro p hp
  have h : env54373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54372_54373 : H12AffineEnvironment.transform 3 12 env54372 = env54373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54372 == env54373) = true)

theorem identity54373 : scanCanonicalize (H12AffineFastState.compose env54373 (packedSelected [4,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54373 : packedSelected [4,8] rootPS < 2^1333 := by decide +kernel

def env54374 : List Nat := [2,2,8,10,32,10,8,256,512,267,514,810,40,801,0,257,520,800,267,1,515,259,10,288,40,11,801,810,521,515,298,32,256,33,515,513]

theorem envBound54374 : H12AffineFastState.Bounded env54374 := by
  intro p hp
  have h : env54374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54373_54374 : H12AffineEnvironment.transform 1 2 env54373 = env54374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54373 == env54374) = true)

theorem identity54374 : scanCanonicalize (H12AffineFastState.compose env54374 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 266) := by decide +kernel

theorem selectedBound54374 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54375 : List Nat := [2,2,8,10,32,10,8,256,266,267,264,32,40,43,0,257,258,42,267,1,265,259,10,288,40,11,43,32,259,265,298,32,256,33,265,267]

theorem envBound54375 : H12AffineFastState.Bounded env54375 := by
  intro p hp
  have h : env54375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54374_54375 : H12AffineEnvironment.transform 8 266 env54374 = env54375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 266 env54374 == env54375) = true)

theorem identity54375 : scanCanonicalize (H12AffineFastState.compose env54375 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound54375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54376 : List Nat := [2,2,8,10,32,10,8,3,9,8,11,32,40,43,0,2,1,42,8,1,10,0,10,35,40,11,43,32,0,10,41,32,3,33,10,8]

theorem envBound54376 : H12AffineFastState.Bounded env54376 := by
  intro p hp
  have h : env54376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54375_54376 : H12AffineEnvironment.transform 7 3 env54375 = env54376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env54375 == env54376) = true)

theorem identity54376 : scanCanonicalize (H12AffineFastState.compose env54376 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54376 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54377 : List Nat := [2,2,8,10,1,10,8,3,9,8,11,1,9,10,0,2,1,11,8,1,10,0,10,2,9,11,10,1,0,10,8,1,3,0,10,8]

theorem envBound54377 : H12AffineFastState.Bounded env54377 := by
  intro p hp
  have h : env54377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54376_54377 : H12AffineEnvironment.transform 4 1 env54376 = env54377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54376 == env54377) = true)

theorem identity54377 : scanCanonicalize (H12AffineFastState.compose env54377 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54378 : List Nat := [2,2,3,1,1,1,3,3,2,3,0,1,2,1,0,2,1,0,3,1,1,0,1,2,2,0,1,1,0,1,3,1,3,0,1,3]

theorem envBound54378 : H12AffineFastState.Bounded env54378 := by
  intro p hp
  have h : env54378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54377_54378 : H12AffineEnvironment.transform 2 3 env54377 = env54378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54377 == env54378) = true)

def env54379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272392,441641,41311,8193,65,270376,436264,45404,32041,412720,156012,256,21793,46093,442168]

theorem envBound54379 : H12AffineFastState.Bounded env54379 := by
  intro p hp
  have h : env54379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54362_54379 : H12AffineEnvironment.transform 6 9 env54362 = env54379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54362 == env54379) = true)

theorem identity54379 : scanCanonicalize (H12AffineFastState.compose env54379 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound54379 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env54380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1024,32769,140300,21793,180224,41311,8193,65,23809,185601,45404,32041,143641,156012,256,21793,46093,180753]

theorem envBound54380 : H12AffineFastState.Bounded env54380 := by
  intro p hp
  have h : env54380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54379_54380 : H12AffineEnvironment.transform 17 32041 env54379 = env54380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env54379 == env54380) = true)

theorem identity54380 : scanCanonicalize (H12AffineFastState.compose env54380 (packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54380 : packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env54381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,32041,1024,8541,140300,21793,155996,3,8193,65,23809,160861,4096,32041,143641,156012,256,21793,5457,156493]

theorem envBound54381 : H12AffineFastState.Bounded env54381 := by
  intro p hp
  have h : env54381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54380_54381 : H12AffineEnvironment.transform 14 8540 env54380 = env54381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54380 == env54381) = true)

theorem identity54381 : scanCanonicalize (H12AffineFastState.compose env54381 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54381 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env54382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,131072,23669,1024,1,132432,21793,147456,3,349,65,23809,152833,4096,23669,135237,147504,256,21793,5457,147985]

theorem envBound54382 : H12AffineFastState.Bounded env54382 := by
  intro p hp
  have h : env54382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54381_54382 : H12AffineEnvironment.transform 12 348 env54381 = env54382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54381 == env54382) = true)

theorem identity54382 : scanCanonicalize (H12AffineFastState.compose env54382 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound54382 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,5393,23669,1024,1,4161,21793,21777,3,349,65,23809,16400,4096,23669,1364,21793,256,21793,5457,22272]

theorem envBound54383 : H12AffineFastState.Bounded env54383 := by
  intro p hp
  have h : env54383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54382_54383 : H12AffineEnvironment.transform 16 5393 env54382 = env54383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env54382 == env54383) = true)

theorem identity54383 : scanCanonicalize (H12AffineFastState.compose env54383 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54383 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54384 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,0,21590,5220,23669,1024,1,4161,21588,21604,3,40,65,23668,16400,4096,23669,1057,21588,117,21588,5156,22133]

theorem envBound54384 : H12AffineFastState.Bounded env54384 := by
  intro p hp
  have h : env54384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54383_54384 : H12AffineEnvironment.transform 7 117 env54383 = env54384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54383 == env54384) = true)

theorem identity54384 : scanCanonicalize (H12AffineFastState.compose env54384 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54384 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54385 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,4096,41,16384,0,21590,5220,21620,1024,1,4161,21588,21604,3,40,65,21621,16400,4096,21620,1057,21588,117,21588,5156,22133]

theorem envBound54385 : H12AffineFastState.Bounded env54385 := by
  intro p hp
  have h : env54385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54384_54385 : H12AffineEnvironment.transform 10 1 env54384 = env54385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54384 == env54385) = true)

theorem identity54385 : scanCanonicalize (H12AffineFastState.compose env54385 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54385 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env54386 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,4096,41,16384,0,20578,4176,20544,52,1,4161,20576,20560,3,40,65,20545,16400,4096,20544,21,20576,117,20576,4112,21057]

theorem envBound54386 : H12AffineFastState.Bounded env54386 := by
  intro p hp
  have h : env54386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54385_54386 : H12AffineEnvironment.transform 9 52 env54385 = env54386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54385 == env54386) = true)

theorem identity54386 : scanCanonicalize (H12AffineFastState.compose env54386 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound54386 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54387 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,16,41,16384,0,16498,64,16464,52,1,81,16496,16448,3,40,65,16465,16400,16,16464,21,16496,117,16496,0,16977]

theorem envBound54387 : H12AffineFastState.Bounded env54387 := by
  intro p hp
  have h : env54387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54386_54387 : H12AffineEnvironment.transform 11 16 env54386 = env54387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env54386 == env54387) = true)

theorem identity54387 : scanCanonicalize (H12AffineFastState.compose env54387 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound54387 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54388 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,16,41,1,0,115,64,81,52,1,81,113,65,3,40,65,80,17,16,81,21,113,117,113,0,592]

theorem envBound54388 : H12AffineFastState.Bounded env54388 := by
  intro p hp
  have h : env54388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54387_54388 : H12AffineEnvironment.transform 13 1 env54387 = env54388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env54387 == env54388) = true)

def env54389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,8388608,8898592,8328,65,4196384,8393984,8785149,8830976,412720,12645452,256,21792,46213,486375]

theorem envBound54389 : H12AffineFastState.Bounded env54389 := by
  intro p hp
  have h : env54389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54275_54389 : H12AffineEnvironment.transform 20 416173 env54275 = env54389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416173 env54275 == env54389) = true)

def env54390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441640,95496,8328,65,4196384,436264,45525,32040,412720,4606308,256,21792,46213,486375]

theorem envBound54390 : H12AffineFastState.Bounded env54390 := by
  intro p hp
  have h : env54390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54389_54390 : H12AffineEnvironment.transform 22 441640 env54389 = env54390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env54389 == env54390) = true)

def env54391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441640,95496,8328,65,270496,436264,45525,32040,412720,156132,256,21792,46213,486375]

theorem envBound54391 : H12AffineFastState.Bounded env54391 := by
  intro p hp
  have h : env54391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54390_54391 : H12AffineEnvironment.transform 21 272512 env54390 = env54391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54390 == env54391) = true)

def env54392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272392,441640,95496,8192,65,270376,436264,45405,32040,412720,156012,256,21792,46093,486255]

theorem envBound54392 : H12AffineFastState.Bounded env54392 := by
  intro p hp
  have h : env54392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54391_54392 : H12AffineEnvironment.transform 6 8 env54391 = env54392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54391 == env54392) = true)

def env54393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314421,272392,272440,95496,8192,65,270376,277816,45405,32040,317728,62588,256,21792,46093,392831]

theorem envBound54393 : H12AffineFastState.Bounded env54393 := by
  intro p hp
  have h : env54393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54392_54393 : H12AffineEnvironment.transform 16 38160 env54392 = env54393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54392 == env54393) = true)

theorem identity54393 : scanCanonicalize (H12AffineFastState.compose env54393 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound54393 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35188,1024,32769,17729,41340,41292,95496,8192,65,43356,46156,45405,32040,20564,62588,256,21792,46093,96011]

theorem envBound54394 : H12AffineFastState.Bounded env54394 := by
  intro p hp
  have h : env54394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54393_54394 : H12AffineEnvironment.transform 17 35188 env54393 = env54394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env54393 == env54394) = true)

theorem identity54394 : scanCanonicalize (H12AffineFastState.compose env54394 (packedSelected [7,8,10,12,14,15,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound54394 : packedSelected [7,8,10,12,14,15,20,27,28] rootPS < 2^1333 := by decide +kernel

def env54395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,65536,38160,35188,1024,32769,12345,41340,41292,65648,8192,65,43356,46156,45405,2128,9516,33028,256,8280,46093,66163]

theorem envBound54395 : H12AffineFastState.Bounded env54395 := by
  intro p hp
  have h : env54395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54394_54395 : H12AffineEnvironment.transform 13 13688 env54394 = env54395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env54394 == env54395) = true)

theorem identity54395 : scanCanonicalize (H12AffineFastState.compose env54395 (packedSelected [1,2,4,6,8,11,12,15,16,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound54395 : packedSelected [1,2,4,6,8,11,12,15,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env54396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,114,38160,35188,1024,32769,12345,41340,41292,2,8192,65,43356,46156,45405,2128,9516,33028,256,8280,46093,513]

theorem envBound54396 : H12AffineFastState.Bounded env54396 := by
  intro p hp
  have h : env54396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54395_54396 : H12AffineEnvironment.transform 15 114 env54395 = env54396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env54395 == env54396) = true)

theorem identity54396 : scanCanonicalize (H12AffineFastState.compose env54396 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound54396 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env54397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9292,114,12636,11576,1024,9293,12345,1328,1280,2,8192,65,3344,4096,5393,2128,9516,9544,256,8280,4161,513]

theorem envBound54397 : H12AffineFastState.Bounded env54397 := by
  intro p hp
  have h : env54397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54396_54397 : H12AffineEnvironment.transform 14 9292 env54396 = env54397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env54396 == env54397) = true)

theorem identity54397 : scanCanonicalize (H12AffineFastState.compose env54397 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound54397 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env54398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,1076,114,4388,3392,1024,1077,4161,1328,1280,2,120,65,3344,4096,5393,2128,1364,1328,256,32,4161,513]

theorem envBound54398 : H12AffineFastState.Bounded env54398 := by
  intro p hp
  have h : env54398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54397_54398 : H12AffineEnvironment.transform 12 120 env54397 = env54398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54397 == env54398) = true)

theorem identity54398 : scanCanonicalize (H12AffineFastState.compose env54398 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54398 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env54399 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4113,293,114,4388,2129,273,292,4161,33,17,2,120,65,2049,4096,4096,2128,69,33,256,32,4161,513]

theorem envBound54399 : H12AffineFastState.Bounded env54399 := by
  intro p hp
  have h : env54399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54398_54399 : H12AffineEnvironment.transform 9 273 env54398 = env54399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54398 == env54399) = true)

theorem identity54399 : scanCanonicalize (H12AffineFastState.compose env54399 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54399 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54400 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,120,4113,1,114,4096,2129,53,0,4161,33,17,2,120,65,2049,4096,4096,2128,69,33,36,32,4161,513]

theorem envBound54400 : H12AffineFastState.Bounded env54400 := by
  intro p hp
  have h : env54400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54399_54400 : H12AffineEnvironment.transform 7 36 env54399 = env54400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54399 == env54400) = true)

theorem identity54400 : scanCanonicalize (H12AffineFastState.compose env54400 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54401 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4113,1,34,4096,2049,53,0,4113,33,17,2,40,17,2049,4096,4096,2048,21,33,36,32,4113,513]

theorem envBound54401 : H12AffineFastState.Bounded env54401 := by
  intro p hp
  have h : env54401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54400_54401 : H12AffineEnvironment.transform 5 16 env54400 = env54401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54400 == env54401) = true)

theorem identity54401 : scanCanonicalize (H12AffineFastState.compose env54401 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound54401 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54402 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,2048,1,34,2065,2049,53,0,2048,33,17,2,40,17,2049,2065,2065,2048,21,33,36,32,2048,513]

theorem envBound54402 : H12AffineFastState.Bounded env54402 := by
  intro p hp
  have h : env54402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54401_54402 : H12AffineEnvironment.transform 11 2065 env54401 = env54402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env54401 == env54402) = true)

theorem identity54402 : scanCanonicalize (H12AffineFastState.compose env54402 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54403 : List Nat := [2,4,8,10,32,10,8,36,512,47,2048,2059,40,2048,1,34,2059,2049,47,0,2048,33,11,2,40,11,2049,2059,2059,2048,15,33,36,32,2048,513]

theorem envBound54403 : H12AffineFastState.Bounded env54403 := by
  intro p hp
  have h : env54403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54402_54403 : H12AffineEnvironment.transform 3 10 env54402 = env54403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54402 == env54403) = true)

theorem identity54403 : scanCanonicalize (H12AffineFastState.compose env54403 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54403 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54404 : List Nat := [2,4,8,10,32,10,8,36,512,47,1,10,40,1,1,34,10,0,47,0,1,33,11,2,40,11,0,10,10,1,15,33,36,32,1,513]

theorem envBound54404 : H12AffineFastState.Bounded env54404 := by
  intro p hp
  have h : env54404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54403_54404 : H12AffineEnvironment.transform 10 1 env54403 = env54404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54403 == env54404) = true)

def env54405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314420,272392,272441,95496,8192,65,270376,277817,45405,32040,317729,62589,256,21792,46093,392830]

theorem envBound54405 : H12AffineFastState.Bounded env54405 := by
  intro p hp
  have h : env54405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54392_54405 : H12AffineEnvironment.transform 16 38161 env54392 = env54405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54392 == env54405) = true)

theorem identity54405 : scanCanonicalize (H12AffineFastState.compose env54405 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54405 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13388,262144,1024,8540,290153,272392,272441,95496,8192,65,270376,277817,4096,32040,292988,21792,256,21792,5456,352035]

theorem envBound54406 : H12AffineFastState.Bounded env54406 := by
  intro p hp
  have h : env54406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54405_54406 : H12AffineEnvironment.transform 14 8541 env54405 = env54406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54405 == env54406) = true)

theorem identity54406 : scanCanonicalize (H12AffineFastState.compose env54406 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound54406 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env54407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,13388,97326,1024,8540,69959,87078,87063,95496,8192,65,89094,82199,4096,32040,66642,21792,256,21792,5456,8973]

theorem envBound54407 : H12AffineFastState.Bounded env54407 := by
  intro p hp
  have h : env54407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54406_54407 : H12AffineEnvironment.transform 17 97326 env54406 = env54407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env54406 == env54407) = true)

theorem identity54407 : scanCanonicalize (H12AffineFastState.compose env54407 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,19,22,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54407 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54408 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8233,65536,13388,97326,1024,8232,69683,87078,87063,95356,8192,65,89094,82019,4096,31836,66642,21588,116,21588,5156,8825]

theorem envBound54408 : H12AffineFastState.Bounded env54408 := by
  intro p hp
  have h : env54408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54407_54408 : H12AffineEnvironment.transform 7 116 env54407 = env54408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54407 == env54408) = true)

theorem identity54408 : scanCanonicalize (H12AffineFastState.compose env54408 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound54408 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54409 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,65536,13388,75866,1024,8232,69683,65618,65635,73736,8192,65,67698,70679,4096,10280,66642,32,116,32,5156,8825]

theorem envBound54409 : H12AffineFastState.Bounded env54409 := by
  intro p hp
  have h : env54409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54408_54409 : H12AffineEnvironment.transform 13 5236 env54408 = env54409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env54408 == env54409) = true)

theorem identity54409 : scanCanonicalize (H12AffineFastState.compose env54409 (packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54409 : packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env54410 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,8202,13388,2128,1024,8232,12345,8280,8297,2,8192,65,10360,13341,4096,10280,9304,32,116,32,5156,8825]

theorem envBound54410 : H12AffineFastState.Bounded env54410 := by
  intro p hp
  have h : env54410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54409_54410 : H12AffineEnvironment.transform 15 8202 env54409 = env54410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54409 == env54410) = true)

theorem identity54410 : scanCanonicalize (H12AffineFastState.compose env54410 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54410 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54411 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,1,34,5220,2128,1024,0,4113,112,65,2,40,65,2128,5173,4096,2048,1136,32,116,32,5156,593]

theorem envBound54411 : H12AffineFastState.Bounded env54411 := by
  intro p hp
  have h : env54411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54410_54411 : H12AffineEnvironment.transform 12 40 env54410 = env54411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54410 == env54411) = true)

theorem identity54411 : scanCanonicalize (H12AffineFastState.compose env54411 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound54411 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54412 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,48,40,1092,1,34,1108,2128,1024,0,33,112,65,2,40,65,2128,1029,48,2048,1136,32,116,32,1044,593]

theorem envBound54412 : H12AffineFastState.Bounded env54412 := by
  intro p hp
  have h : env54412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54411_54412 : H12AffineEnvironment.transform 11 48 env54411 = env54412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54411 == env54412) = true)

theorem identity54412 : scanCanonicalize (H12AffineFastState.compose env54412 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound54412 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env54413 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1044,48,40,1092,1,34,1108,1092,1024,0,33,112,65,2,40,65,1092,1029,48,1044,1136,32,116,32,1044,593]

theorem envBound54413 : H12AffineFastState.Bounded env54413 := by
  intro p hp
  have h : env54413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54412_54413 : H12AffineEnvironment.transform 10 1044 env54412 = env54413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env54412 == env54413) = true)

theorem identity54413 : scanCanonicalize (H12AffineFastState.compose env54413 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54413 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54414 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1045,1,34,1029,1045,1024,0,33,33,16,2,40,16,1045,1029,48,1044,1057,32,37,32,1044,512]

theorem envBound54414 : H12AffineFastState.Bounded env54414 := by
  intro p hp
  have h : env54414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54413_54414 : H12AffineEnvironment.transform 5 17 env54413 = env54414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54413 == env54414) = true)

theorem identity54414 : scanCanonicalize (H12AffineFastState.compose env54414 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54415 : List Nat := [2,4,8,16,32,17,8,37,512,4,16,48,40,17,1,34,1,17,4,0,33,33,16,2,40,16,17,1,48,16,37,32,37,32,16,512]

theorem envBound54415 : H12AffineFastState.Bounded env54415 := by
  intro p hp
  have h : env54415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54414_54415 : H12AffineEnvironment.transform 9 4 env54414 = env54415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54414 == env54415) = true)

theorem identity54415 : scanCanonicalize (H12AffineFastState.compose env54415 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54416 : List Nat := [2,4,8,16,1,17,8,4,512,4,16,17,9,17,1,3,1,17,4,0,0,0,16,2,9,16,17,1,17,16,4,1,4,1,16,512]

theorem envBound54416 : H12AffineFastState.Bounded env54416 := by
  intro p hp
  have h : env54416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54415_54416 : H12AffineEnvironment.transform 4 1 env54415 = env54416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54415 == env54416) = true)

theorem identity54416 : scanCanonicalize (H12AffineFastState.compose env54416 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound54416 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54417 : List Nat := [2,4,8,16,1,17,8,4,0,4,16,17,9,17,1,3,1,17,4,0,0,0,16,2,9,16,17,1,17,16,4,1,4,1,16,0]

theorem envBound54417 : H12AffineFastState.Bounded env54417 := by
  intro p hp
  have h : env54417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54416_54417 : H12AffineEnvironment.transform 8 0 env54416 = env54417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env54416 == env54417) = true)

def env54418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441640,95496,8193,65,270377,436264,45404,32040,412720,156013,256,21792,46092,486254]

theorem envBound54418 : H12AffineFastState.Bounded env54418 := by
  intro p hp
  have h : env54418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54391_54418 : H12AffineEnvironment.transform 6 9 env54391 = env54418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54391 == env54418) = true)

def env54419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272440,95496,8193,65,270377,277816,45404,32040,317728,62589,256,21792,46092,392830]

theorem envBound54419 : H12AffineFastState.Bounded env54419 := by
  intro p hp
  have h : env54419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54418_54419 : H12AffineEnvironment.transform 16 38160 env54418 = env54419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54418 == env54419) = true)

theorem identity54419 : scanCanonicalize (H12AffineFastState.compose env54419 (packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54419 : packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env54420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1024,32769,314420,272393,272440,21762,8193,65,270377,277816,45404,32040,317728,62589,256,21792,46092,319092]

theorem envBound54420 : H12AffineFastState.Bounded env54420 := by
  intro p hp
  have h : env54420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54419_54420 : H12AffineEnvironment.transform 15 8202 env54419 = env54420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54419 == env54420) = true)

theorem identity54420 : scanCanonicalize (H12AffineFastState.compose env54420 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound54420 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env54421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,43048,1024,32769,25628,32801,32784,21762,8193,65,34817,38160,45404,32040,28936,62589,256,21792,46092,30300]

theorem envBound54421 : H12AffineFastState.Bounded env54421 := by
  intro p hp
  have h : env54421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54420_54421 : H12AffineEnvironment.transform 17 43048 env54420 = env54421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env54420 == env54421) = true)

theorem identity54421 : scanCanonicalize (H12AffineFastState.compose env54421 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound54421 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,24909,23669,1024,29788,25628,29820,29773,21762,8193,65,31836,24909,17665,32040,28936,32,256,21792,16465,30300]

theorem envBound54422 : H12AffineFastState.Bounded env54422 := by
  intro p hp
  have h : env54422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54421_54422 : H12AffineEnvironment.transform 14 29789 env54421 = env54422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env54421 == env54422) = true)

theorem identity54422 : scanCanonicalize (H12AffineFastState.compose env54422 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54422 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env54423 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,24861,23589,1024,29708,25628,29740,29725,21762,8193,17,31756,24861,17665,32040,28936,32,256,21792,16385,30220]

theorem envBound54423 : H12AffineFastState.Bounded env54423 := by
  intro p hp
  have h : env54423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54422_54423 : H12AffineEnvironment.transform 5 16 env54422 = env54423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54422 == env54423) = true)

theorem identity54423 : scanCanonicalize (H12AffineFastState.compose env54423 (packedSelected [0,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound54423 : packedSelected [0,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,12345,1076,8202,4388,11292,1024,1077,5157,1045,1060,9531,8193,17,3125,4388,13624,3345,305,32,256,9497,12344,1589]

theorem envBound54424 : H12AffineFastState.Bounded env54424 := by
  intro p hp
  have h : env54424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54423_54424 : H12AffineEnvironment.transform 13 12345 env54423 = env54424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env54423 == env54424) = true)

theorem identity54424 : scanCanonicalize (H12AffineFastState.compose env54424 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54424 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env54425 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,12345,1,8202,4388,10281,53,0,4112,32,17,8462,8193,17,2048,4388,12557,2340,305,32,256,8492,12344,512]

theorem envBound54425 : H12AffineFastState.Bounded env54425 := by
  intro p hp
  have h : env54425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54424_54425 : H12AffineEnvironment.transform 9 53 env54424 = env54425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54424 == env54425) = true)

theorem identity54425 : scanCanonicalize (H12AffineFastState.compose env54425 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound54425 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54426 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,301,4372,1,295,4388,2308,53,0,4112,32,17,35,300,17,2048,4388,4128,2340,305,32,256,1,4373,512]

theorem envBound54426 : H12AffineFastState.Bounded env54426 := by
  intro p hp
  have h : env54426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54425_54426 : H12AffineEnvironment.transform 12 301 env54425 = env54426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env54425 == env54426) = true)

theorem identity54426 : scanCanonicalize (H12AffineFastState.compose env54426 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54426 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env54427 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8,4145,1,2,4097,2081,53,0,4112,32,17,35,9,17,2048,4097,4128,2049,20,32,37,1,4144,512]

theorem envBound54427 : H12AffineFastState.Bounded env54427 := by
  intro p hp
  have h : env54427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54426_54427 : H12AffineEnvironment.transform 7 37 env54426 = env54427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54426 == env54427) = true)

theorem identity54427 : scanCanonicalize (H12AffineFastState.compose env54427 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound54427 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54428 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,8,2048,1,2,2096,2081,53,0,2081,32,17,35,9,17,2048,2096,2065,2049,20,32,37,1,2049,512]

theorem envBound54428 : H12AffineFastState.Bounded env54428 := by
  intro p hp
  have h : env54428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54427_54428 : H12AffineEnvironment.transform 11 2097 env54427 = env54428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env54427 == env54428) = true)

theorem identity54428 : scanCanonicalize (H12AffineFastState.compose env54428 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54428 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env54429 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2065,8,2048,1,2,2064,2049,21,0,2049,0,17,3,9,17,2048,2064,2065,2049,20,0,5,1,2049,512]

theorem envBound54429 : H12AffineFastState.Bounded env54429 := by
  intro p hp
  have h : env54429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54428_54429 : H12AffineEnvironment.transform 4 0 env54428 = env54429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54428 == env54429) = true)

theorem identity54429 : scanCanonicalize (H12AffineFastState.compose env54429 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound54429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54430 : List Nat := [2,4,8,16,0,16,9,5,512,21,5,20,8,5,1,2,21,4,21,0,4,0,17,3,9,17,5,21,20,4,20,0,5,1,4,512]

theorem envBound54430 : H12AffineFastState.Bounded env54430 := by
  intro p hp
  have h : env54430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54429_54430 : H12AffineEnvironment.transform 10 5 env54429 = env54430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env54429 == env54430) = true)

def env54431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272441,95496,8193,65,270377,277817,45404,32040,317729,62588,256,21792,46092,392831]

theorem envBound54431 : H12AffineFastState.Bounded env54431 := by
  intro p hp
  have h : env54431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54418_54431 : H12AffineEnvironment.transform 16 38161 env54418 = env54431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54418 == env54431) = true)

theorem identity54431 : scanCanonicalize (H12AffineFastState.compose env54431 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54431 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,58397,33,17,95496,8193,65,2049,5393,45404,32040,61705,62588,256,21792,46092,120407]

theorem envBound54432 : H12AffineFastState.Bounded env54432 := by
  intro p hp
  have h : env54432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54431_54432 : H12AffineEnvironment.transform 17 10280 env54431 = env54432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54431 == env54432) = true)

theorem identity54432 : scanCanonicalize (H12AffineFastState.compose env54432 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54432 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10280,1024,32769,45340,33,17,73737,8193,65,2049,5393,45404,10281,41992,41341,256,33,46092,99158]

theorem envBound54433 : H12AffineFastState.Bounded env54433 := by
  intro p hp
  have h : env54433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54432_54433 : H12AffineEnvironment.transform 13 5377 env54432 = env54433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54432 == env54433) = true)

theorem identity54433 : scanCanonicalize (H12AffineFastState.compose env54433 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54433 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38161,10280,1024,32769,45340,33,17,3,8193,65,2049,5393,45404,10281,41992,41341,256,33,46092,41820]

theorem envBound54434 : H12AffineFastState.Bounded env54434 := by
  intro p hp
  have h : env54434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54433_54434 : H12AffineEnvironment.transform 15 8202 env54433 = env54434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54433 == env54434) = true)

theorem identity54434 : scanCanonicalize (H12AffineFastState.compose env54434 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54434 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,13389,10280,1024,8541,4160,33,17,3,8193,65,2049,5393,4096,10281,1364,33,256,33,5456,512]

theorem envBound54435 : H12AffineFastState.Bounded env54435 := by
  intro p hp
  have h : env54435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54434_54435 : H12AffineEnvironment.transform 14 8540 env54434 = env54435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54434 == env54435) = true)

theorem identity54435 : scanCanonicalize (H12AffineFastState.compose env54435 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54435 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54436 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,13389,10248,1024,8541,4160,1,17,3,8193,65,2049,5393,4096,10249,1364,1,256,1,5456,512]

theorem envBound54436 : H12AffineFastState.Bounded env54436 := by
  intro p hp
  have h : env54436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54435_54436 : H12AffineEnvironment.transform 4 0 env54435 = env54436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54435 == env54436) = true)

theorem identity54436 : scanCanonicalize (H12AffineFastState.compose env54436 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54436 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54437 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8192,5124,8281,8202,13389,10248,1024,8280,4160,1,17,3,8193,65,2049,5140,4096,10249,1105,1,5,1,5205,512]

theorem envBound54437 : H12AffineFastState.Bounded env54437 := by
  intro p hp
  have h : env54437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54436_54437 : H12AffineEnvironment.transform 7 5 env54436 = env54437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54436 == env54437) = true)

end H12CloudChart0