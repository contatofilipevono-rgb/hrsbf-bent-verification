import H12CloudChart0Data225

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans57267_57268 : H12AffineEnvironment.transform 7 20 env57267 = env57268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57267 == env57268) = true)

theorem identity57268 : scanCanonicalize (H12AffineFastState.compose env57268 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound57268 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57269 : List Nat := [2,4,8,16,32,17,128,20,512,173,691,544,176,544,16,138,665,571,173,16,664,32,168,138,57,168,523,544,664,642,189,168,21,169,664,512]

theorem envBound57269 : H12AffineFastState.Bounded env57269 := by
  intro p hp
  have h : env57269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57268_57269 : H12AffineEnvironment.transform 10 691 env57268 = env57269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env57268 == env57269) = true)

def env57270 : List Nat := [2,4,8,16,32,17,128,20,48,173,131,16,176,16,16,138,169,11,173,16,168,32,168,138,57,168,59,16,168,178,189,168,21,169,168,48]

theorem envBound57270 : H12AffineFastState.Bounded env57270 := by
  intro p hp
  have h : env57270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57269_57270 : H12AffineEnvironment.transform 8 48 env57269 = env57270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env57269 == env57270) = true)

theorem identity57270 : scanCanonicalize (H12AffineFastState.compose env57270 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57271 : List Nat := [2,4,8,16,27,17,128,20,11,150,131,16,139,16,16,138,146,11,150,16,147,27,147,138,2,147,0,16,147,137,134,147,21,146,147,11]

theorem envBound57271 : H12AffineFastState.Bounded env57271 := by
  intro p hp
  have h : env57271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57270_57271 : H12AffineEnvironment.transform 4 27 env57270 = env57271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57270 == env57271) = true)

def env57272 : List Nat := [2,4,8,0,11,1,128,4,11,134,131,0,139,0,0,138,130,11,134,0,131,11,131,138,2,131,0,0,131,137,134,131,5,130,131,11]

theorem envBound57272 : H12AffineFastState.Bounded env57272 := by
  intro p hp
  have h : env57272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57271_57272 : H12AffineEnvironment.transform 3 0 env57271 = env57272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57271 == env57272) = true)

theorem identity57272 : scanCanonicalize (H12AffineFastState.compose env57272 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57273 : List Nat := [2,4,2,0,1,1,128,4,1,134,131,0,129,0,0,128,130,1,134,0,131,1,131,128,2,131,0,0,131,131,134,131,5,130,131,1]

theorem envBound57273 : H12AffineFastState.Bounded env57273 := by
  intro p hp
  have h : env57273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57272_57273 : H12AffineEnvironment.transform 2 2 env57272 = env57273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57272 == env57273) = true)

def env57274 : List Nat := [2,4,8,1,10,0,128,5,11,135,131,1,139,1,1,138,131,11,135,1,130,10,130,138,2,130,0,1,130,137,134,130,4,131,130,11]

theorem envBound57274 : H12AffineFastState.Bounded env57274 := by
  intro p hp
  have h : env57274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57271_57274 : H12AffineEnvironment.transform 3 1 env57271 = env57274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57271 == env57274) = true)

def env57275 : List Nat := [2,4,8,16,32,17,128,20,49,173,130,17,176,17,16,138,168,10,173,16,169,32,168,138,57,168,58,17,169,179,189,168,21,169,169,49]

theorem envBound57275 : H12AffineFastState.Bounded env57275 := by
  intro p hp
  have h : env57275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57269_57275 : H12AffineEnvironment.transform 8 49 env57269 = env57275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env57269 == env57275) = true)

theorem identity57275 : scanCanonicalize (H12AffineFastState.compose env57275 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57275 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57276 : List Nat := [2,4,8,16,32,17,51,20,49,30,49,17,3,17,16,57,27,10,30,16,26,32,27,57,57,27,58,17,26,0,14,27,21,26,26,49]

theorem envBound57276 : H12AffineFastState.Bounded env57276 := by
  intro p hp
  have h : env57276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57275_57276 : H12AffineEnvironment.transform 6 51 env57275 = env57276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57275 == env57276) = true)

def env57277 : List Nat := [2,4,8,16,16,17,3,20,1,30,1,17,3,17,16,9,27,10,30,16,26,16,27,9,9,27,10,17,26,0,14,27,21,26,26,1]

theorem envBound57277 : H12AffineFastState.Bounded env57277 := by
  intro p hp
  have h : env57277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57276_57277 : H12AffineEnvironment.transform 4 16 env57276 = env57277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57276 == env57277) = true)

def env57278 : List Nat := [2,4,8,16,17,17,2,20,0,30,0,17,3,17,16,8,27,10,30,16,26,17,27,8,8,27,11,17,26,0,14,27,21,26,26,0]

theorem envBound57278 : H12AffineFastState.Bounded env57278 := by
  intro p hp
  have h : env57278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57276_57278 : H12AffineEnvironment.transform 4 17 env57276 = env57278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57276 == env57278) = true)

theorem identity57278 : scanCanonicalize (H12AffineFastState.compose env57278 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57279 : List Nat := [2,4,8,10,11,11,2,14,0,4,0,11,3,11,10,8,1,10,4,10,0,11,1,8,8,1,11,11,0,0,14,1,15,0,0,0]

theorem envBound57279 : H12AffineFastState.Bounded env57279 := by
  intro p hp
  have h : env57279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57278_57279 : H12AffineEnvironment.transform 3 10 env57278 = env57279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57278 == env57279) = true)

def env57280 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,4097,32768,33166,45404,37199,252,32768,37113,41088,32952,8575,8409,32953,4462,4097,45324,43477,8205,40968,257,8460,45405,592]

theorem envBound57280 : H12AffineFastState.Bounded env57280 := by
  intro p hp
  have h : env57280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57252_57280 : H12AffineEnvironment.transform 13 4097 env57252 = env57280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env57252 == env57280) = true)

theorem identity57280 : scanCanonicalize (H12AffineFastState.compose env57280 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57280 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57281 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4097,32768,33166,45324,37151,172,32768,37033,41088,32952,8495,8329,32953,4414,4097,45324,43397,8205,40968,257,8460,45325,512]

theorem envBound57281 : H12AffineFastState.Bounded env57281 := by
  intro p hp
  have h : env57281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57280_57281 : H12AffineEnvironment.transform 5 16 env57280 = env57281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57280 == env57281) = true)

theorem identity57281 : scanCanonicalize (H12AffineFastState.compose env57281 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound57281 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57282 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2563,4097,32768,33166,39695,37151,172,32768,37033,35459,32952,2860,2698,32953,4414,4097,39695,33670,2574,35339,257,2831,39694,512]

theorem envBound57282 : H12AffineFastState.Bounded env57282 := by
  intro p hp
  have h : env57282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57281_57282 : H12AffineEnvironment.transform 12 2563 env57281 = env57282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env57281 == env57282) = true)

theorem identity57282 : scanCanonicalize (H12AffineFastState.compose env57282 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57282 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57283 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2563,4097,2723,2861,4524,7100,172,2723,6666,32,2587,2860,2698,2586,4414,4097,4524,2341,2574,168,257,2831,4525,512]

theorem envBound57283 : H12AffineFastState.Bounded env57283 := by
  intro p hp
  have h : env57283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57282_57283 : H12AffineEnvironment.transform 14 2723 env57282 = env57283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57282 == env57283) = true)

theorem identity57283 : scanCanonicalize (H12AffineFastState.compose env57283 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound57283 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57284 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,2091,2563,2090,2723,2861,2439,919,172,2723,545,32,2587,2860,2698,2586,2325,2090,2439,2341,2574,168,257,2831,2438,512]

theorem envBound57284 : H12AffineFastState.Bounded env57284 := by
  intro p hp
  have h : env57284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57283_57284 : H12AffineEnvironment.transform 11 2091 env57283 = env57284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env57283 == env57284) = true)

theorem identity57284 : scanCanonicalize (H12AffineFastState.compose env57284 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound57284 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57285 : List Nat := [2,4,8,16,32,16,128,256,512,172,799,820,284,821,444,50,664,919,172,444,545,32,260,51,405,261,522,821,664,570,273,168,257,16,665,512]

theorem envBound57285 : H12AffineFastState.Bounded env57285 := by
  intro p hp
  have h : env57285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57284_57285 : H12AffineEnvironment.transform 10 799 env57284 = env57285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env57284 == env57285) = true)

theorem identity57285 : scanCanonicalize (H12AffineFastState.compose env57285 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57285 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57286 : List Nat := [2,4,8,16,32,16,57,256,512,21,799,820,284,821,261,50,545,814,21,261,545,32,260,51,300,261,522,821,545,570,273,17,257,16,544,512]

theorem envBound57286 : H12AffineFastState.Bounded env57286 := by
  intro p hp
  have h : env57286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57285_57286 : H12AffineEnvironment.transform 6 57 env57285 = env57286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57285 == env57286) = true)

def env57287 : List Nat := [2,4,8,16,16,16,9,256,512,21,799,772,284,773,261,2,529,798,21,261,529,16,260,3,284,261,522,773,529,522,273,17,257,16,528,512]

theorem envBound57287 : H12AffineFastState.Bounded env57287 := by
  intro p hp
  have h : env57287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57286_57287 : H12AffineEnvironment.transform 4 16 env57286 = env57287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57286 == env57287) = true)

theorem identity57287 : scanCanonicalize (H12AffineFastState.compose env57287 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57287 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57288 : List Nat := [2,4,8,16,16,16,9,31,512,21,512,539,3,538,26,2,529,513,21,26,529,16,27,3,3,26,522,538,529,522,14,17,30,16,528,512]

theorem envBound57288 : H12AffineFastState.Bounded env57288 := by
  intro p hp
  have h : env57288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57287_57288 : H12AffineEnvironment.transform 7 31 env57287 = env57288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57287 == env57288) = true)

theorem identity57288 : scanCanonicalize (H12AffineFastState.compose env57288 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57288 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57289 : List Nat := [2,4,8,11,11,11,9,4,512,14,512,512,3,513,1,2,522,513,14,1,522,11,0,3,3,1,522,513,522,522,14,10,5,11,523,512]

theorem envBound57289 : H12AffineFastState.Bounded env57289 := by
  intro p hp
  have h : env57289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57288_57289 : H12AffineEnvironment.transform 3 11 env57288 = env57289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57288 == env57289) = true)

def env57290 : List Nat := [2,4,8,16,17,16,8,256,512,21,799,773,284,772,261,3,528,799,21,261,528,17,260,2,285,261,522,772,528,523,273,17,257,16,529,512]

theorem envBound57290 : H12AffineFastState.Bounded env57290 := by
  intro p hp
  have h : env57290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57286_57290 : H12AffineEnvironment.transform 4 17 env57286 = env57290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57286 == env57290) = true)

theorem identity57290 : scanCanonicalize (H12AffineFastState.compose env57290 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57290 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57291 : List Nat := [2,4,8,16,17,16,8,256,10,21,277,271,284,270,261,3,26,277,21,261,26,17,260,2,285,261,0,270,26,1,273,17,257,16,27,10]

theorem envBound57291 : H12AffineFastState.Bounded env57291 := by
  intro p hp
  have h : env57291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57290_57291 : H12AffineEnvironment.transform 8 10 env57290 = env57291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57290 == env57291) = true)

theorem identity57291 : scanCanonicalize (H12AffineFastState.compose env57291 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57292 : List Nat := [2,4,8,16,17,16,8,14,10,21,27,1,18,0,11,3,26,27,21,11,26,17,10,2,19,11,0,0,26,1,31,17,15,16,27,10]

theorem envBound57292 : H12AffineFastState.Bounded env57292 := by
  intro p hp
  have h : env57292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57291_57292 : H12AffineEnvironment.transform 7 14 env57291 = env57292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57291 == env57292) = true)

def env57293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142599,28889,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57293 : H12AffineFastState.Bounded env57293 := by
  intro p hp
  have h : env57293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57248_57293 : H12AffineEnvironment.transform 21 41089 env57248 = env57293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57248 == env57293) = true)

theorem identity57293 : scanCanonicalize (H12AffineFastState.compose env57293 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 87094) := by decide +kernel

theorem selectedBound57293 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,87094,41089,83062,124337,28889,70774,103453,16384,77954,96347,25009,74119,257,13389,78035,21072]

theorem envBound57294 : H12AffineFastState.Bounded env57294 := by
  intro p hp
  have h : env57294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57293_57294 : H12AffineEnvironment.transform 20 87094 env57293 = env57294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 87094 env57293 == env57294) = true)

theorem identity57294 : scanCanonicalize (H12AffineFastState.compose env57294 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57294 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,16384,32768,65536,71131,82112,1024,32768,87094,34184,83062,114872,21968,70774,103453,16384,71051,89426,17592,66702,257,4420,71130,21072]

theorem envBound57295 : H12AffineFastState.Bounded env57295 := by
  intro p hp
  have h : env57295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57294_57295 : H12AffineEnvironment.transform 12 1289 env57294 = env57295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57294 == env57295) = true)

theorem identity57295 : scanCanonicalize (H12AffineFastState.compose env57295 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57295 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,16384,32768,65536,66615,82112,1024,32768,83418,34184,83062,114872,17468,66970,99825,16384,66663,85182,17592,66702,257,168,66614,17340]

theorem envBound57296 : H12AffineFastState.Bounded env57296 := by
  intro p hp
  have h : env57296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57295_57296 : H12AffineEnvironment.transform 11 492 env57295 = env57296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57295 == env57296) = true)

theorem identity57296 : scanCanonicalize (H12AffineFastState.compose env57296 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57296 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,65536,66615,65916,1024,32768,66662,34184,67018,98564,1408,66970,99825,444,66663,68866,1284,66702,257,168,66614,512]

theorem envBound57297 : H12AffineFastState.Bounded env57297 := by
  intro p hp
  have h : env57297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57296_57297 : H12AffineEnvironment.transform 13 444 env57296 = env57297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57296 == env57297) = true)

theorem identity57297 : scanCanonicalize (H12AffineFastState.compose env57297 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57297 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,1874,869,1582,1024,32768,820,34184,664,34390,1408,712,33443,444,821,2640,1284,988,257,168,868,512]

theorem envBound57298 : H12AffineFastState.Bounded env57298 := by
  intro p hp
  have h : env57298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57297_57298 : H12AffineEnvironment.transform 15 1874 env57297 = env57298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57297 == env57298) = true)

def env57299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4273309,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound57299 : H12AffineFastState.Bounded env57299 := by
  intro p hp
  have h : env57299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57247_57299 : H12AffineEnvironment.transform 17 82113 env57247 = env57299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57247 == env57299) = true)

def env57300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142598,28888,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57300 : H12AffineFastState.Bounded env57300 := by
  intro p hp
  have h : env57300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57299_57300 : H12AffineEnvironment.transform 21 41088 env57299 = env57300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57299 == env57300) = true)

theorem identity57300 : scanCanonicalize (H12AffineFastState.compose env57300 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound57300 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,82215,41088,86374,127137,28888,65894,103453,16384,77954,96346,29857,74118,257,8541,78035,21073]

theorem envBound57301 : H12AffineFastState.Bounded env57301 := by
  intro p hp
  have h : env57301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57300_57301 : H12AffineEnvironment.transform 20 82215 env57300 = env57301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env57300 == env57301) = true)

theorem identity57301 : scanCanonicalize (H12AffineFastState.compose env57301 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound57301 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,65536,78034,70765,1024,32768,71051,41088,67018,107533,9332,65894,103453,5292,77954,77046,8205,74118,257,8541,78035,1789]

theorem envBound57302 : H12AffineFastState.Bounded env57302 := by
  intro p hp
  have h : env57302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57301_57302 : H12AffineEnvironment.transform 13 5292 env57301 = env57302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env57301 == env57302) = true)

theorem identity57302 : scanCanonicalize (H12AffineFastState.compose env57302 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound57302 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,33166,45404,38371,1024,32768,37893,41088,33860,9603,9332,33000,5523,5292,45324,44408,8205,40968,257,8541,45405,1789]

theorem envBound57303 : H12AffineFastState.Bounded env57303 := by
  intro p hp
  have h : env57303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57302_57303 : H12AffineEnvironment.transform 15 33166 env57302 = env57303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env57302 == env57303) = true)

def env57304 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5292,32768,33166,45324,38323,1024,32768,37893,41088,33812,9603,9252,32952,5523,5292,45324,44328,8205,40968,257,8461,45325,1709]

theorem envBound57304 : H12AffineFastState.Bounded env57304 := by
  intro p hp
  have h : env57304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57303_57304 : H12AffineEnvironment.transform 5 16 env57303 = env57304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57303 == env57304) = true)

theorem identity57304 : scanCanonicalize (H12AffineFastState.compose env57304 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound57304 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57305 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4097,32768,33166,45324,37150,173,32768,37032,41088,32953,8494,8329,32952,4414,4097,45324,43397,8205,40968,257,8461,45325,512]

theorem envBound57305 : H12AffineFastState.Bounded env57305 := by
  intro p hp
  have h : env57305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57304_57305 : H12AffineEnvironment.transform 9 173 env57304 = env57305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env57304 == env57305) = true)

theorem identity57305 : scanCanonicalize (H12AffineFastState.compose env57305 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound57305 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57306 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2563,4097,32768,33166,39695,37150,173,32768,37032,35459,32953,2861,2698,32952,4414,4097,39695,33670,2574,35339,257,2830,39694,512]

theorem envBound57306 : H12AffineFastState.Bounded env57306 := by
  intro p hp
  have h : env57306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57305_57306 : H12AffineEnvironment.transform 12 2563 env57305 = env57306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env57305 == env57306) = true)

theorem identity57306 : scanCanonicalize (H12AffineFastState.compose env57306 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57306 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57307 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2563,4097,2723,2861,4524,7101,173,2723,6667,32,2586,2861,2698,2587,4414,4097,4524,2341,2574,168,257,2830,4525,512]

theorem envBound57307 : H12AffineFastState.Bounded env57307 := by
  intro p hp
  have h : env57307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57306_57307 : H12AffineEnvironment.transform 14 2723 env57306 = env57307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57306 == env57307) = true)

theorem identity57307 : scanCanonicalize (H12AffineFastState.compose env57307 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound57307 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57308 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,2091,2563,2090,2723,2861,2439,918,173,2723,544,32,2586,2861,2698,2587,2325,2090,2439,2341,2574,168,257,2830,2438,512]

theorem envBound57308 : H12AffineFastState.Bounded env57308 := by
  intro p hp
  have h : env57308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57307_57308 : H12AffineEnvironment.transform 11 2091 env57307 = env57308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env57307 == env57308) = true)

theorem identity57308 : scanCanonicalize (H12AffineFastState.compose env57308 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound57308 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57309 : List Nat := [2,4,8,16,32,16,128,256,512,173,798,821,285,820,445,51,665,918,173,445,544,32,260,51,404,261,523,820,665,571,272,168,257,16,664,512]

theorem envBound57309 : H12AffineFastState.Bounded env57309 := by
  intro p hp
  have h : env57309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57308_57309 : H12AffineEnvironment.transform 10 798 env57308 = env57309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env57308 == env57309) = true)

theorem identity57309 : scanCanonicalize (H12AffineFastState.compose env57309 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57309 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57310 : List Nat := [2,4,8,16,32,16,57,256,512,20,798,821,285,820,260,51,544,815,20,260,544,32,260,51,301,261,523,820,544,571,272,17,257,16,545,512]

theorem envBound57310 : H12AffineFastState.Bounded env57310 := by
  intro p hp
  have h : env57310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57309_57310 : H12AffineEnvironment.transform 6 57 env57309 = env57310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57309 == env57310) = true)

def env57311 : List Nat := [2,4,8,16,16,16,9,256,512,20,798,773,285,772,260,3,528,799,20,260,528,16,260,3,285,261,523,772,528,523,272,17,257,16,529,512]

theorem envBound57311 : H12AffineFastState.Bounded env57311 := by
  intro p hp
  have h : env57311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57310_57311 : H12AffineEnvironment.transform 4 16 env57310 = env57311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57310 == env57311) = true)

theorem identity57311 : scanCanonicalize (H12AffineFastState.compose env57311 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57311 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57312 : List Nat := [2,4,8,16,16,16,9,30,512,20,512,539,3,538,26,3,528,513,20,26,528,16,26,3,3,27,523,538,528,523,14,17,31,16,529,512]

theorem envBound57312 : H12AffineFastState.Bounded env57312 := by
  intro p hp
  have h : env57312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57311_57312 : H12AffineEnvironment.transform 7 30 env57311 = env57312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57311 == env57312) = true)

theorem identity57312 : scanCanonicalize (H12AffineFastState.compose env57312 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57313 : List Nat := [2,4,8,11,11,11,9,5,512,15,512,512,3,513,1,3,523,513,15,1,523,11,1,3,3,0,523,513,523,523,14,10,4,11,522,512]

theorem envBound57313 : H12AffineFastState.Bounded env57313 := by
  intro p hp
  have h : env57313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57312_57313 : H12AffineEnvironment.transform 3 11 env57312 = env57313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57312 == env57313) = true)

def env57314 : List Nat := [2,4,8,16,17,16,8,256,512,20,798,772,285,773,260,2,529,798,20,260,529,17,260,2,284,261,523,773,529,522,272,17,257,16,528,512]

theorem envBound57314 : H12AffineFastState.Bounded env57314 := by
  intro p hp
  have h : env57314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57310_57314 : H12AffineEnvironment.transform 4 17 env57310 = env57314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57310 == env57314) = true)

theorem identity57314 : scanCanonicalize (H12AffineFastState.compose env57314 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57315 : List Nat := [2,4,8,16,17,16,8,256,11,20,277,271,285,270,260,2,26,277,20,260,26,17,260,2,284,261,0,270,26,1,272,17,257,16,27,11]

theorem envBound57315 : H12AffineFastState.Bounded env57315 := by
  intro p hp
  have h : env57315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57314_57315 : H12AffineEnvironment.transform 8 11 env57314 = env57315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57314 == env57315) = true)

theorem identity57315 : scanCanonicalize (H12AffineFastState.compose env57315 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57316 : List Nat := [2,4,8,16,17,16,8,14,11,20,27,1,19,0,10,2,26,27,20,10,26,17,10,2,18,11,0,0,26,1,30,17,15,16,27,11]

theorem envBound57316 : H12AffineFastState.Bounded env57316 := by
  intro p hp
  have h : env57316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57315_57316 : H12AffineEnvironment.transform 7 14 env57315 = env57316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57315 == env57316) = true)

def env57317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5292,32768,33166,45325,38322,1024,32768,37893,41088,33813,9603,9253,32953,5523,5292,45324,44329,8205,40968,257,8460,45324,1708]

theorem envBound57317 : H12AffineFastState.Bounded env57317 := by
  intro p hp
  have h : env57317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57303_57317 : H12AffineEnvironment.transform 5 17 env57303 = env57317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57303 == env57317) = true)

def env57318 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,32768,33166,45325,38274,1024,32768,37893,41088,33813,9603,9237,32905,5523,5276,45324,44313,8205,40968,257,8460,45324,1692]

theorem envBound57318 : H12AffineFastState.Bounded env57318 := by
  intro p hp
  have h : env57318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57317_57318 : H12AffineEnvironment.transform 4 16 env57317 = env57318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57317 == env57318) = true)

def env57319 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,1296,1182,13341,4242,1024,1296,4373,9616,261,9603,9237,1433,5523,5276,13340,10249,8205,9496,257,8460,13340,1692]

theorem envBound57319 : H12AffineFastState.Bounded env57319 := by
  intro p hp
  have h : env57319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57318_57319 : H12AffineEnvironment.transform 14 1296 env57318 = env57319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57318 == env57319) = true)

theorem identity57319 : scanCanonicalize (H12AffineFastState.compose env57319 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6543) := by decide +kernel

theorem selectedBound57319 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57320 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,6543,5276,1296,1182,3474,4242,1024,1296,4373,7199,261,7180,7578,1433,5523,5276,3475,4486,6530,7319,257,6275,3475,1692]

theorem envBound57320 : H12AffineFastState.Bounded env57320 := by
  intro p hp
  have h : env57320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57319_57320 : H12AffineEnvironment.transform 12 6543 env57319 = env57320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6543 env57319 == env57320) = true)

theorem identity57320 : scanCanonicalize (H12AffineFastState.compose env57320 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57320 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57321 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,4096,6543,4233,261,139,2439,4242,21,261,4373,6154,261,6169,6543,396,4486,4233,2438,4486,6530,6274,257,6275,2438,649]

theorem envBound57321 : H12AffineFastState.Bounded env57321 := by
  intro p hp
  have h : env57321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57320_57321 : H12AffineEnvironment.transform 9 21 env57320 = env57321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57320 == env57321) = true)

theorem identity57321 : scanCanonicalize (H12AffineFastState.compose env57321 (packedSelected [2,3,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound57321 : packedSelected [2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env57322 : List Nat := [2,4,8,16,16,17,128,256,512,21,799,4096,4752,4233,261,139,664,4242,21,261,4373,4885,261,4870,4752,396,4486,4233,665,4486,4765,5021,257,5020,665,649]

theorem envBound57322 : H12AffineFastState.Bounded env57322 := by
  intro p hp
  have h : env57322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57321_57322 : H12AffineEnvironment.transform 10 799 env57321 = env57322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env57321 == env57322) = true)

theorem identity57322 : scanCanonicalize (H12AffineFastState.compose env57322 (packedSelected [2,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound57322 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env57323 : List Nat := [2,4,8,16,16,17,128,256,512,21,799,529,129,664,261,139,664,643,21,261,772,260,261,279,129,396,919,664,665,919,140,396,257,397,665,649]

theorem envBound57323 : H12AffineFastState.Bounded env57323 := by
  intro p hp
  have h : env57323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57322_57323 : H12AffineEnvironment.transform 11 529 env57322 = env57323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env57322 == env57323) = true)

theorem identity57323 : scanCanonicalize (H12AffineFastState.compose env57323 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound57323 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env57324 : List Nat := [2,4,8,16,16,17,128,157,512,21,642,529,129,664,152,139,664,643,21,152,665,153,152,138,129,17,522,664,665,522,140,17,156,16,665,649]

theorem envBound57324 : H12AffineFastState.Bounded env57324 := by
  intro p hp
  have h : env57324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57323_57324 : H12AffineEnvironment.transform 7 157 env57323 = env57324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env57323 == env57324) = true)

theorem identity57324 : scanCanonicalize (H12AffineFastState.compose env57324 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound57324 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57325 : List Nat := [2,4,8,16,16,17,128,157,16,21,146,1,129,136,152,139,136,147,21,152,137,153,152,138,129,17,26,136,137,26,140,17,156,16,137,153]

theorem envBound57325 : H12AffineFastState.Bounded env57325 := by
  intro p hp
  have h : env57325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57324_57325 : H12AffineEnvironment.transform 8 16 env57324 = env57325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env57324 == env57325) = true)

theorem identity57325 : scanCanonicalize (H12AffineFastState.compose env57325 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57325 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57326 : List Nat := [2,4,8,10,10,11,128,135,10,15,136,1,129,136,130,139,136,137,15,130,137,131,130,138,129,11,0,136,137,0,140,11,134,10,137,131]

theorem envBound57326 : H12AffineFastState.Bounded env57326 := by
  intro p hp
  have h : env57326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57325_57326 : H12AffineEnvironment.transform 3 10 env57325 = env57326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57325 == env57326) = true)

theorem identity57326 : scanCanonicalize (H12AffineFastState.compose env57326 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57326 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57327 : List Nat := [2,4,8,10,10,11,9,14,10,15,1,1,8,1,11,2,1,0,15,11,0,10,11,3,8,11,0,1,0,0,5,11,15,10,0,10]

theorem envBound57327 : H12AffineFastState.Bounded env57327 := by
  intro p hp
  have h : env57327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57326_57327 : H12AffineEnvironment.transform 6 9 env57326 = env57327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57326 == env57327) = true)

def env57328 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,1297,1183,13340,4243,1024,1297,4372,9617,260,9603,9237,1432,5523,5276,13341,10248,8205,9497,257,8460,13341,1692]

theorem envBound57328 : H12AffineFastState.Bounded env57328 := by
  intro p hp
  have h : env57328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57318_57328 : H12AffineEnvironment.transform 14 1297 env57318 = env57328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57318 == env57328) = true)

theorem identity57328 : scanCanonicalize (H12AffineFastState.compose env57328 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6406) := by decide +kernel

theorem selectedBound57328 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57329 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,6406,5276,1297,1183,3354,4243,1024,1297,4372,7319,260,7301,7443,1432,5523,5276,3355,4366,6411,7199,257,6154,3355,1692]

theorem envBound57329 : H12AffineFastState.Bounded env57329 := by
  intro p hp
  have h : env57329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57328_57329 : H12AffineEnvironment.transform 12 6406 env57328 = env57329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6406 env57328 == env57329) = true)

theorem identity57329 : scanCanonicalize (H12AffineFastState.compose env57329 (packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound57329 : packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env57330 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,1945,3743,773,1297,1183,3354,1802,1024,1297,1677,2830,260,2844,2698,1432,522,773,3355,1687,3730,2950,257,3987,3355,1692]

theorem envBound57330 : H12AffineFastState.Bounded env57330 := by
  intro p hp
  have h : env57330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57329_57330 : H12AffineEnvironment.transform 11 1945 env57329 = env57330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env57329 == env57330) = true)

theorem identity57330 : scanCanonicalize (H12AffineFastState.compose env57330 (packedSelected [8,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound57330 : packedSelected [8,10,13] rootPS < 2^1333 := by decide +kernel

def env57331 : List Nat := [2,4,8,16,16,17,128,256,512,30,2048,903,2689,773,271,129,2308,788,30,271,659,2830,260,2844,2698,390,522,773,2309,649,2700,2950,257,2957,2309,642]

theorem envBound57331 : H12AffineFastState.Bounded env57331 := by
  intro p hp
  have h : env57331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57330_57331 : H12AffineEnvironment.transform 9 30 env57330 = env57331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env57330 == env57331) = true)

theorem identity57331 : scanCanonicalize (H12AffineFastState.compose env57331 (packedSelected [0,1,2,4,5,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57331 : packedSelected [0,1,2,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env57332 : List Nat := [2,4,8,16,16,17,128,15,512,30,2048,648,2689,522,0,129,2059,539,30,0,659,2561,11,2579,2698,137,522,522,2058,649,2700,2697,14,2690,2058,642]

theorem envBound57332 : H12AffineFastState.Bounded env57332 := by
  intro p hp
  have h : env57332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57331_57332 : H12AffineEnvironment.transform 7 15 env57331 = env57332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57331 == env57332) = true)

theorem identity57332 : scanCanonicalize (H12AffineFastState.compose env57332 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound57332 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env57333 : List Nat := [2,4,8,16,16,17,128,15,512,30,659,648,18,522,0,129,664,539,30,0,659,146,11,128,25,137,522,522,665,649,31,26,14,17,665,642]

theorem envBound57333 : H12AffineFastState.Bounded env57333 := by
  intro p hp
  have h : env57333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57332_57333 : H12AffineEnvironment.transform 10 659 env57332 = env57333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env57332 == env57333) = true)

theorem identity57333 : scanCanonicalize (H12AffineFastState.compose env57333 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57333 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57334 : List Nat := [2,4,8,11,11,10,128,15,512,5,648,648,9,522,0,129,643,512,5,0,648,137,11,128,2,137,522,522,642,649,4,1,14,10,642,642]

theorem envBound57334 : H12AffineFastState.Bounded env57334 := by
  intro p hp
  have h : env57334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57333_57334 : H12AffineEnvironment.transform 3 11 env57333 = env57334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57333 == env57334) = true)

def env57335 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,32768,33166,45325,38275,1024,32768,37893,41088,33813,9603,9236,32904,5523,5277,45324,44312,8205,40968,257,8460,45324,1693]

theorem envBound57335 : H12AffineFastState.Bounded env57335 := by
  intro p hp
  have h : env57335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57317_57335 : H12AffineEnvironment.transform 4 17 env57317 = env57335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57317 == env57335) = true)

def env57336 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,1296,1182,13341,4243,1024,1296,4373,9616,261,9603,9236,1432,5523,5277,13340,10248,8205,9496,257,8460,13340,1693]

theorem envBound57336 : H12AffineFastState.Bounded env57336 := by
  intro p hp
  have h : env57336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57335_57336 : H12AffineEnvironment.transform 14 1296 env57335 = env57336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57335 == env57336) = true)

theorem identity57336 : scanCanonicalize (H12AffineFastState.compose env57336 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound57336 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57337 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,2195,8192,3086,1296,1182,11406,2048,1024,1296,2438,9616,261,9603,9236,1432,3328,3086,11407,10248,8205,9496,257,8460,11407,1693]

theorem envBound57337 : H12AffineFastState.Bounded env57337 := by
  intro p hp
  have h : env57337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57336_57337 : H12AffineEnvironment.transform 11 2195 env57336 = env57337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env57336 == env57337) = true)

theorem identity57337 : scanCanonicalize (H12AffineFastState.compose env57337 (packedSelected [3,4,5,7,10,11,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57337 : packedSelected [3,4,5,7,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env57338 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,2075,8192,3086,1296,1046,11270,2048,1024,1296,2318,9496,261,9483,9236,1296,3328,3086,11271,10248,8205,9496,257,8460,11271,1557]

theorem envBound57338 : H12AffineFastState.Bounded env57338 := by
  intro p hp
  have h : env57338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57337_57338 : H12AffineEnvironment.transform 6 8 env57337 = env57338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57337 == env57338) = true)

theorem identity57338 : scanCanonicalize (H12AffineFastState.compose env57338 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57338 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57339 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,2075,1289,3086,1296,1046,2319,2048,1024,1296,2318,17,261,2,285,1296,3328,3086,2318,3329,1284,17,257,1029,2318,1557]

theorem envBound57339 : H12AffineFastState.Bounded env57339 := by
  intro p hp
  have h : env57339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57338_57339 : H12AffineEnvironment.transform 12 1289 env57338 = env57339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57338 == env57339) = true)

theorem identity57339 : scanCanonicalize (H12AffineFastState.compose env57339 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound57339 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57340 : List Nat := [2,4,8,16,17,17,8,4,512,1024,2048,2075,1037,3086,1044,1046,2059,2048,1024,1044,2058,17,1,2,25,1044,3076,3086,2058,3077,1024,17,5,1029,2058,1557]

theorem envBound57340 : H12AffineFastState.Bounded env57340 := by
  intro p hp
  have h : env57340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57339_57340 : H12AffineEnvironment.transform 7 4 env57339 = env57340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57339 == env57340) = true)

theorem identity57340 : scanCanonicalize (H12AffineFastState.compose env57340 (packedSelected [1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57340 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env57341 : List Nat := [2,4,8,11,10,10,8,4,512,1024,2048,2048,1037,3086,1039,1037,2059,2048,1024,1039,2058,10,1,2,2,1039,3076,3086,2058,3077,1024,10,5,1029,2058,1550]

theorem envBound57341 : H12AffineFastState.Bounded env57341 := by
  intro p hp
  have h : env57341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57340_57341 : H12AffineEnvironment.transform 3 11 env57340 = env57341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57340 == env57341) = true)

theorem identity57341 : scanCanonicalize (H12AffineFastState.compose env57341 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound57341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57342 : List Nat := [2,4,8,11,10,10,8,4,512,14,2048,2048,3,2048,1,3,2059,2048,14,1,2058,10,1,2,2,1,2058,2048,2058,2059,14,10,5,11,2058,512]

theorem envBound57342 : H12AffineFastState.Bounded env57342 := by
  intro p hp
  have h : env57342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57341_57342 : H12AffineEnvironment.transform 9 14 env57341 = env57342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env57341 == env57342) = true)

theorem identity57342 : scanCanonicalize (H12AffineFastState.compose env57342 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound57342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57343 : List Nat := [2,4,8,11,10,10,8,4,512,14,512,512,3,512,1,3,523,512,14,1,522,10,1,2,2,1,522,512,522,523,14,10,5,11,522,512]

theorem envBound57343 : H12AffineFastState.Bounded env57343 := by
  intro p hp
  have h : env57343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57342_57343 : H12AffineEnvironment.transform 10 512 env57342 = env57343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env57342 == env57343) = true)

def env57344 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,1297,1183,13340,4242,1024,1297,4372,9617,260,9603,9236,1433,5523,5277,13341,10249,8205,9497,257,8460,13341,1693]

theorem envBound57344 : H12AffineFastState.Bounded env57344 := by
  intro p hp
  have h : env57344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57335_57344 : H12AffineEnvironment.transform 14 1297 env57335 = env57344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57335 == env57344) = true)

theorem identity57344 : scanCanonicalize (H12AffineFastState.compose env57344 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound57344 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57345 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,2074,8192,3207,1297,1183,11270,2184,1024,1297,2318,9617,260,9603,9236,1433,3465,3207,11271,10249,8205,9497,257,8460,11271,1693]

theorem envBound57345 : H12AffineFastState.Bounded env57345 := by
  intro p hp
  have h : env57345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57344_57345 : H12AffineEnvironment.transform 11 2074 env57344 = env57345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env57344 == env57345) = true)

theorem identity57345 : scanCanonicalize (H12AffineFastState.compose env57345 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound57345 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57346 : List Nat := [2,4,8,16,17,17,128,256,512,20,2048,2074,8192,2195,261,139,10258,2184,20,261,2318,8581,260,8599,8192,397,2461,2195,10259,10249,8205,8461,257,8460,10259,649]

theorem envBound57346 : H12AffineFastState.Bounded env57346 := by
  intro p hp
  have h : env57346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57345_57346 : H12AffineEnvironment.transform 9 20 env57345 = env57346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env57345 == env57346) = true)

theorem identity57346 : scanCanonicalize (H12AffineFastState.compose env57346 (packedSelected [0,1,4,5,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2839) := by decide +kernel

theorem selectedBound57346 : packedSelected [0,1,4,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57347 : List Nat := [2,4,8,16,17,17,128,256,512,20,2048,2074,2839,2195,261,139,773,2184,20,261,2318,2706,260,2688,2839,397,2461,2195,772,798,2842,2586,257,2587,772,649]

theorem envBound57347 : H12AffineFastState.Bounded env57347 := by
  intro p hp
  have h : env57347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57346_57347 : H12AffineEnvironment.transform 12 2839 env57346 = env57347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2839 env57346 == env57347) = true)

theorem identity57347 : scanCanonicalize (H12AffineFastState.compose env57347 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound57347 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57348 : List Nat := [2,4,8,16,17,17,128,157,512,20,2048,2074,2698,2195,152,139,664,2184,20,152,2195,2706,153,2688,2698,16,2048,2195,665,643,2695,2586,156,2587,665,649]

theorem envBound57348 : H12AffineFastState.Bounded env57348 := by
  intro p hp
  have h : env57348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57347_57348 : H12AffineEnvironment.transform 7 157 env57347 = env57348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env57347 == env57348) = true)

theorem identity57348 : scanCanonicalize (H12AffineFastState.compose env57348 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57348 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57349 : List Nat := [2,4,8,16,17,17,9,20,512,20,2048,2074,2563,2074,17,2,529,2049,20,17,2074,2587,16,2569,2563,16,2048,2074,528,522,2574,2586,21,2587,528,512]

theorem envBound57349 : H12AffineFastState.Bounded env57349 := by
  intro p hp
  have h : env57349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57348_57349 : H12AffineEnvironment.transform 6 9 env57348 = env57349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57348 == env57349) = true)

theorem identity57349 : scanCanonicalize (H12AffineFastState.compose env57349 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound57349 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57350 : List Nat := [2,4,8,16,17,17,9,20,512,20,27,1,536,1,17,2,529,26,20,17,1,512,16,530,536,16,27,1,528,522,533,513,21,512,528,512]

theorem envBound57350 : H12AffineFastState.Bounded env57350 := by
  intro p hp
  have h : env57350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57349_57350 : H12AffineEnvironment.transform 10 27 env57349 = env57350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env57349 == env57350) = true)

theorem identity57350 : scanCanonicalize (H12AffineFastState.compose env57350 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57350 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57351 : List Nat := [2,4,8,16,17,17,9,20,10,20,27,1,18,1,17,2,27,26,20,17,1,10,16,24,18,16,27,1,26,0,31,11,21,10,26,10]

theorem envBound57351 : H12AffineFastState.Bounded env57351 := by
  intro p hp
  have h : env57351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57350_57351 : H12AffineEnvironment.transform 8 10 env57350 = env57351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57350 == env57351) = true)

theorem identity57351 : scanCanonicalize (H12AffineFastState.compose env57351 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57351 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57352 : List Nat := [2,4,8,10,11,11,9,14,10,14,1,1,8,1,11,2,1,0,14,11,1,10,10,2,8,10,1,1,0,0,5,11,15,10,0,10]

theorem envBound57352 : H12AffineFastState.Bounded env57352 := by
  intro p hp
  have h : env57352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57351_57352 : H12AffineEnvironment.transform 3 10 env57351 = env57352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57351 == env57352) = true)

theorem identity57352 : scanCanonicalize (H12AffineFastState.compose env57352 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57353 : List Nat := [2,4,2,0,1,1,3,4,0,4,1,1,2,1,1,2,1,0,4,1,1,0,0,2,2,0,1,1,0,0,5,1,5,0,0,0]

theorem envBound57353 : H12AffineFastState.Bounded env57353 := by
  intro p hp
  have h : env57353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57352_57353 : H12AffineEnvironment.transform 2 2 env57352 = env57353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57352 == env57353) = true)

def env57354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142599,28889,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57354 : H12AffineFastState.Bounded env57354 := by
  intro p hp
  have h : env57354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57299_57354 : H12AffineEnvironment.transform 21 41089 env57299 = env57354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57299 == env57354) = true)

theorem identity57354 : scanCanonicalize (H12AffineFastState.compose env57354 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 66663) := by decide +kernel

theorem selectedBound57354 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,66663,41089,70695,112096,28889,82983,103452,16384,77954,96347,12768,74119,257,25628,78035,21072]

theorem envBound57355 : H12AffineFastState.Bounded env57355 := by
  intro p hp
  have h : env57355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57354_57355 : H12AffineEnvironment.transform 20 66663 env57354 = env57355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66663 env57354 == env57355) = true)

theorem identity57355 : scanCanonicalize (H12AffineFastState.compose env57355 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57355 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,16384,32768,65536,71131,82113,1024,32768,66663,34184,70695,102633,21968,82983,103452,16384,71051,89426,5353,66702,257,16661,71130,21072]

theorem envBound57356 : H12AffineFastState.Bounded env57356 := by
  intro p hp
  have h : env57356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57355_57356 : H12AffineEnvironment.transform 12 1289 env57355 = env57356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57355 == env57356) = true)

theorem identity57356 : scanCanonicalize (H12AffineFastState.compose env57356 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57356 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,445,32768,65536,71131,65916,1024,32768,66663,34184,70695,102633,5229,66970,103452,445,71051,72943,5353,66702,257,168,71130,5101]

theorem envBound57357 : H12AffineFastState.Bounded env57357 := by
  intro p hp
  have h : env57357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57356_57357 : H12AffineEnvironment.transform 13 445 env57356 = env57357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57356 == env57357) = true)

theorem identity57357 : scanCanonicalize (H12AffineFastState.compose env57357 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57357 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,65536,66614,65916,1024,32768,66663,34184,67018,98564,1408,66970,99825,445,66662,68866,1284,66702,257,168,66615,512]

theorem envBound57358 : H12AffineFastState.Bounded env57358 := by
  intro p hp
  have h : env57358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57357_57358 : H12AffineEnvironment.transform 11 493 env57357 = env57358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57357 == env57358) = true)

theorem identity57358 : scanCanonicalize (H12AffineFastState.compose env57358 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57358 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,1874,868,1582,1024,32768,821,34184,664,34390,1408,712,33443,445,820,2640,1284,988,257,168,869,512]

theorem envBound57359 : H12AffineFastState.Bounded env57359 := by
  intro p hp
  have h : env57359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57358_57359 : H12AffineEnvironment.transform 15 1874 env57358 = env57359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57358 == env57359) = true)

def env57360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,4247641,8409088,10798237,16384,77954,4315354,8463815,10564039,257,6406394,78035,4256464]

theorem envBound57360 : H12AffineFastState.Bounded env57360 := by
  intro p hp
  have h : env57360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57160_57360 : H12AffineEnvironment.transform 24 4247641 env57160 = env57360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env57160 == env57360) = true)

def env57361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4486237,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound57361 : H12AffineFastState.Bounded env57361 := by
  intro p hp
  have h : env57361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57360_57361 : H12AffineEnvironment.transform 22 6336704 env57360 = env57361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env57360 == env57361) = true)

def env57362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4273309,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound57362 : H12AffineFastState.Bounded env57362 := by
  intro p hp
  have h : env57362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57361_57362 : H12AffineEnvironment.transform 17 82112 env57361 = env57362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57361 == env57362) = true)

def env57363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142599,28889,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57363 : H12AffineFastState.Bounded env57363 := by
  intro p hp
  have h : env57363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57362_57363 : H12AffineEnvironment.transform 21 41088 env57362 = env57363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57362 == env57363) = true)

theorem identity57363 : scanCanonicalize (H12AffineFastState.compose env57363 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 98403) := by decide +kernel

theorem selectedBound57363 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,98403,41088,102435,78308,28889,114723,103453,16384,77954,96346,46564,74119,257,57369,78035,21072]

theorem envBound57364 : H12AffineFastState.Bounded env57364 := by
  intro p hp
  have h : env57364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57363_57364 : H12AffineEnvironment.transform 20 98403 env57363 = env57364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 98403 env57363 == env57364) = true)

theorem identity57364 : scanCanonicalize (H12AffineFastState.compose env57364 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57364 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,32768,65536,78034,79256,1024,32768,98403,41088,102435,78308,1409,111995,103453,13656,77954,68866,46564,74119,257,38209,78035,9992]

theorem envBound57365 : H12AffineFastState.Bounded env57365 := by
  intro p hp
  have h : env57365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57364_57365 : H12AffineEnvironment.transform 13 13656 env57364 = env57365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57364 == env57365) = true)

theorem identity57365 : scanCanonicalize (H12AffineFastState.compose env57365 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5608) := by decide +kernel

theorem selectedBound57365 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5608,65536,78034,79256,1024,5608,71051,13672,67019,78308,1409,73875,66037,13656,77954,68866,8204,74119,257,169,78035,9992]

theorem envBound57366 : H12AffineFastState.Bounded env57366 := by
  intro p hp
  have h : env57366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57365_57366 : H12AffineEnvironment.transform 14 5608 env57365 = env57366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5608 env57365 == env57366) = true)

theorem identity57366 : scanCanonicalize (H12AffineFastState.compose env57366 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57366 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,65536,71131,69777,1024,5608,71051,4193,67019,70893,1409,66970,66037,4177,71051,68866,1285,66702,257,169,71130,513]

theorem envBound57367 : H12AffineFastState.Bounded env57367 := by
  intro p hp
  have h : env57367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57366_57367 : H12AffineEnvironment.transform 12 1289 env57366 = env57367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57366 == env57367) = true)

theorem identity57367 : scanCanonicalize (H12AffineFastState.compose env57367 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound57367 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,514,6105,4755,1024,5608,6025,4193,1993,5871,1409,1944,1015,4177,6025,3840,1285,1676,257,169,6104,513]

theorem envBound57368 : H12AffineFastState.Bounded env57368 := by
  intro p hp
  have h : env57368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57367_57368 : H12AffineEnvironment.transform 15 514 env57367 = env57368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env57367 == env57368) = true)

theorem identity57368 : scanCanonicalize (H12AffineFastState.compose env57368 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57368 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,444,1029,514,1588,894,1024,1029,1636,396,1993,1794,1409,1944,1015,444,1636,3840,1285,1676,257,169,1589,513]

theorem envBound57369 : H12AffineFastState.Bounded env57369 := by
  intro p hp
  have h : env57369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57368_57369 : H12AffineEnvironment.transform 11 493 env57368 = env57369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57368 == env57369) = true)

theorem identity57369 : scanCanonicalize (H12AffineFastState.compose env57369 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound57369 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,493,1289,444,1029,514,1588,894,1024,1029,1636,396,1993,1794,1409,1944,1015,444,1636,10,1285,1676,257,169,1589,513]

theorem envBound57370 : H12AffineFastState.Bounded env57370 := by
  intro p hp
  have h : env57370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57369_57370 : H12AffineEnvironment.transform 10 1802 env57369 = env57370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env57369 == env57370) = true)

theorem identity57370 : scanCanonicalize (H12AffineFastState.compose env57370 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57370 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57371 : List Nat := [2,4,8,16,32,64,128,256,512,904,130,493,641,444,909,514,444,894,904,909,492,396,65,138,521,16,1015,444,492,10,653,260,257,169,445,513]

theorem envBound57371 : H12AffineFastState.Bounded env57371 := by
  intro p hp
  have h : env57371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57370_57371 : H12AffineEnvironment.transform 9 904 env57370 = env57371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57370 == env57371) = true)

theorem identity57371 : scanCanonicalize (H12AffineFastState.compose env57371 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound57371 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57372 : List Nat := [2,4,8,16,32,64,120,256,512,880,122,277,633,324,885,514,324,894,880,885,276,372,65,114,521,16,783,324,276,10,629,260,257,81,325,513]

theorem envBound57372 : H12AffineFastState.Bounded env57372 := by
  intro p hp
  have h : env57372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57371_57372 : H12AffineEnvironment.transform 6 120 env57371 = env57372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env57371 == env57372) = true)

def env57373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142598,28888,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57373 : H12AffineFastState.Bounded env57373 := by
  intro p hp
  have h : env57373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57362_57373 : H12AffineEnvironment.transform 21 41089 env57362 = env57373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57362 == env57373) = true)

theorem identity57373 : scanCanonicalize (H12AffineFastState.compose env57373 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 116003) := by decide +kernel

theorem selectedBound57373 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,116003,41089,120162,95397,28888,99682,103452,16384,77954,96347,61605,74118,257,42328,78035,21073]

theorem envBound57374 : H12AffineFastState.Bounded env57374 := by
  intro p hp
  have h : env57374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57373_57374 : H12AffineEnvironment.transform 20 116003 env57373 = env57374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116003 env57373 == env57374) = true)

theorem identity57374 : scanCanonicalize (H12AffineFastState.compose env57374 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound57374 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,248,65536,78034,82112,1024,248,83419,8313,87450,95397,28888,66970,70884,16384,77954,96347,28765,74118,257,9632,78035,21073]

theorem envBound57375 : H12AffineFastState.Bounded env57375 := by
  intro p hp
  have h : env57375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57374_57375 : H12AffineEnvironment.transform 14 248 env57374 = env57375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env57374 == env57375) = true)

theorem identity57375 : scanCanonicalize (H12AffineFastState.compose env57375 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57375 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,65536,78034,69777,1024,248,71050,8313,67019,74996,8329,66970,70884,4177,77954,75786,8204,74118,257,9632,78035,512]

theorem envBound57376 : H12AffineFastState.Bounded env57376 := by
  intro p hp
  have h : env57376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57375_57376 : H12AffineEnvironment.transform 13 4177 env57375 = env57376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57375 == env57376) = true)

theorem identity57376 : scanCanonicalize (H12AffineFastState.compose env57376 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound57376 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,374,12708,4583,1024,248,5372,8313,1213,9602,8329,1260,5522,4177,12788,10620,8204,8432,257,9632,12709,512]

theorem envBound57377 : H12AffineFastState.Bounded env57377 := by
  intro p hp
  have h : env57377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57376_57377 : H12AffineEnvironment.transform 15 374 env57376 = env57377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env57376 == env57377) = true)

theorem identity57377 : scanCanonicalize (H12AffineFastState.compose env57377 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57377 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,248,374,8026,4583,1024,248,5372,3719,1213,2940,3703,1260,5522,4177,7946,1922,3826,3598,257,2910,8027,512]

theorem envBound57378 : H12AffineFastState.Bounded env57378 := by
  intro p hp
  have h : env57378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57377_57378 : H12AffineEnvironment.transform 12 3838 env57377 = env57378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57377 == env57378) = true)

theorem identity57378 : scanCanonicalize (H12AffineFastState.compose env57378 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57378 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,89,4177,248,374,4605,4583,1024,248,5372,32,1213,1499,208,1260,5522,4177,4525,1922,85,169,257,1529,4604,512]

theorem envBound57379 : H12AffineFastState.Bounded env57379 := by
  intro p hp
  have h : env57379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57378_57379 : H12AffineEnvironment.transform 10 1703 env57378 = env57379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57378 == env57379) = true)

def env57380 : List Nat := [2,4,8,16,32,64,128,256,512,392,815,4096,89,4177,248,374,4605,4583,392,248,4468,32,309,83,208,356,4122,4177,4525,522,85,169,257,113,4604,512]

theorem envBound57380 : H12AffineFastState.Bounded env57380 := by
  intro p hp
  have h : env57380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57379_57380 : H12AffineEnvironment.transform 9 392 env57379 = env57380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env57379 == env57380) = true)

def env57381 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,4096,41,4129,136,262,4493,4503,392,136,4356,32,309,35,160,276,4122,4129,4525,522,37,169,257,1,4492,512]

theorem envBound57381 : H12AffineFastState.Bounded env57381 := by
  intro p hp
  have h : env57381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57380_57381 : H12AffineEnvironment.transform 5 48 env57380 = env57381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57380 == env57381) = true)

theorem identity57381 : scanCanonicalize (H12AffineFastState.compose env57381 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57382 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,555,41,522,136,262,934,956,392,136,815,32,309,35,160,276,561,522,902,522,37,169,257,1,935,512]

theorem envBound57382 : H12AffineFastState.Bounded env57382 := by
  intro p hp
  have h : env57382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57381_57382 : H12AffineEnvironment.transform 11 555 env57381 = env57382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57381 == env57382) = true)

theorem identity57382 : scanCanonicalize (H12AffineFastState.compose env57382 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound57382 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57383 : List Nat := [2,4,8,16,32,48,128,166,512,46,649,555,41,522,136,160,512,538,46,136,649,32,147,35,160,178,561,522,544,522,37,169,167,1,513,512]

theorem envBound57383 : H12AffineFastState.Bounded env57383 := by
  intro p hp
  have h : env57383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57382_57383 : H12AffineEnvironment.transform 7 166 env57382 = env57383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env57382 == env57383) = true)

theorem identity57383 : scanCanonicalize (H12AffineFastState.compose env57383 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57383 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57384 : List Nat := [2,4,8,16,32,48,41,15,512,46,544,555,41,522,33,9,512,538,46,33,544,32,58,35,9,27,561,522,544,522,37,0,14,1,513,512]

theorem envBound57384 : H12AffineFastState.Bounded env57384 := by
  intro p hp
  have h : env57384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57383_57384 : H12AffineEnvironment.transform 6 41 env57383 = env57384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57383 == env57384) = true)

theorem identity57384 : scanCanonicalize (H12AffineFastState.compose env57384 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57384 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57385 : List Nat := [2,4,8,10,32,42,41,15,512,46,544,555,41,522,33,9,512,512,46,33,544,32,32,35,9,1,555,522,544,522,37,0,14,1,513,512]

theorem envBound57385 : H12AffineFastState.Bounded env57385 := by
  intro p hp
  have h : env57385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57384_57385 : H12AffineEnvironment.transform 3 10 env57384 = env57385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57384 == env57385) = true)

theorem identity57385 : scanCanonicalize (H12AffineFastState.compose env57385 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57385 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57386 : List Nat := [2,4,8,10,10,0,3,15,512,4,522,513,3,522,11,9,512,512,4,11,522,10,10,9,9,1,513,522,522,522,15,0,14,1,513,512]

theorem envBound57386 : H12AffineFastState.Bounded env57386 := by
  intro p hp
  have h : env57386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57385_57386 : H12AffineEnvironment.transform 4 10 env57385 = env57386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57385 == env57386) = true)

def env57387 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,4096,40,4128,137,263,4492,4502,392,137,4357,32,309,34,161,277,4122,4128,4525,522,36,169,257,0,4493,512]

theorem envBound57387 : H12AffineFastState.Bounded env57387 := by
  intro p hp
  have h : env57387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57380_57387 : H12AffineEnvironment.transform 5 49 env57380 = env57387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57380 == env57387) = true)

theorem identity57387 : scanCanonicalize (H12AffineFastState.compose env57387 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57388 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,642,40,674,137,263,782,788,392,137,903,32,309,34,161,277,664,674,815,522,36,169,257,0,783,512]

theorem envBound57388 : H12AffineFastState.Bounded env57388 := by
  intro p hp
  have h : env57388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57387_57388 : H12AffineEnvironment.transform 11 642 env57387 = env57388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57387 == env57388) = true)

theorem identity57388 : scanCanonicalize (H12AffineFastState.compose env57388 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound57388 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57389 : List Nat := [2,4,8,16,32,49,128,188,512,52,659,642,40,674,137,187,690,680,52,137,571,32,137,34,161,169,664,674,659,522,36,169,189,0,691,512]

theorem envBound57389 : H12AffineFastState.Bounded env57389 := by
  intro p hp
  have h : env57389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57388_57389 : H12AffineEnvironment.transform 7 188 env57388 = env57389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env57388 == env57389) = true)

theorem identity57389 : scanCanonicalize (H12AffineFastState.compose env57389 (packedSelected [0,3,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57389 : packedSelected [0,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57390 : List Nat := [2,4,8,11,32,42,128,167,512,47,648,642,40,674,137,160,681,680,47,137,544,32,137,34,161,169,643,674,648,522,36,169,166,0,680,512]

theorem envBound57390 : H12AffineFastState.Bounded env57390 := by
  intro p hp
  have h : env57390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57389_57390 : H12AffineEnvironment.transform 3 11 env57389 = env57390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57389 == env57390) = true)

theorem identity57390 : scanCanonicalize (H12AffineFastState.compose env57390 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound57390 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57391 : List Nat := [2,4,8,11,32,42,128,167,43,47,163,169,40,137,137,160,130,131,47,137,11,32,137,34,161,169,168,137,163,33,36,169,166,0,131,43]

theorem envBound57391 : H12AffineFastState.Bounded env57391 := by
  intro p hp
  have h : env57391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57390_57391 : H12AffineEnvironment.transform 8 43 env57390 = env57391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env57390 == env57391) = true)

theorem identity57391 : scanCanonicalize (H12AffineFastState.compose env57391 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound57391 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57392 : List Nat := [2,4,8,11,32,42,35,4,43,47,0,10,40,42,42,3,33,32,47,42,11,32,42,34,2,10,11,42,0,33,36,10,5,0,32,43]

theorem envBound57392 : H12AffineFastState.Bounded env57392 := by
  intro p hp
  have h : env57392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57391_57392 : H12AffineEnvironment.transform 6 35 env57391 = env57392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env57391 == env57392) = true)

theorem identity57392 : scanCanonicalize (H12AffineFastState.compose env57392 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57392 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57393 : List Nat := [2,4,8,11,0,10,3,4,11,15,0,10,8,10,10,3,1,0,15,10,11,0,10,2,2,10,11,10,0,1,4,10,5,0,0,11]

theorem envBound57393 : H12AffineFastState.Bounded env57393 := by
  intro p hp
  have h : env57393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57392_57393 : H12AffineEnvironment.transform 4 0 env57392 = env57393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57392 == env57393) = true)

theorem identity57393 : scanCanonicalize (H12AffineFastState.compose env57393 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57394 : List Nat := [2,4,3,0,0,1,3,4,0,4,0,1,3,1,1,3,1,0,4,1,0,0,1,2,2,1,0,1,0,1,4,1,5,0,0,0]

theorem envBound57394 : H12AffineFastState.Bounded env57394 := by
  intro p hp
  have h : env57394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57393_57394 : H12AffineEnvironment.transform 2 3 env57393 = env57394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57393 == env57394) = true)

def env57395 : List Nat := [2,4,8,16,32,64,128,256,512,393,814,4096,89,4177,248,374,4605,4583,393,248,4469,32,308,82,208,357,4123,4177,4525,523,85,169,257,112,4604,512]

theorem envBound57395 : H12AffineFastState.Bounded env57395 := by
  intro p hp
  have h : env57395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57379_57395 : H12AffineEnvironment.transform 9 393 env57379 = env57395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env57379 == env57395) = true)

def env57396 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,4096,41,4129,136,262,4493,4503,393,136,4357,32,308,34,160,277,4123,4129,4525,523,37,169,257,0,4492,512]

theorem envBound57396 : H12AffineFastState.Bounded env57396 := by
  intro p hp
  have h : env57396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57395_57396 : H12AffineEnvironment.transform 5 48 env57395 = env57396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57395 == env57396) = true)

theorem identity57396 : scanCanonicalize (H12AffineFastState.compose env57396 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 815) := by decide +kernel

theorem selectedBound57396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57397 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,815,41,782,136,262,674,696,393,136,554,32,308,34,160,277,820,782,642,523,37,169,257,0,675,512]

theorem envBound57397 : H12AffineFastState.Bounded env57397 := by
  intro p hp
  have h : env57397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57396_57397 : H12AffineEnvironment.transform 11 815 env57396 = env57397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 815 env57396 == env57397) = true)

theorem identity57397 : scanCanonicalize (H12AffineFastState.compose env57397 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound57397 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57398 : List Nat := [2,4,8,16,32,48,128,256,162,393,396,397,41,428,136,262,0,26,393,136,136,32,308,34,160,277,406,428,32,169,37,169,257,0,1,162]

theorem envBound57398 : H12AffineFastState.Bounded env57398 := by
  intro p hp
  have h : env57398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57397_57398 : H12AffineEnvironment.transform 8 162 env57397 = env57398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env57397 == env57398) = true)

def env57399 : List Nat := [2,4,8,16,32,48,128,4,162,141,136,137,41,168,136,2,0,26,141,136,136,32,48,34,160,17,146,168,32,169,37,169,5,0,1,162]

theorem envBound57399 : H12AffineFastState.Bounded env57399 := by
  intro p hp
  have h : env57399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57398_57399 : H12AffineEnvironment.transform 7 4 env57398 = env57399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57398 == env57399) = true)

theorem identity57399 : scanCanonicalize (H12AffineFastState.compose env57399 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57399 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57400 : List Nat := [2,4,8,16,0,16,128,4,130,141,136,137,9,136,136,2,0,26,141,136,136,0,16,2,128,17,146,136,0,137,5,137,5,0,1,130]

theorem envBound57400 : H12AffineFastState.Bounded env57400 := by
  intro p hp
  have h : env57400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57399_57400 : H12AffineEnvironment.transform 4 0 env57399 = env57400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57399 == env57400) = true)

theorem identity57400 : scanCanonicalize (H12AffineFastState.compose env57400 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57401 : List Nat := [2,4,8,16,0,16,18,4,16,31,26,27,9,26,26,2,0,26,31,26,26,0,16,2,18,17,0,26,0,27,5,27,5,0,1,16]

theorem envBound57401 : H12AffineFastState.Bounded env57401 := by
  intro p hp
  have h : env57401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57400_57401 : H12AffineEnvironment.transform 6 18 env57400 = env57401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57400 == env57401) = true)

theorem identity57401 : scanCanonicalize (H12AffineFastState.compose env57401 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57402 : List Nat := [2,4,3,16,0,16,18,4,16,20,17,16,2,17,17,2,0,17,20,17,17,0,16,2,18,17,0,17,0,16,5,16,5,0,1,16]

theorem envBound57402 : H12AffineFastState.Bounded env57402 := by
  intro p hp
  have h : env57402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57401_57402 : H12AffineEnvironment.transform 2 3 env57401 = env57402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57401 == env57402) = true)

def env57403 : List Nat := [2,4,8,16,32,48,128,5,162,140,137,136,41,169,136,3,0,26,140,136,136,32,49,34,160,16,147,169,32,169,37,169,4,0,1,162]

theorem envBound57403 : H12AffineFastState.Bounded env57403 := by
  intro p hp
  have h : env57403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57398_57403 : H12AffineEnvironment.transform 7 5 env57398 = env57403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57398 == env57403) = true)

theorem identity57403 : scanCanonicalize (H12AffineFastState.compose env57403 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57403 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57404 : List Nat := [2,4,8,0,32,32,128,5,162,140,137,136,41,169,136,3,0,10,140,136,136,32,33,34,160,0,131,169,32,169,37,169,4,0,1,162]

theorem envBound57404 : H12AffineFastState.Bounded env57404 := by
  intro p hp
  have h : env57404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57403_57404 : H12AffineEnvironment.transform 3 0 env57403 = env57404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57403 == env57404) = true)

def env57405 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,4096,40,4128,137,263,4492,4502,393,137,4356,32,308,35,161,276,4123,4128,4525,523,36,169,257,1,4493,512]

theorem envBound57405 : H12AffineFastState.Bounded env57405 := by
  intro p hp
  have h : env57405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57395_57405 : H12AffineEnvironment.transform 5 49 env57395 = env57405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57395 == env57405) = true)

theorem identity57405 : scanCanonicalize (H12AffineFastState.compose env57405 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 902) := by decide +kernel

theorem selectedBound57405 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57406 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,902,40,934,137,263,522,528,393,137,642,32,308,35,161,276,925,934,555,523,36,169,257,1,523,512]

theorem envBound57406 : H12AffineFastState.Bounded env57406 := by
  intro p hp
  have h : env57406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57405_57406 : H12AffineEnvironment.transform 11 902 env57405 = env57406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 902 env57405 == env57406) = true)

theorem identity57406 : scanCanonicalize (H12AffineFastState.compose env57406 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 445) := by decide +kernel

theorem selectedBound57406 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57407 : List Nat := [2,4,8,16,32,49,128,256,445,393,147,59,40,27,137,263,439,429,393,137,319,32,308,35,161,276,32,27,406,438,36,169,257,1,438,445]

theorem envBound57407 : H12AffineFastState.Bounded env57407 := by
  intro p hp
  have h : env57407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57406_57407 : H12AffineEnvironment.transform 8 445 env57406 = env57407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 445 env57406 == env57407) = true)

theorem identity57407 : scanCanonicalize (H12AffineFastState.compose env57407 (packedSelected [1,13] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57407 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env57408 : List Nat := [2,4,8,16,32,49,128,30,163,151,147,59,40,27,137,25,169,179,151,137,33,32,42,35,161,10,32,27,136,168,36,169,31,1,168,163]

theorem envBound57408 : H12AffineFastState.Bounded env57408 := by
  intro p hp
  have h : env57408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57407_57408 : H12AffineEnvironment.transform 7 30 env57407 = env57408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57407 == env57408) = true)

theorem identity57408 : scanCanonicalize (H12AffineFastState.compose env57408 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57408 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57409 : List Nat := [2,4,8,16,32,49,41,30,10,62,58,59,40,27,32,25,0,26,62,32,33,32,42,35,8,10,32,27,33,1,36,0,31,1,1,10]

theorem envBound57409 : H12AffineFastState.Bounded env57409 := by
  intro p hp
  have h : env57409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57408_57409 : H12AffineEnvironment.transform 6 41 env57408 = env57409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57408 == env57409) = true)

def env57410 : List Nat := [2,4,8,0,32,33,41,14,10,46,42,43,40,11,32,9,0,10,46,32,33,32,42,35,8,10,32,11,33,1,36,0,15,1,1,10]

theorem envBound57410 : H12AffineFastState.Bounded env57410 := by
  intro p hp
  have h : env57410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57409_57410 : H12AffineEnvironment.transform 3 0 env57409 = env57410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57409 == env57410) = true)

theorem identity57410 : scanCanonicalize (H12AffineFastState.compose env57410 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57411 : List Nat := [2,4,8,0,11,10,2,14,10,5,1,0,3,11,11,9,0,10,5,11,10,11,1,8,8,10,11,11,10,1,15,0,15,1,1,10]

theorem envBound57411 : H12AffineFastState.Bounded env57411 := by
  intro p hp
  have h : env57411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57410_57411 : H12AffineEnvironment.transform 4 11 env57410 = env57411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57410 == env57411) = true)

def env57412 : List Nat := [2,4,8,1,32,32,41,15,10,47,43,42,40,10,32,8,0,11,47,32,33,32,42,35,8,10,32,10,33,1,36,0,14,1,1,10]

theorem envBound57412 : H12AffineFastState.Bounded env57412 := by
  intro p hp
  have h : env57412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57409_57412 : H12AffineEnvironment.transform 3 1 env57409 = env57412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57409 == env57412) = true)

def env57413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295815,4247641,6348992,4273308,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256464]

theorem envBound57413 : H12AffineFastState.Bounded env57413 := by
  intro p hp
  have h : env57413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57361_57413 : H12AffineEnvironment.transform 17 82113 env57361 = env57413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57361 == env57413) = true)

def env57414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142599,28889,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57414 : H12AffineFastState.Bounded env57414 := by
  intro p hp
  have h : env57414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57413_57414 : H12AffineEnvironment.transform 21 41088 env57413 = env57414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57413 == env57414) = true)

theorem identity57414 : scanCanonicalize (H12AffineFastState.compose env57414 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 118834) := by decide +kernel

theorem selectedBound57414 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,118834,41088,114802,90549,28889,102514,103452,16384,77954,96346,58805,74119,257,45128,78035,21072]

theorem envBound57415 : H12AffineFastState.Bounded env57415 := by
  intro p hp
  have h : env57415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57414_57415 : H12AffineEnvironment.transform 20 118834 env57414 = env57415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 118834 env57414 == env57415) = true)

theorem identity57415 : scanCanonicalize (H12AffineFastState.compose env57415 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57415 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,32768,65536,78034,79257,1024,32768,107882,41088,111914,70893,1409,102514,103452,13656,77954,68866,37101,74119,257,45128,78035,9992]

theorem envBound57416 : H12AffineFastState.Bounded env57416 := by
  intro p hp
  have h : env57416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57415_57416 : H12AffineEnvironment.transform 13 13656 env57415 = env57416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57415 == env57416) = true)

theorem identity57416 : scanCanonicalize (H12AffineFastState.compose env57416 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57416 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12513,65536,78034,79257,1024,12513,71051,4193,67019,70893,1409,73875,75005,13656,77954,68866,8204,74119,257,169,78035,9992]

theorem envBound57417 : H12AffineFastState.Bounded env57417 := by
  intro p hp
  have h : env57417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57416_57417 : H12AffineEnvironment.transform 14 12513 env57416 = env57417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57416 == env57417) = true)

theorem identity57417 : scanCanonicalize (H12AffineFastState.compose env57417 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57417 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,65536,71131,69776,1024,5608,71051,4193,67019,70893,1409,66970,66036,4177,71051,68866,1285,66702,257,169,71130,513]

theorem envBound57418 : H12AffineFastState.Bounded env57418 := by
  intro p hp
  have h : env57418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57417_57418 : H12AffineEnvironment.transform 12 1289 env57417 = env57418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57417 == env57418) = true)

theorem identity57418 : scanCanonicalize (H12AffineFastState.compose env57418 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound57418 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,514,6105,4754,1024,5608,6025,4193,1993,5871,1409,1944,1014,4177,6025,3840,1285,1676,257,169,6104,513]

theorem envBound57419 : H12AffineFastState.Bounded env57419 := by
  intro p hp
  have h : env57419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57418_57419 : H12AffineEnvironment.transform 15 514 env57418 = env57419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env57418 == env57419) = true)

theorem identity57419 : scanCanonicalize (H12AffineFastState.compose env57419 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57419 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,444,1029,514,1588,895,1024,1029,1636,396,1993,1794,1409,1944,1014,444,1636,3840,1285,1676,257,169,1589,513]

theorem envBound57420 : H12AffineFastState.Bounded env57420 := by
  intro p hp
  have h : env57420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57419_57420 : H12AffineEnvironment.transform 11 493 env57419 = env57420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57419 == env57420) = true)

theorem identity57420 : scanCanonicalize (H12AffineFastState.compose env57420 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57420 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,493,1289,444,1029,514,1588,895,1024,1029,1636,396,1993,1794,1409,1944,1014,444,1636,11,1285,1676,257,169,1589,513]

theorem envBound57421 : H12AffineFastState.Bounded env57421 := by
  intro p hp
  have h : env57421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57420_57421 : H12AffineEnvironment.transform 10 1803 env57420 = env57421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57420 == env57421) = true)

theorem identity57421 : scanCanonicalize (H12AffineFastState.compose env57421 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound57421 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57422 : List Nat := [2,4,8,16,32,64,128,256,512,905,130,493,640,444,908,514,445,895,905,908,493,396,64,139,520,17,1014,444,493,11,652,261,257,169,444,513]

theorem envBound57422 : H12AffineFastState.Bounded env57422 := by
  intro p hp
  have h : env57422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57421_57422 : H12AffineEnvironment.transform 9 905 env57421 = env57422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env57421 == env57422) = true)

theorem identity57422 : scanCanonicalize (H12AffineFastState.compose env57422 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound57422 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57423 : List Nat := [2,4,8,16,32,64,25,256,512,784,27,372,537,293,789,514,292,895,784,789,372,277,64,18,520,17,879,293,372,11,533,261,257,48,293,513]

theorem envBound57423 : H12AffineFastState.Bounded env57423 := by
  intro p hp
  have h : env57423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57422_57423 : H12AffineEnvironment.transform 6 25 env57422 = env57423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env57422 == env57423) = true)

theorem identity57423 : scanCanonicalize (H12AffineFastState.compose env57423 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 382) := by decide +kernel

theorem selectedBound57423 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57424 : List Nat := [2,4,8,16,32,64,25,256,382,110,27,372,359,293,107,380,292,1,110,107,372,277,64,18,374,17,17,293,372,11,363,261,257,48,293,383]

theorem envBound57424 : H12AffineFastState.Bounded env57424 := by
  intro p hp
  have h : env57424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57423_57424 : H12AffineEnvironment.transform 8 382 env57423 = env57424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 382 env57423 == env57424) = true)

theorem identity57424 : scanCanonicalize (H12AffineFastState.compose env57424 (packedSelected [4,5,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57424 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env57425 : List Nat := [2,4,3,16,32,64,18,256,373,101,16,372,359,293,96,375,292,1,101,96,372,277,64,18,374,17,17,293,372,0,352,261,257,48,293,372]

theorem envBound57425 : H12AffineFastState.Bounded env57425 := by
  intro p hp
  have h : env57425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57424_57425 : H12AffineEnvironment.transform 2 3 env57424 = env57425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57424 == env57425) = true)

theorem identity57425 : scanCanonicalize (H12AffineFastState.compose env57425 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57425 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57426 : List Nat := [2,4,3,0,32,64,2,256,357,101,0,356,359,293,96,359,292,1,101,96,356,261,64,2,358,1,1,293,356,0,352,261,257,32,293,356]

theorem envBound57426 : H12AffineFastState.Bounded env57426 := by
  intro p hp
  have h : env57426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57425_57426 : H12AffineEnvironment.transform 3 0 env57425 = env57426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57425 == env57426) = true)

theorem identity57426 : scanCanonicalize (H12AffineFastState.compose env57426 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 38) := by decide +kernel

theorem selectedBound57426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57427 : List Nat := [2,4,3,0,32,64,2,38,67,101,0,66,65,3,96,65,2,1,101,96,66,35,64,2,64,1,1,3,66,0,70,35,39,32,3,66]

theorem envBound57427 : H12AffineFastState.Bounded env57427 := by
  intro p hp
  have h : env57427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57426_57427 : H12AffineEnvironment.transform 7 38 env57426 = env57427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 38 env57426 == env57427) = true)

theorem identity57427 : scanCanonicalize (H12AffineFastState.compose env57427 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound57427 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57428 : List Nat := [2,4,3,0,3,64,2,5,67,70,0,66,65,3,67,65,2,1,70,67,66,0,64,2,64,1,1,3,66,0,70,0,4,3,3,66]

theorem envBound57428 : H12AffineFastState.Bounded env57428 := by
  intro p hp
  have h : env57428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57427_57428 : H12AffineEnvironment.transform 4 3 env57427 = env57428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env57427 == env57428) = true)

theorem identity57428 : scanCanonicalize (H12AffineFastState.compose env57428 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound57428 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env57429 : List Nat := [2,4,3,0,3,3,2,5,0,5,0,1,2,3,0,2,2,1,5,0,1,0,3,2,3,1,1,3,1,0,5,0,4,3,3,1]

theorem envBound57429 : H12AffineFastState.Bounded env57429 := by
  intro p hp
  have h : env57429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57428_57429 : H12AffineEnvironment.transform 5 3 env57428 = env57429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env57428 == env57429) = true)

theorem identity57429 : scanCanonicalize (H12AffineFastState.compose env57429 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57430 : List Nat := [0,4,1,0,1,1,0,5,0,5,0,1,0,1,0,0,0,1,5,0,1,0,1,0,1,1,1,1,1,0,5,0,4,1,1,1]

theorem envBound57430 : H12AffineFastState.Bounded env57430 := by
  intro p hp
  have h : env57430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57429_57430 : H12AffineEnvironment.transform 0 0 env57429 = env57430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57429 == env57430) = true)

def env57431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142598,28888,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57431 : H12AffineFastState.Bounded env57431 := by
  intro p hp
  have h : env57431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57413_57431 : H12AffineEnvironment.transform 21 41089 env57413 = env57431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57413 == env57431) = true)

theorem identity57431 : scanCanonicalize (H12AffineFastState.compose env57431 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 103795) := by decide +kernel

theorem selectedBound57431 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,103795,41089,99634,74997,28888,120114,103453,16384,77954,96347,41205,74118,257,62728,78035,21073]

theorem envBound57432 : H12AffineFastState.Bounded env57432 := by
  intro p hp
  have h : env57432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57431_57432 : H12AffineEnvironment.transform 20 103795 env57431 = env57432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 103795 env57431 == env57432) = true)

theorem identity57432 : scanCanonicalize (H12AffineFastState.compose env57432 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 20648) := by decide +kernel

theorem selectedBound57432 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20648,65536,78034,82113,1024,20648,83419,28713,87450,74997,28888,66970,83125,16384,77954,96347,28765,74118,257,9632,78035,21073]

theorem envBound57433 : H12AffineFastState.Bounded env57433 := by
  intro p hp
  have h : env57433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57432_57433 : H12AffineEnvironment.transform 14 20648 env57432 = env57433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20648 env57432 == env57433) = true)

theorem identity57433 : scanCanonicalize (H12AffineFastState.compose env57433 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57433 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,65536,78034,69776,1024,249,71050,8312,67019,74997,8329,66970,70884,4177,77954,75786,8204,74118,257,9632,78035,512]

theorem envBound57434 : H12AffineFastState.Bounded env57434 := by
  intro p hp
  have h : env57434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57433_57434 : H12AffineEnvironment.transform 13 4177 env57433 = env57434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57433 == env57434) = true)

theorem identity57434 : scanCanonicalize (H12AffineFastState.compose env57434 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound57434 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,375,12709,4583,1024,249,5373,8312,1212,9602,8329,1261,5523,4177,12789,10621,8204,8433,257,9632,12708,512]

theorem envBound57435 : H12AffineFastState.Bounded env57435 := by
  intro p hp
  have h : env57435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57434_57435 : H12AffineEnvironment.transform 15 375 env57434 = env57435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env57434 == env57435) = true)

theorem identity57435 : scanCanonicalize (H12AffineFastState.compose env57435 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound57435 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,249,375,8026,4583,1024,249,5373,3719,1212,2941,3702,1261,5523,4177,7946,1922,3827,3598,257,2911,8027,512]

theorem envBound57436 : H12AffineFastState.Bounded env57436 := by
  intro p hp
  have h : env57436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57435_57436 : H12AffineEnvironment.transform 12 3839 env57435 = env57436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env57435 == env57436) = true)

theorem identity57436 : scanCanonicalize (H12AffineFastState.compose env57436 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57436 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,88,4177,249,375,4605,4583,1024,249,5373,32,1212,1498,209,1261,5523,4177,4525,1922,84,169,257,1528,4604,512]

theorem envBound57437 : H12AffineFastState.Bounded env57437 := by
  intro p hp
  have h : env57437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57436_57437 : H12AffineEnvironment.transform 10 1703 env57436 = env57437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57436 == env57437) = true)

def env57438 : List Nat := [2,4,8,16,32,64,128,256,512,392,815,4096,88,4177,249,375,4605,4583,392,249,4469,32,308,82,209,357,4123,4177,4525,522,84,169,257,112,4604,512]

theorem envBound57438 : H12AffineFastState.Bounded env57438 := by
  intro p hp
  have h : env57438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57437_57438 : H12AffineEnvironment.transform 9 392 env57437 = env57438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env57437 == env57438) = true)

def env57439 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,4096,40,4129,137,263,4493,4503,392,137,4357,32,308,34,161,277,4123,4129,4525,522,36,169,257,0,4492,512]

theorem envBound57439 : H12AffineFastState.Bounded env57439 := by
  intro p hp
  have h : env57439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57438_57439 : H12AffineEnvironment.transform 5 48 env57438 = env57439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57438 == env57439) = true)

theorem identity57439 : scanCanonicalize (H12AffineFastState.compose env57439 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 902) := by decide +kernel

theorem selectedBound57439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57440 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,902,40,935,137,263,523,529,392,137,643,32,308,34,161,277,925,935,555,522,36,169,257,0,522,512]

theorem envBound57440 : H12AffineFastState.Bounded env57440 := by
  intro p hp
  have h : env57440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57439_57440 : H12AffineEnvironment.transform 11 902 env57439 = env57440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 902 env57439 == env57440) = true)

theorem identity57440 : scanCanonicalize (H12AffineFastState.compose env57440 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 444) := by decide +kernel

theorem selectedBound57440 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57441 : List Nat := [2,4,8,16,32,48,128,256,444,392,147,58,40,27,137,263,439,429,392,137,319,32,308,34,161,277,33,27,407,438,36,169,257,0,438,444]

theorem envBound57441 : H12AffineFastState.Bounded env57441 := by
  intro p hp
  have h : env57441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57440_57441 : H12AffineEnvironment.transform 8 444 env57440 = env57441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 444 env57440 == env57441) = true)

theorem identity57441 : scanCanonicalize (H12AffineFastState.compose env57441 (packedSelected [1,13] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57441 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env57442 : List Nat := [2,4,8,16,32,48,128,31,163,151,147,58,40,27,137,24,168,178,151,137,32,32,43,34,161,10,33,27,136,169,36,169,30,0,169,163]

theorem envBound57442 : H12AffineFastState.Bounded env57442 := by
  intro p hp
  have h : env57442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57441_57442 : H12AffineEnvironment.transform 7 31 env57441 = env57442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57441 == env57442) = true)

theorem identity57442 : scanCanonicalize (H12AffineFastState.compose env57442 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57442 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57443 : List Nat := [2,4,8,16,32,48,40,31,11,63,59,58,40,27,33,24,0,26,63,33,32,32,43,34,9,10,33,27,32,1,36,1,30,0,1,11]

theorem envBound57443 : H12AffineFastState.Bounded env57443 := by
  intro p hp
  have h : env57443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57442_57443 : H12AffineEnvironment.transform 6 40 env57442 = env57443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57442 == env57443) = true)

def env57444 : List Nat := [2,4,8,0,32,32,40,15,11,47,43,42,40,11,33,8,0,10,47,33,32,32,43,34,9,10,33,11,32,1,36,1,14,0,1,11]

theorem envBound57444 : H12AffineFastState.Bounded env57444 := by
  intro p hp
  have h : env57444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57443_57444 : H12AffineEnvironment.transform 3 0 env57443 = env57444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57443 == env57444) = true)

def env57445 : List Nat := [2,4,8,1,32,33,40,14,11,46,42,43,40,10,33,9,0,11,46,33,32,32,43,34,9,10,33,10,32,1,36,1,15,0,1,11]

theorem envBound57445 : H12AffineFastState.Bounded env57445 := by
  intro p hp
  have h : env57445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57443_57445 : H12AffineEnvironment.transform 3 1 env57443 = env57445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57443 == env57445) = true)

theorem identity57445 : scanCanonicalize (H12AffineFastState.compose env57445 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57446 : List Nat := [2,4,8,1,11,10,3,14,11,5,1,0,3,10,10,9,0,11,5,10,11,11,0,9,9,10,10,10,11,1,15,1,15,0,1,11]

theorem envBound57446 : H12AffineFastState.Bounded env57446 := by
  intro p hp
  have h : env57446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57445_57446 : H12AffineEnvironment.transform 4 11 env57445 = env57446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57445 == env57446) = true)

def env57447 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,4096,41,4128,136,262,4492,4502,392,136,4356,32,308,35,160,276,4123,4128,4525,522,37,169,257,1,4493,512]

theorem envBound57447 : H12AffineFastState.Bounded env57447 := by
  intro p hp
  have h : env57447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57438_57447 : H12AffineEnvironment.transform 5 49 env57438 = env57447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57438 == env57447) = true)

theorem identity57447 : scanCanonicalize (H12AffineFastState.compose env57447 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 814) := by decide +kernel

theorem selectedBound57447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57448 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,814,41,782,136,262,674,696,392,136,554,32,308,35,160,276,821,782,643,522,37,169,257,1,675,512]

theorem envBound57448 : H12AffineFastState.Bounded env57448 := by
  intro p hp
  have h : env57448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57447_57448 : H12AffineEnvironment.transform 11 814 env57447 = env57448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 814 env57447 == env57448) = true)

theorem identity57448 : scanCanonicalize (H12AffineFastState.compose env57448 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound57448 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57449 : List Nat := [2,4,8,16,32,49,128,256,162,392,397,396,41,428,136,262,0,26,392,136,136,32,308,35,160,276,407,428,33,168,37,169,257,1,1,162]

theorem envBound57449 : H12AffineFastState.Bounded env57449 := by
  intro p hp
  have h : env57449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57448_57449 : H12AffineEnvironment.transform 8 162 env57448 = env57449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env57448 == env57449) = true)

def env57450 : List Nat := [2,4,8,16,32,49,128,4,162,140,137,136,41,168,136,2,0,26,140,136,136,32,48,35,160,16,147,168,33,168,37,169,5,1,1,162]

theorem envBound57450 : H12AffineFastState.Bounded env57450 := by
  intro p hp
  have h : env57450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57449_57450 : H12AffineEnvironment.transform 7 4 env57449 = env57450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57449 == env57450) = true)

theorem identity57450 : scanCanonicalize (H12AffineFastState.compose env57450 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57450 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57451 : List Nat := [2,4,8,1,32,32,128,4,162,140,137,136,41,168,136,2,0,11,140,136,136,32,33,35,160,1,130,168,33,168,37,169,5,1,1,162]

theorem envBound57451 : H12AffineFastState.Bounded env57451 := by
  intro p hp
  have h : env57451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57450_57451 : H12AffineEnvironment.transform 3 1 env57450 = env57451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57450 == env57451) = true)

def env57452 : List Nat := [2,4,8,16,32,49,128,5,162,141,136,137,41,169,136,3,0,26,141,136,136,32,49,35,160,17,146,169,33,168,37,169,4,1,1,162]

theorem envBound57452 : H12AffineFastState.Bounded env57452 := by
  intro p hp
  have h : env57452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57449_57452 : H12AffineEnvironment.transform 7 5 env57449 = env57452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57449 == env57452) = true)

theorem identity57452 : scanCanonicalize (H12AffineFastState.compose env57452 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57452 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57453 : List Nat := [2,4,8,16,1,16,128,5,131,141,136,137,8,136,136,3,0,26,141,136,136,1,16,2,129,17,146,136,0,137,4,136,4,1,1,131]

theorem envBound57453 : H12AffineFastState.Bounded env57453 := by
  intro p hp
  have h : env57453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57452_57453 : H12AffineEnvironment.transform 4 1 env57452 = env57453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57452 == env57453) = true)

theorem identity57453 : scanCanonicalize (H12AffineFastState.compose env57453 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57454 : List Nat := [2,4,8,16,1,16,18,5,17,31,26,27,8,26,26,3,0,26,31,26,26,1,16,2,19,17,0,26,0,27,4,26,4,1,1,17]

theorem envBound57454 : H12AffineFastState.Bounded env57454 := by
  intro p hp
  have h : env57454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57453_57454 : H12AffineEnvironment.transform 6 18 env57453 = env57454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57453 == env57454) = true)

theorem identity57454 : scanCanonicalize (H12AffineFastState.compose env57454 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57454 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57455 : List Nat := [2,4,2,16,1,16,18,5,17,21,16,17,2,16,16,3,0,16,21,16,16,1,16,2,19,17,0,16,0,17,4,16,4,1,1,17]

theorem envBound57455 : H12AffineFastState.Bounded env57455 := by
  intro p hp
  have h : env57455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57454_57455 : H12AffineEnvironment.transform 2 2 env57454 = env57455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57454 == env57455) = true)

def env57456 : List Nat := [2,4,8,16,32,64,128,256,512,393,814,4096,88,4177,249,375,4605,4583,393,249,4468,32,309,83,209,356,4122,4177,4525,523,84,169,257,113,4604,512]

theorem envBound57456 : H12AffineFastState.Bounded env57456 := by
  intro p hp
  have h : env57456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57437_57456 : H12AffineEnvironment.transform 9 393 env57437 = env57456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env57437 == env57456) = true)

def env57457 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,4096,40,4129,137,263,4493,4503,393,137,4356,32,309,35,161,276,4122,4129,4525,523,36,169,257,1,4492,512]

theorem envBound57457 : H12AffineFastState.Bounded env57457 := by
  intro p hp
  have h : env57457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57456_57457 : H12AffineEnvironment.transform 5 48 env57456 = env57457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57456 == env57457) = true)

theorem identity57457 : scanCanonicalize (H12AffineFastState.compose env57457 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57458 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,643,40,674,137,263,782,788,393,137,903,32,309,35,161,276,665,674,814,523,36,169,257,1,783,512]

theorem envBound57458 : H12AffineFastState.Bounded env57458 := by
  intro p hp
  have h : env57458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57457_57458 : H12AffineEnvironment.transform 11 643 env57457 = env57458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57457 == env57458) = true)

theorem identity57458 : scanCanonicalize (H12AffineFastState.compose env57458 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound57458 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57459 : List Nat := [2,4,8,16,32,48,128,189,512,52,659,643,40,674,137,186,691,681,52,137,570,32,136,35,161,169,665,674,659,523,36,169,188,1,690,512]

theorem envBound57459 : H12AffineFastState.Bounded env57459 := by
  intro p hp
  have h : env57459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57458_57459 : H12AffineEnvironment.transform 7 189 env57458 = env57459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env57458 == env57459) = true)

theorem identity57459 : scanCanonicalize (H12AffineFastState.compose env57459 (packedSelected [0,3,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57459 : packedSelected [0,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57460 : List Nat := [2,4,8,11,32,43,128,166,512,47,648,643,40,674,137,161,680,681,47,137,545,32,136,35,161,169,642,674,648,523,36,169,167,1,681,512]

theorem envBound57460 : H12AffineFastState.Bounded env57460 := by
  intro p hp
  have h : env57460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57459_57460 : H12AffineEnvironment.transform 3 11 env57459 = env57460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57459 == env57460) = true)

theorem identity57460 : scanCanonicalize (H12AffineFastState.compose env57460 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound57460 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57461 : List Nat := [2,4,8,11,32,43,128,166,43,47,163,168,40,137,137,161,131,130,47,137,10,32,136,35,161,169,169,137,163,32,36,169,167,1,130,43]

theorem envBound57461 : H12AffineFastState.Bounded env57461 := by
  intro p hp
  have h : env57461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57460_57461 : H12AffineEnvironment.transform 8 43 env57460 = env57461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env57460 == env57461) = true)

theorem identity57461 : scanCanonicalize (H12AffineFastState.compose env57461 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound57461 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57462 : List Nat := [2,4,8,11,32,43,35,5,43,47,0,11,40,42,42,2,32,33,47,42,10,32,43,35,2,10,10,42,0,32,36,10,4,1,33,43]

theorem envBound57462 : H12AffineFastState.Bounded env57462 := by
  intro p hp
  have h : env57462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57461_57462 : H12AffineEnvironment.transform 6 35 env57461 = env57462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env57461 == env57462) = true)

theorem identity57462 : scanCanonicalize (H12AffineFastState.compose env57462 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57462 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57463 : List Nat := [2,4,8,11,1,10,2,5,10,14,0,11,9,11,11,2,1,0,14,11,10,1,10,2,2,10,10,11,0,1,5,10,4,1,0,10]

theorem envBound57463 : H12AffineFastState.Bounded env57463 := by
  intro p hp
  have h : env57463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57462_57463 : H12AffineEnvironment.transform 4 1 env57462 = env57463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57462 == env57463) = true)

theorem identity57463 : scanCanonicalize (H12AffineFastState.compose env57463 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57464 : List Nat := [2,4,2,1,1,0,2,5,0,4,0,1,3,1,1,2,1,0,4,1,0,1,0,2,2,0,0,1,0,1,5,0,4,1,0,0]

theorem envBound57464 : H12AffineFastState.Bounded env57464 := by
  intro p hp
  have h : env57464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57463_57464 : H12AffineEnvironment.transform 2 2 env57463 = env57464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57463 == env57464) = true)

def env57465 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,4096,41,4128,136,262,4492,4502,393,136,4357,32,309,34,160,277,4122,4128,4525,523,37,169,257,0,4493,512]

theorem envBound57465 : H12AffineFastState.Bounded env57465 := by
  intro p hp
  have h : env57465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57456_57465 : H12AffineEnvironment.transform 5 49 env57456 = env57465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57456 == env57465) = true)

theorem identity57465 : scanCanonicalize (H12AffineFastState.compose env57465 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57466 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,555,41,523,136,262,935,957,393,136,814,32,309,34,160,277,561,523,902,523,37,169,257,0,934,512]

theorem envBound57466 : H12AffineFastState.Bounded env57466 := by
  intro p hp
  have h : env57466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57465_57466 : H12AffineEnvironment.transform 11 555 env57465 = env57466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57465 == env57466) = true)

theorem identity57466 : scanCanonicalize (H12AffineFastState.compose env57466 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound57466 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57467 : List Nat := [2,4,8,16,32,49,128,167,512,46,649,555,41,523,136,161,512,538,46,136,649,32,146,34,160,178,561,523,545,523,37,169,166,0,513,512]

theorem envBound57467 : H12AffineFastState.Bounded env57467 := by
  intro p hp
  have h : env57467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57466_57467 : H12AffineEnvironment.transform 7 167 env57466 = env57467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env57466 == env57467) = true)

theorem identity57467 : scanCanonicalize (H12AffineFastState.compose env57467 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57467 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57468 : List Nat := [2,4,8,16,32,49,40,15,512,46,545,555,41,523,32,9,512,538,46,32,545,32,58,34,8,26,561,523,545,523,37,1,14,0,513,512]

theorem envBound57468 : H12AffineFastState.Bounded env57468 := by
  intro p hp
  have h : env57468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57467_57468 : H12AffineEnvironment.transform 6 40 env57467 = env57468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57467 == env57468) = true)

theorem identity57468 : scanCanonicalize (H12AffineFastState.compose env57468 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57468 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57469 : List Nat := [2,4,8,10,32,43,40,15,512,46,545,555,41,523,32,9,512,512,46,32,545,32,32,34,8,0,555,523,545,523,37,1,14,0,513,512]

theorem envBound57469 : H12AffineFastState.Bounded env57469 := by
  intro p hp
  have h : env57469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57468_57469 : H12AffineEnvironment.transform 3 10 env57468 = env57469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57468 == env57469) = true)

theorem identity57469 : scanCanonicalize (H12AffineFastState.compose env57469 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57470 : List Nat := [2,4,8,10,10,1,2,15,512,4,523,513,3,523,10,9,512,512,4,10,523,10,10,8,8,0,513,523,523,523,15,1,14,0,513,512]

theorem envBound57470 : H12AffineFastState.Bounded env57470 := by
  intro p hp
  have h : env57470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57469_57470 : H12AffineEnvironment.transform 4 10 env57469 = env57470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57469 == env57470) = true)

def env57471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4486236,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57471 : H12AffineFastState.Bounded env57471 := by
  intro p hp
  have h : env57471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57360_57471 : H12AffineEnvironment.transform 22 6336705 env57360 = env57471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env57360 == env57471) = true)

def env57472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4273308,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57472 : H12AffineFastState.Bounded env57472 := by
  intro p hp
  have h : env57472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57471_57472 : H12AffineEnvironment.transform 17 82112 env57471 = env57472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57471 == env57472) = true)

def env57473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142598,28889,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57473 : H12AffineFastState.Bounded env57473 := by
  intro p hp
  have h : env57473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57473 : H12AffineEnvironment.transform 21 41088 env57472 = env57473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57472 == env57473) = true)

theorem identity57473 : scanCanonicalize (H12AffineFastState.compose env57473 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 128315) := by decide +kernel

theorem selectedBound57473 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,128315,41088,124282,83133,28889,111994,103452,16384,77954,96346,49341,74118,257,38209,78035,21072]

theorem envBound57474 : H12AffineFastState.Bounded env57474 := by
  intro p hp
  have h : env57474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57473_57474 : H12AffineEnvironment.transform 20 128315 env57473 = env57474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 128315 env57473 == env57474) = true)

theorem identity57474 : scanCanonicalize (H12AffineFastState.compose env57474 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound57474 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,32768,65536,78034,79257,1024,32768,98402,41088,102435,78308,1408,111994,103452,13657,77954,68867,46564,74118,257,38209,78035,9993]

theorem envBound57475 : H12AffineFastState.Bounded env57475 := by
  intro p hp
  have h : env57475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57474_57475 : H12AffineEnvironment.transform 13 13657 env57474 = env57475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env57474 == env57475) = true)

theorem identity57475 : scanCanonicalize (H12AffineFastState.compose env57475 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5609) := by decide +kernel

theorem selectedBound57475 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5609,65536,78034,79257,1024,5609,71051,13673,67018,78308,1408,73875,66037,13657,77954,68867,8205,74118,257,168,78035,9993]

theorem envBound57476 : H12AffineFastState.Bounded env57476 := by
  intro p hp
  have h : env57476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57475_57476 : H12AffineEnvironment.transform 14 5609 env57475 = env57476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5609 env57475 == env57476) = true)

theorem identity57476 : scanCanonicalize (H12AffineFastState.compose env57476 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1418) := by decide +kernel

theorem selectedBound57476 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5609,1418,13656,12307,1024,5609,4097,13673,64,13422,1408,9497,1151,13657,13576,2185,8205,9228,257,168,13657,9993]

theorem envBound57477 : H12AffineFastState.Bounded env57477 := by
  intro p hp
  have h : env57477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57476_57477 : H12AffineEnvironment.transform 15 1418 env57476 = env57477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1418 env57476 == env57477) = true)

theorem identity57477 : scanCanonicalize (H12AffineFastState.compose env57477 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57477 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,1418,4176,5403,1024,5609,4097,4193,64,4454,1408,17,1151,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57478 : H12AffineFastState.Bounded env57478 := by
  intro p hp
  have h : env57478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57477_57478 : H12AffineEnvironment.transform 12 1288 env57477 = env57478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57477 == env57478) = true)

theorem identity57478 : scanCanonicalize (H12AffineFastState.compose env57478 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3815) := by decide +kernel

theorem selectedBound57478 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3815,1288,3766,2830,1418,3767,3068,1024,2830,3814,3718,64,3969,1408,17,1151,3766,3815,2185,1285,260,257,168,3766,513]

theorem envBound57479 : H12AffineFastState.Bounded env57479 := by
  intro p hp
  have h : env57479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57478_57479 : H12AffineEnvironment.transform 11 3815 env57478 = env57479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3815 env57478 == env57479) = true)

theorem identity57479 : scanCanonicalize (H12AffineFastState.compose env57479 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57479 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57480 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,2415,640,2366,2830,514,2367,3068,904,2830,2414,2318,64,2057,520,17,1015,2366,2415,2185,653,260,257,168,2366,513]

theorem envBound57480 : H12AffineFastState.Bounded env57480 := by
  intro p hp
  have h : env57480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57479_57480 : H12AffineEnvironment.transform 9 904 env57479 = env57480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57479 == env57480) = true)

theorem identity57480 : scanCanonicalize (H12AffineFastState.compose env57480 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57480 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57481 : List Nat := [2,4,8,16,32,64,128,256,373,253,2048,2415,501,2366,2171,375,2367,2185,253,2171,2414,2318,64,2057,381,17,130,2366,2415,2185,504,260,257,168,2366,372]

theorem envBound57481 : H12AffineFastState.Bounded env57481 := by
  intro p hp
  have h : env57481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57480_57481 : H12AffineEnvironment.transform 8 373 env57480 = env57481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57480 == env57481) = true)

theorem identity57481 : scanCanonicalize (H12AffineFastState.compose env57481 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound57481 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57482 : List Nat := [2,4,8,16,32,64,128,256,373,253,130,493,501,444,249,375,445,11,253,249,492,396,64,139,381,17,130,444,493,11,504,260,257,168,444,372]

theorem envBound57482 : H12AffineFastState.Bounded env57482 := by
  intro p hp
  have h : env57482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57481_57482 : H12AffineEnvironment.transform 10 130 env57481 = env57482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env57481 == env57482) = true)

theorem identity57482 : scanCanonicalize (H12AffineFastState.compose env57482 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 199) := by decide +kernel

theorem selectedBound57482 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57483 : List Nat := [2,4,8,16,32,64,128,199,178,253,130,42,50,123,249,176,122,11,253,249,43,75,64,139,186,17,130,123,42,11,63,195,198,168,123,179]

theorem envBound57483 : H12AffineFastState.Bounded env57483 := by
  intro p hp
  have h : env57483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57482_57483 : H12AffineEnvironment.transform 7 199 env57482 = env57483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 199 env57482 == env57483) = true)

def env57484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142599,28888,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57484 : H12AffineFastState.Bounded env57484 := by
  intro p hp
  have h : env57484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57484 : H12AffineEnvironment.transform 21 41089 env57472 = env57484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57472 == env57484) = true)

theorem identity57484 : scanCanonicalize (H12AffineFastState.compose env57484 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 110714) := by decide +kernel

theorem selectedBound57484 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,110714,41089,106554,66045,28888,127034,103453,16384,77954,96347,34301,74119,257,53249,78035,21073]

theorem envBound57485 : H12AffineFastState.Bounded env57485 := by
  intro p hp
  have h : env57485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57484_57485 : H12AffineEnvironment.transform 20 110714 env57484 = env57485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110714 env57484 == env57485) = true)

theorem identity57485 : scanCanonicalize (H12AffineFastState.compose env57485 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound57485 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,78034,82112,1024,30113,83419,21792,87451,66045,28888,66971,90556,16384,77954,96347,28764,74119,257,9632,78035,21073]

theorem envBound57486 : H12AffineFastState.Bounded env57486 := by
  intro p hp
  have h : env57486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57485_57486 : H12AffineEnvironment.transform 14 30113 env57485 = env57486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env57485 == env57486) = true)

theorem identity57486 : scanCanonicalize (H12AffineFastState.compose env57486 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57486 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,65536,78034,69777,1024,9712,71050,1393,67018,66045,8329,66971,78317,4177,77954,75786,8205,74119,257,9632,78035,512]

theorem envBound57487 : H12AffineFastState.Bounded env57487 := by
  intro p hp
  have h : env57487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57486_57487 : H12AffineEnvironment.transform 13 4177 env57486 = env57487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57486 == env57487) = true)

theorem identity57487 : scanCanonicalize (H12AffineFastState.compose env57487 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound57487 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,9342,5292,13551,1024,9712,12788,1393,8628,9603,8329,8677,5523,4177,5372,3188,8205,1529,257,9632,5293,512]

theorem envBound57488 : H12AffineFastState.Bounded env57488 := by
  intro p hp
  have h : env57488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57487_57488 : H12AffineEnvironment.transform 15 9342 env57487 = env57488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env57487 == env57488) = true)

theorem identity57488 : scanCanonicalize (H12AffineFastState.compose env57488 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57488 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,2830,2688,5292,6673,1024,2830,7946,1393,3914,2941,3703,3867,5523,4177,5372,3188,3827,1529,257,2910,5293,512]

theorem envBound57489 : H12AffineFastState.Bounded env57489 := by
  intro p hp
  have h : env57489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57488_57489 : H12AffineEnvironment.transform 12 3838 env57488 = env57489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57488 == env57489) = true)

theorem identity57489 : scanCanonicalize (H12AffineFastState.compose env57489 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound57489 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57490 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,4096,2991,4177,2830,2688,4605,6673,337,2830,6747,32,2587,2941,2854,2634,4290,4177,4525,2341,2978,168,257,2910,4604,512]

theorem envBound57490 : H12AffineFastState.Bounded env57490 := by
  intro p hp
  have h : env57490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57489_57490 : H12AffineEnvironment.transform 9 337 env57489 = env57490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57489 == env57490) = true)

def env57491 : List Nat := [2,4,8,16,32,64,128,4,512,85,2048,4096,2731,4177,2570,2688,4345,6673,85,2570,6747,32,2587,2681,2594,2634,4290,4177,4265,2081,2726,168,5,2650,4344,512]

theorem envBound57491 : H12AffineFastState.Bounded env57491 := by
  intro p hp
  have h : env57491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57490_57491 : H12AffineEnvironment.transform 7 4 env57490 = env57491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57490 == env57491) = true)

def env57492 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,4096,2731,4129,2570,2688,4233,6673,37,2570,6699,32,2587,2569,2594,2618,4274,4129,4265,2081,2726,168,5,2602,4232,512]

theorem envBound57492 : H12AffineFastState.Bounded env57492 := by
  intro p hp
  have h : env57492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57491_57492 : H12AffineEnvironment.transform 5 48 env57491 = env57492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57491 == env57492) = true)

theorem identity57492 : scanCanonicalize (H12AffineFastState.compose env57492 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57492 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57493 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,555,2731,522,2570,2688,674,2106,37,2570,2048,32,2587,2569,2594,2618,665,522,642,2081,2726,168,5,2602,675,512]

theorem envBound57493 : H12AffineFastState.Bounded env57493 := by
  intro p hp
  have h : env57493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57492_57493 : H12AffineEnvironment.transform 11 555 env57492 = env57493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57492 == env57493) = true)

def env57494 : List Nat := [2,4,8,16,16,0,128,4,512,21,2048,539,2715,522,2570,2688,658,2058,21,2570,2048,16,2587,2569,2578,2570,665,522,642,2065,2710,152,5,2586,659,512]

theorem envBound57494 : H12AffineFastState.Bounded env57494 := by
  intro p hp
  have h : env57494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57493_57494 : H12AffineEnvironment.transform 4 16 env57493 = env57494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57493 == env57494) = true)

theorem identity57494 : scanCanonicalize (H12AffineFastState.compose env57494 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57494 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57495 : List Nat := [2,4,8,16,16,0,2,4,512,21,2048,539,2585,522,2570,2562,528,2058,21,2570,2048,16,2587,2569,2578,2570,539,522,512,2065,2580,26,5,2586,529,512]

theorem envBound57495 : H12AffineFastState.Bounded env57495 := by
  intro p hp
  have h : env57495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57494_57495 : H12AffineEnvironment.transform 6 2 env57494 = env57495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57494 == env57495) = true)

theorem identity57495 : scanCanonicalize (H12AffineFastState.compose env57495 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound57495 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57496 : List Nat := [2,4,8,16,16,0,2,4,512,21,16,539,521,522,538,530,528,26,21,538,16,16,523,537,514,538,539,522,512,1,516,26,5,522,529,512]

theorem envBound57496 : H12AffineFastState.Bounded env57496 := by
  intro p hp
  have h : env57496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57495_57496 : H12AffineEnvironment.transform 10 16 env57495 = env57496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env57495 == env57496) = true)

theorem identity57496 : scanCanonicalize (H12AffineFastState.compose env57496 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57496 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env57497 : List Nat := [2,4,8,10,10,0,2,4,512,15,10,513,521,522,512,520,522,0,15,512,10,10,523,515,514,512,513,522,512,1,516,0,5,522,523,512]

theorem envBound57497 : H12AffineFastState.Bounded env57497 := by
  intro p hp
  have h : env57497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57496_57497 : H12AffineEnvironment.transform 3 10 env57496 = env57497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57496 == env57497) = true)

theorem identity57497 : scanCanonicalize (H12AffineFastState.compose env57497 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57498 : List Nat := [2,4,8,10,10,0,2,4,11,15,10,10,2,1,11,3,1,0,15,11,10,10,0,8,9,11,10,1,11,1,15,0,5,1,0,11]

theorem envBound57498 : H12AffineFastState.Bounded env57498 := by
  intro p hp
  have h : env57498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57497_57498 : H12AffineEnvironment.transform 8 11 env57497 = env57498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57497 == env57498) = true)

def env57499 : List Nat := [2,4,8,16,17,1,128,4,512,20,2048,538,2714,522,2570,2688,659,2059,20,2570,2048,17,2587,2569,2579,2571,665,522,642,2064,2711,153,5,2587,658,512]

theorem envBound57499 : H12AffineFastState.Bounded env57499 := by
  intro p hp
  have h : env57499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57493_57499 : H12AffineEnvironment.transform 4 17 env57493 = env57499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57493 == env57499) = true)

theorem identity57499 : scanCanonicalize (H12AffineFastState.compose env57499 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound57499 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57500 : List Nat := [2,4,8,16,17,1,128,4,512,20,649,538,19,522,131,9,659,642,20,131,649,17,146,128,154,130,665,522,642,665,30,153,5,146,658,512]

theorem envBound57500 : H12AffineFastState.Bounded env57500 := by
  intro p hp
  have h : env57500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57499_57500 : H12AffineEnvironment.transform 10 649 env57499 = env57500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57499 == env57500) = true)

theorem identity57500 : scanCanonicalize (H12AffineFastState.compose env57500 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57500 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57501 : List Nat := [2,4,8,16,17,1,2,4,512,20,523,538,19,522,1,9,529,512,20,1,523,17,16,2,24,0,539,522,512,539,30,27,5,16,528,512]

theorem envBound57501 : H12AffineFastState.Bounded env57501 := by
  intro p hp
  have h : env57501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57500_57501 : H12AffineEnvironment.transform 6 2 env57500 = env57501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57500 == env57501) = true)

theorem identity57501 : scanCanonicalize (H12AffineFastState.compose env57501 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57501 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57502 : List Nat := [2,4,3,16,17,1,2,4,512,20,512,529,19,513,1,2,529,512,20,1,512,17,16,2,19,0,528,513,512,528,21,16,5,16,528,512]

theorem envBound57502 : H12AffineFastState.Bounded env57502 := by
  intro p hp
  have h : env57502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57501_57502 : H12AffineEnvironment.transform 2 3 env57501 = env57502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57501 == env57502) = true)

theorem identity57502 : scanCanonicalize (H12AffineFastState.compose env57502 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57502 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57503 : List Nat := [2,4,3,16,17,1,2,4,0,20,0,17,19,1,1,2,17,0,20,1,0,17,16,2,19,0,16,1,0,16,21,16,5,16,16,0]

theorem envBound57503 : H12AffineFastState.Bounded env57503 := by
  intro p hp
  have h : env57503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57502_57503 : H12AffineEnvironment.transform 8 0 env57502 = env57503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57502 == env57503) = true)

def env57504 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,4096,2731,4128,2570,2688,4232,6673,36,2570,6698,32,2587,2568,2594,2619,4275,4128,4265,2081,2726,168,5,2603,4233,512]

theorem envBound57504 : H12AffineFastState.Bounded env57504 := by
  intro p hp
  have h : env57504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57491_57504 : H12AffineEnvironment.transform 5 49 env57491 = env57504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57491 == env57504) = true)

theorem identity57504 : scanCanonicalize (H12AffineFastState.compose env57504 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57505 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,642,2731,674,2570,2688,522,2195,36,2570,2216,32,2587,2568,2594,2619,561,674,555,2081,2726,168,5,2603,523,512]

theorem envBound57505 : H12AffineFastState.Bounded env57505 := by
  intro p hp
  have h : env57505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57504_57505 : H12AffineEnvironment.transform 11 642 env57504 = env57505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57504 == env57505) = true)

def env57506 : List Nat := [2,4,8,0,32,33,128,4,512,36,2048,642,2731,674,2570,2688,522,2179,36,2570,2216,32,2571,2568,2594,2603,545,674,555,2081,2726,168,5,2603,523,512]

theorem envBound57506 : H12AffineFastState.Bounded env57506 := by
  intro p hp
  have h : env57506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57505_57506 : H12AffineEnvironment.transform 3 0 env57505 = env57506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57505 == env57506) = true)

theorem identity57506 : scanCanonicalize (H12AffineFastState.compose env57506 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound57506 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57507 : List Nat := [2,4,8,0,32,33,128,4,512,36,643,642,40,674,137,3,522,512,36,137,555,32,136,139,161,168,545,674,555,674,37,168,5,168,523,512]

theorem envBound57507 : H12AffineFastState.Bounded env57507 := by
  intro p hp
  have h : env57507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57506_57507 : H12AffineEnvironment.transform 10 643 env57506 = env57507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env57506 == env57507) = true)

theorem identity57507 : scanCanonicalize (H12AffineFastState.compose env57507 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57507 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57508 : List Nat := [2,4,8,0,32,33,3,4,512,36,512,513,40,545,10,3,522,512,36,10,555,32,11,8,34,43,545,545,555,545,37,43,5,43,523,512]

theorem envBound57508 : H12AffineFastState.Bounded env57508 := by
  intro p hp
  have h : env57508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57507_57508 : H12AffineEnvironment.transform 6 3 env57507 = env57508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57507 == env57508) = true)

theorem identity57508 : scanCanonicalize (H12AffineFastState.compose env57508 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57508 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env57509 : List Nat := [2,4,8,0,32,33,3,4,1,36,1,0,40,32,10,3,11,1,36,10,42,32,11,8,34,43,32,32,42,32,37,43,5,43,10,1]

theorem envBound57509 : H12AffineFastState.Bounded env57509 := by
  intro p hp
  have h : env57509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57508_57509 : H12AffineEnvironment.transform 8 1 env57508 = env57509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57508 == env57509) = true)

theorem identity57509 : scanCanonicalize (H12AffineFastState.compose env57509 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57509 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57510 : List Nat := [2,4,8,0,0,1,3,4,1,4,1,0,8,0,10,3,11,1,4,10,10,0,11,8,2,11,0,0,10,0,5,11,5,11,10,1]

theorem envBound57510 : H12AffineFastState.Bounded env57510 := by
  intro p hp
  have h : env57510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57509_57510 : H12AffineEnvironment.transform 4 0 env57509 = env57510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57509 == env57510) = true)

def env57511 : List Nat := [2,4,8,1,32,32,128,4,512,36,2048,642,2731,674,2570,2688,522,2178,36,2570,2216,32,2570,2568,2594,2602,544,674,555,2081,2726,168,5,2603,523,512]

theorem envBound57511 : H12AffineFastState.Bounded env57511 := by
  intro p hp
  have h : env57511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57505_57511 : H12AffineEnvironment.transform 3 1 env57505 = env57511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57505 == env57511) = true)

theorem identity57511 : scanCanonicalize (H12AffineFastState.compose env57511 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57511 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57512 : List Nat := [2,4,8,1,32,32,8,4,512,36,2048,522,2595,554,2570,2568,522,2058,36,2570,2080,32,2570,2568,2594,2602,544,554,555,2081,2606,32,5,2603,523,512]

theorem envBound57512 : H12AffineFastState.Bounded env57512 := by
  intro p hp
  have h : env57512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57511_57512 : H12AffineEnvironment.transform 6 8 env57511 = env57512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57511 == env57512) = true)

theorem identity57512 : scanCanonicalize (H12AffineFastState.compose env57512 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound57512 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env57513 : List Nat := [2,4,8,1,32,32,8,4,512,36,513,522,34,554,11,9,522,523,36,11,545,32,11,9,35,43,544,554,555,544,47,32,5,42,523,512]

theorem envBound57513 : H12AffineFastState.Bounded env57513 := by
  intro p hp
  have h : env57513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57512_57513 : H12AffineEnvironment.transform 10 513 env57512 = env57513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env57512 == env57513) = true)

theorem identity57513 : scanCanonicalize (H12AffineFastState.compose env57513 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57513 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57514 : List Nat := [2,4,2,1,32,32,2,4,512,36,513,512,34,544,1,3,512,513,36,1,545,32,1,3,35,33,544,544,545,544,37,32,5,32,513,512]

theorem envBound57514 : H12AffineFastState.Bounded env57514 := by
  intro p hp
  have h : env57514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57513_57514 : H12AffineEnvironment.transform 2 2 env57513 = env57514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57513 == env57514) = true)

theorem identity57514 : scanCanonicalize (H12AffineFastState.compose env57514 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57514 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57515 : List Nat := [2,4,2,1,32,32,2,4,0,36,1,0,34,32,1,3,0,1,36,1,33,32,1,3,35,33,32,32,33,32,37,32,5,32,1,0]

theorem envBound57515 : H12AffineFastState.Bounded env57515 := by
  intro p hp
  have h : env57515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57514_57515 : H12AffineEnvironment.transform 8 0 env57514 = env57515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57514 == env57515) = true)

def env57516 : List Nat := [2,4,8,16,32,64,128,5,512,84,2048,4096,2730,4177,2571,2688,4344,6673,84,2571,6747,32,2587,2680,2595,2634,4290,4177,4264,2080,2727,168,4,2651,4345,512]

theorem envBound57516 : H12AffineFastState.Bounded env57516 := by
  intro p hp
  have h : env57516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57490_57516 : H12AffineEnvironment.transform 7 5 env57490 = env57516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57490 == env57516) = true)

def env57517 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,4096,2730,4129,2571,2688,4232,6673,36,2571,6699,32,2587,2568,2595,2618,4274,4129,4264,2080,2727,168,4,2603,4233,512]

theorem envBound57517 : H12AffineFastState.Bounded env57517 := by
  intro p hp
  have h : env57517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57516_57517 : H12AffineEnvironment.transform 5 48 env57516 = env57517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57516 == env57517) = true)

theorem identity57517 : scanCanonicalize (H12AffineFastState.compose env57517 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound57517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57518 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,2048,2730,2081,2571,2688,2184,529,36,2571,555,32,2587,2568,2595,2618,2226,2081,2216,2080,2727,168,4,2603,2185,512]

theorem envBound57518 : H12AffineFastState.Bounded env57518 := by
  intro p hp
  have h : env57518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57517_57518 : H12AffineEnvironment.transform 11 2048 env57517 = env57518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env57517 == env57518) = true)

def env57519 : List Nat := [2,4,8,16,0,16,128,5,512,4,2048,2048,2698,2049,2571,2688,2184,529,4,2571,523,0,2587,2568,2563,2586,2194,2049,2184,2048,2695,136,4,2571,2185,512]

theorem envBound57519 : H12AffineFastState.Bounded env57519 := by
  intro p hp
  have h : env57519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57518_57519 : H12AffineEnvironment.transform 4 0 env57518 = env57519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57518 == env57519) = true)

theorem identity57519 : scanCanonicalize (H12AffineFastState.compose env57519 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound57519 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57520 : List Nat := [2,4,8,16,0,16,128,5,512,4,659,659,25,658,152,19,539,529,4,152,523,0,136,155,144,137,513,658,539,659,20,136,4,152,538,512]

theorem envBound57520 : H12AffineFastState.Bounded env57520 := by
  intro p hp
  have h : env57520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57519_57520 : H12AffineEnvironment.transform 10 659 env57519 = env57520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env57519 == env57520) = true)

theorem identity57520 : scanCanonicalize (H12AffineFastState.compose env57520 (packedSelected [3,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57520 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env57521 : List Nat := [2,4,8,11,0,11,128,5,512,4,648,648,2,649,131,8,512,522,4,131,523,0,136,128,139,137,513,649,512,648,15,136,4,131,513,512]

theorem envBound57521 : H12AffineFastState.Bounded env57521 := by
  intro p hp
  have h : env57521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57520_57521 : H12AffineEnvironment.transform 3 11 env57520 = env57521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57520 == env57521) = true)

theorem identity57521 : scanCanonicalize (H12AffineFastState.compose env57521 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57521 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57522 : List Nat := [2,4,8,11,0,11,128,5,0,4,136,136,2,137,131,8,0,10,4,131,11,0,136,128,139,137,1,137,0,136,15,136,4,131,1,0]

theorem envBound57522 : H12AffineFastState.Bounded env57522 := by
  intro p hp
  have h : env57522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57521_57522 : H12AffineEnvironment.transform 8 0 env57521 = env57522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57521 == env57522) = true)

def env57523 : List Nat := [2,4,8,16,1,17,128,5,512,5,2048,2048,2699,2048,2571,2688,2184,529,5,2571,522,1,2587,2568,2562,2587,2195,2048,2185,2049,2694,137,4,2570,2185,512]

theorem envBound57523 : H12AffineFastState.Bounded env57523 := by
  intro p hp
  have h : env57523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57518_57523 : H12AffineEnvironment.transform 4 1 env57518 = env57523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57518 == env57523) = true)

theorem identity57523 : scanCanonicalize (H12AffineFastState.compose env57523 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound57523 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57524 : List Nat := [2,4,8,16,1,17,128,5,512,5,665,665,18,665,146,25,529,529,5,146,522,1,130,145,155,130,522,665,528,664,31,137,4,147,528,512]

theorem envBound57524 : H12AffineFastState.Bounded env57524 := by
  intro p hp
  have h : env57524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57523_57524 : H12AffineEnvironment.transform 10 665 env57523 = env57524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env57523 == env57524) = true)

theorem identity57524 : scanCanonicalize (H12AffineFastState.compose env57524 (packedSelected [4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57524 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env57525 : List Nat := [2,4,8,16,1,17,128,5,0,5,153,153,18,153,146,25,17,17,5,146,10,1,130,145,155,130,10,153,16,152,31,137,4,147,16,0]

theorem envBound57525 : H12AffineFastState.Bounded env57525 := by
  intro p hp
  have h : env57525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57524_57525 : H12AffineEnvironment.transform 8 0 env57524 = env57525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57524 == env57525) = true)

theorem identity57525 : scanCanonicalize (H12AffineFastState.compose env57525 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57525 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57526 : List Nat := [2,4,8,16,1,17,3,5,0,5,26,26,18,26,17,25,17,17,5,17,10,1,1,18,24,1,10,26,16,27,31,10,4,16,16,0]

theorem envBound57526 : H12AffineFastState.Bounded env57526 := by
  intro p hp
  have h : env57526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57525_57526 : H12AffineEnvironment.transform 6 3 env57525 = env57526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57525 == env57526) = true)

theorem identity57526 : scanCanonicalize (H12AffineFastState.compose env57526 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57526 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57527 : List Nat := [2,4,8,1,1,0,3,5,0,5,11,11,3,11,0,8,0,0,5,0,10,1,1,3,9,1,10,11,1,10,14,10,4,1,1,0]

theorem envBound57527 : H12AffineFastState.Bounded env57527 := by
  intro p hp
  have h : env57527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57526_57527 : H12AffineEnvironment.transform 3 1 env57526 = env57527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57526 == env57527) = true)

theorem identity57527 : scanCanonicalize (H12AffineFastState.compose env57527 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57528 : List Nat := [2,4,3,1,1,0,3,5,0,5,0,0,3,0,0,3,0,0,5,0,1,1,1,3,2,1,1,0,1,1,5,1,4,1,1,0]

theorem envBound57528 : H12AffineFastState.Bounded env57528 := by
  intro p hp
  have h : env57528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57527_57528 : H12AffineEnvironment.transform 2 3 env57527 = env57528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57527 == env57528) = true)

def env57529 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,4096,2730,4128,2571,2688,4233,6673,37,2571,6698,32,2587,2569,2595,2619,4275,4128,4264,2080,2727,168,4,2602,4232,512]

theorem envBound57529 : H12AffineFastState.Bounded env57529 := by
  intro p hp
  have h : env57529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57516_57529 : H12AffineEnvironment.transform 5 49 env57516 = env57529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57516 == env57529) = true)

theorem identity57529 : scanCanonicalize (H12AffineFastState.compose env57529 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound57529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57530 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,2217,2730,2185,2571,2688,2080,696,37,2571,643,32,2587,2569,2595,2619,2074,2185,2049,2080,2727,168,4,2602,2081,512]

theorem envBound57530 : H12AffineFastState.Bounded env57530 := by
  intro p hp
  have h : env57530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57529_57530 : H12AffineEnvironment.transform 11 2217 env57529 = env57530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env57529 == env57530) = true)

def env57531 : List Nat := [2,4,8,16,32,49,128,5,512,37,648,545,34,513,131,8,680,696,37,131,643,32,147,129,171,179,658,513,649,680,47,168,4,162,681,512]

theorem envBound57531 : H12AffineFastState.Bounded env57531 := by
  intro p hp
  have h : env57531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57530_57531 : H12AffineEnvironment.transform 10 648 env57530 = env57531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57530 == env57531) = true)

theorem identity57531 : scanCanonicalize (H12AffineFastState.compose env57531 (packedSelected [1,3,4,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57531 : packedSelected [1,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env57532 : List Nat := [2,4,8,16,32,49,3,5,512,37,523,545,34,513,0,8,555,571,37,0,512,32,16,2,40,48,529,513,522,555,47,43,4,33,554,512]

theorem envBound57532 : H12AffineFastState.Bounded env57532 := by
  intro p hp
  have h : env57532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57531_57532 : H12AffineEnvironment.transform 6 3 env57531 = env57532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57531 == env57532) = true)

theorem identity57532 : scanCanonicalize (H12AffineFastState.compose env57532 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57532 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57533 : List Nat := [2,4,8,16,17,0,3,5,512,20,523,528,19,513,0,8,538,522,20,0,512,17,16,2,25,1,529,513,522,538,30,26,4,16,539,512]

theorem envBound57533 : H12AffineFastState.Bounded env57533 := by
  intro p hp
  have h : env57533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57532_57533 : H12AffineEnvironment.transform 4 17 env57532 = env57533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57532 == env57533) = true)

theorem identity57533 : scanCanonicalize (H12AffineFastState.compose env57533 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57533 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57534 : List Nat := [2,4,3,16,17,0,3,5,512,20,512,528,19,513,0,3,529,513,20,0,512,17,16,2,18,1,529,513,513,529,21,17,4,16,528,512]

theorem envBound57534 : H12AffineFastState.Bounded env57534 := by
  intro p hp
  have h : env57534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57533_57534 : H12AffineEnvironment.transform 2 3 env57533 = env57534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57533 == env57534) = true)

def env57535 : List Nat := [2,4,8,16,32,49,128,5,512,37,649,544,35,512,130,9,681,696,37,130,643,32,146,128,170,178,659,512,648,681,46,168,4,163,680,512]

theorem envBound57535 : H12AffineFastState.Bounded env57535 := by
  intro p hp
  have h : env57535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57530_57535 : H12AffineEnvironment.transform 10 649 env57530 = env57535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57530 == env57535) = true)

theorem identity57535 : scanCanonicalize (H12AffineFastState.compose env57535 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57535 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0