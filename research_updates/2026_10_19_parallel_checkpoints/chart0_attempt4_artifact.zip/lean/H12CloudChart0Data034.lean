import H12CloudChart0Data033

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound8441 : H12AffineFastState.Bounded env8441 := by
  intro p hp
  have h : env8441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8440_8441 : H12AffineEnvironment.transform 2 2 env8440 = env8441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8440 == env8441) = true)

def env8442 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545332,16432,525329,90136,8224,79374,278577,4097,4097,75786,620047,90171,525316,73770,525328,90682]

theorem envBound8442 : H12AffineFastState.Bounded env8442 := by
  intro p hp
  have h : env8442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8429_8442 : H12AffineEnvironment.transform 5 17 env8429 = env8442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8429 == env8442) = true)

theorem identity8442 : scanCanonicalize (H12AffineFastState.compose env8442 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338955) := by decide +kernel

theorem selectedBound8442 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8443 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,338955,8200,359999,16432,337946,90136,8224,79374,278577,4097,4097,75786,285188,90171,337935,73770,337947,90682]

theorem envBound8443 : H12AffineFastState.Bounded env8443 := by
  intro p hp
  have h : env8443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8442_8443 : H12AffineEnvironment.transform 18 338955 env8442 = env8443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338955 env8442 == env8443) = true)

theorem identity8443 : scanCanonicalize (H12AffineFastState.compose env8443 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24069) := by decide +kernel

theorem selectedBound8443 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8444 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,24069,94734,8200,73786,16432,95775,90136,8224,79374,7732,4097,4097,75786,1025,90171,95754,73770,95774,90682]

theorem envBound8444 : H12AffineFastState.Bounded env8444 := by
  intro p hp
  have h : env8444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8443_8444 : H12AffineEnvironment.transform 17 24069 env8443 = env8444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24069 env8443 == env8444) = true)

def env8445 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16480,525329,90137,8304,79374,278624,4176,4176,75786,620127,90171,525317,73770,2119284,90683]

theorem envBound8445 : H12AffineFastState.Bounded env8445 := by
  intro p hp
  have h : env8445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8427_8445 : H12AffineEnvironment.transform 6 121 env8427 = env8445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8427 == env8445) = true)

theorem identity8445 : scanCanonicalize (H12AffineFastState.compose env8445 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619087) := by decide +kernel

theorem selectedBound8445 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8446 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619087,16480,525329,90137,8304,79374,278624,4176,4176,75786,620127,90171,525317,73770,599099,90683]

theorem envBound8446 : H12AffineFastState.Bounded env8446 := by
  intro p hp
  have h : env8446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8445_8446 : H12AffineEnvironment.transform 20 619087 env8445 = env8446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619087 env8445 == env8446) = true)

def env8447 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619039,16432,525329,90137,8224,79374,278576,4096,4096,75786,620047,90171,525317,73770,599099,90683]

theorem envBound8447 : H12AffineFastState.Bounded env8447 := by
  intro p hp
  have h : env8447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8446_8447 : H12AffineEnvironment.transform 5 16 env8446 = env8447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8446 == env8447) = true)

theorem identity8447 : scanCanonicalize (H12AffineFastState.compose env8447 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound8447 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8448 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,524288,8200,619039,16432,525329,90137,8224,79374,81439,4096,4096,75786,620047,90171,525317,73770,599099,90683]

theorem envBound8448 : H12AffineFastState.Bounded env8448 := by
  intro p hp
  have h : env8448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8447_8448 : H12AffineEnvironment.transform 17 97839 env8447 = env8448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env8447 == env8448) = true)

theorem identity8448 : scanCanonicalize (H12AffineFastState.compose env8448 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94735) := by decide +kernel

theorem selectedBound8448 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8449 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,94735,8200,16,16432,95774,90137,8224,79374,81439,4096,4096,75786,1024,90171,95754,73770,22068,90683]

theorem envBound8449 : H12AffineFastState.Bounded env8449 := by
  intro p hp
  have h : env8449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8448_8449 : H12AffineEnvironment.transform 18 94735 env8448 = env8449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94735 env8448 == env8449) = true)

theorem identity8449 : scanCanonicalize (H12AffineFastState.compose env8449 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound8449 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8450 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,24635,4097,7700,4660,8200,16,16432,5669,34,8224,22069,24100,4096,4096,18481,1024,0,5681,16401,22068,512]

theorem envBound8450 : H12AffineFastState.Bounded env8450 := by
  intro p hp
  have h : env8450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8449_8450 : H12AffineEnvironment.transform 15 24635 env8449 = env8450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env8449 == env8450) = true)

theorem identity8450 : scanCanonicalize (H12AffineFastState.compose env8450 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound8450 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8451 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,8192,16384,8200,24635,3135,554,3594,8200,16,16432,2587,34,8224,18955,16922,3134,3134,18481,1024,0,2575,16401,18954,512]

theorem envBound8451 : H12AffineFastState.Bounded env8451 := by
  intro p hp
  have h : env8451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8450_8451 : H12AffineEnvironment.transform 11 3134 env8450 = env8451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env8450 == env8451) = true)

theorem identity8451 : scanCanonicalize (H12AffineFastState.compose env8451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8452 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,8192,16,8200,8235,3135,554,3594,8200,16,32,2587,34,8224,2587,522,3134,3134,2081,1024,0,2575,1,2586,512]

theorem envBound8452 : H12AffineFastState.Bounded env8452 := by
  intro p hp
  have h : env8452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8451_8452 : H12AffineEnvironment.transform 13 16 env8451 = env8452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8451 == env8452) = true)

theorem identity8452 : scanCanonicalize (H12AffineFastState.compose env8452 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound8452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8453 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,1062,16,1070,1037,3135,554,3594,1070,16,32,2587,34,1030,2587,522,3134,3134,2081,1024,0,2575,1,2586,512]

theorem envBound8453 : H12AffineFastState.Bounded env8453 := by
  intro p hp
  have h : env8453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8452_8453 : H12AffineEnvironment.transform 12 1062 env8452 = env8453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env8452 == env8453) = true)

theorem identity8453 : scanCanonicalize (H12AffineFastState.compose env8453 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8454 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3102,1030,16,1038,1037,3103,522,3594,1038,16,0,2587,2,1030,2587,522,3102,3102,2049,1024,0,2575,1,2586,512]

theorem envBound8454 : H12AffineFastState.Bounded env8454 := by
  intro p hp
  have h : env8454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8453_8454 : H12AffineEnvironment.transform 4 0 env8453 = env8454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8453 == env8454) = true)

theorem identity8454 : scanCanonicalize (H12AffineFastState.compose env8454 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound8454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8455 : List Nat := [2,4,8,16,0,16,9,5,512,14,2048,2064,8,16,0,3,2065,522,2564,0,16,0,2587,2,8,2587,522,2064,2064,2049,14,0,2575,1,2586,512]

theorem envBound8455 : H12AffineFastState.Bounded env8455 := by
  intro p hp
  have h : env8455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8454_8455 : H12AffineEnvironment.transform 9 14 env8454 = env8455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env8454 == env8455) = true)

theorem identity8455 : scanCanonicalize (H12AffineFastState.compose env8455 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound8455 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env8456 : List Nat := [2,4,8,16,0,16,9,5,512,14,10,26,8,16,0,3,27,522,526,0,16,0,529,2,8,529,522,26,26,11,14,0,517,1,528,512]

theorem envBound8456 : H12AffineFastState.Bounded env8456 := by
  intro p hp
  have h : env8456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8455_8456 : H12AffineEnvironment.transform 10 10 env8455 = env8456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env8455 == env8456) = true)

theorem identity8456 : scanCanonicalize (H12AffineFastState.compose env8456 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound8456 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8457 : List Nat := [2,4,8,16,0,16,9,5,1,14,10,26,8,16,0,3,27,11,15,0,16,0,16,2,8,16,11,26,26,11,14,0,4,1,17,1]

theorem envBound8457 : H12AffineFastState.Bounded env8457 := by
  intro p hp
  have h : env8457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8456_8457 : H12AffineEnvironment.transform 8 1 env8456 = env8457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env8456 == env8457) = true)

theorem identity8457 : scanCanonicalize (H12AffineFastState.compose env8457 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8458 : List Nat := [2,4,8,11,0,11,9,5,1,14,10,1,8,11,0,3,0,11,15,0,11,0,11,2,8,11,11,1,1,11,14,0,4,1,10,1]

theorem envBound8458 : H12AffineFastState.Bounded env8458 := by
  intro p hp
  have h : env8458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8457_8458 : H12AffineEnvironment.transform 3 11 env8457 = env8458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8457 == env8458) = true)

def env8459 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619038,16433,525329,90137,8225,79374,278577,4097,4097,75786,620046,90171,525317,73770,599099,90683]

theorem envBound8459 : H12AffineFastState.Bounded env8459 := by
  intro p hp
  have h : env8459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8446_8459 : H12AffineEnvironment.transform 5 17 env8446 = env8459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8446 == env8459) = true)

theorem identity8459 : scanCanonicalize (H12AffineFastState.compose env8459 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281648) := by decide +kernel

theorem selectedBound8459 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8460 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,281648,8200,343598,16433,280609,90137,8225,79374,278577,4097,4097,75786,342590,90171,280629,73770,354315,90683]

theorem envBound8460 : H12AffineFastState.Bounded env8460 := by
  intro p hp
  have h : env8460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8459_8460 : H12AffineEnvironment.transform 18 281648 env8459 = env8460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281648 env8459 == env8460) = true)

theorem identity8460 : scanCanonicalize (H12AffineFastState.compose env8460 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound8460 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8461 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,78366,8200,16384,16433,79375,90137,8225,79374,81439,4097,4097,75786,17424,90171,79387,73770,5669,90683]

theorem envBound8461 : H12AffineFastState.Bounded env8461 := by
  intro p hp
  have h : env8461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8460_8461 : H12AffineEnvironment.transform 17 97838 env8460 = env8461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env8460 == env8461) = true)

def env8462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,90337,8329,79858,278624,4524,4176,75787,620379,90170,525568,73771,2119537,90943]

theorem envBound8462 : H12AffineFastState.Bounded env8462 := by
  intro p hp
  have h : env8462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8425_8462 : H12AffineEnvironment.transform 23 90337 env8425 = env8462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8425 == env8462) = true)

theorem identity8462 : scanCanonicalize (H12AffineFastState.compose env8462 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8462 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,4605,262144,524288,8692,2097152,16741,525805,34,8329,22321,278624,4524,4176,18632,530328,249,525568,16616,2119537,1020]

theorem envBound8463 : H12AffineFastState.Bounded env8463 := by
  intro p hp
  have h : env8463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8462_8463 : H12AffineEnvironment.transform 15 24771 env8462 = env8463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8462 == env8463) = true)

def env8464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8403,4605,262144,524288,8692,2097152,373,525805,34,8329,5921,262256,4524,4176,2264,530328,249,525568,248,2103137,1020]

theorem envBound8464 : H12AffineFastState.Bounded env8464 := by
  intro p hp
  have h : env8464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8463_8464 : H12AffineEnvironment.transform 13 16 env8463 = env8464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8463 == env8464) = true)

theorem identity8464 : scanCanonicalize (H12AffineFastState.compose env8464 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5201) := by decide +kernel

theorem selectedBound8464 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env8465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8403,4605,262144,5201,8692,2097152,373,4540,34,8329,5921,262256,4524,4176,2264,969,249,4433,248,2103137,1020]

theorem envBound8465 : H12AffineFastState.Bounded env8465 := by
  intro p hp
  have h : env8465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8464_8465 : H12AffineEnvironment.transform 18 5201 env8464 = env8465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5201 env8464 == env8465) = true)

def env8466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8402,4605,262144,524288,8692,2097152,372,525805,34,8329,5920,262257,4524,4176,2265,530328,249,525568,249,2103136,1020]

theorem envBound8466 : H12AffineFastState.Bounded env8466 := by
  intro p hp
  have h : env8466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8463_8466 : H12AffineEnvironment.transform 13 17 env8463 = env8466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8463 == env8466) = true)

theorem identity8466 : scanCanonicalize (H12AffineFastState.compose env8466 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8466 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8467 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8402,4097,262144,524288,8200,2097152,136,525329,34,8329,5852,262257,4176,4176,2265,530020,249,525564,249,2102940,512]

theorem envBound8467 : H12AffineFastState.Bounded env8467 := by
  intro p hp
  have h : env8467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8466_8467 : H12AffineEnvironment.transform 7 252 env8466 = env8467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8466 == env8467) = true)

theorem identity8467 : scanCanonicalize (H12AffineFastState.compose env8467 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529036) := by decide +kernel

theorem selectedBound8467 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8468 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8402,4097,262144,524288,8200,529036,136,525329,34,8329,5852,262257,4176,4176,2265,530020,249,525564,249,525328,512]

theorem envBound8468 : H12AffineFastState.Bounded env8468 := by
  intro p hp
  have h : env8468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8467_8468 : H12AffineEnvironment.transform 20 529036 env8467 = env8468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529036 env8467 == env8468) = true)

theorem identity8468 : scanCanonicalize (H12AffineFastState.compose env8468 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4661) := by decide +kernel

theorem selectedBound8468 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8469 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8402,4097,262144,4661,8200,185,136,5668,34,8329,5852,262257,4176,4176,2265,1105,249,5833,249,5669,512]

theorem envBound8469 : H12AffineFastState.Bounded env8469 := by
  intro p hp
  have h : env8469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8468_8469 : H12AffineEnvironment.transform 18 4661 env8468 = env8469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4661 env8468 == env8469) = true)

theorem identity8469 : scanCanonicalize (H12AffineFastState.compose env8469 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound8469 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8470 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,17,2275,2105,4097,262144,4661,2275,185,136,5668,34,2146,5852,262257,4176,4176,2265,1105,249,5833,249,5669,512]

theorem envBound8470 : H12AffineFastState.Bounded env8470 := by
  intro p hp
  have h : env8470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8469_8470 : H12AffineEnvironment.transform 12 2283 env8469 = env8470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env8469 == env8470) = true)

theorem identity8470 : scanCanonicalize (H12AffineFastState.compose env8470 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 1190) := by decide +kernel

theorem selectedBound8470 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8471 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,17,2275,2105,4097,1190,4661,2275,185,136,5668,34,2146,5852,1239,4176,4176,2265,1105,249,5833,249,5669,512]

theorem envBound8471 : H12AffineFastState.Bounded env8471 := by
  intro p hp
  have h : env8471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8470_8471 : H12AffineEnvironment.transform 17 1190 env8470 = env8471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1190 env8470 == env8471) = true)

theorem identity8471 : scanCanonicalize (H12AffineFastState.compose env8471 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8471 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env8472 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,4096,2283,17,2275,2105,4097,163,4661,2275,185,136,4641,34,2146,4825,210,4176,4176,2265,84,249,4812,249,4640,512]

theorem envBound8472 : H12AffineFastState.Bounded env8472 := by
  intro p hp
  have h : env8472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8471_8472 : H12AffineEnvironment.transform 9 5 env8471 = env8472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8471 == env8472) = true)

theorem identity8472 : scanCanonicalize (H12AffineFastState.compose env8472 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2738) := by decide +kernel

theorem selectedBound8472 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8473 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,2738,2283,17,2275,2105,2739,163,2183,2275,185,136,2195,34,2146,2155,210,2786,2786,2265,84,249,2174,249,2194,512]

theorem envBound8473 : H12AffineFastState.Bounded env8473 := by
  intro p hp
  have h : env8473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8472_8473 : H12AffineEnvironment.transform 11 2738 env8472 = env8473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2738 env8472 == env8473) = true)

theorem identity8473 : scanCanonicalize (H12AffineFastState.compose env8473 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound8473 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8474 : List Nat := [2,4,8,16,32,64,128,252,201,5,2048,2171,2283,17,2275,2105,2170,163,2183,2275,185,136,2195,34,2146,2155,210,2091,2091,2265,84,249,2174,249,2194,201]

theorem envBound8474 : H12AffineFastState.Bounded env8474 := by
  intro p hp
  have h : env8474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8473_8474 : H12AffineEnvironment.transform 8 201 env8473 = env8474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env8473 == env8474) = true)

theorem identity8474 : scanCanonicalize (H12AffineFastState.compose env8474 (packedSelected [4,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound8474 : packedSelected [4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env8475 : List Nat := [2,4,8,16,32,64,128,252,201,5,11,112,224,17,232,50,113,163,140,232,185,136,152,34,105,96,210,32,32,210,84,249,117,249,153,201]

theorem envBound8475 : H12AffineFastState.Bounded env8475 := by
  intro p hp
  have h : env8475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8474_8475 : H12AffineEnvironment.transform 10 11 env8474 = env8475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env8474 == env8475) = true)

def env8476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,16777216,8329,79858,278625,4525,4177,16795883,17307578,16777434,525568,16793803,2119536,16778206]

theorem envBound8476 : H12AffineFastState.Bounded env8476 := by
  intro p hp
  have h : env8476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8424_8476 : H12AffineEnvironment.transform 26 278625 env8424 = env8476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278625 env8424 == env8476) = true)

def env8477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,90336,8329,79858,278625,4525,4177,75787,620378,90170,525568,73771,2119536,90942]

theorem envBound8477 : H12AffineFastState.Bounded env8477 := by
  intro p hp
  have h : env8477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8476_8477 : H12AffineEnvironment.transform 23 90336 env8476 = env8477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8476 == env8477) = true)

theorem identity8477 : scanCanonicalize (H12AffineFastState.compose env8477 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8477 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24770,4605,262144,524288,8692,2097152,16741,525805,34,8329,22320,278625,4525,4177,18633,530328,248,525568,16617,2119536,1020]

theorem envBound8478 : H12AffineFastState.Bounded env8478 := by
  intro p hp
  have h : env8478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8477_8478 : H12AffineEnvironment.transform 15 24770 env8477 = env8478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8477 == env8478) = true)

def env8479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8402,4605,262144,524288,8692,2097152,373,525805,34,8329,5920,262257,4525,4177,2265,530328,248,525568,249,2103136,1020]

theorem envBound8479 : H12AffineFastState.Bounded env8479 := by
  intro p hp
  have h : env8479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8478_8479 : H12AffineEnvironment.transform 13 16 env8478 = env8479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8478 == env8479) = true)

theorem identity8479 : scanCanonicalize (H12AffineFastState.compose env8479 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5200) := by decide +kernel

theorem selectedBound8479 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env8480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8692,8402,4605,262144,5200,8692,2097152,373,4541,34,8329,5920,262257,4525,4177,2265,968,248,4432,249,2103136,1020]

theorem envBound8480 : H12AffineFastState.Bounded env8480 := by
  intro p hp
  have h : env8480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8479_8480 : H12AffineEnvironment.transform 18 5200 env8479 = env8480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5200 env8479 == env8480) = true)

def env8481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8692,8403,4605,262144,524288,8692,2097152,372,525805,34,8329,5921,262256,4525,4177,2264,530328,248,525568,248,2103137,1020]

theorem envBound8481 : H12AffineFastState.Bounded env8481 := by
  intro p hp
  have h : env8481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8478_8481 : H12AffineEnvironment.transform 13 17 env8478 = env8481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env8478 == env8481) = true)

theorem identity8481 : scanCanonicalize (H12AffineFastState.compose env8481 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8481 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8482 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8403,4097,262144,524288,8200,2097152,136,525329,34,8329,5853,262256,4177,4177,2264,530020,248,525564,248,2102941,512]

theorem envBound8482 : H12AffineFastState.Bounded env8482 := by
  intro p hp
  have h : env8482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8481_8482 : H12AffineEnvironment.transform 7 252 env8481 = env8482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8481 == env8482) = true)

theorem identity8482 : scanCanonicalize (H12AffineFastState.compose env8482 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529036) := by decide +kernel

theorem selectedBound8482 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8483 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8403,4097,262144,524288,8200,529036,136,525329,34,8329,5853,262256,4177,4177,2264,530020,248,525564,248,525329,512]

theorem envBound8483 : H12AffineFastState.Bounded env8483 := by
  intro p hp
  have h : env8483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8482_8483 : H12AffineEnvironment.transform 20 529036 env8482 = env8483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529036 env8482 == env8483) = true)

theorem identity8483 : scanCanonicalize (H12AffineFastState.compose env8483 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4660) := by decide +kernel

theorem selectedBound8483 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8484 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8403,4097,262144,4660,8200,184,136,5669,34,8329,5853,262256,4177,4177,2264,1104,248,5832,248,5669,512]

theorem envBound8484 : H12AffineFastState.Bounded env8484 := by
  intro p hp
  have h : env8484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8483_8484 : H12AffineEnvironment.transform 18 4660 env8483 = env8484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4660 env8483 == env8484) = true)

theorem identity8484 : scanCanonicalize (H12AffineFastState.compose env8484 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 13999) := by decide +kernel

theorem selectedBound8484 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8485 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8200,8403,4097,13999,4660,8200,184,136,5669,34,8329,5853,14047,4177,4177,2264,1104,248,5832,248,5669,512]

theorem envBound8485 : H12AffineFastState.Bounded env8485 := by
  intro p hp
  have h : env8485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8484_8485 : H12AffineEnvironment.transform 17 13999 env8484 = env8485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13999 env8484 == env8485) = true)

theorem identity8485 : scanCanonicalize (H12AffineFastState.compose env8485 (packedSelected [2,13,14] rootPS)) = affineNative (2^(11+1) ^^^ 2787) := by decide +kernel

theorem selectedBound8485 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8486 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2787,8192,17,8200,8403,2786,11340,2263,8200,184,136,3270,34,8329,3134,11324,2738,2738,2264,1104,248,3115,248,3270,512]

theorem envBound8486 : H12AffineFastState.Bounded env8486 := by
  intro p hp
  have h : env8486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8485_8486 : H12AffineEnvironment.transform 11 2787 env8485 = env8486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2787 env8485 == env8486) = true)

theorem identity8486 : scanCanonicalize (H12AffineFastState.compose env8486 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3311) := by decide +kernel

theorem selectedBound8486 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env8487 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2787,3311,17,3303,3132,2786,163,2263,3303,184,136,3270,34,3174,3134,211,2738,2738,2264,1104,248,3115,248,3270,512]

theorem envBound8487 : H12AffineFastState.Bounded env8487 := by
  intro p hp
  have h : env8487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8486_8487 : H12AffineEnvironment.transform 12 3311 env8486 = env8487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3311 env8486 == env8487) = true)

theorem identity8487 : scanCanonicalize (H12AffineFastState.compose env8487 (packedSelected [13,17] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound8487 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8488 : List Nat := [2,4,8,16,32,64,128,252,512,84,2048,2787,2235,17,2227,2152,2786,163,2263,2227,184,136,2194,34,2098,2154,211,2738,2738,2264,4,248,2175,248,2194,512]

theorem envBound8488 : H12AffineFastState.Bounded env8488 := by
  intro p hp
  have h : env8488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8487_8488 : H12AffineEnvironment.transform 9 84 env8487 = env8488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env8487 == env8488) = true)

theorem identity8488 : scanCanonicalize (H12AffineFastState.compose env8488 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 153) := by decide +kernel

theorem selectedBound8488 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8489 : List Nat := [2,4,8,16,32,64,128,252,153,84,2048,2170,2235,17,2227,2152,2171,163,2263,2227,184,136,2194,34,2098,2154,211,2091,2091,2264,4,248,2175,248,2194,153]

theorem envBound8489 : H12AffineFastState.Bounded env8489 := by
  intro p hp
  have h : env8489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8488_8489 : H12AffineEnvironment.transform 8 153 env8488 = env8489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env8488 == env8489) = true)

def env8490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,16741,525805,90337,8329,79858,278625,4525,4177,75786,620379,90171,525568,73770,2119536,90943]

theorem envBound8490 : H12AffineFastState.Bounded env8490 := by
  intro p hp
  have h : env8490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8476_8490 : H12AffineEnvironment.transform 23 90337 env8476 = env8490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8476 == env8490) = true)

theorem identity8490 : scanCanonicalize (H12AffineFastState.compose env8490 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8490 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8491 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16537,525329,90337,8329,79374,278625,4177,4177,75786,620199,90171,525564,73770,2119308,90819]

theorem envBound8491 : H12AffineFastState.Bounded env8491 := by
  intro p hp
  have h : env8491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8490_8491 : H12AffineEnvironment.transform 7 252 env8490 = env8491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8490 == env8491) = true)

def env8492 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16481,525329,90137,8305,79374,278625,4177,4177,75786,620127,90171,525316,73770,2119284,90683]

theorem envBound8492 : H12AffineFastState.Bounded env8492 := by
  intro p hp
  have h : env8492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8491_8492 : H12AffineEnvironment.transform 6 120 env8491 = env8492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8491 == env8492) = true)

theorem identity8492 : scanCanonicalize (H12AffineFastState.compose env8492 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619086) := by decide +kernel

theorem selectedBound8492 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8493 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619086,16481,525329,90137,8305,79374,278625,4177,4177,75786,620127,90171,525316,73770,599098,90683]

theorem envBound8493 : H12AffineFastState.Bounded env8493 := by
  intro p hp
  have h : env8493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8492_8493 : H12AffineEnvironment.transform 20 619086 env8492 = env8493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619086 env8492 == env8493) = true)

def env8494 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619038,16433,525329,90137,8225,79374,278577,4097,4097,75786,620047,90171,525316,73770,599098,90683]

theorem envBound8494 : H12AffineFastState.Bounded env8494 := by
  intro p hp
  have h : env8494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8493_8494 : H12AffineEnvironment.transform 5 16 env8493 = env8494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8493 == env8494) = true)

theorem identity8494 : scanCanonicalize (H12AffineFastState.compose env8494 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281649) := by decide +kernel

theorem selectedBound8494 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8495 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,281649,8200,343599,16433,280608,90137,8225,79374,278577,4097,4097,75786,342590,90171,280629,73770,354315,90683]

theorem envBound8495 : H12AffineFastState.Bounded env8495 := by
  intro p hp
  have h : env8495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8494_8495 : H12AffineEnvironment.transform 18 281649 env8494 = env8495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281649 env8494 == env8495) = true)

theorem identity8495 : scanCanonicalize (H12AffineFastState.compose env8495 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound8495 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8496 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97838,78367,8200,16385,16433,79374,90137,8225,79374,81439,4097,4097,75786,17424,90171,79387,73770,5669,90683]

theorem envBound8496 : H12AffineFastState.Bounded env8496 := by
  intro p hp
  have h : env8496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8495_8496 : H12AffineEnvironment.transform 17 97838 env8495 = env8496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env8495 == env8496) = true)

def env8497 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,619039,16432,525329,90137,8224,79374,278576,4096,4096,75786,620046,90171,525316,73770,599098,90683]

theorem envBound8497 : H12AffineFastState.Bounded env8497 := by
  intro p hp
  have h : env8497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8493_8497 : H12AffineEnvironment.transform 5 17 env8493 = env8497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8493 == env8497) = true)

theorem identity8497 : scanCanonicalize (H12AffineFastState.compose env8497 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound8497 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8498 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,524288,8200,619039,16432,525329,90137,8224,79374,81439,4096,4096,75786,620046,90171,525316,73770,599098,90683]

theorem envBound8498 : H12AffineFastState.Bounded env8498 := by
  intro p hp
  have h : env8498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8497_8498 : H12AffineEnvironment.transform 17 97839 env8497 = env8498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env8497 == env8498) = true)

theorem identity8498 : scanCanonicalize (H12AffineFastState.compose env8498 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94734) := by decide +kernel

theorem selectedBound8498 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8499 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,65536,4097,97839,94734,8200,17,16432,95775,90137,8224,79374,81439,4096,4096,75786,1024,90171,95754,73770,22068,90683]

theorem envBound8499 : H12AffineFastState.Bounded env8499 := by
  intro p hp
  have h : env8499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8498_8499 : H12AffineEnvironment.transform 18 94734 env8498 = env8499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94734 env8498 == env8499) = true)

theorem identity8499 : scanCanonicalize (H12AffineFastState.compose env8499 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound8499 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8500 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8200,24635,4097,7700,4661,8200,17,16432,5668,34,8224,22069,24100,4096,4096,18481,1024,0,5681,16401,22068,512]

theorem envBound8500 : H12AffineFastState.Bounded env8500 := by
  intro p hp
  have h : env8500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8499_8500 : H12AffineEnvironment.transform 15 24635 env8499 = env8500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env8499 == env8500) = true)

theorem identity8500 : scanCanonicalize (H12AffineFastState.compose env8500 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2587) := by decide +kernel

theorem selectedBound8500 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8501 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,2587,8200,10784,4097,7700,4661,8200,17,2603,5668,34,8224,7214,5183,4096,4096,554,1024,0,5681,2570,7215,512]

theorem envBound8501 : H12AffineFastState.Bounded env8501 := by
  intro p hp
  have h : env8501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8500_8501 : H12AffineEnvironment.transform 13 2587 env8500 = env8501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2587 env8500 == env8501) = true)

theorem identity8501 : scanCanonicalize (H12AffineFastState.compose env8501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8502 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,4096,8192,16,8200,8235,4097,5151,4661,8200,17,32,5668,34,8224,5669,5183,4096,4096,554,1024,0,5681,1,5668,512]

theorem envBound8502 : H12AffineFastState.Bounded env8502 := by
  intro p hp
  have h : env8502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8501_8502 : H12AffineEnvironment.transform 10 523 env8501 = env8502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8501 == env8502) = true)

theorem identity8502 : scanCanonicalize (H12AffineFastState.compose env8502 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound8502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8503 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,4096,1063,16,1071,1036,4097,5151,4661,1071,17,32,5668,34,1031,5669,5183,4096,4096,554,1024,0,5681,1,5668,512]

theorem envBound8503 : H12AffineFastState.Bounded env8503 := by
  intro p hp
  have h : env8503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8502_8503 : H12AffineEnvironment.transform 12 1063 env8502 = env8503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env8502 == env8503) = true)

theorem identity8503 : scanCanonicalize (H12AffineFastState.compose env8503 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8504 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,4096,1030,16,1038,1036,4097,5151,4628,1038,17,1,5637,3,1031,5636,5150,4096,4096,523,1024,0,5648,1,5637,512]

theorem envBound8504 : H12AffineFastState.Bounded env8504 := by
  intro p hp
  have h : env8504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8503_8504 : H12AffineEnvironment.transform 4 1 env8503 = env8504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8503 == env8504) = true)

theorem identity8504 : scanCanonicalize (H12AffineFastState.compose env8504 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound8504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8505 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,27,1030,16,1038,1036,26,1028,527,1038,17,1,1566,3,1031,1567,1029,27,27,523,1024,0,1547,1,1566,512]

theorem envBound8505 : H12AffineFastState.Bounded env8505 := by
  intro p hp
  have h : env8505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8504_8505 : H12AffineEnvironment.transform 11 27 env8504 = env8505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env8504 == env8505) = true)

theorem identity8505 : scanCanonicalize (H12AffineFastState.compose env8505 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8505 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env8506 : List Nat := [2,4,8,16,1,17,8,4,0,1024,11,27,1030,16,1038,1036,26,1028,15,1038,17,1,1054,3,1031,1055,1029,27,27,11,1024,0,1035,1,1054,0]

theorem envBound8506 : H12AffineFastState.Bounded env8506 := by
  intro p hp
  have h : env8506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8505_8506 : H12AffineEnvironment.transform 8 0 env8505 = env8506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8505 == env8506) = true)

theorem identity8506 : scanCanonicalize (H12AffineFastState.compose env8506 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound8506 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8507 : List Nat := [2,4,8,16,1,17,8,4,0,15,11,27,9,16,1,3,26,11,15,1,17,1,17,3,8,16,10,27,27,11,15,0,4,1,17,0]

theorem envBound8507 : H12AffineFastState.Bounded env8507 := by
  intro p hp
  have h : env8507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8506_8507 : H12AffineEnvironment.transform 9 15 env8506 = env8507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env8506 == env8507) = true)

theorem identity8507 : scanCanonicalize (H12AffineFastState.compose env8507 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8508 : List Nat := [2,4,8,10,1,11,8,4,0,15,11,1,9,10,1,3,0,11,15,1,11,1,11,3,8,10,10,1,1,11,15,0,4,1,11,0]

theorem envBound8508 : H12AffineFastState.Bounded env8508 := by
  intro p hp
  have h : env8508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8507_8508 : H12AffineEnvironment.transform 3 10 env8507 = env8508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8507 == env8508) = true)

def env8509 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,16480,525329,90136,8304,79374,278625,4177,4177,75786,620126,90171,525317,73770,2119285,90682]

theorem envBound8509 : H12AffineFastState.Bounded env8509 := by
  intro p hp
  have h : env8509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8491_8509 : H12AffineEnvironment.transform 6 121 env8491 = env8509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8491 == env8509) = true)

theorem identity8509 : scanCanonicalize (H12AffineFastState.compose env8509 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545380) := by decide +kernel

theorem selectedBound8509 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8510 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545380,16480,525329,90136,8304,79374,278625,4177,4177,75786,620126,90171,525317,73770,525329,90682]

theorem envBound8510 : H12AffineFastState.Bounded env8510 := by
  intro p hp
  have h : env8510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8509_8510 : H12AffineEnvironment.transform 20 545380 env8509 = env8510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545380 env8509 == env8510) = true)

def env8511 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545332,16432,525329,90136,8224,79374,278577,4097,4097,75786,620046,90171,525317,73770,525329,90682]

theorem envBound8511 : H12AffineFastState.Bounded env8511 := by
  intro p hp
  have h : env8511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8510_8511 : H12AffineEnvironment.transform 5 16 env8510 = env8511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8510 == env8511) = true)

theorem identity8511 : scanCanonicalize (H12AffineFastState.compose env8511 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338954) := by decide +kernel

theorem selectedBound8511 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8512 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,338954,8200,359998,16432,337947,90136,8224,79374,278577,4097,4097,75786,285188,90171,337935,73770,337947,90682]

theorem envBound8512 : H12AffineFastState.Bounded env8512 := by
  intro p hp
  have h : env8512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8511_8512 : H12AffineEnvironment.transform 18 338954 env8511 = env8512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338954 env8511 == env8512) = true)

theorem identity8512 : scanCanonicalize (H12AffineFastState.compose env8512 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24069) := by decide +kernel

theorem selectedBound8512 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env8513 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8200,65536,4097,24069,94735,8200,73787,16432,95774,90136,8224,79374,7732,4097,4097,75786,1025,90171,95754,73770,95774,90682]

theorem envBound8513 : H12AffineFastState.Bounded env8513 := by
  intro p hp
  have h : env8513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8512_8513 : H12AffineEnvironment.transform 17 24069 env8512 = env8513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24069 env8512 == env8513) = true)

def env8514 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,545333,16433,525329,90136,8225,79374,278576,4096,4096,75786,620047,90171,525317,73770,525329,90682]

theorem envBound8514 : H12AffineFastState.Bounded env8514 := by
  intro p hp
  have h : env8514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8510_8514 : H12AffineEnvironment.transform 5 17 env8510 = env8514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8510 == env8514) = true)

theorem identity8514 : scanCanonicalize (H12AffineFastState.compose env8514 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound8514 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8515 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,524288,8200,545333,16433,525329,90136,8225,79374,24101,4096,4096,75786,620047,90171,525317,73770,525329,90682]

theorem envBound8515 : H12AffineFastState.Bounded env8515 := by
  intro p hp
  have h : env8515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8514_8515 : H12AffineEnvironment.transform 17 7701 env8514 = env8515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env8514 == env8515) = true)

theorem identity8515 : scanCanonicalize (H12AffineFastState.compose env8515 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78366) := by decide +kernel

theorem selectedBound8515 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8516 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8200,65536,4097,7701,78366,8200,90155,16433,79375,90136,8225,79374,24101,4096,4096,75786,17425,90171,79387,73770,79375,90682]

theorem envBound8516 : H12AffineFastState.Bounded env8516 := by
  intro p hp
  have h : env8516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8515_8516 : H12AffineEnvironment.transform 18 78366 env8515 = env8516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78366 env8515 == env8516) = true)

theorem identity8516 : scanCanonicalize (H12AffineFastState.compose env8516 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound8516 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env8517 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16,8200,65536,4097,7701,78366,8200,73787,33,79375,73736,8225,79374,7733,4096,4096,75786,1025,73771,79387,73770,79375,74282]

theorem envBound8517 : H12AffineFastState.Bounded env8517 := by
  intro p hp
  have h : env8517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8516_8517 : H12AffineEnvironment.transform 13 16 env8516 = env8517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env8516 == env8517) = true)

theorem identity8517 : scanCanonicalize (H12AffineFastState.compose env8517 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound8517 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8518 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,4096,8192,16,8200,65536,4097,5668,78366,8200,73787,33,79375,73736,8225,79374,5636,4096,4096,73787,1025,73771,79387,73770,79375,74282]

theorem envBound8518 : H12AffineFastState.Bounded env8518 := by
  intro p hp
  have h : env8518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8517_8518 : H12AffineEnvironment.transform 10 49 env8517 = env8518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env8517 == env8518) = true)

theorem identity8518 : scanCanonicalize (H12AffineFastState.compose env8518 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8518 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8519 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,4096,25,16,17,65536,4097,5668,70151,17,65570,33,71190,65553,56,71191,5636,4096,4096,65570,1025,65586,71170,65587,71190,66099]

theorem envBound8519 : H12AffineFastState.Bounded env8519 := by
  intro p hp
  have h : env8519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8518_8519 : H12AffineEnvironment.transform 12 25 env8518 = env8519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8518 == env8519) = true)

theorem identity8519 : scanCanonicalize (H12AffineFastState.compose env8519 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound8519 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8520 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,1029,25,16,17,65536,1028,545,67074,17,65570,33,66067,65553,56,66066,513,1029,1029,65570,1025,65586,66055,65587,66067,66099]

theorem envBound8520 : H12AffineFastState.Bounded env8520 := by
  intro p hp
  have h : env8520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8519_8520 : H12AffineEnvironment.transform 11 1029 env8519 = env8520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env8519 == env8520) = true)

theorem identity8520 : scanCanonicalize (H12AffineFastState.compose env8520 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(15+1) ^^^ 520) := by decide +kernel

theorem selectedBound8520 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env8521 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,1029,25,16,17,520,1028,545,1034,17,554,33,27,537,56,26,513,1029,1029,554,1025,570,15,571,27,59]

theorem envBound8521 : H12AffineFastState.Bounded env8521 := by
  intro p hp
  have h : env8521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8520_8521 : H12AffineEnvironment.transform 15 520 env8520 = env8521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 520 env8520 == env8521) = true)

theorem identity8521 : scanCanonicalize (H12AffineFastState.compose env8521 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound8521 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8522 : List Nat := [2,4,8,16,32,17,40,5,512,63,49,58,25,16,17,520,59,545,53,17,554,33,27,537,56,26,513,58,58,554,62,570,15,571,27,59]

theorem envBound8522 : H12AffineFastState.Bounded env8522 := by
  intro p hp
  have h : env8522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8521_8522 : H12AffineEnvironment.transform 9 63 env8521 = env8522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env8521 == env8522) = true)

theorem identity8522 : scanCanonicalize (H12AffineFastState.compose env8522 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8523 : List Nat := [2,4,8,16,17,17,25,5,512,14,0,11,25,16,17,520,10,528,4,17,539,16,27,537,9,26,513,11,11,539,15,523,15,522,27,10]

theorem envBound8523 : H12AffineFastState.Bounded env8523 := by
  intro p hp
  have h : env8523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8522_8523 : H12AffineEnvironment.transform 4 17 env8522 = env8523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8522 == env8523) = true)

theorem identity8523 : scanCanonicalize (H12AffineFastState.compose env8523 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound8523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8524 : List Nat := [2,4,8,16,17,17,25,5,10,14,0,11,25,16,17,2,10,26,4,17,17,16,27,19,9,26,11,11,11,17,15,1,15,0,27,10]

theorem envBound8524 : H12AffineFastState.Bounded env8524 := by
  intro p hp
  have h : env8524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8523_8524 : H12AffineEnvironment.transform 8 10 env8523 = env8524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env8523 == env8524) = true)

theorem identity8524 : scanCanonicalize (H12AffineFastState.compose env8524 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8525 : List Nat := [2,4,8,10,11,11,3,5,10,14,0,11,3,10,11,2,10,0,4,11,11,10,1,9,9,0,11,11,11,11,15,1,15,0,1,10]

theorem envBound8525 : H12AffineFastState.Bounded env8525 := by
  intro p hp
  have h : env8525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8524_8525 : H12AffineEnvironment.transform 3 10 env8524 = env8525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8524 == env8525) = true)

theorem identity8525 : scanCanonicalize (H12AffineFastState.compose env8525 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8526 : List Nat := [2,4,2,0,1,1,3,5,0,4,0,1,3,0,1,2,0,0,4,1,1,0,1,3,3,0,1,1,1,1,5,1,5,0,1,0]

theorem envBound8526 : H12AffineFastState.Bounded env8526 := by
  intro p hp
  have h : env8526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8525_8526 : H12AffineEnvironment.transform 2 2 env8525 = env8526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8525 == env8526) = true)

def env8527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound8527 : H12AffineFastState.Bounded env8527 := by
  intro p hp
  have h : env8527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8105_8527 : H12AffineEnvironment.transform 14 8693 env8105 = env8527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env8105 == env8527) = true)

def env8528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,138678440,138678612,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound8528 : H12AffineFastState.Bounded env8528 := by
  intro p hp
  have h : env8528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8527_8528 : H12AffineEnvironment.transform 27 138678440 env8527 = env8528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env8527 == env8528) = true)

theorem identity8528 : scanCanonicalize (H12AffineFastState.compose env8528 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 16857041) := by decide +kernel

theorem selectedBound8528 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,16857041,134217728,138678440,138678612,151259274,530328,155451871,525568,151257258,153360179,16778207]

theorem envBound8529 : H12AffineFastState.Bounded env8529 := by
  intro p hp
  have h : env8529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8528_8529 : H12AffineEnvironment.transform 25 16857041 env8528 = env8529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16857041 env8528 == env8529) = true)

def env8530 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855761,134217728,138678440,138678612,151259274,529048,155451871,524288,151257258,153358899,16778207]

theorem envBound8530 : H12AffineFastState.Bounded env8530 := by
  intro p hp
  have h : env8530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8529_8530 : H12AffineEnvironment.transform 9 256 env8529 = env8530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env8529 == env8530) = true)

def env8531 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855761,807680,4735912,4735572,17324938,529048,21517023,524288,17322922,19415347,16778207]

theorem envBound8531 : H12AffineFastState.Bounded env8531 := by
  intro p hp
  have h : env8531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8530_8531 : H12AffineEnvironment.transform 26 807680 env8530 = env8531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807680 env8530 == env8531) = true)

def env8532 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,90336,8329,21041,807680,4735912,4735572,605034,529048,4796991,524288,602954,2695635,90943]

theorem envBound8532 : H12AffineFastState.Bounded env8532 := by
  intro p hp
  have h : env8532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8531_8532 : H12AffineEnvironment.transform 23 90336 env8531 = env8532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8531 == env8532) = true)

def env8533 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5005,90336,8329,21041,278624,4214984,4215092,75786,504,4268383,4960,73770,2175667,90943]

theorem envBound8533 : H12AffineFastState.Bounded env8533 := by
  intro p hp
  have h : env8533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8532_8533 : H12AffineEnvironment.transform 18 4960 env8532 = env8533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8532 == env8533) = true)

theorem identity8533 : scanCanonicalize (H12AffineFastState.compose env8533 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8533 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8534 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,2097152,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4765,73770,2175667,90818]

theorem envBound8534 : H12AffineFastState.Bounded env8534 := by
  intro p hp
  have h : env8534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8533_8534 : H12AffineEnvironment.transform 7 253 env8533 = env8534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8533 == env8534) = true)

def env8535 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,64,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4765,73770,78579,90818]

theorem envBound8535 : H12AffineFastState.Bounded env8535 := by
  intro p hp
  have h : env8535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8534_8535 : H12AffineEnvironment.transform 20 64 env8534 = env8535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8534 == env8535) = true)

theorem identity8535 : scanCanonicalize (H12AffineFastState.compose env8535 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 77920) := by decide +kernel

theorem selectedBound8535 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8536 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,77920,4765,8200,64,4194304,4720,90336,8329,21041,94208,4214984,4214985,75786,5,4268194,4765,73770,78579,90818]

theorem envBound8536 : H12AffineFastState.Bounded env8536 := by
  intro p hp
  have h : env8536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8535_8536 : H12AffineEnvironment.transform 17 77920 env8535 = env8536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77920 env8535 == env8536) = true)

def env8537 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,77920,4765,8200,64,16960,4720,90336,8329,21041,94208,4744,4745,75786,5,90850,4765,73770,78579,90818]

theorem envBound8537 : H12AffineFastState.Bounded env8537 := by
  intro p hp
  have h : env8537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8536_8537 : H12AffineEnvironment.transform 21 16960 env8536 = env8537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8536 == env8537) = true)

def env8538 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,77920,4765,8200,64,112,4720,74448,8329,4097,78384,4744,4745,75786,5,73938,4765,73770,78579,73970]

theorem envBound8538 : H12AffineFastState.Bounded env8538 := by
  intro p hp
  have h : env8538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8537_8538 : H12AffineEnvironment.transform 13 560 env8537 = env8538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8537 == env8538) = true)

theorem identity8538 : scanCanonicalize (H12AffineFastState.compose env8538 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12875) := by decide +kernel

theorem selectedBound8538 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8539 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,12875,4096,555,4765,8200,64,112,4720,4251,8329,4097,123,4744,4745,6721,5,4761,4765,4705,184,4793]

theorem envBound8539 : H12AffineFastState.Bounded env8539 := by
  intro p hp
  have h : env8539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8538_8539 : H12AffineEnvironment.transform 15 12875 env8538 = env8539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12875 env8538 == env8539) = true)

theorem identity8539 : scanCanonicalize (H12AffineFastState.compose env8539 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8539 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env8540 : List Nat := [2,4,8,16,32,64,128,253,512,253,523,4096,8192,560,8200,12875,4096,555,4765,8200,64,112,4720,4251,8329,4097,123,4744,4745,4170,5,4761,4765,4705,184,4793]

theorem envBound8540 : H12AffineFastState.Bounded env8540 := by
  intro p hp
  have h : env8540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8539_8540 : H12AffineEnvironment.transform 10 523 env8539 = env8540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8539 == env8540) = true)

theorem identity8540 : scanCanonicalize (H12AffineFastState.compose env8540 (packedSelected [0,4,7,9,14,17,21] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8540 : packedSelected [0,4,7,9,14,17,21] rootPS < 2^1333 := by decide +kernel

def env8541 : List Nat := [2,4,8,16,32,64,120,5,512,5,523,4096,8192,560,8200,12875,4096,555,4709,8200,64,112,4720,4195,8305,4097,123,4720,4721,4170,5,4705,4709,4705,64,4673]

theorem envBound8541 : H12AffineFastState.Bounded env8541 := by
  intro p hp
  have h : env8541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8540_8541 : H12AffineEnvironment.transform 6 120 env8540 = env8541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8540 == env8541) = true)

theorem identity8541 : scanCanonicalize (H12AffineFastState.compose env8541 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8541 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8542 : List Nat := [2,4,8,16,32,64,120,5,512,5,523,64,8192,560,8200,8715,64,555,549,8200,64,112,560,35,8305,65,123,560,561,10,5,545,549,545,64,513]

theorem envBound8542 : H12AffineFastState.Bounded env8542 := by
  intro p hp
  have h : env8542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8541_8542 : H12AffineEnvironment.transform 11 64 env8541 = env8542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8541 == env8542) = true)

theorem identity8542 : scanCanonicalize (H12AffineFastState.compose env8542 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8542 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8543 : List Nat := [2,4,8,1,32,64,105,5,512,5,523,64,8192,545,8200,8715,64,555,549,8200,64,97,545,35,8288,65,106,545,544,10,5,545,549,545,64,513]

theorem envBound8543 : H12AffineFastState.Bounded env8543 := by
  intro p hp
  have h : env8543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8542_8543 : H12AffineEnvironment.transform 3 1 env8542 = env8543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8542 == env8543) = true)

theorem identity8543 : scanCanonicalize (H12AffineFastState.compose env8543 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 617) := by decide +kernel

theorem selectedBound8543 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env8544 : List Nat := [2,4,8,1,32,64,105,5,512,5,523,64,617,545,609,98,64,555,549,609,64,97,545,35,521,65,106,545,544,10,5,545,549,545,64,513]

theorem envBound8544 : H12AffineFastState.Bounded env8544 := by
  intro p hp
  have h : env8544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8543_8544 : H12AffineEnvironment.transform 12 617 env8543 = env8544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 617 env8543 == env8544) = true)

theorem identity8544 : scanCanonicalize (H12AffineFastState.compose env8544 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8544 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8545 : List Nat := [2,4,8,1,32,64,105,5,33,5,42,64,72,0,64,98,64,10,4,64,64,97,0,35,40,65,106,0,1,10,5,0,4,0,64,32]

theorem envBound8545 : H12AffineFastState.Bounded env8545 := by
  intro p hp
  have h : env8545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8544_8545 : H12AffineEnvironment.transform 8 33 env8544 = env8545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8544 == env8545) = true)

theorem identity8545 : scanCanonicalize (H12AffineFastState.compose env8545 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8545 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8546 : List Nat := [2,4,8,1,10,64,67,5,11,5,0,64,72,0,64,72,64,10,4,64,64,75,0,9,2,65,64,0,1,10,5,0,4,0,64,10]

theorem envBound8546 : H12AffineFastState.Bounded env8546 := by
  intro p hp
  have h : env8546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8545_8546 : H12AffineEnvironment.transform 4 10 env8545 = env8546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8545 == env8546) = true)

theorem identity8546 : scanCanonicalize (H12AffineFastState.compose env8546 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8546 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8547 : List Nat := [2,0,8,1,10,64,67,1,11,1,0,64,72,0,64,72,64,10,0,64,64,75,0,9,2,65,64,0,1,10,1,0,0,0,64,10]

theorem envBound8547 : H12AffineFastState.Bounded env8547 := by
  intro p hp
  have h : env8547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8546_8547 : H12AffineEnvironment.transform 1 0 env8546 = env8547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8546 == env8547) = true)

theorem identity8547 : scanCanonicalize (H12AffineFastState.compose env8547 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8547 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8548 : List Nat := [2,0,2,1,0,64,67,1,1,1,0,64,66,0,64,66,64,0,0,64,64,65,0,3,2,65,64,0,1,0,1,0,0,0,64,0]

theorem envBound8548 : H12AffineFastState.Bounded env8548 := by
  intro p hp
  have h : env8548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8547_8548 : H12AffineEnvironment.transform 2 2 env8547 = env8548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8547 == env8548) = true)

def env8549 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,77920,4765,8200,64,113,4720,74449,8329,4096,78385,4744,4745,75786,5,73939,4765,73770,78579,73971]

theorem envBound8549 : H12AffineFastState.Bounded env8549 := by
  intro p hp
  have h : env8549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8537_8549 : H12AffineEnvironment.transform 13 561 env8537 = env8549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8537 == env8549) = true)

theorem identity8549 : scanCanonicalize (H12AffineFastState.compose env8549 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12979) := by decide +kernel

theorem selectedBound8549 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8550 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,12979,4096,723,4765,8200,64,113,4720,4194,8329,4096,130,4744,4745,6841,5,4704,4765,4761,64,4672]

theorem envBound8550 : H12AffineFastState.Bounded env8550 := by
  intro p hp
  have h : env8550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8549_8550 : H12AffineEnvironment.transform 15 12979 env8549 = env8550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12979 env8549 == env8550) = true)

theorem identity8550 : scanCanonicalize (H12AffineFastState.compose env8550 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8550 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8551 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,184,8192,561,8200,8715,184,723,549,8200,64,113,712,218,8329,184,130,560,561,2561,5,728,549,545,64,760]

theorem envBound8551 : H12AffineFastState.Bounded env8551 := by
  intro p hp
  have h : env8551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8550_8551 : H12AffineEnvironment.transform 11 184 env8550 = env8551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8550 == env8551) = true)

theorem identity8551 : scanCanonicalize (H12AffineFastState.compose env8551 (packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8551 : packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8552 : List Nat := [2,4,8,16,32,64,128,253,136,253,2048,184,8192,185,8200,8323,184,91,173,8200,64,113,64,218,8329,184,130,184,185,2185,5,80,173,169,64,112]

theorem envBound8552 : H12AffineFastState.Bounded env8552 := by
  intro p hp
  have h : env8552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8551_8552 : H12AffineEnvironment.transform 8 136 env8551 = env8552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8551 == env8552) = true)

theorem identity8552 : scanCanonicalize (H12AffineFastState.compose env8552 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound8552 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8553 : List Nat := [2,4,8,16,32,64,128,253,136,253,122,184,8192,185,8200,8323,184,91,173,8200,64,113,64,218,8329,184,130,184,185,243,5,80,173,169,64,112]

theorem envBound8553 : H12AffineFastState.Bounded env8553 := by
  intro p hp
  have h : env8553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8552_8553 : H12AffineEnvironment.transform 10 122 env8552 = env8553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env8552 == env8553) = true)

theorem identity8553 : scanCanonicalize (H12AffineFastState.compose env8553 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8553 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8554 : List Nat := [2,4,8,16,32,64,128,253,136,253,122,184,98,185,106,225,184,91,173,106,64,113,64,218,235,184,130,184,185,243,5,80,173,169,64,112]

theorem envBound8554 : H12AffineFastState.Bounded env8554 := by
  intro p hp
  have h : env8554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8553_8554 : H12AffineEnvironment.transform 12 98 env8553 = env8554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8553 == env8554) = true)

theorem identity8554 : scanCanonicalize (H12AffineFastState.compose env8554 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound8554 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env8555 : List Nat := [2,4,8,16,32,64,114,15,122,15,122,74,98,75,106,19,74,91,95,106,64,113,64,40,25,74,112,74,75,1,5,80,95,91,64,112]

theorem envBound8555 : H12AffineFastState.Bounded env8555 := by
  intro p hp
  have h : env8555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8554_8555 : H12AffineEnvironment.transform 6 114 env8554 = env8555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env8554 == env8555) = true)

theorem identity8555 : scanCanonicalize (H12AffineFastState.compose env8555 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8555 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8556 : List Nat := [2,4,8,10,32,64,104,15,96,15,96,74,98,75,106,9,74,65,69,106,64,107,64,40,3,74,106,74,75,1,5,74,69,65,64,106]

theorem envBound8556 : H12AffineFastState.Bounded env8556 := by
  intro p hp
  have h : env8556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8555_8556 : H12AffineEnvironment.transform 3 10 env8555 = env8556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8555 == env8556) = true)

theorem identity8556 : scanCanonicalize (H12AffineFastState.compose env8556 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8557 : List Nat := [2,4,8,10,11,64,67,15,75,15,75,74,73,75,65,9,74,65,69,65,64,64,64,3,3,74,65,74,75,1,5,74,69,65,64,65]

theorem envBound8557 : H12AffineFastState.Bounded env8557 := by
  intro p hp
  have h : env8557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8556_8557 : H12AffineEnvironment.transform 4 11 env8556 = env8557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8556 == env8557) = true)

theorem identity8557 : scanCanonicalize (H12AffineFastState.compose env8557 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8558 : List Nat := [2,4,3,1,0,64,67,4,64,4,64,65,66,64,65,2,65,65,69,65,64,64,64,3,3,65,65,65,64,1,5,65,69,65,64,65]

theorem envBound8558 : H12AffineFastState.Bounded env8558 := by
  intro p hp
  have h : env8558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8557_8558 : H12AffineEnvironment.transform 2 3 env8557 = env8558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8557 == env8558) = true)

theorem identity8558 : scanCanonicalize (H12AffineFastState.compose env8558 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8559 : List Nat := [2,0,3,1,0,64,67,0,64,0,64,65,66,64,65,2,65,65,65,65,64,64,64,3,3,65,65,65,64,1,1,65,65,65,64,65]

theorem envBound8559 : H12AffineFastState.Bounded env8559 := by
  intro p hp
  have h : env8559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8558_8559 : H12AffineEnvironment.transform 1 0 env8558 = env8559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8558 == env8559) = true)

theorem identity8559 : scanCanonicalize (H12AffineFastState.compose env8559 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8559 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8560 : List Nat := [2,0,3,1,0,0,3,0,0,0,0,1,2,0,1,2,1,1,1,1,0,0,0,3,3,1,1,1,0,1,1,1,1,1,0,1]

theorem envBound8560 : H12AffineFastState.Bounded env8560 := by
  intro p hp
  have h : env8560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8559_8560 : H12AffineEnvironment.transform 5 0 env8559 = env8560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8559 == env8560) = true)

def env8561 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,77920,4765,8200,64,16961,4720,90336,8329,21041,94208,4745,4744,75786,5,90851,4765,73770,78579,90818]

theorem envBound8561 : H12AffineFastState.Bounded env8561 := by
  intro p hp
  have h : env8561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8536_8561 : H12AffineEnvironment.transform 21 16961 env8536 = env8561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8536 == env8561) = true)

def env8562 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8200,65536,4096,77920,4765,8200,64,113,4720,74448,8329,4097,78384,4745,4744,75786,5,73939,4765,73770,78579,73970]

theorem envBound8562 : H12AffineFastState.Bounded env8562 := by
  intro p hp
  have h : env8562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8561_8562 : H12AffineEnvironment.transform 13 560 env8561 = env8562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8561 == env8562) = true)

theorem identity8562 : scanCanonicalize (H12AffineFastState.compose env8562 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8562 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8563 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,184,8192,560,8200,65536,184,73944,549,8200,64,113,712,74448,8329,185,74376,561,560,75786,5,73939,549,73770,74315,73970]

theorem envBound8563 : H12AffineFastState.Bounded env8563 := by
  intro p hp
  have h : env8563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8562_8563 : H12AffineEnvironment.transform 11 184 env8562 = env8563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8562 == env8563) = true)

theorem identity8563 : scanCanonicalize (H12AffineFastState.compose env8563 (packedSelected [13,14,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8563 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env8564 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,16,8192,560,8200,65536,16,73840,549,8200,64,113,608,74360,8225,17,74272,561,560,75786,5,73851,549,73770,74315,73818]

theorem envBound8564 : H12AffineFastState.Bounded env8564 := by
  intro p hp
  have h : env8564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8563_8564 : H12AffineEnvironment.transform 6 40 env8563 = env8564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8563 == env8564) = true)

theorem identity8564 : scanCanonicalize (H12AffineFastState.compose env8564 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8564 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8565 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,16,8192,560,8200,8715,16,635,549,8200,64,113,608,115,8225,17,43,561,560,2561,5,624,549,545,64,593]

theorem envBound8565 : H12AffineFastState.Bounded env8565 := by
  intro p hp
  have h : env8565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8564_8565 : H12AffineEnvironment.transform 15 8715 env8564 = env8565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8564 == env8565) = true)

def env8566 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8200,65536,4096,77920,4765,8200,64,112,4720,74449,8329,4096,78385,4745,4744,75786,5,73938,4765,73770,78579,73971]

theorem envBound8566 : H12AffineFastState.Bounded env8566 := by
  intro p hp
  have h : env8566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8561_8566 : H12AffineEnvironment.transform 13 561 env8561 = env8566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8561 == env8566) = true)

theorem identity8566 : scanCanonicalize (H12AffineFastState.compose env8566 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8566 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8567 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,561,8200,65536,64,73760,733,8200,64,112,560,74449,8329,64,74353,713,712,75786,5,73938,733,73770,74419,73971]

theorem envBound8567 : H12AffineFastState.Bounded env8567 := by
  intro p hp
  have h : env8567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8566_8567 : H12AffineEnvironment.transform 11 64 env8566 = env8567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8566 == env8567) = true)

theorem identity8567 : scanCanonicalize (H12AffineFastState.compose env8567 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound8567 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env8568 : List Nat := [2,4,8,16,32,64,128,253,512,253,674,64,8192,561,8200,65536,64,73760,733,8200,64,112,560,74449,8329,64,74353,713,712,74408,5,73938,733,73770,74419,73971]

theorem envBound8568 : H12AffineFastState.Bounded env8568 := by
  intro p hp
  have h : env8568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8567_8568 : H12AffineEnvironment.transform 10 674 env8567 = env8568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env8567 == env8568) = true)

theorem identity8568 : scanCanonicalize (H12AffineFastState.compose env8568 (packedSelected [1,3,4,9,12,14,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8568 : packedSelected [1,3,4,9,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env8569 : List Nat := [2,4,8,16,32,64,128,253,512,253,674,64,8192,561,8200,8715,64,555,733,8200,64,112,560,218,8329,64,122,713,712,163,5,729,733,545,184,760]

theorem envBound8569 : H12AffineFastState.Bounded env8569 := by
  intro p hp
  have h : env8569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8568_8569 : H12AffineEnvironment.transform 15 8715 env8568 = env8569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8568 == env8569) = true)

def env8570 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,262144,4765,8200,65,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4765,73770,78578,90818]

theorem envBound8570 : H12AffineFastState.Bounded env8570 := by
  intro p hp
  have h : env8570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8534_8570 : H12AffineEnvironment.transform 20 65 env8534 = env8570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8534 == env8570) = true)

theorem identity8570 : scanCanonicalize (H12AffineFastState.compose env8570 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 74240) := by decide +kernel

theorem selectedBound8570 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8571 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8200,65536,4096,74240,4765,8200,65,4194304,4720,90336,8329,21041,90720,4214984,4214985,75786,5,4268194,4765,73770,78578,90818]

theorem envBound8571 : H12AffineFastState.Bounded env8571 := by
  intro p hp
  have h : env8571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8570_8571 : H12AffineEnvironment.transform 17 74240 env8570 = env8571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74240 env8570 == env8571) = true)

def env8572 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8200,65536,4096,74240,4645,8200,65,4194304,4720,90200,8241,21041,90720,4214896,4214897,75786,5,4268058,4645,73770,78410,90746]

theorem envBound8572 : H12AffineFastState.Bounded env8572 := by
  intro p hp
  have h : env8572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8571_8572 : H12AffineEnvironment.transform 6 56 env8571 = env8572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8571 == env8572) = true)

theorem identity8572 : scanCanonicalize (H12AffineFastState.compose env8572 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 608) := by decide +kernel

theorem selectedBound8572 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8573 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,608,8200,65536,4096,74240,4645,8200,65,4194304,4720,74296,8241,4177,73728,4198928,4198929,75786,5,4268058,4645,73770,78410,73754]

theorem envBound8573 : H12AffineFastState.Bounded env8573 := by
  intro p hp
  have h : env8573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8572_8573 : H12AffineEnvironment.transform 13 608 env8572 = env8573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 608 env8572 == env8573) = true)

theorem identity8573 : scanCanonicalize (H12AffineFastState.compose env8573 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 74282) := by decide +kernel

theorem selectedBound8573 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env8574 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,608,8200,65536,4096,74240,4645,8200,65,74282,4720,74296,8241,4177,73728,77882,77883,75786,5,560,4645,73770,78410,73754]

theorem envBound8574 : H12AffineFastState.Bounded env8574 := by
  intro p hp
  have h : env8574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8573_8574 : H12AffineEnvironment.transform 21 74282 env8573 = env8574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74282 env8573 == env8574) = true)

theorem identity8574 : scanCanonicalize (H12AffineFastState.compose env8574 (packedSelected [1,8,19] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8574 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env8575 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,4096,8192,608,8200,65536,4096,74240,4645,8200,65,74282,4704,74280,8225,4161,73728,77866,77867,75786,5,544,4645,73770,78410,73738]

theorem envBound8575 : H12AffineFastState.Bounded env8575 := by
  intro p hp
  have h : env8575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8574_8575 : H12AffineEnvironment.transform 3 0 env8574 = env8575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8574 == env8575) = true)

theorem identity8575 : scanCanonicalize (H12AffineFastState.compose env8575 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8575 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8576 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,4096,8192,608,8200,8714,4096,10,4645,8200,65,32,4704,34,8225,4161,522,4640,4641,2560,5,544,4645,544,4160,512]

theorem envBound8576 : H12AffineFastState.Bounded env8576 := by
  intro p hp
  have h : env8576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8575_8576 : H12AffineEnvironment.transform 15 8714 env8575 = env8576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8575 == env8576) = true)

theorem identity8576 : scanCanonicalize (H12AffineFastState.compose env8576 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8576 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8577 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,2090,8192,608,8200,8714,2090,10,2575,8200,65,32,2634,34,8225,2155,522,2570,2571,2560,5,544,2575,544,2154,512]

theorem envBound8577 : H12AffineFastState.Bounded env8577 := by
  intro p hp
  have h : env8577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8576_8577 : H12AffineEnvironment.transform 11 2090 env8576 = env8577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env8576 == env8577) = true)

theorem identity8577 : scanCanonicalize (H12AffineFastState.compose env8577 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8577 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env8578 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,2090,98,608,106,616,2090,10,2575,106,65,32,2634,34,67,2155,522,2570,2571,2560,5,544,2575,544,2154,512]

theorem envBound8578 : H12AffineFastState.Bounded env8578 := by
  intro p hp
  have h : env8578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8577_8578 : H12AffineEnvironment.transform 12 98 env8577 = env8578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8577 == env8578) = true)

theorem identity8578 : scanCanonicalize (H12AffineFastState.compose env8578 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8578 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env8579 : List Nat := [2,4,8,0,32,64,40,69,0,69,2048,2090,98,96,106,104,2090,10,2063,106,65,32,2122,34,67,2155,10,2058,2059,2048,5,32,2063,32,2154,0]

theorem envBound8579 : H12AffineFastState.Bounded env8579 := by
  intro p hp
  have h : env8579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8578_8579 : H12AffineEnvironment.transform 8 0 env8578 = env8579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8578 == env8579) = true)

theorem identity8579 : scanCanonicalize (H12AffineFastState.compose env8579 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound8579 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8580 : List Nat := [2,4,8,0,32,64,40,69,0,69,96,74,98,96,106,104,74,10,111,106,65,32,42,34,67,11,10,106,107,96,5,32,111,32,10,0]

theorem envBound8580 : H12AffineFastState.Bounded env8580 := by
  intro p hp
  have h : env8580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8579_8580 : H12AffineEnvironment.transform 10 96 env8579 = env8580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env8579 == env8580) = true)

theorem identity8580 : scanCanonicalize (H12AffineFastState.compose env8580 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8580 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8581 : List Nat := [2,4,8,0,10,64,2,69,0,69,74,74,72,74,64,66,74,10,69,64,65,10,0,8,67,11,10,64,65,74,5,10,69,10,10,0]

theorem envBound8581 : H12AffineFastState.Bounded env8581 := by
  intro p hp
  have h : env8581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8580_8581 : H12AffineEnvironment.transform 4 10 env8580 = env8581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8580 == env8581) = true)

theorem identity8581 : scanCanonicalize (H12AffineFastState.compose env8581 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8581 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8582 : List Nat := [2,4,3,0,1,64,2,69,0,69,65,65,67,65,64,66,65,1,69,64,65,1,0,3,67,0,1,64,65,65,5,1,69,1,1,0]

theorem envBound8582 : H12AffineFastState.Bounded env8582 := by
  intro p hp
  have h : env8582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8581_8582 : H12AffineEnvironment.transform 2 3 env8581 = env8582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8581 == env8582) = true)

def env8583 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,74240,4644,8200,65,4194304,4720,90201,8240,21041,90720,4214897,4214896,75786,5,4268059,4644,73770,78411,90747]

theorem envBound8583 : H12AffineFastState.Bounded env8583 := by
  intro p hp
  have h : env8583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8571_8583 : H12AffineEnvironment.transform 6 57 env8571 = env8583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8571 == env8583) = true)

theorem identity8583 : scanCanonicalize (H12AffineFastState.compose env8583 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 74283) := by decide +kernel

theorem selectedBound8583 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8584 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,65536,4096,74240,4644,8200,65,74283,4720,90201,8240,21041,90720,94810,94811,75786,5,560,4644,73770,78411,90747]

theorem envBound8584 : H12AffineFastState.Bounded env8584 := by
  intro p hp
  have h : env8584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8583_8584 : H12AffineEnvironment.transform 21 74283 env8583 = env8584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74283 env8583 == env8584) = true)

theorem identity8584 : scanCanonicalize (H12AffineFastState.compose env8584 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8730) := by decide +kernel

theorem selectedBound8584 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env8585 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8200,8730,4096,26,4644,8200,65,49,4720,16963,8240,21041,16506,20544,20545,2576,5,560,4644,560,4177,16481]

theorem envBound8585 : H12AffineFastState.Bounded env8585 := by
  intro p hp
  have h : env8585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8584_8585 : H12AffineEnvironment.transform 15 8730 env8584 = env8585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8730 env8584 == env8585) = true)

theorem identity8585 : scanCanonicalize (H12AffineFastState.compose env8585 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8585 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8586 : List Nat := [2,4,8,16,32,64,57,68,96,68,2048,4096,8192,16384,8200,8314,4096,26,4164,8200,65,49,4112,16419,8240,20561,16506,20544,20545,2160,5,80,4164,80,4177,16481]

theorem envBound8586 : H12AffineFastState.Bounded env8586 := by
  intro p hp
  have h : env8586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8585_8586 : H12AffineEnvironment.transform 8 96 env8585 = env8586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8585 == env8586) = true)

theorem identity8586 : scanCanonicalize (H12AffineFastState.compose env8586 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8586 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8587 : List Nat := [2,4,8,16,32,64,57,68,96,68,2048,2155,8192,16384,8200,8314,2155,26,2095,8200,65,49,2171,16419,8240,18490,16506,18475,18474,2160,5,80,2095,80,2106,16481]

theorem envBound8587 : H12AffineFastState.Bounded env8587 := by
  intro p hp
  have h : env8587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8586_8587 : H12AffineEnvironment.transform 11 2155 env8586 = env8587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8586 == env8587) = true)

theorem identity8587 : scanCanonicalize (H12AffineFastState.compose env8587 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound8587 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env8588 : List Nat := [2,4,8,16,32,64,57,68,96,68,2048,2155,8192,0,8200,8314,2155,26,2095,8200,65,49,2171,35,8240,2106,122,2091,2090,2160,5,80,2095,80,2106,97]

theorem envBound8588 : H12AffineFastState.Bounded env8588 := by
  intro p hp
  have h : env8588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8587_8588 : H12AffineEnvironment.transform 13 0 env8587 = env8588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env8587 == env8588) = true)

theorem identity8588 : scanCanonicalize (H12AffineFastState.compose env8588 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8588 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8589 : List Nat := [2,4,8,16,32,1,57,5,33,5,2048,2090,8192,0,8200,8251,2090,26,2095,8200,0,49,2106,35,8240,2106,59,2091,2090,2097,5,17,2095,17,2106,32]

theorem envBound8589 : H12AffineFastState.Bounded env8589 := by
  intro p hp
  have h : env8589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8588_8589 : H12AffineEnvironment.transform 5 1 env8588 = env8589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8588 == env8589) = true)

theorem identity8589 : scanCanonicalize (H12AffineFastState.compose env8589 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound8589 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env8590 : List Nat := [2,4,8,16,32,1,57,5,33,5,16,58,8192,0,8200,8251,58,26,63,8200,0,49,42,35,8240,42,59,59,58,33,5,17,63,17,42,32]

theorem envBound8590 : H12AffineFastState.Bounded env8590 := by
  intro p hp
  have h : env8590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8589_8590 : H12AffineEnvironment.transform 10 16 env8589 = env8590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env8589 == env8590) = true)

theorem identity8590 : scanCanonicalize (H12AffineFastState.compose env8590 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8590 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8591 : List Nat := [2,4,8,16,1,1,24,5,0,5,16,27,8192,0,8200,8218,27,26,30,8200,0,16,11,2,8209,11,26,26,27,0,5,17,30,17,11,1]

theorem envBound8591 : H12AffineFastState.Bounded env8591 := by
  intro p hp
  have h : env8591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8590_8591 : H12AffineEnvironment.transform 4 1 env8590 = env8591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8590 == env8591) = true)

theorem identity8591 : scanCanonicalize (H12AffineFastState.compose env8591 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8591 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8592 : List Nat := [2,4,2,16,1,1,18,5,0,5,16,17,8192,0,8194,8208,17,16,20,8194,0,16,1,2,8209,1,16,16,17,0,5,17,20,17,1,1]

theorem envBound8592 : H12AffineFastState.Bounded env8592 := by
  intro p hp
  have h : env8592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8591_8592 : H12AffineEnvironment.transform 2 2 env8591 = env8592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8591 == env8592) = true)

theorem identity8592 : scanCanonicalize (H12AffineFastState.compose env8592 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 23) := by decide +kernel

theorem selectedBound8592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8593 : List Nat := [2,4,2,16,1,1,18,5,0,5,16,17,23,0,21,7,17,16,20,21,0,16,1,2,6,1,16,16,17,0,5,17,20,17,1,1]

theorem envBound8593 : H12AffineFastState.Bounded env8593 := by
  intro p hp
  have h : env8593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8592_8593 : H12AffineEnvironment.transform 12 23 env8592 = env8593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 23 env8592 == env8593) = true)

theorem identity8593 : scanCanonicalize (H12AffineFastState.compose env8593 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8593 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8594 : List Nat := [2,1,2,16,1,1,18,0,0,0,16,17,18,0,16,2,17,16,17,16,0,16,1,2,3,1,16,16,17,0,0,17,17,17,1,1]

theorem envBound8594 : H12AffineFastState.Bounded env8594 := by
  intro p hp
  have h : env8594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8593_8594 : H12AffineEnvironment.transform 1 1 env8593 = env8594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8593 == env8594) = true)

theorem identity8594 : scanCanonicalize (H12AffineFastState.compose env8594 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8595 : List Nat := [2,1,2,1,1,1,3,0,0,0,1,0,3,0,1,2,0,1,0,1,0,1,1,2,3,1,1,1,0,0,0,0,0,0,1,1]

theorem envBound8595 : H12AffineFastState.Bounded env8595 := by
  intro p hp
  have h : env8595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8594_8595 : H12AffineEnvironment.transform 3 1 env8594 = env8595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8594 == env8595) = true)

def env8596 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4961,8693,2097152,4194304,5004,90336,8329,21041,278625,4214985,4215093,75787,505,4268382,4961,73771,2175666,90943]

theorem envBound8596 : H12AffineFastState.Bounded env8596 := by
  intro p hp
  have h : env8596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8532_8596 : H12AffineEnvironment.transform 18 4961 env8532 = env8596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8532 == env8596) = true)

theorem identity8596 : scanCanonicalize (H12AffineFastState.compose env8596 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8596 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8597 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,2097152,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4961,16617,2118256,1021]

theorem envBound8597 : H12AffineFastState.Bounded env8597 := by
  intro p hp
  have h : env8597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8596_8597 : H12AffineEnvironment.transform 15 24770 env8596 = env8597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8596 == env8597) = true)

def env8598 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,64,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4961,16617,21040,1021]

theorem envBound8598 : H12AffineFastState.Bounded env8598 := by
  intro p hp
  have h : env8598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8597_8598 : H12AffineEnvironment.transform 20 64 env8597 = env8598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8597 == env8598) = true)

theorem identity8598 : scanCanonicalize (H12AffineFastState.compose env8598 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282926) := by decide +kernel

theorem selectedBound8598 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8599 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,64,282926,5004,34,8329,21041,278625,262631,262171,18633,505,266418,4961,16617,21040,1021]

theorem envBound8599 : H12AffineFastState.Bounded env8599 := by
  intro p hp
  have h : env8599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8598_8599 : H12AffineEnvironment.transform 21 282926 env8598 = env8599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282926 env8598 == env8599) = true)

def env8600 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8693,8946,4605,262144,4961,8693,64,267038,5004,34,8329,4097,262737,262631,262171,2809,505,266418,4961,729,4096,1021]

theorem envBound8600 : H12AffineFastState.Bounded env8600 := by
  intro p hp
  have h : env8600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8599_8600 : H12AffineEnvironment.transform 13 560 env8599 = env8600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8599 == env8600) = true)

def env8601 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8234,4605,262144,4537,8693,64,266694,4436,34,8329,4097,262281,262631,262171,2081,505,266418,4537,1,4096,293]

theorem envBound8601 : H12AffineFastState.Bounded env8601 := by
  intro p hp
  have h : env8601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8600_8601 : H12AffineEnvironment.transform 8 216 env8600 = env8601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8600 == env8601) = true)

theorem identity8601 : scanCanonicalize (H12AffineFastState.compose env8601 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8601 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8602 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,232,8353,8234,4265,262144,4333,8353,64,266386,4096,34,8329,4097,262281,262323,262171,2081,173,266418,4333,1,4096,113]

theorem envBound8602 : H12AffineFastState.Bounded env8602 := by
  intro p hp
  have h : env8602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8601_8602 : H12AffineEnvironment.transform 7 84 env8601 = env8602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8601 == env8602) = true)

theorem identity8602 : scanCanonicalize (H12AffineFastState.compose env8602 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8602 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8603 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,232,8353,8234,4265,90,4333,8353,64,4296,4096,34,8329,4097,211,233,65,2081,173,4328,4333,1,4096,113]

theorem envBound8603 : H12AffineFastState.Bounded env8603 := by
  intro p hp
  have h : env8603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8602_8603 : H12AffineEnvironment.transform 17 90 env8602 = env8603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8602 == env8603) = true)

theorem identity8603 : scanCanonicalize (H12AffineFastState.compose env8603 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8603 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8604 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,2155,8192,232,8353,8234,2242,90,2182,8353,64,2211,2155,34,8329,2154,211,233,65,2081,173,2179,2182,1,2155,113]

theorem envBound8604 : H12AffineFastState.Bounded env8604 := by
  intro p hp
  have h : env8604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8603_8604 : H12AffineEnvironment.transform 11 2155 env8603 = env8604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8603 == env8604) = true)

theorem identity8604 : scanCanonicalize (H12AffineFastState.compose env8604 (packedSelected [1,3,5,8,10,14,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8604 : packedSelected [1,3,5,8,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env8605 : List Nat := [2,4,8,16,32,64,41,84,113,84,2048,2155,8192,65,8200,8234,2155,90,2095,8200,64,2058,2155,34,8224,2154,122,64,65,2081,4,2090,2095,1,2155,113]

theorem envBound8605 : H12AffineFastState.Bounded env8605 := by
  intro p hp
  have h : env8605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8604_8605 : H12AffineEnvironment.transform 6 41 env8604 = env8605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8604 == env8605) = true)

theorem identity8605 : scanCanonicalize (H12AffineFastState.compose env8605 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8605 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8606 : List Nat := [2,4,8,16,32,64,41,84,113,84,42,65,8192,65,8200,8234,65,90,5,8200,64,32,65,34,8224,64,122,64,65,11,4,0,5,1,65,113]

theorem envBound8606 : H12AffineFastState.Bounded env8606 := by
  intro p hp
  have h : env8606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8605_8606 : H12AffineEnvironment.transform 10 42 env8605 = env8606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8605 == env8606) = true)

theorem identity8606 : scanCanonicalize (H12AffineFastState.compose env8606 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8606 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8607 : List Nat := [2,4,8,16,16,64,25,84,65,84,26,65,8192,65,8200,8218,65,90,5,8200,64,16,65,18,8208,64,74,64,65,11,4,0,5,1,65,65]

theorem envBound8607 : H12AffineFastState.Bounded env8607 := by
  intro p hp
  have h : env8607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8606_8607 : H12AffineEnvironment.transform 4 16 env8606 = env8607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8606 == env8607) = true)

theorem identity8607 : scanCanonicalize (H12AffineFastState.compose env8607 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound8607 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8608 : List Nat := [2,4,8,16,16,64,25,84,65,84,26,65,73,65,65,83,65,90,5,65,64,16,65,18,89,64,74,64,65,11,4,0,5,1,65,65]

theorem envBound8608 : H12AffineFastState.Bounded env8608 := by
  intro p hp
  have h : env8608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8607_8608 : H12AffineEnvironment.transform 12 73 env8607 = env8608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env8607 == env8608) = true)

theorem identity8608 : scanCanonicalize (H12AffineFastState.compose env8608 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound8608 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8609 : List Nat := [2,4,8,16,16,27,25,15,26,15,26,26,18,26,26,8,26,1,5,26,27,16,26,18,2,27,17,27,26,11,4,0,5,1,26,26]

theorem envBound8609 : H12AffineFastState.Bounded env8609 := by
  intro p hp
  have h : env8609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8608_8609 : H12AffineEnvironment.transform 5 27 env8608 = env8609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env8608 == env8609) = true)

def env8610 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8235,4605,262144,4536,8693,64,266695,4437,34,8329,4097,262280,262631,262171,2080,505,266418,4536,0,4096,292]

theorem envBound8610 : H12AffineFastState.Bounded env8610 := by
  intro p hp
  have h : env8610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8600_8610 : H12AffineEnvironment.transform 8 217 env8600 = env8610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8600 == env8610) = true)

theorem identity8610 : scanCanonicalize (H12AffineFastState.compose env8610 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4122) := by decide +kernel

theorem selectedBound8610 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8611 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8235,4605,4122,4536,8693,64,477,4437,34,8329,4097,4242,4605,4097,2080,505,168,4536,0,4096,292]

theorem envBound8611 : H12AffineFastState.Bounded env8611 := by
  intro p hp
  have h : env8611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8610_8611 : H12AffineEnvironment.transform 17 4122 env8610 = env8611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4122 env8610 == env8611) = true)

theorem identity8611 : scanCanonicalize (H12AffineFastState.compose env8611 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound8611 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8612 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,232,8192,233,8693,8235,277,242,336,8693,64,477,445,34,8329,233,122,277,233,2080,505,168,336,0,232,292]

theorem envBound8612 : H12AffineFastState.Bounded env8612 := by
  intro p hp
  have h : env8612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8611_8612 : H12AffineEnvironment.transform 11 232 env8611 = env8612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env8611 == env8612) = true)

theorem identity8612 : scanCanonicalize (H12AffineFastState.compose env8612 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound8612 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env8613 : List Nat := [2,4,8,16,32,64,128,256,217,256,303,232,8192,233,8693,8235,277,242,336,8693,64,477,445,34,8329,233,122,277,233,271,505,168,336,0,232,292]

theorem envBound8613 : H12AffineFastState.Bounded env8613 := by
  intro p hp
  have h : env8613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8612_8613 : H12AffineEnvironment.transform 10 303 env8612 = env8613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env8612 == env8613) = true)

theorem identity8613 : scanCanonicalize (H12AffineFastState.compose env8613 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8613 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env8614 : List Nat := [2,4,8,16,32,64,120,256,33,256,303,16,8192,17,8461,8235,277,10,336,8461,64,293,325,34,8305,17,122,277,17,271,257,80,336,0,16,292]

theorem envBound8614 : H12AffineFastState.Bounded env8614 := by
  intro p hp
  have h : env8614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8613_8614 : H12AffineEnvironment.transform 6 120 env8613 = env8614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8613 == env8614) = true)

theorem identity8614 : scanCanonicalize (H12AffineFastState.compose env8614 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound8614 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env8615 : List Nat := [2,4,8,16,32,64,120,78,33,78,97,16,8192,17,8259,8235,91,10,30,8259,64,107,11,34,8305,17,122,91,17,65,79,80,30,0,16,106]

theorem envBound8615 : H12AffineFastState.Bounded env8615 := by
  intro p hp
  have h : env8615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8614_8615 : H12AffineEnvironment.transform 7 78 env8614 = env8615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env8614 == env8615) = true)

theorem identity8615 : scanCanonicalize (H12AffineFastState.compose env8615 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound8615 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8616 : List Nat := [2,4,8,16,32,64,120,78,33,78,97,16,105,17,42,66,91,10,30,42,64,107,11,34,24,17,122,91,17,65,79,80,30,0,16,106]

theorem envBound8616 : H12AffineFastState.Bounded env8616 := by
  intro p hp
  have h : env8616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8615_8616 : H12AffineEnvironment.transform 12 105 env8615 = env8616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env8615 == env8616) = true)

theorem identity8616 : scanCanonicalize (H12AffineFastState.compose env8616 (packedSelected [1,2,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8616 : packedSelected [1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env8617 : List Nat := [2,4,8,16,17,64,73,78,16,78,80,16,88,17,27,66,91,10,30,27,64,90,11,19,24,17,75,91,17,65,79,80,30,0,16,91]

theorem envBound8617 : H12AffineFastState.Bounded env8617 := by
  intro p hp
  have h : env8617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8616_8617 : H12AffineEnvironment.transform 4 17 env8616 = env8617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8616 == env8617) = true)

def env8618 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8693,8947,4605,262144,4961,8693,64,267039,5004,34,8329,4096,262736,262631,262171,2808,505,266418,4961,728,4097,1021]

theorem envBound8618 : H12AffineFastState.Bounded env8618 := by
  intro p hp
  have h : env8618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8599_8618 : H12AffineEnvironment.transform 13 561 env8599 = env8618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8599 == env8618) = true)

def env8619 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8235,4605,262144,4537,8693,64,266695,4436,34,8329,4096,262280,262631,262171,2080,505,266418,4537,0,4097,293]

theorem envBound8619 : H12AffineFastState.Bounded env8619 := by
  intro p hp
  have h : env8619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8618_8619 : H12AffineEnvironment.transform 8 216 env8618 = env8619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8618 == env8619) = true)

theorem identity8619 : scanCanonicalize (H12AffineFastState.compose env8619 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4122) := by decide +kernel

theorem selectedBound8619 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8620 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8235,4605,4122,4537,8693,64,477,4436,34,8329,4096,4242,4605,4097,2080,505,168,4537,0,4097,293]

theorem envBound8620 : H12AffineFastState.Bounded env8620 := by
  intro p hp
  have h : env8620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8619_8620 : H12AffineEnvironment.transform 17 4122 env8619 = env8620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4122 env8619 == env8620) = true)

theorem identity8620 : scanCanonicalize (H12AffineFastState.compose env8620 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound8620 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8621 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,445,8192,233,8693,8235,64,423,4,8693,64,477,233,34,8329,445,303,64,444,2080,505,168,4,0,444,293]

theorem envBound8621 : H12AffineFastState.Bounded env8621 := by
  intro p hp
  have h : env8621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8620_8621 : H12AffineEnvironment.transform 11 445 env8620 = env8621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env8620 == env8621) = true)

theorem identity8621 : scanCanonicalize (H12AffineFastState.compose env8621 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound8621 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8622 : List Nat := [2,4,8,16,32,64,128,256,216,256,211,445,8192,233,8693,8235,64,423,4,8693,64,477,233,34,8329,445,303,64,444,243,505,168,4,0,444,293]

theorem envBound8622 : H12AffineFastState.Bounded env8622 := by
  intro p hp
  have h : env8622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8621_8622 : H12AffineEnvironment.transform 10 211 env8621 = env8622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env8621 == env8622) = true)

theorem identity8622 : scanCanonicalize (H12AffineFastState.compose env8622 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8622 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env8623 : List Nat := [2,4,8,16,32,64,128,5,216,5,211,184,8192,233,8432,8235,64,162,4,8432,64,216,233,34,8329,184,42,64,185,243,252,168,4,0,185,32]

theorem envBound8623 : H12AffineFastState.Bounded env8623 := by
  intro p hp
  have h : env8623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8622_8623 : H12AffineEnvironment.transform 7 5 env8622 = env8623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8622 == env8623) = true)

theorem identity8623 : scanCanonicalize (H12AffineFastState.compose env8623 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound8623 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env8624 : List Nat := [2,4,8,16,32,64,128,5,216,5,211,184,35,233,211,8,64,162,4,211,64,216,233,34,170,184,42,64,185,243,252,168,4,0,185,32]

theorem envBound8624 : H12AffineFastState.Bounded env8624 := by
  intro p hp
  have h : env8624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8623_8624 : H12AffineEnvironment.transform 12 35 env8623 = env8624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env8623 == env8624) = true)

theorem identity8624 : scanCanonicalize (H12AffineFastState.compose env8624 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound8624 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env8625 : List Nat := [2,4,8,16,32,64,51,5,107,5,96,11,35,90,96,8,64,17,4,96,64,107,90,34,25,11,42,64,10,64,79,27,4,0,10,32]

theorem envBound8625 : H12AffineFastState.Bounded env8625 := by
  intro p hp
  have h : env8625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8624_8625 : H12AffineEnvironment.transform 6 51 env8624 = env8625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env8624 == env8625) = true)

theorem identity8625 : scanCanonicalize (H12AffineFastState.compose env8625 (packedSelected [0,1,3,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8625 : packedSelected [0,1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env8626 : List Nat := [2,4,3,16,32,64,51,5,96,5,96,0,35,81,96,3,64,17,4,96,64,96,81,34,18,0,33,64,1,64,68,16,4,0,1,32]

theorem envBound8626 : H12AffineFastState.Bounded env8626 := by
  intro p hp
  have h : env8626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8625_8626 : H12AffineEnvironment.transform 2 3 env8625 = env8626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8625 == env8626) = true)

theorem identity8626 : scanCanonicalize (H12AffineFastState.compose env8626 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound8626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8627 : List Nat := [2,4,3,16,32,49,51,5,17,5,17,0,35,32,17,3,49,17,4,17,49,17,32,34,18,0,33,49,1,49,53,16,4,0,1,32]

theorem envBound8627 : H12AffineFastState.Bounded env8627 := by
  intro p hp
  have h : env8627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8626_8627 : H12AffineEnvironment.transform 5 49 env8626 = env8627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env8626 == env8627) = true)

theorem identity8627 : scanCanonicalize (H12AffineFastState.compose env8627 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8627 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8628 : List Nat := [2,4,3,16,17,0,2,5,17,5,17,0,18,17,17,3,0,17,4,17,0,17,17,19,18,0,16,0,1,0,4,16,4,0,1,17]

theorem envBound8628 : H12AffineFastState.Bounded env8628 := by
  intro p hp
  have h : env8628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8627_8628 : H12AffineEnvironment.transform 4 17 env8627 = env8628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8627 == env8628) = true)

theorem identity8628 : scanCanonicalize (H12AffineFastState.compose env8628 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8629 : List Nat := [2,4,3,1,0,0,2,5,0,5,0,0,3,0,0,3,0,0,4,0,0,0,0,2,3,0,1,0,1,0,4,1,4,0,1,0]

theorem envBound8629 : H12AffineFastState.Bounded env8629 := by
  intro p hp
  have h : env8629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8628_8629 : H12AffineEnvironment.transform 3 1 env8628 = env8629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8628 == env8629) = true)

def leafEnv8629 : List Nat := [2,4,3,1,0,0,2,5,0,5,0,0,3,0,0,3,0,0,4,0,0,0,0,2,5,3,1,0,1,0,1,0,4,1,4,0,5,2,1,0,1,0,0]

def active8629 : List Nat := [0,1]

def tree8629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8629 : H12WitnessSearch.Good tree8629 := H12GlobalWitnessIndex.good

theorem leafIdentity8629 : H12AffineFastState.composeSystem env8629 rootObs = leafEnv8629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8629 rootObs == leafEnv8629) = true)

theorem terminalChecked8629 : H12PackedTerminal.terminalCheckFast leafEnv8629 active8629 tree8629 = true := by decide +kernel

def env8630 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8234,4605,262144,4536,8693,64,266694,4437,34,8329,4096,262281,262631,262171,2081,505,266418,4536,1,4097,292]

theorem envBound8630 : H12AffineFastState.Bounded env8630 := by
  intro p hp
  have h : env8630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8618_8630 : H12AffineEnvironment.transform 8 217 env8618 = env8630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8618 == env8630) = true)

theorem identity8630 : scanCanonicalize (H12AffineFastState.compose env8630 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8630 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8631 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,232,8353,8234,4265,262144,4332,8353,64,266386,4097,34,8329,4096,262281,262323,262171,2081,173,266418,4332,1,4097,112]

theorem envBound8631 : H12AffineFastState.Bounded env8631 := by
  intro p hp
  have h : env8631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8630_8631 : H12AffineEnvironment.transform 7 84 env8630 = env8631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8630 == env8631) = true)

theorem identity8631 : scanCanonicalize (H12AffineFastState.compose env8631 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8631 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8632 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,64,8192,232,8353,8234,233,262144,172,8353,64,262354,65,34,8329,64,262281,262323,262171,2081,173,262386,172,1,65,112]

theorem envBound8632 : H12AffineFastState.Bounded env8632 := by
  intro p hp
  have h : env8632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8631_8632 : H12AffineEnvironment.transform 11 64 env8631 = env8632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8631 == env8632) = true)

theorem identity8632 : scanCanonicalize (H12AffineFastState.compose env8632 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound8632 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8633 : List Nat := [2,4,8,16,32,64,128,84,217,84,130,64,8192,232,8353,8234,233,262144,172,8353,64,262354,65,34,8329,64,262281,262323,262171,163,173,262386,172,1,65,112]

theorem envBound8633 : H12AffineFastState.Bounded env8633 := by
  intro p hp
  have h : env8633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8632_8633 : H12AffineEnvironment.transform 10 130 env8632 = env8633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env8632 == env8633) = true)

theorem identity8633 : scanCanonicalize (H12AffineFastState.compose env8633 (packedSelected [1,2,3,4,5,8,9,10,11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8633 : packedSelected [1,2,3,4,5,8,9,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env8634 : List Nat := [2,4,8,16,32,64,128,84,217,84,130,64,98,232,195,72,233,262144,172,195,64,262354,65,34,235,64,262281,262323,262171,163,173,262386,172,1,65,112]

theorem envBound8634 : H12AffineFastState.Bounded env8634 := by
  intro p hp
  have h : env8634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8633_8634 : H12AffineEnvironment.transform 12 98 env8633 = env8634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8633 == env8634) = true)

theorem identity8634 : scanCanonicalize (H12AffineFastState.compose env8634 (packedSelected [4,7,10,11,12,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound8634 : packedSelected [4,7,10,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env8635 : List Nat := [2,4,8,16,32,64,128,84,217,84,130,64,98,232,195,72,233,26,172,195,64,200,65,34,235,64,147,169,1,163,173,232,172,1,65,112]

theorem envBound8635 : H12AffineFastState.Bounded env8635 := by
  intro p hp
  have h : env8635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8634_8635 : H12AffineEnvironment.transform 17 26 env8634 = env8635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env8634 == env8635) = true)

theorem identity8635 : scanCanonicalize (H12AffineFastState.compose env8635 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound8635 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8636 : List Nat := [2,4,8,16,32,64,104,84,49,84,106,64,98,0,43,72,1,26,68,43,64,32,65,34,3,64,123,65,1,75,69,0,68,1,65,112]

theorem envBound8636 : H12AffineFastState.Bounded env8636 := by
  intro p hp
  have h : env8636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8635_8636 : H12AffineEnvironment.transform 6 104 env8635 = env8636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env8635 == env8636) = true)

theorem identity8636 : scanCanonicalize (H12AffineFastState.compose env8636 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound8636 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8637 : List Nat := [2,4,8,16,32,42,2,62,49,62,0,42,8,0,43,34,1,26,46,43,42,32,43,34,3,42,17,43,1,33,47,0,46,1,43,26]

theorem envBound8637 : H12AffineFastState.Bounded env8637 := by
  intro p hp
  have h : env8637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8636_8637 : H12AffineEnvironment.transform 5 42 env8636 = env8637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env8636 == env8637) = true)

theorem identity8637 : scanCanonicalize (H12AffineFastState.compose env8637 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8637 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env8638 : List Nat := [2,4,8,16,16,26,2,14,1,14,0,26,8,0,27,18,1,26,30,27,26,16,27,18,3,26,17,27,1,17,31,0,30,1,27,26]

theorem envBound8638 : H12AffineFastState.Bounded env8638 := by
  intro p hp
  have h : env8638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8637_8638 : H12AffineEnvironment.transform 4 16 env8637 = env8638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8637 == env8638) = true)

theorem identity8638 : scanCanonicalize (H12AffineFastState.compose env8638 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8638 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8639 : List Nat := [2,4,8,11,11,1,2,14,1,14,0,1,8,0,0,9,1,1,5,0,1,11,0,9,3,1,10,0,1,10,4,0,5,1,0,1]

theorem envBound8639 : H12AffineFastState.Bounded env8639 := by
  intro p hp
  have h : env8639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8638_8639 : H12AffineEnvironment.transform 3 11 env8638 = env8639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8638 == env8639) = true)

theorem identity8639 : scanCanonicalize (H12AffineFastState.compose env8639 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8639 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8640 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,2,0,0,3,1,1,5,0,1,1,0,3,3,1,0,0,1,0,4,0,5,1,0,1]

theorem envBound8640 : H12AffineFastState.Bounded env8640 := by
  intro p hp
  have h : env8640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8639_8640 : H12AffineEnvironment.transform 2 2 env8639 = env8640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8639 == env8640) = true)

def leafEnv8640 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,2,0,0,3,1,1,5,0,1,1,0,3,5,3,1,1,0,0,1,0,4,0,5,1,5,3,0,1,1,0,0]

def active8640 : List Nat := [0,1]

def tree8640 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8640 : H12WitnessSearch.Good tree8640 := H12GlobalWitnessIndex.good

theorem leafIdentity8640 : H12AffineFastState.composeSystem env8640 rootObs = leafEnv8640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8640 rootObs == leafEnv8640) = true)

theorem terminalChecked8640 : H12PackedTerminal.terminalCheckFast leafEnv8640 active8640 tree8640 = true := by decide +kernel

def env8641 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,65,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4961,16617,21041,1021]

theorem envBound8641 : H12AffineFastState.Bounded env8641 := by
  intro p hp
  have h : env8641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8597_8641 : H12AffineEnvironment.transform 20 65 env8597 = env8641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8597 == env8641) = true)

theorem identity8641 : scanCanonicalize (H12AffineFastState.compose env8641 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279375) := by decide +kernel

theorem selectedBound8641 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8642 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24770,4605,262144,4961,8693,65,279375,5004,34,8329,21041,278625,267142,266874,18633,505,262867,4961,16617,21041,1021]

theorem envBound8642 : H12AffineFastState.Bounded env8642 := by
  intro p hp
  have h : env8642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8641_8642 : H12AffineEnvironment.transform 21 279375 env8641 = env8642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279375 env8641 == env8642) = true)

def env8643 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8693,8946,4605,262144,4961,8693,65,262527,5004,34,8329,4097,262737,267142,266874,2809,505,262867,4961,729,4097,1021]

theorem envBound8643 : H12AffineFastState.Bounded env8643 := by
  intro p hp
  have h : env8643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8642_8643 : H12AffineEnvironment.transform 13 560 env8642 = env8643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8642 == env8643) = true)

def env8644 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8234,4605,262144,4537,8693,65,262527,4436,34,8329,4097,262281,266590,266402,2081,505,262155,4537,1,4097,293]

theorem envBound8644 : H12AffineFastState.Bounded env8644 := by
  intro p hp
  have h : env8644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8643_8644 : H12AffineEnvironment.transform 8 216 env8643 = env8644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8643 == env8644) = true)

theorem identity8644 : scanCanonicalize (H12AffineFastState.compose env8644 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8644 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8645 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,232,8352,8234,4264,262144,4332,8352,65,262186,4097,34,8329,4097,262281,266251,266402,2081,172,262155,4332,1,4097,112]

theorem envBound8645 : H12AffineFastState.Bounded env8645 := by
  intro p hp
  have h : env8645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8644_8645 : H12AffineEnvironment.transform 7 85 env8644 = env8645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8644 == env8645) = true)

theorem identity8645 : scanCanonicalize (H12AffineFastState.compose env8645 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8645 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8646 : List Nat := [2,4,8,16,32,64,120,85,32,85,2048,4096,8192,16,8280,8234,4176,262144,4116,8280,65,262186,4097,34,8305,4097,262257,266251,266330,2081,84,262155,4116,1,4097,112]

theorem envBound8646 : H12AffineFastState.Bounded env8646 := by
  intro p hp
  have h : env8646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8645_8646 : H12AffineEnvironment.transform 6 120 env8645 = env8646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8645 == env8646) = true)

theorem identity8646 : scanCanonicalize (H12AffineFastState.compose env8646 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound8646 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8647 : List Nat := [2,4,8,16,32,64,120,85,32,85,2048,4096,8192,16,8280,8234,4176,6193,4116,8280,65,6171,4097,34,8305,4097,6208,2106,2155,2081,84,6202,4116,1,4097,112]

theorem envBound8647 : H12AffineFastState.Bounded env8647 := by
  intro p hp
  have h : env8647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8646_8647 : H12AffineEnvironment.transform 17 6193 env8646 = env8647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env8646 == env8647) = true)

theorem identity8647 : scanCanonicalize (H12AffineFastState.compose env8647 (packedSelected [2,3,4,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound8647 : packedSelected [2,3,4,7,8,14] rootPS < 2^1333 := by decide +kernel

def env8648 : List Nat := [2,4,8,16,32,64,120,85,32,85,2048,26,8192,16,8280,8234,74,2091,14,8280,65,2049,27,34,8305,27,2138,2106,2155,2081,84,2080,14,1,27,112]

theorem envBound8648 : H12AffineFastState.Bounded env8648 := by
  intro p hp
  have h : env8648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8647_8648 : H12AffineEnvironment.transform 11 26 env8647 = env8648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env8647 == env8648) = true)

theorem identity8648 : scanCanonicalize (H12AffineFastState.compose env8648 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2162) := by decide +kernel

theorem selectedBound8648 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8649 : List Nat := [2,4,8,16,32,64,120,85,32,85,2048,26,2162,16,2090,2136,74,2091,14,2090,65,2049,27,34,2051,27,2138,2106,2155,2081,84,2080,14,1,27,112]

theorem envBound8649 : H12AffineFastState.Bounded env8649 := by
  intro p hp
  have h : env8649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8648_8649 : H12AffineEnvironment.transform 12 2162 env8648 = env8649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2162 env8648 == env8649) = true)

theorem identity8649 : scanCanonicalize (H12AffineFastState.compose env8649 (packedSelected [1,3,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound8649 : packedSelected [1,3,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env8650 : List Nat := [2,4,8,16,32,64,120,85,32,85,96,26,18,16,74,56,74,75,14,74,65,97,27,34,99,27,58,90,11,65,84,64,14,1,27,112]

theorem envBound8650 : H12AffineFastState.Bounded env8650 := by
  intro p hp
  have h : env8650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8649_8650 : H12AffineEnvironment.transform 10 96 env8649 = env8650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env8649 == env8650) = true)

theorem identity8650 : scanCanonicalize (H12AffineFastState.compose env8650 (packedSelected [3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8650 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env8651 : List Nat := [2,4,8,16,32,11,51,30,32,30,43,26,18,16,1,56,1,0,14,1,10,42,27,34,40,27,58,17,11,10,31,11,14,1,27,59]

theorem envBound8651 : H12AffineFastState.Bounded env8651 := by
  intro p hp
  have h : env8651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8650_8651 : H12AffineEnvironment.transform 5 11 env8650 = env8651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8650 == env8651) = true)

theorem identity8651 : scanCanonicalize (H12AffineFastState.compose env8651 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8651 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8652 : List Nat := [2,4,8,16,11,11,24,30,11,30,0,26,18,16,1,19,1,0,14,1,10,1,27,9,3,27,17,17,11,10,31,11,14,1,27,16]

theorem envBound8652 : H12AffineFastState.Bounded env8652 := by
  intro p hp
  have h : env8652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8651_8652 : H12AffineEnvironment.transform 4 11 env8651 = env8652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8651 == env8652) = true)

theorem identity8652 : scanCanonicalize (H12AffineFastState.compose env8652 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8653 : List Nat := [2,4,8,0,11,11,8,14,11,14,0,10,2,0,1,3,1,0,14,1,10,1,11,9,3,11,1,1,11,10,15,11,14,1,11,0]

theorem envBound8653 : H12AffineFastState.Bounded env8653 := by
  intro p hp
  have h : env8653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8652_8653 : H12AffineEnvironment.transform 3 0 env8652 = env8653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8652 == env8653) = true)

theorem identity8653 : scanCanonicalize (H12AffineFastState.compose env8653 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8654 : List Nat := [2,4,2,0,1,1,2,4,1,4,0,0,2,0,1,3,1,0,4,1,0,1,1,3,3,1,1,1,1,0,5,1,4,1,1,0]

theorem envBound8654 : H12AffineFastState.Bounded env8654 := by
  intro p hp
  have h : env8654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8653_8654 : H12AffineEnvironment.transform 2 2 env8653 = env8654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8653 == env8654) = true)

theorem identity8654 : scanCanonicalize (H12AffineFastState.compose env8654 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8655 : List Nat := [2,1,2,0,1,1,2,1,1,1,0,0,2,0,1,3,1,0,1,1,0,1,1,3,3,1,1,1,1,0,0,1,1,1,1,0]

theorem envBound8655 : H12AffineFastState.Bounded env8655 := by
  intro p hp
  have h : env8655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8654_8655 : H12AffineEnvironment.transform 1 1 env8654 = env8655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8654 == env8655) = true)

def env8656 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8235,4605,262144,4536,8693,65,262527,4437,34,8329,4097,262280,266591,266403,2080,505,262154,4536,0,4097,292]

theorem envBound8656 : H12AffineFastState.Bounded env8656 := by
  intro p hp
  have h : env8656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8643_8656 : H12AffineEnvironment.transform 8 217 env8643 = env8656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8643 == env8656) = true)

theorem identity8656 : scanCanonicalize (H12AffineFastState.compose env8656 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound8656 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8657 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8693,8235,4605,163,4536,8693,65,476,4437,34,8329,4097,43,4604,4096,2080,505,169,4536,0,4097,292]

theorem envBound8657 : H12AffineFastState.Bounded env8657 := by
  intro p hp
  have h : env8657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8656_8657 : H12AffineEnvironment.transform 17 163 env8656 = env8657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env8656 == env8657) = true)

theorem identity8657 : scanCanonicalize (H12AffineFastState.compose env8657 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8657 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8658 : List Nat := [2,4,8,16,32,64,128,4,217,4,2048,4096,8192,233,8433,8235,4345,163,4284,8433,65,216,4177,34,8329,4097,43,4344,4096,2080,253,169,4284,0,4097,32]

theorem envBound8658 : H12AffineFastState.Bounded env8658 := by
  intro p hp
  have h : env8658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8657_8658 : H12AffineEnvironment.transform 7 4 env8657 = env8658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8657 == env8658) = true)

theorem identity8658 : scanCanonicalize (H12AffineFastState.compose env8658 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8658 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8659 : List Nat := [2,4,8,16,32,64,128,4,217,4,2048,2242,8192,233,8433,8235,2107,163,2174,8433,65,216,2195,34,8329,2243,43,2106,2242,2080,253,169,2174,0,2243,32]

theorem envBound8659 : H12AffineFastState.Bounded env8659 := by
  intro p hp
  have h : env8659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8658_8659 : H12AffineEnvironment.transform 11 2242 env8658 = env8659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8658 == env8659) = true)

theorem identity8659 : scanCanonicalize (H12AffineFastState.compose env8659 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8659 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8660 : List Nat := [2,4,8,16,32,64,41,4,112,4,2048,2155,8192,64,8280,8235,2107,10,2174,8280,65,113,2106,34,8224,2154,43,2106,2155,2080,84,0,2174,0,2154,32]

theorem envBound8660 : H12AffineFastState.Bounded env8660 := by
  intro p hp
  have h : env8660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8659_8660 : H12AffineEnvironment.transform 6 41 env8659 = env8660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8659 == env8660) = true)

theorem identity8660 : scanCanonicalize (H12AffineFastState.compose env8660 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8660 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env8661 : List Nat := [2,4,8,16,32,16,41,4,32,4,2048,2107,8192,16,8200,8235,2107,10,2094,8200,17,33,2106,34,8224,2106,43,2106,2107,2080,4,0,2094,0,2106,32]

theorem envBound8661 : H12AffineFastState.Bounded env8661 := by
  intro p hp
  have h : env8661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8660_8661 : H12AffineEnvironment.transform 5 16 env8660 = env8661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8660 == env8661) = true)

theorem identity8661 : scanCanonicalize (H12AffineFastState.compose env8661 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound8661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8662 : List Nat := [2,4,8,16,32,16,41,4,32,4,2048,2107,2089,16,2081,2050,2107,10,2094,2081,17,33,2106,34,2057,2106,43,2106,2107,2080,4,0,2094,0,2106,32]

theorem envBound8662 : H12AffineFastState.Bounded env8662 := by
  intro p hp
  have h : env8662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8661_8662 : H12AffineEnvironment.transform 12 2089 env8661 = env8662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env8661 == env8662) = true)

theorem identity8662 : scanCanonicalize (H12AffineFastState.compose env8662 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8662 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8663 : List Nat := [2,4,8,16,32,16,41,4,32,4,0,59,41,16,33,2,59,10,46,33,17,33,58,34,9,58,43,58,59,32,4,0,46,0,58,32]

theorem envBound8663 : H12AffineFastState.Bounded env8663 := by
  intro p hp
  have h : env8663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8662_8663 : H12AffineEnvironment.transform 10 0 env8662 = env8663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8662 == env8663) = true)

def env8664 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8693,8947,4605,262144,4961,8693,65,262526,5004,34,8329,4096,262736,267142,266874,2808,505,262867,4961,728,4096,1021]

theorem envBound8664 : H12AffineFastState.Bounded env8664 := by
  intro p hp
  have h : env8664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8642_8664 : H12AffineEnvironment.transform 13 561 env8642 = env8664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8642 == env8664) = true)

def env8665 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8235,4605,262144,4537,8693,65,262526,4436,34,8329,4096,262280,266590,266402,2080,505,262155,4537,0,4096,293]

theorem envBound8665 : H12AffineFastState.Bounded env8665 := by
  intro p hp
  have h : env8665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8664_8665 : H12AffineEnvironment.transform 8 216 env8664 = env8665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8664 == env8665) = true)

theorem identity8665 : scanCanonicalize (H12AffineFastState.compose env8665 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 162) := by decide +kernel

theorem selectedBound8665 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8666 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8693,8235,4605,162,4537,8693,65,476,4436,34,8329,4096,42,4604,4096,2080,505,169,4537,0,4096,293]

theorem envBound8666 : H12AffineFastState.Bounded env8666 := by
  intro p hp
  have h : env8666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8665_8666 : H12AffineEnvironment.transform 17 162 env8665 = env8666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 162 env8665 == env8666) = true)

theorem identity8666 : scanCanonicalize (H12AffineFastState.compose env8666 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8666 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8667 : List Nat := [2,4,8,16,32,17,128,256,137,256,2048,4096,8192,184,8612,8235,4524,162,4537,8612,16,397,4357,34,8329,4096,42,4525,4096,2080,424,169,4537,0,4096,293]

theorem envBound8667 : H12AffineFastState.Bounded env8667 := by
  intro p hp
  have h : env8667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8666_8667 : H12AffineEnvironment.transform 5 17 env8666 = env8667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8666 == env8667) = true)

theorem identity8667 : scanCanonicalize (H12AffineFastState.compose env8667 (packedSelected [13,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound8667 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8668 : List Nat := [2,4,8,16,32,17,128,256,137,256,2048,2106,8192,184,8612,8235,2454,162,2435,8612,16,397,2367,34,8329,2106,42,2455,2106,2080,424,169,2435,0,2106,293]

theorem envBound8668 : H12AffineFastState.Bounded env8668 := by
  intro p hp
  have h : env8668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8667_8668 : H12AffineEnvironment.transform 11 2106 env8667 = env8668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env8667 == env8668) = true)

theorem identity8668 : scanCanonicalize (H12AffineFastState.compose env8668 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8668 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8669 : List Nat := [2,4,8,16,32,17,128,4,137,4,2048,2106,8192,184,8352,8235,2194,162,2183,8352,16,137,2107,34,8329,2106,42,2195,2106,2080,172,169,2183,0,2106,33]

theorem envBound8669 : H12AffineFastState.Bounded env8669 := by
  intro p hp
  have h : env8669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8668_8669 : H12AffineEnvironment.transform 7 4 env8668 = env8669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8668 == env8669) = true)

theorem identity8669 : scanCanonicalize (H12AffineFastState.compose env8669 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound8669 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8670 : List Nat := [2,4,8,16,32,17,51,4,58,4,2048,2106,8192,11,8211,8235,2081,17,2100,8211,16,58,2107,34,8250,2106,42,2080,2106,2080,31,26,2100,0,2106,33]

theorem envBound8670 : H12AffineFastState.Bounded env8670 := by
  intro p hp
  have h : env8670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8669_8670 : H12AffineEnvironment.transform 6 51 env8669 = env8670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env8669 == env8670) = true)

theorem identity8670 : scanCanonicalize (H12AffineFastState.compose env8670 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8670 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8671 : List Nat := [2,4,8,16,32,17,51,4,58,4,2048,2106,25,11,10,50,2081,17,2100,10,16,58,2107,34,35,2106,42,2080,2106,2080,31,26,2100,0,2106,33]

theorem envBound8671 : H12AffineFastState.Bounded env8671 := by
  intro p hp
  have h : env8671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8670_8671 : H12AffineEnvironment.transform 12 25 env8670 = env8671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8670 == env8671) = true)

theorem identity8671 : scanCanonicalize (H12AffineFastState.compose env8671 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8671 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8672 : List Nat := [2,4,8,16,17,17,2,4,11,4,2048,2059,25,11,10,3,2064,17,2053,10,16,11,2058,19,18,2059,27,2065,2059,2065,31,26,2053,0,2059,16]

theorem envBound8672 : H12AffineFastState.Bounded env8672 := by
  intro p hp
  have h : env8672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8671_8672 : H12AffineEnvironment.transform 4 17 env8671 = env8672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8671 == env8672) = true)

theorem identity8672 : scanCanonicalize (H12AffineFastState.compose env8672 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8672 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8673 : List Nat := [2,4,8,11,10,10,2,4,11,4,2048,2059,2,11,10,3,2059,10,2053,10,11,11,2058,8,9,2059,0,2058,2059,2058,4,1,2053,0,2059,11]

theorem envBound8673 : H12AffineFastState.Bounded env8673 := by
  intro p hp
  have h : env8673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8672_8673 : H12AffineEnvironment.transform 3 11 env8672 = env8673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8672 == env8673) = true)

theorem identity8673 : scanCanonicalize (H12AffineFastState.compose env8673 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8674 : List Nat := [2,4,8,11,10,10,2,4,11,4,1,10,2,11,10,3,10,10,4,10,11,11,11,8,9,10,0,11,10,11,4,1,4,0,10,11]

theorem envBound8674 : H12AffineFastState.Bounded env8674 := by
  intro p hp
  have h : env8674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8673_8674 : H12AffineEnvironment.transform 10 1 env8673 = env8674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8673 == env8674) = true)

theorem identity8674 : scanCanonicalize (H12AffineFastState.compose env8674 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8675 : List Nat := [2,4,2,1,0,0,2,4,1,4,1,0,2,1,0,3,0,0,4,0,1,1,1,2,3,0,0,1,0,1,4,1,4,0,0,1]

theorem envBound8675 : H12AffineFastState.Bounded env8675 := by
  intro p hp
  have h : env8675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8674_8675 : H12AffineEnvironment.transform 2 2 env8674 = env8675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8674 == env8675) = true)

def env8676 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8693,8234,4605,262144,4536,8693,65,262526,4437,34,8329,4096,262281,266591,266403,2081,505,262154,4536,1,4096,292]

theorem envBound8676 : H12AffineFastState.Bounded env8676 := by
  intro p hp
  have h : env8676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8664_8676 : H12AffineEnvironment.transform 8 217 env8664 = env8676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8664 == env8676) = true)

theorem identity8676 : scanCanonicalize (H12AffineFastState.compose env8676 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8676 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8677 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,232,8352,8234,4264,262144,4333,8352,65,262187,4096,34,8329,4096,262281,266250,266403,2081,172,262154,4333,1,4096,113]

theorem envBound8677 : H12AffineFastState.Bounded env8677 := by
  intro p hp
  have h : env8677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8676_8677 : H12AffineEnvironment.transform 7 85 env8676 = env8677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8676 == env8677) = true)

theorem identity8677 : scanCanonicalize (H12AffineFastState.compose env8677 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8677 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8678 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,232,8352,8234,4264,90,4333,8352,65,113,4096,34,8329,4096,211,4176,4345,2081,172,80,4333,1,4096,113]

theorem envBound8678 : H12AffineFastState.Bounded env8678 := by
  intro p hp
  have h : env8678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8677_8678 : H12AffineEnvironment.transform 17 90 env8677 = env8678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8677 == env8678) = true)

theorem identity8678 : scanCanonicalize (H12AffineFastState.compose env8678 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8678 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8679 : List Nat := [2,4,8,16,32,64,121,85,32,85,2048,4096,8192,17,8281,8234,4177,90,4116,8281,65,113,4096,34,8304,4096,42,4176,4096,2081,85,80,4116,1,4096,113]

theorem envBound8679 : H12AffineFastState.Bounded env8679 := by
  intro p hp
  have h : env8679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8678_8679 : H12AffineEnvironment.transform 6 121 env8678 = env8679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8678 == env8679) = true)

theorem identity8679 : scanCanonicalize (H12AffineFastState.compose env8679 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound8679 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env8680 : List Nat := [2,4,8,16,32,64,121,85,32,85,2048,2107,8192,17,8281,8234,2154,90,2095,8281,65,113,2107,34,8304,2107,42,2155,2107,2081,85,80,2095,1,2107,113]

theorem envBound8680 : H12AffineFastState.Bounded env8680 := by
  intro p hp
  have h : env8680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8679_8680 : H12AffineEnvironment.transform 11 2107 env8679 = env8680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env8679 == env8680) = true)

theorem identity8680 : scanCanonicalize (H12AffineFastState.compose env8680 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8680 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8681 : List Nat := [2,4,8,16,32,48,9,37,32,37,2048,2107,8192,17,8233,8234,2074,42,2095,8233,49,1,2107,34,8192,2107,42,2075,2107,2081,37,32,2095,1,2107,1]

theorem envBound8681 : H12AffineFastState.Bounded env8681 := by
  intro p hp
  have h : env8681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8680_8681 : H12AffineEnvironment.transform 5 48 env8680 = env8681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8680 == env8681) = true)

theorem identity8681 : scanCanonicalize (H12AffineFastState.compose env8681 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8681 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8682 : List Nat := [2,4,8,16,0,16,9,5,0,5,2048,2075,8192,17,8201,8202,2074,10,2063,8201,17,1,2075,2,8192,2075,10,2075,2075,2049,5,0,2063,1,2075,1]

theorem envBound8682 : H12AffineFastState.Bounded env8682 := by
  intro p hp
  have h : env8682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8681_8682 : H12AffineEnvironment.transform 4 0 env8681 = env8682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8681 == env8682) = true)

theorem identity8682 : scanCanonicalize (H12AffineFastState.compose env8682 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8683 : List Nat := [2,4,3,16,0,16,2,5,0,5,2048,2064,8192,17,8194,8193,2065,1,2052,8194,17,1,2064,2,8192,2064,1,2064,2064,2049,5,0,2052,1,2064,1]

theorem envBound8683 : H12AffineFastState.Bounded env8683 := by
  intro p hp
  have h : env8683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8682_8683 : H12AffineEnvironment.transform 2 3 env8682 = env8683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8682 == env8683) = true)

theorem identity8683 : scanCanonicalize (H12AffineFastState.compose env8683 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound8683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8684 : List Nat := [2,4,3,16,0,16,2,5,0,5,2048,2064,2,17,0,3,2065,1,2052,0,17,1,2064,2,2,2064,1,2064,2064,2049,5,0,2052,1,2064,1]

theorem envBound8684 : H12AffineFastState.Bounded env8684 := by
  intro p hp
  have h : env8684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8683_8684 : H12AffineEnvironment.transform 12 2 env8683 = env8684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env8683 == env8684) = true)

theorem identity8684 : scanCanonicalize (H12AffineFastState.compose env8684 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound8684 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env8685 : List Nat := [2,4,3,16,0,16,2,5,0,5,20,4,2,17,0,3,5,1,16,0,17,1,4,2,2,4,1,4,4,21,5,0,16,1,4,1]

theorem envBound8685 : H12AffineFastState.Bounded env8685 := by
  intro p hp
  have h : env8685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8684_8685 : H12AffineEnvironment.transform 10 20 env8684 = env8685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env8684 == env8685) = true)

theorem identity8685 : scanCanonicalize (H12AffineFastState.compose env8685 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8685 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8686 : List Nat := [2,4,3,1,0,1,2,5,0,5,5,4,2,0,0,3,5,1,1,0,0,1,4,2,2,4,1,4,4,4,5,0,1,1,4,1]

theorem envBound8686 : H12AffineFastState.Bounded env8686 := by
  intro p hp
  have h : env8686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8685_8686 : H12AffineEnvironment.transform 3 1 env8685 = env8686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8685 == env8686) = true)

def env8687 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,90337,8329,21040,807680,4735912,4735572,605035,529048,4796990,524288,602955,2695634,90942]

theorem envBound8687 : H12AffineFastState.Bounded env8687 := by
  intro p hp
  have h : env8687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8531_8687 : H12AffineEnvironment.transform 23 90337 env8531 = env8687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8531 == env8687) = true)

def env8688 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,4960,8693,2097152,4194304,5005,90337,8329,21040,278624,4214984,4215092,75787,504,4268382,4960,73771,2175666,90942]

theorem envBound8688 : H12AffineFastState.Bounded env8688 := by
  intro p hp
  have h : env8688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8687_8688 : H12AffineEnvironment.transform 18 4960 env8687 = env8688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8687 == env8688) = true)

theorem identity8688 : scanCanonicalize (H12AffineFastState.compose env8688 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8688 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8689 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,2097152,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4960,16616,2118257,1021]

theorem envBound8689 : H12AffineFastState.Bounded env8689 := by
  intro p hp
  have h : env8689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8688_8689 : H12AffineEnvironment.transform 15 24771 env8688 = env8689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8688 == env8689) = true)

def env8690 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,262144,4960,8693,64,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4960,16616,21041,1021]

theorem envBound8690 : H12AffineFastState.Bounded env8690 := by
  intro p hp
  have h : env8690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8689_8690 : H12AffineEnvironment.transform 20 64 env8689 = env8690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8689 == env8690) = true)

theorem identity8690 : scanCanonicalize (H12AffineFastState.compose env8690 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17351) := by decide +kernel

theorem selectedBound8690 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8691 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,24771,4605,17351,4960,8693,64,4194304,5005,34,8329,21040,935,4214984,4215092,18632,504,4211101,4960,16616,21041,1021]

theorem envBound8691 : H12AffineFastState.Bounded env8691 := by
  intro p hp
  have h : env8691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8690_8691 : H12AffineEnvironment.transform 17 17351 env8690 = env8691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17351 env8690 == env8691) = true)

def env8692 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8235,4605,815,4960,8693,64,4194304,5005,34,8329,4824,935,4198432,4198876,2080,504,4194677,4960,0,4825,1021]

theorem envBound8692 : H12AffineFastState.Bounded env8692 := by
  intro p hp
  have h : env8692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8691_8692 : H12AffineEnvironment.transform 13 232 env8691 = env8692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8691 == env8692) = true)

theorem identity8692 : scanCanonicalize (H12AffineFastState.compose env8692 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8692 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8693 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8693,8235,4605,815,4960,8693,64,477,5005,34,8329,4824,935,4605,4097,2080,504,168,4960,0,4825,1021]

theorem envBound8693 : H12AffineFastState.Bounded env8693 := by
  intro p hp
  have h : env8693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8692_8693 : H12AffineEnvironment.transform 21 477 env8692 = env8693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8692 == env8693) = true)

def env8694 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8693,8235,4605,503,4536,8693,64,477,4437,34,8329,4096,383,4605,4097,2080,504,168,4536,0,4097,293]

theorem envBound8694 : H12AffineFastState.Bounded env8694 := by
  intro p hp
  have h : env8694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8693_8694 : H12AffineEnvironment.transform 8 216 env8693 = env8694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8693 == env8694) = true)

theorem identity8694 : scanCanonicalize (H12AffineFastState.compose env8694 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8694 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8695 : List Nat := [2,4,8,16,32,64,128,4,216,4,2048,4096,8192,232,8433,8235,4345,243,4284,8433,64,217,4177,34,8329,4096,123,4345,4097,2080,252,168,4284,0,4097,33]

theorem envBound8695 : H12AffineFastState.Bounded env8695 := by
  intro p hp
  have h : env8695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8694_8695 : H12AffineEnvironment.transform 7 4 env8694 = env8695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8694 == env8695) = true)

theorem identity8695 : scanCanonicalize (H12AffineFastState.compose env8695 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8695 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8696 : List Nat := [2,4,8,16,32,64,128,4,216,4,2048,2242,8192,232,8433,8235,2107,243,2174,8433,64,217,2195,34,8329,2242,123,2107,2243,2080,252,168,2174,0,2243,33]

theorem envBound8696 : H12AffineFastState.Bounded env8696 := by
  intro p hp
  have h : env8696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8695_8696 : H12AffineEnvironment.transform 11 2242 env8695 = env8696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8695 == env8696) = true)

theorem identity8696 : scanCanonicalize (H12AffineFastState.compose env8696 (packedSelected [0,2,4,7,9,11,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound8696 : packedSelected [0,2,4,7,9,11,13,18] rootPS < 2^1333 := by decide +kernel

def env8697 : List Nat := [2,4,8,16,32,64,50,4,106,4,2048,2160,8192,90,8259,8235,2107,65,2174,8259,64,107,2081,34,8251,2160,123,2107,2161,2080,78,26,2174,0,2161,33]

theorem envBound8697 : H12AffineFastState.Bounded env8697 := by
  intro p hp
  have h : env8697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8696_8697 : H12AffineEnvironment.transform 6 50 env8696 = env8697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env8696 == env8697) = true)

theorem identity8697 : scanCanonicalize (H12AffineFastState.compose env8697 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8697 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8698 : List Nat := [2,4,8,16,32,16,50,4,58,4,2048,2080,8192,10,8211,8235,2107,17,2094,8211,16,59,2081,34,8251,2080,43,2107,2081,2080,30,26,2094,0,2081,33]

theorem envBound8698 : H12AffineFastState.Bounded env8698 := by
  intro p hp
  have h : env8698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8697_8698 : H12AffineEnvironment.transform 5 16 env8697 = env8698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8697 == env8698) = true)

theorem identity8698 : scanCanonicalize (H12AffineFastState.compose env8698 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8698 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8699 : List Nat := [2,4,8,16,1,16,19,4,27,4,2048,2049,8192,10,8211,8202,2074,17,2063,8211,16,26,2048,3,8218,2049,10,2074,2048,2049,30,26,2063,0,2048,0]

theorem envBound8699 : H12AffineFastState.Bounded env8699 := by
  intro p hp
  have h : env8699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8698_8699 : H12AffineEnvironment.transform 4 1 env8698 = env8699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8698 == env8699) = true)

theorem identity8699 : scanCanonicalize (H12AffineFastState.compose env8699 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8699 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8700 : List Nat := [2,4,8,16,1,16,19,4,27,4,2048,2049,25,10,10,19,2074,17,2063,10,16,26,2048,3,3,2049,10,2074,2048,2049,30,26,2063,0,2048,0]

theorem envBound8700 : H12AffineFastState.Bounded env8700 := by
  intro p hp
  have h : env8700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0