import H12CloudChart0Data101

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound25822 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25823 : List Nat := [2,4,8,7,1,15,9,12,11,10,9,7,8,0,0,2,7,9,10,1,8,0,6,3,9,14,9,7,6,9,10,0,12,0,9,11]

theorem envBound25823 : H12AffineFastState.Bounded env25823 := by
  intro p hp
  have h : env25823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25822_25823 : H12AffineEnvironment.transform 5 15 env25822 = env25823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env25822 == env25823) = true)

theorem identity25823 : scanCanonicalize (H12AffineFastState.compose env25823 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound25823 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25824 : List Nat := [2,4,1,7,1,6,0,5,2,3,0,7,1,0,0,2,7,0,3,1,1,0,6,3,0,7,0,7,6,0,3,0,5,0,0,2]

theorem envBound25824 : H12AffineFastState.Bounded env25824 := by
  intro p hp
  have h : env25824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25823_25824 : H12AffineEnvironment.transform 2 1 env25823 = env25824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env25823 == env25824) = true)

def env25825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,510137,8328,65,316668,416885,396389,35188,1500,272393,256,21792,46213,74251]

theorem envBound25825 : H12AffineFastState.Bounded env25825 := by
  intro p hp
  have h : env25825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25783_25825 : H12AffineEnvironment.transform 20 4161 env25783 = env25825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25783 == env25825) = true)

theorem identity25825 : scanCanonicalize (H12AffineFastState.compose env25825 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25825 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,169264,412021,452787,8328,65,316668,416885,396389,35188,1500,272393,256,21792,46213,513]

theorem envBound25826 : H12AffineFastState.Bounded env25826 := by
  intro p hp
  have h : env25826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25825_25826 : H12AffineEnvironment.transform 15 8202 env25825 = env25826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25825 == env25826) = true)

def env25827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4161,54560,264549,305315,8328,65,316668,269413,281717,35188,1500,272393,256,21792,46213,513]

theorem envBound25827 : H12AffineFastState.Bounded env25827 := by
  intro p hp
  have h : env25827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25826_25827 : H12AffineEnvironment.transform 16 16400 env25826 = env25827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25826 == env25827) = true)

def env25828 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4113,54560,264501,305315,8328,17,316588,269365,281637,35108,1420,272393,256,21792,46213,513]

theorem envBound25828 : H12AffineFastState.Bounded env25828 := by
  intro p hp
  have h : env25828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25827_25828 : H12AffineEnvironment.transform 5 16 env25827 = env25828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25827 == env25828) = true)

theorem identity25828 : scanCanonicalize (H12AffineFastState.compose env25828 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound25828 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env25829 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32160,1024,32769,4113,54560,29845,54531,8328,17,43276,24981,12677,35108,1420,21929,256,21792,46213,513]

theorem envBound25829 : H12AffineFastState.Bounded env25829 := by
  intro p hp
  have h : env25829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25828_25829 : H12AffineEnvironment.transform 17 32160 env25828 = env25829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env25828 == env25829) = true)

theorem identity25829 : scanCanonicalize (H12AffineFastState.compose env25829 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25829 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25830 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1024,32769,4113,54560,29725,54531,8192,17,43276,24861,12557,35108,1284,21793,256,21792,46093,513]

theorem envBound25830 : H12AffineFastState.Bounded env25830 := by
  intro p hp
  have h : env25830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25829_25830 : H12AffineEnvironment.transform 6 8 env25829 = env25830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25829 == env25830) = true)

theorem identity25830 : scanCanonicalize (H12AffineFastState.compose env25830 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25830 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env25831 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,32040,1024,8460,4113,29741,29725,29710,8192,17,2049,24861,12557,10281,1284,21793,256,21792,5376,513]

theorem envBound25831 : H12AffineFastState.Bounded env25831 := by
  intro p hp
  have h : env25831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25830_25831 : H12AffineEnvironment.transform 14 8461 env25830 = env25831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env25830 == env25831) = true)

theorem identity25831 : scanCanonicalize (H12AffineFastState.compose env25831 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25831 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25832 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,5392,10280,1024,8460,4113,8493,8477,8462,8192,17,2049,13341,12557,10281,1284,33,256,32,5376,513]

theorem envBound25832 : H12AffineFastState.Bounded env25832 := by
  intro p hp
  have h : env25832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25831_25832 : H12AffineEnvironment.transform 13 5376 env25831 = env25832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25831 == env25832) = true)

theorem identity25832 : scanCanonicalize (H12AffineFastState.compose env25832 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25832 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25833 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,263,5392,2341,1024,1,4113,32,16,3,269,17,2049,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound25833 : H12AffineFastState.Bounded env25833 := by
  intro p hp
  have h : env25833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25832_25833 : H12AffineEnvironment.transform 12 269 env25832 = env25833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25832 == env25833) = true)

theorem identity25833 : scanCanonicalize (H12AffineFastState.compose env25833 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound25833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25834 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,49,269,1329,0,263,1313,2341,1024,1,32,32,16,3,269,17,2049,1313,49,2340,1284,33,256,32,1329,513]

theorem envBound25834 : H12AffineFastState.Bounded env25834 := by
  intro p hp
  have h : env25834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25833_25834 : H12AffineEnvironment.transform 11 49 env25833 = env25834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env25833 == env25834) = true)

theorem identity25834 : scanCanonicalize (H12AffineFastState.compose env25834 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25834 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25835 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,0,35,1029,2049,1024,1,32,32,16,3,41,17,2049,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound25835 : H12AffineFastState.Bounded env25835 := by
  intro p hp
  have h : env25835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25834_25835 : H12AffineEnvironment.transform 7 36 env25834 = env25835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25834 == env25835) = true)

theorem identity25835 : scanCanonicalize (H12AffineFastState.compose env25835 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25835 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25836 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,49,41,1045,0,35,1029,1,1024,1,32,32,16,3,41,17,1,1029,49,0,1056,33,36,32,1045,513]

theorem envBound25836 : H12AffineFastState.Bounded env25836 := by
  intro p hp
  have h : env25836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25835_25836 : H12AffineEnvironment.transform 10 0 env25835 = env25836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25835 == env25836) = true)

theorem identity25836 : scanCanonicalize (H12AffineFastState.compose env25836 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound25836 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25837 : List Nat := [2,4,8,16,32,16,8,36,512,565,0,49,41,544,0,35,560,1,565,1,32,32,16,3,41,17,1,560,49,0,533,33,36,32,544,513]

theorem envBound25837 : H12AffineFastState.Bounded env25837 := by
  intro p hp
  have h : env25837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25836_25837 : H12AffineEnvironment.transform 9 565 env25836 = env25837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env25836 == env25837) = true)

theorem identity25837 : scanCanonicalize (H12AffineFastState.compose env25837 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25837 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25838 : List Nat := [2,4,8,0,32,0,8,36,512,549,0,33,41,544,0,35,544,1,549,1,32,32,0,3,41,1,1,544,33,0,517,33,36,32,544,513]

theorem envBound25838 : H12AffineFastState.Bounded env25838 := by
  intro p hp
  have h : env25838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25837_25838 : H12AffineEnvironment.transform 3 0 env25837 = env25838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25837 == env25838) = true)

theorem identity25838 : scanCanonicalize (H12AffineFastState.compose env25838 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25838 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25839 : List Nat := [2,4,8,0,0,0,8,4,512,517,0,1,9,512,0,3,512,1,517,1,0,0,0,3,9,1,1,512,1,0,517,1,4,0,512,513]

theorem envBound25839 : H12AffineFastState.Bounded env25839 := by
  intro p hp
  have h : env25839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25838_25839 : H12AffineEnvironment.transform 4 0 env25838 = env25839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25838 == env25839) = true)

theorem identity25839 : scanCanonicalize (H12AffineFastState.compose env25839 (packedSelected [10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25839 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env25840 : List Nat := [2,4,8,0,0,0,8,4,0,5,0,1,9,0,0,3,0,1,5,1,0,0,0,3,9,1,1,0,1,0,5,1,4,0,0,1]

theorem envBound25840 : H12AffineFastState.Bounded env25840 := by
  intro p hp
  have h : env25840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25839_25840 : H12AffineEnvironment.transform 8 0 env25839 = env25840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25839 == env25840) = true)

theorem identity25840 : scanCanonicalize (H12AffineFastState.compose env25840 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25840 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25841 : List Nat := [2,4,3,0,0,0,3,4,0,5,0,1,2,0,0,3,0,1,5,1,0,0,0,3,2,1,1,0,1,0,5,1,4,0,0,1]

theorem envBound25841 : H12AffineFastState.Bounded env25841 := by
  intro p hp
  have h : env25841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25840_25841 : H12AffineEnvironment.transform 2 3 env25840 = env25841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25840 == env25841) = true)

def env25842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4112,54560,264500,305315,8328,16,316589,269364,281636,35109,1421,272393,256,21792,46213,513]

theorem envBound25842 : H12AffineFastState.Bounded env25842 := by
  intro p hp
  have h : env25842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25827_25842 : H12AffineEnvironment.transform 5 17 env25827 = env25842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25827 == env25842) = true)

theorem identity25842 : scanCanonicalize (H12AffineFastState.compose env25842 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound25842 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env25843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,4112,54560,8476,32907,8328,16,64645,13340,25612,35109,1421,33,256,21792,46213,513]

theorem envBound25843 : H12AffineFastState.Bounded env25843 := by
  intro p hp
  have h : env25843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25842_25843 : H12AffineEnvironment.transform 17 10280 env25842 = env25843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25842 == env25843) = true)

theorem identity25843 : scanCanonicalize (H12AffineFastState.compose env25843 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 9528) := by decide +kernel

theorem selectedBound25843 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env25844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,9528,8202,16400,10280,1024,9529,4112,28696,8476,9651,8328,16,22973,13340,25612,11293,1421,33,256,21792,4541,513]

theorem envBound25844 : H12AffineFastState.Bounded env25844 := by
  intro p hp
  have h : env25844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25843_25844 : H12AffineEnvironment.transform 14 9528 env25843 = env25844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9528 env25843 == env25844) = true)

theorem identity25844 : scanCanonicalize (H12AffineFastState.compose env25844 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound25844 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env25845 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13728,9528,8202,13744,10280,1024,9529,4112,1464,8476,9651,8328,16,11293,13340,4524,11293,1421,33,256,8320,4541,513]

theorem envBound25845 : H12AffineFastState.Bounded env25845 := by
  intro p hp
  have h : env25845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25844_25845 : H12AffineEnvironment.transform 13 13728 env25844 = env25845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env25844 == env25845) = true)

theorem identity25845 : scanCanonicalize (H12AffineFastState.compose env25845 (packedSelected [3,5,10,11,12,15,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25845 : packedSelected [3,5,10,11,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env25846 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,12465,8233,8202,12449,10280,273,8232,4112,169,8476,8354,8328,16,10508,12557,4524,10508,156,33,256,8320,4541,513]

theorem envBound25846 : H12AffineFastState.Bounded env25846 := by
  intro p hp
  have h : env25846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25845_25846 : H12AffineEnvironment.transform 9 273 env25845 = env25846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25845 == env25846) = true)

theorem identity25846 : scanCanonicalize (H12AffineFastState.compose env25846 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound25846 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25847 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,161,4112,136,171,4096,2185,273,137,4112,169,445,3,41,16,2477,4524,4524,2477,156,33,256,33,4541,513]

theorem envBound25847 : H12AffineFastState.Bounded env25847 := by
  intro p hp
  have h : env25847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25846_25847 : H12AffineEnvironment.transform 12 161 env25846 = env25847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env25846 == env25847) = true)

theorem identity25847 : scanCanonicalize (H12AffineFastState.compose env25847 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25847 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25848 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,4096,161,4112,136,171,4096,2185,189,137,4112,169,17,3,41,16,2049,4096,4096,2049,156,33,172,33,4113,513]

theorem envBound25848 : H12AffineFastState.Bounded env25848 := by
  intro p hp
  have h : env25848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25847_25848 : H12AffineEnvironment.transform 7 172 env25847 = env25848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25847 == env25848) = true)

theorem identity25848 : scanCanonicalize (H12AffineFastState.compose env25848 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25848 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25849 : List Nat := [2,4,8,1,32,0,128,172,512,172,2048,4096,161,4097,136,171,4096,2185,172,137,4097,169,0,3,41,1,2049,4096,4096,2049,141,33,172,33,4096,513]

theorem envBound25849 : H12AffineFastState.Bounded env25849 := by
  intro p hp
  have h : env25849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25848_25849 : H12AffineEnvironment.transform 3 1 env25848 = env25849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25848 == env25849) = true)

theorem identity25849 : scanCanonicalize (H12AffineFastState.compose env25849 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound25849 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25850 : List Nat := [2,4,8,1,32,0,128,172,512,172,2048,648,161,649,136,171,648,2185,172,137,649,169,0,3,41,1,2049,648,648,2049,141,33,172,33,648,513]

theorem envBound25850 : H12AffineFastState.Bounded env25850 := by
  intro p hp
  have h : env25850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25849_25850 : H12AffineEnvironment.transform 11 648 env25849 = env25850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env25849 == env25850) = true)

theorem identity25850 : scanCanonicalize (H12AffineFastState.compose env25850 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25850 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env25851 : List Nat := [2,4,8,1,32,0,128,172,0,172,2048,136,161,137,136,171,136,2185,172,137,137,169,0,3,41,1,2049,136,136,2049,141,33,172,33,136,1]

theorem envBound25851 : H12AffineFastState.Bounded env25851 := by
  intro p hp
  have h : env25851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25850_25851 : H12AffineEnvironment.transform 8 0 env25850 = env25851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25850 == env25851) = true)

theorem identity25851 : scanCanonicalize (H12AffineFastState.compose env25851 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25852 : List Nat := [2,4,8,1,32,0,8,36,0,36,2048,0,41,1,0,35,0,2049,36,1,1,33,0,3,41,1,2049,0,0,2049,5,33,36,33,0,1]

theorem envBound25852 : H12AffineFastState.Bounded env25852 := by
  intro p hp
  have h : env25852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25851_25852 : H12AffineEnvironment.transform 6 8 env25851 = env25852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25851 == env25852) = true)

theorem identity25852 : scanCanonicalize (H12AffineFastState.compose env25852 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25852 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25853 : List Nat := [2,4,3,1,32,0,3,36,0,36,2048,0,34,1,0,35,0,2049,36,1,1,33,0,3,34,1,2049,0,0,2049,5,33,36,33,0,1]

theorem envBound25853 : H12AffineFastState.Bounded env25853 := by
  intro p hp
  have h : env25853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25852_25853 : H12AffineEnvironment.transform 2 3 env25852 = env25853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25852 == env25853) = true)

def env25854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,54561,264548,305314,8328,65,316668,269412,281716,35188,1500,272393,256,21792,46213,513]

theorem envBound25854 : H12AffineFastState.Bounded env25854 := by
  intro p hp
  have h : env25854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25826_25854 : H12AffineEnvironment.transform 16 16401 env25826 = env25854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env25826 == env25854) = true)

theorem identity25854 : scanCanonicalize (H12AffineFastState.compose env25854 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound25854 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4161,54561,16,41430,8328,65,56712,5392,17664,35188,1500,8573,256,21792,46213,513]

theorem envBound25855 : H12AffineFastState.Bounded env25855 := by
  intro p hp
  have h : env25855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25854_25855 : H12AffineEnvironment.transform 17 2420 env25854 = env25855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env25854 == env25855) = true)

theorem identity25855 : scanCanonicalize (H12AffineFastState.compose env25855 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound25855 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8202,16401,2420,1024,21896,4161,168,16,29791,8328,65,2049,5392,17664,23805,1500,8573,256,21792,24844,513]

theorem envBound25856 : H12AffineFastState.Bounded env25856 := by
  intro p hp
  have h : env25856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25855_25856 : H12AffineEnvironment.transform 14 21897 env25855 = env25856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env25855 == env25856) = true)

theorem identity25856 : scanCanonicalize (H12AffineFastState.compose env25856 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound25856 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env25857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21897,478,16401,2420,1024,21896,4161,168,16,21899,348,65,2049,5392,17664,23805,1500,169,256,21792,16600,513]

theorem envBound25857 : H12AffineFastState.Bounded env25857 := by
  intro p hp
  have h : env25857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25856_25857 : H12AffineEnvironment.transform 12 468 env25856 = env25857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env25856 == env25857) = true)

theorem identity25857 : scanCanonicalize (H12AffineFastState.compose env25857 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound25857 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,1,478,5529,2420,1024,0,4161,168,16,3,348,65,2049,5392,4232,2421,1500,169,256,168,5456,513]

theorem envBound25858 : H12AffineFastState.Bounded env25858 := by
  intro p hp
  have h : env25858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25857_25858 : H12AffineEnvironment.transform 13 5512 env25857 = env25858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env25857 == env25858) = true)

theorem identity25858 : scanCanonicalize (H12AffineFastState.compose env25858 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound25858 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env25859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1432,468,16,1,478,1,2420,1024,0,1497,168,16,3,348,65,2049,136,1296,2421,1500,169,256,168,200,513]

theorem envBound25859 : H12AffineFastState.Bounded env25859 := by
  intro p hp
  have h : env25859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25858_25859 : H12AffineEnvironment.transform 11 1432 env25858 = env25859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env25858 == env25859) = true)

theorem identity25859 : scanCanonicalize (H12AffineFastState.compose env25859 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound25859 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env25860 : List Nat := [2,4,8,16,32,64,128,256,512,167,2048,319,468,16,1,478,1,2420,167,0,382,168,16,3,348,65,2049,136,439,2421,379,169,256,168,200,513]

theorem envBound25860 : H12AffineFastState.Bounded env25860 := by
  intro p hp
  have h : env25860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25859_25860 : H12AffineEnvironment.transform 9 167 env25859 = env25860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env25859 == env25860) = true)

theorem identity25860 : scanCanonicalize (H12AffineFastState.compose env25860 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound25860 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env25861 : List Nat := [2,4,8,16,32,64,128,62,512,167,2048,1,234,16,1,224,1,2122,167,0,64,168,16,3,98,65,2049,136,137,2123,69,169,62,168,200,513]

theorem envBound25861 : H12AffineFastState.Bounded env25861 := by
  intro p hp
  have h : env25861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25860_25861 : H12AffineEnvironment.transform 7 62 env25860 = env25861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env25860 == env25861) = true)

def env25862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513204,510137,8328,65,2409660,2509876,396389,2136373,2102685,2373705,256,21792,46213,2175562]

theorem envBound25862 : H12AffineFastState.Bounded env25862 := by
  intro p hp
  have h : env25862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25782_25862 : H12AffineEnvironment.transform 21 169265 env25782 = env25862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env25782 == env25862) = true)

def env25863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,510137,8328,65,316668,416884,396389,35189,1501,272393,256,21792,46213,74250]

theorem envBound25863 : H12AffineFastState.Bounded env25863 := by
  intro p hp
  have h : env25863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25862_25863 : H12AffineEnvironment.transform 20 4160 env25862 = env25863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25862 == env25863) = true)

theorem identity25863 : scanCanonicalize (H12AffineFastState.compose env25863 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound25863 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,169265,412020,400486,8328,65,316668,416884,396389,35189,1501,272393,256,21792,46213,63189]

theorem envBound25864 : H12AffineFastState.Bounded env25864 := by
  intro p hp
  have h : env25864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25863_25864 : H12AffineEnvironment.transform 15 54495 env25863 = env25864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env25863 == env25864) = true)

def env25865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1024,32769,4160,54641,264500,285734,8328,65,316668,269364,281637,35189,1501,272393,256,21792,46213,63189]

theorem envBound25865 : H12AffineFastState.Bounded env25865 := by
  intro p hp
  have h : env25865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25864_25865 : H12AffineEnvironment.transform 16 16448 env25864 = env25865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env25864 == env25865) = true)

theorem identity25865 : scanCanonicalize (H12AffineFastState.compose env25865 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound25865 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,56572,1024,32769,4160,54641,54728,32986,8328,65,2048,49352,37081,35189,1501,62709,256,21792,46213,63189]

theorem envBound25866 : H12AffineFastState.Bounded env25866 := by
  intro p hp
  have h : env25866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25865_25866 : H12AffineEnvironment.transform 17 56572 env25865 = env25866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env25865 == env25866) = true)

theorem identity25866 : scanCanonicalize (H12AffineFastState.compose env25866 (packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound25866 : packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS < 2^1333 := by decide +kernel

def env25867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,32768,33019,5220,35032,1024,32769,4160,33109,33260,32986,8328,65,2048,38124,37081,35189,1501,41169,256,260,46213,41713]

theorem envBound25867 : H12AffineFastState.Bounded env25867 := by
  intro p hp
  have h : env25867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25866_25867 : H12AffineEnvironment.transform 13 5156 env25866 = env25867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env25866 == env25867) = true)

theorem identity25867 : scanCanonicalize (H12AffineFastState.compose env25867 (packedSelected [1,2,3,5,6,7,8,9,10,11,16,19,22,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25867 : packedSelected [1,2,3,5,6,7,8,9,10,11,16,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env25868 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,32768,33019,5220,35032,1024,32769,4160,32881,32968,32986,8328,65,2048,38124,37081,34897,1273,41169,36,32,46213,41713]

theorem envBound25868 : H12AffineFastState.Bounded env25868 := by
  intro p hp
  have h : env25868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25867_25868 : H12AffineEnvironment.transform 7 36 env25867 = env25868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25867 == env25868) = true)

theorem identity25868 : scanCanonicalize (H12AffineFastState.compose env25868 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound25868 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env25869 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,8192,5156,32768,32802,5220,34817,1024,32769,4160,32881,32785,32771,8273,65,2048,37941,36864,34897,1056,40968,36,32,46172,41512]

theorem envBound25869 : H12AffineFastState.Bounded env25869 := by
  intro p hp
  have h : env25869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25868_25869 : H12AffineEnvironment.transform 6 89 env25868 = env25869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env25868 == env25869) = true)

theorem identity25869 : scanCanonicalize (H12AffineFastState.compose env25869 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound25869 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env25870 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,5156,32768,32802,5220,34817,1024,32769,4160,32881,32785,32771,41,65,2048,37941,36864,34897,1056,32880,36,32,37924,33360]

theorem envBound25870 : H12AffineFastState.Bounded env25870 := by
  intro p hp
  have h : env25870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25869_25870 : H12AffineEnvironment.transform 12 120 env25869 = env25870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env25869 == env25870) = true)

theorem identity25870 : scanCanonicalize (H12AffineFastState.compose env25870 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25870 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25871 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,32768,32802,5172,34817,1024,32769,4112,32801,32785,32771,41,17,2048,37941,36864,34817,1056,32800,36,32,37924,33280]

theorem envBound25871 : H12AffineFastState.Bounded env25871 := by
  intro p hp
  have h : env25871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25870_25871 : H12AffineEnvironment.transform 5 16 env25870 = env25871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25870 == env25871) = true)

theorem identity25871 : scanCanonicalize (H12AffineFastState.compose env25871 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25871 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env25872 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,32768,32771,5141,34817,1024,32769,4112,32768,32785,32771,8,17,2048,37908,36864,34817,1025,32769,5,1,37893,33280]

theorem envBound25872 : H12AffineFastState.Bounded env25872 := by
  intro p hp
  have h : env25872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25871_25872 : H12AffineEnvironment.transform 4 1 env25871 = env25872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25871 == env25872) = true)

theorem identity25872 : scanCanonicalize (H12AffineFastState.compose env25872 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25873 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,1,2,5141,2048,1024,0,4112,1,16,2,8,17,2048,5141,4097,2048,1025,0,5,1,5124,513]

theorem envBound25873 : H12AffineFastState.Bounded env25873 := by
  intro p hp
  have h : env25873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25872_25873 : H12AffineEnvironment.transform 14 1 env25872 = env25873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25872 == env25873) = true)

def env25874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1024,32769,4160,54640,264501,285735,8328,65,316668,269365,281636,35189,1501,272393,256,21792,46213,63189]

theorem envBound25874 : H12AffineFastState.Bounded env25874 := by
  intro p hp
  have h : env25874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25864_25874 : H12AffineEnvironment.transform 16 16449 env25864 = env25874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env25864 == env25874) = true)

theorem identity25874 : scanCanonicalize (H12AffineFastState.compose env25874 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound25874 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,56437,1024,32769,4160,54640,54592,32850,8328,65,2185,49216,36945,35189,1501,62588,256,21792,46213,63189]

theorem envBound25875 : H12AffineFastState.Bounded env25875 := by
  intro p hp
  have h : env25875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25874_25875 : H12AffineEnvironment.transform 17 56437 env25874 = env25875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env25874 == env25875) = true)

theorem identity25875 : scanCanonicalize (H12AffineFastState.compose env25875 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound25875 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env25876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,30163,16449,32121,1024,8461,4160,29820,29772,8542,8328,65,2185,24908,12637,10361,1501,21872,256,21792,5513,22489]

theorem envBound25876 : H12AffineFastState.Bounded env25876 := by
  intro p hp
  have h : env25876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25875_25876 : H12AffineEnvironment.transform 14 8460 env25875 = env25876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env25875 == env25876) = true)

theorem identity25876 : scanCanonicalize (H12AffineFastState.compose env25876 (packedSelected [1,2,3,4,5,6,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound25876 : packedSelected [1,2,3,4,5,6,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env25877 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8460,29962,16449,32121,1024,8461,4160,29820,29772,8542,8273,65,2128,24908,12637,10361,1284,21872,256,21792,5456,22272]

theorem envBound25877 : H12AffineFastState.Bounded env25877 := by
  intro p hp
  have h : env25877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25876_25877 : H12AffineEnvironment.transform 6 89 env25876 = env25877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env25876 == env25877) = true)

def env25878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,510137,8328,65,316669,416885,396389,35188,1500,272392,256,21792,46213,74251]

theorem envBound25878 : H12AffineFastState.Bounded env25878 := by
  intro p hp
  have h : env25878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25862_25878 : H12AffineEnvironment.transform 20 4161 env25862 = env25878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25862 == env25878) = true)

theorem identity25878 : scanCanonicalize (H12AffineFastState.compose env25878 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound25878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,169265,73754,41430,8328,65,245138,79130,91402,35188,1500,213351,256,21792,46213,74251]

theorem envBound25879 : H12AffineFastState.Bounded env25879 := by
  intro p hp
  have h : env25879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25878_25879 : H12AffineEnvironment.transform 17 223599 env25878 = env25879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env25878 == env25879) = true)

def env25880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4113,169265,73754,41350,8328,17,245138,79130,91402,35108,1420,213303,256,21792,46213,74251]

theorem envBound25880 : H12AffineFastState.Bounded env25880 := by
  intro p hp
  have h : env25880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25879_25880 : H12AffineEnvironment.transform 5 16 env25879 = env25880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25879 == env25880) = true)

theorem identity25880 : scanCanonicalize (H12AffineFastState.compose env25880 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound25880 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env25881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13341,89378,1024,32769,4113,41260,73754,41350,8328,17,100751,79130,91402,35108,1420,95530,256,21792,46213,74251]

theorem envBound25881 : H12AffineFastState.Bounded env25881 := by
  intro p hp
  have h : env25881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25880_25881 : H12AffineEnvironment.transform 16 13341 env25880 = env25881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env25880 == env25881) = true)

theorem identity25881 : scanCanonicalize (H12AffineFastState.compose env25881 (packedSelected [1,3,5,8,14,18,19,23,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25881 : packedSelected [1,3,5,8,14,18,19,23,31,35] rootPS < 2^1333 := by decide +kernel

def env25882 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,65536,13341,89378,1024,21760,4113,29741,73754,29831,8328,17,89230,79130,91402,23589,1420,95530,256,21792,24964,74251]

theorem envBound25882 : H12AffineFastState.Bounded env25882 := by
  intro p hp
  have h : env25882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25881_25882 : H12AffineEnvironment.transform 14 21761 env25881 = env25882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25881 == env25882) = true)

theorem identity25882 : scanCanonicalize (H12AffineFastState.compose env25882 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound25882 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env25883 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,8322,13341,32160,1024,21760,4113,29741,152,29831,8328,17,31756,5528,17800,23589,1420,21928,256,21792,24964,649]

theorem envBound25883 : H12AffineFastState.Bounded env25883 := by
  intro p hp
  have h : env25883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25882_25883 : H12AffineEnvironment.transform 15 8322 env25882 = env25883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env25882 == env25883) = true)

theorem identity25883 : scanCanonicalize (H12AffineFastState.compose env25883 (packedSelected [0,1,2,6,7,8,12,15,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound25883 : packedSelected [0,1,2,6,7,8,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env25884 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,136,8322,13341,10281,1024,137,4113,8612,152,8462,8328,17,10629,5528,4097,2476,1420,33,256,169,13325,649]

theorem envBound25884 : H12AffineFastState.Bounded env25884 := by
  intro p hp
  have h : env25884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25883_25884 : H12AffineEnvironment.transform 13 5513 env25883 = env25884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env25883 == env25884) = true)

theorem identity25884 : scanCanonicalize (H12AffineFastState.compose env25884 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25884 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25885 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5513,136,399,5392,2340,1024,137,4113,169,152,3,389,17,2184,5528,4097,2476,1420,33,256,169,5376,649]

theorem envBound25885 : H12AffineFastState.Bounded env25885 := by
  intro p hp
  have h : env25885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25884_25885 : H12AffineEnvironment.transform 12 269 env25884 = env25885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25884 == env25885) = true)

theorem identity25885 : scanCanonicalize (H12AffineFastState.compose env25885 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25885 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env25886 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1024,0,4113,32,17,3,268,17,2049,5393,4097,2341,1285,33,256,32,5376,512]

theorem envBound25886 : H12AffineFastState.Bounded env25886 := by
  intro p hp
  have h : env25886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25885_25886 : H12AffineEnvironment.transform 6 9 env25885 = env25886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25885 == env25886) = true)

theorem identity25886 : scanCanonicalize (H12AffineFastState.compose env25886 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25887 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5376,1,262,5392,2309,1024,0,4113,1,17,3,268,17,2049,5393,4097,2308,1285,0,256,1,5376,512]

theorem envBound25887 : H12AffineFastState.Bounded env25887 := by
  intro p hp
  have h : env25887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25886_25887 : H12AffineEnvironment.transform 4 1 env25886 = env25887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25886 == env25887) = true)

theorem identity25887 : scanCanonicalize (H12AffineFastState.compose env25887 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25887 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25888 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5125,1,3,5141,2048,1024,0,4113,1,17,3,9,17,2049,5140,4097,2049,1024,0,5,1,5125,512]

theorem envBound25888 : H12AffineFastState.Bounded env25888 := by
  intro p hp
  have h : env25888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25887_25888 : H12AffineEnvironment.transform 7 5 env25887 = env25888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25887 == env25888) = true)

def env25889 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4112,169265,73754,41351,8328,16,245138,79130,91402,35109,1421,213302,256,21792,46213,74251]

theorem envBound25889 : H12AffineFastState.Bounded env25889 := by
  intro p hp
  have h : env25889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25879_25889 : H12AffineEnvironment.transform 5 17 env25879 = env25889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25879 == env25889) = true)

theorem identity25889 : scanCanonicalize (H12AffineFastState.compose env25889 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound25889 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env25890 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,56356,1024,32769,4112,73771,73754,41351,8328,16,2184,79130,91402,35109,1421,62508,256,21792,46213,74251]

theorem envBound25890 : H12AffineFastState.Bounded env25890 := by
  intro p hp
  have h : env25890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25889_25890 : H12AffineEnvironment.transform 16 111898 env25889 = env25890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env25889 == env25890) = true)

theorem identity25890 : scanCanonicalize (H12AffineFastState.compose env25890 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound25890 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env25891 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,24981,56356,1024,32769,4112,62628,62613,41351,8328,16,2184,57749,45445,35109,1421,62508,256,21792,46213,63108]

theorem envBound25891 : H12AffineFastState.Bounded env25891 := by
  intro p hp
  have h : env25891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25890_25891 : H12AffineEnvironment.transform 15 54415 env25890 = env25891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env25890 == env25891) = true)

theorem identity25891 : scanCanonicalize (H12AffineFastState.compose env25891 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25891 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env25892 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,30082,24981,32041,1024,8460,4112,21929,21912,138,8328,16,2184,16536,4232,10280,1421,21793,256,21792,5512,22409]

theorem envBound25892 : H12AffineFastState.Bounded env25892 := by
  intro p hp
  have h : env25892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25891_25892 : H12AffineEnvironment.transform 14 8461 env25891 = env25892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env25891 == env25892) = true)

theorem identity25892 : scanCanonicalize (H12AffineFastState.compose env25892 (packedSelected [1,3,4,5,6,8,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound25892 : packedSelected [1,3,4,5,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env25893 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1084,16384,1329,20926,17833,22805,1024,1328,4112,21929,21912,138,1204,16,2184,16536,4232,3092,1421,21793,256,21792,5512,22409]

theorem envBound25893 : H12AffineFastState.Bounded env25893 := by
  intro p hp
  have h : env25893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25892_25893 : H12AffineEnvironment.transform 12 1084 env25892 = env25893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env25892 == env25893) = true)

theorem identity25893 : scanCanonicalize (H12AffineFastState.compose env25893 (packedSelected [1,2,3,5,8,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25893 : packedSelected [1,2,3,5,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env25894 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1084,4113,1329,431,5560,2308,1024,1328,4112,1464,1417,138,1204,16,2184,4233,4232,3092,1421,1328,256,1329,5512,1944]

theorem envBound25894 : H12AffineFastState.Bounded env25894 := by
  intro p hp
  have h : env25894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25893_25894 : H12AffineEnvironment.transform 13 4113 env25893 = env25894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25893 == env25894) = true)

theorem identity25894 : scanCanonicalize (H12AffineFastState.compose env25894 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25894 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env25895 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,1052,4113,1297,399,5528,2308,1024,1296,4112,1432,1417,138,1172,16,2184,4233,4232,3092,1421,1296,256,1297,5512,1944]

theorem envBound25895 : H12AffineFastState.Bounded env25895 := by
  intro p hp
  have h : env25895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25894_25895 : H12AffineEnvironment.transform 4 0 env25894 = env25895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25894 == env25895) = true)

theorem identity25895 : scanCanonicalize (H12AffineFastState.compose env25895 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25895 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25896 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,1052,4113,1297,262,5393,2308,1024,1296,4112,1297,1280,3,1053,16,2049,4096,4097,3092,1284,1296,256,1297,5377,1809]

theorem envBound25896 : H12AffineFastState.Bounded env25896 := by
  intro p hp
  have h : env25896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25895_25896 : H12AffineEnvironment.transform 6 9 env25895 = env25896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25895 == env25896) = true)

theorem identity25896 : scanCanonicalize (H12AffineFastState.compose env25896 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25896 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25897 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,4096,269,4113,0,262,4096,2308,273,1,4112,0,17,3,268,16,2049,4096,4097,2309,21,1,256,0,4112,512]

theorem envBound25897 : H12AffineFastState.Bounded env25897 := by
  intro p hp
  have h : env25897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25896_25897 : H12AffineEnvironment.transform 9 273 env25896 = env25897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25896 == env25897) = true)

theorem identity25897 : scanCanonicalize (H12AffineFastState.compose env25897 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound25897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25898 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,0,269,17,0,262,0,2308,273,1,16,0,17,3,268,16,2049,0,1,2309,21,1,256,0,16,512]

theorem envBound25898 : H12AffineFastState.Bounded env25898 := by
  intro p hp
  have h : env25898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25897_25898 : H12AffineEnvironment.transform 11 0 env25897 = env25898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25897 == env25898) = true)

theorem identity25898 : scanCanonicalize (H12AffineFastState.compose env25898 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound25898 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25899 : List Nat := [2,4,8,16,0,17,9,256,512,273,11,0,269,17,0,262,0,271,273,1,16,0,17,3,268,16,10,0,1,270,21,1,256,0,16,512]

theorem envBound25899 : H12AffineFastState.Bounded env25899 := by
  intro p hp
  have h : env25899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25898_25899 : H12AffineEnvironment.transform 10 11 env25898 = env25899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env25898 == env25899) = true)

def env25900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513205,510137,8328,65,6705548,2509876,396388,2136372,2102684,6729080,256,21793,46212,2175563]

theorem envBound25900 : H12AffineFastState.Bounded env25900 := by
  intro p hp
  have h : env25900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25781_25900 : H12AffineEnvironment.transform 22 2513205 env25781 = env25900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513205 env25781 == env25900) = true)

def env25901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513205,510137,8328,65,2409660,2509876,396388,2136372,2102684,2373704,256,21793,46212,2175563]

theorem envBound25901 : H12AffineFastState.Bounded env25901 := by
  intro p hp
  have h : env25901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25900_25901 : H12AffineEnvironment.transform 21 169264 env25900 = env25901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env25900 == env25901) = true)

def env25902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,510137,8328,65,316668,416884,396388,35188,1500,272392,256,21793,46212,74251]

theorem envBound25902 : H12AffineFastState.Bounded env25902 := by
  intro p hp
  have h : env25902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25901_25902 : H12AffineEnvironment.transform 20 4160 env25901 = env25902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25901 == env25902) = true)

theorem identity25902 : scanCanonicalize (H12AffineFastState.compose env25902 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound25902 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,98780,8328,65,171417,5393,17665,35188,1500,156013,256,21793,46212,74251]

theorem envBound25903 : H12AffineFastState.Bounded env25903 := by
  intro p hp
  have h : env25903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25902_25903 : H12AffineEnvironment.transform 17 149861 env25902 = env25903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env25902 == env25903) = true)

def env25904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,98644,8192,65,171281,5393,17665,35188,1364,156013,256,21793,46092,74251]

theorem envBound25904 : H12AffineFastState.Bounded env25904 := by
  intro p hp
  have h : env25904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25903_25904 : H12AffineEnvironment.transform 6 8 env25903 = env25904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25903 == env25904) = true)

theorem identity25904 : scanCanonicalize (H12AffineFastState.compose env25904 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound25904 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1024,32769,4160,119926,16,98644,8192,65,121943,5393,17665,35188,1364,73771,256,21793,46092,74251]

theorem envBound25905 : H12AffineFastState.Bounded env25905 := by
  intro p hp
  have h : env25905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25904_25905 : H12AffineEnvironment.transform 16 82246 env25904 = env25905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env25904 == env25905) = true)

theorem identity25905 : scanCanonicalize (H12AffineFastState.compose env25905 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound25905 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env25906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,46157,64808,1024,32769,4160,8573,16,29791,8192,65,10588,5393,17665,35188,1364,54560,256,21793,46092,55040]

theorem envBound25906 : H12AffineFastState.Bounded env25906 := by
  intro p hp
  have h : env25906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25905_25906 : H12AffineEnvironment.transform 15 62731 env25905 = env25906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env25905 == env25906) = true)

theorem identity25906 : scanCanonicalize (H12AffineFastState.compose env25906 (packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound25906 : packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,343,16401,2420,1024,29789,4160,8573,16,29791,8192,65,10588,5393,17665,32040,1364,8572,256,21793,16464,9052]

theorem envBound25907 : H12AffineFastState.Bounded env25907 := by
  intro p hp
  have h : env25907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25906_25907 : H12AffineEnvironment.transform 14 29788 env25906 = env25907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env25906 == env25907) = true)

def env25908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,98645,8193,65,171280,5393,17665,35188,1365,156013,256,21793,46093,74251]

theorem envBound25908 : H12AffineFastState.Bounded env25908 := by
  intro p hp
  have h : env25908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25903_25908 : H12AffineEnvironment.transform 6 9 env25903 = env25908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25903 == env25908) = true)

theorem identity25908 : scanCanonicalize (H12AffineFastState.compose env25908 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound25908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,108927,1024,32769,4160,95530,16,98645,8193,65,97546,5393,17665,35188,1365,98679,256,21793,46093,74251]

theorem envBound25909 : H12AffineFastState.Bounded env25909 := by
  intro p hp
  have h : env25909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25908_25909 : H12AffineEnvironment.transform 16 122906 env25908 = env25909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env25908 == env25909) = true)

theorem identity25909 : scanCanonicalize (H12AffineFastState.compose env25909 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25909 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,65536,111946,108927,1024,32769,4160,73850,16,98645,8193,65,75866,5393,4177,35188,1365,98679,256,113,46093,74251]

theorem envBound25910 : H12AffineFastState.Bounded env25910 := by
  intro p hp
  have h : env25910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25909_25910 : H12AffineEnvironment.transform 13 5456 env25909 = env25910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25909 == env25910) = true)

theorem identity25910 : scanCanonicalize (H12AffineFastState.compose env25910 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound25910 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,34,46440,43357,1024,32769,4160,8280,16,33143,8193,65,10360,5393,4177,35188,1365,33109,256,113,46093,8745]

theorem envBound25911 : H12AffineFastState.Bounded env25911 := by
  intro p hp
  have h : env25911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25910_25911 : H12AffineEnvironment.transform 15 34 env25910 = env25911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env25910 == env25911) = true)

theorem identity25911 : scanCanonicalize (H12AffineFastState.compose env25911 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25911 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env25912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,34,37940,34817,1024,32769,4160,260,16,33143,349,65,2340,5393,4177,35188,1365,33109,256,113,38225,885]

theorem envBound25912 : H12AffineFastState.Bounded env25912 := by
  intro p hp
  have h : env25912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25911_25912 : H12AffineEnvironment.transform 12 348 env25911 = env25912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25911 == env25912) = true)

theorem identity25912 : scanCanonicalize (H12AffineFastState.compose env25912 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound25912 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env25913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,81,34,5221,2128,1024,80,4160,260,16,294,349,65,2340,5393,4177,2341,1365,260,256,113,5376,885]

theorem envBound25913 : H12AffineFastState.Bounded env25913 := by
  intro p hp
  have h : env25913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25912_25913 : H12AffineEnvironment.transform 14 81 env25912 = env25913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env25912 == env25913) = true)

theorem identity25913 : scanCanonicalize (H12AffineFastState.compose env25913 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25913 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25914 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,34,5173,2048,1024,0,4112,260,16,294,269,17,2340,5393,4097,2341,1285,260,256,33,5376,805]

theorem envBound25914 : H12AffineFastState.Bounded env25914 := by
  intro p hp
  have h : env25914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25913_25914 : H12AffineEnvironment.transform 5 16 env25913 = env25914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25913 == env25914) = true)

theorem identity25914 : scanCanonicalize (H12AffineFastState.compose env25914 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound25914 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25915 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2049,268,3329,1,34,3124,2048,1024,0,2065,260,16,294,269,17,2340,3344,2048,2341,1285,260,256,33,3329,805]

theorem envBound25915 : H12AffineFastState.Bounded env25915 := by
  intro p hp
  have h : env25915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25914_25915 : H12AffineEnvironment.transform 11 2049 env25914 = env25915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env25914 == env25915) = true)

theorem identity25915 : scanCanonicalize (H12AffineFastState.compose env25915 (packedSelected [1,2,3,5,6,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25915 : packedSelected [1,2,3,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env25916 : List Nat := [2,4,8,16,16,16,9,256,512,1024,2048,2049,268,3329,1,18,3076,2048,1024,0,2065,260,16,278,269,17,2324,3344,2048,2325,1285,260,256,17,3329,789]

theorem envBound25916 : H12AffineFastState.Bounded env25916 := by
  intro p hp
  have h : env25916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25915_25916 : H12AffineEnvironment.transform 4 16 env25915 = env25916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25915 == env25916) = true)

def env25917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,510137,8328,65,316669,416885,396388,35189,1501,272393,256,21793,46212,74250]

theorem envBound25917 : H12AffineFastState.Bounded env25917 := by
  intro p hp
  have h : env25917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25901_25917 : H12AffineEnvironment.transform 20 4161 env25901 = env25917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25901 == env25917) = true)

theorem identity25917 : scanCanonicalize (H12AffineFastState.compose env25917 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound25917 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,156133,412020,474220,8328,65,270376,416885,396388,32160,1501,272393,256,21793,16465,74250]

theorem envBound25918 : H12AffineFastState.Bounded env25918 := by
  intro p hp
  have h : env25918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25917_25918 : H12AffineEnvironment.transform 14 29909 env25917 = env25918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env25917 == env25918) = true)

def env25919 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4113,156085,411940,474172,8328,17,270376,416805,396340,32160,1421,272393,256,21793,16385,74250]

theorem envBound25919 : H12AffineFastState.Bounded env25919 := by
  intro p hp
  have h : env25919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25918_25919 : H12AffineEnvironment.transform 5 16 env25918 = env25919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25918 == env25919) = true)

theorem identity25919 : scanCanonicalize (H12AffineFastState.compose env25919 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215227) := by decide +kernel

theorem selectedBound25919 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,215227,1024,29828,4113,156085,65951,29831,8328,17,223379,70814,83087,32160,1421,221362,256,21793,16385,74250]

theorem envBound25920 : H12AffineFastState.Bounded env25920 := by
  intro p hp
  have h : env25920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25919_25920 : H12AffineEnvironment.transform 17 215227 env25919 = env25920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215227 env25919 == env25920) = true)

theorem identity25920 : scanCanonicalize (H12AffineFastState.compose env25920 (packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound25920 : packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env25921 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,32161,1024,29828,4113,87215,65951,29831,8328,17,23945,70814,83087,32160,1421,21928,256,21793,16385,74250]

theorem envBound25921 : H12AffineFastState.Bounded env25921 := by
  intro p hp
  have h : env25921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25920_25921 : H12AffineEnvironment.transform 16 79130 env25920 = env25921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env25920 == env25921) = true)

theorem identity25921 : scanCanonicalize (H12AffineFastState.compose env25921 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound25921 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env25922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,30083,16537,32161,1024,29828,4113,8492,29724,29831,8328,17,23945,24861,12556,32160,1421,21928,256,21793,16385,22409]

theorem envBound25922 : H12AffineFastState.Bounded env25922 := by
  intro p hp
  have h : env25922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25921_25922 : H12AffineEnvironment.transform 15 30083 env25921 = env25922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env25921 == env25922) = true)

theorem identity25922 : scanCanonicalize (H12AffineFastState.compose env25922 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound25922 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env25923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21760,21510,16537,23588,1024,21761,4113,169,21913,21762,269,17,23945,16536,4233,23589,1421,21928,256,21793,16385,22409]

theorem envBound25923 : H12AffineFastState.Bounded env25923 := by
  intro p hp
  have h : env25923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25922_25923 : H12AffineEnvironment.transform 12 389 env25922 = env25923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env25922 == env25923) = true)

theorem identity25923 : scanCanonicalize (H12AffineFastState.compose env25923 (packedSelected [3,4,5,6,7,11,12,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound25923 : packedSelected [3,4,5,6,7,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env25924 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,389,16384,20633,20895,16537,22973,409,20632,4113,169,20480,20635,269,17,22544,16536,4233,22972,20,20529,256,20664,16385,21008]

theorem envBound25924 : H12AffineFastState.Bounded env25924 := by
  intro p hp
  have h : env25924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25923_25924 : H12AffineEnvironment.transform 9 409 env25923 = env25924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env25923 == env25924) = true)

theorem identity25924 : scanCanonicalize (H12AffineFastState.compose env25924 (packedSelected [1,2,4,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound25924 : packedSelected [1,2,4,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env25925 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,389,4112,137,399,4233,2477,409,136,4113,169,16,139,269,17,2048,4232,4233,2476,20,33,256,168,4113,512]

theorem envBound25925 : H12AffineFastState.Bounded env25925 := by
  intro p hp
  have h : env25925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25924_25925 : H12AffineEnvironment.transform 13 4112 env25924 = env25925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env25924 == env25925) = true)

theorem identity25925 : scanCanonicalize (H12AffineFastState.compose env25925 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound25925 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25926 : List Nat := [2,4,8,16,32,16,40,256,512,305,2048,4096,301,4112,33,295,4129,2309,305,32,4113,1,16,35,269,17,2048,4128,4129,2308,20,33,256,0,4113,512]

theorem envBound25926 : H12AffineFastState.Bounded env25926 := by
  intro p hp
  have h : env25926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25925_25926 : H12AffineEnvironment.transform 6 40 env25925 = env25926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env25925 == env25926) = true)

theorem identity25926 : scanCanonicalize (H12AffineFastState.compose env25926 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound25926 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25927 : List Nat := [2,4,8,16,32,16,40,256,512,305,2048,2325,301,2309,33,295,2356,2309,305,32,2308,1,16,35,269,17,2048,2357,2356,2308,20,33,256,0,2308,512]

theorem envBound25927 : H12AffineFastState.Bounded env25927 := by
  intro p hp
  have h : env25927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25926_25927 : H12AffineEnvironment.transform 11 2325 env25926 = env25927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env25926 == env25927) = true)

theorem identity25927 : scanCanonicalize (H12AffineFastState.compose env25927 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25927 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env25928 : List Nat := [2,4,8,16,32,16,40,256,512,305,0,277,301,261,33,295,308,261,305,32,260,1,16,35,269,17,0,309,308,260,20,33,256,0,260,512]

theorem envBound25928 : H12AffineFastState.Bounded env25928 := by
  intro p hp
  have h : env25928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25927_25928 : H12AffineEnvironment.transform 10 0 env25927 = env25928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25927 == env25928) = true)

theorem identity25928 : scanCanonicalize (H12AffineFastState.compose env25928 (packedSelected [3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25928 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env25929 : List Nat := [2,4,8,16,32,16,40,36,512,21,0,49,9,33,33,3,16,33,21,32,32,1,16,35,41,17,0,17,16,32,20,33,36,0,32,512]

theorem envBound25929 : H12AffineFastState.Bounded env25929 := by
  intro p hp
  have h : env25929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25928_25929 : H12AffineEnvironment.transform 7 36 env25928 = env25929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25928 == env25929) = true)

theorem identity25929 : scanCanonicalize (H12AffineFastState.compose env25929 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25929 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env25930 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,1,1,3,16,1,21,0,0,1,16,3,9,17,0,17,16,0,20,1,4,0,0,512]

theorem envBound25930 : H12AffineFastState.Bounded env25930 := by
  intro p hp
  have h : env25930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25929_25930 : H12AffineEnvironment.transform 4 0 env25929 = env25930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25929 == env25930) = true)

theorem identity25930 : scanCanonicalize (H12AffineFastState.compose env25930 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25931 : List Nat := [2,4,8,16,0,16,8,4,1,21,0,17,9,1,1,3,16,1,21,0,0,1,16,3,9,17,0,17,16,0,20,1,4,0,0,1]

theorem envBound25931 : H12AffineFastState.Bounded env25931 := by
  intro p hp
  have h : env25931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25930_25931 : H12AffineEnvironment.transform 8 1 env25930 = env25931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25930 == env25931) = true)

theorem identity25931 : scanCanonicalize (H12AffineFastState.compose env25931 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25932 : List Nat := [2,4,8,15,0,15,8,4,1,10,0,14,9,1,1,3,15,1,10,0,0,1,15,3,9,14,0,14,15,0,11,1,4,0,0,1]

theorem envBound25932 : H12AffineFastState.Bounded env25932 := by
  intro p hp
  have h : env25932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25931_25932 : H12AffineEnvironment.transform 3 15 env25931 = env25932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25931 == env25932) = true)

def env25933 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4112,156084,411941,474173,8328,16,270376,416804,396341,32160,1420,272393,256,21793,16384,74250]

theorem envBound25933 : H12AffineFastState.Bounded env25933 := by
  intro p hp
  have h : env25933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25918_25933 : H12AffineEnvironment.transform 5 17 env25918 = env25933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25918 == env25933) = true)

theorem identity25933 : scanCanonicalize (H12AffineFastState.compose env25933 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound25933 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25934 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,215090,1024,29829,4112,156084,65815,29711,8328,16,223258,70678,82951,32160,1420,221243,256,21793,16384,74250]

theorem envBound25934 : H12AffineFastState.Bounded env25934 := by
  intro p hp
  have h : env25934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25933_25934 : H12AffineEnvironment.transform 17 215090 env25933 = env25934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env25933 == env25934) = true)

theorem identity25934 : scanCanonicalize (H12AffineFastState.compose env25934 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound25934 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25935 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,29962,131072,146744,1024,29829,4112,156084,29725,29711,8328,16,138512,24860,12557,32160,1420,136497,256,21793,16384,22272]

theorem envBound25935 : H12AffineFastState.Bounded env25935 := by
  intro p hp
  have h : env25935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25934_25935 : H12AffineEnvironment.transform 15 29962 env25934 = env25935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env25934 == env25935) = true)

theorem identity25935 : scanCanonicalize (H12AffineFastState.compose env25935 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25935 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env25936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8203,131072,146744,1024,8580,4112,144565,8476,8462,8328,16,138512,13341,12557,10401,1420,136497,256,32,5377,513]

theorem envBound25936 : H12AffineFastState.Bounded env25936 := by
  intro p hp
  have h : env25936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25935_25936 : H12AffineEnvironment.transform 13 5377 env25935 = env25936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25935 == env25936) = true)

theorem identity25936 : scanCanonicalize (H12AffineFastState.compose env25936 (packedSelected [2,6,17] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound25936 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env25937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8203,5529,10401,1024,8580,4112,8492,8476,8462,8328,16,2185,13341,12557,10401,1420,168,256,32,5377,513]

theorem envBound25937 : H12AffineFastState.Bounded env25937 := by
  intro p hp
  have h : env25937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25936_25937 : H12AffineEnvironment.transform 16 5529 env25936 = env25937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env25936 == env25937) = true)

theorem identity25937 : scanCanonicalize (H12AffineFastState.compose env25937 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound25937 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env25938 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,8192,2476,8581,8203,2356,10401,1024,8580,3261,8492,8476,8462,8328,16,2185,10416,11680,10401,1420,168,256,32,2476,513]

theorem envBound25938 : H12AffineFastState.Bounded env25938 := by
  intro p hp
  have h : env25938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25937_25938 : H12AffineEnvironment.transform 11 3245 env25937 = env25938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env25937 == env25938) = true)

theorem identity25938 : scanCanonicalize (H12AffineFastState.compose env25938 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25938 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25939 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,8192,2341,8460,8203,2356,10280,1024,8461,3124,8492,8476,8462,8193,16,2048,10297,11561,10280,1285,33,256,32,2341,513]

theorem envBound25939 : H12AffineFastState.Bounded env25939 := by
  intro p hp
  have h : env25939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25938_25939 : H12AffineEnvironment.transform 6 9 env25938 = env25939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25938 == env25939) = true)

theorem identity25939 : scanCanonicalize (H12AffineFastState.compose env25939 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound25939 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env25940 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,1052,2341,1296,1047,2356,3124,1024,1297,3124,1328,1280,1298,1053,16,2048,3109,2357,3124,1285,33,256,32,2341,513]

theorem envBound25940 : H12AffineFastState.Bounded env25940 := by
  intro p hp
  have h : env25940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25939_25940 : H12AffineEnvironment.transform 12 1052 env25939 = env25940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env25939 == env25940) = true)

theorem identity25940 : scanCanonicalize (H12AffineFastState.compose env25940 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25940 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25941 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2357,269,2341,1,262,2356,2341,273,0,2341,33,17,3,268,16,2048,2356,2357,2341,20,33,256,32,2341,513]

theorem envBound25941 : H12AffineFastState.Bounded env25941 := by
  intro p hp
  have h : env25941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25940_25941 : H12AffineEnvironment.transform 9 273 env25940 = env25941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25940 == env25941) = true)

theorem identity25941 : scanCanonicalize (H12AffineFastState.compose env25941 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25941 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25942 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,40,2048,1,35,2065,2048,52,0,2048,33,17,3,41,16,2048,2065,2064,2048,20,33,37,32,2048,513]

theorem envBound25942 : H12AffineFastState.Bounded env25942 := by
  intro p hp
  have h : env25942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25941_25942 : H12AffineEnvironment.transform 7 37 env25941 = env25942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25941 == env25942) = true)

theorem identity25942 : scanCanonicalize (H12AffineFastState.compose env25942 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound25942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25943 : List Nat := [2,4,8,16,32,17,9,37,33,52,2048,2064,40,2048,1,35,2065,2048,52,0,2048,33,17,3,41,16,2048,2065,2064,2048,20,33,37,32,2048,32]

theorem envBound25943 : H12AffineFastState.Bounded env25943 := by
  intro p hp
  have h : env25943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25942_25943 : H12AffineEnvironment.transform 8 33 env25942 = env25943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env25942 == env25943) = true)

theorem identity25943 : scanCanonicalize (H12AffineFastState.compose env25943 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound25943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25944 : List Nat := [2,4,8,16,32,17,9,37,33,52,33,49,40,33,1,35,48,33,52,0,33,33,17,3,41,16,33,48,49,33,20,33,37,32,33,32]

theorem envBound25944 : H12AffineFastState.Bounded env25944 := by
  intro p hp
  have h : env25944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25943_25944 : H12AffineEnvironment.transform 10 33 env25943 = env25944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env25943 == env25944) = true)

def env25945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513205,510137,8328,65,2409661,2509876,396388,2136372,2102684,2373705,256,21793,46212,2175563]

theorem envBound25945 : H12AffineFastState.Bounded env25945 := by
  intro p hp
  have h : env25945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25900_25945 : H12AffineEnvironment.transform 21 169265 env25900 = env25945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env25900 == env25945) = true)

def env25946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,510137,8328,65,316669,416884,396388,35188,1500,272393,256,21793,46212,74251]

theorem envBound25946 : H12AffineFastState.Bounded env25946 := by
  intro p hp
  have h : env25946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25945_25946 : H12AffineEnvironment.transform 20 4160 env25945 = env25946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25945 == env25946) = true)

def env25947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169265,155997,254097,8328,65,64725,160860,140364,35188,1500,33,256,21793,46212,74251]

theorem envBound25947 : H12AffineFastState.Bounded env25947 := by
  intro p hp
  have h : env25947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25946_25947 : H12AffineEnvironment.transform 17 10280 env25946 = env25947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25946 == env25947) = true)

def env25948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21793,41293,73857,8328,65,64725,46156,58460,35188,1500,33,256,21793,46212,74251]

theorem envBound25948 : H12AffineFastState.Bounded env25948 := by
  intro p hp
  have h : env25948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25947_25948 : H12AffineEnvironment.transform 16 49168 env25947 = env25948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25947 == env25948) = true)

theorem identity25948 : scanCanonicalize (H12AffineFastState.compose env25948 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound25948 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,49168,10280,1024,32769,4160,21793,41293,41311,8328,65,64725,46156,58460,35188,1500,33,256,21793,46212,41941]

theorem envBound25949 : H12AffineFastState.Bounded env25949 := by
  intro p hp
  have h : env25949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25948_25949 : H12AffineEnvironment.transform 15 33246 env25948 = env25949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env25948 == env25949) = true)

theorem identity25949 : scanCanonicalize (H12AffineFastState.compose env25949 (packedSelected [5,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound25949 : packedSelected [5,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env25950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29004,28818,12636,10280,1024,29005,4160,21793,20481,20499,8328,65,3481,17664,5392,30776,1500,33,256,21793,17864,21145]

theorem envBound25950 : H12AffineFastState.Bounded env25950 := by
  intro p hp
  have h : env25950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25949_25950 : H12AffineEnvironment.transform 14 29004 env25949 = env25950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env25949 == env25950) = true)

theorem identity25950 : scanCanonicalize (H12AffineFastState.compose env25950 (packedSelected [1,3,4,7,8,9,10,11,16,18,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound25950 : packedSelected [1,3,4,7,8,9,10,11,16,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env25951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,20924,20578,4524,2264,1024,20925,4160,21793,20481,20499,120,65,3481,17664,5392,22728,1500,33,256,21793,17864,21145]

theorem envBound25951 : H12AffineFastState.Bounded env25951 := by
  intro p hp
  have h : env25951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25950_25951 : H12AffineEnvironment.transform 12 240 env25950 = env25951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env25950 == env25951) = true)

theorem identity25951 : scanCanonicalize (H12AffineFastState.compose env25951 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound25951 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25952 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,240,16384,20924,20578,4524,2264,101,20925,4160,20804,20481,20499,120,65,2556,16741,4469,22728,441,33,256,20804,16813,21145]

theorem envBound25952 : H12AffineFastState.Bounded env25952 := by
  intro p hp
  have h : env25952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25951_25952 : H12AffineEnvironment.transform 9 101 env25951 = env25952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env25951 == env25952) = true)

theorem identity25952 : scanCanonicalize (H12AffineFastState.compose env25952 (packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound25952 : packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env25953 : List Nat := [2,4,8,16,32,64,89,256,512,101,2048,4096,41,16384,20837,20578,4469,2049,101,20836,4160,20804,20481,20499,120,65,2341,16741,4469,22545,352,33,256,20804,16756,21056]

theorem envBound25953 : H12AffineFastState.Bounded env25953 := by
  intro p hp
  have h : env25953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25952_25953 : H12AffineEnvironment.transform 6 89 env25952 = env25953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env25952 == env25953) = true)

theorem identity25953 : scanCanonicalize (H12AffineFastState.compose env25953 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25953 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env25954 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,4096,41,16384,20544,20578,4176,2049,101,20545,4160,20577,20481,20499,120,65,2048,16448,4176,22545,69,33,37,20577,16465,21056]

theorem envBound25954 : H12AffineFastState.Bounded env25954 := by
  intro p hp
  have h : env25954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25953_25954 : H12AffineEnvironment.transform 7 37 env25953 = env25954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25953 == env25954) = true)

theorem identity25954 : scanCanonicalize (H12AffineFastState.compose env25954 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25954 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env25955 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,4096,41,4113,81,115,4176,2049,101,80,4160,112,16,2,120,65,2048,4177,4176,2048,69,33,37,112,4160,593]

theorem envBound25955 : H12AffineFastState.Bounded env25955 := by
  intro p hp
  have h : env25955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25954_25955 : H12AffineEnvironment.transform 13 4113 env25954 = env25955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25954 == env25955) = true)

theorem identity25955 : scanCanonicalize (H12AffineFastState.compose env25955 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound25955 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25956 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,2049,41,2064,81,115,2129,2049,101,80,2113,112,16,2,120,65,2048,2128,2129,2048,69,33,37,112,2113,593]

theorem envBound25956 : H12AffineFastState.Bounded env25956 := by
  intro p hp
  have h : env25956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25955_25956 : H12AffineEnvironment.transform 11 2049 env25955 = env25956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env25955 == env25956) = true)

theorem identity25956 : scanCanonicalize (H12AffineFastState.compose env25956 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound25956 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env25957 : List Nat := [2,4,8,16,32,64,89,37,512,101,96,97,41,112,81,115,49,97,101,80,33,112,16,2,120,65,96,48,49,96,69,33,37,112,33,593]

theorem envBound25957 : H12AffineFastState.Bounded env25957 := by
  intro p hp
  have h : env25957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25956_25957 : H12AffineEnvironment.transform 10 96 env25956 = env25957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env25956 == env25957) = true)

theorem identity25957 : scanCanonicalize (H12AffineFastState.compose env25957 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25957 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25958 : List Nat := [2,4,8,16,32,0,25,37,512,37,32,33,41,48,17,51,49,33,37,16,33,48,16,2,56,1,32,48,49,32,5,33,37,48,33,529]

theorem envBound25958 : H12AffineFastState.Bounded env25958 := by
  intro p hp
  have h : env25958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25957_25958 : H12AffineEnvironment.transform 5 0 env25957 = env25958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25957 == env25958) = true)

theorem identity25958 : scanCanonicalize (H12AffineFastState.compose env25958 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25958 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env25959 : List Nat := [2,4,8,1,32,0,8,37,512,37,32,33,41,33,0,34,32,33,37,1,33,33,1,2,41,1,32,33,32,32,5,33,37,33,33,512]

theorem envBound25959 : H12AffineFastState.Bounded env25959 := by
  intro p hp
  have h : env25959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25958_25959 : H12AffineEnvironment.transform 3 1 env25958 = env25959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25958 == env25959) = true)

theorem identity25959 : scanCanonicalize (H12AffineFastState.compose env25959 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound25959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25960 : List Nat := [2,4,8,1,32,0,8,37,33,37,32,33,41,33,0,34,32,33,37,1,33,33,1,2,41,1,32,33,32,32,5,33,37,33,33,33]

theorem envBound25960 : H12AffineFastState.Bounded env25960 := by
  intro p hp
  have h : env25960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25959_25960 : H12AffineEnvironment.transform 8 33 env25959 = env25960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env25959 == env25960) = true)

theorem identity25960 : scanCanonicalize (H12AffineFastState.compose env25960 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25961 : List Nat := [2,4,7,1,32,0,7,37,33,37,32,33,38,33,0,34,32,33,37,1,33,33,1,2,38,1,32,33,32,32,5,33,37,33,33,33]

theorem envBound25961 : H12AffineFastState.Bounded env25961 := by
  intro p hp
  have h : env25961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25960_25961 : H12AffineEnvironment.transform 2 7 env25960 = env25961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25960 == env25961) = true)

theorem identity25961 : scanCanonicalize (H12AffineFastState.compose env25961 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25962 : List Nat := [2,4,7,1,0,0,7,5,1,5,0,1,6,1,0,2,0,1,5,1,1,1,1,2,6,1,0,1,0,0,5,1,5,1,1,1]

theorem envBound25962 : H12AffineFastState.Bounded env25962 := by
  intro p hp
  have h : env25962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25961_25962 : H12AffineEnvironment.transform 4 0 env25961 = env25962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25961 == env25962) = true)

def env25963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21792,41292,73856,8328,65,64725,46157,58461,35188,1500,33,256,21793,46212,74251]

theorem envBound25963 : H12AffineFastState.Bounded env25963 := by
  intro p hp
  have h : env25963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25947_25963 : H12AffineEnvironment.transform 16 49169 env25947 = env25963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25947 == env25963) = true)

theorem identity25963 : scanCanonicalize (H12AffineFastState.compose env25963 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound25963 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49169,10280,1024,32769,4160,21792,41292,41431,8328,65,64725,46157,58461,35188,1500,33,256,21793,46212,41820]

theorem envBound25964 : H12AffineFastState.Bounded env25964 := by
  intro p hp
  have h : env25964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25963_25964 : H12AffineEnvironment.transform 15 33111 env25963 = env25964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env25963 == env25964) = true)

theorem identity25964 : scanCanonicalize (H12AffineFastState.compose env25964 (packedSelected [0,1,4,5,7,8,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound25964 : packedSelected [0,1,4,5,7,8,22,24] rootPS < 2^1333 := by decide +kernel

def env25965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,80,263,16449,10280,1024,81,4160,21792,8476,8583,8328,65,31877,13341,25613,2340,1500,33,256,21793,13524,8972]

theorem envBound25965 : H12AffineFastState.Bounded env25965 := by
  intro p hp
  have h : env25965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25964_25965 : H12AffineEnvironment.transform 14 80 env25964 = env25965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env25964 == env25965) = true)

theorem identity25965 : scanCanonicalize (H12AffineFastState.compose env25965 (packedSelected [0,1,2,6,7,8,11,16,18,26] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound25965 : packedSelected [0,1,2,6,7,8,11,16,18,26] rootPS < 2^1333 := by decide +kernel

def env25966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,80,263,16449,3392,1024,81,4160,21792,1140,1263,1504,65,23021,4469,16741,2340,1500,33,256,21793,4540,1636]

theorem envBound25966 : H12AffineFastState.Bounded env25966 := by
  intro p hp
  have h : env25966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25965_25966 : H12AffineEnvironment.transform 12 1384 env25965 = env25966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env25965 == env25966) = true)

theorem identity25966 : scanCanonicalize (H12AffineFastState.compose env25966 (packedSelected [2,3,4,5,6,10,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 4588) := by decide +kernel

theorem selectedBound25966 : packedSelected [2,3,4,5,6,10,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env25967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4588,80,263,4525,3392,1024,81,4160,1228,1140,1263,1504,65,2049,4469,4233,2340,1500,33,256,1229,4540,1636]

theorem envBound25967 : H12AffineFastState.Bounded env25967 := by
  intro p hp
  have h : env25967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25966_25967 : H12AffineEnvironment.transform 13 4588 env25966 = env25967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4588 env25966 == env25967) = true)

theorem identity25967 : scanCanonicalize (H12AffineFastState.compose env25967 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound25967 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env25968 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,388,4588,80,263,4525,2476,236,81,4160,32,152,3,268,65,2049,4469,4233,2340,304,33,256,33,4540,648]

theorem envBound25968 : H12AffineFastState.Bounded env25968 := by
  intro p hp
  have h : env25968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25967_25968 : H12AffineEnvironment.transform 9 236 env25967 = env25968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env25967 == env25968) = true)

theorem identity25968 : scanCanonicalize (H12AffineFastState.compose env25968 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound25968 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25969 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2540,388,2048,80,263,2113,2476,236,81,2476,32,152,3,268,65,2049,2201,2405,2340,304,33,256,33,2128,648]

theorem envBound25969 : H12AffineFastState.Bounded env25969 := by
  intro p hp
  have h : env25969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25968_25969 : H12AffineEnvironment.transform 11 2540 env25968 = env25969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env25968 == env25969) = true)

theorem identity25969 : scanCanonicalize (H12AffineFastState.compose env25969 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25969 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env25970 : List Nat := [2,4,8,16,32,64,128,256,512,236,0,492,388,0,80,263,65,428,236,81,428,32,152,3,268,65,1,153,357,292,304,33,256,33,80,648]

theorem envBound25970 : H12AffineFastState.Bounded env25970 := by
  intro p hp
  have h : env25970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25969_25970 : H12AffineEnvironment.transform 10 0 env25969 = env25970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25969 == env25970) = true)

theorem identity25970 : scanCanonicalize (H12AffineFastState.compose env25970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25971 : List Nat := [2,4,8,16,32,64,128,36,512,236,0,200,160,0,80,35,65,136,236,81,136,32,152,3,40,65,1,153,65,0,20,33,36,33,80,648]

theorem envBound25971 : H12AffineFastState.Bounded env25971 := by
  intro p hp
  have h : env25971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25970_25971 : H12AffineEnvironment.transform 7 36 env25970 = env25971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25970 == env25971) = true)

theorem identity25971 : scanCanonicalize (H12AffineFastState.compose env25971 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound25971 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25972 : List Nat := [2,4,8,16,32,64,88,36,512,52,0,16,120,0,80,35,65,80,52,81,80,32,64,3,40,65,1,65,65,0,20,33,36,33,80,592]

theorem envBound25972 : H12AffineFastState.Bounded env25972 := by
  intro p hp
  have h : env25972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25971_25972 : H12AffineEnvironment.transform 6 88 env25971 = env25972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env25971 == env25972) = true)

def env25973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169265,155996,254096,8328,65,64724,160861,140365,35188,1500,32,256,21793,46212,74251]

theorem envBound25973 : H12AffineFastState.Bounded env25973 := by
  intro p hp
  have h : env25973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25946_25973 : H12AffineEnvironment.transform 17 10281 env25946 = env25973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25946 == env25973) = true)

def env25974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21793,41292,73856,8328,65,64724,46157,58461,35188,1500,32,256,21793,46212,74251]

theorem envBound25974 : H12AffineFastState.Bounded env25974 := by
  intro p hp
  have h : env25974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25973_25974 : H12AffineEnvironment.transform 16 49168 env25973 = env25974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25973 == env25974) = true)

theorem identity25974 : scanCanonicalize (H12AffineFastState.compose env25974 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25974 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1024,32769,4160,21793,41292,138,8328,65,64724,46157,58461,35188,1500,32,256,21793,46212,513]

theorem envBound25975 : H12AffineFastState.Bounded env25975 := by
  intro p hp
  have h : env25975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25974_25975 : H12AffineEnvironment.transform 15 8202 env25974 = env25975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25974 == env25975) = true)

theorem identity25975 : scanCanonicalize (H12AffineFastState.compose env25975 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound25975 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49168,2557,1024,32769,4160,21793,32920,138,348,65,56576,38297,50569,35188,1500,32,256,21793,38224,513]

theorem envBound25976 : H12AffineFastState.Bounded env25976 := by
  intro p hp
  have h : env25976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25975_25976 : H12AffineEnvironment.transform 12 468 env25975 = env25976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env25975 == env25976) = true)

theorem identity25976 : scanCanonicalize (H12AffineFastState.compose env25976 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25976 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,2421,1024,32769,4160,21793,32784,2,348,65,56576,38161,50433,35188,1364,32,256,21793,38224,513]

theorem envBound25977 : H12AffineFastState.Bounded env25977 := by
  intro p hp
  have h : env25977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25976_25977 : H12AffineEnvironment.transform 6 8 env25976 = env25977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25976 == env25977) = true)

theorem identity25977 : scanCanonicalize (H12AffineFastState.compose env25977 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25977 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25978 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,263,49168,2340,1024,32769,4113,21793,32784,2,269,16,56576,38161,50433,35109,1285,32,256,21793,38145,513]

theorem envBound25978 : H12AffineFastState.Bounded env25978 := by
  intro p hp
  have h : env25978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25977_25978 : H12AffineEnvironment.transform 5 17 env25977 = env25978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25977 == env25978) = true)

theorem identity25978 : scanCanonicalize (H12AffineFastState.compose env25978 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25978 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25979 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,263,16401,2340,1024,0,4113,21793,17,2,269,16,23809,5392,17664,2340,1285,32,256,21793,5376,513]

theorem envBound25979 : H12AffineFastState.Bounded env25979 := by
  intro p hp
  have h : env25979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25978_25979 : H12AffineEnvironment.transform 14 1 env25978 = env25979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25978 == env25979) = true)

theorem identity25979 : scanCanonicalize (H12AffineFastState.compose env25979 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound25979 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25980 : List Nat := [2,4,8,16,32,17,8,256,512,794,2048,4096,269,16384,1,263,16401,2340,794,0,4113,21051,17,2,269,16,23067,4618,16922,2340,543,32,256,21051,4634,513]

theorem envBound25980 : H12AffineFastState.Bounded env25980 := by
  intro p hp
  have h : env25980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25979_25980 : H12AffineEnvironment.transform 9 794 env25979 = env25980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env25979 == env25980) = true)

def env25981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21792,41293,73857,8328,65,64724,46156,58460,35188,1500,32,256,21793,46212,74251]

theorem envBound25981 : H12AffineFastState.Bounded env25981 := by
  intro p hp
  have h : env25981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25973_25981 : H12AffineEnvironment.transform 16 49169 env25973 = env25981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25973 == env25981) = true)

theorem identity25981 : scanCanonicalize (H12AffineFastState.compose env25981 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound25981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1024,32769,4160,21792,41293,3,8328,65,64724,46156,58460,35188,1500,32,256,21793,46212,649]

theorem envBound25982 : H12AffineFastState.Bounded env25982 := by
  intro p hp
  have h : env25982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25981_25982 : H12AffineEnvironment.transform 15 8322 env25981 = env25982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env25981 == env25982) = true)

theorem identity25982 : scanCanonicalize (H12AffineFastState.compose env25982 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound25982 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,8322,46228,10281,1024,32769,4160,8613,41293,3,8328,65,34897,46156,37081,35188,1500,32,256,8612,46212,649]

theorem envBound25983 : H12AffineFastState.Bounded env25983 := by
  intro p hp
  have h : env25983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25982_25983 : H12AffineEnvironment.transform 13 13445 env25982 = env25983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env25982 == env25983) = true)

theorem identity25983 : scanCanonicalize (H12AffineFastState.compose env25983 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound25983 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env25984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,136,8322,13340,10281,1024,137,4160,8613,8645,3,8328,65,2265,13508,4177,2556,1500,32,256,8612,13324,649]

theorem envBound25984 : H12AffineFastState.Bounded env25984 := by
  intro p hp
  have h : env25984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25983_25984 : H12AffineEnvironment.transform 14 136 env25983 = env25984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env25983 == env25984) = true)

theorem identity25984 : scanCanonicalize (H12AffineFastState.compose env25984 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25984 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env25985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,8203,13340,10281,1024,0,4160,8492,8524,3,8193,65,2128,13389,4177,2421,1365,32,256,8493,13324,512]

theorem envBound25985 : H12AffineFastState.Bounded env25985 := by
  intro p hp
  have h : env25985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25984_25985 : H12AffineEnvironment.transform 6 9 env25984 = env25985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25984 == env25985) = true)

theorem identity25985 : scanCanonicalize (H12AffineFastState.compose env25985 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25985 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25986 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13324,1,8203,13340,10248,1024,0,4160,8461,8524,3,8193,65,2128,13389,4177,2388,1365,1,256,8460,13324,512]

theorem envBound25986 : H12AffineFastState.Bounded env25986 := by
  intro p hp
  have h : env25986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25985_25986 : H12AffineEnvironment.transform 4 1 env25985 = env25986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25985 == env25986) = true)

theorem identity25986 : scanCanonicalize (H12AffineFastState.compose env25986 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25986 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25987 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5457,1,342,5441,2389,1024,0,4160,80,17,3,348,65,2128,5392,4177,2388,1365,1,256,81,5457,512]

theorem envBound25987 : H12AffineFastState.Bounded env25987 := by
  intro p hp
  have h : env25987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25986_25987 : H12AffineEnvironment.transform 12 349 env25986 = env25987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25986 == env25987) = true)

theorem identity25987 : scanCanonicalize (H12AffineFastState.compose env25987 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound25987 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25988 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5125,1,2,5141,2049,1024,0,4160,80,17,3,8,65,2128,5188,4177,2048,1025,1,84,81,5125,512]

theorem envBound25988 : H12AffineFastState.Bounded env25988 := by
  intro p hp
  have h : env25988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25987_25988 : H12AffineEnvironment.transform 7 84 env25987 = env25988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env25987 == env25988) = true)

def env25989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,510137,8328,65,316668,416885,396388,35189,1501,272392,256,21793,46212,74250]

theorem envBound25989 : H12AffineFastState.Bounded env25989 := by
  intro p hp
  have h : env25989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25945_25989 : H12AffineEnvironment.transform 20 4161 env25945 = env25989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25945 == env25989) = true)

theorem identity25989 : scanCanonicalize (H12AffineFastState.compose env25989 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound25989 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,169265,62661,95496,8328,65,158029,57796,45525,35189,1501,169401,256,21793,46212,74250]

theorem envBound25990 : H12AffineFastState.Bounded env25990 := by
  intro p hp
  have h : env25990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25989_25990 : H12AffineEnvironment.transform 17 179633 env25989 = env25990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env25989 == env25990) = true)

theorem identity25990 : scanCanonicalize (H12AffineFastState.compose env25990 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25990 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env25991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179633,1024,32769,4161,169265,62661,21763,8328,65,158029,57796,45525,35189,1501,169401,256,21793,46212,513]

theorem envBound25991 : H12AffineFastState.Bounded env25991 := by
  intro p hp
  have h : env25991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25990_25991 : H12AffineEnvironment.transform 15 8203 env25990 = env25991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25990 == env25991) = true)

theorem identity25991 : scanCanonicalize (H12AffineFastState.compose env25991 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound25991 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env25992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,46276,2421,1024,32769,4161,8693,62661,21763,8328,65,56713,57796,45525,35189,1501,8573,256,21793,46212,513]

theorem envBound25992 : H12AffineFastState.Bounded env25992 := by
  intro p hp
  have h : env25992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25991_25992 : H12AffineEnvironment.transform 16 46276 env25991 = env25992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env25991 == env25992) = true)

theorem identity25992 : scanCanonicalize (H12AffineFastState.compose env25992 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound25992 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,2421,1024,29908,4161,8693,16,21763,8328,65,10588,5393,17664,32160,1501,8573,256,21793,16465,513]

theorem envBound25993 : H12AffineFastState.Bounded env25993 := by
  intro p hp
  have h : env25993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25992_25993 : H12AffineEnvironment.transform 14 29909 env25992 = env25993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env25992 == env25993) = true)

theorem identity25993 : scanCanonicalize (H12AffineFastState.compose env25993 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25993 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env25994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8581,8203,5441,2421,1024,8580,4161,8693,16,83,8328,65,10588,5393,4176,10480,1501,8573,256,113,5377,513]

theorem envBound25994 : H12AffineFastState.Bounded env25994 := by
  intro p hp
  have h : env25994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25993_25994 : H12AffineEnvironment.transform 13 5456 env25993 = env25994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25993 == env25994) = true)

theorem identity25994 : scanCanonicalize (H12AffineFastState.compose env25994 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound25994 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,4257,5456,4388,4266,5441,2421,1024,4389,4161,4436,16,83,4137,65,6653,5393,4176,6225,1501,4572,256,113,5377,513]

theorem envBound25995 : H12AffineFastState.Bounded env25995 := by
  intro p hp
  have h : env25995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25994_25995 : H12AffineEnvironment.transform 12 4257 env25994 = env25995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env25994 == env25995) = true)

theorem identity25995 : scanCanonicalize (H12AffineFastState.compose env25995 (packedSelected [0,1,5,6,7,11,12,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound25995 : packedSelected [0,1,5,6,7,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env25996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1724,1565,1004,1944,1558,1021,2421,1024,1945,1789,2024,16,83,1685,65,3905,941,1772,3821,1501,1888,256,113,957,513]

theorem envBound25996 : H12AffineFastState.Bounded env25996 := by
  intro p hp
  have h : env25996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25995_25996 : H12AffineEnvironment.transform 11 1724 env25995 = env25996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env25995 == env25996) = true)

theorem identity25996 : scanCanonicalize (H12AffineFastState.compose env25996 (packedSelected [1,2,3,4,6,7,11,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound25996 : packedSelected [1,2,3,4,6,7,11,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env25997 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,593,752,1004,885,763,1021,2421,237,884,528,773,16,83,632,65,2988,941,513,2560,304,909,256,113,957,513]

theorem envBound25997 : H12AffineFastState.Bounded env25997 := by
  intro p hp
  have h : env25997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25996_25997 : H12AffineEnvironment.transform 9 237 env25996 = env25997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env25996 == env25997) = true)

theorem identity25997 : scanCanonicalize (H12AffineFastState.compose env25997 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound25997 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env25998 : List Nat := [2,4,8,16,32,64,128,256,508,237,2048,429,268,16,137,263,1,2421,237,136,492,249,16,83,388,65,2128,81,509,2556,304,113,256,113,65,509]

theorem envBound25998 : H12AffineFastState.Bounded env25998 := by
  intro p hp
  have h : env25998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25997_25998 : H12AffineEnvironment.transform 8 508 env25997 = env25998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env25997 == env25998) = true)

theorem identity25998 : scanCanonicalize (H12AffineFastState.compose env25998 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound25998 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25999 : List Nat := [2,4,8,16,32,64,128,256,508,237,492,429,268,16,137,263,1,153,237,136,492,249,16,83,388,65,444,81,509,16,304,113,256,113,65,509]

theorem envBound25999 : H12AffineFastState.Bounded env25999 := by
  intro p hp
  have h : env25999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25998_25999 : H12AffineEnvironment.transform 10 492 env25998 = env25999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env25998 == env25999) = true)

theorem identity25999 : scanCanonicalize (H12AffineFastState.compose env25999 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25999 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env26000 : List Nat := [2,4,8,16,32,0,128,256,444,173,428,429,268,16,137,263,1,153,173,136,428,185,16,19,388,1,444,17,445,16,304,49,256,49,1,445]

theorem envBound26000 : H12AffineFastState.Bounded env26000 := by
  intro p hp
  have h : env26000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25999_26000 : H12AffineEnvironment.transform 5 0 env25999 = env26000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25999 == env26000) = true)

theorem identity26000 : scanCanonicalize (H12AffineFastState.compose env26000 (packedSelected [1,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26000 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env26001 : List Nat := [2,4,8,16,32,0,128,37,153,173,137,136,41,16,137,34,1,153,173,136,137,185,16,19,161,1,153,17,152,16,21,49,37,49,1,152]

theorem envBound26001 : H12AffineFastState.Bounded env26001 := by
  intro p hp
  have h : env26001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26000_26001 : H12AffineEnvironment.transform 7 37 env26000 = env26001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26000 == env26001) = true)

theorem identity26001 : scanCanonicalize (H12AffineFastState.compose env26001 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26002 : List Nat := [2,4,8,16,32,0,8,37,17,37,1,0,41,16,1,34,1,17,37,0,1,49,16,19,41,1,17,17,16,16,21,49,37,49,1,16]

theorem envBound26002 : H12AffineFastState.Bounded env26002 := by
  intro p hp
  have h : env26002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26001_26002 : H12AffineEnvironment.transform 6 8 env26001 = env26002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26001 == env26002) = true)

theorem identity26002 : scanCanonicalize (H12AffineFastState.compose env26002 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26003 : List Nat := [2,4,8,0,32,0,8,37,1,37,1,0,41,0,1,34,1,1,37,0,1,33,0,3,41,1,1,1,0,0,5,33,37,33,1,0]

theorem envBound26003 : H12AffineFastState.Bounded env26003 := by
  intro p hp
  have h : env26003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26002_26003 : H12AffineEnvironment.transform 3 0 env26002 = env26003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26002 == env26003) = true)

theorem identity26003 : scanCanonicalize (H12AffineFastState.compose env26003 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26003 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26004 : List Nat := [2,4,8,0,10,0,8,15,1,15,1,0,3,0,1,8,1,1,15,0,1,11,0,3,3,1,1,1,0,0,5,11,15,11,1,0]

theorem envBound26004 : H12AffineFastState.Bounded env26004 := by
  intro p hp
  have h : env26004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26003_26004 : H12AffineEnvironment.transform 4 10 env26003 = env26004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26003 == env26004) = true)

def env26005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound26005 : H12AffineFastState.Bounded env26005 := by
  intro p hp
  have h : env26005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25779_26005 : H12AffineEnvironment.transform 18 1025 env25779 = env26005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25779 == env26005) = true)

theorem identity26005 : scanCanonicalize (H12AffineFastState.compose env26005 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272440) := by decide +kernel

theorem selectedBound26005 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8328,65,21227577,18973836,2391401,190520,17148968,23160257,257,19262612,19205424,17075198]

theorem envBound26006 : H12AffineFastState.Bounded env26006 := by
  intro p hp
  have h : env26006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26005_26006 : H12AffineEnvironment.transform 22 272440 env26005 = env26006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272440 env26005 == env26006) = true)

def env26007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227577,18973700,2391401,190520,17148968,23160137,257,19262492,19205424,17075062]

theorem envBound26007 : H12AffineFastState.Bounded env26007 := by
  intro p hp
  have h : env26007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26006_26007 : H12AffineEnvironment.transform 6 8 env26006 = env26007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26006 == env26007) = true)

theorem identity26007 : scanCanonicalize (H12AffineFastState.compose env26007 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272427) := by decide +kernel

theorem selectedBound26007 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,272427,8192,65,4702226,2468911,2391401,190520,99331,6638946,257,2212919,2172187,41821]

theorem envBound26008 : H12AffineFastState.Bounded env26008 := by
  intro p hp
  have h : env26008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26007_26008 : H12AffineEnvironment.transform 23 272427 env26007 = env26008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272427 env26007 == env26008) = true)

def env26009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,2097152,4194304,147456,147475,8192,65,4302890,2343959,2233681,190520,99331,6497626,257,2212919,2172187,41821]

theorem envBound26009 : H12AffineFastState.Bounded env26009 := by
  intro p hp
  have h : env26009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26008_26009 : H12AffineEnvironment.transform 17 157752 env26008 = env26009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env26008 == env26009) = true)

theorem identity26009 : scanCanonicalize (H12AffineFastState.compose env26009 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 188780) := by decide +kernel

theorem selectedBound26009 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env26010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,2097152,188780,147456,147475,8192,65,215366,2343959,2233681,190520,99331,2212918,257,2212919,2172187,41821]

theorem envBound26010 : H12AffineFastState.Bounded env26010 := by
  intro p hp
  have h : env26010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26009_26010 : H12AffineEnvironment.transform 21 188780 env26009 = env26010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188780 env26009 == env26010) = true)

theorem identity26010 : scanCanonicalize (H12AffineFastState.compose env26010 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound26010 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env26011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1025,32769,2097152,32,41292,41311,8192,65,108554,2172251,2159645,2420,99331,2212918,257,2212919,2172187,41821]

theorem envBound26011 : H12AffineFastState.Bounded env26011 := by
  intro p hp
  have h : env26011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26010_26011 : H12AffineEnvironment.transform 16 57676 env26010 = env26011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env26010 == env26011) = true)

theorem identity26011 : scanCanonicalize (H12AffineFastState.compose env26011 (packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 115782) := by decide +kernel

theorem selectedBound26011 : packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS < 2^1333 := by decide +kernel

def env26012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1025,32769,115782,32,41292,41311,8192,65,108554,57629,77915,2420,99331,112,257,113,57693,41821]

theorem envBound26012 : H12AffineFastState.Bounded env26012 := by
  intro p hp
  have h : env26012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26011_26012 : H12AffineEnvironment.transform 20 115782 env26011 = env26012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115782 env26011 == env26012) = true)

theorem identity26012 : scanCanonicalize (H12AffineFastState.compose env26012 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound26012 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env26013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57676,35188,1025,32769,25677,32,41292,41311,8192,65,2049,57629,36944,2420,9224,112,257,113,57693,41821]

theorem envBound26013 : H12AffineFastState.Bounded env26013 := by
  intro p hp
  have h : env26013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26012_26013 : H12AffineEnvironment.transform 15 40971 env26012 = env26013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env26012 == env26013) = true)

theorem identity26013 : scanCanonicalize (H12AffineFastState.compose env26013 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound26013 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env26014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,40971,37940,35188,1025,32769,4405,32,41292,41311,8192,65,2049,37989,36944,2420,9224,112,257,113,37925,41821]

theorem envBound26014 : H12AffineFastState.Bounded env26014 := by
  intro p hp
  have h : env26014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26013_26014 : H12AffineEnvironment.transform 13 13688 env26013 = env26014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env26013 == env26014) = true)

theorem identity26014 : scanCanonicalize (H12AffineFastState.compose env26014 (packedSelected [10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26014 : packedSelected [10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,32768,33111,37940,35188,1025,32769,4405,32,32784,32771,348,65,2049,37989,36944,2420,1364,112,257,113,37925,33281]

theorem envBound26015 : H12AffineFastState.Bounded env26015 := by
  intro p hp
  have h : env26015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26014_26015 : H12AffineEnvironment.transform 12 348 env26014 = env26015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26014 == env26015) = true)

theorem identity26015 : scanCanonicalize (H12AffineFastState.compose env26015 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound26015 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,80,263,5220,2340,1025,81,4405,32,64,83,348,65,2049,5173,4096,2420,1364,112,257,113,5237,593]

theorem envBound26016 : H12AffineFastState.Bounded env26016 := by
  intro p hp
  have h : env26016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26015_26016 : H12AffineEnvironment.transform 14 80 env26015 = env26016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env26015 == env26016) = true)

theorem identity26016 : scanCanonicalize (H12AffineFastState.compose env26016 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound26016 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env26017 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,5156,33,263,5141,2340,1025,32,4405,32,49,34,301,48,2049,5173,4096,2309,1317,1,257,0,5124,544]

theorem envBound26017 : H12AffineFastState.Bounded env26017 := by
  intro p hp
  have h : env26017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26016_26017 : H12AffineEnvironment.transform 5 49 env26016 = env26017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26016 == env26017) = true)

theorem identity26017 : scanCanonicalize (H12AffineFastState.compose env26017 (packedSelected [0,2,3,5,7,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26017 : packedSelected [0,2,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env26018 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,5124,1,263,5141,2308,1025,0,4373,0,17,2,269,16,2049,5141,4096,2309,1285,1,257,0,5124,512]

theorem envBound26018 : H12AffineFastState.Bounded env26018 := by
  intro p hp
  have h : env26018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26017_26018 : H12AffineEnvironment.transform 4 0 env26017 = env26018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26017 == env26018) = true)

theorem identity26018 : scanCanonicalize (H12AffineFastState.compose env26018 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26019 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,1,2,5141,2049,1025,0,4112,0,17,2,8,16,2049,5141,4096,2048,1024,1,4,0,5124,512]

theorem envBound26019 : H12AffineFastState.Bounded env26019 := by
  intro p hp
  have h : env26019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26018_26019 : H12AffineEnvironment.transform 7 5 env26018 = env26019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26018 == env26019) = true)

def env26020 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1044,1,2,1029,2049,1025,0,0,0,17,2,8,16,2049,1029,16,2048,1024,1,4,0,1044,512]

theorem envBound26020 : H12AffineFastState.Bounded env26020 := by
  intro p hp
  have h : env26020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26019_26020 : H12AffineEnvironment.transform 11 16 env26019 = env26020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26019 == env26020) = true)

theorem identity26020 : scanCanonicalize (H12AffineFastState.compose env26020 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26021 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,8,1044,1,2,1029,1,1025,0,0,0,17,2,8,16,1,1029,16,0,1024,1,4,0,1044,512]

theorem envBound26021 : H12AffineFastState.Bounded env26021 := by
  intro p hp
  have h : env26021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26020_26021 : H12AffineEnvironment.transform 10 0 env26020 = env26021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26020 == env26021) = true)

def env26022 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,0,1,2,17,1,21,0,0,0,17,2,8,16,1,17,16,0,20,1,4,0,0,512]

theorem envBound26022 : H12AffineFastState.Bounded env26022 := by
  intro p hp
  have h : env26022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26021_26022 : H12AffineEnvironment.transform 9 20 env26021 = env26022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26021 == env26022) = true)

theorem identity26022 : scanCanonicalize (H12AffineFastState.compose env26022 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound26022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26023 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,8,0,1,2,17,1,21,0,0,0,17,2,8,16,1,17,16,0,20,1,4,0,0,30]

theorem envBound26023 : H12AffineFastState.Bounded env26023 := by
  intro p hp
  have h : env26023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26022_26023 : H12AffineEnvironment.transform 8 30 env26022 = env26023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env26022 == env26023) = true)

def leafEnv26023 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,8,0,1,2,17,1,21,0,0,0,17,2,21,8,1,16,1,17,16,0,20,1,4,0,5,2,0,30,1,0,0]

def active26023 : List Nat := [0,1,2,3]

def tree26023 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26023 : H12WitnessSearch.Good tree26023 := H12GlobalWitnessIndex.good

theorem leafIdentity26023 : H12AffineFastState.composeSystem env26023 rootObs = leafEnv26023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26023 rootObs == leafEnv26023) = true)

theorem terminalChecked26023 : H12PackedTerminal.terminalCheckFast leafEnv26023 active26023 tree26023 = true := by decide +kernel

def env26024 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,1,2,16,1,20,0,0,0,17,2,8,16,1,16,16,0,21,1,4,0,1,512]

theorem envBound26024 : H12AffineFastState.Bounded env26024 := by
  intro p hp
  have h : env26024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26021_26024 : H12AffineEnvironment.transform 9 21 env26021 = env26024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26021 == env26024) = true)

theorem identity26024 : scanCanonicalize (H12AffineFastState.compose env26024 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26025 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,1,2,5,1,1,0,0,0,4,2,8,5,1,5,5,0,0,1,4,0,1,512]

theorem envBound26025 : H12AffineFastState.Bounded env26025 := by
  intro p hp
  have h : env26025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26024_26025 : H12AffineEnvironment.transform 3 5 env26024 = env26025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26024 == env26025) = true)

def leafEnv26025 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,1,2,5,1,1,0,0,0,4,2,1,8,1,5,1,5,5,0,0,1,4,0,5,2,1,512,1,0,0]

def active26025 : List Nat := [0,1,2,8]

def tree26025 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26025 : H12WitnessSearch.Good tree26025 := H12GlobalWitnessIndex.good

theorem leafIdentity26025 : H12AffineFastState.composeSystem env26025 rootObs = leafEnv26025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26025 rootObs == leafEnv26025) = true)

theorem terminalChecked26025 : H12PackedTerminal.terminalCheckFast leafEnv26025 active26025 tree26025 = true := by decide +kernel

def env26026 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1045,1,2,1028,2049,1025,0,1,0,17,2,8,16,2049,1028,17,2048,1024,1,4,0,1045,512]

theorem envBound26026 : H12AffineFastState.Bounded env26026 := by
  intro p hp
  have h : env26026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26019_26026 : H12AffineEnvironment.transform 11 17 env26019 = env26026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26019 == env26026) = true)

theorem identity26026 : scanCanonicalize (H12AffineFastState.compose env26026 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound26026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26027 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,8,1045,1,2,1028,1044,1025,0,1,0,17,2,8,16,1044,1028,17,1045,1024,1,4,0,1045,512]

theorem envBound26027 : H12AffineFastState.Bounded env26027 := by
  intro p hp
  have h : env26027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26026_26027 : H12AffineEnvironment.transform 10 1045 env26026 = env26027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env26026 == env26027) = true)

def env26028 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,8,1,1,2,16,0,21,0,1,0,17,2,8,16,0,16,17,1,20,1,4,0,1,512]

theorem envBound26028 : H12AffineFastState.Bounded env26028 := by
  intro p hp
  have h : env26028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26027_26028 : H12AffineEnvironment.transform 9 20 env26027 = env26028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26027 == env26028) = true)

theorem identity26028 : scanCanonicalize (H12AffineFastState.compose env26028 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound26028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26029 : List Nat := [2,4,8,16,0,17,8,5,31,20,1,17,8,1,1,2,16,0,21,0,1,0,17,2,8,16,0,16,17,1,20,1,4,0,1,31]

theorem envBound26029 : H12AffineFastState.Bounded env26029 := by
  intro p hp
  have h : env26029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26028_26029 : H12AffineEnvironment.transform 8 31 env26028 = env26029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env26028 == env26029) = true)

def leafEnv26029 : List Nat := [2,4,8,16,0,17,8,5,31,20,1,17,8,1,1,2,16,0,21,0,1,0,17,2,21,8,1,16,0,16,17,1,20,1,4,0,5,2,1,31,1,1,0]

def active26029 : List Nat := [0,1,2,3]

def tree26029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26029 : H12WitnessSearch.Good tree26029 := H12GlobalWitnessIndex.good

theorem leafIdentity26029 : H12AffineFastState.composeSystem env26029 rootObs = leafEnv26029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26029 rootObs == leafEnv26029) = true)

theorem terminalChecked26029 : H12PackedTerminal.terminalCheckFast leafEnv26029 active26029 tree26029 = true := by decide +kernel

def env26030 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,1,2,17,1,20,0,1,0,17,2,8,16,1,17,17,0,21,1,4,0,0,512]

theorem envBound26030 : H12AffineFastState.Bounded env26030 := by
  intro p hp
  have h : env26030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26027_26030 : H12AffineEnvironment.transform 9 21 env26027 = env26030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26027 == env26030) = true)

theorem identity26030 : scanCanonicalize (H12AffineFastState.compose env26030 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26031 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,4,8,0,1,2,4,1,1,0,1,0,4,2,8,5,1,4,4,0,0,1,4,0,0,512]

theorem envBound26031 : H12AffineFastState.Bounded env26031 := by
  intro p hp
  have h : env26031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26030_26031 : H12AffineEnvironment.transform 3 5 env26030 = env26031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26030 == env26031) = true)

def leafEnv26031 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,4,8,0,1,2,4,1,1,0,1,0,4,2,1,8,1,5,1,4,4,0,0,1,4,0,5,2,0,512,1,1,0]

def active26031 : List Nat := [0,1,2,8]

def tree26031 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26031 : H12WitnessSearch.Good tree26031 := H12GlobalWitnessIndex.good

theorem leafIdentity26031 : H12AffineFastState.composeSystem env26031 rootObs = leafEnv26031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26031 rootObs == leafEnv26031) = true)

theorem terminalChecked26031 : H12PackedTerminal.terminalCheckFast leafEnv26031 active26031 tree26031 = true := by decide +kernel

def env26032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,2097152,4194304,147457,147474,8192,65,4302891,2343958,2233680,190520,99331,6497627,257,2212919,2172187,41821]

theorem envBound26032 : H12AffineFastState.Bounded env26032 := by
  intro p hp
  have h : env26032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26008_26032 : H12AffineEnvironment.transform 17 157753 env26008 = env26032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env26008 == env26032) = true)

theorem identity26032 : scanCanonicalize (H12AffineFastState.compose env26032 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26032 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157753,1025,8541,2097152,4194304,147457,147474,8192,65,4262263,2319690,2233680,149860,75103,6497627,257,2188651,2172187,513]

theorem envBound26033 : H12AffineFastState.Bounded env26033 := by
  intro p hp
  have h : env26033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26032_26033 : H12AffineEnvironment.transform 14 8540 env26032 = env26033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26032 == env26033) = true)

theorem identity26033 : scanCanonicalize (H12AffineFastState.compose env26033 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound26033 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,67619,1025,8541,2097152,4194304,73755,73736,8192,65,4262263,2098512,2192714,76158,75103,6309185,257,2188651,2172187,513]

theorem envBound26034 : H12AffineFastState.Bounded env26034 := by
  intro p hp
  have h : env26034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26033_26034 : H12AffineEnvironment.transform 16 90138 env26033 = env26034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env26033 == env26034) = true)

theorem identity26034 : scanCanonicalize (H12AffineFastState.compose env26034 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound26034 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env26035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,67619,1025,8541,25677,4194304,73755,73736,8192,65,4262263,24861,69895,76158,75103,4202764,257,65830,82262,513]

theorem envBound26035 : H12AffineFastState.Bounded env26035 := by
  intro p hp
  have h : env26035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26034_26035 : H12AffineEnvironment.transform 20 25677 env26034 = env26035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env26034 == env26035) = true)

theorem identity26035 : scanCanonicalize (H12AffineFastState.compose env26035 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound26035 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env26036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,67619,1025,8541,25677,32,73755,73736,8192,65,67927,24861,69895,76158,75103,8492,257,65830,82262,513]

theorem envBound26036 : H12AffineFastState.Bounded env26036 := by
  intro p hp
  have h : env26036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26035_26036 : H12AffineEnvironment.transform 21 32 env26035 = env26036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26035 == env26036) = true)

theorem identity26036 : scanCanonicalize (H12AffineFastState.compose env26036 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound26036 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env26037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29743,5173,31756,1025,8541,25677,32,21556,21543,8192,65,32120,24861,25896,23889,20848,8492,257,29961,13689,513]

theorem envBound26037 : H12AffineFastState.Bounded env26037 := by
  intro p hp
  have h : env26037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26036_26037 : H12AffineEnvironment.transform 15 29743 env26036 = env26037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env26036 == env26037) = true)

theorem identity26037 : scanCanonicalize (H12AffineFastState.compose env26037 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 11340) := by decide +kernel

theorem selectedBound26037 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11340,8540,6243,5173,4160,1025,8541,2049,32,14456,14443,8192,65,4404,3409,2404,12573,15676,8492,257,6469,13689,513]

theorem envBound26038 : H12AffineFastState.Bounded env26038 := by
  intro p hp
  have h : env26038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26037_26038 : H12AffineEnvironment.transform 13 11340 env26037 = env26038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11340 env26037 == env26038) = true)

theorem identity26038 : scanCanonicalize (H12AffineFastState.compose env26038 (packedSelected [1,2,3,6,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound26038 : packedSelected [1,2,3,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,2129,1345,6243,5173,4160,1025,1344,2049,32,7269,7286,1053,65,4404,3409,2404,5376,6433,1329,257,6469,4452,513]

theorem envBound26039 : H12AffineFastState.Bounded env26039 := by
  intro p hp
  have h : env26039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26038_26039 : H12AffineEnvironment.transform 12 1053 env26038 = env26039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env26038 == env26039) = true)

theorem identity26039 : scanCanonicalize (H12AffineFastState.compose env26039 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound26039 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env26040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1053,2129,1345,3378,356,1297,1025,1344,2049,32,2356,2343,1053,65,1125,3409,2404,81,3184,1329,257,3092,1077,513]

theorem envBound26040 : H12AffineFastState.Bounded env26040 := by
  intro p hp
  have h : env26040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26039_26040 : H12AffineEnvironment.transform 11 1361 env26039 = env26040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env26039 == env26040) = true)

theorem identity26040 : scanCanonicalize (H12AffineFastState.compose env26040 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound26040 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env26041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1361,1053,1,1345,1378,356,1297,1025,1344,81,32,356,375,1053,65,1125,1281,308,81,1056,1329,257,1092,1077,513]

theorem envBound26041 : H12AffineFastState.Bounded env26041 := by
  intro p hp
  have h : env26041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26040_26041 : H12AffineEnvironment.transform 10 80 env26040 = env26041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env26040 == env26041) = true)

theorem identity26041 : scanCanonicalize (H12AffineFastState.compose env26041 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound26041 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26042 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,17,349,1,1,34,356,81,321,0,81,32,356,375,349,65,293,65,308,81,352,113,257,260,373,513]

theorem envBound26042 : H12AffineFastState.Bounded env26042 := by
  intro p hp
  have h : env26042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26041_26042 : H12AffineEnvironment.transform 9 320 env26041 = env26042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26041 == env26042) = true)

theorem identity26042 : scanCanonicalize (H12AffineFastState.compose env26042 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26043 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,41,1,1,34,16,81,53,0,81,32,16,3,41,65,81,65,64,81,20,113,117,112,1,513]

theorem envBound26043 : H12AffineFastState.Bounded env26043 := by
  intro p hp
  have h : env26043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26042_26043 : H12AffineEnvironment.transform 7 116 env26042 = env26043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26042 == env26043) = true)

def env26044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8193,65,21227577,18973701,2391401,190520,17148968,23160136,257,19262493,19205424,17075063]

theorem envBound26044 : H12AffineFastState.Bounded env26044 := by
  intro p hp
  have h : env26044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26006_26044 : H12AffineEnvironment.transform 6 9 env26006 = env26044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26006 == env26044) = true)

theorem identity26044 : scanCanonicalize (H12AffineFastState.compose env26044 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound26044 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,41311,8193,65,4409702,2172250,2391401,190520,331127,6407191,257,2444610,2468975,272936]

theorem envBound26045 : H12AffineFastState.Bounded env26045 := by
  intro p hp
  have h : env26045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26044_26045 : H12AffineEnvironment.transform 23 41311 env26044 = env26045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env26044 == env26045) = true)

def env26046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,272440,41311,8193,65,4262262,2172250,2391401,43048,331127,6407191,257,2444610,2468975,272936]

theorem envBound26046 : H12AffineFastState.Bounded env26046 := by
  intro p hp
  have h : env26046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26045_26046 : H12AffineEnvironment.transform 16 16400 env26045 = env26046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26045 == env26046) = true)

def env26047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,58396,4194304,272440,41311,8193,65,4262262,115014,301429,43048,331127,4268043,257,371038,346227,272936]

theorem envBound26047 : H12AffineFastState.Bounded env26047 := by
  intro p hp
  have h : env26047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26046_26047 : H12AffineEnvironment.transform 20 58396 env26046 = env26047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env26046 == env26047) = true)

def env26048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,4194304,16,41311,8193,65,4262262,115014,45405,43048,75103,4268043,257,98678,90203,512]

theorem envBound26048 : H12AffineFastState.Bounded env26048 := by
  intro p hp
  have h : env26048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26047_26048 : H12AffineEnvironment.transform 17 10280 env26047 = env26048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26047 == env26048) = true)

theorem identity26048 : scanCanonicalize (H12AffineFastState.compose env26048 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26048 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26049 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,4194304,16,41002,8193,65,4261891,114739,45096,43048,74794,4268043,116,98307,90203,512]

theorem envBound26049 : H12AffineFastState.Bounded env26049 := by
  intro p hp
  have h : env26049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26048_26049 : H12AffineEnvironment.transform 7 117 env26048 = env26049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26048 == env26049) = true)

theorem identity26049 : scanCanonicalize (H12AffineFastState.compose env26049 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound26049 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26050 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,119927,16,41002,8193,65,56436,114739,45096,43048,74794,62588,116,98307,90203,512]

theorem envBound26050 : H12AffineFastState.Bounded env26050 := by
  intro p hp
  have h : env26050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26049_26050 : H12AffineEnvironment.transform 21 119927 env26049 = env26050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env26049 == env26050) = true)

theorem identity26050 : scanCanonicalize (H12AffineFastState.compose env26050 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound26050 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26051 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,29822,16400,10280,1025,32769,58396,40969,16,41002,8193,65,56436,46157,45096,43048,20564,62588,116,62589,5157,512]

theorem envBound26051 : H12AffineFastState.Bounded env26051 := by
  intro p hp
  have h : env26051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26050_26051 : H12AffineEnvironment.transform 15 29822 env26050 = env26051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env26050 == env26051) = true)

theorem identity26051 : scanCanonicalize (H12AffineFastState.compose env26051 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound26051 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26052 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5205,32768,8235,5189,10280,1025,32769,45129,40969,16,41002,8193,65,34849,46157,45096,43048,1025,41001,116,41000,5157,512]

theorem envBound26052 : H12AffineFastState.Bounded env26052 := by
  intro p hp
  have h : env26052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26051_26052 : H12AffineEnvironment.transform 13 5205 env26051 = env26052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env26051 == env26052) = true)

theorem identity26052 : scanCanonicalize (H12AffineFastState.compose env26052 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound26052 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26053 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5205,32768,83,5189,2128,1025,32769,36913,32881,16,32850,121,65,34849,37941,36944,34896,1025,32849,116,32848,5157,512]

theorem envBound26053 : H12AffineFastState.Bounded env26053 := by
  intro p hp
  have h : env26053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26052_26053 : H12AffineEnvironment.transform 12 120 env26052 = env26053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env26052 == env26053) = true)

theorem identity26053 : scanCanonicalize (H12AffineFastState.compose env26053 (packedSelected [0,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26053 : packedSelected [0,6,7,12] rootPS < 2^1333 := by decide +kernel

def env26054 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2065,120,3140,32768,83,3156,2128,1025,32769,34848,32881,16,32850,121,65,34849,35876,34881,34896,1025,32849,116,32848,3124,512]

theorem envBound26054 : H12AffineFastState.Bounded env26054 := by
  intro p hp
  have h : env26054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26053_26054 : H12AffineEnvironment.transform 11 2065 env26053 = env26054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26053 == env26054) = true)

theorem identity26054 : scanCanonicalize (H12AffineFastState.compose env26054 (packedSelected [0,3,5,6,7,10,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26054 : packedSelected [0,3,5,6,7,10,15] rootPS < 2^1333 := by decide +kernel

def env26055 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,2065,88,3140,32768,83,3156,2128,1025,32769,34816,32849,16,32850,89,65,34817,35844,34881,34896,1025,32849,84,32848,3092,512]

theorem envBound26055 : H12AffineFastState.Bounded env26055 := by
  intro p hp
  have h : env26055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26054_26055 : H12AffineEnvironment.transform 4 0 env26054 = env26055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26054 == env26055) = true)

theorem identity26055 : scanCanonicalize (H12AffineFastState.compose env26055 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound26055 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26056 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,2065,88,2049,32768,83,2065,2128,68,32769,34816,32849,16,32850,89,65,34817,34881,34881,34896,68,32849,84,32848,2129,512]

theorem envBound26056 : H12AffineFastState.Bounded env26056 := by
  intro p hp
  have h : env26056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26055_26056 : H12AffineEnvironment.transform 9 69 env26055 = env26056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env26055 == env26056) = true)

theorem identity26056 : scanCanonicalize (H12AffineFastState.compose env26056 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound26056 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26057 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,2065,88,2049,2048,83,2065,2128,68,2049,0,2129,16,2130,89,65,1,65,65,80,68,2129,84,2128,2129,512]

theorem envBound26057 : H12AffineFastState.Bounded env26057 := by
  intro p hp
  have h : env26057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26056_26057 : H12AffineEnvironment.transform 14 2048 env26056 = env26057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env26056 == env26057) = true)

theorem identity26057 : scanCanonicalize (H12AffineFastState.compose env26057 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26057 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26058 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,2065,9,2049,2048,2,2065,2049,21,2049,0,2048,16,2051,8,16,1,16,16,1,21,2048,5,2049,2048,512]

theorem envBound26058 : H12AffineFastState.Bounded env26058 := by
  intro p hp
  have h : env26058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26057_26058 : H12AffineEnvironment.transform 5 17 env26057 = env26058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26057 == env26058) = true)

theorem identity26058 : scanCanonicalize (H12AffineFastState.compose env26058 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 527) := by decide +kernel

theorem selectedBound26058 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26059 : List Nat := [2,4,8,16,0,17,9,4,512,20,527,542,9,526,527,2,542,526,21,526,0,527,16,524,8,16,1,16,16,1,21,527,5,526,527,512]

theorem envBound26059 : H12AffineFastState.Bounded env26059 := by
  intro p hp
  have h : env26059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26058_26059 : H12AffineEnvironment.transform 10 527 env26058 = env26059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 527 env26058 == env26059) = true)

theorem identity26059 : scanCanonicalize (H12AffineFastState.compose env26059 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound26059 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26060 : List Nat := [2,4,8,16,0,17,9,4,15,20,0,17,9,1,0,2,17,1,21,1,0,0,16,3,8,16,1,16,16,1,21,0,5,1,0,15]

theorem envBound26060 : H12AffineFastState.Bounded env26060 := by
  intro p hp
  have h : env26060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26059_26060 : H12AffineEnvironment.transform 8 15 env26059 = env26060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env26059 == env26060) = true)

theorem identity26060 : scanCanonicalize (H12AffineFastState.compose env26060 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound26060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26061 : List Nat := [2,4,7,16,0,17,6,4,0,20,0,17,6,1,0,2,17,1,21,1,0,0,16,3,7,16,1,16,16,1,21,0,5,1,0,0]

theorem envBound26061 : H12AffineFastState.Bounded env26061 := by
  intro p hp
  have h : env26061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26060_26061 : H12AffineEnvironment.transform 2 7 env26060 = env26061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env26060 == env26061) = true)

theorem identity26061 : scanCanonicalize (H12AffineFastState.compose env26061 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26062 : List Nat := [2,4,7,1,0,0,6,4,0,5,0,0,6,1,0,2,0,1,4,1,0,0,1,3,7,1,1,1,1,1,4,0,5,1,0,0]

theorem envBound26062 : H12AffineFastState.Bounded env26062 := by
  intro p hp
  have h : env26062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26061_26062 : H12AffineEnvironment.transform 3 1 env26061 = env26062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26061 == env26062) = true)

def env26063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41311,8193,65,4262262,115014,45404,43048,75102,4268043,257,98679,90202,513]

theorem envBound26063 : H12AffineFastState.Bounded env26063 := by
  intro p hp
  have h : env26063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26047_26063 : H12AffineEnvironment.transform 17 10281 env26047 = env26063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26047 == env26063) = true)

theorem identity26063 : scanCanonicalize (H12AffineFastState.compose env26063 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26063 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58396,4194304,17,41311,8193,65,4204924,57676,45404,43048,1364,4194305,257,41341,16464,513]

theorem envBound26064 : H12AffineFastState.Bounded env26064 := by
  intro p hp
  have h : env26064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26063_26064 : H12AffineEnvironment.transform 15 8202 env26063 = env26064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26063 == env26064) = true)

theorem identity26064 : scanCanonicalize (H12AffineFastState.compose env26064 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound26064 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env26065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58396,113,17,41311,8193,65,10509,57676,45404,43048,1364,112,257,41341,16464,513]

theorem envBound26065 : H12AffineFastState.Bounded env26065 := by
  intro p hp
  have h : env26065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26064_26065 : H12AffineEnvironment.transform 21 113 env26064 = env26065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env26064 == env26065) = true)

theorem identity26065 : scanCanonicalize (H12AffineFastState.compose env26065 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26065 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env26066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,16400,2421,1025,32769,50496,113,17,32771,349,65,2129,49168,36864,35188,1364,112,257,32801,16464,513]

theorem envBound26066 : H12AffineFastState.Bounded env26066 := by
  intro p hp
  have h : env26066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26065_26066 : H12AffineEnvironment.transform 12 348 env26065 = env26066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26065 == env26066) = true)

theorem identity26066 : scanCanonicalize (H12AffineFastState.compose env26066 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26066 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26067 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16400,2341,1025,32769,50448,33,17,32771,269,17,2049,49168,36864,35108,1284,32,257,32801,16384,513]

theorem envBound26067 : H12AffineFastState.Bounded env26067 := by
  intro p hp
  have h : env26067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26066_26067 : H12AffineEnvironment.transform 5 16 env26066 = env26067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26066 == env26067) = true)

theorem identity26067 : scanCanonicalize (H12AffineFastState.compose env26067 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26067 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26068 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1025,0,17681,33,17,2,269,17,2049,16401,4097,2341,1284,32,257,32,16384,513]

theorem envBound26068 : H12AffineFastState.Bounded env26068 := by
  intro p hp
  have h : env26068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26067_26068 : H12AffineEnvironment.transform 14 1 env26067 = env26068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26067 == env26068) = true)

theorem identity26068 : scanCanonicalize (H12AffineFastState.compose env26068 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26069 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1025,0,4112,33,17,2,269,17,2049,5392,4097,2341,1284,32,257,32,5377,513]

theorem envBound26069 : H12AffineFastState.Bounded env26069 := by
  intro p hp
  have h : env26069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26068_26069 : H12AffineEnvironment.transform 13 5377 env26068 = env26069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26068 == env26069) = true)

theorem identity26069 : scanCanonicalize (H12AffineFastState.compose env26069 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound26069 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26070 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,268,1076,1,262,1060,2341,1025,0,293,33,17,2,269,17,2049,1061,308,2341,1284,32,257,32,1076,513]

theorem envBound26070 : H12AffineFastState.Bounded env26070 := by
  intro p hp
  have h : env26070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26069_26070 : H12AffineEnvironment.transform 11 309 env26069 = env26070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env26069 == env26070) = true)

theorem identity26070 : scanCanonicalize (H12AffineFastState.compose env26070 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound26070 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26071 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,309,268,292,1,262,308,2341,273,0,293,33,17,2,269,17,2049,309,308,2341,20,32,257,32,292,513]

theorem envBound26071 : H12AffineFastState.Bounded env26071 := by
  intro p hp
  have h : env26071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26070_26071 : H12AffineEnvironment.transform 9 272 env26070 = env26071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env26070 == env26071) = true)

theorem identity26071 : scanCanonicalize (H12AffineFastState.compose env26071 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26071 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26072 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,309,268,292,1,262,308,292,273,0,293,33,17,2,269,17,0,309,308,292,20,32,257,32,292,513]

theorem envBound26072 : H12AffineFastState.Bounded env26072 := by
  intro p hp
  have h : env26072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26071_26072 : H12AffineEnvironment.transform 10 1 env26071 = env26072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26071 == env26072) = true)

theorem identity26072 : scanCanonicalize (H12AffineFastState.compose env26072 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26072 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26073 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,40,0,1,34,16,0,53,0,1,33,17,2,41,17,0,17,16,0,20,32,37,32,0,513]

theorem envBound26073 : H12AffineFastState.Bounded env26073 := by
  intro p hp
  have h : env26073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26072_26073 : H12AffineEnvironment.transform 7 36 env26072 = env26073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26072 == env26073) = true)

theorem identity26073 : scanCanonicalize (H12AffineFastState.compose env26073 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound26073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26074 : List Nat := [2,4,8,16,32,16,9,36,17,52,1,17,40,0,1,34,16,0,53,0,1,33,17,2,41,17,0,17,16,0,20,32,37,32,0,16]

theorem envBound26074 : H12AffineFastState.Bounded env26074 := by
  intro p hp
  have h : env26074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26073_26074 : H12AffineEnvironment.transform 8 17 env26073 = env26074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env26073 == env26074) = true)

theorem identity26074 : scanCanonicalize (H12AffineFastState.compose env26074 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26075 : List Nat := [2,4,2,16,32,16,3,36,17,52,1,17,34,0,1,34,16,0,53,0,1,33,17,2,35,17,0,17,16,0,20,32,37,32,0,16]

theorem envBound26075 : H12AffineFastState.Bounded env26075 := by
  intro p hp
  have h : env26075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26074_26075 : H12AffineEnvironment.transform 2 2 env26074 = env26075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26074 == env26075) = true)

end H12CloudChart0