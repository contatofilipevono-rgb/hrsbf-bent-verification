import H12CloudChart0Data129

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound32992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32993 : List Nat := [2,4,8,0,0,0,9,4,0,5,0,0,9,1,1,3,0,0,4,0,1,1,1,3,8,1,1,1,1,0,5,0,5,1,1,1]

theorem envBound32993 : H12AffineFastState.Bounded env32993 := by
  intro p hp
  have h : env32993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32992_32993 : H12AffineEnvironment.transform 4 0 env32992 = env32993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32992 == env32993) = true)

def env32994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16401,10401,1025,8660,2097152,4194304,152,139,8328,65,4262263,2172371,2119113,2556,75222,6382923,257,2188651,2172186,512]

theorem envBound32994 : H12AffineFastState.Bounded env32994 := by
  intro p hp
  have h : env32994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32978_32994 : H12AffineEnvironment.transform 17 10401 env32978 = env32994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32978 == env32994) = true)

theorem identity32994 : scanCanonicalize (H12AffineFastState.compose env32994 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32994 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,17,2,8193,65,4262263,2172250,2118976,2421,75103,6382923,257,2188651,2172186,512]

theorem envBound32995 : H12AffineFastState.Bounded env32995 := by
  intro p hp
  have h : env32995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32994_32995 : H12AffineEnvironment.transform 6 9 env32994 = env32995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32994 == env32995) = true)

theorem identity32995 : scanCanonicalize (H12AffineFastState.compose env32995 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound32995 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91198,4194304,17,2,8193,65,4262263,16740,78206,2421,75103,4194677,257,341,16676,512]

theorem envBound32996 : H12AffineFastState.Bounded env32996 := by
  intro p hp
  have h : env32996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32995_32996 : H12AffineEnvironment.transform 20 91198 env32995 = env32996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env32995 == env32996) = true)

theorem identity32996 : scanCanonicalize (H12AffineFastState.compose env32996 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound32996 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91198,372,17,2,8193,65,67587,16740,78206,2421,75103,1,257,341,16676,512]

theorem envBound32997 : H12AffineFastState.Bounded env32997 := by
  intro p hp
  have h : env32997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32996_32997 : H12AffineEnvironment.transform 21 372 env32996 = env32997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env32996 == env32997) = true)

theorem identity32997 : scanCanonicalize (H12AffineFastState.compose env32997 (packedSelected [0,3,5,6,7,10,11,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32997 : packedSelected [0,3,5,6,7,10,11,17] rootPS < 2^1333 := by decide +kernel

def env32998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1025,8541,17460,372,17,2,8193,65,10249,16740,4468,2421,1365,1,257,341,16676,512]

theorem envBound32998 : H12AffineFastState.Bounded env32998 := by
  intro p hp
  have h : env32998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32997_32998 : H12AffineEnvironment.transform 15 8202 env32997 = env32998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32997 == env32998) = true)

theorem identity32998 : scanCanonicalize (H12AffineFastState.compose env32998 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32998 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32999 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,8202,16401,10280,1025,8232,17460,1,17,2,8193,65,10249,16401,4097,2048,1056,1,116,32,16465,512]

theorem envBound32999 : H12AffineFastState.Bounded env32999 := by
  intro p hp
  have h : env32999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32998_32999 : H12AffineEnvironment.transform 7 117 env32998 = env32999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32998 == env32999) = true)

theorem identity32999 : scanCanonicalize (H12AffineFastState.compose env32999 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32999 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33000 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,0,35,16401,2049,1025,1,17460,1,17,2,40,65,2080,16401,4097,2048,1056,1,116,32,16465,512]

theorem envBound33000 : H12AffineFastState.Bounded env33000 := by
  intro p hp
  have h : env33000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32999_33000 : H12AffineEnvironment.transform 12 41 env32999 = env33000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32999 == env33000) = true)

theorem identity33000 : scanCanonicalize (H12AffineFastState.compose env33000 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33000 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33001 : List Nat := [2,4,8,16,32,64,9,117,43,1024,2048,4096,41,16384,0,35,16401,2049,1025,1,17460,1,17,2,40,65,2080,16401,4097,2048,1056,1,116,32,16465,43]

theorem envBound33001 : H12AffineFastState.Bounded env33001 := by
  intro p hp
  have h : env33001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33000_33001 : H12AffineEnvironment.transform 8 43 env33000 = env33001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33000 == env33001) = true)

theorem identity33001 : scanCanonicalize (H12AffineFastState.compose env33001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33002 : List Nat := [2,4,8,16,32,64,9,117,43,1024,2048,4096,41,5236,0,35,5221,2049,1025,1,4160,1,17,2,40,65,2080,5221,4097,2048,1056,1,116,32,5157,43]

theorem envBound33002 : H12AffineFastState.Bounded env33002 := by
  intro p hp
  have h : env33002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33001_33002 : H12AffineEnvironment.transform 13 5236 env33001 = env33002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33001 == env33002) = true)

def env33003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound33003 : H12AffineFastState.Bounded env33003 := by
  intro p hp
  have h : env33003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32654_33003 : H12AffineEnvironment.transform 26 30393345 env32654 = env33003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env32654 == env33003) = true)

def env33004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound33004 : H12AffineFastState.Bounded env33004 := by
  intro p hp
  have h : env33004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33003_33004 : H12AffineEnvironment.transform 18 1024 env33003 = env33004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env33003 == env33004) = true)

theorem identity33004 : scanCanonicalize (H12AffineFastState.compose env33004 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923370) := by decide +kernel

theorem selectedBound33004 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923370,8328,65,6385003,8858086,10507601,8830977,2566522,13093035,256,485831,493667,2494125]

theorem envBound33005 : H12AffineFastState.Bounded env33005 := by
  intro p hp
  have h : env33005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33004_33005 : H12AffineEnvironment.transform 23 10923370 env33004 = env33005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923370 env33004 == env33005) = true)

def env33006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452648,2114882,8328,65,6385003,115150,2538873,10281,2566522,4268163,256,485831,493667,2494125]

theorem envBound33006 : H12AffineFastState.Bounded env33006 := by
  intro p hp
  have h : env33006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33005_33006 : H12AffineEnvironment.transform 22 452648 env33005 = env33006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env33005 == env33006) = true)

def env33007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,441658,8328,65,4691219,115150,17665,10281,119042,4268163,256,485831,493667,63189]

theorem envBound33007 : H12AffineFastState.Bounded env33007 := by
  intro p hp
  have h : env33007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33006_33007 : H12AffineEnvironment.transform 20 456824 env33006 = env33007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env33006 == env33007) = true)

def env33008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,441658,8328,65,245139,115150,17665,10281,119042,329731,256,485831,493667,63189]

theorem envBound33008 : H12AffineFastState.Bounded env33008 := by
  intro p hp
  have h : env33008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33007_33008 : H12AffineEnvironment.transform 21 272512 env33007 = env33008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33007 == env33008) = true)

theorem identity33008 : scanCanonicalize (H12AffineFastState.compose env33008 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound33008 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180408,16,21762,8328,65,245139,115150,17665,10281,119042,254011,256,98815,90203,63189]

theorem envBound33009 : H12AffineFastState.Bounded env33009 := by
  intro p hp
  have h : env33009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33008_33009 : H12AffineEnvironment.transform 17 190520 env33008 = env33009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env33008 == env33009) = true)

def env33010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180272,16,21762,8192,65,245019,115014,17665,10281,119042,254011,256,98679,90203,63069]

theorem envBound33010 : H12AffineFastState.Bounded env33010 := by
  intro p hp
  have h : env33010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33009_33010 : H12AffineEnvironment.transform 6 8 env33009 = env33010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33009 == env33010) = true)

theorem identity33010 : scanCanonicalize (H12AffineFastState.compose env33010 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound33010 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,32,16,21762,8192,65,97547,115014,17665,10281,119042,73771,256,98679,90203,63069]

theorem envBound33011 : H12AffineFastState.Bounded env33011 := by
  intro p hp
  have h : env33011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33010_33011 : H12AffineEnvironment.transform 16 49168 env33010 = env33011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33010 == env33011) = true)

theorem identity33011 : scanCanonicalize (H12AffineFastState.compose env33011 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound33011 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env33012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5440,10280,1024,21841,4160,32,16,21762,8192,65,97547,70678,17665,10281,66642,73771,256,87079,90203,8973]

theorem envBound33012 : H12AffineFastState.Bounded env33012 := by
  intro p hp
  have h : env33012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33011_33012 : H12AffineEnvironment.transform 14 21840 env33011 = env33012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env33011 == env33012) = true)

theorem identity33012 : scanCanonicalize (H12AffineFastState.compose env33012 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33012 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21840,65536,5440,2420,1024,21841,4160,32,16,21762,348,65,89175,70678,17665,2421,66642,65911,256,87079,82183,593]

theorem envBound33013 : H12AffineFastState.Bounded env33013 := by
  intro p hp
  have h : env33013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33012_33013 : H12AffineEnvironment.transform 12 348 env33012 = env33013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33012 == env33013) = true)

theorem identity33013 : scanCanonicalize (H12AffineFastState.compose env33013 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound33013 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env33014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,0,65536,5440,2420,1024,1,4160,32,16,82,348,65,67847,70678,4177,2421,66642,65911,256,65911,70743,593]

theorem envBound33014 : H12AffineFastState.Bounded env33014 := by
  intro p hp
  have h : env33014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33013_33014 : H12AffineEnvironment.transform 13 5456 env33013 = env33014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env33013 == env33014) = true)

theorem identity33014 : scanCanonicalize (H12AffineFastState.compose env33014 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound33014 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3392,0,65536,3408,2420,1024,1,2128,32,16,82,348,65,67847,68614,2113,2421,66642,65911,256,65911,68679,593]

theorem envBound33015 : H12AffineFastState.Bounded env33015 := by
  intro p hp
  have h : env33015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33014_33015 : H12AffineEnvironment.transform 11 2064 env33014 = env33015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env33014 == env33015) = true)

theorem identity33015 : scanCanonicalize (H12AffineFastState.compose env33015 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound33015 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env33016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3392,0,263,3408,2420,1024,1,2128,32,16,82,348,65,2048,3329,2113,2421,1365,112,256,112,3392,593]

theorem envBound33016 : H12AffineFastState.Bounded env33016 := by
  intro p hp
  have h : env33016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33015_33016 : H12AffineEnvironment.transform 15 263 env33015 = env33016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env33015 == env33016) = true)

theorem identity33016 : scanCanonicalize (H12AffineFastState.compose env33016 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound33016 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33017 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,2064,348,2161,0,263,2145,2420,305,1,2128,32,16,82,348,65,2048,2096,2113,2421,100,112,256,112,2161,593]

theorem envBound33017 : H12AffineFastState.Bounded env33017 := by
  intro p hp
  have h : env33017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33016_33017 : H12AffineEnvironment.transform 9 305 env33016 = env33017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env33016 == env33017) = true)

theorem identity33017 : scanCanonicalize (H12AffineFastState.compose env33017 (packedSelected [1,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33017 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env33018 : List Nat := [2,4,8,16,32,64,8,256,512,305,1,17,348,112,0,263,96,373,305,1,81,32,16,82,348,65,1,49,64,372,100,112,256,112,112,593]

theorem envBound33018 : H12AffineFastState.Bounded env33018 := by
  intro p hp
  have h : env33018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33017_33018 : H12AffineEnvironment.transform 10 1 env33017 = env33018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33017 == env33018) = true)

theorem identity33018 : scanCanonicalize (H12AffineFastState.compose env33018 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33018 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env33019 : List Nat := [2,4,8,16,32,49,8,256,512,305,1,17,301,1,0,263,17,260,305,1,32,32,16,35,301,48,1,49,49,261,21,1,256,1,1,544]

theorem envBound33019 : H12AffineFastState.Bounded env33019 := by
  intro p hp
  have h : env33019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33018_33019 : H12AffineEnvironment.transform 5 49 env33018 = env33019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33018 == env33019) = true)

theorem identity33019 : scanCanonicalize (H12AffineFastState.compose env33019 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33019 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33020 : List Nat := [2,4,8,16,1,16,8,256,512,272,1,17,268,1,0,263,17,260,272,1,1,1,16,2,268,17,1,16,16,261,21,1,256,1,1,513]

theorem envBound33020 : H12AffineFastState.Bounded env33020 := by
  intro p hp
  have h : env33020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33019_33020 : H12AffineEnvironment.transform 4 1 env33019 = env33020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33019 == env33020) = true)

theorem identity33020 : scanCanonicalize (H12AffineFastState.compose env33020 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33020 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33021 : List Nat := [2,4,8,0,1,0,8,256,512,256,1,1,268,1,0,263,1,260,256,1,1,1,0,2,268,1,1,0,0,261,5,1,256,1,1,513]

theorem envBound33021 : H12AffineFastState.Bounded env33021 := by
  intro p hp
  have h : env33021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33020_33021 : H12AffineEnvironment.transform 3 0 env33020 = env33021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33020 == env33021) = true)

def env33022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180273,16,21762,8193,65,245018,115015,17665,10281,119042,254011,256,98678,90203,63068]

theorem envBound33022 : H12AffineFastState.Bounded env33022 := by
  intro p hp
  have h : env33022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33009_33022 : H12AffineEnvironment.transform 6 9 env33009 = env33022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33009 == env33022) = true)

theorem identity33022 : scanCanonicalize (H12AffineFastState.compose env33022 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound33022 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4160,41341,16,21762,8193,65,121942,115015,17665,10281,119042,98679,256,98678,90203,63068]

theorem envBound33023 : H12AffineFastState.Bounded env33023 := by
  intro p hp
  have h : env33023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33022_33023 : H12AffineEnvironment.transform 16 24908 env33022 = env33023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env33022 == env33023) = true)

theorem identity33023 : scanCanonicalize (H12AffineFastState.compose env33023 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound33023 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,24908,35188,1024,32769,4160,41341,16,21762,8193,65,31837,24908,17665,10281,28937,8572,256,8573,49232,63068]

theorem envBound33024 : H12AffineFastState.Bounded env33024 := by
  intro p hp
  have h : env33024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33023_33024 : H12AffineEnvironment.transform 15 40971 env33023 = env33024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env33023 == env33024) = true)

theorem identity33024 : scanCanonicalize (H12AffineFastState.compose env33024 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound33024 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env33025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,30072,21875,24908,31756,1024,30073,4160,21509,16,21762,8193,65,31837,24908,17665,10281,28937,8572,256,8573,13608,804]

theorem envBound33025 : H12AffineFastState.Bounded env33025 := by
  intro p hp
  have h : env33025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33024_33025 : H12AffineEnvironment.transform 14 30072 env33024 = env33025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env33024 == env33025) = true)

theorem identity33025 : scanCanonicalize (H12AffineFastState.compose env33025 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33025 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env33026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8313,114,13389,10509,1024,8312,4160,260,16,3,8193,65,10588,13389,4096,10281,9224,8572,256,8573,13608,804]

theorem envBound33026 : H12AffineFastState.Bounded env33026 := by
  intro p hp
  have h : env33026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33025_33026 : H12AffineEnvironment.transform 13 5377 env33025 = env33026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33025 == env33026) = true)

theorem identity33026 : scanCanonicalize (H12AffineFastState.compose env33026 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound33026 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env33027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,3125,8313,114,11641,10509,1024,8312,2420,260,16,3,8193,65,10588,11641,2356,10281,9224,8572,256,8573,11292,804]

theorem envBound33027 : H12AffineFastState.Bounded env33027 := by
  intro p hp
  have h : env33027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33026_33027 : H12AffineEnvironment.transform 11 2356 env33026 = env33027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env33026 == env33027) = true)

theorem identity33027 : scanCanonicalize (H12AffineFastState.compose env33027 (packedSelected [2,4,5,6,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33027 : packedSelected [2,4,5,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env33028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,348,3125,293,114,3109,2129,1024,292,2420,260,16,3,349,65,2048,3109,2356,2421,1364,32,256,33,3392,804]

theorem envBound33028 : H12AffineFastState.Bounded env33028 := by
  intro p hp
  have h : env33028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33027_33028 : H12AffineEnvironment.transform 12 348 env33027 = env33028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33027 == env33028) = true)

theorem identity33028 : scanCanonicalize (H12AffineFastState.compose env33028 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33028 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33029 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,2096,88,3125,33,114,3109,2129,1024,32,2160,0,16,3,89,65,2048,3109,2096,2161,1104,32,4,33,3140,544]

theorem envBound33029 : H12AffineFastState.Bounded env33029 := by
  intro p hp
  have h : env33029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33028_33029 : H12AffineEnvironment.transform 7 4 env33028 = env33029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33028 == env33029) = true)

theorem identity33029 : scanCanonicalize (H12AffineFastState.compose env33029 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound33029 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env33030 : List Nat := [2,4,8,16,32,64,9,4,512,1024,1044,1060,88,33,33,114,49,1093,1024,32,1124,0,16,3,89,65,1044,49,1060,1125,1104,32,4,33,80,544]

theorem envBound33030 : H12AffineFastState.Bounded env33030 := by
  intro p hp
  have h : env33030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33029_33030 : H12AffineEnvironment.transform 10 1044 env33029 = env33030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env33029 == env33030) = true)

theorem identity33030 : scanCanonicalize (H12AffineFastState.compose env33030 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33030 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33031 : List Nat := [2,4,8,16,32,64,9,4,512,53,33,17,88,33,33,114,49,112,53,32,81,0,16,3,89,65,33,49,17,80,101,32,4,33,80,544]

theorem envBound33031 : H12AffineFastState.Bounded env33031 := by
  intro p hp
  have h : env33031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33030_33031 : H12AffineEnvironment.transform 9 53 env33030 = env33031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33030 == env33031) = true)

def env33032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,441658,8328,65,245138,115150,17665,10281,119042,329730,256,485831,493667,63189]

theorem envBound33032 : H12AffineFastState.Bounded env33032 := by
  intro p hp
  have h : env33032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33007_33032 : H12AffineEnvironment.transform 21 272513 env33007 = env33032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33007 == env33032) = true)

def env33033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452648,441658,8192,65,245018,115014,17665,10281,119042,329730,256,485711,493667,63069]

theorem envBound33033 : H12AffineFastState.Bounded env33033 := by
  intro p hp
  have h : env33033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33032_33033 : H12AffineEnvironment.transform 6 8 env33032 = env33033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33032 == env33033) = true)

def env33034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272393,272440,294186,8192,65,97546,115014,17665,10281,119042,329730,256,371039,346227,63069]

theorem envBound33034 : H12AffineFastState.Bounded env33034 := by
  intro p hp
  have h : env33034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33033_33034 : H12AffineEnvironment.transform 16 49168 env33033 = env33034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33033 == env33034) = true)

theorem identity33034 : scanCanonicalize (H12AffineFastState.compose env33034 (packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound33034 : packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env33035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56356,1024,32769,58444,62509,62492,41230,8192,65,97546,115014,17665,10281,119042,119846,256,95611,103511,63069]

theorem envBound33035 : H12AffineFastState.Bounded env33035 := by
  intro p hp
  have h : env33035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33034_33035 : H12AffineEnvironment.transform 17 56356 env33034 = env33035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env33034 == env33035) = true)

theorem identity33035 : scanCanonicalize (H12AffineFastState.compose env33035 (packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33035 : packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,10361,1024,29788,4113,112,65,21843,8192,65,97546,79131,17665,10281,75103,73851,256,95611,90122,512]

theorem envBound33036 : H12AffineFastState.Bounded env33036 := by
  intro p hp
  have h : env33036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33035_33036 : H12AffineEnvironment.transform 14 29789 env33035 = env33036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33035 == env33036) = true)

theorem identity33036 : scanCanonicalize (H12AffineFastState.compose env33036 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound33036 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env33037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,30042,13389,10361,1024,29788,4113,112,65,21843,8192,65,2128,16449,17665,10281,20485,21793,256,33,5456,512]

theorem envBound33037 : H12AffineFastState.Bounded env33037 := by
  intro p hp
  have h : env33037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33036_33037 : H12AffineEnvironment.transform 15 30042 env33036 = env33037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env33036 == env33037) = true)

theorem identity33037 : scanCanonicalize (H12AffineFastState.compose env33037 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound33037 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9529,9278,13389,10361,1024,9528,4113,112,65,1079,8192,65,2128,4389,5221,10281,353,1093,256,33,5456,512]

theorem envBound33038 : H12AffineFastState.Bounded env33038 := by
  intro p hp
  have h : env33038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33037_33038 : H12AffineEnvironment.transform 13 4452 env33037 = env33038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env33037 == env33038) = true)

theorem identity33038 : scanCanonicalize (H12AffineFastState.compose env33038 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound33038 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env33039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4452,81,342,4389,3345,1024,80,4113,112,65,1079,1384,65,2128,4389,5221,3393,353,1093,256,33,5456,512]

theorem envBound33039 : H12AffineFastState.Bounded env33039 := by
  intro p hp
  have h : env33039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33038_33039 : H12AffineEnvironment.transform 12 1384 env33038 = env33039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env33038 == env33039) = true)

theorem identity33039 : scanCanonicalize (H12AffineFastState.compose env33039 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33039 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33040 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,1305,4373,32,295,4389,3345,1024,33,4113,1,48,1079,1305,48,2081,4389,5140,3376,272,1076,256,33,5409,512]

theorem envBound33040 : H12AffineFastState.Bounded env33040 := by
  intro p hp
  have h : env33040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33039_33040 : H12AffineEnvironment.transform 5 49 env33039 = env33040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33039 == env33040) = true)

theorem identity33040 : scanCanonicalize (H12AffineFastState.compose env33040 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33040 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env33041 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,1305,4373,1,262,4356,3345,1024,0,4113,1,17,1046,1305,17,2048,4356,5140,3345,272,1045,256,0,5376,512]

theorem envBound33041 : H12AffineFastState.Bounded env33041 := by
  intro p hp
  have h : env33041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33040_33041 : H12AffineEnvironment.transform 4 1 env33040 = env33041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33040 == env33041) = true)

theorem identity33041 : scanCanonicalize (H12AffineFastState.compose env33041 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33041 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33042 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,1052,4112,1,3,4097,3092,1024,0,4113,1,17,1046,1052,17,2048,4097,5140,3092,21,1045,5,0,5125,512]

theorem envBound33042 : H12AffineFastState.Bounded env33042 := by
  intro p hp
  have h : env33042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33041_33042 : H12AffineEnvironment.transform 7 5 env33041 = env33042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33041 == env33042) = true)

def env33043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272393,272441,294187,8192,65,97547,115014,17665,10281,119042,329730,256,371038,346226,63069]

theorem envBound33043 : H12AffineFastState.Bounded env33043 := by
  intro p hp
  have h : env33043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33033_33043 : H12AffineEnvironment.transform 16 49169 env33033 = env33043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env33033 == env33043) = true)

theorem identity33043 : scanCanonicalize (H12AffineFastState.compose env33043 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound33043 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,33,17,21763,8192,65,97547,115014,17665,10281,119042,73770,256,98678,90202,63069]

theorem envBound33044 : H12AffineFastState.Bounded env33044 := by
  intro p hp
  have h : env33044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33043_33044 : H12AffineEnvironment.transform 17 10280 env33043 = env33044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33043 == env33044) = true)

theorem identity33044 : scanCanonicalize (H12AffineFastState.compose env33044 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound33044 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env33045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62811,49169,10280,1024,32769,4161,33,17,21763,8192,65,34896,13341,17665,10281,9305,54641,256,29741,38145,63069]

theorem envBound33045 : H12AffineFastState.Bounded env33045 := by
  intro p hp
  have h : env33045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33044_33045 : H12AffineEnvironment.transform 15 62811 env33044 = env33045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env33044 == env33045) = true)

theorem identity33045 : scanCanonicalize (H12AffineFastState.compose env33045 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound33045 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env33046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,343,13341,10280,1024,29709,4161,33,17,21763,8192,65,31836,13341,17665,10281,9305,8573,256,29741,24845,593]

theorem envBound33046 : H12AffineFastState.Bounded env33046 := by
  intro p hp
  have h : env33046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33045_33046 : H12AffineEnvironment.transform 14 29708 env33045 = env33046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env33045 == env33046) = true)

def env33047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452648,441658,8193,65,245019,115015,17665,10281,119042,329730,256,485710,493667,63068]

theorem envBound33047 : H12AffineFastState.Bounded env33047 := by
  intro p hp
  have h : env33047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33032_33047 : H12AffineEnvironment.transform 6 9 env33032 = env33047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33032 == env33047) = true)

def env33048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272440,294186,8193,65,97547,115015,17665,10281,119042,329730,256,371038,346227,63068]

theorem envBound33048 : H12AffineFastState.Bounded env33048 := by
  intro p hp
  have h : env33048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33047_33048 : H12AffineEnvironment.transform 16 49168 env33047 = env33048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33047 == env33048) = true)

theorem identity33048 : scanCanonicalize (H12AffineFastState.compose env33048 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound33048 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,45340,41340,41292,62558,8193,65,97547,115015,17665,10281,119042,98678,256,73770,114951,63068]

theorem envBound33049 : H12AffineFastState.Bounded env33049 := by
  intro p hp
  have h : env33049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33048_33049 : H12AffineEnvironment.transform 17 35188 env33048 = env33049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env33048 == env33049) = true)

theorem identity33049 : scanCanonicalize (H12AffineFastState.compose env33049 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound33049 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env33050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,65536,16741,2049,1024,372,12393,8201,8249,29995,8193,65,97547,81970,17665,10281,86135,65539,256,73770,82034,30505]

theorem envBound33050 : H12AffineFastState.Bounded env33050 := by
  intro p hp
  have h : env33050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33049_33050 : H12AffineEnvironment.transform 14 373 env33049 = env33050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env33049 == env33050) = true)

theorem identity33050 : scanCanonicalize (H12AffineFastState.compose env33050 (packedSelected [0,2,4,6,7,8,9,10,11,12,14,15,16,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound33050 : packedSelected [0,2,4,6,7,8,9,10,11,12,14,15,16,20,23,28] rootPS < 2^1333 := by decide +kernel

def env33051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,35,16741,2049,1024,372,12393,8201,8249,29995,8193,65,32040,16401,17665,10281,20564,32,256,8201,16465,30505]

theorem envBound33051 : H12AffineFastState.Bounded env33051 := by
  intro p hp
  have h : env33051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33050_33051 : H12AffineEnvironment.transform 15 35 env33050 = env33051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env33050 == env33051) = true)

theorem identity33051 : scanCanonicalize (H12AffineFastState.compose env33051 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound33051 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env33052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,373,35,13388,2049,1024,372,12393,8201,8249,2,8193,65,2049,13624,12328,10281,9597,32,256,8201,13688,512]

theorem envBound33052 : H12AffineFastState.Bounded env33052 := by
  intro p hp
  have h : env33052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33051_33052 : H12AffineEnvironment.transform 13 13609 env33051 = env33052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env33051 == env33052) = true)

theorem identity33052 : scanCanonicalize (H12AffineFastState.compose env33052 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33052 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33053 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,1,35,13388,2049,1024,0,12393,8201,8249,2,8193,65,2049,13388,12328,10281,9225,32,116,8201,13324,512]

theorem envBound33053 : H12AffineFastState.Bounded env33053 := by
  intro p hp
  have h : env33053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33052_33053 : H12AffineEnvironment.transform 7 116 env33052 = env33053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33052 == env33053) = true)

theorem identity33053 : scanCanonicalize (H12AffineFastState.compose env33053 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound33053 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33054 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,9,5204,1,35,5189,2049,1024,0,4192,0,48,2,8,65,2049,5189,4129,2080,1024,32,116,0,5125,512]

theorem envBound33054 : H12AffineFastState.Bounded env33054 := by
  intro p hp
  have h : env33054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33053_33054 : H12AffineEnvironment.transform 12 9 env33053 = env33054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env33053 == env33054) = true)

theorem identity33054 : scanCanonicalize (H12AffineFastState.compose env33054 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound33054 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33055 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1044,4096,9,5204,1,35,5189,1045,1024,0,4192,0,48,2,8,65,1045,5189,4129,1076,1024,32,116,0,5125,512]

theorem envBound33055 : H12AffineFastState.Bounded env33055 := by
  intro p hp
  have h : env33055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33054_33055 : H12AffineEnvironment.transform 10 1044 env33054 = env33055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env33054 == env33055) = true)

theorem identity33055 : scanCanonicalize (H12AffineFastState.compose env33055 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound33055 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env33056 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1044,16,9,1092,1,35,1109,1045,1024,0,112,0,48,2,8,65,1045,1109,49,1076,1024,32,116,0,1045,512]

theorem envBound33056 : H12AffineFastState.Bounded env33056 := by
  intro p hp
  have h : env33056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33055_33056 : H12AffineEnvironment.transform 11 16 env33055 = env33056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33055 == env33056) = true)

theorem identity33056 : scanCanonicalize (H12AffineFastState.compose env33056 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33056 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33057 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1044,16,9,1044,1,35,1029,1045,1024,0,32,0,48,2,8,17,1045,1029,49,1076,1024,32,36,0,1045,512]

theorem envBound33057 : H12AffineFastState.Bounded env33057 := by
  intro p hp
  have h : env33057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33056_33057 : H12AffineEnvironment.transform 5 16 env33056 = env33057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33056 == env33057) = true)

theorem identity33057 : scanCanonicalize (H12AffineFastState.compose env33057 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33057 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env33058 : List Nat := [2,4,8,16,32,16,9,36,512,21,1,16,9,1,1,35,16,0,21,0,32,0,48,2,8,17,0,16,49,33,21,32,36,0,0,512]

theorem envBound33058 : H12AffineFastState.Bounded env33058 := by
  intro p hp
  have h : env33058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33057_33058 : H12AffineEnvironment.transform 9 21 env33057 = env33058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33057 == env33058) = true)

theorem identity33058 : scanCanonicalize (H12AffineFastState.compose env33058 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33058 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env33059 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,16,9,1,1,2,16,0,21,0,1,0,17,2,8,17,0,16,16,0,21,1,5,0,0,512]

theorem envBound33059 : H12AffineFastState.Bounded env33059 := by
  intro p hp
  have h : env33059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33058_33059 : H12AffineEnvironment.transform 4 1 env33058 = env33059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33058 == env33059) = true)

theorem identity33059 : scanCanonicalize (H12AffineFastState.compose env33059 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33060 : List Nat := [2,4,8,16,1,16,9,5,0,21,1,16,9,1,1,2,16,0,21,0,1,0,17,2,8,17,0,16,16,0,21,1,5,0,0,0]

theorem envBound33060 : H12AffineFastState.Bounded env33060 := by
  intro p hp
  have h : env33060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33059_33060 : H12AffineEnvironment.transform 8 0 env33059 = env33060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33059 == env33060) = true)

theorem identity33060 : scanCanonicalize (H12AffineFastState.compose env33060 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound33060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33061 : List Nat := [2,4,8,15,1,15,9,5,0,10,1,15,9,1,1,2,15,0,10,0,1,0,14,2,8,14,0,15,15,0,10,1,5,0,0,0]

theorem envBound33061 : H12AffineFastState.Bounded env33061 := by
  intro p hp
  have h : env33061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33060_33061 : H12AffineEnvironment.transform 3 15 env33060 = env33061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env33060 == env33061) = true)

def env33062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272441,294187,8193,65,97546,115015,17665,10281,119042,329730,256,371039,346226,63068]

theorem envBound33062 : H12AffineFastState.Bounded env33062 := by
  intro p hp
  have h : env33062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33047_33062 : H12AffineEnvironment.transform 16 49169 env33047 = env33062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env33047 == env33062) = true)

theorem identity33062 : scanCanonicalize (H12AffineFastState.compose env33062 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33062 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1024,8540,276585,272392,272441,294187,8193,65,97546,90138,17665,10281,94303,329730,256,329730,346226,22273]

theorem envBound33063 : H12AffineFastState.Bounded env33063 := by
  intro p hp
  have h : env33063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33062_33063 : H12AffineEnvironment.transform 14 8541 env33062 = env33063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33062 == env33063) = true)

theorem identity33063 : scanCanonicalize (H12AffineFastState.compose env33063 (packedSelected [3,4,5,7,8,9,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound33063 : packedSelected [3,4,5,7,8,9,27,28] rootPS < 2^1333 := by decide +kernel

def env33064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,2420,1024,8540,12573,8572,8525,29791,8193,65,97546,90138,17665,10281,94303,65910,256,65910,82182,22273]

theorem envBound33064 : H12AffineFastState.Bounded env33064 := by
  intro p hp
  have h : env33064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33063_33064 : H12AffineEnvironment.transform 17 2420 env33063 = env33064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env33063 == env33064) = true)

theorem identity33064 : scanCanonicalize (H12AffineFastState.compose env33064 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33064 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env33065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,24908,2420,1024,8540,12573,8572,8525,29791,8193,65,31836,24908,17665,10281,28937,32,256,32,16464,22273]

theorem envBound33065 : H12AffineFastState.Bounded env33065 := by
  intro p hp
  have h : env33065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33064_33065 : H12AffineEnvironment.transform 15 342 env33064 = env33065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33064 == env33065) = true)

def env33066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,441659,8328,65,4691218,115150,17664,10281,119043,4268163,256,485831,493667,63188]

theorem envBound33066 : H12AffineFastState.Bounded env33066 := by
  intro p hp
  have h : env33066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33006_33066 : H12AffineEnvironment.transform 20 456825 env33006 = env33066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env33006 == env33066) = true)

def env33067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,441659,8328,65,245138,115150,17664,10281,119043,329731,256,485831,493667,63188]

theorem envBound33067 : H12AffineFastState.Bounded env33067 := by
  intro p hp
  have h : env33067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33066_33067 : H12AffineEnvironment.transform 21 272512 env33066 = env33067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33066 == env33067) = true)

theorem identity33067 : scanCanonicalize (H12AffineFastState.compose env33067 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound33067 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,58516,144493,62661,41430,8328,65,245138,115150,17664,10281,119043,201966,256,95530,103566,63188]

theorem envBound33068 : H12AffineFastState.Bounded env33068 := by
  intro p hp
  have h : env33068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33067_33068 : H12AffineEnvironment.transform 17 138477 env33067 = env33068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env33067 == env33068) = true)

def env33069 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138429,1024,32769,58516,144445,62613,41350,8328,17,245138,115102,17664,10281,119043,201918,256,95530,103566,63108]

theorem envBound33069 : H12AffineFastState.Bounded env33069 := by
  intro p hp
  have h : env33069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33068_33069 : H12AffineEnvironment.transform 5 16 env33068 = env33069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33068 == env33069) = true)

theorem identity33069 : scanCanonicalize (H12AffineFastState.compose env33069 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound33069 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env33070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,138429,1024,8461,17816,144445,21913,138,8328,17,203934,90258,17664,10281,94223,201918,256,95530,79234,22408]

theorem envBound33070 : H12AffineFastState.Bounded env33070 := by
  intro p hp
  have h : env33070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33069_33070 : H12AffineEnvironment.transform 14 8460 env33069 = env33070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env33069 == env33070) = true)

theorem identity33070 : scanCanonicalize (H12AffineFastState.compose env33070 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound33070 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33071 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,13341,10400,1024,8461,17816,32,21913,138,8328,17,75907,90258,17664,10281,94223,73891,256,95530,79234,22408]

theorem envBound33071 : H12AffineFastState.Bounded env33071 := by
  intro p hp
  have h : env33071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33070_33071 : H12AffineEnvironment.transform 16 13341 env33070 = env33071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env33070 == env33071) = true)

theorem identity33071 : scanCanonicalize (H12AffineFastState.compose env33071 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,13341,10280,1024,8461,17680,32,21777,2,8192,17,75787,90138,17664,10281,94223,73771,256,95530,79114,22272]

theorem envBound33072 : H12AffineFastState.Bounded env33072 := by
  intro p hp
  have h : env33072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33071_33072 : H12AffineEnvironment.transform 6 8 env33071 = env33072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33071 == env33072) = true)

theorem identity33072 : scanCanonicalize (H12AffineFastState.compose env33072 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound33072 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env33073 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,3345,8460,65536,13341,10280,1024,8461,2049,32,6144,2,8192,17,75787,77067,2065,10281,81182,73771,256,79931,79114,6673]

theorem envBound33073 : H12AffineFastState.Bounded env33073 := by
  intro p hp
  have h : env33073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33072_33073 : H12AffineEnvironment.transform 13 3345 env33072 = env33073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env33072 == env33073) = true)

theorem identity33073 : scanCanonicalize (H12AffineFastState.compose env33073 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound33073 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env33074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6428,3345,6160,65536,3329,4404,1024,6161,2049,32,6144,2,6428,17,69911,70679,2065,4405,66562,71991,256,65831,68630,6673]

theorem envBound33074 : H12AffineFastState.Bounded env33074 := by
  intro p hp
  have h : env33074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33073_33074 : H12AffineEnvironment.transform 12 6428 env33073 = env33074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env33073 == env33074) = true)

theorem identity33074 : scanCanonicalize (H12AffineFastState.compose env33074 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound33074 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6428,3345,6160,263,3329,4404,1024,6161,2049,32,6144,2,6428,17,4112,5392,2065,4405,1285,6192,256,32,3345,6673]

theorem envBound33075 : H12AffineFastState.Bounded env33075 := by
  intro p hp
  have h : env33075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33074_33075 : H12AffineEnvironment.transform 15 263 env33074 = env33075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env33074 == env33075) = true)

theorem identity33075 : scanCanonicalize (H12AffineFastState.compose env33075 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound33075 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env33076 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1573,4096,5945,820,5685,263,804,4404,1024,5684,1572,32,5669,2,5945,17,4112,5392,1588,4405,1285,5653,256,32,820,5172]

theorem envBound33076 : H12AffineFastState.Bounded env33076 := by
  intro p hp
  have h : env33076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33075_33076 : H12AffineEnvironment.transform 10 1573 env33075 = env33076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env33075 == env33076) = true)

theorem identity33076 : scanCanonicalize (H12AffineFastState.compose env33076 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound33076 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env33077 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1573,512,1337,820,1077,263,804,820,1024,1076,1572,32,1061,2,1337,17,528,1808,1588,821,1285,1045,256,32,820,1588]

theorem envBound33077 : H12AffineFastState.Bounded env33077 := by
  intro p hp
  have h : env33077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33076_33077 : H12AffineEnvironment.transform 11 512 env33076 = env33077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env33076 == env33077) = true)

theorem identity33077 : scanCanonicalize (H12AffineFastState.compose env33077 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound33077 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33078 : List Nat := [2,4,8,16,32,16,8,256,512,304,789,512,9,820,261,263,804,820,304,260,788,32,277,2,9,17,528,544,772,821,53,293,256,32,820,772]

theorem envBound33078 : H12AffineFastState.Bounded env33078 := by
  intro p hp
  have h : env33078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33077_33078 : H12AffineEnvironment.transform 9 304 env33077 = env33078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env33077 == env33078) = true)

theorem identity33078 : scanCanonicalize (H12AffineFastState.compose env33078 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound33078 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33079 : List Nat := [2,4,8,16,32,16,8,256,48,304,293,48,9,260,261,263,276,260,304,260,292,32,277,2,9,17,32,16,308,261,53,293,256,32,260,308]

theorem envBound33079 : H12AffineFastState.Bounded env33079 := by
  intro p hp
  have h : env33079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33078_33079 : H12AffineEnvironment.transform 8 48 env33078 = env33079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33078 == env33079) = true)

theorem identity33079 : scanCanonicalize (H12AffineFastState.compose env33079 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33079 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33080 : List Nat := [2,4,8,16,16,16,8,256,0,256,277,0,9,260,261,263,276,260,256,260,276,16,277,2,9,17,16,16,260,261,5,277,256,16,260,260]

theorem envBound33080 : H12AffineFastState.Bounded env33080 := by
  intro p hp
  have h : env33080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33079_33080 : H12AffineEnvironment.transform 4 16 env33079 = env33080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33079 == env33080) = true)

theorem identity33080 : scanCanonicalize (H12AffineFastState.compose env33080 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33081 : List Nat := [2,4,8,16,16,16,8,4,0,4,17,0,9,0,1,3,16,0,4,0,16,16,17,2,9,17,16,16,0,1,5,17,4,16,0,0]

theorem envBound33081 : H12AffineFastState.Bounded env33081 := by
  intro p hp
  have h : env33081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33080_33081 : H12AffineEnvironment.transform 7 4 env33080 = env33081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33080 == env33081) = true)

theorem identity33081 : scanCanonicalize (H12AffineFastState.compose env33081 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33081 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33082 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,0,9,0,1,3,1,0,4,0,1,1,0,2,9,0,1,1,0,1,5,0,4,1,0,0]

theorem envBound33082 : H12AffineFastState.Bounded env33082 := by
  intro p hp
  have h : env33082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33081_33082 : H12AffineEnvironment.transform 3 1 env33081 = env33082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33081 == env33082) = true)

theorem identity33082 : scanCanonicalize (H12AffineFastState.compose env33082 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33083 : List Nat := [2,0,8,1,1,1,8,0,0,0,0,0,9,0,1,3,1,0,0,0,1,1,0,2,9,0,1,1,0,1,1,0,0,1,0,0]

theorem envBound33083 : H12AffineFastState.Bounded env33083 := by
  intro p hp
  have h : env33083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33082_33083 : H12AffineEnvironment.transform 1 0 env33082 = env33083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33082 == env33083) = true)

def env33084 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138428,1024,32769,58516,144444,62612,41351,8328,16,245138,115103,17664,10281,119043,201919,256,95530,103566,63109]

theorem envBound33084 : H12AffineFastState.Bounded env33084 := by
  intro p hp
  have h : env33084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33068_33084 : H12AffineEnvironment.transform 5 17 env33068 = env33084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33068 == env33084) = true)

theorem identity33084 : scanCanonicalize (H12AffineFastState.compose env33084 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33084 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env33085 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138293,1024,32769,58397,144444,62493,41230,8193,16,245019,114966,17664,10281,119043,201782,256,95530,103431,62988]

theorem envBound33085 : H12AffineFastState.Bounded env33085 := by
  intro p hp
  have h : env33085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33084_33085 : H12AffineEnvironment.transform 6 9 env33084 = env33085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33084 == env33085) = true)

theorem identity33085 : scanCanonicalize (H12AffineFastState.compose env33085 (packedSelected [0,1,3,4,8,12,14,15,16,19,22,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound33085 : packedSelected [0,1,3,4,8,12,14,15,16,19,22,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env33086 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,13625,10508,1024,32769,58397,261,62493,41230,8193,16,100386,114966,17664,10281,119043,73999,256,95530,103431,62988]

theorem envBound33086 : H12AffineFastState.Bounded env33086 := by
  intro p hp
  have h : env33086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33085_33086 : H12AffineEnvironment.transform 16 13625 env33085 = env33086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env33085 == env33086) = true)

theorem identity33086 : scanCanonicalize (H12AffineFastState.compose env33086 (packedSelected [0,1,2,4,5,6,8,9,11,18,19,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33086 : packedSelected [0,1,2,4,5,6,8,9,11,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33087 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,13625,10508,1024,32769,45340,261,41244,41230,8193,16,100386,103447,4097,10281,99330,73999,256,73771,103431,41741]

theorem envBound33087 : H12AffineFastState.Bounded env33087 := by
  intro p hp
  have h : env33087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33086_33087 : H12AffineEnvironment.transform 13 5377 env33086 = env33087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33086 == env33087) = true)

theorem identity33087 : scanCanonicalize (H12AffineFastState.compose env33087 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33087 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,23] rootPS < 2^1333 := by decide +kernel

def env33088 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,32768,65536,13341,10280,1024,32769,45112,33,41016,41002,8193,16,100386,103447,4097,10281,99330,73771,36,73771,103431,41513]

theorem envBound33088 : H12AffineFastState.Bounded env33088 := by
  intro p hp
  have h : env33088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33087_33088 : H12AffineEnvironment.transform 7 36 env33087 = env33088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33087 == env33088) = true)

theorem identity33088 : scanCanonicalize (H12AffineFastState.compose env33088 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound33088 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env33089 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,6200,5157,32768,65536,3109,4112,1024,32769,34816,33,38912,38930,6201,16,100386,103447,4097,4113,99330,71699,36,71699,103431,39441]

theorem envBound33089 : H12AffineFastState.Bounded env33089 := by
  intro p hp
  have h : env33089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33088_33089 : H12AffineEnvironment.transform 12 6200 env33088 = env33089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env33088 == env33089) = true)

theorem identity33089 : scanCanonicalize (H12AffineFastState.compose env33089 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound33089 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33090 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,40,3125,32768,65536,3109,2048,1024,32769,34816,33,32784,32770,41,16,100386,101383,2065,2049,99330,65539,36,65539,101399,33281]

theorem envBound33090 : H12AffineFastState.Bounded env33090 := by
  intro p hp
  have h : env33090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33089_33090 : H12AffineEnvironment.transform 11 2064 env33089 = env33090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env33089 == env33090) = true)

theorem identity33090 : scanCanonicalize (H12AffineFastState.compose env33090 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound33090 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env33091 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,40,3125,32768,2083,3109,2048,1024,32769,34816,33,32784,32770,41,16,32769,33828,2065,2049,35873,2080,36,2080,33844,33281]

theorem envBound33091 : H12AffineFastState.Bounded env33091 := by
  intro p hp
  have h : env33091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33090_33091 : H12AffineEnvironment.transform 15 2083 env33090 = env33091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env33090 == env33091) = true)

theorem identity33091 : scanCanonicalize (H12AffineFastState.compose env33091 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound33091 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33092 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1060,1076,40,17,32768,1031,1,1060,1024,32769,33828,33,32784,32770,41,16,32769,33828,1077,1061,32773,1028,36,1028,33844,33281]

theorem envBound33092 : H12AffineFastState.Bounded env33092 := by
  intro p hp
  have h : env33092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33091_33092 : H12AffineEnvironment.transform 10 1060 env33091 = env33092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env33091 == env33092) = true)

theorem identity33092 : scanCanonicalize (H12AffineFastState.compose env33092 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 1060) := by decide +kernel

theorem selectedBound33092 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env33093 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1060,1076,40,17,1060,1031,1,1060,1024,1061,0,33,1076,1062,41,16,1061,0,1077,1061,1057,1028,36,1028,16,1573]

theorem envBound33093 : H12AffineFastState.Bounded env33093 := by
  intro p hp
  have h : env33093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33092_33093 : H12AffineEnvironment.transform 14 1060 env33092 = env33093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1060 env33092 == env33093) = true)

theorem identity33093 : scanCanonicalize (H12AffineFastState.compose env33093 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33094 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1028,1044,8,17,1028,1031,1,1028,1024,1029,0,1,1044,1030,9,16,1029,0,1045,1029,1025,1028,4,1028,16,1541]

theorem envBound33094 : H12AffineFastState.Bounded env33094 := by
  intro p hp
  have h : env33094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33093_33094 : H12AffineEnvironment.transform 4 0 env33093 = env33094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33093 == env33094) = true)

theorem identity33094 : scanCanonicalize (H12AffineFastState.compose env33094 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33094 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env33095 : List Nat := [2,4,8,16,0,17,9,4,1,1024,1028,1044,8,17,1028,1031,1,1028,1024,1029,0,1,1044,1030,9,16,1029,0,1045,1029,1025,1028,4,1028,16,1028]

theorem envBound33095 : H12AffineFastState.Bounded env33095 := by
  intro p hp
  have h : env33095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33094_33095 : H12AffineEnvironment.transform 8 1 env33094 = env33095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33094 == env33095) = true)

theorem identity33095 : scanCanonicalize (H12AffineFastState.compose env33095 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33095 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33096 : List Nat := [2,4,8,16,0,17,9,4,1,21,17,1,8,17,17,18,1,17,21,16,0,1,1,19,9,16,16,0,0,16,20,17,4,17,16,17]

theorem envBound33096 : H12AffineFastState.Bounded env33096 := by
  intro p hp
  have h : env33096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33095_33096 : H12AffineEnvironment.transform 9 21 env33095 = env33096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33095 == env33096) = true)

theorem identity33096 : scanCanonicalize (H12AffineFastState.compose env33096 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33097 : List Nat := [2,4,8,1,0,0,9,4,1,4,0,1,8,0,0,3,1,0,4,1,0,1,1,2,9,1,1,0,0,1,5,0,4,0,1,0]

theorem envBound33097 : H12AffineFastState.Bounded env33097 := by
  intro p hp
  have h : env33097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33096_33097 : H12AffineEnvironment.transform 3 1 env33096 = env33097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33096 == env33097) = true)

def env33098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,441659,8328,65,245139,115150,17664,10281,119043,329730,256,485831,493667,63188]

theorem envBound33098 : H12AffineFastState.Bounded env33098 := by
  intro p hp
  have h : env33098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33066_33098 : H12AffineEnvironment.transform 21 272513 env33066 = env33098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33066 == env33098) = true)

theorem identity33098 : scanCanonicalize (H12AffineFastState.compose env33098 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound33098 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396460,272513,400637,412142,8328,65,215366,79131,17664,10281,75222,329730,256,485831,490678,513]

theorem envBound33099 : H12AffineFastState.Bounded env33099 := by
  intro p hp
  have h : env33099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33098_33099 : H12AffineEnvironment.transform 14 29909 env33098 = env33099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env33098 == env33099) = true)

def env33100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396324,272393,400501,412006,8192,65,215366,79131,17664,10281,75102,329730,256,485711,490558,513]

theorem envBound33100 : H12AffineFastState.Bounded env33100 := by
  intro p hp
  have h : env33100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33099_33100 : H12AffineEnvironment.transform 6 8 env33099 = env33100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33099 == env33100) = true)

theorem identity33100 : scanCanonicalize (H12AffineFastState.compose env33100 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound33100 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,140300,33,144477,155982,8192,65,215366,79131,17664,10281,75102,73770,256,213351,218134,513]

theorem envBound33101 : H12AffineFastState.Bounded env33101 := by
  intro p hp
  have h : env33101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33100_33101 : H12AffineEnvironment.transform 17 10280 env33100 = env33101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33100 == env33101) = true)

theorem identity33101 : scanCanonicalize (H12AffineFastState.compose env33101 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound33101 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env33102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5393,10280,1024,29788,12573,33,8524,29791,8192,65,89175,79131,17664,10281,75102,73770,256,87158,82183,513]

theorem envBound33102 : H12AffineFastState.Bounded env33102 := by
  intro p hp
  have h : env33102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33101_33102 : H12AffineEnvironment.transform 16 5393 env33101 = env33102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33101 == env33102) = true)

theorem identity33102 : scanCanonicalize (H12AffineFastState.compose env33102 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33102 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env33103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,65536,5393,2341,1024,21841,4112,33,65,21842,269,65,89175,70678,17664,2340,66643,65831,256,87158,82183,513]

theorem envBound33103 : H12AffineFastState.Bounded env33103 := by
  intro p hp
  have h : env33103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33102_33103 : H12AffineEnvironment.transform 12 269 env33102 = env33103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33102 == env33103) = true)

theorem identity33103 : scanCanonicalize (H12AffineFastState.compose env33103 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound33103 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env33104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,21591,5393,2341,1024,21841,4112,33,65,21842,269,65,2048,16449,17664,2340,20484,21872,256,33,5456,513]

theorem envBound33104 : H12AffineFastState.Bounded env33104 := by
  intro p hp
  have h : env33104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33103_33104 : H12AffineEnvironment.transform 15 21591 env33103 = env33104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env33103 == env33104) = true)

def env33105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396325,272392,400500,412007,8193,65,215366,79131,17664,10281,75103,329730,256,485710,490559,513]

theorem envBound33105 : H12AffineFastState.Bounded env33105 := by
  intro p hp
  have h : env33105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33099_33105 : H12AffineEnvironment.transform 6 9 env33099 = env33105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33099 == env33105) = true)

theorem identity33105 : scanCanonicalize (H12AffineFastState.compose env33105 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound33105 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env33106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,355390,272392,359535,338300,8193,65,10589,79131,17664,10281,75103,329730,256,264533,269348,513]

theorem envBound33106 : H12AffineFastState.Bounded env33106 := by
  intro p hp
  have h : env33106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33105_33106 : H12AffineEnvironment.transform 16 90139 env33105 = env33106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env33105 == env33106) = true)

theorem identity33106 : scanCanonicalize (H12AffineFastState.compose env33106 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound33106 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21510,13341,262144,1024,29789,276536,272392,272489,294266,8193,65,10589,24861,17664,10281,29017,285700,256,264533,269348,513]

theorem envBound33107 : H12AffineFastState.Bounded env33107 := by
  intro p hp
  have h : env33107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33106_33107 : H12AffineEnvironment.transform 15 21510 env33106 = env33107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env33106 == env33107) = true)

theorem identity33107 : scanCanonicalize (H12AffineFastState.compose env33107 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33107 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env33108 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,28776,20530,12329,262144,52,28777,276536,272392,272489,293198,8193,65,10589,24861,16692,10281,29017,284720,256,264533,268304,513]

theorem envBound33108 : H12AffineFastState.Bounded env33108 := by
  intro p hp
  have h : env33108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33107_33108 : H12AffineEnvironment.transform 9 52 env33107 = env33108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33107 == env33108) = true)

theorem identity33108 : scanCanonicalize (H12AffineFastState.compose env33108 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(17+1) ^^^ 22592) := by decide +kernel

theorem selectedBound33108 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env33109 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,28776,20530,12329,22592,52,28777,24696,28744,28713,8462,8193,65,10589,24861,16692,10281,29017,112,256,20757,16464,513]

theorem envBound33109 : H12AffineFastState.Bounded env33109 := by
  intro p hp
  have h : env33109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33108_33109 : H12AffineEnvironment.transform 17 22592 env33108 = env33109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22592 env33108 == env33109) = true)

theorem identity33109 : scanCanonicalize (H12AffineFastState.compose env33109 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33109 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env33110 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28729,20530,12329,22545,52,28728,24617,28697,28713,8462,8193,16,10508,24861,16692,10281,28936,33,256,20757,16385,513]

theorem envBound33110 : H12AffineFastState.Bounded env33110 := by
  intro p hp
  have h : env33110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33109_33110 : H12AffineEnvironment.transform 5 17 env33109 = env33110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33109 == env33110) = true)

theorem identity33110 : scanCanonicalize (H12AffineFastState.compose env33110 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 804) := by decide +kernel

theorem selectedBound33110 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33111 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,804,13085,4886,12329,6965,52,13084,8973,13117,13069,8462,8193,16,10508,8761,528,10281,12844,33,256,4657,805,513]

theorem envBound33111 : H12AffineFastState.Bounded env33111 := by
  intro p hp
  have h : env33111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33110_33111 : H12AffineEnvironment.transform 13 804 env33110 = env33111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 804 env33110 == env33111) = true)

theorem identity33111 : scanCanonicalize (H12AffineFastState.compose env33111 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound33111 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env33112 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,820,8192,804,8233,34,8989,2049,52,8232,8973,8201,8249,8462,8193,16,10508,8761,528,10281,8472,33,256,261,805,513]

theorem envBound33112 : H12AffineFastState.Bounded env33112 := by
  intro p hp
  have h : env33112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33111_33112 : H12AffineEnvironment.transform 11 820 env33111 = env33112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env33111 == env33112) = true)

theorem identity33112 : scanCanonicalize (H12AffineFastState.compose env33112 (packedSelected [5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound33112 : packedSelected [5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env33113 : List Nat := [2,4,8,16,32,17,9,256,512,52,529,820,8192,804,8233,34,8989,528,52,8232,8973,8201,8249,8462,8193,16,8989,8761,528,8760,8472,33,256,261,805,513]

theorem envBound33113 : H12AffineFastState.Bounded env33113 := by
  intro p hp
  have h : env33113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33112_33113 : H12AffineEnvironment.transform 10 529 env33112 = env33113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env33112 == env33113) = true)

theorem identity33113 : scanCanonicalize (H12AffineFastState.compose env33113 (packedSelected [1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound33113 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env33114 : List Nat := [2,4,8,16,32,17,9,256,512,52,529,820,300,804,261,34,561,528,52,260,545,293,277,34,301,16,561,789,528,788,52,33,256,261,805,513]

theorem envBound33114 : H12AffineFastState.Bounded env33114 := by
  intro p hp
  have h : env33114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33113_33114 : H12AffineEnvironment.transform 12 300 env33113 = env33114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env33113 == env33114) = true)

theorem identity33114 : scanCanonicalize (H12AffineFastState.compose env33114 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33114 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33115 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,529,9,513,32,34,561,528,52,33,545,0,48,34,8,16,561,560,528,561,52,33,37,32,512,513]

theorem envBound33115 : H12AffineFastState.Bounded env33115 := by
  intro p hp
  have h : env33115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33114_33115 : H12AffineEnvironment.transform 7 37 env33114 = env33115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33114 == env33115) = true)

theorem identity33115 : scanCanonicalize (H12AffineFastState.compose env33115 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33115 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33116 : List Nat := [2,4,8,16,0,17,9,5,512,20,529,529,9,513,0,2,529,528,20,1,513,0,16,2,8,16,529,528,528,529,20,1,5,0,512,513]

theorem envBound33116 : H12AffineFastState.Bounded env33116 := by
  intro p hp
  have h : env33116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33115_33116 : H12AffineEnvironment.transform 4 0 env33115 = env33116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33115 == env33116) = true)

theorem identity33116 : scanCanonicalize (H12AffineFastState.compose env33116 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33116 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33117 : List Nat := [2,4,8,16,0,17,9,5,16,20,1,1,9,17,0,2,1,0,20,1,17,0,16,2,8,16,1,0,0,1,20,1,5,0,16,17]

theorem envBound33117 : H12AffineFastState.Bounded env33117 := by
  intro p hp
  have h : env33117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33116_33117 : H12AffineEnvironment.transform 8 16 env33116 = env33117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33116 == env33117) = true)

def env33118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452649,2114883,8328,65,6385003,115151,2538872,10280,2566522,4268162,256,485831,493667,2494125]

theorem envBound33118 : H12AffineFastState.Bounded env33118 := by
  intro p hp
  have h : env33118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33005_33118 : H12AffineEnvironment.transform 22 452649 env33005 = env33118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env33005 == env33118) = true)

def env33119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,441659,8328,65,4691219,115151,17664,10280,119042,4268162,256,485831,493667,63189]

theorem envBound33119 : H12AffineFastState.Bounded env33119 := by
  intro p hp
  have h : env33119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33118_33119 : H12AffineEnvironment.transform 20 456824 env33118 = env33119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env33118 == env33119) = true)

def env33120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,441659,8328,65,245139,115151,17664,10280,119042,329730,256,485831,493667,63189]

theorem envBound33120 : H12AffineFastState.Bounded env33120 := by
  intro p hp
  have h : env33120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33119_33120 : H12AffineEnvironment.transform 21 272512 env33119 = env33120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33119 == env33120) = true)

theorem identity33120 : scanCanonicalize (H12AffineFastState.compose env33120 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33120 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272512,452649,441659,8328,65,171417,57797,17664,10280,61704,272392,256,412109,436329,63189]

theorem envBound33121 : H12AffineFastState.Bounded env33121 := by
  intro p hp
  have h : env33121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33120_33121 : H12AffineEnvironment.transform 15 8202 env33120 = env33121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33120 == env33121) = true)

def env33122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272392,452649,441659,8192,65,171281,57677,17664,10280,61704,272392,256,411973,436329,63069]

theorem envBound33122 : H12AffineFastState.Bounded env33122 := by
  intro p hp
  have h : env33122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33121_33122 : H12AffineEnvironment.transform 6 8 env33121 = env33122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33121 == env33122) = true)

theorem identity33122 : scanCanonicalize (H12AffineFastState.compose env33122 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound33122 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env33123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,262144,1024,32769,281652,272392,285797,264567,8192,65,10589,57677,17664,10280,61704,272392,256,326921,269349,63069]

theorem envBound33123 : H12AffineFastState.Bounded env33123 := by
  intro p hp
  have h : env33123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33122_33123 : H12AffineEnvironment.transform 16 46156 env33122 = env33123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env33122 == env33123) = true)

theorem identity33123 : scanCanonicalize (H12AffineFastState.compose env33123 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound33123 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env33124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,35188,1024,32769,50496,41340,54545,32771,8192,65,10589,57677,17664,10280,61704,41340,256,29821,38225,63069]

theorem envBound33124 : H12AffineFastState.Bounded env33124 := by
  intro p hp
  have h : env33124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33123_33124 : H12AffineEnvironment.transform 17 35188 env33123 = env33124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env33123 == env33124) = true)

theorem identity33124 : scanCanonicalize (H12AffineFastState.compose env33124 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33124 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,38160,35188,1024,32769,50496,32800,54545,32771,348,65,2049,49169,17664,2420,53332,32800,256,21793,38225,55041]

theorem envBound33125 : H12AffineFastState.Bounded env33125 := by
  intro p hp
  have h : env33125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33124_33125 : H12AffineEnvironment.transform 12 348 env33124 = env33125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33124 == env33125) = true)

theorem identity33125 : scanCanonicalize (H12AffineFastState.compose env33125 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound33125 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21840,342,16448,23588,1024,21841,4112,21872,65,21843,348,65,2049,5441,17664,2420,1284,21872,256,21793,16385,593]

theorem envBound33126 : H12AffineFastState.Bounded env33126 := by
  intro p hp
  have h : env33126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33125_33126 : H12AffineEnvironment.transform 14 21840 env33125 = env33126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env33125 == env33126) = true)

theorem identity33126 : scanCanonicalize (H12AffineFastState.compose env33126 (packedSelected [4,6,7,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound33126 : packedSelected [4,6,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env33127 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,16384,20497,342,16448,22885,321,20496,4112,20529,65,20498,348,65,2049,4096,16449,2420,69,20529,256,20576,16385,593]

theorem envBound33127 : H12AffineFastState.Bounded env33127 := by
  intro p hp
  have h : env33127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33126_33127 : H12AffineEnvironment.transform 9 321 env33126 = env33127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33126 == env33127) = true)

theorem identity33127 : scanCanonicalize (H12AffineFastState.compose env33127 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 4420) := by decide +kernel

theorem selectedBound33127 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env33128 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,4420,341,342,4356,2081,321,340,4112,373,65,342,348,65,2049,4096,4357,2420,69,373,256,292,4421,593]

theorem envBound33128 : H12AffineFastState.Bounded env33128 := by
  intro p hp
  have h : env33128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33127_33128 : H12AffineEnvironment.transform 13 4420 env33127 = env33128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4420 env33127 == env33128) = true)

theorem identity33128 : scanCanonicalize (H12AffineFastState.compose env33128 (packedSelected [0,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33128 : packedSelected [0,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env33129 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,4096,9,4113,0,3,4177,2081,20,1,4112,32,65,3,9,65,2049,4096,4176,2081,69,32,85,113,4112,593]

theorem envBound33129 : H12AffineFastState.Bounded env33129 := by
  intro p hp
  have h : env33129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33128_33129 : H12AffineEnvironment.transform 7 85 env33128 = env33129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33128 == env33129) = true)

theorem identity33129 : scanCanonicalize (H12AffineFastState.compose env33129 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound33129 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33130 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,2144,9,2161,0,3,2097,2081,20,1,2160,32,65,3,9,65,2049,2144,2096,2081,69,32,85,113,2160,593]

theorem envBound33130 : H12AffineFastState.Bounded env33130 := by
  intro p hp
  have h : env33130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33129_33130 : H12AffineEnvironment.transform 11 2144 env33129 = env33130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env33129 == env33130) = true)

def env33131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272393,452649,441659,8193,65,171280,57676,17664,10280,61704,272392,256,411972,436329,63068]

theorem envBound33131 : H12AffineFastState.Bounded env33131 := by
  intro p hp
  have h : env33131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33121_33131 : H12AffineEnvironment.transform 6 9 env33121 = env33131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33121 == env33131) = true)

theorem identity33131 : scanCanonicalize (H12AffineFastState.compose env33131 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 182337) := by decide +kernel

theorem selectedBound33131 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env33132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182337,1024,32769,12345,188488,8296,30074,8193,65,171280,57676,17664,10280,61704,188489,256,33029,24616,63068]

theorem envBound33132 : H12AffineFastState.Bounded env33132 := by
  intro p hp
  have h : env33132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33131_33132 : H12AffineEnvironment.transform 17 182337 env33131 = env33132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182337 env33131 == env33132) = true)

theorem identity33132 : scanCanonicalize (H12AffineFastState.compose env33132 (packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound33132 : packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13624,64889,1024,32769,12345,54640,8296,30074,8193,65,43048,57676,17664,10280,61704,54641,256,33029,24616,63068]

theorem envBound33133 : H12AffineFastState.Bounded env33133 := by
  intro p hp
  have h : env33133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33132_33133 : H12AffineEnvironment.transform 16 13624 env33132 = env33133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env33132 == env33133) = true)

theorem identity33133 : scanCanonicalize (H12AffineFastState.compose env33133 (packedSelected [1,2,4,8,9,11,12,15,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound33133 : packedSelected [1,2,4,8,9,11,12,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,34,5392,56657,1024,32769,4113,54640,64,21842,41,65,34816,49508,17664,2048,53536,54641,256,33029,16384,54900]

theorem envBound33134 : H12AffineFastState.Bounded env33134 := by
  intro p hp
  have h : env33134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33133_33134 : H12AffineEnvironment.transform 12 40 env33133 = env33134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env33133 == env33134) = true)

theorem identity33134 : scanCanonicalize (H12AffineFastState.compose env33134 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound33134 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env33135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,293,34,5392,23668,1024,292,4113,21589,64,21842,41,65,2341,16449,17664,2048,20485,21588,256,32,16384,22353]

theorem envBound33135 : H12AffineFastState.Bounded env33135 := by
  intro p hp
  have h : env33135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33134_33135 : H12AffineEnvironment.transform 14 293 env33134 = env33135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env33134 == env33135) = true)

def env33136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,441659,8328,65,245138,115151,17664,10280,119042,329731,256,485831,493667,63189]

theorem envBound33136 : H12AffineFastState.Bounded env33136 := by
  intro p hp
  have h : env33136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33119_33136 : H12AffineEnvironment.transform 21 272513 env33119 = env33136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33119 == env33136) = true)

theorem identity33136 : scanCanonicalize (H12AffineFastState.compose env33136 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound33136 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254130,73754,95496,8328,65,245138,115151,17664,10280,119042,180272,256,41460,16464,63189]

theorem envBound33137 : H12AffineFastState.Bounded env33137 := by
  intro p hp
  have h : env33137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33136_33137 : H12AffineEnvironment.transform 17 247859 env33136 = env33137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env33136 == env33137) = true)

def env33138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77851,254130,73754,95496,8328,17,245138,115103,17664,10280,119042,180272,256,41380,16384,63109]

theorem envBound33138 : H12AffineFastState.Bounded env33138 := by
  intro p hp
  have h : env33138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33137_33138 : H12AffineEnvironment.transform 5 16 env33137 = env33138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33137 == env33138) = true)

theorem identity33138 : scanCanonicalize (H12AffineFastState.compose env33138 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33138 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77851,254010,73754,95496,8192,17,245018,114967,17664,10280,119042,180272,256,41260,16384,62989]

theorem envBound33139 : H12AffineFastState.Bounded env33139 := by
  intro p hp
  have h : env33139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33138_33139 : H12AffineEnvironment.transform 6 8 env33138 = env33139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33138 == env33139) = true)

theorem identity33139 : scanCanonicalize (H12AffineFastState.compose env33139 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound33139 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,138292,1024,32769,58396,144445,62493,41231,8192,17,157981,5392,17664,10280,1285,180272,256,41260,16384,62989]

theorem envBound33140 : H12AffineFastState.Bounded env33140 := by
  intro p hp
  have h : env33140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33139_33140 : H12AffineEnvironment.transform 15 54279 env33139 = env33140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env33139 == env33140) = true)

theorem identity33140 : scanCanonicalize (H12AffineFastState.compose env33140 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound33140 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,131072,138292,1024,29709,4112,144445,17,21763,8192,17,157981,5392,17664,10280,1285,144444,256,21792,16384,513]

theorem envBound33141 : H12AffineFastState.Bounded env33141 := by
  intro p hp
  have h : env33141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33140_33141 : H12AffineEnvironment.transform 14 29708 env33140 = env33141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env33140 == env33141) = true)

theorem identity33141 : scanCanonicalize (H12AffineFastState.compose env33141 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound33141 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,5393,2341,1024,29709,4112,8492,17,21763,8192,17,31756,5392,17664,10280,1285,8493,256,21792,16384,513]

theorem envBound33142 : H12AffineFastState.Bounded env33142 := by
  intro p hp
  have h : env33142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33141_33142 : H12AffineEnvironment.transform 16 5393 env33141 = env33142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33141 == env33142) = true)

theorem identity33142 : scanCanonicalize (H12AffineFastState.compose env33142 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33142 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33143 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,5393,2341,1024,8460,4112,8492,17,2,8192,17,10509,5392,4097,10280,1285,8493,256,33,5377,513]

theorem envBound33143 : H12AffineFastState.Bounded env33143 := by
  intro p hp
  have h : env33143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33142_33143 : H12AffineEnvironment.transform 13 5377 env33142 = env33143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33142 == env33143) = true)

theorem identity33143 : scanCanonicalize (H12AffineFastState.compose env33143 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33144 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8233,8203,5173,2049,1024,8232,4112,8200,17,2,8192,17,10281,5172,4097,10280,1057,8201,36,33,5157,513]

theorem envBound33144 : H12AffineFastState.Bounded env33144 := by
  intro p hp
  have h : env33144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33143_33144 : H12AffineEnvironment.transform 7 36 env33143 = env33144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33143 == env33144) = true)

theorem identity33144 : scanCanonicalize (H12AffineFastState.compose env33144 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33144 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33145 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5173,2049,1024,1,4112,33,17,2,41,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound33145 : H12AffineFastState.Bounded env33145 := by
  intro p hp
  have h : env33145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33144_33145 : H12AffineEnvironment.transform 12 41 env33144 = env33145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33144 == env33145) = true)

def env33146 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,0,34,1029,2049,1024,1,32,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound33146 : H12AffineFastState.Bounded env33146 := by
  intro p hp
  have h : env33146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33145_33146 : H12AffineEnvironment.transform 11 48 env33145 = env33146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33145 == env33146) = true)

theorem identity33146 : scanCanonicalize (H12AffineFastState.compose env33146 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound33146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33147 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,48,41,1045,0,34,1029,2049,1024,1,32,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1045,49]

theorem envBound33147 : H12AffineFastState.Bounded env33147 := by
  intro p hp
  have h : env33147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33146_33147 : H12AffineEnvironment.transform 8 48 env33146 = env33147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33146 == env33147) = true)

def env33148 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,41,33,0,34,49,2049,52,1,32,33,17,2,41,17,2048,48,49,2049,21,32,36,33,33,49]

theorem envBound33148 : H12AffineFastState.Bounded env33148 := by
  intro p hp
  have h : env33148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33147_33148 : H12AffineEnvironment.transform 9 52 env33147 = env33148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33147 == env33148) = true)

def env33149 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,41,32,0,34,48,2049,53,1,32,33,17,2,41,17,2048,49,49,2049,20,32,36,33,32,49]

theorem envBound33149 : H12AffineFastState.Bounded env33149 := by
  intro p hp
  have h : env33149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33147_33149 : H12AffineEnvironment.transform 9 53 env33147 = env33149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33147 == env33149) = true)

theorem identity33149 : scanCanonicalize (H12AffineFastState.compose env33149 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33150 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,42,41,32,0,34,42,2049,47,1,32,33,11,2,41,11,2048,43,43,2049,14,32,36,33,32,43]

theorem envBound33150 : H12AffineFastState.Bounded env33150 := by
  intro p hp
  have h : env33150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33149_33150 : H12AffineEnvironment.transform 3 10 env33149 = env33150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33149 == env33150) = true)

def leafEnv33150 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,42,41,32,0,34,42,2049,47,1,32,33,11,2,14,41,1,11,2048,43,43,2049,14,32,36,33,4,34,32,43,1,32,0]

def active33150 : List Nat := [0,1,2,4,10]

def tree33150 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33150 : H12WitnessSearch.Good tree33150 := H12GlobalWitnessIndex.good

theorem leafIdentity33150 : H12AffineFastState.composeSystem env33150 rootObs = leafEnv33150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33150 rootObs == leafEnv33150) = true)

theorem terminalChecked33150 : H12PackedTerminal.terminalCheckFast leafEnv33150 active33150 tree33150 = true := by decide +kernel

def env33151 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,0,34,1028,2049,1024,1,33,33,17,2,41,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound33151 : H12AffineFastState.Bounded env33151 := by
  intro p hp
  have h : env33151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33145_33151 : H12AffineEnvironment.transform 11 49 env33145 = env33151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33145 == env33151) = true)

theorem identity33151 : scanCanonicalize (H12AffineFastState.compose env33151 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound33151 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33152 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,49,41,528,0,34,512,2049,516,1,33,33,17,2,41,17,2048,513,48,2049,549,32,36,33,528,513]

theorem envBound33152 : H12AffineFastState.Bounded env33152 := by
  intro p hp
  have h : env33152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33151_33152 : H12AffineEnvironment.transform 9 516 env33151 = env33152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env33151 == env33152) = true)

def env33153 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,41,32,0,34,48,2049,52,1,33,33,17,2,41,17,2048,49,48,2049,21,32,36,33,32,49]

theorem envBound33153 : H12AffineFastState.Bounded env33153 := by
  intro p hp
  have h : env33153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33152_33153 : H12AffineEnvironment.transform 8 48 env33152 = env33153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33152 == env33153) = true)

def env33154 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,41,33,0,34,49,2049,53,1,33,33,17,2,41,17,2048,48,48,2049,20,32,36,33,33,48]

theorem envBound33154 : H12AffineFastState.Bounded env33154 := by
  intro p hp
  have h : env33154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33152_33154 : H12AffineEnvironment.transform 8 49 env33152 = env33154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env33152 == env33154) = true)

theorem identity33154 : scanCanonicalize (H12AffineFastState.compose env33154 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33155 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,43,41,33,0,34,43,2049,47,1,33,33,11,2,41,11,2048,42,42,2049,14,32,36,33,33,42]

theorem envBound33155 : H12AffineFastState.Bounded env33155 := by
  intro p hp
  have h : env33155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33154_33155 : H12AffineEnvironment.transform 3 10 env33154 = env33155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33154 == env33155) = true)

def leafEnv33155 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,43,41,33,0,34,43,2049,47,1,33,33,11,2,14,41,1,11,2048,42,42,2049,14,32,36,33,4,34,33,42,1,33,0]

def active33155 : List Nat := [0,1,2,4,10]

def tree33155 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33155 : H12WitnessSearch.Good tree33155 := H12GlobalWitnessIndex.good

theorem leafIdentity33155 : H12AffineFastState.composeSystem env33155 rootObs = leafEnv33155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33155 rootObs == leafEnv33155) = true)

theorem terminalChecked33155 : H12PackedTerminal.terminalCheckFast leafEnv33155 active33155 tree33155 = true := by decide +kernel

def env33156 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77850,254130,73754,95496,8328,16,245138,115102,17664,10280,119042,180272,256,41381,16385,63108]

theorem envBound33156 : H12AffineFastState.Bounded env33156 := by
  intro p hp
  have h : env33156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33137_33156 : H12AffineEnvironment.transform 5 17 env33137 = env33156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33137 == env33156) = true)

theorem identity33156 : scanCanonicalize (H12AffineFastState.compose env33156 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound33156 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33157 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,212150,1024,29828,77850,201783,73754,95496,8328,16,215319,79131,17664,10280,75143,144565,256,21792,16385,513]

theorem envBound33157 : H12AffineFastState.Bounded env33157 := by
  intro p hp
  have h : env33157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33156_33157 : H12AffineEnvironment.transform 14 29829 env33156 = env33157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env33156 == env33157) = true)

theorem identity33157 : scanCanonicalize (H12AffineFastState.compose env33157 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound33157 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env33158 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8322,131072,138292,1024,29828,4248,144565,152,21898,8328,16,158101,5529,17664,10280,1285,144565,256,21792,16385,513]

theorem envBound33158 : H12AffineFastState.Bounded env33158 := by
  intro p hp
  have h : env33158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33157_33158 : H12AffineEnvironment.transform 15 8322 env33157 = env33158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env33157 == env33158) = true)

theorem identity33158 : scanCanonicalize (H12AffineFastState.compose env33158 (packedSelected [2,3,6,10,16,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound33158 : packedSelected [2,3,6,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env33159 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8322,13341,10281,1024,29828,4248,168,152,21898,8328,16,23944,5529,17664,10280,1285,168,256,21792,16385,513]

theorem envBound33159 : H12AffineFastState.Bounded env33159 := by
  intro p hp
  have h : env33159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33158_33159 : H12AffineEnvironment.transform 16 13341 env33158 = env33159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env33158 == env33159) = true)

theorem identity33159 : scanCanonicalize (H12AffineFastState.compose env33159 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound33159 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,16384,20496,1047,4232,3260,1024,20497,4248,168,152,21898,1053,16,23944,5529,17664,3261,1285,168,256,21792,16385,513]

theorem envBound33160 : H12AffineFastState.Bounded env33160 := by
  intro p hp
  have h : env33160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33159_33160 : H12AffineEnvironment.transform 12 1173 env33159 = env33160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env33159 == env33160) = true)

theorem identity33160 : scanCanonicalize (H12AffineFastState.compose env33160 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound33160 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,4248,136,1047,4232,3260,1024,137,4248,168,152,1298,1053,16,3344,5529,5528,3261,1285,168,256,1464,4249,513]

theorem envBound33161 : H12AffineFastState.Bounded env33161 := by
  intro p hp
  have h : env33161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33160_33161 : H12AffineEnvironment.transform 13 4248 env33160 = env33161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env33160 == env33161) = true)

theorem identity33161 : scanCanonicalize (H12AffineFastState.compose env33161 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound33161 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33162 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,269,4248,136,399,4232,2340,408,137,4248,168,152,138,389,16,2184,4097,4096,2341,157,168,256,32,4249,513]

theorem envBound33162 : H12AffineFastState.Bounded env33162 := by
  intro p hp
  have h : env33162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33161_33162 : H12AffineEnvironment.transform 9 408 env33161 = env33162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env33161 == env33162) = true)

theorem identity33162 : scanCanonicalize (H12AffineFastState.compose env33162 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound33162 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env33163 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,2493,269,2341,136,399,2357,2340,408,137,2341,168,152,138,389,16,2184,2492,2493,2341,157,168,256,32,2340,513]

theorem envBound33163 : H12AffineFastState.Bounded env33163 := by
  intro p hp
  have h : env33163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33162_33163 : H12AffineEnvironment.transform 11 2493 env33162 = env33163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env33162 == env33163) = true)

theorem identity33163 : scanCanonicalize (H12AffineFastState.compose env33163 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33163 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env33164 : List Nat := [2,4,8,16,32,17,128,37,512,189,2048,2200,40,2048,136,170,2064,2049,189,137,2048,168,152,138,160,16,2184,2201,2200,2048,157,168,37,32,2049,513]

theorem envBound33164 : H12AffineFastState.Bounded env33164 := by
  intro p hp
  have h : env33164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33163_33164 : H12AffineEnvironment.transform 7 37 env33163 = env33164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33163 == env33164) = true)

theorem identity33164 : scanCanonicalize (H12AffineFastState.compose env33164 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33164 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env33165 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,40,2048,1,35,2064,2049,52,0,2048,33,17,3,41,16,2049,2064,2065,2048,20,33,37,32,2049,513]

theorem envBound33165 : H12AffineFastState.Bounded env33165 := by
  intro p hp
  have h : env33165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33164_33165 : H12AffineEnvironment.transform 6 9 env33164 = env33165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33164 == env33165) = true)

theorem identity33165 : scanCanonicalize (H12AffineFastState.compose env33165 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound33165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33166 : List Nat := [2,4,8,16,32,17,9,37,32,52,2048,2065,40,2048,1,35,2064,2049,52,0,2048,33,17,3,41,16,2049,2064,2065,2048,20,33,37,32,2049,33]

theorem envBound33166 : H12AffineFastState.Bounded env33166 := by
  intro p hp
  have h : env33166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33165_33166 : H12AffineEnvironment.transform 8 32 env33165 = env33166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env33165 == env33166) = true)

def env33167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,441658,8328,65,4691218,115151,17665,10280,119043,4268162,256,485831,493667,63188]

theorem envBound33167 : H12AffineFastState.Bounded env33167 := by
  intro p hp
  have h : env33167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33118_33167 : H12AffineEnvironment.transform 20 456825 env33118 = env33167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env33118 == env33167) = true)

def env33168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,441658,8328,65,245138,115151,17665,10280,119043,329730,256,485831,493667,63188]

theorem envBound33168 : H12AffineFastState.Bounded env33168 := by
  intro p hp
  have h : env33168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33167_33168 : H12AffineEnvironment.transform 21 272512 env33167 = env33168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33167 == env33168) = true)

theorem identity33168 : scanCanonicalize (H12AffineFastState.compose env33168 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound33168 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456825,272512,452649,441658,8328,65,158029,5392,17665,10280,1500,318685,256,441624,416956,63188]

theorem envBound33169 : H12AffineFastState.Bounded env33169 := by
  intro p hp
  have h : env33169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33168_33169 : H12AffineEnvironment.transform 15 54495 env33168 = env33169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env33168 == env33169) = true)

theorem identity33169 : scanCanonicalize (H12AffineFastState.compose env33169 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound33169 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,262144,1024,29908,396460,272512,400636,412143,8328,65,158029,5392,17665,10280,1500,272392,256,412109,416956,513]

theorem envBound33170 : H12AffineFastState.Bounded env33170 := by
  intro p hp
  have h : env33170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33169_33170 : H12AffineEnvironment.transform 14 29909 env33169 = env33170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env33169 == env33170) = true)

theorem identity33170 : scanCanonicalize (H12AffineFastState.compose env33170 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound33170 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env33171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,2421,1024,29908,132569,8693,136585,147610,8328,65,158029,5392,17665,10280,1500,8573,256,147640,153033,513]

theorem envBound33171 : H12AffineFastState.Bounded env33171 := by
  intro p hp
  have h : env33171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33170_33171 : H12AffineEnvironment.transform 17 2421 env33170 = env33171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env33170 == env33171) = true)

theorem identity33171 : scanCanonicalize (H12AffineFastState.compose env33171 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound33171 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env33172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,478,131072,2421,1024,21760,132569,33,136585,147610,348,65,149657,5392,17665,2556,1500,169,256,147640,153033,513]

theorem envBound33172 : H12AffineFastState.Bounded env33172 := by
  intro p hp
  have h : env33172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33171_33172 : H12AffineEnvironment.transform 12 468 env33171 = env33172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env33171 == env33172) = true)

theorem identity33172 : scanCanonicalize (H12AffineFastState.compose env33172 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound33172 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env33173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1296,478,131072,2421,1024,1297,132569,33,136585,135307,348,65,137352,5392,5392,2556,1500,169,256,135337,132568,513]

theorem envBound33173 : H12AffineFastState.Bounded env33173 := by
  intro p hp
  have h : env33173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33172_33173 : H12AffineEnvironment.transform 13 4113 env33172 = env33173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env33172 == env33173) = true)

theorem identity33173 : scanCanonicalize (H12AffineFastState.compose env33173 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(16+1) ^^^ 3329) := by decide +kernel

theorem selectedBound33173 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env33174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1296,478,3329,2421,1024,1297,2264,33,6280,7562,348,65,5513,5392,5392,2556,1500,169,256,7592,2265,513]

theorem envBound33174 : H12AffineFastState.Bounded env33174 := by
  intro p hp
  have h : env33174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33173_33174 : H12AffineEnvironment.transform 16 3329 env33173 = env33174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3329 env33173 == env33174) = true)

theorem identity33174 : scanCanonicalize (H12AffineFastState.compose env33174 (packedSelected [0,1,3,4,5,6,8,10,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33174 : packedSelected [0,1,3,4,5,6,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4113,1296,342,3329,2421,1024,1297,2128,33,6144,7426,348,65,5377,5392,5392,2420,1364,33,256,7456,2129,513]

theorem envBound33175 : H12AffineFastState.Bounded env33175 := by
  intro p hp
  have h : env33175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33174_33175 : H12AffineEnvironment.transform 6 8 env33174 = env33175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33174 == env33175) = true)

theorem identity33175 : scanCanonicalize (H12AffineFastState.compose env33175 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound33175 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,348,3344,1296,342,3329,2421,1024,1297,2128,33,1281,3,348,65,2048,2065,2065,2420,1364,33,256,33,2129,513]

theorem envBound33176 : H12AffineFastState.Bounded env33176 := by
  intro p hp
  have h : env33176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33175_33176 : H12AffineEnvironment.transform 11 3329 env33175 = env33176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env33175 == env33176) = true)

def env33177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,441658,8328,65,245139,115151,17665,10280,119043,329731,256,485831,493667,63188]

theorem envBound33177 : H12AffineFastState.Bounded env33177 := by
  intro p hp
  have h : env33177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33167_33177 : H12AffineEnvironment.transform 21 272513 env33167 = env33177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33167 == env33177) = true)

theorem identity33177 : scanCanonicalize (H12AffineFastState.compose env33177 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound33177 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115871,201831,120015,98780,8328,65,245139,115151,17665,10280,119043,144613,256,21793,46213,63188]

theorem envBound33178 : H12AffineFastState.Bounded env33178 := by
  intro p hp
  have h : env33178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33177_33178 : H12AffineEnvironment.transform 17 212198 env33177 = env33178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env33177 == env33178) = true)

def env33179 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115871,201783,119967,98700,8328,17,245139,115103,17665,10280,119043,144565,256,21793,46213,63108]

theorem envBound33179 : H12AffineFastState.Bounded env33179 := by
  intro p hp
  have h : env33179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33178_33179 : H12AffineEnvironment.transform 5 16 env33178 = env33179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33178 == env33179) = true)

theorem identity33179 : scanCanonicalize (H12AffineFastState.compose env33179 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound33179 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33180 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76078,1024,32769,115871,65967,119967,98700,8328,17,108555,115103,17665,10280,119043,8493,256,21793,46213,63108]

theorem envBound33180 : H12AffineFastState.Bounded env33180 := by
  intro p hp
  have h : env33180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33179_33180 : H12AffineEnvironment.transform 16 5528 env33179 = env33180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env33179 == env33180) = true)

theorem identity33180 : scanCanonicalize (H12AffineFastState.compose env33180 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound33180 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env33181 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,5528,64928,1024,32769,4113,54561,17,21762,8328,17,31877,5393,17665,10280,1421,8493,256,21793,46213,63108]

theorem envBound33181 : H12AffineFastState.Bounded env33181 := by
  intro p hp
  have h : env33181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33180_33181 : H12AffineEnvironment.transform 15 54414 env33180 = env33181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env33180 == env33181) = true)

theorem identity33181 : scanCanonicalize (H12AffineFastState.compose env33181 (packedSelected [0,1,4,5,7,8,16,17,18,19,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound33181 : packedSelected [0,1,4,5,7,8,16,17,18,19,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33182 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,30083,5528,23725,1024,8460,4113,29740,17,21762,8328,17,31877,5393,17665,10280,1421,8493,256,21793,5512,22409]

theorem envBound33182 : H12AffineFastState.Bounded env33182 := by
  intro p hp
  have h : env33182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33181_33182 : H12AffineEnvironment.transform 14 8461 env33181 = env33182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env33181 == env33182) = true)

theorem identity33182 : scanCanonicalize (H12AffineFastState.compose env33182 (packedSelected [0,2,3,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound33182 : packedSelected [0,2,3,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env33183 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,8203,5528,2341,1024,8460,4113,8612,17,138,8328,17,10509,5393,4233,10280,1421,8493,256,169,5512,513]

theorem envBound33183 : H12AffineFastState.Bounded env33183 := by
  intro p hp
  have h : env33183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33182_33183 : H12AffineEnvironment.transform 13 5512 env33182 = env33183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env33182 == env33183) = true)

theorem identity33183 : scanCanonicalize (H12AffineFastState.compose env33183 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound33183 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33184 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,160,5512,429,171,5528,2341,1024,428,4113,260,17,138,40,17,2477,5393,4233,2184,1421,397,256,169,5512,513]

theorem envBound33184 : H12AffineFastState.Bounded env33184 := by
  intro p hp
  have h : env33184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33183_33184 : H12AffineEnvironment.transform 12 160 env33183 = env33184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env33183 == env33184) = true)

theorem identity33184 : scanCanonicalize (H12AffineFastState.compose env33184 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33184 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33185 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,160,5157,0,171,5173,2184,1024,1,4113,169,17,138,40,17,2048,5308,4233,2184,1056,32,173,169,5157,513]

theorem envBound33185 : H12AffineFastState.Bounded env33185 := by
  intro p hp
  have h : env33185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33184_33185 : H12AffineEnvironment.transform 7 173 env33184 = env33185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33184 == env33185) = true)

theorem identity33185 : scanCanonicalize (H12AffineFastState.compose env33185 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33186 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,0,35,5173,2048,1024,1,4113,33,17,2,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound33186 : H12AffineFastState.Bounded env33186 := by
  intro p hp
  have h : env33186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33185_33186 : H12AffineEnvironment.transform 6 8 env33185 = env33186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33185 == env33186) = true)

def env33187 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,0,35,1029,2048,1024,1,33,33,17,2,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound33187 : H12AffineFastState.Bounded env33187 := by
  intro p hp
  have h : env33187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33186_33187 : H12AffineEnvironment.transform 11 48 env33186 = env33187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33186 == env33187) = true)

theorem identity33187 : scanCanonicalize (H12AffineFastState.compose env33187 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound33187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33188 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,48,40,1045,0,35,1029,1044,1024,1,33,33,17,2,40,17,1044,1028,49,1044,1056,32,37,33,1045,513]

theorem envBound33188 : H12AffineFastState.Bounded env33188 := by
  intro p hp
  have h : env33188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33187_33188 : H12AffineEnvironment.transform 10 1044 env33187 = env33188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env33187 == env33188) = true)

def env33189 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,40,33,0,35,49,32,52,1,33,33,17,2,40,17,32,48,49,32,20,32,37,33,33,513]

theorem envBound33189 : H12AffineFastState.Bounded env33189 := by
  intro p hp
  have h : env33189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33188_33189 : H12AffineEnvironment.transform 9 52 env33188 = env33189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33188 == env33189) = true)

def env33190 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,40,32,0,35,48,33,53,1,33,33,17,2,40,17,33,49,49,33,21,32,37,33,32,513]

theorem envBound33190 : H12AffineFastState.Bounded env33190 := by
  intro p hp
  have h : env33190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33188_33190 : H12AffineEnvironment.transform 9 53 env33188 = env33190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33188 == env33190) = true)

theorem identity33190 : scanCanonicalize (H12AffineFastState.compose env33190 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33191 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,48,40,32,0,35,48,33,53,1,33,33,17,2,40,17,33,49,49,33,21,32,37,33,32,42]

theorem envBound33191 : H12AffineFastState.Bounded env33191 := by
  intro p hp
  have h : env33191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33190_33191 : H12AffineEnvironment.transform 8 43 env33190 = env33191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33190 == env33191) = true)

def leafEnv33191 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,48,40,32,0,35,48,33,53,1,33,33,17,2,21,40,1,17,33,49,49,33,21,32,37,33,4,35,32,42,1,33,0]

def active33191 : List Nat := [0,1,2,3,4]

def tree33191 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33191 : H12WitnessSearch.Good tree33191 := H12GlobalWitnessIndex.good

theorem leafIdentity33191 : H12AffineFastState.composeSystem env33191 rootObs = leafEnv33191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33191 rootObs == leafEnv33191) = true)

theorem terminalChecked33191 : H12PackedTerminal.terminalCheckFast leafEnv33191 active33191 tree33191 = true := by decide +kernel

def env33192 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,0,35,1028,2048,1024,1,32,33,17,2,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound33192 : H12AffineFastState.Bounded env33192 := by
  intro p hp
  have h : env33192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33186_33192 : H12AffineEnvironment.transform 11 49 env33186 = env33192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33186 == env33192) = true)

theorem identity33192 : scanCanonicalize (H12AffineFastState.compose env33192 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound33192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33193 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,49,40,1044,0,35,1028,32,1024,1,32,33,17,2,40,17,32,1029,48,32,1056,32,37,33,1044,513]

theorem envBound33193 : H12AffineFastState.Bounded env33193 := by
  intro p hp
  have h : env33193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33192_33193 : H12AffineEnvironment.transform 10 32 env33192 = env33193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env33192 == env33193) = true)

def env33194 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,40,32,0,35,48,32,52,1,32,33,17,2,40,17,32,49,48,32,20,32,37,33,32,513]

theorem envBound33194 : H12AffineFastState.Bounded env33194 := by
  intro p hp
  have h : env33194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33193_33194 : H12AffineEnvironment.transform 9 52 env33193 = env33194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33193 == env33194) = true)

def env33195 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,40,33,0,35,49,32,53,1,32,33,17,2,40,17,32,48,48,32,21,32,37,33,33,513]

theorem envBound33195 : H12AffineFastState.Bounded env33195 := by
  intro p hp
  have h : env33195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33193_33195 : H12AffineEnvironment.transform 9 53 env33193 = env33195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33193 == env33195) = true)

theorem identity33195 : scanCanonicalize (H12AffineFastState.compose env33195 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33195 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33196 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,49,40,33,0,35,49,32,53,1,32,33,17,2,40,17,32,48,48,32,21,32,37,33,33,43]

theorem envBound33196 : H12AffineFastState.Bounded env33196 := by
  intro p hp
  have h : env33196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33195_33196 : H12AffineEnvironment.transform 8 42 env33195 = env33196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33195 == env33196) = true)

def leafEnv33196 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,49,40,33,0,35,49,32,53,1,32,33,17,2,21,40,1,17,32,48,48,32,21,32,37,33,4,35,33,43,1,32,0]

def active33196 : List Nat := [0,1,2,3,4]

def tree33196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33196 : H12WitnessSearch.Good tree33196 := H12GlobalWitnessIndex.good

theorem leafIdentity33196 : H12AffineFastState.composeSystem env33196 rootObs = leafEnv33196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33196 rootObs == leafEnv33196) = true)

theorem terminalChecked33196 : H12PackedTerminal.terminalCheckFast leafEnv33196 active33196 tree33196 = true := by decide +kernel

def env33197 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115871,201782,119966,98701,8328,16,245139,115102,17665,10280,119043,144564,256,21793,46213,63109]

theorem envBound33197 : H12AffineFastState.Bounded env33197 := by
  intro p hp
  have h : env33197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33178_33197 : H12AffineEnvironment.transform 5 17 env33178 = env33197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33178 == env33197) = true)

theorem identity33197 : scanCanonicalize (H12AffineFastState.compose env33197 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115102) := by decide +kernel

theorem selectedBound33197 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33198 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115102,64809,1024,32769,115871,54696,119966,98701,8328,16,31757,115102,17665,10280,119043,128298,256,21793,46213,63109]

theorem envBound33198 : H12AffineFastState.Bounded env33198 := by
  intro p hp
  have h : env33198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33197_33198 : H12AffineEnvironment.transform 16 115102 env33197 = env33198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115102 env33197 == env33198) = true)

theorem identity33198 : scanCanonicalize (H12AffineFastState.compose env33198 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound33198 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env33199 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54278,5528,64809,1024,32769,4249,54696,152,21899,8328,16,31757,5528,17665,10280,1285,8492,256,21793,46213,63109]

theorem envBound33199 : H12AffineFastState.Bounded env33199 := by
  intro p hp
  have h : env33199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33198_33199 : H12AffineEnvironment.transform 15 54278 env33198 = env33199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env33198 == env33199) = true)

theorem identity33199 : scanCanonicalize (H12AffineFastState.compose env33199 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound33199 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env33200 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,2477,1024,29829,4249,8492,152,21899,8328,16,31757,5528,17665,10280,1285,8492,256,21793,16385,513]

theorem envBound33200 : H12AffineFastState.Bounded env33200 := by
  intro p hp
  have h : env33200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33199_33200 : H12AffineEnvironment.transform 14 29828 env33199 = env33200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env33199 == env33200) = true)

theorem identity33200 : scanCanonicalize (H12AffineFastState.compose env33200 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33200 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33201 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,262,5528,2477,1024,21761,4249,168,152,21899,268,16,23945,5528,17665,2476,1285,168,256,21793,16385,513]

theorem envBound33201 : H12AffineFastState.Bounded env33201 := by
  intro p hp
  have h : env33201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33200_33201 : H12AffineEnvironment.transform 12 388 env33200 = env33201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33200 == env33201) = true)

theorem identity33201 : scanCanonicalize (H12AffineFastState.compose env33201 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33201 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33202 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,388,16384,20496,262,4232,2477,272,20497,4249,168,152,20635,268,16,22681,4232,16401,2476,21,168,256,20529,16385,513]

theorem envBound33202 : H12AffineFastState.Bounded env33202 := by
  intro p hp
  have h : env33202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33201_33202 : H12AffineEnvironment.transform 9 272 env33201 = env33202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33201 == env33202) = true)

theorem identity33202 : scanCanonicalize (H12AffineFastState.compose env33202 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33202 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33203 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,20496,262,4097,2340,272,20497,4112,33,17,20498,268,16,22544,4097,16401,2341,21,33,256,20529,16385,513]

theorem envBound33203 : H12AffineFastState.Bounded env33203 := by
  intro p hp
  have h : env33203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33202_33203 : H12AffineEnvironment.transform 6 9 env33202 = env33203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33202 == env33203) = true)

theorem identity33203 : scanCanonicalize (H12AffineFastState.compose env33203 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33203 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33204 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,16384,20496,34,4097,2048,52,20497,4112,33,17,20498,40,16,22544,4097,16401,2049,21,33,36,20529,16385,513]

theorem envBound33204 : H12AffineFastState.Bounded env33204 := by
  intro p hp
  have h : env33204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33203_33204 : H12AffineEnvironment.transform 7 36 env33203 = env33204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33203 == env33204) = true)

theorem identity33204 : scanCanonicalize (H12AffineFastState.compose env33204 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound33204 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env33205 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,1,34,4097,2048,52,0,4112,33,17,3,40,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound33205 : H12AffineFastState.Bounded env33205 := by
  intro p hp
  have h : env33205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33204_33205 : H12AffineEnvironment.transform 13 4113 env33204 = env33205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env33204 == env33205) = true)

theorem identity33205 : scanCanonicalize (H12AffineFastState.compose env33205 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound33205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33206 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,33,41,48,1,34,32,2048,52,0,49,33,17,3,40,16,2049,32,33,2049,21,33,36,32,49,513]

theorem envBound33206 : H12AffineFastState.Bounded env33206 := by
  intro p hp
  have h : env33206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33205_33206 : H12AffineEnvironment.transform 11 33 env33205 = env33206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env33205 == env33206) = true)

theorem identity33206 : scanCanonicalize (H12AffineFastState.compose env33206 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33206 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33207 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,41,48,1,34,32,49,52,0,49,33,17,3,40,16,48,32,33,48,21,33,36,32,49,513]

theorem envBound33207 : H12AffineFastState.Bounded env33207 := by
  intro p hp
  have h : env33207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33206_33207 : H12AffineEnvironment.transform 10 49 env33206 = env33207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33206 == env33207) = true)

def leafEnv33207 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,41,48,1,34,32,49,52,0,49,33,17,3,21,40,1,16,48,32,33,48,21,33,36,32,4,35,49,513,1,48,0]

def active33207 : List Nat := [0,1,2,3,4,8]

def tree33207 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33207 : H12WitnessSearch.Good tree33207 := H12GlobalWitnessIndex.good

theorem leafIdentity33207 : H12AffineFastState.composeSystem env33207 rootObs = leafEnv33207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33207 rootObs == leafEnv33207) = true)

theorem terminalChecked33207 : H12PackedTerminal.terminalCheckFast leafEnv33207 active33207 tree33207 = true := by decide +kernel

def env33208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound33208 : H12AffineFastState.Bounded env33208 := by
  intro p hp
  have h : env33208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33003_33208 : H12AffineEnvironment.transform 18 1025 env33003 = env33208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env33003 == env33208) = true)

theorem identity33208 : scanCanonicalize (H12AffineFastState.compose env33208 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347627) := by decide +kernel

theorem selectedBound33208 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,16777216,8328,65,29868032,17090918,8722618,8830976,25265168,21243946,257,25463111,25454818,25207750]

theorem envBound33209 : H12AffineFastState.Bounded env33209 := by
  intro p hp
  have h : env33209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33208_33209 : H12AffineEnvironment.transform 20 347627 env33208 = env33209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347627 env33208 == env33209) = true)

def env33210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392316,8328,65,12729468,79130,8722618,8830976,8681580,4314198,257,8484155,8492190,8740794]

theorem envBound33210 : H12AffineFastState.Bounded env33210 := by
  intro p hp
  have h : env33210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33209_33210 : H12AffineEnvironment.transform 23 392316 env33209 = env33210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392316 env33209 == env33210) = true)

def env33211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98780,8328,65,12729468,79130,8480026,8568224,8390092,4314198,257,8484155,8492190,8462874]

theorem envBound33211 : H12AffineFastState.Bounded env33211 := by
  intro p hp
  have h : env33211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33210_33211 : H12AffineEnvironment.transform 17 32160 env33210 = env33211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env33210 == env33211) = true)

def env33212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98780,8328,65,8546652,79130,8480026,8568224,8390092,98678,257,8484155,8492190,8462874]

theorem envBound33212 : H12AffineFastState.Bounded env33212 := by
  intro p hp
  have h : env33212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33211_33212 : H12AffineEnvironment.transform 21 21792 env33211 = env33212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env33211 == env33212) = true)

theorem identity33212 : scanCanonicalize (H12AffineFastState.compose env33212 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33212 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,8388608,41430,8328,65,8546652,5392,8406288,8568224,8390092,41340,257,8410417,8434836,8389136]

theorem envBound33213 : H12AffineFastState.Bounded env33213 := by
  intro p hp
  have h : env33213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33212_33213 : H12AffineEnvironment.transform 15 8202 env33212 = env33213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33212 == env33213) = true)

def env33214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,96,41430,8328,65,158012,5392,17776,179648,1452,41340,257,21841,46324,624]

theorem envBound33214 : H12AffineFastState.Bounded env33214 := by
  intro p hp
  have h : env33214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33213_33214 : H12AffineEnvironment.transform 22 96 env33213 = env33214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 96 env33213 == env33214) = true)

theorem identity33214 : scanCanonicalize (H12AffineFastState.compose env33214 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound33214 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13509,32160,1025,32769,4161,21792,96,41430,8328,65,24057,5392,17776,35077,1452,41340,257,21841,46324,624]

theorem envBound33215 : H12AffineFastState.Bounded env33215 := by
  intro p hp
  have h : env33215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33214_33215 : H12AffineEnvironment.transform 16 13509 env33214 = env33215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env33214 == env33215) = true)

theorem identity33215 : scanCanonicalize (H12AffineFastState.compose env33215 (packedSelected [0,2,3,4,5,6,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound33215 : packedSelected [0,2,3,4,5,6,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5409,32768,8202,13509,10369,1025,32769,4161,1,96,41430,8328,65,2264,5392,4177,35077,1452,41340,257,112,46324,624]

theorem envBound33216 : H12AffineFastState.Bounded env33216 := by
  intro p hp
  have h : env33216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33215_33216 : H12AffineEnvironment.transform 13 5409 env33215 = env33216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env33215 == env33216) = true)

theorem identity33216 : scanCanonicalize (H12AffineFastState.compose env33216 (packedSelected [1,3,5,8,17,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33216 : packedSelected [1,3,5,8,17,26,31] rootPS < 2^1333 := by decide +kernel

def env33217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5409,8540,8202,13509,10369,1025,8541,4161,1,96,138,8328,65,2264,5392,4177,10329,1452,32,257,112,5544,624]

theorem envBound33217 : H12AffineFastState.Bounded env33217 := by
  intro p hp
  have h : env33217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33216_33217 : H12AffineEnvironment.transform 14 8540 env33216 = env33217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33216 == env33217) = true)

theorem identity33217 : scanCanonicalize (H12AffineFastState.compose env33217 (packedSelected [0,1,2,7,8,10,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound33217 : packedSelected [0,1,2,7,8,10,14,17,20] rootPS < 2^1333 := by decide +kernel

def env33218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5409,248,430,5473,2341,1025,249,4161,1,96,138,300,65,2264,5392,4177,2557,1452,32,257,112,5544,624]

theorem envBound33218 : H12AffineFastState.Bounded env33218 := by
  intro p hp
  have h : env33218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33217_33218 : H12AffineEnvironment.transform 12 420 env33217 = env33218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env33217 == env33218) = true)

theorem identity33218 : scanCanonicalize (H12AffineFastState.compose env33218 (packedSelected [2,4,6,9,11,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33218 : packedSelected [2,4,6,9,11,17,18] rootPS < 2^1333 := by decide +kernel

def env33219 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,420,5409,137,430,5392,2341,1025,136,4144,1,17,138,300,48,2217,5392,4128,2444,1452,32,257,1,5544,513]

theorem envBound33219 : H12AffineFastState.Bounded env33219 := by
  intro p hp
  have h : env33219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33218_33219 : H12AffineEnvironment.transform 5 49 env33218 = env33219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33218 == env33219) = true)

theorem identity33219 : scanCanonicalize (H12AffineFastState.compose env33219 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33219 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33220 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,388,5377,137,398,5392,2309,1025,136,4112,1,17,138,268,16,2185,5392,4096,2444,1420,0,257,1,5512,513]

theorem envBound33220 : H12AffineFastState.Bounded env33220 := by
  intro p hp
  have h : env33220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33219_33220 : H12AffineEnvironment.transform 4 0 env33219 = env33220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33219 == env33220) = true)

theorem identity33220 : scanCanonicalize (H12AffineFastState.compose env33220 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33220 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33221 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,0,263,5392,2309,1025,1,4112,1,17,3,268,16,2048,5392,4096,2309,1285,0,257,1,5377,513]

theorem envBound33221 : H12AffineFastState.Bounded env33221 := by
  intro p hp
  have h : env33221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33220_33221 : H12AffineEnvironment.transform 6 9 env33220 = env33221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33220 == env33221) = true)

theorem identity33221 : scanCanonicalize (H12AffineFastState.compose env33221 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33222 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5125,0,3,5140,2049,1025,1,4112,1,17,3,8,16,2048,5140,4096,2049,1025,0,5,1,5125,513]

theorem envBound33222 : H12AffineFastState.Bounded env33222 := by
  intro p hp
  have h : env33222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33221_33222 : H12AffineEnvironment.transform 7 4 env33221 = env33222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33221 == env33222) = true)

def env33223 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1045,0,3,1028,2049,1025,1,0,1,17,3,8,16,2048,1028,16,2049,1025,0,5,1,1045,513]

theorem envBound33223 : H12AffineFastState.Bounded env33223 := by
  intro p hp
  have h : env33223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33222_33223 : H12AffineEnvironment.transform 11 16 env33222 = env33223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33222 == env33223) = true)

theorem identity33223 : scanCanonicalize (H12AffineFastState.compose env33223 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound33223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33224 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,1,0,3,16,2049,21,1,0,1,17,3,8,16,2048,16,16,2049,21,0,5,1,1,513]

theorem envBound33224 : H12AffineFastState.Bounded env33224 := by
  intro p hp
  have h : env33224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33223_33224 : H12AffineEnvironment.transform 9 20 env33223 = env33224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33223 == env33224) = true)

theorem identity33224 : scanCanonicalize (H12AffineFastState.compose env33224 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33225 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,1,0,3,16,0,21,1,0,1,17,3,8,16,1,16,16,0,21,0,5,1,1,513]

theorem envBound33225 : H12AffineFastState.Bounded env33225 := by
  intro p hp
  have h : env33225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33224_33225 : H12AffineEnvironment.transform 10 1 env33224 = env33225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33224 == env33225) = true)

def leafEnv33225 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,1,0,3,16,0,21,1,0,1,17,3,20,8,1,16,1,16,16,0,21,0,5,1,5,2,1,513,1,0,0]

def active33225 : List Nat := [0,1,2,3,8]

def tree33225 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33225 : H12WitnessSearch.Good tree33225 := H12GlobalWitnessIndex.good

theorem leafIdentity33225 : H12AffineFastState.composeSystem env33225 rootObs = leafEnv33225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33225 rootObs == leafEnv33225) = true)

theorem terminalChecked33225 : H12PackedTerminal.terminalCheckFast leafEnv33225 active33225 tree33225 = true := by decide +kernel

def env33226 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1044,0,3,1029,2049,1025,1,1,1,17,3,8,16,2048,1029,17,2049,1025,0,5,1,1044,513]

theorem envBound33226 : H12AffineFastState.Bounded env33226 := by
  intro p hp
  have h : env33226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33222_33226 : H12AffineEnvironment.transform 11 17 env33222 = env33226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33222 == env33226) = true)

def env33227 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,9,0,0,3,17,2049,21,1,1,1,17,3,8,16,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound33227 : H12AffineFastState.Bounded env33227 := by
  intro p hp
  have h : env33227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33226_33227 : H12AffineEnvironment.transform 9 20 env33226 = env33227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33226 == env33227) = true)

theorem identity33227 : scanCanonicalize (H12AffineFastState.compose env33227 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33228 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,0,0,3,17,1,21,1,1,1,17,3,8,16,0,17,17,1,21,0,5,1,0,513]

theorem envBound33228 : H12AffineFastState.Bounded env33228 := by
  intro p hp
  have h : env33228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33227_33228 : H12AffineEnvironment.transform 10 0 env33227 = env33228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33227 == env33228) = true)

def leafEnv33228 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,0,0,3,17,1,21,1,1,1,17,3,20,8,1,16,0,17,17,1,21,0,5,1,5,2,0,513,1,1,0]

def active33228 : List Nat := [0,1,2,3,8]

def tree33228 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33228 : H12WitnessSearch.Good tree33228 := H12GlobalWitnessIndex.good

theorem leafIdentity33228 : H12AffineFastState.composeSystem env33228 rootObs = leafEnv33228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33228 rootObs == leafEnv33228) = true)

theorem terminalChecked33228 : H12PackedTerminal.terminalCheckFast leafEnv33228 active33228 tree33228 = true := by decide +kernel

def env33229 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,1,0,3,16,2049,20,1,1,1,17,3,8,16,2048,16,17,2049,20,0,5,1,1,513]

theorem envBound33229 : H12AffineFastState.Bounded env33229 := by
  intro p hp
  have h : env33229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33226_33229 : H12AffineEnvironment.transform 9 21 env33226 = env33229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33226 == env33229) = true)

theorem identity33229 : scanCanonicalize (H12AffineFastState.compose env33229 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound33229 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33230 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,17,9,1,0,3,16,523,20,1,1,1,17,3,8,16,522,16,17,523,20,0,5,1,1,513]

theorem envBound33230 : H12AffineFastState.Bounded env33230 := by
  intro p hp
  have h : env33230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33229_33230 : H12AffineEnvironment.transform 10 522 env33229 = env33230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env33229 == env33230) = true)

def leafEnv33230 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,17,9,1,0,3,16,523,20,1,1,1,17,3,21,8,1,16,522,16,17,523,20,0,5,1,5,2,1,513,1,1,0]

def active33230 : List Nat := [0,1,2,3,8]

def tree33230 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33230 : H12WitnessSearch.Good tree33230 := H12GlobalWitnessIndex.good

theorem leafIdentity33230 : H12AffineFastState.composeSystem env33230 rootObs = leafEnv33230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33230 rootObs == leafEnv33230) = true)

theorem terminalChecked33230 : H12PackedTerminal.terminalCheckFast leafEnv33230 active33230 tree33230 = true := by decide +kernel

def env33231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,97,41430,8328,65,158013,5392,17777,179649,1453,41340,257,21840,46325,625]

theorem envBound33231 : H12AffineFastState.Bounded env33231 := by
  intro p hp
  have h : env33231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33213_33231 : H12AffineEnvironment.transform 22 97 env33213 = env33231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 97 env33213 == env33231) = true)

theorem identity33231 : scanCanonicalize (H12AffineFastState.compose env33231 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13493) := by decide +kernel

theorem selectedBound33231 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13493,32160,1025,32769,4161,21792,97,41430,8328,65,23944,5392,17777,35188,1453,41340,257,21840,46325,625]

theorem envBound33232 : H12AffineFastState.Bounded env33232 := by
  intro p hp
  have h : env33232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33231_33232 : H12AffineEnvironment.transform 16 13493 env33231 = env33232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13493 env33231 == env33232) = true)

theorem identity33232 : scanCanonicalize (H12AffineFastState.compose env33232 (packedSelected [1,11,12,15,16,17,18,19,20,23,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound33232 : packedSelected [1,11,12,15,16,17,18,19,20,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8492,8202,13493,32160,1025,8493,4161,21792,97,250,8328,65,23944,5392,17777,10328,1453,80,257,21840,5593,625]

theorem envBound33233 : H12AffineFastState.Bounded env33233 := by
  intro p hp
  have h : env33233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33232_33233 : H12AffineEnvironment.transform 14 8492 env33232 = env33233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env33232 == env33233) = true)

theorem identity33233 : scanCanonicalize (H12AffineFastState.compose env33233 (packedSelected [1,2,3,4,5,12,14,15,17,19,20,22,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33233 : packedSelected [1,2,3,4,5,12,14,15,17,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env33234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8492,8202,13493,10401,1025,8493,4161,33,97,250,8328,65,2185,5392,4208,10328,1453,80,257,81,5593,625]

theorem envBound33234 : H12AffineFastState.Bounded env33234 := by
  intro p hp
  have h : env33234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33233_33234 : H12AffineEnvironment.transform 13 5377 env33233 = env33234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33233 == env33234) = true)

theorem identity33234 : scanCanonicalize (H12AffineFastState.compose env33234 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33234 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env33235 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,8192,5377,8492,8202,13493,10401,1025,8493,4145,33,17,138,8328,49,2185,5392,4096,10280,1453,32,257,33,5545,513]

theorem envBound33235 : H12AffineFastState.Bounded env33235 := by
  intro p hp
  have h : env33235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33234_33235 : H12AffineEnvironment.transform 5 48 env33234 = env33235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33234 == env33235) = true)

theorem identity33235 : scanCanonicalize (H12AffineFastState.compose env33235 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33236 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,5377,8461,8202,13460,10368,1025,8460,4112,0,17,138,8328,16,2185,5392,4096,10249,1420,1,257,0,5512,513]

theorem envBound33236 : H12AffineFastState.Bounded env33236 := by
  intro p hp
  have h : env33236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33235_33236 : H12AffineEnvironment.transform 4 1 env33235 = env33236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33235 == env33236) = true)

theorem identity33236 : scanCanonicalize (H12AffineFastState.compose env33236 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33236 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env33237 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,388,5377,137,398,5392,2308,1025,136,4112,0,17,138,268,16,2185,5392,4096,2445,1420,1,257,0,5512,513]

theorem envBound33237 : H12AffineFastState.Bounded env33237 := by
  intro p hp
  have h : env33237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33236_33237 : H12AffineEnvironment.transform 12 388 env33236 = env33237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33236 == env33237) = true)

theorem identity33237 : scanCanonicalize (H12AffineFastState.compose env33237 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33237 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33238 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,0,263,5392,2308,1025,1,4112,0,17,3,268,16,2048,5392,4096,2308,1285,1,257,0,5377,513]

theorem envBound33238 : H12AffineFastState.Bounded env33238 := by
  intro p hp
  have h : env33238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33237_33238 : H12AffineEnvironment.transform 6 9 env33237 = env33238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33237 == env33238) = true)

theorem identity33238 : scanCanonicalize (H12AffineFastState.compose env33238 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33239 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,0,2,5141,2049,1025,1,4112,0,17,3,9,16,2048,5141,4096,2049,1024,1,4,0,5124,513]

theorem envBound33239 : H12AffineFastState.Bounded env33239 := by
  intro p hp
  have h : env33239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33238_33239 : H12AffineEnvironment.transform 7 5 env33238 = env33239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33238 == env33239) = true)

def env33240 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,0,2,1029,2049,1025,1,0,0,17,3,9,16,2048,1029,16,2049,1024,1,4,0,1044,513]

theorem envBound33240 : H12AffineFastState.Bounded env33240 := by
  intro p hp
  have h : env33240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33239_33240 : H12AffineEnvironment.transform 11 16 env33239 = env33240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33239 == env33240) = true)

def env33241 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,0,2,1028,2049,1025,1,1,0,17,3,9,16,2048,1028,17,2049,1024,1,4,0,1045,513]

theorem envBound33241 : H12AffineFastState.Bounded env33241 := by
  intro p hp
  have h : env33241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33239_33241 : H12AffineEnvironment.transform 11 17 env33239 = env33241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33239 == env33241) = true)

theorem identity33241 : scanCanonicalize (H12AffineFastState.compose env33241 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound33241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33242 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,1,0,2,16,2049,21,1,1,0,17,3,9,16,2048,16,17,2049,20,1,4,0,1,513]

theorem envBound33242 : H12AffineFastState.Bounded env33242 := by
  intro p hp
  have h : env33242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33241_33242 : H12AffineEnvironment.transform 9 20 env33241 = env33242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33241 == env33242) = true)

theorem identity33242 : scanCanonicalize (H12AffineFastState.compose env33242 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound33242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33243 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,17,8,1,0,2,16,522,21,1,1,0,17,3,9,16,523,16,17,522,20,1,4,0,1,513]

theorem envBound33243 : H12AffineFastState.Bounded env33243 := by
  intro p hp
  have h : env33243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33242_33243 : H12AffineEnvironment.transform 10 523 env33242 = env33243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env33242 == env33243) = true)

def leafEnv33243 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,17,8,1,0,2,16,522,21,1,1,0,17,3,21,9,1,16,523,16,17,522,20,1,4,0,5,3,1,513,1,1,0]

def active33243 : List Nat := [0,1,2,3,8]

def tree33243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33243 : H12WitnessSearch.Good tree33243 := H12GlobalWitnessIndex.good

theorem leafIdentity33243 : H12AffineFastState.composeSystem env33243 rootObs = leafEnv33243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33243 rootObs == leafEnv33243) = true)

theorem terminalChecked33243 : H12PackedTerminal.terminalCheckFast leafEnv33243 active33243 tree33243 = true := by decide +kernel

def env33244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98780,8328,65,8546653,79130,8480026,8568224,8390092,98679,257,8484155,8492190,8462874]

theorem envBound33244 : H12AffineFastState.Bounded env33244 := by
  intro p hp
  have h : env33244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33211_33244 : H12AffineEnvironment.transform 21 21793 env33211 = env33244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env33211 == env33244) = true)

theorem identity33244 : scanCanonicalize (H12AffineFastState.compose env33244 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound33244 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,73755,98780,8328,65,215366,79130,17665,236987,75223,98679,257,21792,46213,513]

theorem envBound33245 : H12AffineFastState.Bounded env33245 := by
  intro p hp
  have h : env33245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33244_33245 : H12AffineEnvironment.transform 22 73755 env33244 = env33245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env33244 == env33245) = true)

def env33246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,73755,98644,8192,65,215366,79130,17665,236851,75103,98679,257,21792,46093,513]

theorem envBound33246 : H12AffineFastState.Bounded env33246 := by
  intro p hp
  have h : env33246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0