import H12CloudChart0Data066

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound16872 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env16873 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2492,161,2556,509,250,2492,2048,320,508,2340,113,16,138,41,64,2477,2405,2405,2477,204,249,256,168,2476,513]

theorem envBound16873 : H12AffineFastState.Bounded env16873 := by
  intro p hp
  have h : env16873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16872_16873 : H12AffineEnvironment.transform 11 2492 env16872 = env16873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env16872 == env16873) = true)

theorem identity16873 : scanCanonicalize (H12AffineFastState.compose env16873 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16873 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env16874 : List Nat := [2,4,8,16,32,64,128,36,512,100,2048,2200,161,2264,217,250,2200,2048,100,216,2048,113,16,138,41,64,2185,2113,2113,2185,204,249,36,168,2184,513]

theorem envBound16874 : H12AffineFastState.Bounded env16874 := by
  intro p hp
  have h : env16874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16873_16874 : H12AffineEnvironment.transform 7 36 env16873 = env16874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16873 == env16874) = true)

theorem identity16874 : scanCanonicalize (H12AffineFastState.compose env16874 (packedSelected [4,6] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound16874 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env16875 : List Nat := [2,4,8,16,32,64,128,36,512,100,545,697,161,761,217,250,697,545,100,216,545,113,16,138,41,64,680,608,608,680,204,249,36,168,681,513]

theorem envBound16875 : H12AffineFastState.Bounded env16875 := by
  intro p hp
  have h : env16875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16874_16875 : H12AffineEnvironment.transform 10 545 env16874 = env16875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env16874 == env16875) = true)

theorem identity16875 : scanCanonicalize (H12AffineFastState.compose env16875 (packedSelected [3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16875 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env16876 : List Nat := [2,4,8,16,32,64,9,36,512,100,545,560,40,624,80,115,560,545,100,81,545,113,16,3,41,64,545,608,608,545,69,112,36,33,544,513]

theorem envBound16876 : H12AffineFastState.Bounded env16876 := by
  intro p hp
  have h : env16876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16875_16876 : H12AffineEnvironment.transform 6 9 env16875 = env16876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16875 == env16876) = true)

theorem identity16876 : scanCanonicalize (H12AffineFastState.compose env16876 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16876 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env16877 : List Nat := [2,4,8,0,32,64,9,36,512,100,545,544,40,608,64,99,544,545,100,65,545,97,0,3,41,64,545,608,608,545,69,96,36,33,544,513]

theorem envBound16877 : H12AffineFastState.Bounded env16877 := by
  intro p hp
  have h : env16877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16876_16877 : H12AffineEnvironment.transform 3 0 env16876 = env16877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16876 == env16877) = true)

theorem identity16877 : scanCanonicalize (H12AffineFastState.compose env16877 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound16877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16878 : List Nat := [2,4,8,0,32,0,9,36,512,36,545,544,40,544,0,35,544,545,36,1,545,33,0,3,41,0,545,544,544,545,5,32,36,33,544,513]

theorem envBound16878 : H12AffineFastState.Bounded env16878 := by
  intro p hp
  have h : env16878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16877_16878 : H12AffineEnvironment.transform 5 0 env16877 = env16878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16877 == env16878) = true)

def env16879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175049,8328,64,2590067,46277,77954,2598355,99466,2101345,256,2199863,2172306,41820]

theorem envBound16879 : H12AffineFastState.Bounded env16879 := by
  intro p hp
  have h : env16879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16847_16879 : H12AffineEnvironment.transform 13 5377 env16847 = env16879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16847 == env16879) = true)

theorem identity16879 : scanCanonicalize (H12AffineFastState.compose env16879 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45340) := by decide +kernel

theorem selectedBound16879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41460,98766,98645,8328,64,472175,46277,77954,464079,99466,41341,256,73771,103566,41820]

theorem envBound16880 : H12AffineFastState.Bounded env16880 := by
  intro p hp
  have h : env16880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16879_16880 : H12AffineEnvironment.transform 20 45340 env16879 = env16880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45340 env16879 == env16880) = true)

def env16881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41340,98630,98645,8192,64,472175,46157,77834,463943,99330,41341,256,73771,103430,41820]

theorem envBound16881 : H12AffineFastState.Bounded env16881 := by
  intro p hp
  have h : env16881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16880_16881 : H12AffineEnvironment.transform 6 8 env16880 = env16881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16880 == env16881) = true)

theorem identity16881 : scanCanonicalize (H12AffineFastState.compose env16881 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound16881 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,45340,41340,98630,98645,8192,64,262517,46157,77834,270685,99330,41341,256,73771,103430,41820]

theorem envBound16882 : H12AffineFastState.Bounded env16882 := by
  intro p hp
  have h : env16882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16881_16882 : H12AffineEnvironment.transform 16 79130 env16881 = env16882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env16881 == env16882) = true)

theorem identity16882 : scanCanonicalize (H12AffineFastState.compose env16882 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16882 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env16883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79130,262144,1024,8540,4161,33,73755,73736,8192,64,262517,5392,77834,270685,75103,32,256,73771,79195,513]

theorem envBound16883 : H12AffineFastState.Bounded env16883 := by
  intro p hp
  have h : env16883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16882_16883 : H12AffineEnvironment.transform 14 8541 env16882 = env16883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16882 == env16883) = true)

theorem identity16883 : scanCanonicalize (H12AffineFastState.compose env16883 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound16883 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79130,10508,1024,8540,4161,33,73755,73736,8192,64,10361,5392,77834,2129,75103,32,256,73771,79195,513]

theorem envBound16884 : H12AffineFastState.Bounded env16884 := by
  intro p hp
  have h : env16884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16883_16884 : H12AffineEnvironment.transform 17 10508 env16883 = env16884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env16883 == env16884) = true)

theorem identity16884 : scanCanonicalize (H12AffineFastState.compose env16884 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16884 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16885 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,65536,77834,10508,272,8540,4161,33,73755,73736,8192,64,10361,4096,77834,2129,73807,32,256,73771,77899,513]

theorem envBound16885 : H12AffineFastState.Bounded env16885 := by
  intro p hp
  have h : env16885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16884_16885 : H12AffineEnvironment.transform 9 272 env16884 = env16885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16884 == env16885) = true)

theorem identity16885 : scanCanonicalize (H12AffineFastState.compose env16885 (packedSelected [2,5,6,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound16885 : packedSelected [2,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env16886 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,512,8192,529,8541,65536,74250,10508,272,8540,577,33,73755,73736,8192,64,10361,512,74250,2129,73807,32,256,73771,74315,513]

theorem envBound16886 : H12AffineFastState.Bounded env16886 := by
  intro p hp
  have h : env16886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16885_16886 : H12AffineEnvironment.transform 11 512 env16885 = env16886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env16885 == env16886) = true)

theorem identity16886 : scanCanonicalize (H12AffineFastState.compose env16886 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound16886 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env16887 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,512,8192,529,8541,8494,804,10508,272,8540,577,33,309,294,8192,64,10361,512,804,2129,353,32,256,261,869,513]

theorem envBound16887 : H12AffineFastState.Bounded env16887 := by
  intro p hp
  have h : env16887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16886_16887 : H12AffineEnvironment.transform 15 8494 env16886 = env16887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env16886 == env16887) = true)

theorem identity16887 : scanCanonicalize (H12AffineFastState.compose env16887 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16887 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16888 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,512,269,529,80,35,804,2049,272,81,577,33,309,294,269,64,2420,512,804,2129,353,32,256,261,869,513]

theorem envBound16888 : H12AffineFastState.Bounded env16888 := by
  intro p hp
  have h : env16888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16887_16888 : H12AffineEnvironment.transform 12 269 env16887 = env16888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16887 == env16888) = true)

theorem identity16888 : scanCanonicalize (H12AffineFastState.compose env16888 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound16888 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16889 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,512,120,529,80,35,593,2049,101,81,577,33,64,83,120,64,2049,512,593,2129,20,32,117,112,528,513]

theorem envBound16889 : H12AffineFastState.Bounded env16889 := by
  intro p hp
  have h : env16889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16888_16889 : H12AffineEnvironment.transform 7 117 env16888 = env16889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env16888 == env16889) = true)

theorem identity16889 : scanCanonicalize (H12AffineFastState.compose env16889 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound16889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16890 : List Nat := [2,4,8,16,32,64,8,117,512,101,27,512,120,529,80,35,593,26,101,81,577,33,64,83,120,64,26,512,593,74,20,32,117,112,528,513]

theorem envBound16890 : H12AffineFastState.Bounded env16890 := by
  intro p hp
  have h : env16890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16889_16890 : H12AffineEnvironment.transform 10 27 env16889 = env16890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env16889 == env16890) = true)

theorem identity16890 : scanCanonicalize (H12AffineFastState.compose env16890 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16890 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env16891 : List Nat := [2,4,8,16,32,17,8,36,512,52,27,512,41,529,1,35,512,26,52,0,528,33,17,2,41,17,26,512,512,27,20,32,36,33,528,513]

theorem envBound16891 : H12AffineFastState.Bounded env16891 := by
  intro p hp
  have h : env16891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16890_16891 : H12AffineEnvironment.transform 5 17 env16890 = env16891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16890 == env16891) = true)

theorem identity16891 : scanCanonicalize (H12AffineFastState.compose env16891 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound16891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16892 : List Nat := [2,4,8,16,32,17,8,36,27,52,27,27,41,10,1,35,27,26,52,0,11,33,17,2,41,17,26,27,27,27,20,32,36,33,11,26]

theorem envBound16892 : H12AffineFastState.Bounded env16892 := by
  intro p hp
  have h : env16892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16891_16892 : H12AffineEnvironment.transform 8 27 env16891 = env16892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env16891 == env16892) = true)

theorem identity16892 : scanCanonicalize (H12AffineFastState.compose env16892 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16893 : List Nat := [2,4,8,10,32,11,8,36,1,46,1,1,41,10,1,35,1,0,46,0,11,33,11,2,41,11,0,1,1,1,14,32,36,33,11,0]

theorem envBound16893 : H12AffineFastState.Bounded env16893 := by
  intro p hp
  have h : env16893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16892_16893 : H12AffineEnvironment.transform 3 10 env16892 = env16893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16892 == env16893) = true)

theorem identity16893 : scanCanonicalize (H12AffineFastState.compose env16893 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16893 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16894 : List Nat := [2,4,2,0,32,1,2,36,1,36,1,1,35,0,1,35,1,0,36,0,1,33,1,2,35,1,0,1,1,1,4,32,36,33,1,0]

theorem envBound16894 : H12AffineFastState.Bounded env16894 := by
  intro p hp
  have h : env16894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16893_16894 : H12AffineEnvironment.transform 2 2 env16893 = env16894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16893 == env16894) = true)

def env16895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41341,98631,98645,8193,64,472175,46156,77835,463942,99331,41341,256,73771,103431,41820]

theorem envBound16895 : H12AffineFastState.Bounded env16895 := by
  intro p hp
  have h : env16895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16880_16895 : H12AffineEnvironment.transform 6 9 env16880 = env16895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16880 == env16895) = true)

theorem identity16895 : scanCanonicalize (H12AffineFastState.compose env16895 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound16895 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103495,262144,1024,32769,45340,41341,98631,98645,8193,64,303144,46156,77835,294913,99331,41341,256,73771,103431,41820]

theorem envBound16896 : H12AffineFastState.Bounded env16896 := by
  intro p hp
  have h : env16896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16895_16896 : H12AffineEnvironment.transform 16 103495 env16895 = env16896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env16895 == env16896) = true)

theorem identity16896 : scanCanonicalize (H12AffineFastState.compose env16896 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16896 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,262144,1024,8540,4161,32,73754,73736,8193,64,262517,5393,77835,270684,75102,32,256,73771,79194,513]

theorem envBound16897 : H12AffineFastState.Bounded env16897 := by
  intro p hp
  have h : env16897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16896_16897 : H12AffineEnvironment.transform 14 8541 env16896 = env16897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16896 == env16897) = true)

theorem identity16897 : scanCanonicalize (H12AffineFastState.compose env16897 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound16897 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,76079,1024,8540,4161,32,73754,73736,8193,64,75866,5393,77835,67699,75102,32,256,73771,79194,513]

theorem envBound16898 : H12AffineFastState.Bounded env16898 := by
  intro p hp
  have h : env16898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16897_16898 : H12AffineEnvironment.transform 17 76079 env16897 = env16898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env16897 == env16898) = true)

theorem identity16898 : scanCanonicalize (H12AffineFastState.compose env16898 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16898 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5393,2340,1024,8540,4161,32,17,3,8193,64,2129,5393,4096,10360,1365,32,256,32,5457,513]

theorem envBound16899 : H12AffineFastState.Bounded env16899 := by
  intro p hp
  have h : env16899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16898_16899 : H12AffineEnvironment.transform 15 8203 env16898 = env16899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16898 == env16899) = true)

theorem identity16899 : scanCanonicalize (H12AffineFastState.compose env16899 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16899 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5393,2340,1024,0,4161,32,17,3,349,64,2129,5393,4096,2340,1365,32,256,32,5457,513]

theorem envBound16900 : H12AffineFastState.Bounded env16900 := by
  intro p hp
  have h : env16900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16899_16900 : H12AffineEnvironment.transform 12 348 env16899 = env16900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16899 == env16900) = true)

theorem identity16900 : scanCanonicalize (H12AffineFastState.compose env16900 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound16900 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env16901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,309,348,1076,1,343,1060,2340,1024,0,372,32,17,3,349,64,2129,1060,309,2340,1365,32,256,32,1124,513]

theorem envBound16901 : H12AffineFastState.Bounded env16901 := by
  intro p hp
  have h : env16901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16900_16901 : H12AffineEnvironment.transform 11 309 env16900 = env16901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env16900 == env16901) = true)

theorem identity16901 : scanCanonicalize (H12AffineFastState.compose env16901 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16901 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,309,348,1076,1,343,1060,0,1024,0,372,32,17,3,349,64,373,1060,309,0,1365,32,256,32,1124,513]

theorem envBound16902 : H12AffineFastState.Bounded env16902 := by
  intro p hp
  have h : env16902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16901_16902 : H12AffineEnvironment.transform 10 292 env16901 = env16902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16901 == env16902) = true)

theorem identity16902 : scanCanonicalize (H12AffineFastState.compose env16902 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound16902 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16903 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,309,348,80,1,343,64,0,100,0,372,32,17,3,349,64,373,64,309,0,305,32,256,32,0,513]

theorem envBound16903 : H12AffineFastState.Bounded env16903 := by
  intro p hp
  have h : env16903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16902_16903 : H12AffineEnvironment.transform 9 100 env16902 = env16903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env16902 == env16903) = true)

theorem identity16903 : scanCanonicalize (H12AffineFastState.compose env16903 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16903 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env16904 : List Nat := [2,4,8,16,32,16,9,256,512,52,292,309,268,0,1,263,16,0,52,0,292,32,17,3,269,16,293,16,309,0,305,32,256,32,0,513]

theorem envBound16904 : H12AffineFastState.Bounded env16904 := by
  intro p hp
  have h : env16904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16903_16904 : H12AffineEnvironment.transform 5 16 env16903 = env16904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16903 == env16904) = true)

theorem identity16904 : scanCanonicalize (H12AffineFastState.compose env16904 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16904 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16905 : List Nat := [2,4,8,16,32,16,9,5,512,52,33,48,9,0,1,2,16,0,52,0,33,32,17,3,8,16,32,16,48,0,52,32,5,32,0,513]

theorem envBound16905 : H12AffineFastState.Bounded env16905 := by
  intro p hp
  have h : env16905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16904_16905 : H12AffineEnvironment.transform 7 5 env16904 = env16905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16904 == env16905) = true)

theorem identity16905 : scanCanonicalize (H12AffineFastState.compose env16905 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16905 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16906 : List Nat := [2,4,8,16,0,16,9,5,512,20,1,16,9,0,1,2,16,0,20,0,1,0,17,3,8,16,0,16,16,0,20,0,5,0,0,513]

theorem envBound16906 : H12AffineFastState.Bounded env16906 := by
  intro p hp
  have h : env16906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16905_16906 : H12AffineEnvironment.transform 4 0 env16905 = env16906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16905 == env16906) = true)

theorem identity16906 : scanCanonicalize (H12AffineFastState.compose env16906 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16907 : List Nat := [2,4,8,16,0,16,9,5,0,20,1,16,9,0,1,2,16,0,20,0,1,0,17,3,8,16,0,16,16,0,20,0,5,0,0,1]

theorem envBound16907 : H12AffineFastState.Bounded env16907 := by
  intro p hp
  have h : env16907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16906_16907 : H12AffineEnvironment.transform 8 0 env16906 = env16907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16906 == env16907) = true)

theorem identity16907 : scanCanonicalize (H12AffineFastState.compose env16907 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16907 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16908 : List Nat := [2,4,8,10,0,10,9,5,0,14,1,10,9,0,1,2,10,0,14,0,1,0,11,3,8,10,0,10,10,0,14,0,5,0,0,1]

theorem envBound16908 : H12AffineFastState.Bounded env16908 := by
  intro p hp
  have h : env16908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16907_16908 : H12AffineEnvironment.transform 3 10 env16907 = env16908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16907 == env16908) = true)

def env16909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound16909 : H12AffineFastState.Bounded env16909 := by
  intro p hp
  have h : env16909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16692_16909 : H12AffineEnvironment.transform 18 1025 env16692 = env16909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env16692 == env16909) = true)

theorem identity16909 : scanCanonicalize (H12AffineFastState.compose env16909 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262354) := by decide +kernel

theorem selectedBound16909 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262354,8328,64,15025490,197087,10507601,8830977,10682691,4448403,257,8602110,8626267,10626708]

theorem envBound16910 : H12AffineFastState.Bounded env16910 := by
  intro p hp
  have h : env16910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16909_16910 : H12AffineEnvironment.transform 23 2262354 env16909 = env16910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262354 env16909 == env16910) = true)

def env16911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025490,115151,10507601,8650769,10600787,4268163,257,8487406,8478795,10544772]

theorem envBound16911 : H12AffineFastState.Bounded env16911 := by
  intro p hp
  have h : env16911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16910_16911 : H12AffineEnvironment.transform 16 49168 env16910 = env16911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16910 == env16911) = true)

def env16912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543746,115151,17665,2363457,119043,4268163,257,2199998,2191387,63188]

theorem envBound16912 : H12AffineFastState.Bounded env16912 := by
  intro p hp
  have h : env16912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16911_16912 : H12AffineEnvironment.transform 22 2101328 env16911 = env16912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env16911 == env16912) = true)

def env16913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97666,115151,17665,2363457,119043,329731,257,2199998,2191387,63188]

theorem envBound16913 : H12AffineFastState.Bounded env16913 := by
  intro p hp
  have h : env16913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16912_16913 : H12AffineEnvironment.transform 21 272512 env16912 = env16913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16912 == env16913) = true)

theorem identity16913 : scanCanonicalize (H12AffineFastState.compose env16913 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound16913 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,262144,1025,29908,2097152,272512,2101328,2114882,8328,64,97666,79130,17665,2363457,75222,329731,257,2188651,2191387,513]

theorem envBound16914 : H12AffineFastState.Bounded env16914 := by
  intro p hp
  have h : env16914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16913_16914 : H12AffineEnvironment.transform 14 29909 env16913 = env16914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env16913 == env16914) = true)

def env16915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10400,1025,29908,2097152,32,2101328,2114882,8328,64,97666,79130,17665,2111713,75222,73891,257,2188651,2191387,513]

theorem envBound16915 : H12AffineFastState.Bounded env16915 := by
  intro p hp
  have h : env16915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16914_16915 : H12AffineEnvironment.transform 17 10400 env16914 = env16915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16914 == env16915) = true)

theorem identity16915 : scanCanonicalize (H12AffineFastState.compose env16915 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound16915 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env16916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21726,13509,10400,1025,29908,2097152,32,2101328,2114882,8328,64,10588,25028,17665,2111713,28936,29821,257,2109877,2106565,513]

theorem envBound16916 : H12AffineFastState.Bounded env16916 := by
  intro p hp
  have h : env16916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16915_16916 : H12AffineEnvironment.transform 15 21726 env16915 = env16916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env16915 == env16916) = true)

theorem identity16916 : scanCanonicalize (H12AffineFastState.compose env16916 (packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 4588) := by decide +kernel

theorem selectedBound16916 : packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env16917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21726,13509,10400,1025,29908,4588,32,444,21678,8328,64,10588,25028,17665,10509,28936,29821,257,8281,13609,513]

theorem envBound16917 : H12AffineFastState.Bounded env16917 := by
  intro p hp
  have h : env16917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16916_16917 : H12AffineEnvironment.transform 20 4588 env16916 = env16917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4588 env16916 == env16917) = true)

theorem identity16917 : scanCanonicalize (H12AffineFastState.compose env16917 (packedSelected [0,1,5,8,11,14,17,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16917 : packedSelected [0,1,5,8,11,14,17,23,24,27] rootPS < 2^1333 := by decide +kernel

def env16918 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,21511,13340,10361,1025,29709,4405,32,357,21623,8273,64,10588,24861,17665,10509,28936,29821,257,8281,13609,513]

theorem envBound16918 : H12AffineFastState.Bounded env16918 := by
  intro p hp
  have h : env16918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16917_16918 : H12AffineEnvironment.transform 6 89 env16917 = env16918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16917 == env16918) = true)

theorem identity16918 : scanCanonicalize (H12AffineFastState.compose env16918 (packedSelected [0,1,2,3,5,6,7,8,11,12,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound16918 : packedSelected [0,1,2,3,5,6,7,8,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env16919 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2357,8192,16384,27961,19762,11561,10361,1025,27960,2048,32,357,19778,8273,64,10588,24861,17665,10509,26685,27976,257,8281,11292,513]

theorem envBound16919 : H12AffineFastState.Bounded env16919 := by
  intro p hp
  have h : env16919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16918_16919 : H12AffineEnvironment.transform 11 2357 env16918 = env16919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env16918 == env16919) = true)

theorem identity16919 : scanCanonicalize (H12AffineFastState.compose env16919 (packedSelected [4,9,18] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16919 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env16920 : List Nat := [2,4,8,16,32,64,89,256,512,1024,292,17,8192,16384,25629,17430,9229,8541,1025,25628,292,32,357,17510,8273,64,8312,24861,17665,8233,24857,25708,257,8281,9528,513]

theorem envBound16920 : H12AffineFastState.Bounded env16920 := by
  intro p hp
  have h : env16920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16919_16920 : H12AffineEnvironment.transform 10 292 env16919 = env16920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16919 == env16920) = true)

theorem identity16920 : scanCanonicalize (H12AffineFastState.compose env16920 (packedSelected [0,1,3,4,5,7,8,9,11,12,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16920 : packedSelected [0,1,3,4,5,7,8,9,11,12,20] rootPS < 2^1333 := by decide +kernel

def env16921 : List Nat := [2,4,8,16,32,64,89,36,512,1024,0,17,8192,16384,25629,17430,9229,8313,1025,25628,0,32,65,17510,8273,64,8312,24633,17445,8233,24637,25708,37,8281,9244,513]

theorem envBound16921 : H12AffineFastState.Bounded env16921 := by
  intro p hp
  have h : env16921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16920_16921 : H12AffineEnvironment.transform 7 36 env16920 = env16921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16920 == env16921) = true)

theorem identity16921 : scanCanonicalize (H12AffineFastState.compose env16921 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16921 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env16922 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,17,8192,16384,25629,17430,9229,8232,1025,25628,0,32,16,17463,8192,17,8233,24633,17445,8233,24637,25661,37,8200,9244,513]

theorem envBound16922 : H12AffineFastState.Bounded env16922 := by
  intro p hp
  have h : env16922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16921_16922 : H12AffineEnvironment.transform 5 17 env16921 = env16922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16921 == env16922) = true)

theorem identity16922 : scanCanonicalize (H12AffineFastState.compose env16922 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16922 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env16923 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,8192,16384,24616,16419,8248,8232,52,24617,0,32,16,16386,8192,17,8233,24633,16400,8233,24637,24584,37,8200,8233,513]

theorem envBound16923 : H12AffineFastState.Bounded env16923 := by
  intro p hp
  have h : env16923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16922_16923 : H12AffineEnvironment.transform 9 53 env16922 = env16923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16922 == env16923) = true)

theorem identity16923 : scanCanonicalize (H12AffineFastState.compose env16923 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound16923 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env16924 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,8192,1,8233,34,8248,8232,52,8232,0,32,16,3,8192,17,8233,8248,17,8233,8252,8201,37,8200,8233,513]

theorem envBound16924 : H12AffineFastState.Bounded env16924 := by
  intro p hp
  have h : env16924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16923_16924 : H12AffineEnvironment.transform 13 1 env16923 = env16924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env16923 == env16924) = true)

theorem identity16924 : scanCanonicalize (H12AffineFastState.compose env16924 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound16924 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16925 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,553,1,512,34,529,513,52,513,0,32,16,3,553,17,512,529,17,512,533,544,37,545,512,513]

theorem envBound16925 : H12AffineFastState.Bounded env16925 := by
  intro p hp
  have h : env16925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16924_16925 : H12AffineEnvironment.transform 12 553 env16924 = env16925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env16924 == env16925) = true)

theorem identity16925 : scanCanonicalize (H12AffineFastState.compose env16925 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16925 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16926 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,17,41,1,0,34,17,1,52,1,0,32,16,3,41,17,0,17,17,0,21,32,37,33,0,1]

theorem envBound16926 : H12AffineFastState.Bounded env16926 := by
  intro p hp
  have h : env16926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16925_16926 : H12AffineEnvironment.transform 8 0 env16925 = env16926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16925 == env16926) = true)

theorem identity16926 : scanCanonicalize (H12AffineFastState.compose env16926 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound16926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16927 : List Nat := [2,4,8,16,11,17,8,15,0,30,0,17,2,1,0,9,17,1,31,1,0,11,16,3,2,17,0,17,17,0,21,11,14,10,0,1]

theorem envBound16927 : H12AffineFastState.Bounded env16927 := by
  intro p hp
  have h : env16927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16926_16927 : H12AffineEnvironment.transform 4 11 env16926 = env16927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env16926 == env16927) = true)

def env16928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10401,1025,29908,2097152,33,2101328,2114882,8328,64,97666,79130,17665,2111712,75222,73890,257,2188651,2191387,513]

theorem envBound16928 : H12AffineFastState.Bounded env16928 := by
  intro p hp
  have h : env16928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16914_16928 : H12AffineEnvironment.transform 17 10401 env16914 = env16928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16914 == env16928) = true)

def env16929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13509,10401,1025,8660,2097152,33,2101328,2101314,8328,64,75906,79130,4097,2111712,75222,73890,257,2175083,2172187,513]

theorem envBound16929 : H12AffineFastState.Bounded env16929 := by
  intro p hp
  have h : env16929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16928_16929 : H12AffineEnvironment.transform 13 5376 env16928 = env16929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16928 == env16929) = true)

theorem identity16929 : scanCanonicalize (H12AffineFastState.compose env16929 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1025,8540,2097152,33,2101328,2101314,8192,64,75786,79130,4097,2111592,75102,73770,257,2175083,2172187,513]

theorem envBound16930 : H12AffineFastState.Bounded env16930 := by
  intro p hp
  have h : env16930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16929_16930 : H12AffineEnvironment.transform 6 8 env16929 = env16930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16929 == env16930) = true)

theorem identity16930 : scanCanonicalize (H12AffineFastState.compose env16930 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound16930 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1025,8540,12573,33,8525,8543,8192,64,75786,79130,4097,2421,75102,73770,257,65910,70662,513]

theorem envBound16931 : H12AffineFastState.Bounded env16931 := by
  intro p hp
  have h : env16931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16930_16931 : H12AffineEnvironment.transform 20 12573 env16930 = env16931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env16930 == env16931) = true)

theorem identity16931 : scanCanonicalize (H12AffineFastState.compose env16931 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16931 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,13389,10281,1025,8540,12573,33,8525,8543,8192,64,2048,5392,4097,2421,1364,32,257,8572,13324,513]

theorem envBound16932 : H12AffineFastState.Bounded env16932 := by
  intro p hp
  have h : env16932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16931_16932 : H12AffineEnvironment.transform 15 8202 env16931 = env16932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16931 == env16932) = true)

theorem identity16932 : scanCanonicalize (H12AffineFastState.compose env16932 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16932 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,262,5441,2341,1025,80,4113,33,65,83,268,64,2048,5392,4097,2421,1364,32,257,112,5376,513]

theorem envBound16933 : H12AffineFastState.Bounded env16933 := by
  intro p hp
  have h : env16933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16932_16933 : H12AffineEnvironment.transform 12 268 env16932 = env16933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16932 == env16933) = true)

theorem identity16933 : scanCanonicalize (H12AffineFastState.compose env16933 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16933 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16934 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4113,33,17,3,268,16,2048,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound16934 : H12AffineFastState.Bounded env16934 := by
  intro p hp
  have h : env16934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16933_16934 : H12AffineEnvironment.transform 5 16 env16933 = env16934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16933 == env16934) = true)

theorem identity16934 : scanCanonicalize (H12AffineFastState.compose env16934 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound16934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16935 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,48,268,1328,1,262,1313,2341,1025,0,33,33,17,3,268,16,2048,1312,49,2341,1284,32,257,32,1328,513]

theorem envBound16935 : H12AffineFastState.Bounded env16935 := by
  intro p hp
  have h : env16935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16934_16935 : H12AffineEnvironment.transform 11 48 env16934 = env16935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env16934 == env16935) = true)

theorem identity16935 : scanCanonicalize (H12AffineFastState.compose env16935 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16935 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16936 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,48,268,32,1,262,49,2341,273,0,33,33,17,3,268,16,2048,48,49,2341,20,32,257,32,32,513]

theorem envBound16936 : H12AffineFastState.Bounded env16936 := by
  intro p hp
  have h : env16936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16935_16936 : H12AffineEnvironment.transform 9 272 env16935 = env16936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16935 == env16936) = true)

theorem identity16936 : scanCanonicalize (H12AffineFastState.compose env16936 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound16936 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16937 : List Nat := [2,4,8,16,32,16,8,256,292,272,2048,48,268,32,1,262,49,2341,273,0,33,33,17,3,268,16,2048,48,49,2341,20,32,257,32,32,293]

theorem envBound16937 : H12AffineFastState.Bounded env16937 := by
  intro p hp
  have h : env16937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16936_16937 : H12AffineEnvironment.transform 8 292 env16936 = env16937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env16936 == env16937) = true)

theorem identity16937 : scanCanonicalize (H12AffineFastState.compose env16937 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound16937 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16938 : List Nat := [2,4,8,16,32,16,8,256,292,272,277,48,268,32,1,262,49,48,273,0,33,33,17,3,268,16,277,48,49,48,20,32,257,32,32,293]

theorem envBound16938 : H12AffineFastState.Bounded env16938 := by
  intro p hp
  have h : env16938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16937_16938 : H12AffineEnvironment.transform 10 277 env16937 = env16938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env16937 == env16938) = true)

theorem identity16938 : scanCanonicalize (H12AffineFastState.compose env16938 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16938 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16939 : List Nat := [2,4,8,16,32,16,8,36,0,52,49,48,40,32,1,34,49,48,53,0,33,33,17,3,40,16,49,48,49,48,20,32,37,32,32,1]

theorem envBound16939 : H12AffineFastState.Bounded env16939 := by
  intro p hp
  have h : env16939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16938_16939 : H12AffineEnvironment.transform 7 36 env16938 = env16939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16938 == env16939) = true)

theorem identity16939 : scanCanonicalize (H12AffineFastState.compose env16939 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16939 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16940 : List Nat := [2,4,8,16,1,16,8,5,0,21,16,17,9,1,1,3,16,17,20,0,0,0,17,3,9,16,16,17,16,17,20,1,4,1,1,1]

theorem envBound16940 : H12AffineFastState.Bounded env16940 := by
  intro p hp
  have h : env16940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16939_16940 : H12AffineEnvironment.transform 4 1 env16939 = env16940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16939 == env16940) = true)

theorem identity16940 : scanCanonicalize (H12AffineFastState.compose env16940 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16941 : List Nat := [2,4,2,16,1,16,2,5,0,21,16,17,3,1,1,3,16,17,20,0,0,0,17,3,3,16,16,17,16,17,20,1,4,1,1,1]

theorem envBound16941 : H12AffineFastState.Bounded env16941 := by
  intro p hp
  have h : env16941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16940_16941 : H12AffineEnvironment.transform 2 2 env16940 = env16941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16940 == env16941) = true)

theorem identity16941 : scanCanonicalize (H12AffineFastState.compose env16941 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16941 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16942 : List Nat := [2,4,2,1,1,1,2,5,0,4,1,0,3,1,1,3,1,0,5,0,0,0,0,3,3,1,1,0,1,0,5,1,4,1,1,1]

theorem envBound16942 : H12AffineFastState.Bounded env16942 := by
  intro p hp
  have h : env16942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16941_16942 : H12AffineEnvironment.transform 3 1 env16941 = env16942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16941 == env16942) = true)

def env16943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,10401,1025,8661,2097152,33,2101328,2101315,8328,64,75907,79130,4096,2111712,75222,73890,257,2175082,2172186,513]

theorem envBound16943 : H12AffineFastState.Bounded env16943 := by
  intro p hp
  have h : env16943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16928_16943 : H12AffineEnvironment.transform 13 5377 env16928 = env16943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16928 == env16943) = true)

theorem identity16943 : scanCanonicalize (H12AffineFastState.compose env16943 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16943 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env16944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13509,10401,1025,8661,2097152,33,2101328,2101315,8328,64,2049,5528,4096,2111712,1364,32,257,2101480,2098584,513]

theorem envBound16944 : H12AffineFastState.Bounded env16944 := by
  intro p hp
  have h : env16944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16943_16944 : H12AffineEnvironment.transform 15 8322 env16943 = env16944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16943 == env16944) = true)

theorem identity16944 : scanCanonicalize (H12AffineFastState.compose env16944 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16944 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5528,2556,1025,136,2097152,33,2101328,2101315,469,64,2049,5528,4096,2103741,1364,32,257,2101480,2098584,513]

theorem envBound16945 : H12AffineFastState.Bounded env16945 := by
  intro p hp
  have h : env16945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16944_16945 : H12AffineEnvironment.transform 12 349 env16944 = env16945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16944 == env16945) = true)

theorem identity16945 : scanCanonicalize (H12AffineFastState.compose env16945 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound16945 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env16946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5528,2556,1025,136,4297,33,153,138,469,64,2049,5528,4096,2420,1364,32,257,33,5457,513]

theorem envBound16946 : H12AffineFastState.Bounded env16946 := by
  intro p hp
  have h : env16946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16945_16946 : H12AffineEnvironment.transform 20 4297 env16945 = env16946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env16945 == env16946) = true)

theorem identity16946 : scanCanonicalize (H12AffineFastState.compose env16946 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16946 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5393,2421,1025,1,4160,33,16,3,348,64,2049,5393,4096,2420,1364,32,257,33,5457,513]

theorem envBound16947 : H12AffineFastState.Bounded env16947 := by
  intro p hp
  have h : env16947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16946_16947 : H12AffineEnvironment.transform 6 9 env16946 = env16947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16946 == env16947) = true)

theorem identity16947 : scanCanonicalize (H12AffineFastState.compose env16947 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16947 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16948 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4113,33,16,3,269,17,2049,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound16948 : H12AffineFastState.Bounded env16948 := by
  intro p hp
  have h : env16948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16947_16948 : H12AffineEnvironment.transform 5 17 env16947 = env16948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16947 == env16948) = true)

theorem identity16948 : scanCanonicalize (H12AffineFastState.compose env16948 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound16948 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16949 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,268,2048,0,263,2064,2340,1025,1,3344,33,16,3,269,17,2049,2064,3329,2341,1285,32,257,33,2049,513]

theorem envBound16949 : H12AffineFastState.Bounded env16949 := by
  intro p hp
  have h : env16949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16948_16949 : H12AffineEnvironment.transform 11 3329 env16948 = env16949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env16948 == env16949) = true)

theorem identity16949 : scanCanonicalize (H12AffineFastState.compose env16949 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16949 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16950 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,40,2048,0,35,2064,2048,1025,1,3124,33,16,3,41,17,2049,2064,3109,2049,1057,32,37,33,2049,513]

theorem envBound16950 : H12AffineFastState.Bounded env16950 := by
  intro p hp
  have h : env16950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16949_16950 : H12AffineEnvironment.transform 7 36 env16949 = env16950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16949 == env16950) = true)

theorem identity16950 : scanCanonicalize (H12AffineFastState.compose env16950 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16950 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16951 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2048,0,35,2064,2048,52,1,2049,33,16,3,41,17,2049,2064,2064,2049,20,32,37,33,2049,513]

theorem envBound16951 : H12AffineFastState.Bounded env16951 := by
  intro p hp
  have h : env16951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16950_16951 : H12AffineEnvironment.transform 9 53 env16950 = env16951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16950 == env16951) = true)

def env16952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97667,115151,17665,2363457,119043,329730,257,2199998,2191387,63188]

theorem envBound16952 : H12AffineFastState.Bounded env16952 := by
  intro p hp
  have h : env16952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16912_16952 : H12AffineEnvironment.transform 21 272513 env16912 = env16952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16912 == env16952) = true)

theorem identity16952 : scanCanonicalize (H12AffineFastState.compose env16952 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound16952 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272513,62660,41430,8328,64,97667,115151,17665,324821,119043,329730,257,95530,103567,63188]

theorem envBound16953 : H12AffineFastState.Bounded env16953 := by
  intro p hp
  have h : env16953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16952_16953 : H12AffineEnvironment.transform 20 58516 env16952 = env16953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env16952 == env16953) = true)

def env16954 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272513,62612,41350,8328,16,97667,115103,17665,324741,119043,329730,257,95530,103567,63108]

theorem envBound16954 : H12AffineFastState.Bounded env16954 := by
  intro p hp
  have h : env16954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16953_16954 : H12AffineEnvironment.transform 5 16 env16953 = env16954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16953 == env16954) = true)

theorem identity16954 : scanCanonicalize (H12AffineFastState.compose env16954 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound16954 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env16955 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,64808,1025,32769,58516,54697,62612,41350,8328,16,97667,115103,17665,2477,119043,128298,257,95530,103567,63108]

theorem envBound16955 : H12AffineFastState.Bounded env16955 := by
  intro p hp
  have h : env16955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16954_16955 : H12AffineEnvironment.transform 17 64808 env16954 = env16955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env16954 == env16955) = true)

theorem identity16955 : scanCanonicalize (H12AffineFastState.compose env16955 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16955 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env16956 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,64808,1025,32769,58397,54560,62493,41231,8193,16,97546,114966,17665,2340,119043,128298,257,95530,103430,62989]

theorem envBound16956 : H12AffineFastState.Bounded env16956 := by
  intro p hp
  have h : env16956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16955_16956 : H12AffineEnvironment.transform 6 9 env16955 = env16956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16955 == env16956) = true)

theorem identity16956 : scanCanonicalize (H12AffineFastState.compose env16956 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound16956 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env16957 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,65536,5393,10281,1025,21760,12572,33,8476,29710,8193,16,97546,70679,17665,2340,66562,73771,257,95530,82183,8972]

theorem envBound16957 : H12AffineFastState.Bounded env16957 := by
  intro p hp
  have h : env16957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16956_16957 : H12AffineEnvironment.transform 14 21761 env16956 = env16957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env16956 == env16957) = true)

theorem identity16957 : scanCanonicalize (H12AffineFastState.compose env16957 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound16957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16958 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8460,65536,5393,10281,1025,8461,12572,33,8476,3,8193,16,67847,70679,12556,2340,66562,73771,257,65831,79114,8972]

theorem envBound16958 : H12AffineFastState.Bounded env16958 := by
  intro p hp
  have h : env16958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16957_16958 : H12AffineEnvironment.transform 13 13325 env16957 = env16958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env16957 == env16958) = true)

theorem identity16958 : scanCanonicalize (H12AffineFastState.compose env16958 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 14655) := by decide +kernel

theorem selectedBound16958 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16959 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8460,14655,5393,10281,1025,8461,12572,33,8476,3,8193,16,12344,11560,12556,2340,15677,6420,257,14360,3125,8972]

theorem envBound16959 : H12AffineFastState.Bounded env16959 := by
  intro p hp
  have h : env16959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16958_16959 : H12AffineEnvironment.transform 15 14655 env16958 = env16959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14655 env16958 == env16959) = true)

theorem identity16959 : scanCanonicalize (H12AffineFastState.compose env16959 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound16959 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16960 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,1297,4112,2083,5393,6453,1025,4113,0,33,4096,3,4381,16,292,7220,16,2340,3105,6420,257,2308,3125,4624]

theorem envBound16960 : H12AffineFastState.Bounded env16960 := by
  intro p hp
  have h : env16960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16959_16960 : H12AffineEnvironment.transform 12 4380 env16959 = env16960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env16959 == env16960) = true)

theorem identity16960 : scanCanonicalize (H12AffineFastState.compose env16960 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound16960 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env16961 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,2088,1297,2340,2083,3109,1,1025,2341,0,33,2356,3,2089,16,292,1280,16,2340,3105,32,257,2308,3125,2852]

theorem envBound16961 : H12AffineFastState.Bounded env16961 := by
  intro p hp
  have h : env16961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16960_16961 : H12AffineEnvironment.transform 11 2356 env16960 = env16961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env16960 == env16961) = true)

theorem identity16961 : scanCanonicalize (H12AffineFastState.compose env16961 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound16961 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env16962 : List Nat := [2,4,8,16,32,16,9,256,512,548,2048,2356,2088,821,2340,2083,2561,1,549,2341,0,33,2356,3,2089,16,292,804,16,2340,2565,32,257,2308,2577,2852]

theorem envBound16962 : H12AffineFastState.Bounded env16962 := by
  intro p hp
  have h : env16962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16961_16962 : H12AffineEnvironment.transform 9 548 env16961 = env16962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env16961 == env16962) = true)

theorem identity16962 : scanCanonicalize (H12AffineFastState.compose env16962 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound16962 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env16963 : List Nat := [2,4,8,16,32,16,9,47,512,548,2048,2075,2088,538,2059,2083,2561,1,549,2058,0,33,2075,3,2089,16,11,523,16,2059,2565,32,46,2091,2577,2571]

theorem envBound16963 : H12AffineFastState.Bounded env16963 := by
  intro p hp
  have h : env16963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16962_16963 : H12AffineEnvironment.transform 7 47 env16962 = env16963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env16962 == env16963) = true)

theorem identity16963 : scanCanonicalize (H12AffineFastState.compose env16963 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound16963 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env16964 : List Nat := [2,4,8,16,11,16,9,4,512,527,2048,2075,2051,538,2059,2056,2561,1,526,2058,0,10,2075,3,2050,16,11,523,16,2059,2565,11,5,2048,2577,2571]

theorem envBound16964 : H12AffineFastState.Bounded env16964 := by
  intro p hp
  have h : env16964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16963_16964 : H12AffineEnvironment.transform 4 11 env16963 = env16964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env16963 == env16964) = true)

theorem identity16964 : scanCanonicalize (H12AffineFastState.compose env16964 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16964 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16965 : List Nat := [2,4,8,16,11,16,9,4,512,527,0,27,3,538,11,8,513,1,526,10,0,10,27,3,2,16,11,523,16,11,517,11,5,0,529,523]

theorem envBound16965 : H12AffineFastState.Bounded env16965 := by
  intro p hp
  have h : env16965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16964_16965 : H12AffineEnvironment.transform 10 0 env16964 = env16965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16964 == env16965) = true)

theorem identity16965 : scanCanonicalize (H12AffineFastState.compose env16965 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound16965 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16966 : List Nat := [2,4,8,16,11,16,9,4,5,10,0,27,3,31,11,8,4,1,11,10,0,10,27,3,2,16,11,14,16,11,0,11,5,0,20,14]

theorem envBound16966 : H12AffineFastState.Bounded env16966 := by
  intro p hp
  have h : env16966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16965_16966 : H12AffineEnvironment.transform 8 5 env16965 = env16966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env16965 == env16966) = true)

theorem identity16966 : scanCanonicalize (H12AffineFastState.compose env16966 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16966 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env16967 : List Nat := [2,4,3,16,0,16,2,4,5,1,0,16,3,20,0,3,4,1,0,1,0,1,16,3,2,16,0,5,16,0,0,0,5,0,20,5]

theorem envBound16967 : H12AffineFastState.Bounded env16967 := by
  intro p hp
  have h : env16967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16966_16967 : H12AffineEnvironment.transform 2 3 env16966 = env16967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16966 == env16967) = true)

theorem identity16967 : scanCanonicalize (H12AffineFastState.compose env16967 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16967 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16968 : List Nat := [2,4,3,1,0,1,2,4,5,1,0,1,3,5,0,3,4,1,0,1,0,1,1,3,2,1,0,5,1,0,0,0,5,0,5,5]

theorem envBound16968 : H12AffineFastState.Bounded env16968 := by
  intro p hp
  have h : env16968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16967_16968 : H12AffineEnvironment.transform 3 1 env16967 = env16968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16967 == env16968) = true)

theorem identity16968 : scanCanonicalize (H12AffineFastState.compose env16968 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound16968 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16969 : List Nat := [1,4,0,1,0,1,1,4,5,1,0,1,0,5,0,0,4,1,0,1,0,1,1,0,1,1,0,5,1,0,0,0,5,0,5,5]

theorem envBound16969 : H12AffineFastState.Bounded env16969 := by
  intro p hp
  have h : env16969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16968_16969 : H12AffineEnvironment.transform 0 1 env16968 = env16969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env16968 == env16969) = true)

def env16970 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272513,62613,41351,8328,17,97667,115102,17665,324740,119043,329730,257,95530,103567,63109]

theorem envBound16970 : H12AffineFastState.Bounded env16970 := by
  intro p hp
  have h : env16970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16953_16970 : H12AffineEnvironment.transform 5 17 env16953 = env16970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16953 == env16970) = true)

theorem identity16970 : scanCanonicalize (H12AffineFastState.compose env16970 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound16970 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env16971 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,122146,1025,32769,58516,128419,62613,41351,8328,17,97667,115102,17665,76198,119043,54560,257,95530,103567,63109]

theorem envBound16971 : H12AffineFastState.Bounded env16971 := by
  intro p hp
  have h : env16971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16970_16971 : H12AffineEnvironment.transform 17 122146 env16970 = env16971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env16970 == env16971) = true)

theorem identity16971 : scanCanonicalize (H12AffineFastState.compose env16971 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound16971 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env16972 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,62851,49168,10401,1025,32769,58516,32,62613,41351,8328,17,34816,13341,17665,56357,9344,54560,257,32937,24844,63109]

theorem envBound16972 : H12AffineFastState.Bounded env16972 := by
  intro p hp
  have h : env16972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16971_16972 : H12AffineEnvironment.transform 15 62851 env16971 = env16972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env16971 == env16972) = true)

theorem identity16972 : scanCanonicalize (H12AffineFastState.compose env16972 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16972 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env16973 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,21647,24860,10401,1025,8461,17816,32,21913,139,8328,17,10508,13341,17665,32041,9344,29740,257,8613,24844,22409]

theorem envBound16973 : H12AffineFastState.Bounded env16973 := by
  intro p hp
  have h : env16973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16972_16973 : H12AffineEnvironment.transform 14 8460 env16972 = env16973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16972 == env16973) = true)

theorem identity16973 : scanCanonicalize (H12AffineFastState.compose env16973 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound16973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16974 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8460,263,13460,10401,1025,8461,4112,32,17,139,8328,17,10508,13341,4233,10401,9344,8612,257,8613,13444,513]

theorem envBound16974 : H12AffineFastState.Bounded env16974 := by
  intro p hp
  have h : env16974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16973_16974 : H12AffineEnvironment.transform 13 5512 env16973 = env16974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env16973 == env16974) = true)

theorem identity16974 : scanCanonicalize (H12AffineFastState.compose env16974 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound16974 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16975 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,136,263,5392,2341,1025,137,4112,32,17,139,268,17,2184,5529,4233,2341,1284,32,257,33,5376,513]

theorem envBound16975 : H12AffineFastState.Bounded env16975 := by
  intro p hp
  have h : env16975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16974_16975 : H12AffineEnvironment.transform 12 388 env16974 = env16975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env16974 == env16975) = true)

theorem identity16975 : scanCanonicalize (H12AffineFastState.compose env16975 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16975 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env16976 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1025,1,4112,32,17,3,268,17,2048,5393,4097,2341,1284,32,257,33,5376,513]

theorem envBound16976 : H12AffineFastState.Bounded env16976 := by
  intro p hp
  have h : env16976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16975_16976 : H12AffineEnvironment.transform 6 8 env16975 = env16976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16975 == env16976) = true)

theorem identity16976 : scanCanonicalize (H12AffineFastState.compose env16976 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound16976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16977 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1045,268,277,0,263,261,2341,1025,1,1029,32,17,3,268,17,2048,260,1044,2341,1284,32,257,33,277,513]

theorem envBound16977 : H12AffineFastState.Bounded env16977 := by
  intro p hp
  have h : env16977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16976_16977 : H12AffineEnvironment.transform 11 1045 env16976 = env16977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env16976 == env16977) = true)

theorem identity16977 : scanCanonicalize (H12AffineFastState.compose env16977 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16978 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,1045,268,277,0,263,261,2341,1025,1,1029,32,17,3,268,17,2048,260,1044,2341,1284,32,257,33,277,0]

theorem envBound16978 : H12AffineFastState.Bounded env16978 := by
  intro p hp
  have h : env16978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16977_16978 : H12AffineEnvironment.transform 8 1 env16977 = env16978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16977 == env16978) = true)

theorem identity16978 : scanCanonicalize (H12AffineFastState.compose env16978 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16978 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16979 : List Nat := [2,4,8,16,32,17,8,37,1,1024,2048,1045,41,48,0,34,32,2048,1025,1,1029,32,17,3,41,17,2048,33,1044,2048,1057,32,36,33,48,0]

theorem envBound16979 : H12AffineFastState.Bounded env16979 := by
  intro p hp
  have h : env16979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16978_16979 : H12AffineEnvironment.transform 7 37 env16978 = env16979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16978 == env16979) = true)

theorem identity16979 : scanCanonicalize (H12AffineFastState.compose env16979 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16979 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16980 : List Nat := [2,4,8,16,0,17,8,5,1,1024,2048,1045,9,16,0,2,0,2048,1025,1,1029,0,17,3,9,17,2048,1,1044,2048,1025,0,4,1,16,0]

theorem envBound16980 : H12AffineFastState.Bounded env16980 := by
  intro p hp
  have h : env16980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16979_16980 : H12AffineEnvironment.transform 4 0 env16979 = env16980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16979 == env16980) = true)

theorem identity16980 : scanCanonicalize (H12AffineFastState.compose env16980 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16980 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16981 : List Nat := [2,4,8,16,0,17,8,5,1,20,2048,1,9,16,0,2,0,2048,21,1,17,0,17,3,9,17,2048,1,0,2048,21,0,4,1,16,0]

theorem envBound16981 : H12AffineFastState.Bounded env16981 := by
  intro p hp
  have h : env16981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16980_16981 : H12AffineEnvironment.transform 9 20 env16980 = env16981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16980 == env16981) = true)

theorem identity16981 : scanCanonicalize (H12AffineFastState.compose env16981 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16981 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16982 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,1,9,16,0,2,0,1,21,1,17,0,17,3,9,17,1,1,0,1,21,0,4,1,16,0]

theorem envBound16982 : H12AffineFastState.Bounded env16982 := by
  intro p hp
  have h : env16982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16981_16982 : H12AffineEnvironment.transform 10 1 env16981 = env16982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16981 == env16982) = true)

theorem identity16982 : scanCanonicalize (H12AffineFastState.compose env16982 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16983 : List Nat := [2,4,2,16,0,17,2,5,1,20,1,1,3,16,0,2,0,1,21,1,17,0,17,3,3,17,1,1,0,1,21,0,4,1,16,0]

theorem envBound16983 : H12AffineFastState.Bounded env16983 := by
  intro p hp
  have h : env16983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16982_16983 : H12AffineEnvironment.transform 2 2 env16982 = env16983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16982 == env16983) = true)

def env16984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543747,115151,17664,2363456,119042,4268163,257,2199999,2191386,63189]

theorem envBound16984 : H12AffineFastState.Bounded env16984 := by
  intro p hp
  have h : env16984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16911_16984 : H12AffineEnvironment.transform 22 2101329 env16911 = env16984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env16911 == env16984) = true)

def env16985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97667,115151,17664,2363456,119042,329731,257,2199999,2191386,63189]

theorem envBound16985 : H12AffineFastState.Bounded env16985 := by
  intro p hp
  have h : env16985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16984_16985 : H12AffineEnvironment.transform 21 272512 env16984 = env16985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16984 == env16985) = true)

def env16986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,97547,115015,17664,2363456,119042,329731,257,2199863,2191386,63069]

theorem envBound16986 : H12AffineFastState.Bounded env16986 := by
  intro p hp
  have h : env16986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16985_16986 : H12AffineEnvironment.transform 6 8 env16985 = env16986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16985 == env16986) = true)

def env16987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21762,8192,64,97547,115015,17664,262144,119042,329731,257,98679,90202,63069]

theorem envBound16987 : H12AffineFastState.Bounded env16987 := by
  intro p hp
  have h : env16987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16986_16987 : H12AffineEnvironment.transform 20 4160 env16986 = env16987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16986 == env16987) = true)

theorem identity16987 : scanCanonicalize (H12AffineFastState.compose env16987 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound16987 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1025,32769,4160,62589,17,21762,8192,64,97547,115015,17664,56437,119042,119926,257,98679,90202,63069]

theorem envBound16988 : H12AffineFastState.Bounded env16988 := by
  intro p hp
  have h : env16988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16987_16988 : H12AffineEnvironment.transform 17 56437 env16987 = env16988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env16987 == env16988) = true)

theorem identity16988 : scanCanonicalize (H12AffineFastState.compose env16988 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound16988 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env16989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,49168,56437,1025,32769,4160,62589,17,21762,8192,64,64605,16401,17664,56437,20564,21792,257,33,57612,63069]

theorem envBound16989 : H12AffineFastState.Bounded env16989 := by
  intro p hp
  have h : env16989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16988_16989 : H12AffineEnvironment.transform 15 33110 env16988 = env16989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env16988 == env16989) = true)

theorem identity16989 : scanCanonicalize (H12AffineFastState.compose env16989 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound16989 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,30042,13340,10361,1025,29709,4160,113,17,21762,8192,64,2129,16401,17664,10361,20564,21792,257,33,5376,593]

theorem envBound16990 : H12AffineFastState.Bounded env16990 := by
  intro p hp
  have h : env16990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16989_16990 : H12AffineEnvironment.transform 14 29708 env16989 = env16990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env16989 == env16990) = true)

theorem identity16990 : scanCanonicalize (H12AffineFastState.compose env16990 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound16990 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env16991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,8203,13340,10361,1025,8540,4160,113,17,83,8192,64,2129,5440,4177,10361,1285,113,257,33,5376,593]

theorem envBound16991 : H12AffineFastState.Bounded env16991 := by
  intro p hp
  have h : env16991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16990_16991 : H12AffineEnvironment.transform 13 5457 env16990 = env16991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env16990 == env16991) = true)

theorem identity16991 : scanCanonicalize (H12AffineFastState.compose env16991 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound16991 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5457,293,115,5220,2049,1025,292,4160,113,17,83,120,64,2129,5440,4177,2049,1285,113,257,33,5376,593]

theorem envBound16992 : H12AffineFastState.Bounded env16992 := by
  intro p hp
  have h : env16992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16991_16992 : H12AffineEnvironment.transform 12 120 env16991 = env16992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env16991 == env16992) = true)

theorem identity16992 : scanCanonicalize (H12AffineFastState.compose env16992 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound16992 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env16993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,120,2048,293,115,2357,2049,1025,292,3345,113,17,83,120,64,2129,2065,3328,2049,1285,113,257,33,2129,593]

theorem envBound16993 : H12AffineFastState.Bounded env16993 := by
  intro p hp
  have h : env16993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16992_16993 : H12AffineEnvironment.transform 11 3409 env16992 = env16993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env16992 == env16993) = true)

theorem identity16993 : scanCanonicalize (H12AffineFastState.compose env16993 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16993 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env16994 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3188,120,2048,0,115,2064,2049,1025,1,3124,113,17,83,120,64,2129,2065,3109,2049,1056,113,36,33,2129,593]

theorem envBound16994 : H12AffineFastState.Bounded env16994 := by
  intro p hp
  have h : env16994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16993_16994 : H12AffineEnvironment.transform 7 37 env16993 = env16994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16993 == env16994) = true)

theorem identity16994 : scanCanonicalize (H12AffineFastState.compose env16994 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16994 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env16995 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,40,2048,0,35,2064,2049,1025,1,3124,33,17,3,40,16,2049,2065,3109,2049,1056,33,36,33,2049,513]

theorem envBound16995 : H12AffineFastState.Bounded env16995 := by
  intro p hp
  have h : env16995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16994_16995 : H12AffineEnvironment.transform 5 16 env16994 = env16995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16994 == env16995) = true)

theorem identity16995 : scanCanonicalize (H12AffineFastState.compose env16995 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound16995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16996 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1060,0,40,1060,0,35,1076,1061,1025,1,16,33,17,3,40,16,1061,1077,1,1061,1056,33,36,33,1061,513]

theorem envBound16996 : H12AffineFastState.Bounded env16996 := by
  intro p hp
  have h : env16996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16995_16996 : H12AffineEnvironment.transform 10 1060 env16995 = env16996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env16995 == env16996) = true)

theorem identity16996 : scanCanonicalize (H12AffineFastState.compose env16996 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound16996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16997 : List Nat := [2,4,8,16,32,16,8,37,16,1024,1060,0,40,1060,0,35,1076,1061,1025,1,16,33,17,3,40,16,1061,1077,1,1061,1056,33,36,33,1061,17]

theorem envBound16997 : H12AffineFastState.Bounded env16997 := by
  intro p hp
  have h : env16997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16996_16997 : H12AffineEnvironment.transform 8 16 env16996 = env16997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env16996 == env16997) = true)

theorem identity16997 : scanCanonicalize (H12AffineFastState.compose env16997 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound16997 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16998 : List Nat := [2,4,8,16,32,16,8,37,16,36,0,0,40,0,0,35,16,1,37,1,16,33,17,3,40,16,1,17,1,1,4,33,36,33,1,17]

theorem envBound16998 : H12AffineFastState.Bounded env16998 := by
  intro p hp
  have h : env16998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16997_16998 : H12AffineEnvironment.transform 9 36 env16997 = env16998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env16997 == env16998) = true)

def env16999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,16,21763,8192,64,97547,115015,17664,262145,119042,329731,257,98678,90203,63069]

theorem envBound16999 : H12AffineFastState.Bounded env16999 := by
  intro p hp
  have h : env16999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16986_16999 : H12AffineEnvironment.transform 20 4161 env16986 = env16999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16986 == env16999) = true)

theorem identity16999 : scanCanonicalize (H12AffineFastState.compose env16999 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound16999 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,4161,272392,16,21763,8192,64,97547,79131,17664,262145,75102,329731,257,95530,90203,513]

theorem envBound17000 : H12AffineFastState.Bounded env17000 := by
  intro p hp
  have h : env17000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16999_17000 : H12AffineEnvironment.transform 14 29788 env16999 = env17000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env16999 == env17000) = true)

theorem identity17000 : scanCanonicalize (H12AffineFastState.compose env17000 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound17000 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21591,13388,262144,1025,29789,4161,272392,16,21763,8192,64,10588,24908,17664,262145,28937,285780,257,8573,13324,513]

theorem envBound17001 : H12AffineFastState.Bounded env17001 := by
  intro p hp
  have h : env17001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17000_17001 : H12AffineEnvironment.transform 15 21591 env17000 = env17001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env17000 == env17001) = true)

theorem identity17001 : scanCanonicalize (H12AffineFastState.compose env17001 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17001 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21591,5392,262144,1025,21761,4161,264532,16,21763,348,64,2048,16400,17664,262145,20565,285780,257,33,5456,513]

theorem envBound17002 : H12AffineFastState.Bounded env17002 := by
  intro p hp
  have h : env17002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17001_17002 : H12AffineEnvironment.transform 12 348 env17001 = env17002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17001 == env17002) = true)

theorem identity17002 : scanCanonicalize (H12AffineFastState.compose env17002 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound17002 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21591,5392,2420,1025,21761,4161,32,16,21763,348,64,2048,16400,17664,2421,20565,21792,257,33,5456,513]

theorem envBound17003 : H12AffineFastState.Bounded env17003 := by
  intro p hp
  have h : env17003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17002_17003 : H12AffineEnvironment.transform 17 2420 env17002 = env17003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env17002 == env17003) = true)

theorem identity17003 : scanCanonicalize (H12AffineFastState.compose env17003 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17003 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,1296,1095,5392,2420,1025,1297,4161,32,16,1299,348,64,2048,4096,5392,2421,69,1328,257,33,5456,513]

theorem envBound17004 : H12AffineFastState.Bounded env17004 := by
  intro p hp
  have h : env17004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17003_17004 : H12AffineEnvironment.transform 13 4112 env17003 = env17004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17003 == env17004) = true)

theorem identity17004 : scanCanonicalize (H12AffineFastState.compose env17004 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound17004 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,348,4112,1296,1095,5392,1076,1025,1297,4161,32,16,1299,348,64,1344,4096,5392,1077,69,1328,257,33,5456,513]

theorem envBound17005 : H12AffineFastState.Bounded env17005 := by
  intro p hp
  have h : env17005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17004_17005 : H12AffineEnvironment.transform 10 1344 env17004 = env17005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env17004 == env17005) = true)

theorem identity17005 : scanCanonicalize (H12AffineFastState.compose env17005 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17005 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17006 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,4096,41,4112,1125,1095,5221,1076,1025,1124,4161,32,16,1126,41,64,1077,4096,5221,1077,69,1093,116,33,5157,513]

theorem envBound17006 : H12AffineFastState.Bounded env17006 := by
  intro p hp
  have h : env17006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17005_17006 : H12AffineEnvironment.transform 7 117 env17005 = env17006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17005 == env17006) = true)

theorem identity17006 : scanCanonicalize (H12AffineFastState.compose env17006 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound17006 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env17007 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,1141,41,1125,1125,1095,16,1076,1025,1124,1076,32,16,1126,41,64,1077,1141,16,1077,69,1093,116,33,80,513]

theorem envBound17007 : H12AffineFastState.Bounded env17007 := by
  intro p hp
  have h : env17007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17006_17007 : H12AffineEnvironment.transform 11 1141 env17006 = env17007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env17006 == env17007) = true)

theorem identity17007 : scanCanonicalize (H12AffineFastState.compose env17007 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound17007 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17008 : List Nat := [2,4,8,16,32,64,8,117,512,100,81,17,41,1,1,35,16,80,101,0,80,32,16,2,41,64,81,17,16,81,69,33,116,33,80,513]

theorem envBound17008 : H12AffineFastState.Bounded env17008 := by
  intro p hp
  have h : env17008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17007_17008 : H12AffineEnvironment.transform 9 100 env17007 = env17008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env17007 == env17008) = true)

theorem identity17008 : scanCanonicalize (H12AffineFastState.compose env17008 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound17008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17009 : List Nat := [2,4,8,16,32,64,8,117,49,100,81,17,41,1,1,35,16,80,101,0,80,32,16,2,41,64,81,17,16,81,69,33,116,33,80,48]

theorem envBound17009 : H12AffineFastState.Bounded env17009 := by
  intro p hp
  have h : env17009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17008_17009 : H12AffineEnvironment.transform 8 49 env17008 = env17009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env17008 == env17009) = true)

theorem identity17009 : scanCanonicalize (H12AffineFastState.compose env17009 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17010 : List Nat := [2,4,8,1,32,64,8,100,32,100,64,0,41,1,1,35,1,65,101,0,65,32,1,2,41,64,64,0,1,64,69,33,101,33,65,33]

theorem envBound17010 : H12AffineFastState.Bounded env17010 := by
  intro p hp
  have h : env17010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17009_17010 : H12AffineEnvironment.transform 3 1 env17009 = env17010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17009 == env17010) = true)

theorem identity17010 : scanCanonicalize (H12AffineFastState.compose env17010 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound17010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17011 : List Nat := [2,4,8,1,32,32,8,4,32,4,32,0,41,1,1,35,1,33,5,0,33,32,1,2,41,32,32,0,1,32,37,33,5,33,33,33]

theorem envBound17011 : H12AffineFastState.Bounded env17011 := by
  intro p hp
  have h : env17011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17010_17011 : H12AffineEnvironment.transform 5 32 env17010 = env17011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env17010 == env17011) = true)

theorem identity17011 : scanCanonicalize (H12AffineFastState.compose env17011 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17011 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17012 : List Nat := [2,4,8,1,1,1,8,4,1,4,1,0,8,1,1,2,1,0,5,0,0,1,1,2,8,1,1,0,1,1,4,0,5,0,0,0]

theorem envBound17012 : H12AffineFastState.Bounded env17012 := by
  intro p hp
  have h : env17012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17011_17012 : H12AffineEnvironment.transform 4 1 env17011 = env17012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17011 == env17012) = true)

def env17013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,97546,115014,17664,2363456,119042,329731,257,2199862,2191386,63068]

theorem envBound17013 : H12AffineFastState.Bounded env17013 := by
  intro p hp
  have h : env17013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16985_17013 : H12AffineEnvironment.transform 6 9 env16985 = env17013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16985 == env17013) = true)

def env17014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21762,8193,64,97546,115014,17664,262144,119042,329731,257,98678,90202,63068]

theorem envBound17014 : H12AffineFastState.Bounded env17014 := by
  intro p hp
  have h : env17014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17013_17014 : H12AffineEnvironment.transform 20 4160 env17013 = env17014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17013 == env17014) = true)

theorem identity17014 : scanCanonicalize (H12AffineFastState.compose env17014 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound17014 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,4160,21793,17,21762,8193,64,97546,115014,17664,32040,119042,95531,257,98678,90202,63068]

theorem envBound17015 : H12AffineFastState.Bounded env17015 := by
  intro p hp
  have h : env17015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17014_17015 : H12AffineEnvironment.transform 17 32040 env17014 = env17015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env17014 == env17015) = true)

theorem identity17015 : scanCanonicalize (H12AffineFastState.compose env17015 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound17015 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8494,49168,32040,1025,32769,4160,21793,17,21762,8193,64,23588,57448,17664,32040,61484,21509,257,41048,16756,63068]

theorem envBound17016 : H12AffineFastState.Bounded env17016 := by
  intro p hp
  have h : env17016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17015_17016 : H12AffineEnvironment.transform 15 8494 env17015 = env17016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env17015 == env17016) = true)

theorem identity17016 : scanCanonicalize (H12AffineFastState.compose env17016 (packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound17016 : packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env17017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8494,24860,32040,1025,8461,4160,21793,17,21762,8193,64,23588,16740,17664,32040,20768,21509,257,340,16756,22352]

theorem envBound17017 : H12AffineFastState.Bounded env17017 := by
  intro p hp
  have h : env17017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17016_17017 : H12AffineEnvironment.transform 14 8460 env17016 = env17017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env17016 == env17017) = true)

theorem identity17017 : scanCanonicalize (H12AffineFastState.compose env17017 (packedSelected [0,3,4,5,7,10,12,15,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17017 : packedSelected [0,3,4,5,7,10,12,15,22] rootPS < 2^1333 := by decide +kernel

def env17018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,35,16401,23589,1025,0,4160,21793,17,21762,268,64,23588,16740,17664,23589,20768,21509,257,340,16756,22352]

theorem envBound17018 : H12AffineFastState.Bounded env17018 := by
  intro p hp
  have h : env17018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17017_17018 : H12AffineEnvironment.transform 12 269 env17017 = env17018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17017 == env17018) = true)

theorem identity17018 : scanCanonicalize (H12AffineFastState.compose env17018 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17018 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,1,35,5440,2420,1025,0,4160,112,17,83,268,64,2421,5173,4177,2420,1137,340,257,340,5157,513]

theorem envBound17019 : H12AffineFastState.Bounded env17019 := by
  intro p hp
  have h : env17019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17018_17019 : H12AffineEnvironment.transform 13 5457 env17018 = env17019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17018 == env17019) = true)

theorem identity17019 : scanCanonicalize (H12AffineFastState.compose env17019 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17019 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17020 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5156,1,35,5173,2049,1025,0,4160,112,17,83,121,64,2048,5173,4177,2049,1137,33,116,33,5157,513]

theorem envBound17020 : H12AffineFastState.Bounded env17020 := by
  intro p hp
  have h : env17020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17019_17020 : H12AffineEnvironment.transform 7 117 env17019 = env17020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17019 == env17020) = true)

theorem identity17020 : scanCanonicalize (H12AffineFastState.compose env17020 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17020 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env17021 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4112,1,35,4097,2049,53,0,4160,112,17,83,121,64,2048,4097,4177,2049,69,33,116,33,4113,513]

theorem envBound17021 : H12AffineFastState.Bounded env17021 := by
  intro p hp
  have h : env17021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17020_17021 : H12AffineEnvironment.transform 9 52 env17020 = env17021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17020 == env17021) = true)

def env17022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,16,21763,8193,64,97546,115014,17664,262145,119042,329731,257,98679,90203,63068]

theorem envBound17022 : H12AffineFastState.Bounded env17022 := by
  intro p hp
  have h : env17022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17013_17022 : H12AffineEnvironment.transform 20 4161 env17013 = env17022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17013 == env17022) = true)

theorem identity17022 : scanCanonicalize (H12AffineFastState.compose env17022 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17022 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,262144,1025,32769,4161,272393,16,3,8193,64,75786,103494,4096,262145,99330,329731,257,98679,79195,41820]

theorem envBound17023 : H12AffineFastState.Bounded env17023 := by
  intro p hp
  have h : env17023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17022_17023 : H12AffineEnvironment.transform 13 5376 env17022 = env17023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17022 == env17023) = true)

theorem identity17023 : scanCanonicalize (H12AffineFastState.compose env17023 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound17023 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env17024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10361,1025,32769,4161,112,16,3,8193,64,75786,103494,4096,10360,99330,73850,257,98679,79195,41820]

theorem envBound17024 : H12AffineFastState.Bounded env17024 := by
  intro p hp
  have h : env17024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17023_17024 : H12AffineEnvironment.transform 17 10361 env17023 = env17024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env17023 == env17024) = true)

theorem identity17024 : scanCanonicalize (H12AffineFastState.compose env17024 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17024 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env17025 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,32768,65536,37941,10361,1025,32769,4161,112,16,3,8193,64,75786,103494,4096,10360,99330,73850,36,98386,78974,41593]

theorem envBound17025 : H12AffineFastState.Bounded env17025 := by
  intro p hp
  have h : env17025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17024_17025 : H12AffineEnvironment.transform 7 37 env17024 = env17025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17024 == env17025) = true)

theorem identity17025 : scanCanonicalize (H12AffineFastState.compose env17025 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound17025 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env17026 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,32768,32802,37941,10361,1025,32769,4161,112,16,3,8193,64,43048,5220,4096,10360,1056,41048,36,112,46172,41593]

theorem envBound17026 : H12AffineFastState.Bounded env17026 := by
  intro p hp
  have h : env17026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17025_17026 : H12AffineEnvironment.transform 15 32802 env17025 = env17026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env17025 == env17026) = true)

theorem identity17026 : scanCanonicalize (H12AffineFastState.compose env17026 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound17026 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env17027 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,8233,8203,13340,10361,1025,8232,4161,112,16,3,8193,64,2049,5220,4096,10360,1056,113,36,112,5237,592]

theorem envBound17027 : H12AffineFastState.Bounded env17027 := by
  intro p hp
  have h : env17027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17026_17027 : H12AffineEnvironment.transform 14 8233 env17026 = env17027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17026 == env17027) = true)

theorem identity17027 : scanCanonicalize (H12AffineFastState.compose env17027 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17027 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env17028 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5157,81,115,5220,2049,1025,80,4161,112,16,3,121,64,2049,5220,4096,2048,1056,113,36,112,5237,592]

theorem envBound17028 : H12AffineFastState.Bounded env17028 := by
  intro p hp
  have h : env17028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17027_17028 : H12AffineEnvironment.transform 12 120 env17027 = env17028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17027 == env17028) = true)

def env17029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97666,115151,17664,2363456,119042,329730,257,2199999,2191386,63189]

theorem envBound17029 : H12AffineFastState.Bounded env17029 := by
  intro p hp
  have h : env17029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16984_17029 : H12AffineEnvironment.transform 21 272513 env16984 = env17029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16984 == env17029) = true)

theorem identity17029 : scanCanonicalize (H12AffineFastState.compose env17029 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound17029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272513,17,21762,8328,64,97666,115151,17664,262144,119042,329730,257,98815,90202,63189]

theorem envBound17030 : H12AffineFastState.Bounded env17030 := by
  intro p hp
  have h : env17030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17029_17030 : H12AffineEnvironment.transform 20 4160 env17029 = env17030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17029 == env17030) = true)

def env17031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21762,8192,64,97546,115015,17664,262144,119042,329730,257,98679,90202,63069]

theorem envBound17031 : H12AffineFastState.Bounded env17031 := by
  intro p hp
  have h : env17031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17030_17031 : H12AffineEnvironment.transform 6 8 env17030 = env17031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17030 == env17031) = true)

theorem identity17031 : scanCanonicalize (H12AffineFastState.compose env17031 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound17031 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1025,32769,4160,62588,17,21762,8192,64,97546,115015,17664,56437,119042,119927,257,98679,90202,63069]

theorem envBound17032 : H12AffineFastState.Bounded env17032 := by
  intro p hp
  have h : env17032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17031_17032 : H12AffineEnvironment.transform 17 56437 env17031 = env17032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env17031 == env17032) = true)

theorem identity17032 : scanCanonicalize (H12AffineFastState.compose env17032 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound17032 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,5393,2420,1025,21760,4160,8573,17,21762,8192,64,97546,70726,17664,2420,66563,65910,257,87158,90202,9052]

theorem envBound17033 : H12AffineFastState.Bounded env17033 := by
  intro p hp
  have h : env17033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17032_17033 : H12AffineEnvironment.transform 14 21761 env17032 = env17033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env17032 == env17033) = true)

theorem identity17033 : scanCanonicalize (H12AffineFastState.compose env17033 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17033 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env17034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,5393,2420,1025,21760,4160,8573,17,21762,8192,64,23809,13389,17664,2420,9224,8573,257,29821,16465,9052]

theorem envBound17034 : H12AffineFastState.Bounded env17034 := by
  intro p hp
  have h : env17034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17033_17034 : H12AffineEnvironment.transform 15 8203 env17033 = env17034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17033 == env17034) = true)

def env17035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21762,8193,64,97547,115014,17664,262144,119042,329730,257,98678,90202,63068]

theorem envBound17035 : H12AffineFastState.Bounded env17035 := by
  intro p hp
  have h : env17035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17030_17035 : H12AffineEnvironment.transform 6 9 env17030 = env17035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17030 == env17035) = true)

theorem identity17035 : scanCanonicalize (H12AffineFastState.compose env17035 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound17035 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,4160,21792,17,21762,8193,64,97547,115014,17664,32040,119042,95530,257,98678,90202,63068]

theorem envBound17036 : H12AffineFastState.Bounded env17036 := by
  intro p hp
  have h : env17036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17035_17036 : H12AffineEnvironment.transform 17 32040 env17035 = env17036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env17035 == env17036) = true)

theorem identity17036 : scanCanonicalize (H12AffineFastState.compose env17036 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound17036 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32802,49168,32040,1025,32769,4160,21792,17,21762,8193,64,64809,16740,17664,32040,20768,62728,257,340,57464,63068]

theorem envBound17037 : H12AffineFastState.Bounded env17037 := by
  intro p hp
  have h : env17037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17036_17037 : H12AffineEnvironment.transform 15 32802 env17036 = env17037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env17036 == env17037) = true)

theorem identity17037 : scanCanonicalize (H12AffineFastState.compose env17037 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,18,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17037 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,18,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,32802,49168,23668,1025,32769,4160,21792,17,21762,349,64,56437,16740,17664,23668,20768,54356,257,340,49444,55040]

theorem envBound17038 : H12AffineFastState.Bounded env17038 := by
  intro p hp
  have h : env17038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17037_17038 : H12AffineEnvironment.transform 12 348 env17037 = env17038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17037 == env17038) = true)

theorem identity17038 : scanCanonicalize (H12AffineFastState.compose env17038 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17038 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17039 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,32802,49168,23668,1025,32769,4160,21589,17,21623,40,64,56437,16401,17525,23668,20565,54356,116,33,49233,54901]

theorem envBound17039 : H12AffineFastState.Bounded env17039 := by
  intro p hp
  have h : env17039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17038_17039 : H12AffineEnvironment.transform 7 117 env17038 = env17039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17038 == env17039) = true)

theorem identity17039 : scanCanonicalize (H12AffineFastState.compose env17039 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound17039 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env17040 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21620,21590,5220,23668,1025,21621,4160,21589,17,21623,40,64,2049,16401,17525,23668,20565,32,116,33,5157,513]

theorem envBound17040 : H12AffineFastState.Bounded env17040 := by
  intro p hp
  have h : env17040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17039_17040 : H12AffineEnvironment.transform 14 21620 env17039 = env17040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env17039 == env17040) = true)

theorem identity17040 : scanCanonicalize (H12AffineFastState.compose env17040 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17040 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17041 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,4113,1125,1095,5220,3173,1025,1124,4160,1092,17,1126,40,64,2049,4096,5220,3173,68,32,116,33,5157,513]

theorem envBound17041 : H12AffineFastState.Bounded env17041 := by
  intro p hp
  have h : env17041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17040_17041 : H12AffineEnvironment.transform 13 4113 env17040 = env17041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17040 == env17041) = true)

theorem identity17041 : scanCanonicalize (H12AffineFastState.compose env17041 (packedSelected [0,1,2,3,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3589) := by decide +kernel

theorem selectedBound17041 : packedSelected [0,1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17042 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3589,41,3604,1125,1095,2657,3173,1025,1124,3653,1092,17,1126,40,64,2049,3589,2657,3173,68,32,116,33,2592,513]

theorem envBound17042 : H12AffineFastState.Bounded env17042 := by
  intro p hp
  have h : env17042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17041_17042 : H12AffineEnvironment.transform 11 3589 env17041 = env17042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3589 env17041 == env17042) = true)

theorem identity17042 : scanCanonicalize (H12AffineFastState.compose env17042 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound17042 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env17043 : List Nat := [2,4,8,16,32,64,9,117,512,1024,544,1061,41,1076,1125,1095,65,1605,1025,1124,1125,1092,17,1126,40,64,545,1061,65,1605,68,32,116,33,0,513]

theorem envBound17043 : H12AffineFastState.Bounded env17043 := by
  intro p hp
  have h : env17043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17042_17043 : H12AffineEnvironment.transform 10 544 env17042 = env17043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env17042 == env17043) = true)

theorem identity17043 : scanCanonicalize (H12AffineFastState.compose env17043 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound17043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17044 : List Nat := [2,4,8,16,32,64,9,117,113,1024,81,1061,41,1076,1125,1095,65,1076,1025,1124,1125,1092,17,1126,40,64,80,1061,65,1076,68,32,116,33,0,112]

theorem envBound17044 : H12AffineFastState.Bounded env17044 := by
  intro p hp
  have h : env17044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17043_17044 : H12AffineEnvironment.transform 8 113 env17043 = env17044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env17043 == env17044) = true)

def env17045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025490,115150,10507601,8650768,10600786,4268162,257,8487407,8478794,10544773]

theorem envBound17045 : H12AffineFastState.Bounded env17045 := by
  intro p hp
  have h : env17045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16910_17045 : H12AffineEnvironment.transform 16 49169 env16910 = env17045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env16910 == env17045) = true)

def env17046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543746,115150,17665,2363456,119042,4268162,257,2199999,2191386,63189]

theorem envBound17046 : H12AffineFastState.Bounded env17046 := by
  intro p hp
  have h : env17046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17045_17046 : H12AffineEnvironment.transform 22 2101328 env17045 = env17046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env17045 == env17046) = true)

def env17047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97666,115150,17665,2363456,119042,329730,257,2199999,2191386,63189]

theorem envBound17047 : H12AffineFastState.Bounded env17047 := by
  intro p hp
  have h : env17047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17046_17047 : H12AffineEnvironment.transform 21 272512 env17046 = env17047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17046 == env17047) = true)

theorem identity17047 : scanCanonicalize (H12AffineFastState.compose env17047 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound17047 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272512,73755,95496,8328,64,97666,115150,17665,335883,119042,329730,257,41460,16465,63189]

theorem envBound17048 : H12AffineFastState.Bounded env17048 := by
  intro p hp
  have h : env17048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17047_17048 : H12AffineEnvironment.transform 20 77899 env17047 = env17048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env17047 == env17048) = true)

def env17049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1025,32769,77899,32,73755,95496,8328,64,97666,115150,17665,67755,119042,73890,257,41460,16465,63189]

theorem envBound17049 : H12AffineFastState.Bounded env17049 := by
  intro p hp
  have h : env17049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17048_17049 : H12AffineEnvironment.transform 17 10400 env17048 = env17049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17048 == env17049) = true)

theorem identity17049 : scanCanonicalize (H12AffineFastState.compose env17049 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound17049 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env17050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,65536,38125,10400,1025,32769,77899,32,73755,74228,8328,64,76158,103730,4605,67755,99838,73890,257,41460,5293,41513]

theorem envBound17050 : H12AffineFastState.Bounded env17050 := by
  intro p hp
  have h : env17050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17049_17050 : H12AffineEnvironment.transform 13 5372 env17049 = env17050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env17049 == env17050) = true)

theorem identity17050 : scanCanonicalize (H12AffineFastState.compose env17050 (packedSelected [3,4,5,9,12,14,15,16,17,18,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17050 : packedSelected [3,4,5,9,12,14,15,16,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env17051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8540,65536,13745,10400,1025,8541,77899,32,73755,74228,8328,64,76158,78958,4605,67755,74914,73890,257,168,5293,885]

theorem envBound17051 : H12AffineFastState.Bounded env17051 := by
  intro p hp
  have h : env17051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17050_17051 : H12AffineEnvironment.transform 14 8540 env17050 = env17051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17050 == env17051) = true)

theorem identity17051 : scanCanonicalize (H12AffineFastState.compose env17051 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8695) := by decide +kernel

theorem selectedBound17051 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8540,8695,13745,10400,1025,8541,4540,32,492,3,8328,64,2185,5529,4605,10588,1365,341,257,168,5293,885]

theorem envBound17052 : H12AffineFastState.Bounded env17052 := by
  intro p hp
  have h : env17052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17051_17052 : H12AffineEnvironment.transform 15 8695 env17051 = env17052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8695 env17051 == env17052) = true)

theorem identity17052 : scanCanonicalize (H12AffineFastState.compose env17052 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17052 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env17053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5372,292,399,5577,2264,1025,293,4540,32,492,3,240,64,2185,5529,4605,2340,1365,341,257,168,5293,885]

theorem envBound17053 : H12AffineFastState.Bounded env17053 := by
  intro p hp
  have h : env17053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17052_17053 : H12AffineEnvironment.transform 12 120 env17052 = env17053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17052 == env17053) = true)

def env17054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1025,32769,77899,33,73755,95496,8328,64,97666,115150,17665,67754,119042,73891,257,41460,16465,63189]

theorem envBound17054 : H12AffineFastState.Bounded env17054 := by
  intro p hp
  have h : env17054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17048_17054 : H12AffineEnvironment.transform 17 10401 env17048 = env17054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17048 == env17054) = true)

theorem identity17054 : scanCanonicalize (H12AffineFastState.compose env17054 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound17054 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env17055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30042,49169,10401,1025,32769,17681,33,21825,82,8328,64,2264,46228,17665,32240,42072,22009,257,41460,16465,63189]

theorem envBound17055 : H12AffineFastState.Bounded env17055 := by
  intro p hp
  have h : env17055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17054_17055 : H12AffineEnvironment.transform 15 30042 env17054 = env17055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env17054 == env17055) = true)

theorem identity17055 : scanCanonicalize (H12AffineFastState.compose env17055 (packedSelected [0,1,5,8,9,10,19,22,24,26,27,31] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17055 : packedSelected [0,1,5,8,9,10,19,22,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env17056 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,49169,10401,1025,32769,17681,33,21776,3,8328,17,2185,46228,17665,32161,41993,21928,257,41381,16384,63108]

theorem envBound17056 : H12AffineFastState.Bounded env17056 := by
  intro p hp
  have h : env17056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17055_17056 : H12AffineEnvironment.transform 5 17 env17055 = env17056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17055 == env17056) = true)

theorem identity17056 : scanCanonicalize (H12AffineFastState.compose env17056 (packedSelected [1,5,8,16,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound17056 : packedSelected [1,5,8,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env17057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,32768,399,46229,10401,1025,32769,12693,33,8596,3,8328,17,2185,46228,12677,2341,41993,8492,257,41381,13444,33280]

theorem envBound17057 : H12AffineFastState.Bounded env17057 := by
  intro p hp
  have h : env17057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17056_17057 : H12AffineEnvironment.transform 13 13444 env17056 = env17057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env17056 == env17057) = true)

theorem identity17057 : scanCanonicalize (H12AffineFastState.compose env17057 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound17057 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env17058 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,137,399,13340,10401,1025,136,12693,33,8596,3,8328,17,2185,13341,12677,2341,9344,8492,257,8492,13444,649]

theorem envBound17058 : H12AffineFastState.Bounded env17058 := by
  intro p hp
  have h : env17058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17057_17058 : H12AffineEnvironment.transform 14 137 env17057 = env17058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env17057 == env17058) = true)

def env17059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97667,115150,17665,2363456,119042,329731,257,2199999,2191386,63189]

theorem envBound17059 : H12AffineFastState.Bounded env17059 := by
  intro p hp
  have h : env17059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17046_17059 : H12AffineEnvironment.transform 21 272513 env17046 = env17059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17046 == env17059) = true)

theorem identity17059 : scanCanonicalize (H12AffineFastState.compose env17059 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17059 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,23945,57796,17665,2363456,61704,272393,257,2142645,2117648,63189]

theorem envBound17060 : H12AffineFastState.Bounded env17060 := by
  intro p hp
  have h : env17060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17059_17060 : H12AffineEnvironment.transform 15 8202 env17059 = env17060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17059 == env17060) = true)

def env17061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,23809,57676,17665,2363456,61704,272393,257,2142525,2117648,63069]

theorem envBound17061 : H12AffineFastState.Bounded env17061 := by
  intro p hp
  have h : env17061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17060_17061 : H12AffineEnvironment.transform 6 8 env17060 = env17061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17060 == env17061) = true)

theorem identity17061 : scanCanonicalize (H12AffineFastState.compose env17061 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound17061 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env17062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,25628,272393,29772,8543,8192,64,23809,57676,17665,291932,61704,272393,257,54561,13324,63069]

theorem envBound17062 : H12AffineFastState.Bounded env17062 := by
  intro p hp
  have h : env17062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17061_17062 : H12AffineEnvironment.transform 20 25628 env17061 = env17062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env17061 == env17062) = true)

theorem identity17062 : scanCanonicalize (H12AffineFastState.compose env17062 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound17062 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env17063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1025,32769,25628,32,29772,8543,8192,64,23809,57676,17665,23669,61704,32,257,54561,13324,63069]

theorem envBound17063 : H12AffineFastState.Bounded env17063 := by
  intro p hp
  have h : env17063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17062_17063 : H12AffineEnvironment.transform 17 10281 env17062 = env17063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17062 == env17063) = true)

theorem identity17063 : scanCanonicalize (H12AffineFastState.compose env17063 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17063 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,13389,10281,1025,29789,25628,32,29772,8543,8192,64,23809,5392,17665,23669,1364,32,257,8573,13324,513]

theorem envBound17064 : H12AffineFastState.Bounded env17064 := by
  intro p hp
  have h : env17064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17063_17064 : H12AffineEnvironment.transform 14 29788 env17063 = env17064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17063 == env17064) = true)

theorem identity17064 : scanCanonicalize (H12AffineFastState.compose env17064 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17064 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17065 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8202,13340,10281,1025,29708,25628,32,29725,8462,8192,17,23809,5392,17665,23588,1285,32,257,8492,13324,513]

theorem envBound17065 : H12AffineFastState.Bounded env17065 := by
  intro p hp
  have h : env17065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17064_17065 : H12AffineEnvironment.transform 5 17 env17064 = env17065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17064 == env17065) = true)

theorem identity17065 : scanCanonicalize (H12AffineFastState.compose env17065 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17065 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17066 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10281,1025,8461,12573,32,8476,8462,8192,17,2048,5392,4096,2341,1285,32,257,8492,13324,513]

theorem envBound17066 : H12AffineFastState.Bounded env17066 := by
  intro p hp
  have h : env17066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17065_17066 : H12AffineEnvironment.transform 13 5377 env17065 = env17066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17065 == env17066) = true)

def env17067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,23808,57677,17665,2363456,61704,272393,257,2142524,2117648,63068]

theorem envBound17067 : H12AffineFastState.Bounded env17067 := by
  intro p hp
  have h : env17067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17060_17067 : H12AffineEnvironment.transform 6 9 env17060 = env17067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17060 == env17067) = true)

theorem identity17067 : scanCanonicalize (H12AffineFastState.compose env17067 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17067 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env17068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38160,262144,1025,32769,2097152,272392,2101328,2101314,8193,64,2049,46156,4096,2363456,41993,272393,257,2142524,2098449,41821]

theorem envBound17068 : H12AffineFastState.Bounded env17068 := by
  intro p hp
  have h : env17068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17067_17068 : H12AffineEnvironment.transform 13 5377 env17067 = env17068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17067 == env17068) = true)

theorem identity17068 : scanCanonicalize (H12AffineFastState.compose env17068 (packedSelected [3,5,8,16,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound17068 : packedSelected [3,5,8,16,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env17069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38160,35189,1025,32769,2097152,41341,2101328,2101314,8193,64,2049,46156,4096,2136373,41993,41340,257,2142524,2098449,41821]

theorem envBound17069 : H12AffineFastState.Bounded env17069 := by
  intro p hp
  have h : env17069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17068_17069 : H12AffineEnvironment.transform 17 35189 env17068 = env17069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env17068 == env17069) = true)

theorem identity17069 : scanCanonicalize (H12AffineFastState.compose env17069 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound17069 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env17070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7180,5377,32768,7174,38160,35189,1025,32769,2097152,40305,2101328,2101314,7181,64,2049,34880,4096,2136373,38917,40304,257,2133296,2098449,40785]

theorem envBound17070 : H12AffineFastState.Bounded env17070 := by
  intro p hp
  have h : env17070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17069_17070 : H12AffineEnvironment.transform 12 7180 env17069 = env17070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env17069 == env17070) = true)

theorem identity17070 : scanCanonicalize (H12AffineFastState.compose env17070 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound17070 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env17071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,32768,342,34880,35189,1025,32769,2097152,32801,2100480,2100498,349,64,2049,34880,3408,2131045,34133,32800,257,2133296,2098449,33281]

theorem envBound17071 : H12AffineFastState.Bounded env17071 := by
  intro p hp
  have h : env17071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17070_17071 : H12AffineEnvironment.transform 11 3408 env17070 = env17071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env17070 == env17071) = true)

theorem identity17071 : scanCanonicalize (H12AffineFastState.compose env17071 (packedSelected [1,4,8,9,10,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 2420) := by decide +kernel

theorem selectedBound17071 : packedSelected [1,4,8,9,10,12,14,16] rootPS < 2^1333 := by decide +kernel

def env17072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,2420,342,308,1,1025,2421,2097152,2389,2100480,2100498,349,64,2049,308,3408,2100497,3105,2388,257,2098244,2098449,2933]

theorem envBound17072 : H12AffineFastState.Bounded env17072 := by
  intro p hp
  have h : env17072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17071_17072 : H12AffineEnvironment.transform 14 2420 env17071 = env17072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2420 env17071 == env17072) = true)

theorem identity17072 : scanCanonicalize (H12AffineFastState.compose env17072 (packedSelected [0,4,6,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 2128) := by decide +kernel

theorem selectedBound17072 : packedSelected [0,4,6,14,15] rootPS < 2^1333 := by decide +kernel

def env17073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,2420,342,308,1,1025,2421,2128,2389,1360,1346,349,64,2049,308,3408,1345,3105,2388,257,3092,3393,2933]

theorem envBound17073 : H12AffineFastState.Bounded env17073 := by
  intro p hp
  have h : env17073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17072_17073 : H12AffineEnvironment.transform 20 2128 env17072 = env17073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2128 env17072 == env17073) = true)

theorem identity17073 : scanCanonicalize (H12AffineFastState.compose env17073 (packedSelected [0,1,3,5,6,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound17073 : packedSelected [0,1,3,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,356,348,1125,1344,342,308,1,1025,1345,1124,1377,1360,1346,349,64,1077,308,356,1345,21,1376,257,32,373,1857]

theorem envBound17074 : H12AffineFastState.Bounded env17074 := by
  intro p hp
  have h : env17074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17073_17074 : H12AffineEnvironment.transform 10 1076 env17073 = env17074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env17073 == env17074) = true)

theorem identity17074 : scanCanonicalize (H12AffineFastState.compose env17074 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound17074 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17075 : List Nat := [2,4,8,16,32,64,9,256,512,320,372,356,348,293,0,342,308,1,321,1,292,33,16,2,349,64,373,308,356,1,21,32,257,32,373,513]

theorem envBound17075 : H12AffineFastState.Bounded env17075 := by
  intro p hp
  have h : env17075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17074_17075 : H12AffineEnvironment.transform 9 320 env17074 = env17075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env17074 == env17075) = true)

theorem identity17075 : scanCanonicalize (H12AffineFastState.compose env17075 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17076 : List Nat := [2,4,8,0,32,64,9,256,512,320,356,356,332,293,0,326,292,1,321,1,292,33,0,2,333,64,357,292,356,1,5,32,257,32,357,513]

theorem envBound17076 : H12AffineFastState.Bounded env17076 := by
  intro p hp
  have h : env17076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17075_17076 : H12AffineEnvironment.transform 3 0 env17075 = env17076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17075 == env17076) = true)

theorem identity17076 : scanCanonicalize (H12AffineFastState.compose env17076 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound17076 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17077 : List Nat := [2,4,8,0,32,64,9,256,293,320,356,356,332,293,0,326,292,1,321,1,292,33,0,2,333,64,357,292,356,1,5,32,257,32,357,292]

theorem envBound17077 : H12AffineFastState.Bounded env17077 := by
  intro p hp
  have h : env17077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17076_17077 : H12AffineEnvironment.transform 8 293 env17076 = env17077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env17076 == env17077) = true)

theorem identity17077 : scanCanonicalize (H12AffineFastState.compose env17077 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound17077 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17078 : List Nat := [2,4,8,0,32,1,9,256,293,257,293,293,269,293,0,263,292,1,256,1,292,33,0,2,268,1,292,292,293,1,5,32,257,32,292,292]

theorem envBound17078 : H12AffineFastState.Bounded env17078 := by
  intro p hp
  have h : env17078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17077_17078 : H12AffineEnvironment.transform 5 1 env17077 = env17078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17077 == env17078) = true)

theorem identity17078 : scanCanonicalize (H12AffineFastState.compose env17078 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17078 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17079 : List Nat := [2,4,8,0,0,1,9,256,261,257,261,261,269,261,0,263,260,1,256,1,260,1,0,2,268,1,260,260,261,1,5,0,257,0,260,260]

theorem envBound17079 : H12AffineFastState.Bounded env17079 := by
  intro p hp
  have h : env17079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17078_17079 : H12AffineEnvironment.transform 4 0 env17078 = env17079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17078 == env17079) = true)

theorem identity17079 : scanCanonicalize (H12AffineFastState.compose env17079 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17079 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17080 : List Nat := [2,4,8,0,0,1,9,4,1,5,1,1,9,1,0,3,0,1,4,1,0,1,0,2,8,1,0,0,1,1,5,0,5,0,0,0]

theorem envBound17080 : H12AffineFastState.Bounded env17080 := by
  intro p hp
  have h : env17080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17079_17080 : H12AffineEnvironment.transform 7 4 env17079 = env17080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17079 == env17080) = true)

def env17081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543747,115150,17664,2363457,119043,4268162,257,2199998,2191387,63188]

theorem envBound17081 : H12AffineFastState.Bounded env17081 := by
  intro p hp
  have h : env17081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17045_17081 : H12AffineEnvironment.transform 22 2101329 env17045 = env17081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env17045 == env17081) = true)

def env17082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97667,115150,17664,2363457,119043,329730,257,2199998,2191387,63188]

theorem envBound17082 : H12AffineFastState.Bounded env17082 := by
  intro p hp
  have h : env17082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17081_17082 : H12AffineEnvironment.transform 21 272512 env17081 = env17082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17081 == env17082) = true)

theorem identity17082 : scanCanonicalize (H12AffineFastState.compose env17082 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound17082 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115871,272512,120014,98780,8328,64,97667,115150,17664,382174,119043,329730,257,21793,46212,63188]

theorem envBound17083 : H12AffineFastState.Bounded env17083 := by
  intro p hp
  have h : env17083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17082_17083 : H12AffineEnvironment.transform 20 115871 env17082 = env17083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env17082 == env17083) = true)

def env17084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115735,272392,119878,98644,8192,64,97547,115014,17664,382038,119043,329730,257,21793,46092,63068]

theorem envBound17084 : H12AffineFastState.Bounded env17084 := by
  intro p hp
  have h : env17084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17083_17084 : H12AffineEnvironment.transform 6 8 env17083 = env17084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17083 == env17084) = true)

theorem identity17084 : scanCanonicalize (H12AffineFastState.compose env17084 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound17084 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env17085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5440,262144,1025,21840,69958,272392,65815,87045,8192,64,97547,70679,17664,327943,66642,329730,257,21793,24925,8973]

theorem envBound17085 : H12AffineFastState.Bounded env17085 := by
  intro p hp
  have h : env17085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17084_17085 : H12AffineEnvironment.transform 14 21841 env17084 = env17085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env17084 == env17085) = true)

theorem identity17085 : scanCanonicalize (H12AffineFastState.compose env17085 (packedSelected [17,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17085 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env17086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,65536,5440,262144,1025,1,69958,272392,65815,65876,8192,64,75866,70679,4177,327943,66642,329730,257,112,13324,8973]

theorem envBound17086 : H12AffineFastState.Bounded env17086 := by
  intro p hp
  have h : env17086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17085_17086 : H12AffineEnvironment.transform 13 5457 env17085 = env17086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17085 == env17086) = true)

theorem identity17086 : scanCanonicalize (H12AffineFastState.compose env17086 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound17086 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env17087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,342,5440,262144,1025,1,4112,272392,65,2,8192,64,10508,5441,4177,262225,1284,264532,257,112,13324,8973]

theorem envBound17087 : H12AffineFastState.Bounded env17087 := by
  intro p hp
  have h : env17087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17086_17087 : H12AffineEnvironment.transform 15 342 env17086 = env17087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env17086 == env17087) = true)

theorem identity17087 : scanCanonicalize (H12AffineFastState.compose env17087 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound17087 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,342,5440,2340,1025,1,4112,8492,65,2,8192,64,10508,5441,4177,2421,1284,112,257,112,13324,8973]

theorem envBound17088 : H12AffineFastState.Bounded env17088 := by
  intro p hp
  have h : env17088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17087_17088 : H12AffineEnvironment.transform 17 2340 env17087 = env17088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env17087 == env17088) = true)

theorem identity17088 : scanCanonicalize (H12AffineFastState.compose env17088 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound17088 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,8192,3344,0,342,3329,2340,1025,1,2129,8492,65,2,8192,64,10508,3328,2064,2421,1284,112,257,112,11341,8973]

theorem envBound17089 : H12AffineFastState.Bounded env17089 := by
  intro p hp
  have h : env17089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17088_17089 : H12AffineEnvironment.transform 11 2113 env17088 = env17089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env17088 == env17089) = true)

theorem identity17089 : scanCanonicalize (H12AffineFastState.compose env17089 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound17089 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17090 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2113,8192,2048,0,342,2065,2340,273,1,2129,8492,65,2,8192,64,10508,2064,2064,2421,20,112,257,112,10589,8973]

theorem envBound17090 : H12AffineFastState.Bounded env17090 := by
  intro p hp
  have h : env17090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17089_17090 : H12AffineEnvironment.transform 9 272 env17089 = env17090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17089 == env17090) = true)

theorem identity17090 : scanCanonicalize (H12AffineFastState.compose env17090 (packedSelected [2,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17090 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env17091 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2113,2317,2048,0,342,2065,2340,273,1,2129,2081,65,2,2317,64,1,2064,2064,2421,20,112,257,112,80,2560]

theorem envBound17091 : H12AffineFastState.Bounded env17091 := by
  intro p hp
  have h : env17091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17090_17091 : H12AffineEnvironment.transform 12 2317 env17090 = env17091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17090 == env17091) = true)

theorem identity17091 : scanCanonicalize (H12AffineFastState.compose env17091 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17091 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env17092 : List Nat := [2,4,8,16,16,64,8,256,512,272,2048,2113,2317,2048,0,342,2065,2324,273,1,2129,2065,65,2,2317,64,1,2064,2064,2373,20,64,257,64,80,2560]

theorem envBound17092 : H12AffineFastState.Bounded env17092 := by
  intro p hp
  have h : env17092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17091_17092 : H12AffineEnvironment.transform 4 16 env17091 = env17092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17091 == env17092) = true)

theorem identity17092 : scanCanonicalize (H12AffineFastState.compose env17092 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound17092 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17093 : List Nat := [2,4,8,16,16,64,8,85,512,69,2048,2113,2136,2048,0,3,2065,2113,68,1,2129,2065,65,2,2136,64,1,2064,2064,2064,20,64,84,64,80,2560]

theorem envBound17093 : H12AffineFastState.Bounded env17093 := by
  intro p hp
  have h : env17093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17092_17093 : H12AffineEnvironment.transform 7 85 env17092 = env17093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env17092 == env17093) = true)

theorem identity17093 : scanCanonicalize (H12AffineFastState.compose env17093 (packedSelected [0,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17093 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env17094 : List Nat := [2,4,8,16,16,16,8,5,512,21,2048,2065,2056,2048,0,3,2065,2065,20,1,2049,2065,17,2,2056,16,1,2064,2064,2064,20,16,4,16,0,2560]

theorem envBound17094 : H12AffineFastState.Bounded env17094 := by
  intro p hp
  have h : env17094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17093_17094 : H12AffineEnvironment.transform 5 16 env17093 = env17094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17093 == env17094) = true)

theorem identity17094 : scanCanonicalize (H12AffineFastState.compose env17094 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound17094 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env17095 : List Nat := [2,4,8,16,16,16,8,5,16,21,2048,2065,2056,2048,0,3,2065,2065,20,1,2049,2065,17,2,2056,16,1,2064,2064,2064,20,16,4,16,0,2064]

theorem envBound17095 : H12AffineFastState.Bounded env17095 := by
  intro p hp
  have h : env17095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17094_17095 : H12AffineEnvironment.transform 8 16 env17094 = env17095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env17094 == env17095) = true)

theorem identity17095 : scanCanonicalize (H12AffineFastState.compose env17095 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound17095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17096 : List Nat := [2,4,8,16,16,16,8,5,16,21,16,1,24,16,0,3,1,1,20,1,17,1,17,2,24,16,1,0,0,0,20,16,4,16,0,0]

theorem envBound17096 : H12AffineFastState.Bounded env17096 := by
  intro p hp
  have h : env17096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17095_17096 : H12AffineEnvironment.transform 10 16 env17095 = env17096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env17095 == env17096) = true)

def env17097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115734,272393,119879,98645,8193,64,97546,115015,17664,382039,119043,329730,257,21793,46093,63069]

theorem envBound17097 : H12AffineFastState.Bounded env17097 := by
  intro p hp
  have h : env17097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17083_17097 : H12AffineEnvironment.transform 6 9 env17083 = env17097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17083 == env17097) = true)

theorem identity17097 : scanCanonicalize (H12AffineFastState.compose env17097 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound17097 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env17098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,49169,262144,1025,32769,50277,272393,54324,33062,8193,64,32121,49460,17664,316452,53616,264305,257,21793,46093,63069]

theorem envBound17098 : H12AffineFastState.Bounded env17098 := by
  intro p hp
  have h : env17098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17097_17098 : H12AffineEnvironment.transform 15 115 env17097 = env17098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env17097 == env17098) = true)

theorem identity17098 : scanCanonicalize (H12AffineFastState.compose env17098 (packedSelected [2,3,4,6,7,8,11,12,15,18,22,24,26,27,28,35] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound17098 : packedSelected [2,3,4,6,7,8,11,12,15,18,22,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env17099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8313,115,24680,262144,1025,8312,25628,272393,29773,8543,8193,64,32121,24909,17664,291933,28937,264305,257,21793,5236,22052]

theorem envBound17099 : H12AffineFastState.Bounded env17099 := by
  intro p hp
  have h : env17099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17098_17099 : H12AffineEnvironment.transform 14 8313 env17098 = env17099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env17098 == env17099) = true)

theorem identity17099 : scanCanonicalize (H12AffineFastState.compose env17099 (packedSelected [1,4,5,8,9,14,17,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17099 : packedSelected [1,4,5,8,9,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env17100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1,115,16400,262144,1025,0,17508,264305,21557,295,121,64,23809,16693,17664,283685,20849,264305,257,21793,5236,22052]

theorem envBound17100 : H12AffineFastState.Bounded env17100 := by
  intro p hp
  have h : env17100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17099_17100 : H12AffineEnvironment.transform 12 120 env17099 = env17100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17099 == env17100) = true)

theorem identity17100 : scanCanonicalize (H12AffineFastState.compose env17100 (packedSelected [16,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound17100 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env17101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1,115,16400,2129,1025,0,17508,32,21557,295,121,64,23809,16693,17664,23668,20849,32,257,21793,5236,22052]

theorem envBound17101 : H12AffineFastState.Bounded env17101 := by
  intro p hp
  have h : env17101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17100_17101 : H12AffineEnvironment.transform 17 2129 env17100 = env17101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env17100 == env17101) = true)

theorem identity17101 : scanCanonicalize (H12AffineFastState.compose env17101 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17101 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,1,115,5392,2129,1025,0,4452,32,309,295,121,64,2049,5173,4096,2420,1137,32,257,33,5236,804]

theorem envBound17102 : H12AffineFastState.Bounded env17102 := by
  intro p hp
  have h : env17102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17101_17102 : H12AffineEnvironment.transform 13 5376 env17101 = env17102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17101 == env17102) = true)

theorem identity17102 : scanCanonicalize (H12AffineFastState.compose env17102 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17102 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17103 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,1,34,5392,2048,1025,0,4405,32,309,295,40,17,2049,5173,4096,2341,1056,32,257,33,5157,804]

theorem envBound17103 : H12AffineFastState.Bounded env17103 := by
  intro p hp
  have h : env17103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17102_17103 : H12AffineEnvironment.transform 5 17 env17102 = env17103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17102 == env17103) = true)

theorem identity17103 : scanCanonicalize (H12AffineFastState.compose env17103 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17103 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env17104 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,34,5172,2048,1025,0,4113,32,17,3,40,17,2049,5173,4096,2049,1056,32,37,33,5157,512]

theorem envBound17104 : H12AffineFastState.Bounded env17104 := by
  intro p hp
  have h : env17104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17103_17104 : H12AffineEnvironment.transform 7 36 env17103 = env17104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17103 == env17104) = true)

theorem identity17104 : scanCanonicalize (H12AffineFastState.compose env17104 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17105 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,1,2,5140,2048,1025,0,4113,0,17,3,8,17,2049,5141,4096,2049,1024,0,5,1,5125,512]

theorem envBound17105 : H12AffineFastState.Bounded env17105 := by
  intro p hp
  have h : env17105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17104_17105 : H12AffineEnvironment.transform 4 0 env17104 = env17105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17104 == env17105) = true)

theorem identity17105 : scanCanonicalize (H12AffineFastState.compose env17105 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound17105 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17106 : List Nat := [2,4,8,16,0,17,9,4,512,1024,522,4096,9,5124,1,2,5140,522,1025,0,4113,0,17,3,8,17,523,5141,4096,523,1024,0,5,1,5125,512]

theorem envBound17106 : H12AffineFastState.Bounded env17106 := by
  intro p hp
  have h : env17106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17105_17106 : H12AffineEnvironment.transform 10 522 env17105 = env17106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env17105 == env17106) = true)

def env17107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97666,115150,17664,2363457,119043,329731,257,2199998,2191387,63188]

theorem envBound17107 : H12AffineFastState.Bounded env17107 := by
  intro p hp
  have h : env17107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17081_17107 : H12AffineEnvironment.transform 21 272513 env17081 = env17107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17081 == env17107) = true)

theorem identity17107 : scanCanonicalize (H12AffineFastState.compose env17107 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound17107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49169,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,43357,5393,17664,2363457,1500,318684,257,2114913,2139332,63188]

theorem envBound17108 : H12AffineFastState.Bounded env17108 := by
  intro p hp
  have h : env17108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17107_17108 : H12AffineEnvironment.transform 15 54495 env17107 = env17108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env17107 == env17108) = true)

theorem identity17108 : scanCanonicalize (H12AffineFastState.compose env17108 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17108 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13508,262144,1025,29908,2097152,272513,2101329,2114883,8328,64,23944,5393,17664,2363457,1500,272393,257,2114913,2117649,513]

theorem envBound17109 : H12AffineFastState.Bounded env17109 := by
  intro p hp
  have h : env17109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17108_17109 : H12AffineEnvironment.transform 14 29909 env17108 = env17109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17108 == env17109) = true)

theorem identity17109 : scanCanonicalize (H12AffineFastState.compose env17109 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound17109 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13508,262144,1025,29908,281653,272513,285796,264566,8328,64,23944,5393,17664,23668,1500,272393,257,264532,269348,513]

theorem envBound17110 : H12AffineFastState.Bounded env17110 := by
  intro p hp
  have h : env17110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17109_17110 : H12AffineEnvironment.transform 20 281653 env17109 = env17110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env17109 == env17110) = true)

theorem identity17110 : scanCanonicalize (H12AffineFastState.compose env17110 (packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 32240) := by decide +kernel

theorem selectedBound17110 : packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS < 2^1333 := by decide +kernel

def env17111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13508,32240,1025,29908,12741,21873,8596,29830,8328,64,23944,5393,17664,23668,1500,22009,257,29860,25044,513]

theorem envBound17111 : H12AffineFastState.Bounded env17111 := by
  intro p hp
  have h : env17111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17110_17111 : H12AffineEnvironment.transform 17 32240 env17110 = env17111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env17110 == env17111) = true)

theorem identity17111 : scanCanonicalize (H12AffineFastState.compose env17111 (packedSelected [2,3,4,6,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17111 : packedSelected [2,3,4,6,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env17112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,8202,13508,10401,1025,8581,12741,32,8596,8663,8328,64,2265,5393,4177,2341,1500,168,257,8693,13445,513]

theorem envBound17112 : H12AffineFastState.Bounded env17112 := by
  intro p hp
  have h : env17112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17111_17112 : H12AffineEnvironment.transform 13 5457 env17111 = env17112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17111 == env17112) = true)

theorem identity17112 : scanCanonicalize (H12AffineFastState.compose env17112 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17112 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env17113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8461,8202,13389,10280,1025,8460,12620,32,8477,8542,8193,64,2128,5393,4177,2341,1365,33,257,8572,13324,513]

theorem envBound17113 : H12AffineFastState.Bounded env17113 := by
  intro p hp
  have h : env17113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17112_17113 : H12AffineEnvironment.transform 6 9 env17112 = env17113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17112 == env17113) = true)

theorem identity17113 : scanCanonicalize (H12AffineFastState.compose env17113 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17113 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,0,263,5440,2341,1025,1,4161,32,16,83,268,64,2128,5393,4177,2341,1365,33,257,113,5377,513]

theorem envBound17114 : H12AffineFastState.Bounded env17114 := by
  intro p hp
  have h : env17114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17113_17114 : H12AffineEnvironment.transform 12 269 env17113 = env17114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17113 == env17114) = true)

theorem identity17114 : scanCanonicalize (H12AffineFastState.compose env17114 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound17114 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17115 : List Nat := [2,4,8,16,32,64,9,256,512,613,2048,4096,269,4916,0,263,4901,2341,612,1,4161,32,16,83,268,64,2128,4980,4177,2341,816,33,257,113,4964,513]

theorem envBound17115 : H12AffineFastState.Bounded env17115 := by
  intro p hp
  have h : env17115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17114_17115 : H12AffineEnvironment.transform 9 613 env17114 = env17115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env17114 == env17115) = true)

theorem identity17115 : scanCanonicalize (H12AffineFastState.compose env17115 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2625) := by decide +kernel

theorem selectedBound17115 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env17116 : List Nat := [2,4,8,16,32,64,9,256,512,613,2048,2625,269,2421,0,263,2404,2341,612,1,2560,32,16,83,268,64,2128,2357,2576,2341,816,33,257,113,2341,513]

theorem envBound17116 : H12AffineFastState.Bounded env17116 := by
  intro p hp
  have h : env17116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17115_17116 : H12AffineEnvironment.transform 11 2625 env17115 = env17116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2625 env17115 == env17116) = true)

theorem identity17116 : scanCanonicalize (H12AffineFastState.compose env17116 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound17116 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17117 : List Nat := [2,4,8,16,32,64,9,256,512,613,593,16,269,804,0,263,821,884,612,1,81,32,16,83,268,64,513,868,65,884,816,33,257,113,884,513]

theorem envBound17117 : H12AffineFastState.Bounded env17117 := by
  intro p hp
  have h : env17117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17116_17117 : H12AffineEnvironment.transform 10 593 env17116 = env17117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env17116 == env17117) = true)

theorem identity17117 : scanCanonicalize (H12AffineFastState.compose env17117 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound17117 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17118 : List Nat := [2,4,8,16,32,64,9,256,65,36,16,16,269,357,0,263,372,309,37,1,81,32,16,83,268,64,64,293,65,309,369,33,257,113,309,64]

theorem envBound17118 : H12AffineFastState.Bounded env17118 := by
  intro p hp
  have h : env17118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17117_17118 : H12AffineEnvironment.transform 8 65 env17117 = env17118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env17117 == env17118) = true)

theorem identity17118 : scanCanonicalize (H12AffineFastState.compose env17118 (packedSelected [0,2,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound17118 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env17119 : List Nat := [2,4,8,16,32,64,9,101,65,36,16,16,104,0,0,98,17,80,37,1,81,32,16,83,105,64,64,64,65,80,20,33,100,113,80,64]

theorem envBound17119 : H12AffineFastState.Bounded env17119 := by
  intro p hp
  have h : env17119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17118_17119 : H12AffineEnvironment.transform 7 101 env17118 = env17119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env17118 == env17119) = true)

theorem identity17119 : scanCanonicalize (H12AffineFastState.compose env17119 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17119 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17120 : List Nat := [2,4,8,16,16,64,9,85,65,20,16,16,88,0,0,82,17,80,21,1,81,16,16,83,89,64,64,64,65,80,20,17,84,65,80,64]

theorem envBound17120 : H12AffineFastState.Bounded env17120 := by
  intro p hp
  have h : env17120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17119_17120 : H12AffineEnvironment.transform 4 16 env17119 = env17120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17119 == env17120) = true)

theorem identity17120 : scanCanonicalize (H12AffineFastState.compose env17120 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17121 : List Nat := [2,4,8,0,0,64,9,69,65,4,0,0,72,0,0,66,1,64,5,1,65,0,0,67,73,64,64,64,65,64,4,1,68,65,64,64]

theorem envBound17121 : H12AffineFastState.Bounded env17121 := by
  intro p hp
  have h : env17121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17120_17121 : H12AffineEnvironment.transform 3 0 env17120 = env17121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17120 == env17121) = true)

theorem identity17121 : scanCanonicalize (H12AffineFastState.compose env17121 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17122 : List Nat := [2,4,8,0,0,0,9,5,1,4,0,0,8,0,0,2,1,0,5,1,1,0,0,3,9,0,0,0,1,0,4,1,4,1,0,0]

theorem envBound17122 : H12AffineFastState.Bounded env17122 := by
  intro p hp
  have h : env17122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17121_17122 : H12AffineEnvironment.transform 5 0 env17121 = env17122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17121 == env17122) = true)

def env17123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound17123 : H12AffineFastState.Bounded env17123 := by
  intro p hp
  have h : env17123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16458_17123 : H12AffineEnvironment.transform 25 65 env16458 = env17123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env16458 == env17123) = true)

def env17124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound17124 : H12AffineFastState.Bounded env17124 := by
  intro p hp
  have h : env17124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17123_17124 : H12AffineEnvironment.transform 26 30393344 env17123 = env17124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env17123 == env17124) = true)

def env17125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound17125 : H12AffineFastState.Bounded env17125 := by
  intro p hp
  have h : env17125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17124_17125 : H12AffineEnvironment.transform 18 1024 env17124 = env17125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17124 == env17125) = true)

theorem identity17125 : scanCanonicalize (H12AffineFastState.compose env17125 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound17125 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362227,18973836,10507600,8456242,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound17126 : H12AffineFastState.Bounded env17126 := by
  intro p hp
  have h : env17126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17125_17126 : H12AffineEnvironment.transform 17 247859 env17125 = env17126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env17125 == env17126) = true)

def env17127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784943,5392,10507600,8456242,10491276,4256860,256,8410416,8434837,10564187]

theorem envBound17127 : H12AffineFastState.Bounded env17127 := by
  intro p hp
  have h : env17127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17126_17127 : H12AffineEnvironment.transform 23 2199964 env17126 = env17127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env17126 == env17127) = true)

def env17128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,8388608,98780,8328,65,12683759,5392,8406288,8456242,8390092,4256860,256,8410416,8434837,8462875]

theorem envBound17128 : H12AffineFastState.Bounded env17128 := by
  intro p hp
  have h : env17128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17127_17128 : H12AffineEnvironment.transform 20 4160 env17127 = env17128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17127 == env17128) = true)

def env17129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98780,8328,65,4295167,5392,17664,67618,1500,4256860,256,21792,46213,74251]

theorem envBound17129 : H12AffineFastState.Bounded env17129 := by
  intro p hp
  have h : env17129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17128_17129 : H12AffineEnvironment.transform 22 16 env17128 = env17129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17128 == env17129) = true)

def env17130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98644,8192,65,4295031,5392,17664,67618,1364,4256860,256,21792,46093,74251]

theorem envBound17130 : H12AffineFastState.Bounded env17130 := by
  intro p hp
  have h : env17130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17129_17130 : H12AffineEnvironment.transform 6 8 env17129 = env17130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17129 == env17130) = true)

theorem identity17130 : scanCanonicalize (H12AffineFastState.compose env17130 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

end H12CloudChart0