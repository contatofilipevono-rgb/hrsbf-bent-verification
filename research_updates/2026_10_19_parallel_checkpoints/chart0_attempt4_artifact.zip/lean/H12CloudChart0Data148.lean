import H12CloudChart0Data147

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env37530 : List Nat := [2,4,8,4,1,5,9,5,9,0,3,4,9,0,1,3,4,2,0,0,0,0,4,3,8,4,3,4,5,2,1,1,5,0,1,8]

theorem envBound37530 : H12AffineFastState.Bounded env37530 := by
  intro p hp
  have h : env37530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37529_37530 : H12AffineEnvironment.transform 8 9 env37529 = env37530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env37529 == env37530) = true)

def leafEnv37530 : List Nat := [2,4,8,4,1,5,9,5,9,0,3,4,9,0,1,3,4,2,0,0,0,0,4,3,0,8,1,4,3,4,5,2,1,1,5,0,5,2,1,8,1,1,0]

def active37530 : List Nat := [0,1,2]

def tree37530 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37530 : H12WitnessSearch.Good tree37530 := H12GlobalWitnessIndex.good

theorem leafIdentity37530 : H12AffineFastState.composeSystem env37530 rootObs = leafEnv37530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37530 rootObs == leafEnv37530) = true)

theorem terminalChecked37530 : H12PackedTerminal.terminalCheckFast leafEnv37530 active37530 tree37530 = true := by decide +kernel

def env37531 : List Nat := [2,4,8,5,1,4,9,5,512,0,522,5,9,1,1,3,4,523,0,0,0,0,5,3,8,5,522,4,4,523,1,1,5,0,0,513]

theorem envBound37531 : H12AffineFastState.Bounded env37531 := by
  intro p hp
  have h : env37531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37528_37531 : H12AffineEnvironment.transform 3 5 env37528 = env37531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37528 == env37531) = true)

theorem identity37531 : scanCanonicalize (H12AffineFastState.compose env37531 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37532 : List Nat := [0,4,8,5,1,4,9,5,512,0,520,5,9,1,1,1,4,521,0,0,0,0,5,1,8,5,520,4,4,521,1,1,5,0,0,513]

theorem envBound37532 : H12AffineFastState.Bounded env37532 := by
  intro p hp
  have h : env37532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37531_37532 : H12AffineEnvironment.transform 0 0 env37531 = env37532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37531 == env37532) = true)

def leafEnv37532 : List Nat := [0,4,8,5,1,4,9,5,512,0,520,5,9,1,1,1,4,521,0,0,0,0,5,1,0,8,1,5,520,4,4,521,1,1,5,0,5,0,0,513,1,1,0]

def active37532 : List Nat := [1,2,8]

def tree37532 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37532 : H12WitnessSearch.Good tree37532 := H12GlobalWitnessIndex.good

theorem leafIdentity37532 : H12AffineFastState.composeSystem env37532 rootObs = leafEnv37532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37532 rootObs == leafEnv37532) = true)

theorem terminalChecked37532 : H12PackedTerminal.terminalCheckFast leafEnv37532 active37532 tree37532 = true := by decide +kernel

def env37533 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,17,9,1045,1,3,1029,523,1024,0,1,0,16,3,8,16,522,1029,16,523,1025,1,5,0,1044,513]

theorem envBound37533 : H12AffineFastState.Bounded env37533 := by
  intro p hp
  have h : env37533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37526_37533 : H12AffineEnvironment.transform 11 17 env37526 = env37533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37526 == env37533) = true)

theorem identity37533 : scanCanonicalize (H12AffineFastState.compose env37533 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37534 : List Nat := [2,4,8,4,1,5,9,5,512,1024,522,5,9,1025,1,3,1029,523,1024,0,1,0,4,3,8,4,522,1029,4,523,1025,1,5,0,1024,513]

theorem envBound37534 : H12AffineFastState.Bounded env37534 := by
  intro p hp
  have h : env37534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37533_37534 : H12AffineEnvironment.transform 3 4 env37533 = env37534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37533 == env37534) = true)

def env37535 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,5,9,1,1,3,5,523,0,0,1,0,4,3,8,4,522,5,4,523,1,1,5,0,0,513]

theorem envBound37535 : H12AffineFastState.Bounded env37535 := by
  intro p hp
  have h : env37535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37534_37535 : H12AffineEnvironment.transform 9 0 env37534 = env37535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env37534 == env37535) = true)

theorem identity37535 : scanCanonicalize (H12AffineFastState.compose env37535 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound37535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37536 : List Nat := [2,4,8,4,1,5,9,5,8,0,2,5,9,1,1,3,5,3,0,0,1,0,4,3,8,4,2,5,4,3,1,1,5,0,0,9]

theorem envBound37536 : H12AffineFastState.Bounded env37536 := by
  intro p hp
  have h : env37536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37535_37536 : H12AffineEnvironment.transform 8 8 env37535 = env37536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env37535 == env37536) = true)

def leafEnv37536 : List Nat := [2,4,8,4,1,5,9,5,8,0,2,5,9,1,1,3,5,3,0,0,1,0,4,3,0,8,1,4,2,5,4,3,1,1,5,0,5,2,0,9,1,0,0]

def active37536 : List Nat := [0,1,2]

def tree37536 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37536 : H12WitnessSearch.Good tree37536 := H12GlobalWitnessIndex.good

theorem leafIdentity37536 : H12AffineFastState.composeSystem env37536 rootObs = leafEnv37536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37536 rootObs == leafEnv37536) = true)

theorem terminalChecked37536 : H12PackedTerminal.terminalCheckFast leafEnv37536 active37536 tree37536 = true := by decide +kernel

def env37537 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,5,9,0,1,3,4,523,1,0,1,0,4,3,8,4,522,4,4,523,0,1,5,0,1,513]

theorem envBound37537 : H12AffineFastState.Bounded env37537 := by
  intro p hp
  have h : env37537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37534_37537 : H12AffineEnvironment.transform 9 1 env37534 = env37537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env37534 == env37537) = true)

theorem identity37537 : scanCanonicalize (H12AffineFastState.compose env37537 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37537 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37538 : List Nat := [1,4,8,4,1,5,9,5,512,1,521,5,9,0,1,0,4,520,1,0,1,0,4,0,8,4,521,4,4,520,0,1,5,0,1,513]

theorem envBound37538 : H12AffineFastState.Bounded env37538 := by
  intro p hp
  have h : env37538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37537_37538 : H12AffineEnvironment.transform 0 1 env37537 = env37538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37537 == env37538) = true)

def leafEnv37538 : List Nat := [1,4,8,4,1,5,9,5,512,1,521,5,9,0,1,0,4,520,1,0,1,0,4,0,1,8,1,4,521,4,4,520,0,1,5,0,5,1,1,513,1,0,0]

def active37538 : List Nat := [1,2,8]

def tree37538 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37538 : H12WitnessSearch.Good tree37538 := H12GlobalWitnessIndex.good

theorem leafIdentity37538 : H12AffineFastState.composeSystem env37538 rootObs = leafEnv37538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37538 rootObs == leafEnv37538) = true)

theorem terminalChecked37538 : H12PackedTerminal.terminalCheckFast leafEnv37538 active37538 tree37538 = true := by decide +kernel

def env37539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound37539 : H12AffineFastState.Bounded env37539 := by
  intro p hp
  have h : env37539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37307_37539 : H12AffineEnvironment.transform 18 1025 env37307 = env37539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37307 == env37539) = true)

theorem identity37539 : scanCanonicalize (H12AffineFastState.compose env37539 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444659) := by decide +kernel

theorem selectedBound37539 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444659,16777216,8328,65,23235954,18973837,333858,2329971,19188067,23160257,257,17074655,17066106,19263157]

theorem envBound37540 : H12AffineFastState.Bounded env37540 := by
  intro p hp
  have h : env37540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37539_37540 : H12AffineEnvironment.transform 22 2444659 env37539 = env37540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444659 env37539 == env37540) = true)

def env37541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,16777216,8328,65,16959642,18973837,333858,2329971,19188067,16850985,257,17074655,17066106,19263157]

theorem envBound37541 : H12AffineFastState.Bounded env37541 := by
  intro p hp
  have h : env37541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37540_37541 : H12AffineEnvironment.transform 21 2115048 env37540 = env37541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env37540 == env37541) = true)

def env37542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431072,8328,65,2609402,302317,333858,2329971,119043,2373705,257,2199999,2191386,63189]

theorem envBound37542 : H12AffineFastState.Bounded env37542 := by
  intro p hp
  have h : env37542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37541_37542 : H12AffineEnvironment.transform 23 2431072 env37541 = env37542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env37541 == env37542) = true)

def env37543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329760,8328,65,508090,302317,333858,236851,119043,272393,257,98815,90202,63189]

theorem envBound37543 : H12AffineFastState.Bounded env37543 := by
  intro p hp
  have h : env37543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37542_37543 : H12AffineEnvironment.transform 20 4160 env37542 = env37543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37542 == env37543) = true)

theorem identity37543 : scanCanonicalize (H12AffineFastState.compose env37543 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound37543 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,4160,21928,120014,98781,8328,65,215367,5392,102879,236851,119043,41460,257,98815,90202,63189]

theorem envBound37544 : H12AffineFastState.Bounded env37544 := by
  intro p hp
  have h : env37544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37543_37544 : H12AffineEnvironment.transform 17 35325 env37543 = env37544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env37543 == env37544) = true)

def env37545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1025,8541,4160,21928,95634,73857,8328,65,215367,5392,77955,212079,94303,168,257,73891,90202,22409]

theorem envBound37545 : H12AffineFastState.Bounded env37545 := by
  intro p hp
  have h : env37545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37544_37545 : H12AffineEnvironment.transform 14 8540 env37544 = env37545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37544 == env37545) = true)

def env37546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1025,8541,4160,32,73754,73857,8328,65,203983,5392,77955,212079,75223,168,257,73891,79314,513]

theorem envBound37546 : H12AffineFastState.Bounded env37546 := by
  intro p hp
  have h : env37546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37545_37546 : H12AffineEnvironment.transform 13 5512 env37545 = env37546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env37545 == env37546) = true)

theorem identity37546 : scanCanonicalize (H12AffineFastState.compose env37546 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 70814) := by decide +kernel

theorem selectedBound37546 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,70814,10401,1025,8541,4160,32,73754,73857,8328,65,2129,5392,77955,10481,75223,168,257,73891,79314,513]

theorem envBound37547 : H12AffineFastState.Bounded env37547 := by
  intro p hp
  have h : env37547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37546_37547 : H12AffineEnvironment.transform 16 70814 env37546 = env37547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70814 env37546 == env37547) = true)

def env37548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1025,8541,4160,33,73755,73857,8328,65,203982,5392,77955,212079,75222,168,257,73891,79315,512]

theorem envBound37548 : H12AffineFastState.Bounded env37548 := by
  intro p hp
  have h : env37548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37545_37548 : H12AffineEnvironment.transform 13 5513 env37545 = env37548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env37545 == env37548) = true)

theorem identity37548 : scanCanonicalize (H12AffineFastState.compose env37548 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound37548 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env37549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,79130,10401,1025,8541,4160,33,73755,73857,8328,65,10708,5392,77955,2421,75222,168,257,73891,79315,512]

theorem envBound37549 : H12AffineFastState.Bounded env37549 := by
  intro p hp
  have h : env37549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37548_37549 : H12AffineEnvironment.transform 16 79130 env37548 = env37549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env37548 == env37549) = true)

theorem identity37549 : scanCanonicalize (H12AffineFastState.compose env37549 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound37549 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8323,5529,10401,1025,8541,4160,33,152,2,8328,65,10708,5392,4096,2421,1365,168,257,32,5456,512]

theorem envBound37550 : H12AffineFastState.Bounded env37550 := by
  intro p hp
  have h : env37550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37549_37550 : H12AffineEnvironment.transform 15 8323 env37549 = env37550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env37549 == env37550) = true)

theorem identity37550 : scanCanonicalize (H12AffineFastState.compose env37550 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37550 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env37551 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,4588,8540,8323,4604,10401,100,8541,4160,33,152,2,8328,65,10708,4469,4096,2421,304,168,257,32,4405,512]

theorem envBound37551 : H12AffineFastState.Bounded env37551 := by
  intro p hp
  have h : env37551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37550_37551 : H12AffineEnvironment.transform 9 101 env37550 = env37551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37550 == env37551) = true)

theorem identity37551 : scanCanonicalize (H12AffineFastState.compose env37551 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound37551 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env37552 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,6429,4588,6209,6558,4604,4540,100,6208,4160,33,152,2,6549,65,4297,4469,4096,2421,304,168,257,32,4405,512]

theorem envBound37552 : H12AffineFastState.Bounded env37552 := by
  intro p hp
  have h : env37552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37551_37552 : H12AffineEnvironment.transform 12 6429 env37551 = env37552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env37551 == env37552) = true)

theorem identity37552 : scanCanonicalize (H12AffineFastState.compose env37552 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound37552 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env37553 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,152,2437,372,2265,2310,356,292,100,2264,216,33,152,2,2317,65,81,493,152,2421,304,168,257,32,429,512]

theorem envBound37553 : H12AffineFastState.Bounded env37553 := by
  intro p hp
  have h : env37553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37552_37553 : H12AffineEnvironment.transform 11 152 env37552 = env37553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env37552 == env37553) = true)

theorem identity37553 : scanCanonicalize (H12AffineFastState.compose env37553 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound37553 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env37554 : List Nat := [2,4,8,16,32,64,128,256,512,101,428,152,41,372,373,170,356,292,100,372,216,33,152,2,161,65,81,493,152,217,304,168,257,32,429,512]

theorem envBound37554 : H12AffineFastState.Bounded env37554 := by
  intro p hp
  have h : env37554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37553_37554 : H12AffineEnvironment.transform 10 428 env37553 = env37554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env37553 == env37554) = true)

theorem identity37554 : scanCanonicalize (H12AffineFastState.compose env37554 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37554 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37555 : List Nat := [2,4,8,16,32,64,128,36,512,101,136,152,41,80,81,170,64,0,100,80,216,33,152,2,161,65,81,201,152,217,20,168,37,32,137,512]

theorem envBound37555 : H12AffineFastState.Bounded env37555 := by
  intro p hp
  have h : env37555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37554_37555 : H12AffineEnvironment.transform 7 36 env37554 = env37555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37554 == env37555) = true)

theorem identity37555 : scanCanonicalize (H12AffineFastState.compose env37555 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound37555 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env37556 : List Nat := [2,4,8,16,32,64,120,36,512,101,112,96,41,80,81,82,64,0,100,80,32,33,96,2,89,65,81,49,96,33,20,80,37,32,113,512]

theorem envBound37556 : H12AffineFastState.Bounded env37556 := by
  intro p hp
  have h : env37556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37555_37556 : H12AffineEnvironment.transform 6 120 env37555 = env37556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env37555 == env37556) = true)

theorem identity37556 : scanCanonicalize (H12AffineFastState.compose env37556 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37556 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37557 : List Nat := [2,4,8,16,1,64,89,5,512,68,81,65,8,80,81,82,64,0,69,80,1,0,65,2,89,65,81,16,65,0,20,80,4,1,80,512]

theorem envBound37557 : H12AffineFastState.Bounded env37557 := by
  intro p hp
  have h : env37557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37556_37557 : H12AffineEnvironment.transform 4 1 env37556 = env37557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37556 == env37557) = true)

theorem identity37557 : scanCanonicalize (H12AffineFastState.compose env37557 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37557 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37558 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,17,8,0,1,2,16,0,21,0,1,0,17,2,9,17,1,16,17,0,20,0,4,1,0,512]

theorem envBound37558 : H12AffineFastState.Bounded env37558 := by
  intro p hp
  have h : env37558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37557_37558 : H12AffineEnvironment.transform 5 16 env37557 = env37558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37557 == env37558) = true)

def env37559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1025,8540,4160,21928,95635,73856,8328,65,215367,5392,77954,212078,94302,169,257,73890,90202,22408]

theorem envBound37559 : H12AffineFastState.Bounded env37559 := by
  intro p hp
  have h : env37559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37544_37559 : H12AffineEnvironment.transform 14 8541 env37544 = env37559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37544 == env37559) = true)

theorem identity37559 : scanCanonicalize (H12AffineFastState.compose env37559 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound37559 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10400,1025,8540,4160,21928,153,21898,8328,65,146509,5392,17800,149860,1364,169,257,21928,5456,22408]

theorem envBound37560 : H12AffineFastState.Bounded env37560 := by
  intro p hp
  have h : env37560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37559_37560 : H12AffineEnvironment.transform 15 29962 env37559 = env37560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env37559 == env37560) = true)

theorem identity37560 : scanCanonicalize (H12AffineFastState.compose env37560 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound37560 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,5529,10400,1025,8540,4160,21928,153,21898,8328,65,10708,5392,17800,23805,1364,169,257,21928,5456,22408]

theorem envBound37561 : H12AffineFastState.Bounded env37561 := by
  intro p hp
  have h : env37561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37560_37561 : H12AffineEnvironment.transform 16 5529 env37560 = env37561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env37560 == env37561) = true)

theorem identity37561 : scanCanonicalize (H12AffineFastState.compose env37561 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound37561 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env37562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,8541,171,5529,10400,1025,8540,4160,8201,153,8235,8328,65,10708,5392,12329,10588,1364,169,257,8201,5456,8745]

theorem envBound37562 : H12AffineFastState.Bounded env37562 := by
  intro p hp
  have h : env37562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37561_37562 : H12AffineEnvironment.transform 13 13729 env37561 = env37562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env37561 == env37562) = true)

theorem identity37562 : scanCanonicalize (H12AffineFastState.compose env37562 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37562 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env37563 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13525,8233,171,5357,10400,1025,8232,4160,8201,153,8235,8328,65,10400,5220,12329,10280,1056,169,117,8201,5156,8745]

theorem envBound37563 : H12AffineFastState.Bounded env37563 := by
  intro p hp
  have h : env37563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37562_37563 : H12AffineEnvironment.transform 7 116 env37562 = env37563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37562 == env37563) = true)

theorem identity37563 : scanCanonicalize (H12AffineFastState.compose env37563 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37563 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env37564 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8233,35,5221,10280,1025,8232,4160,8201,17,8235,8192,65,10280,5220,12329,10280,1056,33,117,8201,5156,8745]

theorem envBound37564 : H12AffineFastState.Bounded env37564 := by
  intro p hp
  have h : env37564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37563_37564 : H12AffineEnvironment.transform 6 8 env37563 = env37564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37563 == env37564) = true)

theorem identity37564 : scanCanonicalize (H12AffineFastState.compose env37564 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound37564 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37565 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,4112,1124,35,5221,3173,1025,1125,4160,1092,17,1126,1101,65,3173,5220,5220,3173,1056,33,117,1092,5156,1636]

theorem envBound37565 : H12AffineFastState.Bounded env37565 := by
  intro p hp
  have h : env37565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37564_37565 : H12AffineEnvironment.transform 12 1101 env37564 = env37565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env37564 == env37565) = true)

def env37566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329761,8328,65,508091,302317,333858,236850,119043,272392,257,98814,90203,63189]

theorem envBound37566 : H12AffineFastState.Bounded env37566 := by
  intro p hp
  have h : env37566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37542_37566 : H12AffineEnvironment.transform 20 4161 env37542 = env37566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37542 == env37566) = true)

theorem identity37566 : scanCanonicalize (H12AffineFastState.compose env37566 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound37566 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,21929,351538,329761,8328,65,472175,288825,333858,223718,75223,272392,257,95530,90203,513]

theorem envBound37567 : H12AffineFastState.Bounded env37567 := by
  intro p hp
  have h : env37567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37566_37567 : H12AffineEnvironment.transform 14 29908 env37566 = env37567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env37566 == env37567) = true)

def env37568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,21793,351538,329761,8192,65,472175,288825,333858,223598,75103,272392,257,95530,90203,513]

theorem envBound37568 : H12AffineFastState.Bounded env37568 := by
  intro p hp
  have h : env37568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37567_37568 : H12AffineEnvironment.transform 6 8 env37567 = env37568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37567 == env37568) = true)

theorem identity37568 : scanCanonicalize (H12AffineFastState.compose env37568 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound37568 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env37569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,2341,1025,29789,4161,21793,87063,65796,8192,65,212298,24860,69895,223598,75103,8493,257,95530,90203,513]

theorem envBound37569 : H12AffineFastState.Bounded env37569 := by
  intro p hp
  have h : env37569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37568_37569 : H12AffineEnvironment.transform 17 2341 env37568 = env37569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env37568 == env37569) = true)

theorem identity37569 : scanCanonicalize (H12AffineFastState.compose env37569 (packedSelected [0,2,3,6,7,10,16,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound37569 : packedSelected [0,2,3,6,7,10,16,19,24] rootPS < 2^1333 := by decide +kernel

def env37570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,16401,2341,1025,29789,4161,21793,87063,65796,8192,65,97627,24860,69895,76159,75103,8493,257,95530,90203,513]

theorem envBound37570 : H12AffineFastState.Bounded env37570 := by
  intro p hp
  have h : env37570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37569_37570 : H12AffineEnvironment.transform 16 16401 env37569 = env37570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37569 == env37570) = true)

theorem identity37570 : scanCanonicalize (H12AffineFastState.compose env37570 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37570 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env37571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,16401,2341,1025,21760,4161,21793,87063,65796,349,65,89094,16449,69895,67618,66562,112,257,87159,82182,513]

theorem envBound37571 : H12AffineFastState.Bounded env37571 := by
  intro p hp
  have h : env37571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37570_37571 : H12AffineEnvironment.transform 12 349 env37570 = env37571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37570 == env37571) = true)

theorem identity37571 : scanCanonicalize (H12AffineFastState.compose env37571 (packedSelected [2,3,4,5,6,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37571 : packedSelected [2,3,4,5,6,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16401,2341,1025,21760,4161,21793,21824,83,349,65,23889,16449,4176,2421,1365,112,257,21792,16465,513]

theorem envBound37572 : H12AffineFastState.Bounded env37572 := by
  intro p hp
  have h : env37572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37571_37572 : H12AffineEnvironment.transform 15 343 env37571 = env37572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37571 == env37572) = true)

theorem identity37572 : scanCanonicalize (H12AffineFastState.compose env37572 (packedSelected [0,1,5,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37572 : packedSelected [0,1,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37573 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21620,34,16401,2128,1025,21621,4161,21588,21557,83,40,65,23588,16449,4176,2048,1056,112,116,21589,16465,513]

theorem envBound37573 : H12AffineFastState.Bounded env37573 := by
  intro p hp
  have h : env37573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37572_37573 : H12AffineEnvironment.transform 7 117 env37572 = env37573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37572 == env37573) = true)

theorem identity37573 : scanCanonicalize (H12AffineFastState.compose env37573 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound37573 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37574 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,34,5221,2128,1025,1,4161,32,65,83,40,65,2128,5173,4176,2048,1056,112,116,33,5157,513]

theorem envBound37574 : H12AffineFastState.Bounded env37574 := by
  intro p hp
  have h : env37574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37573_37574 : H12AffineEnvironment.transform 13 5236 env37573 = env37574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env37573 == env37574) = true)

theorem identity37574 : scanCanonicalize (H12AffineFastState.compose env37574 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound37574 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37575 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,40,5236,0,34,5221,1076,1025,1,4161,32,65,83,40,65,1076,5173,4176,1124,1056,112,116,33,5157,513]

theorem envBound37575 : H12AffineFastState.Bounded env37575 := by
  intro p hp
  have h : env37575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37574_37575 : H12AffineEnvironment.transform 10 1124 env37574 = env37575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env37574 == env37575) = true)

theorem identity37575 : scanCanonicalize (H12AffineFastState.compose env37575 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound37575 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env37576 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,16,40,1124,0,34,1141,1076,1025,1,81,32,65,83,40,65,1076,1061,64,1124,1056,112,116,33,1077,513]

theorem envBound37576 : H12AffineFastState.Bounded env37576 := by
  intro p hp
  have h : env37576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37575_37576 : H12AffineEnvironment.transform 11 16 env37575 = env37576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37575 == env37576) = true)

def env37577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,21792,351538,329761,8193,65,472175,288825,333858,223599,75102,272392,257,95530,90203,513]

theorem envBound37577 : H12AffineFastState.Bounded env37577 := by
  intro p hp
  have h : env37577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37567_37577 : H12AffineEnvironment.transform 6 9 env37567 = env37577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37567 == env37577) = true)

theorem identity37577 : scanCanonicalize (H12AffineFastState.compose env37577 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound37577 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,4161,21792,351538,329761,8193,65,283764,288825,333858,2420,75102,272392,257,95530,90203,513]

theorem envBound37578 : H12AffineFastState.Bounded env37578 := by
  intro p hp
  have h : env37578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37577_37578 : H12AffineEnvironment.transform 16 90139 env37577 = env37578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env37577 == env37578) = true)

theorem identity37578 : scanCanonicalize (H12AffineFastState.compose env37578 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 3344) := by decide +kernel

theorem selectedBound37578 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env37579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,3344,1025,29788,4161,21792,86050,66865,8193,65,22884,25897,70962,2420,75102,9496,257,95530,90203,513]

theorem envBound37579 : H12AffineFastState.Bounded env37579 := by
  intro p hp
  have h : env37579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37578_37579 : H12AffineEnvironment.transform 17 3344 env37578 = env37579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3344 env37578 == env37579) = true)

theorem identity37579 : scanCanonicalize (H12AffineFastState.compose env37579 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound37579 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env37580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,65536,78911,3344,1025,8312,4161,260,66566,66865,8193,65,3392,12557,70962,2420,75102,9496,257,73998,78975,513]

theorem envBound37580 : H12AffineFastState.Bounded env37580 := by
  intro p hp
  have h : env37580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37579_37580 : H12AffineEnvironment.transform 13 5156 env37579 = env37580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env37579 == env37580) = true)

theorem identity37580 : scanCanonicalize (H12AffineFastState.compose env37580 (packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound37580 : packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS < 2^1333 := by decide +kernel

def env37581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,34,13341,3344,1025,8312,4161,260,1060,1299,8193,65,3392,12557,5392,2420,9596,9496,257,8492,13405,513]

theorem envBound37581 : H12AffineFastState.Bounded env37581 := by
  intro p hp
  have h : env37581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37580_37581 : H12AffineEnvironment.transform 15 34 env37580 = env37581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env37580 == env37581) = true)

theorem identity37581 : scanCanonicalize (H12AffineFastState.compose env37581 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound37581 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env37582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5156,1345,34,4389,3344,1025,1344,4161,260,1060,1299,1337,65,3392,5173,5392,2420,68,32,257,1044,4453,513]

theorem envBound37582 : H12AffineFastState.Bounded env37582 := by
  intro p hp
  have h : env37582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37581_37582 : H12AffineEnvironment.transform 12 1336 env37581 = env37582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env37581 == env37582) = true)

theorem identity37582 : scanCanonicalize (H12AffineFastState.compose env37582 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37582 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37583 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,5156,1124,34,4096,3125,1025,1125,4161,33,1060,1078,1052,65,3173,5173,5173,2129,68,32,36,1044,4160,513]

theorem envBound37583 : H12AffineFastState.Bounded env37583 := by
  intro p hp
  have h : env37583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37582_37583 : H12AffineEnvironment.transform 7 37 env37582 = env37583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37582 == env37583) = true)

theorem identity37583 : scanCanonicalize (H12AffineFastState.compose env37583 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound37583 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env37584 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,1572,1053,512,1124,34,1572,3125,1025,1125,1637,33,1060,1078,1052,65,3173,529,529,2129,68,32,36,1044,1636,513]

theorem envBound37584 : H12AffineFastState.Bounded env37584 := by
  intro p hp
  have h : env37584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37583_37584 : H12AffineEnvironment.transform 11 1572 env37583 = env37584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env37583 == env37584) = true)

theorem identity37584 : scanCanonicalize (H12AffineFastState.compose env37584 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound37584 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37585 : List Nat := [2,4,8,16,32,64,9,37,512,1024,577,1572,1053,512,1124,34,1572,1652,1025,1125,1637,33,1060,1078,1052,65,1572,529,529,528,68,32,36,1044,1636,513]

theorem envBound37585 : H12AffineFastState.Bounded env37585 := by
  intro p hp
  have h : env37585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37584_37585 : H12AffineEnvironment.transform 10 577 env37584 = env37585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env37584 == env37585) = true)

theorem identity37585 : scanCanonicalize (H12AffineFastState.compose env37585 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound37585 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env37586 : List Nat := [2,4,8,16,32,64,9,37,512,36,577,512,57,512,64,34,512,592,37,65,577,33,0,18,56,65,512,529,529,528,68,32,36,48,576,513]

theorem envBound37586 : H12AffineFastState.Bounded env37586 := by
  intro p hp
  have h : env37586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37585_37586 : H12AffineEnvironment.transform 9 36 env37585 = env37586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env37585 == env37586) = true)

theorem identity37586 : scanCanonicalize (H12AffineFastState.compose env37586 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound37586 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37587 : List Nat := [2,4,8,16,32,64,9,37,81,36,16,81,57,81,64,34,81,1,37,65,16,33,0,18,56,65,81,64,64,65,68,32,36,48,17,80]

theorem envBound37587 : H12AffineFastState.Bounded env37587 := by
  intro p hp
  have h : env37587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37586_37587 : H12AffineEnvironment.transform 8 81 env37586 = env37587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env37586 == env37587) = true)

theorem identity37587 : scanCanonicalize (H12AffineFastState.compose env37587 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37587 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env37588 : List Nat := [2,4,8,16,32,17,9,37,0,36,16,0,57,0,17,34,0,1,37,16,16,33,0,18,56,16,0,17,17,16,21,32,36,48,17,1]

theorem envBound37588 : H12AffineFastState.Bounded env37588 := by
  intro p hp
  have h : env37588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37587_37588 : H12AffineEnvironment.transform 5 17 env37587 = env37588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37587 == env37588) = true)

theorem identity37588 : scanCanonicalize (H12AffineFastState.compose env37588 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37588 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37589 : List Nat := [2,4,8,0,32,1,9,37,0,36,0,0,41,0,1,34,0,1,37,0,0,33,0,2,40,0,0,1,1,0,5,32,36,32,1,1]

theorem envBound37589 : H12AffineFastState.Bounded env37589 := by
  intro p hp
  have h : env37589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37588_37589 : H12AffineEnvironment.transform 3 0 env37588 = env37589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37588 == env37589) = true)

def env37590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431073,8328,65,2609403,302316,333858,2329971,119042,2373704,257,2199998,2191387,63188]

theorem envBound37590 : H12AffineFastState.Bounded env37590 := by
  intro p hp
  have h : env37590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37541_37590 : H12AffineEnvironment.transform 23 2431073 env37541 = env37590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env37541 == env37590) = true)

def env37591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329761,8328,65,508091,302316,333858,236851,119042,272392,257,98814,90203,63188]

theorem envBound37591 : H12AffineFastState.Bounded env37591 := by
  intro p hp
  have h : env37591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37590_37591 : H12AffineEnvironment.transform 20 4160 env37590 = env37591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37590 == env37591) = true)

def env37592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,21928,95635,73857,8328,65,256027,46156,77954,236851,119042,168,257,98814,90203,63188]

theorem envBound37592 : H12AffineFastState.Bounded env37592 := by
  intro p hp
  have h : env37592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37591_37592 : H12AffineEnvironment.transform 17 10400 env37591 = env37592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37591 == env37592) = true)

theorem identity37592 : scanCanonicalize (H12AffineFastState.compose env37592 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound37592 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,10400,1025,32769,4160,21928,16,21762,8328,65,171416,46156,17665,190640,42113,168,257,62589,5592,63188]

theorem envBound37593 : H12AffineFastState.Bounded env37593 := by
  intro p hp
  have h : env37593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37592_37593 : H12AffineEnvironment.transform 15 30083 env37592 = env37593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env37592 == env37593) = true)

theorem identity37593 : scanCanonicalize (H12AffineFastState.compose env37593 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 16876) := by decide +kernel

theorem selectedBound37593 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env37594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,16876,10400,1025,32769,4160,21928,16,21762,8328,65,56436,46156,17665,43356,42113,168,257,62589,5592,63188]

theorem envBound37594 : H12AffineFastState.Bounded env37594 := by
  intro p hp
  have h : env37594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37593_37594 : H12AffineEnvironment.transform 16 16876 env37593 = env37594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16876 env37593 == env37594) = true)

theorem identity37594 : scanCanonicalize (H12AffineFastState.compose env37594 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound37594 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env37595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,5220,10400,1025,32769,4160,32,16,138,8328,65,35324,46156,4233,43356,42113,168,257,41461,5592,41820]

theorem envBound37595 : H12AffineFastState.Bounded env37595 := by
  intro p hp
  have h : env37595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37594_37595 : H12AffineEnvironment.transform 13 5512 env37594 = env37595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env37594 == env37595) = true)

theorem identity37595 : scanCanonicalize (H12AffineFastState.compose env37595 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37595 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,32768,263,5220,2476,1025,32769,4160,32,16,138,388,65,35324,38208,4233,34896,34189,168,257,33017,5592,33360]

theorem envBound37596 : H12AffineFastState.Bounded env37596 := by
  intro p hp
  have h : env37596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37595_37596 : H12AffineEnvironment.transform 12 268 env37595 = env37596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37595 == env37596) = true)

theorem identity37596 : scanCanonicalize (H12AffineFastState.compose env37596 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37596 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env37597 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5373,32768,114,5220,2265,1025,32769,4160,32,16,138,241,65,34953,37941,4233,34896,34040,168,116,33017,5293,33360]

theorem envBound37597 : H12AffineFastState.Bounded env37597 := by
  intro p hp
  have h : env37597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37596_37597 : H12AffineEnvironment.transform 7 117 env37596 = env37597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37596 == env37597) = true)

theorem identity37597 : scanCanonicalize (H12AffineFastState.compose env37597 (packedSelected [1,2,4,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound37597 : packedSelected [1,2,4,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env37598 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5373,1124,114,5220,2265,1025,1125,4160,32,16,138,241,65,3309,4177,4233,3124,156,168,116,1181,5293,1588]

theorem envBound37598 : H12AffineFastState.Bounded env37598 := by
  intro p hp
  have h : env37598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37597_37598 : H12AffineEnvironment.transform 14 1124 env37597 = env37598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env37597 == env37598) = true)

theorem identity37598 : scanCanonicalize (H12AffineFastState.compose env37598 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37598 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env37599 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,1124,114,5220,2128,1025,1125,4160,32,16,3,120,65,3172,4177,4096,3124,21,33,116,1044,5156,1588]

theorem envBound37599 : H12AffineFastState.Bounded env37599 := by
  intro p hp
  have h : env37599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37598_37599 : H12AffineEnvironment.transform 6 9 env37598 = env37599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37598 == env37599) = true)

theorem identity37599 : scanCanonicalize (H12AffineFastState.compose env37599 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound37599 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env37600 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,121,4112,0,114,4096,2128,101,1,4160,32,16,3,120,65,2048,4177,4096,2128,21,33,116,112,4160,592]

theorem envBound37600 : H12AffineFastState.Bounded env37600 := by
  intro p hp
  have h : env37600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37599_37600 : H12AffineEnvironment.transform 9 100 env37599 = env37600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env37599 == env37600) = true)

theorem identity37600 : scanCanonicalize (H12AffineFastState.compose env37600 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37600 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37601 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4112,0,35,4096,2049,52,1,4113,32,16,3,41,16,2048,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound37601 : H12AffineFastState.Bounded env37601 := by
  intro p hp
  have h : env37601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37600_37601 : H12AffineEnvironment.transform 5 17 env37600 = env37601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37600 == env37601) = true)

theorem identity37601 : scanCanonicalize (H12AffineFastState.compose env37601 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound37601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37602 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,0,40,16,0,35,0,2049,52,1,17,32,16,3,41,16,2048,0,0,2049,21,33,37,33,17,513]

theorem envBound37602 : H12AffineFastState.Bounded env37602 := by
  intro p hp
  have h : env37602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37601_37602 : H12AffineEnvironment.transform 11 0 env37601 = env37602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env37601 == env37602) = true)

theorem identity37602 : scanCanonicalize (H12AffineFastState.compose env37602 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound37602 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37603 : List Nat := [2,4,8,16,32,17,9,36,512,53,538,0,40,16,0,35,0,539,52,1,17,32,16,3,41,16,538,0,0,539,21,33,37,33,17,513]

theorem envBound37603 : H12AffineFastState.Bounded env37603 := by
  intro p hp
  have h : env37603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37602_37603 : H12AffineEnvironment.transform 10 538 env37602 = env37603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env37602 == env37603) = true)

theorem identity37603 : scanCanonicalize (H12AffineFastState.compose env37603 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37603 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37604 : List Nat := [2,4,8,16,32,17,9,36,0,53,26,0,40,16,0,35,0,27,52,1,17,32,16,3,41,16,26,0,0,27,21,33,37,33,17,1]

theorem envBound37604 : H12AffineFastState.Bounded env37604 := by
  intro p hp
  have h : env37604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37603_37604 : H12AffineEnvironment.transform 8 0 env37603 = env37604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37603 == env37604) = true)

theorem identity37604 : scanCanonicalize (H12AffineFastState.compose env37604 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37604 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37605 : List Nat := [2,4,8,0,32,1,9,36,0,37,10,0,40,0,0,35,0,11,36,1,1,32,0,3,41,0,10,0,0,11,5,33,37,33,1,1]

theorem envBound37605 : H12AffineFastState.Bounded env37605 := by
  intro p hp
  have h : env37605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37604_37605 : H12AffineEnvironment.transform 3 0 env37604 = env37605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37604 == env37605) = true)

theorem identity37605 : scanCanonicalize (H12AffineFastState.compose env37605 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37605 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37606 : List Nat := [2,4,3,0,32,1,2,36,0,37,1,0,35,0,0,35,0,0,36,1,1,32,0,3,34,0,1,0,0,0,5,33,37,33,1,1]

theorem envBound37606 : H12AffineFastState.Bounded env37606 := by
  intro p hp
  have h : env37606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37605_37606 : H12AffineEnvironment.transform 2 3 env37605 = env37606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37605 == env37606) = true)

def env37607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,21928,95634,73856,8328,65,256026,46157,77955,236851,119042,169,257,98814,90203,63188]

theorem envBound37607 : H12AffineFastState.Bounded env37607 := by
  intro p hp
  have h : env37607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37591_37607 : H12AffineEnvironment.transform 17 10401 env37591 = env37607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37591 == env37607) = true)

theorem identity37607 : scanCanonicalize (H12AffineFastState.compose env37607 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37607 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1025,29908,4160,21928,95634,73856,8328,65,203983,16536,77955,223718,75223,169,257,95531,90203,513]

theorem envBound37608 : H12AffineFastState.Bounded env37608 := by
  intro p hp
  have h : env37608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37607_37608 : H12AffineEnvironment.transform 14 29909 env37607 = env37608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37607 == env37608) = true)

def env37609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1025,8660,4160,168,73874,73856,8328,65,203983,5528,77955,212198,75223,169,257,73771,79195,513]

theorem envBound37609 : H12AffineFastState.Bounded env37609 := by
  intro p hp
  have h : env37609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37608_37609 : H12AffineEnvironment.transform 13 5376 env37608 = env37609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37608 == env37609) = true)

theorem identity37609 : scanCanonicalize (H12AffineFastState.compose env37609 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound37609 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79131,10401,1025,8660,4160,168,73874,73856,8328,65,10708,5528,77955,2557,75223,169,257,73771,79195,513]

theorem envBound37610 : H12AffineFastState.Bounded env37610 := by
  intro p hp
  have h : env37610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37609_37610 : H12AffineEnvironment.transform 16 79131 env37609 = env37610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env37609 == env37610) = true)

theorem identity37610 : scanCanonicalize (H12AffineFastState.compose env37610 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37610 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env37611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,343,13388,10401,1025,8660,4160,168,8645,8663,8328,65,10708,5528,12756,2557,9344,169,257,8572,13324,513]

theorem envBound37611 : H12AffineFastState.Bounded env37611 := by
  intro p hp
  have h : env37611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37610_37611 : H12AffineEnvironment.transform 15 343 env37610 = env37611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37610 == env37611) = true)

theorem identity37611 : scanCanonicalize (H12AffineFastState.compose env37611 (packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37611 : packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env37612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,263,13340,10401,1025,8580,4112,168,8597,8583,8328,17,10628,5528,12676,2477,9344,169,257,8492,13324,513]

theorem envBound37612 : H12AffineFastState.Bounded env37612 := by
  intro p hp
  have h : env37612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37611_37612 : H12AffineEnvironment.transform 5 16 env37611 = env37612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37611 == env37612) = true)

def env37613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1025,8661,4160,169,73875,73856,8328,65,203983,5529,77955,212199,75223,169,257,73770,79194,513]

theorem envBound37613 : H12AffineFastState.Bounded env37613 := by
  intro p hp
  have h : env37613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37608_37613 : H12AffineEnvironment.transform 13 5377 env37608 = env37613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37608 == env37613) = true)

theorem identity37613 : scanCanonicalize (H12AffineFastState.compose env37613 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37613 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1025,8541,4160,33,73755,73736,8192,65,203847,5393,77835,212079,75103,33,257,73770,79194,513]

theorem envBound37614 : H12AffineFastState.Bounded env37614 := by
  intro p hp
  have h : env37614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37613_37614 : H12AffineEnvironment.transform 6 8 env37613 = env37614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37613 == env37614) = true)

theorem identity37614 : scanCanonicalize (H12AffineFastState.compose env37614 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37614 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10281,1025,8541,4160,33,16,3,8192,65,146508,5393,4096,138340,1364,33,257,33,5457,513]

theorem envBound37615 : H12AffineFastState.Bounded env37615 := by
  intro p hp
  have h : env37615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37614_37615 : H12AffineEnvironment.transform 15 8203 env37614 = env37615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37614 == env37615) = true)

theorem identity37615 : scanCanonicalize (H12AffineFastState.compose env37615 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound37615 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13388,10281,1025,8541,4160,33,16,3,8192,65,2048,5393,4096,10280,1364,33,257,33,5457,513]

theorem envBound37616 : H12AffineFastState.Bounded env37616 := by
  intro p hp
  have h : env37616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37615_37616 : H12AffineEnvironment.transform 16 13388 env37615 = env37616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env37615 == env37616) = true)

theorem identity37616 : scanCanonicalize (H12AffineFastState.compose env37616 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37616 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37617 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5157,8312,8203,13388,10281,1025,8313,4160,33,16,3,8192,65,2048,5173,4096,10280,1136,33,37,33,5237,513]

theorem envBound37617 : H12AffineFastState.Bounded env37617 := by
  intro p hp
  have h : env37617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37616_37617 : H12AffineEnvironment.transform 7 36 env37616 = env37617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37616 == env37617) = true)

def env37618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329760,8328,65,508090,302316,333858,236850,119042,272393,257,98815,90202,63188]

theorem envBound37618 : H12AffineFastState.Bounded env37618 := by
  intro p hp
  have h : env37618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37590_37618 : H12AffineEnvironment.transform 20 4161 env37590 = env37618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37590 == env37618) = true)

theorem identity37618 : scanCanonicalize (H12AffineFastState.compose env37618 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound37618 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21929,73754,95496,8328,65,245138,57796,91402,236850,119042,21793,257,98815,90202,63188]

theorem envBound37619 : H12AffineFastState.Bounded env37619 := by
  intro p hp
  have h : env37619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37618_37619 : H12AffineEnvironment.transform 17 32040 env37618 = env37619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env37618 == env37619) = true)

def env37620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10400,1025,32769,4161,33,73754,73856,8328,65,245138,46156,77954,236850,99466,169,257,98815,79314,41820]

theorem envBound37620 : H12AffineFastState.Bounded env37620 := by
  intro p hp
  have h : env37620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37619_37620 : H12AffineEnvironment.transform 13 5512 env37619 = env37620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env37619 == env37620) = true)

theorem identity37620 : scanCanonicalize (H12AffineFastState.compose env37620 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound37620 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env37621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,5392,10400,1025,32769,4161,33,73754,73856,8328,65,108674,46156,77954,100386,99466,169,257,98815,79314,41820]

theorem envBound37621 : H12AffineFastState.Bounded env37621 := by
  intro p hp
  have h : env37621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37620_37621 : H12AffineEnvironment.transform 16 5392 env37620 = env37621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env37620 == env37621) = true)

theorem identity37621 : scanCanonicalize (H12AffineFastState.compose env37621 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound37621 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,40970,5392,10400,1025,32769,4161,33,32784,32906,8328,65,2184,46156,37000,10280,9344,169,257,8693,38360,41820]

theorem envBound37622 : H12AffineFastState.Bounded env37622 := by
  intro p hp
  have h : env37622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37621_37622 : H12AffineEnvironment.transform 15 40970 env37621 = env37622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env37621 == env37622) = true)

theorem identity37622 : scanCanonicalize (H12AffineFastState.compose env37622 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound37622 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env37623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8661,479,5392,10400,1025,8660,4161,33,8645,8543,8328,65,2184,5529,12637,10280,9344,169,257,8693,13325,649]

theorem envBound37623 : H12AffineFastState.Bounded env37623 := by
  intro p hp
  have h : env37623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37622_37623 : H12AffineEnvironment.transform 14 8661 env37622 = env37623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env37622 == env37623) = true)

theorem identity37623 : scanCanonicalize (H12AffineFastState.compose env37623 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37623 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,1,479,5392,2420,1025,0,4161,33,17,139,348,65,2184,5529,4233,2556,1364,169,257,33,5593,649]

theorem envBound37624 : H12AffineFastState.Bounded env37624 := by
  intro p hp
  have h : env37624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37623_37624 : H12AffineEnvironment.transform 12 468 env37623 = env37624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37623 == env37624) = true)

theorem identity37624 : scanCanonicalize (H12AffineFastState.compose env37624 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37624 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env37625 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,240,5292,1,251,5172,2128,1025,0,4161,33,17,139,120,65,2184,5309,4233,2264,1136,169,37,33,5373,649]

theorem envBound37625 : H12AffineFastState.Bounded env37625 := by
  intro p hp
  have h : env37625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37624_37625 : H12AffineEnvironment.transform 7 36 env37624 = env37625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37624 == env37625) = true)

theorem identity37625 : scanCanonicalize (H12AffineFastState.compose env37625 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37625 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37626 : List Nat := [2,4,8,16,32,48,128,36,512,1024,2048,4096,128,5292,1,139,5172,2080,1025,0,4145,33,17,139,8,49,2184,5309,4233,2216,1024,169,37,33,5261,649]

theorem envBound37626 : H12AffineFastState.Bounded env37626 := by
  intro p hp
  have h : env37626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37625_37626 : H12AffineEnvironment.transform 5 48 env37625 = env37626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37625 == env37626) = true)

theorem identity37626 : scanCanonicalize (H12AffineFastState.compose env37626 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound37626 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37627 : List Nat := [2,4,8,16,32,48,128,36,512,21,2048,4096,128,4281,1,139,4129,2080,20,0,4145,33,17,139,8,49,2184,4264,4233,2216,21,169,37,33,4248,649]

theorem envBound37627 : H12AffineFastState.Bounded env37627 := by
  intro p hp
  have h : env37627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37626_37627 : H12AffineEnvironment.transform 9 21 env37626 = env37627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37626 == env37627) = true)

theorem identity37627 : scanCanonicalize (H12AffineFastState.compose env37627 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37628 : List Nat := [2,4,8,16,1,17,128,5,512,21,2048,4096,128,4248,1,139,4096,2049,20,0,4112,0,17,139,8,16,2184,4233,4233,2185,21,136,4,0,4248,649]

theorem envBound37628 : H12AffineFastState.Bounded env37628 := by
  intro p hp
  have h : env37628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37627_37628 : H12AffineEnvironment.transform 4 1 env37627 = env37628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37627 == env37628) = true)

theorem identity37628 : scanCanonicalize (H12AffineFastState.compose env37628 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37628 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37629 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4113,1,2,4096,2049,20,0,4112,0,17,2,8,16,2049,4096,4096,2048,21,1,4,0,4113,512]

theorem envBound37629 : H12AffineFastState.Bounded env37629 := by
  intro p hp
  have h : env37629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37628_37629 : H12AffineEnvironment.transform 6 9 env37628 = env37629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37628 == env37629) = true)

theorem identity37629 : scanCanonicalize (H12AffineFastState.compose env37629 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound37629 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37630 : List Nat := [2,4,8,16,1,17,9,5,512,21,512,4096,9,4113,1,2,4096,513,20,0,4112,0,17,2,8,16,513,4096,4096,512,21,1,4,0,4113,512]

theorem envBound37630 : H12AffineFastState.Bounded env37630 := by
  intro p hp
  have h : env37630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37629_37630 : H12AffineEnvironment.transform 10 512 env37629 = env37630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env37629 == env37630) = true)

theorem identity37630 : scanCanonicalize (H12AffineFastState.compose env37630 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 533) := by decide +kernel

theorem selectedBound37630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37631 : List Nat := [2,4,8,16,1,17,9,5,512,21,512,533,9,516,1,2,533,513,20,0,517,0,17,2,8,16,513,533,533,512,21,1,4,0,516,512]

theorem envBound37631 : H12AffineFastState.Bounded env37631 := by
  intro p hp
  have h : env37631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37630_37631 : H12AffineEnvironment.transform 11 533 env37630 = env37631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 533 env37630 == env37631) = true)

theorem identity37631 : scanCanonicalize (H12AffineFastState.compose env37631 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37631 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37632 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,20,9,5,1,2,20,0,20,0,4,0,17,2,8,16,0,20,20,1,21,1,4,0,5,1]

theorem envBound37632 : H12AffineFastState.Bounded env37632 := by
  intro p hp
  have h : env37632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37631_37632 : H12AffineEnvironment.transform 8 1 env37631 = env37632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37631 == env37632) = true)

theorem identity37632 : scanCanonicalize (H12AffineFastState.compose env37632 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound37632 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37633 : List Nat := [2,4,8,5,1,4,9,5,1,0,1,1,9,5,1,2,1,0,1,0,4,0,4,2,8,5,0,1,1,1,0,1,4,0,5,1]

theorem envBound37633 : H12AffineFastState.Bounded env37633 := by
  intro p hp
  have h : env37633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37632_37633 : H12AffineEnvironment.transform 3 5 env37632 = env37633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37632 == env37633) = true)

def env37634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10401,1025,32769,4161,32,73754,73857,8328,65,245138,46157,77955,236850,99467,168,257,98815,79315,41821]

theorem envBound37634 : H12AffineFastState.Bounded env37634 := by
  intro p hp
  have h : env37634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37619_37634 : H12AffineEnvironment.transform 13 5513 env37619 = env37634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env37619 == env37634) = true)

def env37635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4161,32,73754,73737,8192,65,245018,46157,77835,236850,99331,32,257,98679,79195,41821]

theorem envBound37635 : H12AffineFastState.Bounded env37635 := by
  intro p hp
  have h : env37635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37634_37635 : H12AffineEnvironment.transform 6 8 env37634 = env37635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37634 == env37635) = true)

theorem identity37635 : scanCanonicalize (H12AffineFastState.compose env37635 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound37635 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env37636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13340,10281,1025,32769,4161,32,73754,73737,8192,65,100614,46157,77835,108846,99331,32,257,98679,79195,41821]

theorem envBound37636 : H12AffineFastState.Bounded env37636 := by
  intro p hp
  have h : env37636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37635_37636 : H12AffineEnvironment.transform 16 13340 env37635 = env37636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env37635 == env37636) = true)

theorem identity37636 : scanCanonicalize (H12AffineFastState.compose env37636 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37636 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env37637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,13340,10281,1025,8541,4161,32,73754,73737,8192,65,75866,5393,77835,67698,75103,32,257,73771,79195,513]

theorem envBound37637 : H12AffineFastState.Bounded env37637 := by
  intro p hp
  have h : env37637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37636_37637 : H12AffineEnvironment.transform 14 8540 env37636 = env37637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37636 == env37637) = true)

theorem identity37637 : scanCanonicalize (H12AffineFastState.compose env37637 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37637 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37638 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,65536,13340,10281,1025,8460,4112,32,73754,73737,8192,16,75787,5393,77835,67619,75022,32,257,73771,79114,513]

theorem envBound37638 : H12AffineFastState.Bounded env37638 := by
  intro p hp
  have h : env37638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37637_37638 : H12AffineEnvironment.transform 5 17 env37637 = env37638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37637 == env37638) = true)

theorem identity37638 : scanCanonicalize (H12AffineFastState.compose env37638 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound37638 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env37639 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,262,13340,10281,1025,8460,4112,32,8476,8463,8192,16,10509,5393,12557,2341,9224,32,257,8493,13324,513]

theorem envBound37639 : H12AffineFastState.Bounded env37639 := by
  intro p hp
  have h : env37639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37638_37639 : H12AffineEnvironment.transform 15 262 env37638 = env37639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env37638 == env37639) = true)

theorem identity37639 : scanCanonicalize (H12AffineFastState.compose env37639 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound37639 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37640 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,8192,1,8461,262,8476,10281,1025,8460,1296,32,8476,8463,8192,16,10509,17,9229,2341,9224,32,257,8493,8460,513]

theorem envBound37640 : H12AffineFastState.Bounded env37640 := by
  intro p hp
  have h : env37640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37639_37640 : H12AffineEnvironment.transform 11 1280 env37639 = env37640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env37639 == env37640) = true)

theorem identity37640 : scanCanonicalize (H12AffineFastState.compose env37640 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37640 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37641 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,269,1,0,262,17,2340,1025,1,1296,32,17,2,269,16,2048,17,1280,2341,1285,32,257,32,1,513]

theorem envBound37641 : H12AffineFastState.Bounded env37641 := by
  intro p hp
  have h : env37641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37640_37641 : H12AffineEnvironment.transform 12 269 env37640 = env37641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37640 == env37641) = true)

theorem identity37641 : scanCanonicalize (H12AffineFastState.compose env37641 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37642 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1280,269,1,0,262,17,2309,1025,1,1296,1,17,2,269,16,2048,17,1280,2308,1285,1,257,1,1,513]

theorem envBound37642 : H12AffineFastState.Bounded env37642 := by
  intro p hp
  have h : env37642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37641_37642 : H12AffineEnvironment.transform 4 1 env37641 = env37642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37641 == env37642) = true)

theorem identity37642 : scanCanonicalize (H12AffineFastState.compose env37642 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound37642 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37643 : List Nat := [2,4,8,16,1,17,8,256,512,1024,513,1280,269,1,0,262,17,772,1025,1,1296,1,17,2,269,16,513,17,1280,773,1285,1,257,1,1,513]

theorem envBound37643 : H12AffineFastState.Bounded env37643 := by
  intro p hp
  have h : env37643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37642_37643 : H12AffineEnvironment.transform 10 513 env37642 = env37643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env37642 == env37643) = true)

theorem identity37643 : scanCanonicalize (H12AffineFastState.compose env37643 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37643 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37644 : List Nat := [2,4,8,1,1,0,8,256,512,1024,513,1280,269,1,0,262,0,772,1025,1,1281,1,0,2,269,1,513,0,1280,773,1285,1,257,1,1,513]

theorem envBound37644 : H12AffineFastState.Bounded env37644 := by
  intro p hp
  have h : env37644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37643_37644 : H12AffineEnvironment.transform 3 1 env37643 = env37644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37643 == env37644) = true)

theorem identity37644 : scanCanonicalize (H12AffineFastState.compose env37644 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound37644 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37645 : List Nat := [2,4,8,1,1,0,8,256,260,1024,261,1280,269,1,0,262,0,0,1025,1,1281,1,0,2,269,1,261,0,1280,1,1285,1,257,1,1,261]

theorem envBound37645 : H12AffineFastState.Bounded env37645 := by
  intro p hp
  have h : env37645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37644_37645 : H12AffineEnvironment.transform 8 260 env37644 = env37645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env37644 == env37645) = true)

def env37646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4161,32,73754,73736,8193,65,245019,46157,77834,236850,99330,33,257,98678,79194,41821]

theorem envBound37646 : H12AffineFastState.Bounded env37646 := by
  intro p hp
  have h : env37646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37634_37646 : H12AffineEnvironment.transform 6 9 env37634 = env37646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37634 == env37646) = true)

theorem identity37646 : scanCanonicalize (H12AffineFastState.compose env37646 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1025,8541,4161,32,73754,73736,8193,65,203847,5393,77834,212078,75102,33,257,73770,79194,513]

theorem envBound37647 : H12AffineFastState.Bounded env37647 := by
  intro p hp
  have h : env37647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37646_37647 : H12AffineEnvironment.transform 14 8540 env37646 = env37647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37646 == env37647) = true)

theorem identity37647 : scanCanonicalize (H12AffineFastState.compose env37647 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound37647 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5376,7205,65536,131072,5457,1025,7204,4161,32,73059,73073,7544,65,203847,5393,68979,196887,71719,33,257,73043,67619,513]

theorem envBound37648 : H12AffineFastState.Bounded env37648 := by
  intro p hp
  have h : env37648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37647_37648 : H12AffineEnvironment.transform 12 7545 env37647 = env37648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env37647 == env37648) = true)

theorem identity37648 : scanCanonicalize (H12AffineFastState.compose env37648 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 69746) := by decide +kernel

theorem selectedBound37648 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env37649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5376,7205,65536,69746,5457,1025,7204,4161,32,73059,73073,7544,65,3125,5393,68979,4453,71719,33,257,73043,67619,513]

theorem envBound37649 : H12AffineFastState.Bounded env37649 := by
  intro p hp
  have h : env37649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37648_37649 : H12AffineEnvironment.transform 16 69746 env37648 = env37649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69746 env37648 == env37649) = true)

theorem identity37649 : scanCanonicalize (H12AffineFastState.compose env37649 (packedSelected [0,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound37649 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env37650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,120,2049,292,65536,68979,2128,1025,293,3392,32,65634,65648,121,65,3125,2064,68979,3172,66854,33,257,65618,67619,513]

theorem envBound37650 : H12AffineFastState.Bounded env37650 := by
  intro p hp
  have h : env37650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37649_37650 : H12AffineEnvironment.transform 11 3329 env37649 = env37650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env37649 == env37650) = true)

theorem identity37650 : scanCanonicalize (H12AffineFastState.compose env37650 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37650 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env37651 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2049,80,65536,68615,2128,1025,81,3124,32,65634,65648,121,65,3125,2064,68615,3172,66642,33,117,65618,67619,513]

theorem envBound37651 : H12AffineFastState.Bounded env37651 := by
  intro p hp
  have h : env37651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37650_37651 : H12AffineEnvironment.transform 7 116 env37650 = env37651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37650 == env37651) = true)

theorem identity37651 : scanCanonicalize (H12AffineFastState.compose env37651 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37651 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env37652 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,120,2049,80,65536,67682,2128,100,81,2129,32,65634,65648,121,65,2128,2064,67682,2049,65591,33,117,65618,67619,513]

theorem envBound37652 : H12AffineFastState.Bounded env37652 := by
  intro p hp
  have h : env37652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37651_37652 : H12AffineEnvironment.transform 9 101 env37651 = env37652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37651 == env37652) = true)

theorem identity37652 : scanCanonicalize (H12AffineFastState.compose env37652 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37652 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env37653 : List Nat := [2,4,8,16,32,64,9,116,512,101,0,16,120,1,80,65536,65634,80,100,81,81,32,65634,65648,121,65,80,16,65634,1,65591,33,117,65618,65571,513]

theorem envBound37653 : H12AffineFastState.Bounded env37653 := by
  intro p hp
  have h : env37653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37652_37653 : H12AffineEnvironment.transform 10 0 env37652 = env37653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37652 == env37653) = true)

theorem identity37653 : scanCanonicalize (H12AffineFastState.compose env37653 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound37653 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37654 : List Nat := [2,4,8,16,32,64,9,116,59,101,0,16,120,1,80,65536,65634,80,100,81,81,32,65634,65648,121,65,80,16,65634,1,65591,33,117,65618,65571,58]

theorem envBound37654 : H12AffineFastState.Bounded env37654 := by
  intro p hp
  have h : env37654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37653_37654 : H12AffineEnvironment.transform 8 59 env37653 = env37654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env37653 == env37654) = true)

theorem identity37654 : scanCanonicalize (H12AffineFastState.compose env37654 (packedSelected [0,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 88) := by decide +kernel

theorem selectedBound37654 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env37655 : List Nat := [2,4,8,16,32,64,9,116,59,101,0,16,120,1,80,88,58,80,100,81,81,32,58,40,121,65,80,16,58,1,111,33,117,10,123,58]

theorem envBound37655 : H12AffineFastState.Bounded env37655 := by
  intro p hp
  have h : env37655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37654_37655 : H12AffineEnvironment.transform 15 88 env37654 = env37655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 88 env37654 == env37655) = true)

theorem identity37655 : scanCanonicalize (H12AffineFastState.compose env37655 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37655 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env37656 : List Nat := [2,4,8,16,10,64,9,94,17,79,0,16,82,1,80,88,16,80,78,81,81,10,16,2,83,65,80,16,16,1,69,11,95,10,81,16]

theorem envBound37656 : H12AffineFastState.Bounded env37656 := by
  intro p hp
  have h : env37656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37655_37656 : H12AffineEnvironment.transform 4 10 env37655 = env37656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37655 == env37656) = true)

def env37657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,16777216,8328,65,16959643,18973837,333858,2329971,19188067,16850984,257,17074655,17066106,19263157]

theorem envBound37657 : H12AffineFastState.Bounded env37657 := by
  intro p hp
  have h : env37657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37540_37657 : H12AffineEnvironment.transform 21 2115049 env37540 = env37657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env37540 == env37657) = true)

def env37658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431072,8328,65,2609403,302317,333858,2329971,119043,2373704,257,2199999,2191386,63189]

theorem envBound37658 : H12AffineFastState.Bounded env37658 := by
  intro p hp
  have h : env37658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37657_37658 : H12AffineEnvironment.transform 23 2431072 env37657 = env37658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env37657 == env37658) = true)

def env37659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329760,8328,65,508091,302317,333858,236851,119043,272392,257,98815,90202,63189]

theorem envBound37659 : H12AffineFastState.Bounded env37659 := by
  intro p hp
  have h : env37659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37658_37659 : H12AffineEnvironment.transform 20 4160 env37658 = env37659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37658 == env37659) = true)

theorem identity37659 : scanCanonicalize (H12AffineFastState.compose env37659 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37659 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,21929,297452,318719,8328,65,398436,302317,314621,149996,1500,272392,257,21792,46213,63189]

theorem envBound37660 : H12AffineFastState.Bounded env37660 := by
  intro p hp
  have h : env37660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37659_37660 : H12AffineEnvironment.transform 15 54495 env37659 = env37660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37659 == env37660) = true)

def env37661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4160,21929,41412,62679,8328,65,146508,46277,58581,149996,1500,32,257,21792,46213,63189]

theorem envBound37661 : H12AffineFastState.Bounded env37661 := by
  intro p hp
  have h : env37661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37660_37661 : H12AffineEnvironment.transform 17 10280 env37660 = env37661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env37660 == env37661) = true)

theorem identity37661 : scanCanonicalize (H12AffineFastState.compose env37661 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound37661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,131072,10280,1025,8660,4160,21929,17,21762,8328,65,146508,5392,17664,149996,1500,32,257,21792,5456,22272]

theorem envBound37662 : H12AffineFastState.Bounded env37662 := by
  intro p hp
  have h : env37662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37661_37662 : H12AffineEnvironment.transform 14 8661 env37661 = env37662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env37661 == env37662) = true)

theorem identity37662 : scanCanonicalize (H12AffineFastState.compose env37662 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37662 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,16400,10280,1025,8660,4160,21929,17,21762,8328,65,31836,5392,17664,2556,1500,32,257,21792,5456,22272]

theorem envBound37663 : H12AffineFastState.Bounded env37663 := by
  intro p hp
  have h : env37663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37662_37663 : H12AffineEnvironment.transform 16 16400 env37662 = env37663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37662 == env37663) = true)

theorem identity37663 : scanCanonicalize (H12AffineFastState.compose env37663 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37663 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37664 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,8661,28699,16400,10280,272,8660,4160,20664,17,20499,8328,65,31053,4097,16401,2556,205,32,257,20529,4161,21009]

theorem envBound37664 : H12AffineFastState.Bounded env37664 := by
  intro p hp
  have h : env37664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37663_37664 : H12AffineEnvironment.transform 9 273 env37663 = env37664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37663 == env37664) = true)

theorem identity37664 : scanCanonicalize (H12AffineFastState.compose env37664 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound37664 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env37665 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,161,16384,372,20666,16400,2185,272,373,4160,20664,17,20499,41,65,23020,4097,16401,2556,205,32,257,20529,4161,21009]

theorem envBound37665 : H12AffineFastState.Bounded env37665 := by
  intro p hp
  have h : env37665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37664_37665 : H12AffineEnvironment.transform 12 161 env37664 = env37665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env37664 == env37665) = true)

theorem identity37665 : scanCanonicalize (H12AffineFastState.compose env37665 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound37665 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env37666 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,161,4112,372,170,4096,2185,272,373,4160,168,17,3,41,65,2556,4097,4097,2556,205,32,257,33,4161,513]

theorem envBound37666 : H12AffineFastState.Bounded env37666 := by
  intro p hp
  have h : env37666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37665_37666 : H12AffineEnvironment.transform 13 4112 env37665 = env37666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env37665 == env37666) = true)

theorem identity37666 : scanCanonicalize (H12AffineFastState.compose env37666 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound37666 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37667 : List Nat := [2,4,8,16,32,64,89,256,512,273,2048,4096,120,4112,372,115,4096,2128,272,373,4160,113,17,3,41,65,2341,4097,4097,2341,20,32,257,33,4161,513]

theorem envBound37667 : H12AffineFastState.Bounded env37667 := by
  intro p hp
  have h : env37667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37666_37667 : H12AffineEnvironment.transform 6 89 env37666 = env37667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env37666 == env37667) = true)

theorem identity37667 : scanCanonicalize (H12AffineFastState.compose env37667 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37667 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env37668 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4112,293,34,4096,2049,272,292,4113,32,17,3,41,16,2341,4097,4097,2341,20,32,257,33,4112,513]

theorem envBound37668 : H12AffineFastState.Bounded env37668 := by
  intro p hp
  have h : env37668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37667_37668 : H12AffineEnvironment.transform 5 17 env37667 = env37668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37667 == env37668) = true)

theorem identity37668 : scanCanonicalize (H12AffineFastState.compose env37668 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37669 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4112,1,34,4096,2049,52,0,4113,32,17,3,41,16,2049,4097,4097,2049,20,32,37,33,4112,513]

theorem envBound37669 : H12AffineFastState.Bounded env37669 := by
  intro p hp
  have h : env37669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37668_37669 : H12AffineEnvironment.transform 7 36 env37668 = env37669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37668 == env37669) = true)

theorem identity37669 : scanCanonicalize (H12AffineFastState.compose env37669 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound37669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37670 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,32,41,48,1,34,32,2049,52,0,49,32,17,3,41,16,2049,33,33,2049,20,32,37,33,48,513]

theorem envBound37670 : H12AffineFastState.Bounded env37670 := by
  intro p hp
  have h : env37670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37669_37670 : H12AffineEnvironment.transform 11 32 env37669 = env37670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env37669 == env37670) = true)

theorem identity37670 : scanCanonicalize (H12AffineFastState.compose env37670 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound37670 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37671 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,32,41,48,1,34,32,48,52,0,49,32,17,3,41,16,48,33,33,48,20,32,37,33,48,513]

theorem envBound37671 : H12AffineFastState.Bounded env37671 := by
  intro p hp
  have h : env37671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37670_37671 : H12AffineEnvironment.transform 10 49 env37670 = env37671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env37670 == env37671) = true)

theorem identity37671 : scanCanonicalize (H12AffineFastState.compose env37671 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37671 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37672 : List Nat := [2,4,8,16,17,17,8,21,512,4,0,17,24,1,1,19,17,1,5,0,0,17,17,3,24,16,1,16,16,1,20,17,20,16,1,513]

theorem envBound37672 : H12AffineFastState.Bounded env37672 := by
  intro p hp
  have h : env37672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37671_37672 : H12AffineEnvironment.transform 4 17 env37671 = env37672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37671 == env37672) = true)

def env37673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4160,21929,41413,62678,8328,65,146509,46276,58580,149996,1500,33,257,21792,46213,63189]

theorem envBound37673 : H12AffineFastState.Bounded env37673 := by
  intro p hp
  have h : env37673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37660_37673 : H12AffineEnvironment.transform 17 10281 env37660 = env37673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37660 == env37673) = true)

theorem identity37673 : scanCanonicalize (H12AffineFastState.compose env37673 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37673 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,21793,41293,62558,8192,65,146509,46156,58460,149860,1364,33,257,21792,46093,63069]

theorem envBound37674 : H12AffineFastState.Bounded env37674 := by
  intro p hp
  have h : env37674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37673_37674 : H12AffineEnvironment.transform 6 8 env37673 = env37674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37673 == env37674) = true)

theorem identity37674 : scanCanonicalize (H12AffineFastState.compose env37674 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37674 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37675 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,21793,41244,62479,8192,16,146460,46109,58381,149813,1285,33,257,21792,46093,62988]

theorem envBound37675 : H12AffineFastState.Bounded env37675 := by
  intro p hp
  have h : env37675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37674_37675 : H12AffineEnvironment.transform 5 17 env37674 = env37675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37674 == env37675) = true)

theorem identity37675 : scanCanonicalize (H12AffineFastState.compose env37675 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound37675 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env37676 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,13340,10281,1025,32769,4113,21793,41244,62479,8192,16,2048,46109,58381,32041,1285,33,257,21792,46093,62988]

theorem envBound37676 : H12AffineFastState.Bounded env37676 := by
  intro p hp
  have h : env37676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37675_37676 : H12AffineEnvironment.transform 16 13340 env37675 = env37676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env37675 == env37676) = true)

theorem identity37676 : scanCanonicalize (H12AffineFastState.compose env37676 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37676 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env37677 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,33030,13340,10281,1025,32769,4113,33,41244,41231,8192,16,2048,46109,45325,10281,1285,33,257,32,46093,41740]

theorem envBound37677 : H12AffineFastState.Bounded env37677 := by
  intro p hp
  have h : env37677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37676_37677 : H12AffineEnvironment.transform 13 5376 env37676 = env37677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37676 == env37677) = true)

theorem identity37677 : scanCanonicalize (H12AffineFastState.compose env37677 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37677 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env37678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,1,263,13340,10281,1025,0,4113,33,8477,8462,8192,16,2048,13340,12556,10281,1285,33,257,32,13324,8973]

theorem envBound37678 : H12AffineFastState.Bounded env37678 := by
  intro p hp
  have h : env37678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37677_37678 : H12AffineEnvironment.transform 14 1 env37677 = env37678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37677 == env37678) = true)

theorem identity37678 : scanCanonicalize (H12AffineFastState.compose env37678 (packedSelected [1,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37678 : packedSelected [1,8,14] rootPS < 2^1333 := by decide +kernel

def env37679 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,1,34,13340,10281,1025,0,4113,33,8248,8235,8192,16,2048,13340,12329,10281,1056,33,36,32,13324,8744]

theorem envBound37679 : H12AffineFastState.Bounded env37679 := by
  intro p hp
  have h : env37679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37678_37679 : H12AffineEnvironment.transform 7 37 env37678 = env37679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37678 == env37679) = true)

theorem identity37679 : scanCanonicalize (H12AffineFastState.compose env37679 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37679 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37680 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5173,2048,1025,0,4113,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound37680 : H12AffineFastState.Bounded env37680 := by
  intro p hp
  have h : env37680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37679_37680 : H12AffineEnvironment.transform 12 41 env37679 = env37680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37679 == env37680) = true)

def env37681 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,1,34,1029,2048,1025,0,33,33,17,2,41,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound37681 : H12AffineFastState.Bounded env37681 := by
  intro p hp
  have h : env37681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37680_37681 : H12AffineEnvironment.transform 11 48 env37680 = env37681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37680 == env37681) = true)

theorem identity37681 : scanCanonicalize (H12AffineFastState.compose env37681 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound37681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37682 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,41,1045,1,34,1029,32,1025,0,33,33,17,2,41,16,32,1029,48,32,1056,33,36,32,1045,513]

theorem envBound37682 : H12AffineFastState.Bounded env37682 := by
  intro p hp
  have h : env37682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37681_37682 : H12AffineEnvironment.transform 10 32 env37681 = env37682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env37681 == env37682) = true)

def env37683 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,33,1,34,49,32,53,0,33,33,17,2,41,16,32,49,48,32,20,33,36,32,33,513]

theorem envBound37683 : H12AffineFastState.Bounded env37683 := by
  intro p hp
  have h : env37683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37682_37683 : H12AffineEnvironment.transform 9 52 env37682 = env37683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37682 == env37683) = true)

theorem identity37683 : scanCanonicalize (H12AffineFastState.compose env37683 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound37683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37684 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,41,33,1,34,49,32,53,0,33,33,17,2,41,16,32,49,48,32,20,33,36,32,33,10]

theorem envBound37684 : H12AffineFastState.Bounded env37684 := by
  intro p hp
  have h : env37684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37683_37684 : H12AffineEnvironment.transform 8 11 env37683 = env37684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env37683 == env37684) = true)

def leafEnv37684 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,41,33,1,34,49,32,53,0,33,33,17,2,21,41,1,16,32,49,48,32,20,33,36,32,5,34,33,10,1,33,0]

def active37684 : List Nat := [0,1,2,3,4]

def tree37684 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37684 : H12WitnessSearch.Good tree37684 := H12GlobalWitnessIndex.good

theorem leafIdentity37684 : H12AffineFastState.composeSystem env37684 rootObs = leafEnv37684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37684 rootObs == leafEnv37684) = true)

theorem terminalChecked37684 : H12PackedTerminal.terminalCheckFast leafEnv37684 active37684 tree37684 = true := by decide +kernel

def env37685 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,41,32,1,34,48,32,52,0,33,33,17,2,41,16,32,48,48,32,21,33,36,32,32,513]

theorem envBound37685 : H12AffineFastState.Bounded env37685 := by
  intro p hp
  have h : env37685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37682_37685 : H12AffineEnvironment.transform 9 53 env37682 = env37685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37682 == env37685) = true)

theorem identity37685 : scanCanonicalize (H12AffineFastState.compose env37685 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37686 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,1,2,16,0,20,0,1,1,17,2,9,16,0,16,16,0,21,1,4,0,0,513]

theorem envBound37686 : H12AffineFastState.Bounded env37686 := by
  intro p hp
  have h : env37686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37685_37686 : H12AffineEnvironment.transform 4 0 env37685 = env37686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37685 == env37686) = true)

def leafEnv37686 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,1,2,16,0,20,0,1,1,17,2,20,9,1,16,0,16,16,0,21,1,4,0,5,2,0,513,1,1,0]

def active37686 : List Nat := [0,1,2,3,8]

def tree37686 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37686 : H12WitnessSearch.Good tree37686 := H12GlobalWitnessIndex.good

theorem leafIdentity37686 : H12AffineFastState.composeSystem env37686 rootObs = leafEnv37686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37686 rootObs == leafEnv37686) = true)

theorem terminalChecked37686 : H12PackedTerminal.terminalCheckFast leafEnv37686 active37686 tree37686 = true := by decide +kernel

def env37687 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,1,34,1028,2048,1025,0,32,33,17,2,41,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound37687 : H12AffineFastState.Bounded env37687 := by
  intro p hp
  have h : env37687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37680_37687 : H12AffineEnvironment.transform 11 49 env37680 = env37687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37680 == env37687) = true)

theorem identity37687 : scanCanonicalize (H12AffineFastState.compose env37687 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound37687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37688 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,41,1044,1,34,1028,1045,1025,0,32,33,17,2,41,16,1045,1028,49,1045,1056,33,36,32,1044,513]

theorem envBound37688 : H12AffineFastState.Bounded env37688 := by
  intro p hp
  have h : env37688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37687_37688 : H12AffineEnvironment.transform 10 1045 env37687 = env37688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env37687 == env37688) = true)

def env37689 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,41,32,1,34,48,33,53,0,32,33,17,2,41,16,33,48,49,33,20,33,36,32,32,513]

theorem envBound37689 : H12AffineFastState.Bounded env37689 := by
  intro p hp
  have h : env37689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37688_37689 : H12AffineEnvironment.transform 9 52 env37688 = env37689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37688 == env37689) = true)

theorem identity37689 : scanCanonicalize (H12AffineFastState.compose env37689 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound37689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37690 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,41,32,1,34,48,33,53,0,32,33,17,2,41,16,33,48,49,33,20,33,36,32,32,11]

theorem envBound37690 : H12AffineFastState.Bounded env37690 := by
  intro p hp
  have h : env37690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37689_37690 : H12AffineEnvironment.transform 8 10 env37689 = env37690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env37689 == env37690) = true)

def leafEnv37690 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,41,32,1,34,48,33,53,0,32,33,17,2,21,41,1,16,33,48,49,33,20,33,36,32,5,34,32,11,1,32,0]

def active37690 : List Nat := [0,1,2,3,4]

def tree37690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37690 : H12WitnessSearch.Good tree37690 := H12GlobalWitnessIndex.good

theorem leafIdentity37690 : H12AffineFastState.composeSystem env37690 rootObs = leafEnv37690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37690 rootObs == leafEnv37690) = true)

theorem terminalChecked37690 : H12PackedTerminal.terminalCheckFast leafEnv37690 active37690 tree37690 = true := by decide +kernel

def env37691 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,33,1,34,49,32,52,0,32,33,17,2,41,16,32,49,49,32,21,33,36,32,33,513]

theorem envBound37691 : H12AffineFastState.Bounded env37691 := by
  intro p hp
  have h : env37691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37688_37691 : H12AffineEnvironment.transform 9 53 env37688 = env37691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37688 == env37691) = true)

theorem identity37691 : scanCanonicalize (H12AffineFastState.compose env37691 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37692 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,1,2,17,0,20,0,0,1,17,2,9,16,0,17,17,0,21,1,4,0,1,513]

theorem envBound37692 : H12AffineFastState.Bounded env37692 := by
  intro p hp
  have h : env37692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37691_37692 : H12AffineEnvironment.transform 4 0 env37691 = env37692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37691 == env37692) = true)

def leafEnv37692 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,1,2,17,0,20,0,0,1,17,2,20,9,1,16,0,17,17,0,21,1,4,0,5,2,1,513,1,0,0]

def active37692 : List Nat := [0,1,2,3,8]

def tree37692 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37692 : H12WitnessSearch.Good tree37692 := H12GlobalWitnessIndex.good

theorem leafIdentity37692 : H12AffineFastState.composeSystem env37692 rootObs = leafEnv37692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37692 rootObs == leafEnv37692) = true)

theorem terminalChecked37692 : H12PackedTerminal.terminalCheckFast leafEnv37692 active37692 tree37692 = true := by decide +kernel

def env37693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329761,8328,65,508090,302317,333858,236850,119043,272393,257,98814,90203,63189]

theorem envBound37693 : H12AffineFastState.Bounded env37693 := by
  intro p hp
  have h : env37693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37658_37693 : H12AffineEnvironment.transform 20 4161 env37658 = env37693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37658 == env37693) = true)

theorem identity37693 : scanCanonicalize (H12AffineFastState.compose env37693 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109047) := by decide +kernel

theorem selectedBound37693 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109047,1025,32769,4161,21928,62661,41430,8328,65,158029,79130,45525,236850,119043,98814,257,98814,90203,63189]

theorem envBound37694 : H12AffineFastState.Bounded env37694 := by
  intro p hp
  have h : env37694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37693_37694 : H12AffineEnvironment.transform 17 109047 env37693 = env37694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109047 env37693 == env37694) = true)

theorem identity37694 : scanCanonicalize (H12AffineFastState.compose env37694 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound37694 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89379,1025,29909,4161,21928,17,21762,8328,65,158029,79130,17665,223718,75223,95530,257,95530,90203,513]

theorem envBound37695 : H12AffineFastState.Bounded env37695 := by
  intro p hp
  have h : env37695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37694_37695 : H12AffineEnvironment.transform 14 29908 env37694 = env37695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env37694 == env37695) = true)

theorem identity37695 : scanCanonicalize (H12AffineFastState.compose env37695 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 90478) := by decide +kernel

theorem selectedBound37695 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env37696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90478,89379,1025,29909,4161,21928,17,21762,8328,65,67619,79130,17665,2184,75223,95530,257,95530,90203,513]

theorem envBound37696 : H12AffineFastState.Bounded env37696 := by
  intro p hp
  have h : env37696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37695_37696 : H12AffineEnvironment.transform 16 90478 env37695 = env37696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90478 env37695 == env37696) = true)

theorem identity37696 : scanCanonicalize (H12AffineFastState.compose env37696 (packedSelected [0,6,17,27] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound37696 : packedSelected [0,6,17,27] rootPS < 2^1333 := by decide +kernel

def env37697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30083,5357,10400,1025,29909,4161,21928,17,21762,8328,65,32160,16537,17665,2184,20564,169,257,169,5592,513]

theorem envBound37697 : H12AffineFastState.Bounded env37697 := by
  intro p hp
  have h : env37697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37696_37697 : H12AffineEnvironment.transform 15 30083 env37696 = env37697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env37696 == env37697) = true)

theorem identity37697 : scanCanonicalize (H12AffineFastState.compose env37697 (packedSelected [0,1,2,3,4,5,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound37697 : packedSelected [0,1,2,3,4,5,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env37698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,342,5357,10400,1025,0,4161,8573,17,8663,8328,65,2421,13388,12756,2184,9345,169,257,169,5592,513]

theorem envBound37698 : H12AffineFastState.Bounded env37698 := by
  intro p hp
  have h : env37698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37697_37698 : H12AffineEnvironment.transform 13 13525 env37697 = env37698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env37697 == env37698) = true)

theorem identity37698 : scanCanonicalize (H12AffineFastState.compose env37698 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound37698 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env37699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7301,2128,1,342,5357,5157,1025,0,4161,7672,17,7506,7181,65,2421,2249,3409,2184,6148,169,257,169,5592,513]

theorem envBound37699 : H12AffineFastState.Bounded env37699 := by
  intro p hp
  have h : env37699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37698_37699 : H12AffineEnvironment.transform 12 7301 env37698 = env37699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env37698 == env37699) = true)

theorem identity37699 : scanCanonicalize (H12AffineFastState.compose env37699 (packedSelected [2,3,4,5,9,10,11,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound37699 : packedSelected [2,3,4,5,9,10,11,14,17] rootPS < 2^1333 := by decide +kernel

def env37700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,3433,2128,1,342,1281,1481,1025,0,429,3092,17,3262,3553,65,2421,2249,3409,2184,2536,169,257,169,1076,513]

theorem envBound37700 : H12AffineFastState.Bounded env37700 := by
  intro p hp
  have h : env37700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37699_37700 : H12AffineEnvironment.transform 11 492 env37699 = env37700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env37699 == env37700) = true)

theorem identity37700 : scanCanonicalize (H12AffineFastState.compose env37700 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound37700 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37701 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,492,2436,2128,1,342,492,292,236,0,429,2297,17,2131,2316,65,2421,2249,2492,2184,2536,169,257,169,217,513]

theorem envBound37701 : H12AffineFastState.Bounded env37701 := by
  intro p hp
  have h : env37701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37700_37701 : H12AffineEnvironment.transform 9 237 env37700 = env37701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env37700 == env37701) = true)

theorem identity37701 : scanCanonicalize (H12AffineFastState.compose env37701 (packedSelected [0,1,3,4,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound37701 : packedSelected [0,1,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env37702 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,17,2169,2128,1,171,17,217,236,0,80,2297,17,2131,2289,65,2184,2249,2113,2184,2069,169,252,169,217,513]

theorem envBound37702 : H12AffineFastState.Bounded env37702 := by
  intro p hp
  have h : env37702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37701_37702 : H12AffineEnvironment.transform 7 253 env37701 = env37702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env37701 == env37702) = true)

theorem identity37702 : scanCanonicalize (H12AffineFastState.compose env37702 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37702 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37703 : List Nat := [2,4,8,16,32,17,128,172,512,188,2048,17,2088,2049,1,171,17,136,189,0,1,2216,17,2050,2208,16,2184,2200,2064,2184,2069,169,173,169,136,513]

theorem envBound37703 : H12AffineFastState.Bounded env37703 := by
  intro p hp
  have h : env37703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37702_37703 : H12AffineEnvironment.transform 5 17 env37702 = env37703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37702 == env37703) = true)

theorem identity37703 : scanCanonicalize (H12AffineFastState.compose env37703 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound37703 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37704 : List Nat := [2,4,8,16,32,17,128,172,512,188,136,17,160,137,1,171,17,136,189,0,1,32,17,138,40,16,0,16,152,0,157,169,173,169,136,513]

theorem envBound37704 : H12AffineFastState.Bounded env37704 := by
  intro p hp
  have h : env37704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37703_37704 : H12AffineEnvironment.transform 10 136 env37703 = env37704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env37703 == env37704) = true)

def env37705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431073,8328,65,2609402,302316,333858,2329971,119042,2373705,257,2199998,2191387,63188]

theorem envBound37705 : H12AffineFastState.Bounded env37705 := by
  intro p hp
  have h : env37705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37657_37705 : H12AffineEnvironment.transform 23 2431073 env37657 = env37705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env37657 == env37705) = true)

def env37706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329761,8328,65,508090,302316,333858,236851,119042,272393,257,98814,90203,63188]

theorem envBound37706 : H12AffineFastState.Bounded env37706 := by
  intro p hp
  have h : env37706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37705_37706 : H12AffineEnvironment.transform 20 4160 env37705 = env37706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37705 == env37706) = true)

theorem identity37706 : scanCanonicalize (H12AffineFastState.compose env37706 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound37706 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4160,21929,17,21763,8328,65,171416,115150,17664,236851,119042,95531,257,98814,90203,63188]

theorem envBound37707 : H12AffineFastState.Bounded env37707 := by
  intro p hp
  have h : env37707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37706_37707 : H12AffineEnvironment.transform 17 89378 env37706 = env37707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env37706 == env37707) = true)

theorem identity37707 : scanCanonicalize (H12AffineFastState.compose env37707 (packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 32938) := by decide +kernel

theorem selectedBound37707 : packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32938,131072,56712,1025,32769,4160,21929,17,21763,8328,65,171416,16740,17664,138649,20904,62849,257,340,57585,63188]

theorem envBound37708 : H12AffineFastState.Bounded env37708 := by
  intro p hp
  have h : env37708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37707_37708 : H12AffineEnvironment.transform 15 32938 env37707 = env37708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32938 env37707 == env37708) = true)

def env37709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,32802,131072,56576,1025,32769,4160,21793,17,21763,8192,65,171280,16740,17664,138513,20768,62729,257,340,57465,63068]

theorem envBound37709 : H12AffineFastState.Bounded env37709 := by
  intro p hp
  have h : env37709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37708_37709 : H12AffineEnvironment.transform 6 8 env37708 = env37709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37708 == env37709) = true)

theorem identity37709 : scanCanonicalize (H12AffineFastState.compose env37709 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37709 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env37710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29823,131072,10589,1025,29788,4160,21793,17,21763,8192,65,158029,16740,17664,138513,20768,340,257,340,5156,513]

theorem envBound37710 : H12AffineFastState.Bounded env37710 := by
  intro p hp
  have h : env37710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37709_37710 : H12AffineEnvironment.transform 14 29789 env37709 = env37710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37709 == env37710) = true)

theorem identity37710 : scanCanonicalize (H12AffineFastState.compose env37710 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound37710 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env37711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,8202,131072,10589,1025,8233,4160,340,17,374,8192,65,146744,5393,4469,138513,1365,340,257,340,5156,513]

theorem envBound37711 : H12AffineFastState.Bounded env37711 := by
  intro p hp
  have h : env37711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37710_37711 : H12AffineEnvironment.transform 13 5237 env37710 = env37711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env37710 == env37711) = true)

theorem identity37711 : scanCanonicalize (H12AffineFastState.compose env37711 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37711 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,1,35,131072,2420,1025,0,4160,340,17,374,41,65,138513,5393,4469,138513,1365,340,257,340,5156,513]

theorem envBound37712 : H12AffineFastState.Bounded env37712 := by
  intro p hp
  have h : env37712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37711_37712 : H12AffineEnvironment.transform 12 41 env37711 = env37712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37711 == env37712) = true)

theorem identity37712 : scanCanonicalize (H12AffineFastState.compose env37712 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound37712 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,1,35,5221,2420,1025,0,4160,340,17,374,41,65,2420,5393,4469,2420,1365,340,257,340,5156,513]

theorem envBound37713 : H12AffineFastState.Bounded env37713 := by
  intro p hp
  have h : env37713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37712_37713 : H12AffineEnvironment.transform 16 5221 env37712 = env37713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env37712 == env37713) = true)

theorem identity37713 : scanCanonicalize (H12AffineFastState.compose env37713 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound37713 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env37714 : List Nat := [2,4,8,16,32,64,8,256,512,623,2048,4096,41,4634,1,35,4618,2420,622,0,4160,340,17,374,41,65,2420,4990,4469,2420,826,340,257,340,4683,513]

theorem envBound37714 : H12AffineFastState.Bounded env37714 := by
  intro p hp
  have h : env37714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37713_37714 : H12AffineEnvironment.transform 9 623 env37713 = env37714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env37713 == env37714) = true)

theorem identity37714 : scanCanonicalize (H12AffineFastState.compose env37714 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound37714 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env37715 : List Nat := [2,4,8,16,32,64,8,256,512,623,293,4096,41,4634,1,35,4618,81,622,0,4160,340,17,374,41,65,81,4990,4469,81,826,340,257,340,4683,513]

theorem envBound37715 : H12AffineFastState.Bounded env37715 := by
  intro p hp
  have h : env37715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37714_37715 : H12AffineEnvironment.transform 10 293 env37714 = env37715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env37714 == env37715) = true)

theorem identity37715 : scanCanonicalize (H12AffineFastState.compose env37715 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37715 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37716 : List Nat := [2,4,8,16,32,64,8,117,512,623,80,4096,41,4634,1,35,4618,81,622,0,4160,33,17,3,41,65,81,4619,4096,81,591,33,116,33,4683,513]

theorem envBound37716 : H12AffineFastState.Bounded env37716 := by
  intro p hp
  have h : env37716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37715_37716 : H12AffineEnvironment.transform 7 117 env37715 = env37716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37715 == env37716) = true)

theorem identity37716 : scanCanonicalize (H12AffineFastState.compose env37716 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37716 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37717 : List Nat := [2,4,8,16,32,64,8,117,512,623,80,17,41,523,1,35,539,81,622,0,81,33,17,3,41,65,81,538,17,81,591,33,116,33,602,513]

theorem envBound37717 : H12AffineFastState.Bounded env37717 := by
  intro p hp
  have h : env37717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37716_37717 : H12AffineEnvironment.transform 11 17 env37716 = env37717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37716 == env37717) = true)

theorem identity37717 : scanCanonicalize (H12AffineFastState.compose env37717 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37717 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env37718 : List Nat := [2,2,8,16,32,64,8,115,512,617,80,17,41,523,1,35,539,81,616,0,81,33,17,3,41,65,81,538,17,81,585,33,114,33,602,513]

theorem envBound37718 : H12AffineFastState.Bounded env37718 := by
  intro p hp
  have h : env37718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37717_37718 : H12AffineEnvironment.transform 1 2 env37717 = env37718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37717 == env37718) = true)

theorem identity37718 : scanCanonicalize (H12AffineFastState.compose env37718 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound37718 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env37719 : List Nat := [2,2,8,16,32,64,8,115,42,67,80,17,41,33,1,35,49,81,66,0,81,33,17,3,41,65,81,48,17,81,99,33,114,33,112,43]

theorem envBound37719 : H12AffineFastState.Bounded env37719 := by
  intro p hp
  have h : env37719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37718_37719 : H12AffineEnvironment.transform 8 42 env37718 = env37719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env37718 == env37719) = true)

theorem identity37719 : scanCanonicalize (H12AffineFastState.compose env37719 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound37719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37720 : List Nat := [2,2,8,16,3,64,8,80,9,67,80,17,10,2,1,0,18,81,66,0,81,2,17,3,10,65,81,19,17,81,64,2,81,2,83,8]

theorem envBound37720 : H12AffineFastState.Bounded env37720 := by
  intro p hp
  have h : env37720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37719_37720 : H12AffineEnvironment.transform 4 3 env37719 = env37720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env37719 == env37720) = true)

def env37721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32803,131072,56577,1025,32769,4160,21792,17,21763,8193,65,171281,16740,17664,138512,20769,62728,257,340,57464,63069]

theorem envBound37721 : H12AffineFastState.Bounded env37721 := by
  intro p hp
  have h : env37721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37708_37721 : H12AffineEnvironment.transform 6 9 env37708 = env37721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37708 == env37721) = true)

theorem identity37721 : scanCanonicalize (H12AffineFastState.compose env37721 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37721 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8575,131072,31837,1025,8541,4160,21792,17,21763,8193,65,146509,16740,17664,138512,20769,21588,257,340,16676,22273]

theorem envBound37722 : H12AffineFastState.Bounded env37722 := by
  intro p hp
  have h : env37722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37721_37722 : H12AffineEnvironment.transform 14 8540 env37721 = env37722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37721 == env37722) = true)

theorem identity37722 : scanCanonicalize (H12AffineFastState.compose env37722 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound37722 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env37723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8575,16740,31837,1025,8541,4160,21792,17,21763,8193,65,32041,16740,17664,23668,20769,21588,257,340,16676,22273]

theorem envBound37723 : H12AffineFastState.Bounded env37723 := by
  intro p hp
  have h : env37723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37722_37723 : H12AffineEnvironment.transform 16 16740 env37722 = env37723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env37722 == env37723) = true)

theorem identity37723 : scanCanonicalize (H12AffineFastState.compose env37723 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37723 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8575,5220,10589,1025,8541,4160,32,17,3,8193,65,10281,5220,4096,2420,1057,340,257,340,5156,513]

theorem envBound37724 : H12AffineFastState.Bounded env37724 := by
  intro p hp
  have h : env37724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37723_37724 : H12AffineEnvironment.transform 13 5376 env37723 = env37724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37723 == env37724) = true)

theorem identity37724 : scanCanonicalize (H12AffineFastState.compose env37724 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37724 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,35,5220,2049,1025,1,4160,32,17,3,349,65,2421,5220,4096,2420,1057,340,257,340,5156,513]

theorem envBound37725 : H12AffineFastState.Bounded env37725 := by
  intro p hp
  have h : env37725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37724_37725 : H12AffineEnvironment.transform 12 348 env37724 = env37725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37724 == env37725) = true)

theorem identity37725 : scanCanonicalize (H12AffineFastState.compose env37725 (packedSelected [0,1,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37725 : packedSelected [0,1,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env37726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,348,1297,0,35,1141,2049,1025,1,81,32,17,3,349,65,2421,1141,17,2420,1057,340,257,340,1077,513]

theorem envBound37726 : H12AffineFastState.Bounded env37726 := by
  intro p hp
  have h : env37726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37725_37726 : H12AffineEnvironment.transform 11 17 env37725 = env37726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37725 == env37726) = true)

theorem identity37726 : scanCanonicalize (H12AffineFastState.compose env37726 (packedSelected [1,2,4,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound37726 : packedSelected [1,2,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env37727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,17,348,1297,0,35,1141,372,1025,1,81,32,17,3,349,65,0,1141,17,1,1057,340,257,340,1077,513]

theorem envBound37727 : H12AffineFastState.Bounded env37727 := by
  intro p hp
  have h : env37727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37726_37727 : H12AffineEnvironment.transform 10 373 env37726 = env37727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env37726 == env37727) = true)

theorem identity37727 : scanCanonicalize (H12AffineFastState.compose env37727 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37727 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env37728 : List Nat := [2,4,8,16,32,64,9,256,512,53,373,17,348,292,0,35,64,372,52,1,81,32,17,3,349,65,0,64,17,1,20,340,257,340,0,513]

theorem envBound37728 : H12AffineFastState.Bounded env37728 := by
  intro p hp
  have h : env37728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37727_37728 : H12AffineEnvironment.transform 9 53 env37727 = env37728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37727 == env37728) = true)

theorem identity37728 : scanCanonicalize (H12AffineFastState.compose env37728 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37728 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37729 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,17,269,292,0,35,17,293,52,1,0,32,17,3,268,16,0,17,17,1,20,261,257,261,0,513]

theorem envBound37729 : H12AffineFastState.Bounded env37729 := by
  intro p hp
  have h : env37729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37728_37729 : H12AffineEnvironment.transform 5 17 env37728 = env37729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37728 == env37729) = true)

theorem identity37729 : scanCanonicalize (H12AffineFastState.compose env37729 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound37729 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env37730 : List Nat := [2,4,8,16,32,17,9,256,260,53,292,17,269,292,0,35,17,293,52,1,0,32,17,3,268,16,0,17,17,1,20,261,257,261,0,261]

theorem envBound37730 : H12AffineFastState.Bounded env37730 := by
  intro p hp
  have h : env37730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37729_37730 : H12AffineEnvironment.transform 8 260 env37729 = env37730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env37729 == env37730) = true)

theorem identity37730 : scanCanonicalize (H12AffineFastState.compose env37730 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37730 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37731 : List Nat := [2,4,8,16,32,17,9,37,33,53,1,17,40,1,0,35,17,0,52,1,0,32,17,3,41,16,0,17,17,1,20,32,36,32,0,32]

theorem envBound37731 : H12AffineFastState.Bounded env37731 := by
  intro p hp
  have h : env37731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37730_37731 : H12AffineEnvironment.transform 7 37 env37730 = env37731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37730 == env37731) = true)

def env37732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329760,8328,65,508091,302316,333858,236850,119042,272392,257,98815,90202,63188]

theorem envBound37732 : H12AffineFastState.Bounded env37732 := by
  intro p hp
  have h : env37732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37705_37732 : H12AffineEnvironment.transform 20 4161 env37705 = env37732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37705 == env37732) = true)

theorem identity37732 : scanCanonicalize (H12AffineFastState.compose env37732 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37732 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21928,294201,272427,8328,65,450736,302316,276521,179513,61705,272392,257,41460,16465,63188]

theorem envBound37733 : H12AffineFastState.Bounded env37733 := by
  intro p hp
  have h : env37733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37732_37733 : H12AffineEnvironment.transform 15 8203 env37732 = env37733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37732 == env37733) = true)

def env37734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21792,294201,272427,8192,65,450616,302180,276521,179513,61705,272392,257,41340,16465,63068]

theorem envBound37734 : H12AffineFastState.Bounded env37734 := by
  intro p hp
  have h : env37734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37733_37734 : H12AffineEnvironment.transform 6 8 env37733 = env37734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37733 == env37734) = true)

theorem identity37734 : scanCanonicalize (H12AffineFastState.compose env37734 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37734 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,262144,1025,29788,4161,21792,294201,272427,8192,65,398437,288825,276521,149860,1364,272392,257,21793,16465,513]

theorem envBound37735 : H12AffineFastState.Bounded env37735 := by
  intro p hp
  have h : env37735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37734_37735 : H12AffineEnvironment.transform 14 29789 env37734 = env37735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37734 == env37735) = true)

theorem identity37735 : scanCanonicalize (H12AffineFastState.compose env37735 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37735 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env37736 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8203,131072,262144,1025,29709,4112,21792,294201,272427,8192,16,398388,288825,276521,149813,1285,272392,257,21793,16384,513]

theorem envBound37736 : H12AffineFastState.Bounded env37736 := by
  intro p hp
  have h : env37736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37735_37736 : H12AffineEnvironment.transform 5 17 env37735 = env37736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37735 == env37736) = true)

theorem identity37736 : scanCanonicalize (H12AffineFastState.compose env37736 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37736 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env37737 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,262144,1025,8460,4112,33,272440,272427,8192,16,398388,277816,276521,138292,1285,272392,257,32,5377,513]

theorem envBound37737 : H12AffineFastState.Bounded env37737 := by
  intro p hp
  have h : env37737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37736_37737 : H12AffineEnvironment.transform 13 5377 env37736 = env37737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37736 == env37737) = true)

theorem identity37737 : scanCanonicalize (H12AffineFastState.compose env37737 (packedSelected [0,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound37737 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env37738 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,13341,262144,1025,8460,4112,33,272440,272427,8192,16,270377,277816,276521,10281,1285,272392,257,32,5377,513]

theorem envBound37738 : H12AffineFastState.Bounded env37738 := by
  intro p hp
  have h : env37738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37737_37738 : H12AffineEnvironment.transform 16 13341 env37737 = env37738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env37737 == env37738) = true)

theorem identity37738 : scanCanonicalize (H12AffineFastState.compose env37738 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37738 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37739 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5393,262144,1025,0,4112,33,264500,264487,268,16,262437,269364,268581,2341,1285,264452,257,32,5377,513]

theorem envBound37739 : H12AffineFastState.Bounded env37739 := by
  intro p hp
  have h : env37739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37738_37739 : H12AffineEnvironment.transform 12 268 env37738 = env37739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37738 == env37739) = true)

theorem identity37739 : scanCanonicalize (H12AffineFastState.compose env37739 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37739 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env37740 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,35,5173,262144,1025,0,4112,33,264208,264195,40,16,262145,269364,268289,2049,1057,264224,37,32,5157,513]

theorem envBound37740 : H12AffineFastState.Bounded env37740 := by
  intro p hp
  have h : env37740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37739_37740 : H12AffineEnvironment.transform 7 36 env37739 = env37740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37739 == env37740) = true)

theorem identity37740 : scanCanonicalize (H12AffineFastState.compose env37740 (packedSelected [0,3,4,5,7,9,15] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound37740 : packedSelected [0,3,4,5,7,9,15] rootPS < 2^1333 := by decide +kernel

def env37741 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,35,5173,2049,1025,0,4112,33,17,2,40,16,2048,5173,4096,2049,1057,33,37,32,5157,513]

theorem envBound37741 : H12AffineFastState.Bounded env37741 := by
  intro p hp
  have h : env37741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37740_37741 : H12AffineEnvironment.transform 17 2049 env37740 = env37741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env37740 == env37741) = true)

def env37742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21793,294201,272427,8193,65,450617,302181,276521,179513,61705,272392,257,41341,16465,63069]

theorem envBound37742 : H12AffineFastState.Bounded env37742 := by
  intro p hp
  have h : env37742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37733_37742 : H12AffineEnvironment.transform 6 9 env37733 = env37742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37733 == env37742) = true)

theorem identity37742 : scanCanonicalize (H12AffineFastState.compose env37742 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37742 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,21793,294201,272427,8193,65,303145,302181,276521,64809,61705,272392,257,41341,16465,63069]

theorem envBound37743 : H12AffineFastState.Bounded env37743 := by
  intro p hp
  have h : env37743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37742_37743 : H12AffineEnvironment.transform 16 16400 env37742 = env37743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37742 == env37743) = true)

theorem identity37743 : scanCanonicalize (H12AffineFastState.compose env37743 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound37743 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16400,262144,1025,29789,4161,21793,294201,272427,8193,65,283765,288825,276521,2421,1365,272392,257,21793,16465,513]

theorem envBound37744 : H12AffineFastState.Bounded env37744 := by
  intro p hp
  have h : env37744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37743_37744 : H12AffineEnvironment.transform 14 29788 env37743 = env37744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env37743 == env37744) = true)

theorem identity37744 : scanCanonicalize (H12AffineFastState.compose env37744 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound37744 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env37745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,9529,8203,4469,262144,1025,9528,4161,1092,273500,272427,8193,65,263440,276828,276521,2421,1365,272392,257,1092,4404,513]

theorem envBound37745 : H12AffineFastState.Bounded env37745 := by
  intro p hp
  have h : env37745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37744_37745 : H12AffineEnvironment.transform 13 4453 env37744 = env37745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env37744 == env37745) = true)

theorem identity37745 : scanCanonicalize (H12AffineFastState.compose env37745 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound37745 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env37746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,9529,8203,4469,10589,1025,9528,4161,1092,1281,374,8193,65,11341,4097,4468,2421,1365,341,257,1092,4404,513]

theorem envBound37746 : H12AffineFastState.Bounded env37746 := by
  intro p hp
  have h : env37746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37745_37746 : H12AffineEnvironment.transform 17 10589 env37745 = env37746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env37745 == env37746) = true)

theorem identity37746 : scanCanonicalize (H12AffineFastState.compose env37746 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37746 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37747 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4453,8233,8203,4469,10589,273,8232,4161,340,17,374,8193,65,10589,4097,4468,2421,69,341,257,340,4404,513]

theorem envBound37747 : H12AffineFastState.Bounded env37747 := by
  intro p hp
  have h : env37747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37746_37747 : H12AffineEnvironment.transform 9 272 env37746 = env37747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37746 == env37747) = true)

theorem identity37747 : scanCanonicalize (H12AffineFastState.compose env37747 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37747 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37748 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4453,1,35,4469,2421,273,0,4161,340,17,374,41,65,2421,4097,4468,2421,69,341,257,340,4404,513]

theorem envBound37748 : H12AffineFastState.Bounded env37748 := by
  intro p hp
  have h : env37748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37747_37748 : H12AffineEnvironment.transform 12 40 env37747 = env37748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37747 == env37748) = true)

theorem identity37748 : scanCanonicalize (H12AffineFastState.compose env37748 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37749 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,40,4405,1,35,4389,2341,273,0,4113,260,17,294,41,17,2341,4097,4388,2341,21,261,257,260,4404,513]

theorem envBound37749 : H12AffineFastState.Bounded env37749 := by
  intro p hp
  have h : env37749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37748_37749 : H12AffineEnvironment.transform 5 16 env37748 = env37749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37748 == env37749) = true)

theorem identity37749 : scanCanonicalize (H12AffineFastState.compose env37749 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37749 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37750 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,1,35,4096,2048,52,0,4113,33,17,3,41,17,2048,4097,4097,2048,21,32,36,33,4113,513]

theorem envBound37750 : H12AffineFastState.Bounded env37750 := by
  intro p hp
  have h : env37750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37749_37750 : H12AffineEnvironment.transform 7 37 env37749 = env37750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37749 == env37750) = true)

theorem identity37750 : scanCanonicalize (H12AffineFastState.compose env37750 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound37750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37751 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2608,40,2592,1,35,2608,2048,52,0,2593,33,17,3,41,17,2048,2609,2609,2048,21,32,36,33,2593,513]

theorem envBound37751 : H12AffineFastState.Bounded env37751 := by
  intro p hp
  have h : env37751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37750_37751 : H12AffineEnvironment.transform 11 2608 env37750 = env37751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env37750 == env37751) = true)

theorem identity37751 : scanCanonicalize (H12AffineFastState.compose env37751 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound37751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37752 : List Nat := [2,4,8,16,32,16,9,37,512,53,512,48,40,32,1,35,48,512,52,0,33,33,17,3,41,17,512,49,49,512,21,32,36,33,33,513]

theorem envBound37752 : H12AffineFastState.Bounded env37752 := by
  intro p hp
  have h : env37752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37751_37752 : H12AffineEnvironment.transform 10 512 env37751 = env37752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env37751 == env37752) = true)

def env37753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound37753 : H12AffineFastState.Bounded env37753 := by
  intro p hp
  have h : env37753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37306_37753 : H12AffineEnvironment.transform 26 30393345 env37306 = env37753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env37306 == env37753) = true)

def env37754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound37754 : H12AffineFastState.Bounded env37754 := by
  intro p hp
  have h : env37754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37753_37754 : H12AffineEnvironment.transform 18 1024 env37753 = env37754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37753 == env37754) = true)

theorem identity37754 : scanCanonicalize (H12AffineFastState.compose env37754 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound37754 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362227,18973836,10507601,8456242,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound37755 : H12AffineFastState.Bounded env37755 := by
  intro p hp
  have h : env37755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37754_37755 : H12AffineEnvironment.transform 17 247858 env37754 = env37755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env37754 == env37755) = true)

def env37756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784943,5392,10507601,8456242,10491276,4256860,256,8410416,8434837,10564187]

theorem envBound37756 : H12AffineFastState.Bounded env37756 := by
  intro p hp
  have h : env37756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37755_37756 : H12AffineEnvironment.transform 23 2199964 env37755 = env37756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env37755 == env37756) = true)

def env37757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,8388608,98780,8328,65,12683759,5392,8406289,8456242,8390092,4256860,256,8410416,8434837,8462875]

theorem envBound37757 : H12AffineFastState.Bounded env37757 := by
  intro p hp
  have h : env37757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37756_37757 : H12AffineEnvironment.transform 20 4160 env37756 = env37757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37756 == env37757) = true)

def env37758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98780,8328,65,4295167,5392,17665,67618,1500,4256860,256,21792,46213,74251]

theorem envBound37758 : H12AffineFastState.Bounded env37758 := by
  intro p hp
  have h : env37758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37757_37758 : H12AffineEnvironment.transform 22 16 env37757 = env37758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37757 == env37758) = true)

theorem identity37758 : scanCanonicalize (H12AffineFastState.compose env37758 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37758 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,4194304,16,41430,8328,65,4237813,5392,17665,10280,1500,4256860,256,21792,46213,513]

theorem envBound37759 : H12AffineFastState.Bounded env37759 := by
  intro p hp
  have h : env37759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37758_37759 : H12AffineEnvironment.transform 15 8202 env37758 = env37759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37758 == env37759) = true)

theorem identity37759 : scanCanonicalize (H12AffineFastState.compose env37759 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound37759 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,32937,16,41430,8328,65,10588,5392,17665,10280,1500,29941,256,21792,46213,513]

theorem envBound37760 : H12AffineFastState.Bounded env37760 := by
  intro p hp
  have h : env37760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37759_37760 : H12AffineEnvironment.transform 21 32937 env37759 = env37760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env37759 == env37760) = true)

theorem identity37760 : scanCanonicalize (H12AffineFastState.compose env37760 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound37760 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32937,16,41430,8328,65,10588,5392,17665,10280,1500,29941,256,21792,46213,513]

theorem envBound37761 : H12AffineFastState.Bounded env37761 := by
  intro p hp
  have h : env37761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37760_37761 : H12AffineEnvironment.transform 16 16401 env37760 = env37761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37760 == env37761) = true)

theorem identity37761 : scanCanonicalize (H12AffineFastState.compose env37761 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37761 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env37762 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4112,32937,16,41350,8328,17,10508,5392,17665,10280,1420,29861,256,21792,46213,513]

theorem envBound37762 : H12AffineFastState.Bounded env37762 := by
  intro p hp
  have h : env37762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37761_37762 : H12AffineEnvironment.transform 5 16 env37761 = env37762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37761 == env37762) = true)

theorem identity37762 : scanCanonicalize (H12AffineFastState.compose env37762 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37762 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env37763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,262,16401,35109,1024,32769,4112,32937,16,32906,388,17,2048,5392,17665,2340,1420,21929,256,21792,38281,513]

theorem envBound37763 : H12AffineFastState.Bounded env37763 := by
  intro p hp
  have h : env37763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37762_37763 : H12AffineEnvironment.transform 12 268 env37762 = env37763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37762 == env37763) = true)

theorem identity37763 : scanCanonicalize (H12AffineFastState.compose env37763 (packedSelected [3,6,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 22804) := by decide +kernel

theorem selectedBound37763 : packedSelected [3,6,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env37764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,22804,262,16401,20529,1024,22805,4112,22973,16,22942,388,17,2048,5392,17665,2340,1420,21929,256,21792,19613,513]

theorem envBound37764 : H12AffineFastState.Bounded env37764 := by
  intro p hp
  have h : env37764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37763_37764 : H12AffineEnvironment.transform 14 22804 env37763 = env37764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22804 env37763 == env37764) = true)

theorem identity37764 : scanCanonicalize (H12AffineFastState.compose env37764 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37764 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37765 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,22804,262,16401,20529,1024,22805,4112,22837,16,22806,268,17,2048,5392,17665,2340,1284,21793,256,21792,19477,513]

theorem envBound37765 : H12AffineFastState.Bounded env37765 := by
  intro p hp
  have h : env37765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37764_37765 : H12AffineEnvironment.transform 6 8 env37764 = env37765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37764 == env37765) = true)

theorem identity37765 : scanCanonicalize (H12AffineFastState.compose env37765 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37765 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37766 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,3093,262,5392,1328,1024,3092,4112,3124,16,3095,268,17,2048,5392,4096,2340,1284,32,256,33,6420,513]

theorem envBound37766 : H12AffineFastState.Bounded env37766 := by
  intro p hp
  have h : env37766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37765_37766 : H12AffineEnvironment.transform 13 5377 env37765 = env37766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37765 == env37766) = true)

theorem identity37766 : scanCanonicalize (H12AffineFastState.compose env37766 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound37766 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env37767 : List Nat := [2,4,8,16,32,16,8,256,512,1024,561,4096,268,5377,1572,262,5392,1328,1024,1573,4112,1541,16,1574,268,17,561,5392,4096,789,1284,32,256,33,4901,513]

theorem envBound37767 : H12AffineFastState.Bounded env37767 := by
  intro p hp
  have h : env37767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37766_37767 : H12AffineEnvironment.transform 10 561 env37766 = env37767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env37766 == env37767) = true)

theorem identity37767 : scanCanonicalize (H12AffineFastState.compose env37767 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound37767 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37768 : List Nat := [2,4,8,16,32,16,8,256,512,1024,561,292,268,1061,1572,262,1076,1328,1024,1573,308,1541,16,1574,268,17,561,1076,292,789,1284,32,256,33,513,513]

theorem envBound37768 : H12AffineFastState.Bounded env37768 := by
  intro p hp
  have h : env37768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37767_37768 : H12AffineEnvironment.transform 11 292 env37767 = env37768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env37767 == env37768) = true)

theorem identity37768 : scanCanonicalize (H12AffineFastState.compose env37768 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37768 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env37769 : List Nat := [2,4,8,0,32,0,8,256,512,1024,545,292,268,1061,1572,262,1060,1312,1024,1573,292,1541,0,1574,268,1,545,1060,292,773,1284,32,256,33,513,513]

theorem envBound37769 : H12AffineFastState.Bounded env37769 := by
  intro p hp
  have h : env37769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37768_37769 : H12AffineEnvironment.transform 3 0 env37768 = env37769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37768 == env37769) = true)

theorem identity37769 : scanCanonicalize (H12AffineFastState.compose env37769 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37769 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env37770 : List Nat := [2,4,8,0,0,0,8,256,512,1024,513,260,268,1029,1540,262,1028,1280,1024,1541,260,1541,0,1542,268,1,513,1028,260,773,1284,0,256,1,513,513]

theorem envBound37770 : H12AffineFastState.Bounded env37770 := by
  intro p hp
  have h : env37770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37769_37770 : H12AffineEnvironment.transform 4 0 env37769 = env37770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37769 == env37770) = true)

theorem identity37770 : scanCanonicalize (H12AffineFastState.compose env37770 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound37770 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env37771 : List Nat := [2,4,8,0,0,0,8,256,261,1024,260,260,268,1029,1281,262,1028,1280,1024,1280,260,1280,0,1283,268,1,260,1028,260,0,1284,0,256,1,260,260]

theorem envBound37771 : H12AffineFastState.Bounded env37771 := by
  intro p hp
  have h : env37771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37770_37771 : H12AffineEnvironment.transform 8 261 env37770 = env37771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env37770 == env37771) = true)

theorem identity37771 : scanCanonicalize (H12AffineFastState.compose env37771 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound37771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37772 : List Nat := [2,4,8,0,0,0,8,256,261,257,260,260,268,260,0,262,261,1,257,1,260,1,0,2,268,1,260,261,260,0,5,0,256,1,260,260]

theorem envBound37772 : H12AffineFastState.Bounded env37772 := by
  intro p hp
  have h : env37772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37771_37772 : H12AffineEnvironment.transform 9 257 env37771 = env37772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env37771 == env37772) = true)

theorem identity37772 : scanCanonicalize (H12AffineFastState.compose env37772 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37773 : List Nat := [2,4,3,0,0,0,3,256,261,257,260,260,263,260,0,262,261,1,257,1,260,1,0,2,263,1,260,261,260,0,5,0,256,1,260,260]

theorem envBound37773 : H12AffineFastState.Bounded env37773 := by
  intro p hp
  have h : env37773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37772_37773 : H12AffineEnvironment.transform 2 3 env37772 = env37773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37772 == env37773) = true)

def env37774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,17,98780,8328,65,4295166,5392,17664,67619,1501,4256860,256,21793,46212,74250]

theorem envBound37774 : H12AffineFastState.Bounded env37774 := by
  intro p hp
  have h : env37774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37757_37774 : H12AffineEnvironment.transform 22 17 env37757 = env37774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37757 == env37774) = true)

theorem identity37774 : scanCanonicalize (H12AffineFastState.compose env37774 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254130) := by decide +kernel

theorem selectedBound37774 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,254130,17,98780,8328,65,158028,5392,17664,67619,1501,201966,256,21793,46212,74250]

theorem envBound37775 : H12AffineFastState.Bounded env37775 := by
  intro p hp
  have h : env37775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37774_37775 : H12AffineEnvironment.transform 21 254130 env37774 = env37775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254130 env37774 == env37775) = true)

theorem identity37775 : scanCanonicalize (H12AffineFastState.compose env37775 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37775 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4160,180409,17,41431,8328,65,158028,5392,17664,10280,1501,144613,256,21793,46212,513]

theorem envBound37776 : H12AffineFastState.Bounded env37776 := by
  intro p hp
  have h : env37776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37775_37776 : H12AffineEnvironment.transform 15 8203 env37775 = env37776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37775 == env37776) = true)

theorem identity37776 : scanCanonicalize (H12AffineFastState.compose env37776 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37776 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43049,1024,32769,4160,32937,17,41431,8328,65,10588,5392,17664,10280,1501,29941,256,21793,46212,513]

theorem envBound37777 : H12AffineFastState.Bounded env37777 := by
  intro p hp
  have h : env37777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37776_37777 : H12AffineEnvironment.transform 16 16400 env37776 = env37777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37776 == env37777) = true)

theorem identity37777 : scanCanonicalize (H12AffineFastState.compose env37777 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound37777 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env37778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16400,23589,1024,29709,4160,29861,17,21979,8328,65,10588,5392,17664,10280,1501,29941,256,21793,16520,513]

theorem envBound37778 : H12AffineFastState.Bounded env37778 := by
  intro p hp
  have h : env37778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37777_37778 : H12AffineEnvironment.transform 14 29708 env37777 = env37778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env37777 == env37778) = true)

theorem identity37778 : scanCanonicalize (H12AffineFastState.compose env37778 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound37778 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,0,8203,13340,10281,1024,1,4160,169,17,8663,8328,65,10588,5392,12556,10280,1501,249,256,8493,13444,513]

theorem envBound37779 : H12AffineFastState.Bounded env37779 := by
  intro p hp
  have h : env37779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37778_37779 : H12AffineEnvironment.transform 13 13324 env37778 = env37779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env37778 == env37779) = true)

theorem identity37779 : scanCanonicalize (H12AffineFastState.compose env37779 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound37779 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env37780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,8192,11744,0,8203,11760,10281,1024,1,2476,169,17,8663,8328,65,10588,3324,10464,10280,1501,249,256,8493,11624,513]

theorem envBound37780 : H12AffineFastState.Bounded env37780 := by
  intro p hp
  have h : env37780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37779_37780 : H12AffineEnvironment.transform 11 2540 env37779 = env37780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env37779 == env37780) = true)

theorem identity37780 : scanCanonicalize (H12AffineFastState.compose env37780 (packedSelected [1,6,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

end H12CloudChart0