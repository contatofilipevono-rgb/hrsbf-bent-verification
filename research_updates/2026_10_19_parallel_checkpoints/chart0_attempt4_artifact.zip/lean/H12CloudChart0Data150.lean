import H12CloudChart0Data149

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity38031 : scanCanonicalize (H12AffineFastState.compose env38031 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38032 : List Nat := [2,4,8,10,32,10,9,5,42,46,0,10,8,0,1,2,11,33,47,0,32,33,11,3,9,11,0,10,11,33,47,32,4,33,0,43]

theorem envBound38032 : H12AffineFastState.Bounded env38032 := by
  intro p hp
  have h : env38032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38031_38032 : H12AffineEnvironment.transform 3 10 env38031 = env38032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38031 == env38032) = true)

def leafEnv38032 : List Nat := [2,4,8,10,32,10,9,5,42,46,0,10,8,0,1,2,11,33,47,0,32,33,11,3,46,9,1,11,0,10,11,33,47,32,4,33,5,3,0,43,1,32,0]

def active38032 : List Nat := [0,1,2,4]

def tree38032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38032 : H12WitnessSearch.Good tree38032 := H12GlobalWitnessIndex.good

theorem leafIdentity38032 : H12AffineFastState.composeSystem env38032 rootObs = leafEnv38032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38032 rootObs == leafEnv38032) = true)

theorem terminalChecked38032 : H12PackedTerminal.terminalCheckFast leafEnv38032 active38032 tree38032 = true := by decide +kernel

def env38033 : List Nat := [2,4,8,16,32,16,9,5,49,53,1,17,8,0,1,2,17,32,52,0,33,33,17,3,9,17,1,16,16,32,52,32,4,33,0,48]

theorem envBound38033 : H12AffineFastState.Bounded env38033 := by
  intro p hp
  have h : env38033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38030_38033 : H12AffineEnvironment.transform 8 49 env38030 = env38033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38030 == env38033) = true)

def leafEnv38033 : List Nat := [2,4,8,16,32,16,9,5,49,53,1,17,8,0,1,2,17,32,52,0,33,33,17,3,53,9,1,17,1,16,16,32,52,32,4,33,5,3,0,48,1,33,0]

def active38033 : List Nat := [0,1,2,3,4]

def tree38033 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38033 : H12WitnessSearch.Good tree38033 := H12GlobalWitnessIndex.good

theorem leafIdentity38033 : H12AffineFastState.composeSystem env38033 rootObs = leafEnv38033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38033 rootObs == leafEnv38033) = true)

theorem terminalChecked38033 : H12PackedTerminal.terminalCheckFast leafEnv38033 active38033 tree38033 = true := by decide +kernel

def env38034 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,545,269,1541,1,263,1556,1296,1025,0,788,33,17,3,268,17,1076,1557,544,1296,1284,32,257,33,1541,513]

theorem envBound38034 : H12AffineFastState.Bounded env38034 := by
  intro p hp
  have h : env38034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38021_38034 : H12AffineEnvironment.transform 11 545 env38021 = env38034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env38021 == env38034) = true)

def env38035 : List Nat := [2,4,8,16,32,16,9,256,512,768,820,545,269,261,1,263,276,528,769,0,788,33,17,3,268,17,820,277,544,528,516,32,257,33,261,513]

theorem envBound38035 : H12AffineFastState.Bounded env38035 := by
  intro p hp
  have h : env38035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38034_38035 : H12AffineEnvironment.transform 9 768 env38034 = env38035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env38034 == env38035) = true)

theorem identity38035 : scanCanonicalize (H12AffineFastState.compose env38035 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38036 : List Nat := [2,4,8,16,0,16,9,256,512,768,788,513,269,261,1,263,276,528,769,0,788,1,17,3,268,17,788,277,512,528,516,0,257,1,261,513]

theorem envBound38036 : H12AffineFastState.Bounded env38036 := by
  intro p hp
  have h : env38036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38035_38036 : H12AffineEnvironment.transform 4 0 env38035 = env38036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38035 == env38036) = true)

def env38037 : List Nat := [2,4,8,16,0,16,9,256,276,20,0,277,269,261,1,263,276,260,21,0,0,1,17,3,268,17,0,277,276,260,272,0,257,1,261,277]

theorem envBound38037 : H12AffineFastState.Bounded env38037 := by
  intro p hp
  have h : env38037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38036_38037 : H12AffineEnvironment.transform 8 276 env38036 = env38037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env38036 == env38037) = true)

theorem identity38037 : scanCanonicalize (H12AffineFastState.compose env38037 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38038 : List Nat := [2,4,8,11,0,11,9,256,271,15,0,270,269,261,1,263,271,260,14,0,0,1,10,3,268,10,0,270,271,260,267,0,257,1,261,270]

theorem envBound38038 : H12AffineFastState.Bounded env38038 := by
  intro p hp
  have h : env38038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38037_38038 : H12AffineEnvironment.transform 3 11 env38037 = env38038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38037 == env38038) = true)

def leafEnv38038 : List Nat := [2,4,8,11,0,11,9,256,271,15,0,270,269,261,1,263,271,260,14,0,0,1,10,3,266,268,1,10,0,270,271,260,267,0,257,1,5,262,261,270,1,0,0]

def active38038 : List Nat := [0,1,2,7]

def tree38038 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38038 : H12WitnessSearch.Good tree38038 := H12GlobalWitnessIndex.good

theorem leafIdentity38038 : H12AffineFastState.composeSystem env38038 rootObs = leafEnv38038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38038 rootObs == leafEnv38038) = true)

theorem terminalChecked38038 : H12PackedTerminal.terminalCheckFast leafEnv38038 active38038 tree38038 = true := by decide +kernel

def env38039 : List Nat := [2,4,8,16,0,16,9,256,277,21,1,276,269,261,1,263,276,261,20,0,1,1,17,3,268,17,1,277,277,261,273,0,257,1,261,276]

theorem envBound38039 : H12AffineFastState.Bounded env38039 := by
  intro p hp
  have h : env38039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38036_38039 : H12AffineEnvironment.transform 8 277 env38036 = env38039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env38036 == env38039) = true)

theorem identity38039 : scanCanonicalize (H12AffineFastState.compose env38039 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38040 : List Nat := [2,4,8,16,0,16,9,5,16,21,1,17,8,0,1,2,17,0,20,0,1,1,17,3,9,17,1,16,16,0,20,0,4,1,0,17]

theorem envBound38040 : H12AffineFastState.Bounded env38040 := by
  intro p hp
  have h : env38040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38039_38040 : H12AffineEnvironment.transform 7 5 env38039 = env38040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38039 == env38040) = true)

def leafEnv38040 : List Nat := [2,4,8,16,0,16,9,5,16,21,1,17,8,0,1,2,17,0,20,0,1,1,17,3,21,9,1,17,1,16,16,0,20,0,4,1,5,3,0,17,1,1,0]

def active38040 : List Nat := [0,1,2,3]

def tree38040 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38040 : H12WitnessSearch.Good tree38040 := H12GlobalWitnessIndex.good

theorem leafIdentity38040 : H12AffineFastState.composeSystem env38040 rootObs = leafEnv38040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38040 rootObs == leafEnv38040) = true)

theorem terminalChecked38040 : H12PackedTerminal.terminalCheckFast leafEnv38040 active38040 tree38040 = true := by decide +kernel

def env38041 : List Nat := [2,4,8,16,32,16,9,256,512,769,821,545,269,260,1,263,277,529,768,0,788,33,17,3,268,17,821,276,544,529,517,32,257,33,260,513]

theorem envBound38041 : H12AffineFastState.Bounded env38041 := by
  intro p hp
  have h : env38041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38034_38041 : H12AffineEnvironment.transform 9 769 env38034 = env38041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env38034 == env38041) = true)

theorem identity38041 : scanCanonicalize (H12AffineFastState.compose env38041 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound38041 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38042 : List Nat := [2,4,8,16,32,16,9,256,49,304,260,16,269,260,1,263,277,32,305,0,293,33,17,3,268,17,260,276,17,32,52,32,257,33,260,48]

theorem envBound38042 : H12AffineFastState.Bounded env38042 := by
  intro p hp
  have h : env38042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38041_38042 : H12AffineEnvironment.transform 8 49 env38041 = env38042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38041 == env38042) = true)

def env38043 : List Nat := [2,4,8,16,32,16,9,4,49,52,0,16,9,0,1,3,17,32,53,0,33,33,17,3,8,17,0,16,17,32,52,32,5,33,0,48]

theorem envBound38043 : H12AffineFastState.Bounded env38043 := by
  intro p hp
  have h : env38043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38042_38043 : H12AffineEnvironment.transform 7 4 env38042 = env38043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38042 == env38043) = true)

theorem identity38043 : scanCanonicalize (H12AffineFastState.compose env38043 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38043 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38044 : List Nat := [2,4,8,10,32,10,9,4,43,46,0,10,9,0,1,3,11,32,47,0,33,33,11,3,8,11,0,10,11,32,46,32,5,33,0,42]

theorem envBound38044 : H12AffineFastState.Bounded env38044 := by
  intro p hp
  have h : env38044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38043_38044 : H12AffineEnvironment.transform 3 10 env38043 = env38044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38043 == env38044) = true)

def leafEnv38044 : List Nat := [2,4,8,10,32,10,9,4,43,46,0,10,9,0,1,3,11,32,47,0,33,33,11,3,47,8,1,11,0,10,11,32,46,32,5,33,5,2,0,42,1,33,0]

def active38044 : List Nat := [0,1,2,4]

def tree38044 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38044 : H12WitnessSearch.Good tree38044 := H12GlobalWitnessIndex.good

theorem leafIdentity38044 : H12AffineFastState.composeSystem env38044 rootObs = leafEnv38044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38044 rootObs == leafEnv38044) = true)

theorem terminalChecked38044 : H12PackedTerminal.terminalCheckFast leafEnv38044 active38044 tree38044 = true := by decide +kernel

def env38045 : List Nat := [2,4,8,16,32,16,9,5,49,53,1,16,8,1,1,2,16,32,52,0,32,33,17,3,9,17,1,17,17,32,52,32,4,33,1,48]

theorem envBound38045 : H12AffineFastState.Bounded env38045 := by
  intro p hp
  have h : env38045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38042_38045 : H12AffineEnvironment.transform 7 5 env38042 = env38045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38042 == env38045) = true)

def env38046 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8461,65536,82199,9244,1025,8460,91418,4194304,17,3,8193,16,4195348,16400,77835,66582,75023,4194305,257,33,16385,513]

theorem envBound38046 : H12AffineFastState.Bounded env38046 := by
  intro p hp
  have h : env38046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38016_38046 : H12AffineEnvironment.transform 5 17 env38016 = env38046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38016 == env38046) = true)

def env38047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9292,1025,11576,92462,4194304,17,3174,8193,65,4408578,19573,81006,149861,75102,4194305,257,3140,16464,513]

theorem envBound38047 : H12AffineFastState.Bounded env38047 := by
  intro p hp
  have h : env38047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38013_38047 : H12AffineEnvironment.transform 14 11577 env38013 = env38047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env38013 == env38047) = true)

theorem identity38047 : scanCanonicalize (H12AffineFastState.compose env38047 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound38047 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env38048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,82246,9292,1025,11576,92462,4194304,17,3174,8193,65,4195396,19573,81006,67619,75102,4194305,257,3140,16464,513]

theorem envBound38048 : H12AffineFastState.Bounded env38048 := by
  intro p hp
  have h : env38048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38047_38048 : H12AffineEnvironment.transform 16 82246 env38047 = env38048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env38047 == env38048) = true)

def env38049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,65536,82246,9292,1025,8540,91466,4194304,17,2,8193,65,4195396,16401,77834,66631,75102,4194305,257,32,16464,513]

theorem envBound38049 : H12AffineFastState.Bounded env38049 := by
  intro p hp
  have h : env38049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38048_38049 : H12AffineEnvironment.transform 10 1124 env38048 = env38049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env38048 == env38049) = true)

theorem identity38049 : scanCanonicalize (H12AffineFastState.compose env38049 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound38049 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,28699,12637,9292,1025,8540,5457,4194304,17,2,8193,65,4195396,16401,16401,29788,21829,4194305,257,32,16464,513]

theorem envBound38050 : H12AffineFastState.Bounded env38050 := by
  intro p hp
  have h : env38050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38049_38050 : H12AffineEnvironment.transform 15 28699 env38049 = env38050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env38049 == env38050) = true)

theorem identity38050 : scanCanonicalize (H12AffineFastState.compose env38050 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38050 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env38051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,41,16384,372,20530,4468,1125,1025,373,5457,4194304,17,2,40,65,4195396,16401,16401,21621,21829,4194305,257,32,16464,513]

theorem envBound38051 : H12AffineFastState.Bounded env38051 := by
  intro p hp
  have h : env38051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38050_38051 : H12AffineEnvironment.transform 12 41 env38050 = env38051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38050 == env38051) = true)

theorem identity38051 : scanCanonicalize (H12AffineFastState.compose env38051 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound38051 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env38052 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,0,20530,4096,1125,1025,1,5157,4194304,17,2,40,65,4195396,16401,16401,21621,21553,4194305,117,32,16464,513]

theorem envBound38052 : H12AffineFastState.Bounded env38052 := by
  intro p hp
  have h : env38052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38051_38052 : H12AffineEnvironment.transform 7 116 env38051 = env38052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env38051 == env38052) = true)

theorem identity38052 : scanCanonicalize (H12AffineFastState.compose env38052 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1044) := by decide +kernel

theorem selectedBound38052 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38053 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,0,20530,4096,1125,1025,1,5157,1044,17,2,40,65,80,16401,16401,21621,21553,1045,117,32,16464,513]

theorem envBound38053 : H12AffineFastState.Bounded env38053 := by
  intro p hp
  have h : env38053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38052_38053 : H12AffineEnvironment.transform 21 1044 env38052 = env38053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1044 env38052 == env38053) = true)

theorem identity38053 : scanCanonicalize (H12AffineFastState.compose env38053 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound38053 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env38054 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,1076,0,5126,4096,1125,1025,1,5157,1044,17,2,40,65,80,1061,1061,4161,4101,1045,117,32,1124,513]

theorem envBound38054 : H12AffineFastState.Bounded env38054 := by
  intro p hp
  have h : env38054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38053_38054 : H12AffineEnvironment.transform 13 1076 env38053 = env38054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env38053 == env38054) = true)

theorem identity38054 : scanCanonicalize (H12AffineFastState.compose env38054 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38054 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38055 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,4096,41,1076,0,5126,4096,1076,1025,1,5157,1044,17,2,40,16,1,1061,1061,4112,4101,1045,36,32,1077,513]

theorem envBound38055 : H12AffineFastState.Bounded env38055 := by
  intro p hp
  have h : env38055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38054_38055 : H12AffineEnvironment.transform 5 17 env38054 = env38055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38054 == env38055) = true)

theorem identity38055 : scanCanonicalize (H12AffineFastState.compose env38055 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38055 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env38056 : List Nat := [2,4,8,0,32,1,9,37,512,1024,1061,4096,41,1060,0,5126,4096,1060,1025,1,5157,1028,1,2,40,0,1,1061,1061,4096,4101,1029,36,32,1061,513]

theorem envBound38056 : H12AffineFastState.Bounded env38056 := by
  intro p hp
  have h : env38056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38055_38056 : H12AffineEnvironment.transform 3 0 env38055 = env38056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38055 == env38056) = true)

theorem identity38056 : scanCanonicalize (H12AffineFastState.compose env38056 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38056 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38057 : List Nat := [2,4,8,0,1,1,9,4,512,1024,1028,4096,8,1029,0,5126,4096,1029,1025,1,5124,1028,1,2,9,0,1,1028,1028,4096,4101,1029,5,1,1028,513]

theorem envBound38057 : H12AffineFastState.Bounded env38057 := by
  intro p hp
  have h : env38057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38056_38057 : H12AffineEnvironment.transform 4 1 env38056 = env38057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38056 == env38057) = true)

theorem identity38057 : scanCanonicalize (H12AffineFastState.compose env38057 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound38057 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38058 : List Nat := [2,4,8,0,1,1,9,4,512,1024,1028,1029,8,1029,0,3,1029,1029,1025,1,1,1028,1,2,9,0,1,1028,1028,1029,1024,1029,5,1,1028,513]

theorem envBound38058 : H12AffineFastState.Bounded env38058 := by
  intro p hp
  have h : env38058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38057_38058 : H12AffineEnvironment.transform 11 1029 env38057 = env38058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env38057 == env38058) = true)

theorem identity38058 : scanCanonicalize (H12AffineFastState.compose env38058 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38059 : List Nat := [2,4,8,0,1,1,9,4,512,4,0,1,8,1,0,3,1,1,5,1,1,0,1,2,9,0,1,0,0,1,4,1,5,1,0,513]

theorem envBound38059 : H12AffineFastState.Bounded env38059 := by
  intro p hp
  have h : env38059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38058_38059 : H12AffineEnvironment.transform 9 4 env38058 = env38059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38058 == env38059) = true)

theorem identity38059 : scanCanonicalize (H12AffineFastState.compose env38059 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38060 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,1,8,1,0,3,1,1,5,1,1,0,1,2,9,0,1,0,0,1,4,1,5,1,0,1]

theorem envBound38060 : H12AffineFastState.Bounded env38060 := by
  intro p hp
  have h : env38060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38059_38060 : H12AffineEnvironment.transform 8 0 env38059 = env38060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38059 == env38060) = true)

def env38061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,16384,8540,65536,82246,9292,1025,8541,91467,4194304,17,3,8193,65,4195396,16400,77835,66630,75102,4194305,257,33,16464,513]

theorem envBound38061 : H12AffineFastState.Bounded env38061 := by
  intro p hp
  have h : env38061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38048_38061 : H12AffineEnvironment.transform 10 1125 env38048 = env38061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env38048 == env38061) = true)

def env38062 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8460,65536,82198,9244,1025,8461,91419,4194304,17,3,8193,17,4195348,16400,77835,66582,75022,4194305,257,33,16384,513]

theorem envBound38062 : H12AffineFastState.Bounded env38062 := by
  intro p hp
  have h : env38062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38061_38062 : H12AffineEnvironment.transform 5 16 env38061 = env38062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38061 == env38062) = true)

theorem identity38062 : scanCanonicalize (H12AffineFastState.compose env38062 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38062 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38063 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8460,8202,24860,9244,1025,8461,17681,4194304,17,3,8193,17,4195348,16400,4097,9244,1284,4194305,257,33,16384,513]

theorem envBound38063 : H12AffineFastState.Bounded env38063 := by
  intro p hp
  have h : env38063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38062_38063 : H12AffineEnvironment.transform 15 8202 env38062 = env38063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38062 == env38063) = true)

theorem identity38063 : scanCanonicalize (H12AffineFastState.compose env38063 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38063 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38064 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,16384,1,263,16401,1297,1025,0,17681,4194304,17,3,268,17,4195348,16400,4097,1297,1284,4194305,257,33,16384,513]

theorem envBound38064 : H12AffineFastState.Bounded env38064 := by
  intro p hp
  have h : env38064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38063_38064 : H12AffineEnvironment.transform 12 269 env38063 = env38064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38063 == env38064) = true)

theorem identity38064 : scanCanonicalize (H12AffineFastState.compose env38064 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound38064 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38065 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,16384,1,263,16401,1297,1025,0,17681,21509,17,3,268,17,20497,16400,4097,1297,1284,21508,257,33,16384,513]

theorem envBound38065 : H12AffineFastState.Bounded env38065 := by
  intro p hp
  have h : env38065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38064_38065 : H12AffineEnvironment.transform 21 21509 env38064 = env38065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env38064 == env38065) = true)

theorem identity38065 : scanCanonicalize (H12AffineFastState.compose env38065 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38065 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38066 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,5156,1,263,5173,1297,1025,0,4405,33,17,3,268,17,1077,5172,4097,1297,1284,32,257,33,5156,513]

theorem envBound38066 : H12AffineFastState.Bounded env38066 := by
  intro p hp
  have h : env38066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38065_38066 : H12AffineEnvironment.transform 13 5156 env38065 = env38066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38065 == env38066) = true)

def env38067 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,544,269,1540,1,263,1557,1297,1025,0,789,33,17,3,268,17,1077,1556,545,1297,1284,32,257,33,1540,513]

theorem envBound38067 : H12AffineFastState.Bounded env38067 := by
  intro p hp
  have h : env38067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38066_38067 : H12AffineEnvironment.transform 11 544 env38066 = env38067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env38066 == env38067) = true)

def env38068 : List Nat := [2,4,8,16,32,16,9,256,512,768,821,544,269,260,1,263,277,529,769,0,789,33,17,3,268,17,821,276,545,529,516,32,257,33,260,513]

theorem envBound38068 : H12AffineFastState.Bounded env38068 := by
  intro p hp
  have h : env38068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38067_38068 : H12AffineEnvironment.transform 9 768 env38067 = env38068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env38067 == env38068) = true)

theorem identity38068 : scanCanonicalize (H12AffineFastState.compose env38068 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound38068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38069 : List Nat := [2,4,8,16,32,16,9,256,48,304,261,16,269,260,1,263,277,33,305,0,293,33,17,3,268,17,261,276,17,33,52,32,257,33,260,49]

theorem envBound38069 : H12AffineFastState.Bounded env38069 := by
  intro p hp
  have h : env38069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38068_38069 : H12AffineEnvironment.transform 8 48 env38068 = env38069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38068 == env38069) = true)

def env38070 : List Nat := [2,4,8,16,32,16,9,4,48,52,1,16,9,0,1,3,17,33,53,0,33,33,17,3,8,17,1,16,17,33,52,32,5,33,0,49]

theorem envBound38070 : H12AffineFastState.Bounded env38070 := by
  intro p hp
  have h : env38070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38069_38070 : H12AffineEnvironment.transform 7 4 env38069 = env38070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38069 == env38070) = true)

theorem identity38070 : scanCanonicalize (H12AffineFastState.compose env38070 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38071 : List Nat := [2,4,8,10,32,10,9,4,42,46,1,10,9,0,1,3,11,33,47,0,33,33,11,3,8,11,1,10,11,33,46,32,5,33,0,43]

theorem envBound38071 : H12AffineFastState.Bounded env38071 := by
  intro p hp
  have h : env38071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38070_38071 : H12AffineEnvironment.transform 3 10 env38070 = env38071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38070 == env38071) = true)

def leafEnv38071 : List Nat := [2,4,8,10,32,10,9,4,42,46,1,10,9,0,1,3,11,33,47,0,33,33,11,3,47,8,1,11,1,10,11,33,46,32,5,33,5,2,0,43,1,33,0]

def active38071 : List Nat := [0,1,2,4]

def tree38071 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38071 : H12WitnessSearch.Good tree38071 := H12GlobalWitnessIndex.good

theorem leafIdentity38071 : H12AffineFastState.composeSystem env38071 rootObs = leafEnv38071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38071 rootObs == leafEnv38071) = true)

theorem terminalChecked38071 : H12PackedTerminal.terminalCheckFast leafEnv38071 active38071 tree38071 = true := by decide +kernel

def env38072 : List Nat := [2,4,8,16,32,16,9,5,48,53,0,16,8,1,1,2,16,33,52,0,32,33,17,3,9,17,0,17,17,33,52,32,4,33,1,49]

theorem envBound38072 : H12AffineFastState.Bounded env38072 := by
  intro p hp
  have h : env38072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38069_38072 : H12AffineEnvironment.transform 7 5 env38069 = env38072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38069 == env38072) = true)

def leafEnv38072 : List Nat := [2,4,8,16,32,16,9,5,48,53,0,16,8,1,1,2,16,33,52,0,32,33,17,3,53,9,1,17,0,17,17,33,52,32,4,33,5,3,1,49,1,32,0]

def active38072 : List Nat := [0,1,2,3,4]

def tree38072 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38072 : H12WitnessSearch.Good tree38072 := H12GlobalWitnessIndex.good

theorem leafIdentity38072 : H12AffineFastState.composeSystem env38072 rootObs = leafEnv38072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38072 rootObs == leafEnv38072) = true)

theorem terminalChecked38072 : H12PackedTerminal.terminalCheckFast leafEnv38072 active38072 tree38072 = true := by decide +kernel

def env38073 : List Nat := [2,4,8,16,32,16,9,256,512,769,820,544,269,261,1,263,276,528,768,0,789,33,17,3,268,17,820,277,545,528,517,32,257,33,261,513]

theorem envBound38073 : H12AffineFastState.Bounded env38073 := by
  intro p hp
  have h : env38073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38067_38073 : H12AffineEnvironment.transform 9 769 env38067 = env38073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env38067 == env38073) = true)

theorem identity38073 : scanCanonicalize (H12AffineFastState.compose env38073 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38074 : List Nat := [2,4,8,16,0,16,9,256,512,769,788,512,269,261,1,263,276,528,768,0,789,1,17,3,268,17,788,277,513,528,517,0,257,1,261,513]

theorem envBound38074 : H12AffineFastState.Bounded env38074 := by
  intro p hp
  have h : env38074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38073_38074 : H12AffineEnvironment.transform 4 0 env38073 = env38074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38073 == env38074) = true)

def env38075 : List Nat := [2,4,8,16,0,16,9,256,276,21,0,276,269,261,1,263,276,260,20,0,1,1,17,3,268,17,0,277,277,260,273,0,257,1,261,277]

theorem envBound38075 : H12AffineFastState.Bounded env38075 := by
  intro p hp
  have h : env38075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38074_38075 : H12AffineEnvironment.transform 8 276 env38074 = env38075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env38074 == env38075) = true)

theorem identity38075 : scanCanonicalize (H12AffineFastState.compose env38075 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38076 : List Nat := [2,4,8,16,0,16,9,4,16,21,0,16,9,1,1,3,16,0,20,0,1,1,17,3,8,17,0,17,17,0,21,0,5,1,1,17]

theorem envBound38076 : H12AffineFastState.Bounded env38076 := by
  intro p hp
  have h : env38076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38075_38076 : H12AffineEnvironment.transform 7 4 env38075 = env38076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38075 == env38076) = true)

def leafEnv38076 : List Nat := [2,4,8,16,0,16,9,4,16,21,0,16,9,1,1,3,16,0,20,0,1,1,17,3,20,8,1,17,0,17,17,0,21,0,5,1,5,2,1,17,1,1,0]

def active38076 : List Nat := [0,1,2,3]

def tree38076 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38076 : H12WitnessSearch.Good tree38076 := H12GlobalWitnessIndex.good

theorem leafIdentity38076 : H12AffineFastState.composeSystem env38076 rootObs = leafEnv38076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38076 rootObs == leafEnv38076) = true)

theorem terminalChecked38076 : H12PackedTerminal.terminalCheckFast leafEnv38076 active38076 tree38076 = true := by decide +kernel

def env38077 : List Nat := [2,4,8,16,0,16,9,256,277,20,1,277,269,261,1,263,276,261,21,0,0,1,17,3,268,17,1,277,276,261,272,0,257,1,261,276]

theorem envBound38077 : H12AffineFastState.Bounded env38077 := by
  intro p hp
  have h : env38077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38074_38077 : H12AffineEnvironment.transform 8 277 env38074 = env38077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env38074 == env38077) = true)

theorem identity38077 : scanCanonicalize (H12AffineFastState.compose env38077 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38078 : List Nat := [2,4,8,11,0,11,9,256,270,15,1,270,269,261,1,263,271,261,14,0,0,1,10,3,268,10,1,270,271,261,267,0,257,1,261,271]

theorem envBound38078 : H12AffineFastState.Bounded env38078 := by
  intro p hp
  have h : env38078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38077_38078 : H12AffineEnvironment.transform 3 11 env38077 = env38078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38077 == env38078) = true)

def leafEnv38078 : List Nat := [2,4,8,11,0,11,9,256,270,15,1,270,269,261,1,263,271,261,14,0,0,1,10,3,266,268,1,10,1,270,271,261,267,0,257,1,5,262,261,271,1,0,0]

def active38078 : List Nat := [0,1,2,7]

def tree38078 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38078 : H12WitnessSearch.Good tree38078 := H12GlobalWitnessIndex.good

theorem leafIdentity38078 : H12AffineFastState.composeSystem env38078 rootObs = leafEnv38078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38078 rootObs == leafEnv38078) = true)

theorem terminalChecked38078 : H12PackedTerminal.terminalCheckFast leafEnv38078 active38078 tree38078 = true := by decide +kernel

def env38079 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,545,269,1541,1,263,1556,1297,1025,0,788,33,17,3,268,17,1077,1557,544,1297,1284,32,257,33,1541,513]

theorem envBound38079 : H12AffineFastState.Bounded env38079 := by
  intro p hp
  have h : env38079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38066_38079 : H12AffineEnvironment.transform 11 545 env38066 = env38079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env38066 == env38079) = true)

def env38080 : List Nat := [2,4,8,16,32,16,9,256,512,768,821,545,269,261,1,263,276,529,769,0,788,33,17,3,268,17,821,277,544,529,516,32,257,33,261,513]

theorem envBound38080 : H12AffineFastState.Bounded env38080 := by
  intro p hp
  have h : env38080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38079_38080 : H12AffineEnvironment.transform 9 768 env38079 = env38080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env38079 == env38080) = true)

theorem identity38080 : scanCanonicalize (H12AffineFastState.compose env38080 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38081 : List Nat := [2,4,8,16,32,16,9,5,512,517,560,545,8,0,1,2,17,529,516,0,529,33,17,3,9,17,560,16,544,529,516,32,4,33,0,513]

theorem envBound38081 : H12AffineFastState.Bounded env38081 := by
  intro p hp
  have h : env38081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38080_38081 : H12AffineEnvironment.transform 7 5 env38080 = env38081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38080 == env38081) = true)

def env38082 : List Nat := [2,4,8,16,32,16,9,5,48,53,0,17,8,0,1,2,17,33,52,0,33,33,17,3,9,17,0,16,16,33,52,32,4,33,0,49]

theorem envBound38082 : H12AffineFastState.Bounded env38082 := by
  intro p hp
  have h : env38082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38081_38082 : H12AffineEnvironment.transform 8 48 env38081 = env38082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38081 == env38082) = true)

def env38083 : List Nat := [2,4,8,16,32,16,9,5,49,52,1,16,8,0,1,2,17,32,53,0,32,33,17,3,9,17,1,16,17,32,53,32,4,33,0,48]

theorem envBound38083 : H12AffineFastState.Bounded env38083 := by
  intro p hp
  have h : env38083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38081_38083 : H12AffineEnvironment.transform 8 49 env38081 = env38083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38081 == env38083) = true)

theorem identity38083 : scanCanonicalize (H12AffineFastState.compose env38083 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38083 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38084 : List Nat := [2,4,8,10,32,10,9,5,43,46,1,10,8,0,1,2,11,32,47,0,32,33,11,3,9,11,1,10,11,32,47,32,4,33,0,42]

theorem envBound38084 : H12AffineFastState.Bounded env38084 := by
  intro p hp
  have h : env38084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38083_38084 : H12AffineEnvironment.transform 3 10 env38083 = env38084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38083 == env38084) = true)

def leafEnv38084 : List Nat := [2,4,8,10,32,10,9,5,43,46,1,10,8,0,1,2,11,32,47,0,32,33,11,3,46,9,1,11,1,10,11,32,47,32,4,33,5,3,0,42,1,32,0]

def active38084 : List Nat := [0,1,2,4]

def tree38084 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38084 : H12WitnessSearch.Good tree38084 := H12GlobalWitnessIndex.good

theorem leafIdentity38084 : H12AffineFastState.composeSystem env38084 rootObs = leafEnv38084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38084 rootObs == leafEnv38084) = true)

theorem terminalChecked38084 : H12PackedTerminal.terminalCheckFast leafEnv38084 active38084 tree38084 = true := by decide +kernel

def env38085 : List Nat := [2,4,8,16,32,16,9,256,512,769,820,545,269,260,1,263,277,528,768,0,788,33,17,3,268,17,820,276,544,528,517,32,257,33,260,513]

theorem envBound38085 : H12AffineFastState.Bounded env38085 := by
  intro p hp
  have h : env38085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38079_38085 : H12AffineEnvironment.transform 9 769 env38079 = env38085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env38079 == env38085) = true)

theorem identity38085 : scanCanonicalize (H12AffineFastState.compose env38085 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound38085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38086 : List Nat := [2,4,8,16,32,16,9,256,276,21,32,309,269,260,1,263,277,260,20,0,0,33,17,3,268,17,32,276,308,260,273,32,257,33,260,277]

theorem envBound38086 : H12AffineFastState.Bounded env38086 := by
  intro p hp
  have h : env38086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38085_38086 : H12AffineEnvironment.transform 8 276 env38085 = env38086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env38085 == env38086) = true)

def env38087 : List Nat := [2,4,8,16,0,16,9,256,276,21,0,277,269,260,1,263,277,260,20,0,0,1,17,3,268,17,0,276,276,260,273,0,257,1,260,277]

theorem envBound38087 : H12AffineFastState.Bounded env38087 := by
  intro p hp
  have h : env38087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38086_38087 : H12AffineEnvironment.transform 4 0 env38086 = env38087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38086 == env38087) = true)

theorem identity38087 : scanCanonicalize (H12AffineFastState.compose env38087 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38088 : List Nat := [2,4,8,16,0,16,9,5,17,21,0,16,8,1,1,2,16,1,20,0,0,1,17,3,9,17,0,17,17,1,20,0,4,1,1,16]

theorem envBound38088 : H12AffineFastState.Bounded env38088 := by
  intro p hp
  have h : env38088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38087_38088 : H12AffineEnvironment.transform 7 5 env38087 = env38088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38087 == env38088) = true)

def leafEnv38088 : List Nat := [2,4,8,16,0,16,9,5,17,21,0,16,8,1,1,2,16,1,20,0,0,1,17,3,21,9,1,17,0,17,17,1,20,0,4,1,5,3,1,16,1,0,0]

def active38088 : List Nat := [0,1,2,3]

def tree38088 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38088 : H12WitnessSearch.Good tree38088 := H12GlobalWitnessIndex.good

theorem leafIdentity38088 : H12AffineFastState.composeSystem env38088 rootObs = leafEnv38088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38088 rootObs == leafEnv38088) = true)

theorem terminalChecked38088 : H12PackedTerminal.terminalCheckFast leafEnv38088 active38088 tree38088 = true := by decide +kernel

def env38089 : List Nat := [2,4,8,16,1,16,9,256,276,21,1,276,269,260,1,263,277,260,20,0,0,0,17,3,268,17,1,276,277,260,273,1,257,0,260,277]

theorem envBound38089 : H12AffineFastState.Bounded env38089 := by
  intro p hp
  have h : env38089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38086_38089 : H12AffineEnvironment.transform 4 1 env38086 = env38089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38086 == env38089) = true)

theorem identity38089 : scanCanonicalize (H12AffineFastState.compose env38089 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38090 : List Nat := [2,4,8,11,1,11,9,256,271,14,1,271,269,260,1,263,270,260,15,0,0,0,10,3,268,10,1,271,270,260,266,1,257,0,260,270]

theorem envBound38090 : H12AffineFastState.Bounded env38090 := by
  intro p hp
  have h : env38090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38089_38090 : H12AffineEnvironment.transform 3 11 env38089 = env38090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38089 == env38090) = true)

def leafEnv38090 : List Nat := [2,4,8,11,1,11,9,256,271,14,1,271,269,260,1,263,270,260,15,0,0,0,10,3,267,268,1,10,1,271,270,260,266,1,257,0,5,262,260,270,1,0,0]

def active38090 : List Nat := [0,1,2,7]

def tree38090 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38090 : H12WitnessSearch.Good tree38090 := H12GlobalWitnessIndex.good

theorem leafIdentity38090 : H12AffineFastState.composeSystem env38090 rootObs = leafEnv38090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38090 rootObs == leafEnv38090) = true)

theorem terminalChecked38090 : H12PackedTerminal.terminalCheckFast leafEnv38090 active38090 tree38090 = true := by decide +kernel

def env38091 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8461,65536,82199,9245,1025,8460,91418,4194304,17,3,8193,16,4195349,16400,77835,66583,75023,4194305,257,33,16385,513]

theorem envBound38091 : H12AffineFastState.Bounded env38091 := by
  intro p hp
  have h : env38091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38061_38091 : H12AffineEnvironment.transform 5 17 env38061 = env38091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38061 == env38091) = true)

def env38092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,4294967296,525568,4308116844,27337992,25733063]

theorem envBound38092 : H12AffineFastState.Bounded env38092 := by
  intro p hp
  have h : env38092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31846_38092 : H12AffineEnvironment.transform 28 77616401 env31846 = env38092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env31846 == env38092) = true)

def env38093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound38093 : H12AffineFastState.Bounded env38093 := by
  intro p hp
  have h : env38093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38092_38093 : H12AffineEnvironment.transform 31 145662400 env38092 = env38093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env38092 == env38093) = true)

def env38094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound38094 : H12AffineFastState.Bounded env38094 := by
  intro p hp
  have h : env38094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38093_38094 : H12AffineEnvironment.transform 29 155254784 env38093 = env38094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env38093 == env38094) = true)

def env38095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound38095 : H12AffineFastState.Bounded env38095 := by
  intro p hp
  have h : env38095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38094_38095 : H12AffineEnvironment.transform 25 64 env38094 = env38095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env38094 == env38095) = true)

def env38096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound38096 : H12AffineFastState.Bounded env38096 := by
  intro p hp
  have h : env38096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38095_38096 : H12AffineEnvironment.transform 26 30393344 env38095 = env38096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env38095 == env38096) = true)

def env38097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound38097 : H12AffineFastState.Bounded env38097 := by
  intro p hp
  have h : env38097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38096_38097 : H12AffineEnvironment.transform 18 1024 env38096 = env38097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env38096 == env38097) = true)

theorem identity38097 : scanCanonicalize (H12AffineFastState.compose env38097 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2212870) := by decide +kernel

theorem selectedBound38097 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2212870,16777216,8328,64,23462918,18973836,102743,2556934,18890775,23160256,256,16777386,16834830,18966465]

theorem envBound38098 : H12AffineFastState.Bounded env38098 := by
  intro p hp
  have h : env38098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38097_38098 : H12AffineEnvironment.transform 22 2212870 env38097 = env38098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2212870 env38097 == env38098) = true)

def env38099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8328,64,17227834,18973836,102743,2556934,18890775,16876028,256,16777386,16834830,18966465]

theorem envBound38099 : H12AffineFastState.Bounded env38099 := by
  intro p hp
  have h : env38099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38098_38099 : H12AffineEnvironment.transform 21 2155580 env38098 = env38099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env38098 == env38099) = true)

def env38100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8192,64,17227834,18973700,102743,2556934,18890775,16875892,256,16777250,16834830,18966345]

theorem envBound38100 : H12AffineFastState.Bounded env38100 := by
  intro p hp
  have h : env38100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38099_38100 : H12AffineEnvironment.transform 6 8 env38099 = env38100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38099 == env38100) = true)

theorem identity38100 : scanCanonicalize (H12AffineFastState.compose env38100 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound38100 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env38101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,73770,16,16777216,8192,64,17227834,16793618,102743,442384,16876545,16875892,256,16777250,16834830,16819039]

theorem envBound38101 : H12AffineFastState.Bounded env38101 := by
  intro p hp
  have h : env38101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38100_38101 : H12AffineEnvironment.transform 20 115734 env38100 = env38101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env38100 == env38101) = true)

def env38102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,73770,16,95496,8192,64,496946,79130,102743,442384,61705,62588,256,95530,103430,120407]

theorem envBound38102 : H12AffineFastState.Bounded env38102 := by
  intro p hp
  have h : env38102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38101_38102 : H12AffineEnvironment.transform 23 95496 env38101 = env38102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env38101 == env38102) = true)

theorem identity38102 : scanCanonicalize (H12AffineFastState.compose env38102 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound38102 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,62588,16,41310,8192,64,409956,57676,17665,442384,61705,62588,256,41340,16464,513]

theorem envBound38103 : H12AffineFastState.Bounded env38103 := by
  intro p hp
  have h : env38103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38102_38103 : H12AffineEnvironment.transform 15 54358 env38102 = env38103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env38102 == env38103) = true)

def env38104 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,62508,16,41230,8192,16,409908,57628,17665,442384,61705,62508,256,41260,16384,513]

theorem envBound38104 : H12AffineFastState.Bounded env38104 := by
  intro p hp
  have h : env38104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38103_38104 : H12AffineEnvironment.transform 5 16 env38103 = env38104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38103 == env38104) = true)

theorem identity38104 : scanCanonicalize (H12AffineFastState.compose env38104 (packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound38104 : packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env38105 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,263,131072,262144,1024,21760,4112,8493,16,29711,8192,16,409908,13341,17665,398609,9224,8493,256,29741,16384,513]

theorem envBound38105 : H12AffineFastState.Bounded env38105 := by
  intro p hp
  have h : env38105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38104_38105 : H12AffineEnvironment.transform 14 21761 env38104 = env38105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38104 == env38105) = true)

theorem identity38105 : scanCanonicalize (H12AffineFastState.compose env38105 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound38105 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env38106 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,263,131072,32041,1024,21760,4112,8493,16,29711,8192,16,146461,13341,17665,157752,9224,8493,256,29741,16384,513]

theorem envBound38106 : H12AffineFastState.Bounded env38106 := by
  intro p hp
  have h : env38106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38105_38106 : H12AffineEnvironment.transform 17 32041 env38105 = env38106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env38105 == env38106) = true)

theorem identity38106 : scanCanonicalize (H12AffineFastState.compose env38106 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound38106 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env38107 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,263,5393,32041,1024,21760,4112,8493,16,29711,8192,16,10508,13341,17665,32041,9224,8493,256,29741,16384,513]

theorem envBound38107 : H12AffineFastState.Bounded env38107 := by
  intro p hp
  have h : env38107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38106_38107 : H12AffineEnvironment.transform 16 5393 env38106 = env38107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env38106 == env38107) = true)

theorem identity38107 : scanCanonicalize (H12AffineFastState.compose env38107 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38108 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,0,263,5393,10280,1024,1,4112,8493,16,8462,8192,16,10508,13341,4096,10280,9224,8493,256,8492,5377,513]

theorem envBound38108 : H12AffineFastState.Bounded env38108 := by
  intro p hp
  have h : env38108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38107_38108 : H12AffineEnvironment.transform 13 5377 env38107 = env38108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38107 == env38108) = true)

theorem identity38108 : scanCanonicalize (H12AffineFastState.compose env38108 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38108 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38109 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1024,1,4112,33,16,2,268,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound38109 : H12AffineFastState.Bounded env38109 := by
  intro p hp
  have h : env38109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38108_38109 : H12AffineEnvironment.transform 12 268 env38108 = env38109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38108 == env38109) = true)

theorem identity38109 : scanCanonicalize (H12AffineFastState.compose env38109 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38110 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5173,2048,1024,1,4112,33,16,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound38110 : H12AffineFastState.Bounded env38110 := by
  intro p hp
  have h : env38110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38109_38110 : H12AffineEnvironment.transform 7 36 env38109 = env38110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38109 == env38110) = true)

def env38111 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,0,35,1029,2048,1024,1,32,33,16,2,40,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound38111 : H12AffineFastState.Bounded env38111 := by
  intro p hp
  have h : env38111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38110_38111 : H12AffineEnvironment.transform 11 48 env38110 = env38111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38110 == env38111) = true)

theorem identity38111 : scanCanonicalize (H12AffineFastState.compose env38111 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38112 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,48,40,1045,0,35,1029,0,1024,1,32,33,16,2,40,16,0,1029,48,0,1056,33,36,32,1045,513]

theorem envBound38112 : H12AffineFastState.Bounded env38112 := by
  intro p hp
  have h : env38112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38111_38112 : H12AffineEnvironment.transform 10 0 env38111 = env38112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38111 == env38112) = true)

def env38113 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,40,33,0,35,49,0,52,1,32,33,16,2,40,16,0,49,48,0,20,33,36,32,33,513]

theorem envBound38113 : H12AffineFastState.Bounded env38113 := by
  intro p hp
  have h : env38113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38112_38113 : H12AffineEnvironment.transform 9 52 env38112 = env38113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38112 == env38113) = true)

theorem identity38113 : scanCanonicalize (H12AffineFastState.compose env38113 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38114 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,48,40,33,0,35,49,0,52,1,32,33,16,2,40,16,0,49,48,0,20,33,36,32,33,42]

theorem envBound38114 : H12AffineFastState.Bounded env38114 := by
  intro p hp
  have h : env38114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38113_38114 : H12AffineEnvironment.transform 8 43 env38113 = env38114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38113 == env38114) = true)

def leafEnv38114 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,48,40,33,0,35,49,0,52,1,32,33,16,2,20,40,1,16,0,49,48,0,20,33,36,32,4,35,33,42,1,32,0]

def active38114 : List Nat := [0,1,2,3,4]

def tree38114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38114 : H12WitnessSearch.Good tree38114 := H12GlobalWitnessIndex.good

theorem leafIdentity38114 : H12AffineFastState.composeSystem env38114 rootObs = leafEnv38114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38114 rootObs == leafEnv38114) = true)

theorem terminalChecked38114 : H12PackedTerminal.terminalCheckFast leafEnv38114 active38114 tree38114 = true := by decide +kernel

def env38115 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,32,0,35,48,0,53,1,32,33,16,2,40,16,0,48,48,0,21,33,36,32,32,513]

theorem envBound38115 : H12AffineFastState.Bounded env38115 := by
  intro p hp
  have h : env38115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38112_38115 : H12AffineEnvironment.transform 9 53 env38112 = env38115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38112 == env38115) = true)

def leafEnv38115 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,32,0,35,48,0,53,1,32,33,16,2,21,40,1,16,0,48,48,0,21,33,36,32,4,35,32,513,1,32,0]

def active38115 : List Nat := [0,1,2,3,4,8]

def tree38115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38115 : H12WitnessSearch.Good tree38115 := H12GlobalWitnessIndex.good

theorem leafIdentity38115 : H12AffineFastState.composeSystem env38115 rootObs = leafEnv38115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38115 rootObs == leafEnv38115) = true)

theorem terminalChecked38115 : H12PackedTerminal.terminalCheckFast leafEnv38115 active38115 tree38115 = true := by decide +kernel

def env38116 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,0,35,1028,2048,1024,1,33,33,16,2,40,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound38116 : H12AffineFastState.Bounded env38116 := by
  intro p hp
  have h : env38116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38110_38116 : H12AffineEnvironment.transform 11 49 env38110 = env38116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38110 == env38116) = true)

theorem identity38116 : scanCanonicalize (H12AffineFastState.compose env38116 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound38116 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38117 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,40,1044,0,35,1028,1076,1024,1,33,33,16,2,40,16,1076,1028,49,1076,1056,33,36,32,1044,513]

theorem envBound38117 : H12AffineFastState.Bounded env38117 := by
  intro p hp
  have h : env38117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38116_38117 : H12AffineEnvironment.transform 10 1076 env38116 = env38117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env38116 == env38117) = true)

def env38118 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,32,0,35,48,0,52,1,33,33,16,2,40,16,0,48,49,0,20,33,36,32,32,513]

theorem envBound38118 : H12AffineFastState.Bounded env38118 := by
  intro p hp
  have h : env38118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38117_38118 : H12AffineEnvironment.transform 9 52 env38117 = env38118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38117 == env38118) = true)

theorem identity38118 : scanCanonicalize (H12AffineFastState.compose env38118 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38119 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,49,40,32,0,35,48,0,52,1,33,33,16,2,40,16,0,48,49,0,20,33,36,32,32,42]

theorem envBound38119 : H12AffineFastState.Bounded env38119 := by
  intro p hp
  have h : env38119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38118_38119 : H12AffineEnvironment.transform 8 43 env38118 = env38119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38118 == env38119) = true)

def leafEnv38119 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,49,40,32,0,35,48,0,52,1,33,33,16,2,20,40,1,16,0,48,49,0,20,33,36,32,4,35,32,42,1,33,0]

def active38119 : List Nat := [0,1,2,3,4]

def tree38119 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38119 : H12WitnessSearch.Good tree38119 := H12GlobalWitnessIndex.good

theorem leafIdentity38119 : H12AffineFastState.composeSystem env38119 rootObs = leafEnv38119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38119 rootObs == leafEnv38119) = true)

theorem terminalChecked38119 : H12PackedTerminal.terminalCheckFast leafEnv38119 active38119 tree38119 = true := by decide +kernel

def env38120 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,0,35,49,1,53,1,33,33,16,2,40,16,1,49,49,1,21,33,36,32,33,513]

theorem envBound38120 : H12AffineFastState.Bounded env38120 := by
  intro p hp
  have h : env38120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38117_38120 : H12AffineEnvironment.transform 9 53 env38117 = env38120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38117 == env38120) = true)

def leafEnv38120 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,0,35,49,1,53,1,33,33,16,2,21,40,1,16,1,49,49,1,21,33,36,32,4,35,33,513,1,33,0]

def active38120 : List Nat := [0,1,2,3,4,8]

def tree38120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38120 : H12WitnessSearch.Good tree38120 := H12GlobalWitnessIndex.good

theorem leafIdentity38120 : H12AffineFastState.composeSystem env38120 rootObs = leafEnv38120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38120 rootObs == leafEnv38120) = true)

theorem terminalChecked38120 : H12PackedTerminal.terminalCheckFast leafEnv38120 active38120 tree38120 = true := by decide +kernel

def env38121 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,62509,16,41231,8192,17,409909,57629,17665,442384,61705,62509,256,41261,16385,513]

theorem envBound38121 : H12AffineFastState.Bounded env38121 := by
  intro p hp
  have h : env38121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38103_38121 : H12AffineEnvironment.transform 5 17 env38103 = env38121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38103 == env38121) = true)

theorem identity38121 : scanCanonicalize (H12AffineFastState.compose env38121 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38121 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env38122 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10280,1024,32769,4113,62509,16,41231,8192,17,157981,57629,17665,190520,61705,62509,256,41261,16385,513]

theorem envBound38122 : H12AffineFastState.Bounded env38122 := by
  intro p hp
  have h : env38122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38121_38122 : H12AffineEnvironment.transform 17 10280 env38121 = env38122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38121 == env38122) = true)

theorem identity38122 : scanCanonicalize (H12AffineFastState.compose env38122 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38122 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38123 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,54279,131072,2340,1024,32769,4113,54561,16,32771,268,17,149521,49169,17665,182580,53253,54561,256,32801,16385,513]

theorem envBound38123 : H12AffineFastState.Bounded env38123 := by
  intro p hp
  have h : env38123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38122_38123 : H12AffineEnvironment.transform 12 268 env38122 = env38123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38122 == env38123) = true)

theorem identity38123 : scanCanonicalize (H12AffineFastState.compose env38123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound38123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38124 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,54279,38160,2340,1024,32769,4113,54561,16,32771,268,17,56577,49169,17665,23588,53253,54561,256,32801,16385,513]

theorem envBound38124 : H12AffineFastState.Bounded env38124 := by
  intro p hp
  have h : env38124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38123_38124 : H12AffineEnvironment.transform 16 38160 env38123 = env38124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38123 == env38124) = true)

def env38125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,73770,16,95497,8192,64,496947,79131,102743,442384,61704,62589,256,95531,103431,120406]

theorem envBound38125 : H12AffineFastState.Bounded env38125 := by
  intro p hp
  have h : env38125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38101_38125 : H12AffineEnvironment.transform 23 95497 env38101 = env38125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env38101 == env38125) = true)

def env38126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,73770,16,95497,8192,64,382243,79131,102743,294912,61704,62589,256,95531,103431,120406]

theorem envBound38126 : H12AffineFastState.Bounded env38126 := by
  intro p hp
  have h : env38126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38125_38126 : H12AffineEnvironment.transform 16 16400 env38125 = env38126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env38125 == env38126) = true)

theorem identity38126 : scanCanonicalize (H12AffineFastState.compose env38126 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound38126 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env38127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16400,262144,1024,32769,4161,62589,16,41310,8192,64,262516,57676,17664,294912,61704,62589,256,41340,16464,513]

theorem envBound38127 : H12AffineFastState.Bounded env38127 := by
  intro p hp
  have h : env38127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38126_38127 : H12AffineEnvironment.transform 15 54359 env38126 = env38127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env38126 == env38127) = true)

theorem identity38127 : scanCanonicalize (H12AffineFastState.compose env38127 (packedSelected [1,2,3,5,6,8,10,11,19,32] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound38127 : packedSelected [1,2,3,5,6,8,10,11,19,32] rootPS < 2^1333 := by decide +kernel

def env38128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16400,64808,1024,32769,4161,62589,16,41310,8192,64,64604,57676,17664,32040,61704,62589,256,41340,16464,513]

theorem envBound38128 : H12AffineFastState.Bounded env38128 := by
  intro p hp
  have h : env38128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38127_38128 : H12AffineEnvironment.transform 17 64808 env38127 = env38128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env38127 == env38128) = true)

theorem identity38128 : scanCanonicalize (H12AffineFastState.compose env38128 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38128 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env38129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21591,16400,32040,1024,1,4161,29821,16,8542,8192,64,31836,24908,17664,32040,28936,29821,256,8572,16464,513]

theorem envBound38129 : H12AffineFastState.Bounded env38129 := by
  intro p hp
  have h : env38129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38128_38129 : H12AffineEnvironment.transform 14 0 env38128 = env38129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38128 == env38129) = true)

theorem identity38129 : scanCanonicalize (H12AffineFastState.compose env38129 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38129 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env38130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21591,16400,23668,1024,1,4161,21793,16,2,348,64,23808,16400,17664,23668,20564,21793,256,32,16464,513]

theorem envBound38130 : H12AffineFastState.Bounded env38130 := by
  intro p hp
  have h : env38130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38129_38130 : H12AffineEnvironment.transform 12 348 env38129 = env38130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38129 == env38130) = true)

theorem identity38130 : scanCanonicalize (H12AffineFastState.compose env38130 (packedSelected [0,2,4,6,7,9,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38130 : packedSelected [0,2,4,6,7,9,18] rootPS < 2^1333 := by decide +kernel

def env38131 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,0,21591,16400,23668,1024,1,4161,21509,16,2,120,64,23588,16400,17444,23668,20564,21509,36,32,16464,513]

theorem envBound38131 : H12AffineFastState.Bounded env38131 := by
  intro p hp
  have h : env38131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38130_38131 : H12AffineEnvironment.transform 7 36 env38130 = env38131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38130 == env38131) = true)

theorem identity38131 : scanCanonicalize (H12AffineFastState.compose env38131 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38131 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env38132 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,0,21511,16400,23588,1024,1,4113,21509,16,2,40,16,23588,16400,17444,23588,20484,21509,36,32,16384,513]

theorem envBound38132 : H12AffineFastState.Bounded env38132 := by
  intro p hp
  have h : env38132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38131_38132 : H12AffineEnvironment.transform 5 16 env38131 = env38132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38131 == env38132) = true)

theorem identity38132 : scanCanonicalize (H12AffineFastState.compose env38132 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38132 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38133 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,35,5172,2048,1024,1,4113,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound38133 : H12AffineFastState.Bounded env38133 := by
  intro p hp
  have h : env38133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38132_38133 : H12AffineEnvironment.transform 13 5156 env38132 = env38133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38132 == env38133) = true)

def env38134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115734,73770,16,95497,8192,64,382242,79131,102743,294913,61704,62589,256,95531,103431,120406]

theorem envBound38134 : H12AffineFastState.Bounded env38134 := by
  intro p hp
  have h : env38134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38125_38134 : H12AffineEnvironment.transform 16 16401 env38125 = env38134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env38125 == env38134) = true)

theorem identity38134 : scanCanonicalize (H12AffineFastState.compose env38134 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38134 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env38135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115734,73770,16,95497,8192,64,130314,79131,102743,43049,61704,62589,256,95531,103431,120406]

theorem envBound38135 : H12AffineFastState.Bounded env38135 := by
  intro p hp
  have h : env38135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38134_38135 : H12AffineEnvironment.transform 17 10280 env38134 = env38135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38134 == env38135) = true)

theorem identity38135 : scanCanonicalize (H12AffineFastState.compose env38135 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound38135 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16401,10280,1024,32769,4161,62589,16,41310,8192,64,10589,57676,17664,43049,61704,62589,256,41340,16464,513]

theorem envBound38136 : H12AffineFastState.Bounded env38136 := by
  intro p hp
  have h : env38136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38135_38136 : H12AffineEnvironment.transform 15 54359 env38135 = env38136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env38135 == env38136) = true)

theorem identity38136 : scanCanonicalize (H12AffineFastState.compose env38136 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38136 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21590,16401,10280,1024,0,4161,29820,16,8543,8192,64,10589,24909,17664,10280,28937,29820,256,8573,16464,513]

theorem envBound38137 : H12AffineFastState.Bounded env38137 := by
  intro p hp
  have h : env38137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38136_38137 : H12AffineEnvironment.transform 14 1 env38136 = env38137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38136 == env38137) = true)

def env38138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8193,64,17227834,18973701,102743,2556934,18890775,16875893,256,16777251,16834830,18966344]

theorem envBound38138 : H12AffineFastState.Bounded env38138 := by
  intro p hp
  have h : env38138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38099_38138 : H12AffineEnvironment.transform 6 9 env38099 = env38138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38099 == env38138) = true)

theorem identity38138 : scanCanonicalize (H12AffineFastState.compose env38138 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2327557) := by decide +kernel

theorem selectedBound38138 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env38139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,2327557,8193,64,2450495,131072,102743,2556934,246802,2229616,256,2327590,2319627,189261]

theorem envBound38139 : H12AffineFastState.Bounded env38139 := by
  intro p hp
  have h : env38139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38138_38139 : H12AffineEnvironment.transform 23 2327557 env38138 = env38139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2327557 env38138 == env38139) = true)

theorem identity38139 : scanCanonicalize (H12AffineFastState.compose env38139 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound38139 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,262144,1024,32769,2097152,2155580,2114897,2229586,8193,64,2418024,131072,4096,2524497,148805,2229616,256,2229617,2286684,189261]

theorem envBound38140 : H12AffineFastState.Bounded env38140 := by
  intro p hp
  have h : env38140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38139_38140 : H12AffineEnvironment.transform 15 33111 env38139 = env38140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env38139 == env38140) = true)

theorem identity38140 : scanCanonicalize (H12AffineFastState.compose env38140 (packedSelected [11,15,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound38140 : packedSelected [11,15,32,38] rootPS < 2^1333 := by decide +kernel

def env38141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,24861,262144,1024,32769,2097152,2155580,2114897,2122831,8193,64,2418024,24861,4096,2417740,9304,2122861,256,2122860,2131265,33360]

theorem envBound38141 : H12AffineFastState.Bounded env38141 := by
  intro p hp
  have h : env38141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38140_38141 : H12AffineEnvironment.transform 16 24861 env38140 = env38141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env38140 == env38141) = true)

theorem identity38141 : scanCanonicalize (H12AffineFastState.compose env38141 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound38141 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env38142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,24861,43128,1024,32769,2097152,2155580,2114897,2122831,8193,64,2116880,24861,4096,2116660,9304,2122861,256,2122860,2131265,33360]

theorem envBound38142 : H12AffineFastState.Bounded env38142 := by
  intro p hp
  have h : env38142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38141_38142 : H12AffineEnvironment.transform 17 43128 env38141 = env38142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env38141 == env38142) = true)

theorem identity38142 : scanCanonicalize (H12AffineFastState.compose env38142 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound38142 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,32768,33111,5220,43128,1024,32769,2097152,2134341,2109480,2101558,8193,64,2111593,5220,4096,2111821,9304,2101524,256,2101525,2131265,33360]

theorem envBound38143 : H12AffineFastState.Bounded env38143 := by
  intro p hp
  have h : env38143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38142_38143 : H12AffineEnvironment.transform 13 13689 env38142 = env38143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env38142 == env38143) = true)

theorem identity38143 : scanCanonicalize (H12AffineFastState.compose env38143 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38143 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env38144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33111,5220,35189,1024,32769,2097152,2134341,2101541,2101558,268,64,2103652,5220,4096,2103360,1365,2101524,256,2101525,2131265,33360]

theorem envBound38144 : H12AffineFastState.Bounded env38144 := by
  intro p hp
  have h : env38144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38143_38144 : H12AffineEnvironment.transform 12 269 env38143 = env38144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38143 == env38144) = true)

theorem identity38144 : scanCanonicalize (H12AffineFastState.compose env38144 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 37220) := by decide +kernel

theorem selectedBound38144 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33111,5220,35189,1024,32769,37220,33,32833,32850,268,64,34816,5220,4096,35108,1365,32880,256,32881,5157,33360]

theorem envBound38145 : H12AffineFastState.Bounded env38145 := by
  intro p hp
  have h : env38145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38144_38145 : H12AffineEnvironment.transform 20 37220 env38144 = env38145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37220 env38144 == env38145) = true)

theorem identity38145 : scanCanonicalize (H12AffineFastState.compose env38145 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38145 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env38146 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,32768,32802,5220,34816,1024,32769,36881,33,32833,32850,121,64,34816,5220,4096,34897,1056,32880,117,32881,5157,33360]

theorem envBound38146 : H12AffineFastState.Bounded env38146 := by
  intro p hp
  have h : env38146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38145_38146 : H12AffineEnvironment.transform 7 117 env38145 = env38146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38145 == env38146) = true)

theorem identity38146 : scanCanonicalize (H12AffineFastState.compose env38146 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound38146 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env38147 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,81,115,5220,2129,1024,80,4160,33,16,3,121,64,2129,5220,4096,2048,1056,33,117,32,5157,513]

theorem envBound38147 : H12AffineFastState.Bounded env38147 := by
  intro p hp
  have h : env38147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38146_38147 : H12AffineEnvironment.transform 14 81 env38146 = env38147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env38146 == env38147) = true)

theorem identity38147 : scanCanonicalize (H12AffineFastState.compose env38147 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound38147 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38148 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,120,4113,81,115,4097,2129,101,80,4160,33,16,3,121,64,2129,4097,4096,2048,69,33,117,32,4160,513]

theorem envBound38148 : H12AffineFastState.Bounded env38148 := by
  intro p hp
  have h : env38148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38147_38148 : H12AffineEnvironment.transform 9 101 env38147 = env38148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env38147 == env38148) = true)

theorem identity38148 : scanCanonicalize (H12AffineFastState.compose env38148 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38149 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,0,34,4097,2048,52,1,4113,33,16,3,40,17,2048,4097,4096,2048,20,33,36,32,4113,513]

theorem envBound38149 : H12AffineFastState.Bounded env38149 := by
  intro p hp
  have h : env38149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38148_38149 : H12AffineEnvironment.transform 5 17 env38148 = env38149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38148 == env38149) = true)

theorem identity38149 : scanCanonicalize (H12AffineFastState.compose env38149 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound38149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38150 : List Nat := [2,4,8,16,32,17,9,36,512,52,512,4096,41,4113,0,34,4097,512,52,1,4113,33,16,3,40,17,512,4097,4096,512,20,33,36,32,4113,513]

theorem envBound38150 : H12AffineFastState.Bounded env38150 := by
  intro p hp
  have h : env38150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38149_38150 : H12AffineEnvironment.transform 10 512 env38149 = env38150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env38149 == env38150) = true)

theorem identity38150 : scanCanonicalize (H12AffineFastState.compose env38150 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound38150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38151 : List Nat := [2,4,8,16,32,17,9,36,10,52,10,4096,41,4113,0,34,4097,10,52,1,4113,33,16,3,40,17,10,4097,4096,10,20,33,36,32,4113,11]

theorem envBound38151 : H12AffineFastState.Bounded env38151 := by
  intro p hp
  have h : env38151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38150_38151 : H12AffineEnvironment.transform 8 10 env38150 = env38151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env38150 == env38151) = true)

def env38152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8328,64,17227835,18973836,102743,2556934,18890775,16876029,256,16777386,16834830,18966465]

theorem envBound38152 : H12AffineFastState.Bounded env38152 := by
  intro p hp
  have h : env38152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38098_38152 : H12AffineEnvironment.transform 21 2155581 env38098 = env38152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env38098 == env38152) = true)

def env38153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8192,64,17227835,18973700,102743,2556934,18890775,16875893,256,16777250,16834830,18966345]

theorem envBound38153 : H12AffineFastState.Bounded env38153 := by
  intro p hp
  have h : env38153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38152_38153 : H12AffineEnvironment.transform 6 8 env38152 = env38153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38152 == env38153) = true)

def env38154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62589,119878,16777216,8192,64,17227835,16880708,102743,463942,16797783,16875893,256,16777250,16834830,16873225]

theorem envBound38154 : H12AffineFastState.Bounded env38154 := by
  intro p hp
  have h : env38154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38153_38154 : H12AffineEnvironment.transform 20 4160 env38153 = env38154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38153 == env38154) = true)

def env38155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119878,16777216,8192,64,16959507,16880708,102743,212078,16797783,16875893,256,16777250,16834830,16873225]

theorem envBound38155 : H12AffineFastState.Bounded env38155 := by
  intro p hp
  have h : env38155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38154_38155 : H12AffineEnvironment.transform 17 10280 env38154 = env38155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38154 == env38155) = true)

def env38156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119878,95496,8192,64,245019,57676,102743,212078,75103,62589,256,95530,103430,513]

theorem envBound38156 : H12AffineFastState.Bounded env38156 := by
  intro p hp
  have h : env38156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38155_38156 : H12AffineEnvironment.transform 23 95496 env38155 = env38156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env38155 == env38156) = true)

theorem identity38156 : scanCanonicalize (H12AffineFastState.compose env38156 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38156 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env38157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,4160,21792,95515,95496,8192,64,203846,16401,77834,212078,75103,21792,256,95530,79195,513]

theorem envBound38157 : H12AffineFastState.Bounded env38157 := by
  intro p hp
  have h : env38157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38156_38157 : H12AffineEnvironment.transform 14 8541 env38156 = env38157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38156 == env38157) = true)

theorem identity38157 : scanCanonicalize (H12AffineFastState.compose env38157 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound38157 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env38158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,65536,131072,10280,1024,8540,4160,113,73802,73817,8192,64,203846,5440,77834,212078,75103,113,256,73851,79195,513]

theorem envBound38158 : H12AffineFastState.Bounded env38158 := by
  intro p hp
  have h : env38158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38157_38158 : H12AffineEnvironment.transform 13 5457 env38157 = env38158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env38157 == env38158) = true)

theorem identity38158 : scanCanonicalize (H12AffineFastState.compose env38158 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38158 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38159 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,65536,131072,10280,1024,8460,4112,33,73754,73737,8192,16,203798,5392,77834,212030,75023,33,256,73771,79115,513]

theorem envBound38159 : H12AffineFastState.Bounded env38159 := by
  intro p hp
  have h : env38159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38158_38159 : H12AffineEnvironment.transform 5 16 env38158 = env38159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38158 == env38159) = true)

theorem identity38159 : scanCanonicalize (H12AffineFastState.compose env38159 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound38159 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38160 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,65536,70679,10280,1024,8460,4112,33,73754,73737,8192,16,2049,5392,77834,10281,75023,33,256,73771,79115,513]

theorem envBound38160 : H12AffineFastState.Bounded env38160 := by
  intro p hp
  have h : env38160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38159_38160 : H12AffineEnvironment.transform 16 70679 env38159 = env38160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env38159 == env38160) = true)

theorem identity38160 : scanCanonicalize (H12AffineFastState.compose env38160 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38160 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38161 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8202,13341,10280,1024,8460,4112,33,16,3,8192,16,2049,5392,4096,10281,1285,33,256,33,5377,513]

theorem envBound38161 : H12AffineFastState.Bounded env38161 := by
  intro p hp
  have h : env38161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38160_38161 : H12AffineEnvironment.transform 15 8202 env38160 = env38161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38160 == env38161) = true)

def env38162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119878,95497,8192,64,245018,57677,102743,212078,75102,62588,256,95531,103431,512]

theorem envBound38162 : H12AffineFastState.Bounded env38162 := by
  intro p hp
  have h : env38162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38155_38162 : H12AffineEnvironment.transform 23 95497 env38155 = env38162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env38155 == env38162) = true)

theorem identity38162 : scanCanonicalize (H12AffineFastState.compose env38162 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound38162 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4160,62589,41293,2,8192,64,182289,57677,58460,149861,20565,62588,256,32,57612,512]

theorem envBound38163 : H12AffineFastState.Bounded env38163 := by
  intro p hp
  have h : env38163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38162_38163 : H12AffineEnvironment.transform 15 29963 env38162 = env38163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env38162 == env38163) = true)

theorem identity38163 : scanCanonicalize (H12AffineFastState.compose env38163 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58380) := by decide +kernel

theorem selectedBound38163 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,58380,10280,1024,32769,4160,62589,41293,2,8192,64,11293,57677,58460,44393,20565,62588,256,32,57612,512]

theorem envBound38164 : H12AffineFastState.Bounded env38164 := by
  intro p hp
  have h : env38164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38163_38164 : H12AffineEnvironment.transform 16 58380 env38163 = env38164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58380 env38163 == env38164) = true)

theorem identity38164 : scanCanonicalize (H12AffineFastState.compose env38164 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22805) := by decide +kernel

theorem selectedBound38164 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env38165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,22805,29963,15641,10280,1024,22804,4160,11624,30808,2,8192,64,11293,14424,15689,29820,20565,11625,256,32,14361,512]

theorem envBound38165 : H12AffineFastState.Bounded env38165 := by
  intro p hp
  have h : env38165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38164_38165 : H12AffineEnvironment.transform 14 22805 env38164 = env38165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22805 env38164 == env38165) = true)

theorem identity38165 : scanCanonicalize (H12AffineFastState.compose env38165 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound38165 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env38166 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,16384,22805,28747,14425,10280,320,22804,4160,10280,30808,2,8192,64,10589,14424,14345,28988,20565,10281,256,32,14361,512]

theorem envBound38166 : H12AffineFastState.Bounded env38166 := by
  intro p hp
  have h : env38166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38165_38166 : H12AffineEnvironment.transform 9 320 env38165 = env38166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38165 == env38166) = true)

theorem identity38166 : scanCanonicalize (H12AffineFastState.compose env38166 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound38166 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38167 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,17,8192,16384,18692,24666,10312,10280,320,18693,81,10280,26697,2,8192,64,10589,10313,10264,24877,16452,10281,256,32,10248,512]

theorem envBound38167 : H12AffineFastState.Bounded env38167 := by
  intro p hp
  have h : env38167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38166_38167 : H12AffineEnvironment.transform 11 17 env38166 = env38167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env38166 == env38167) = true)

theorem identity38167 : scanCanonicalize (H12AffineFastState.compose env38167 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38167 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env38168 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,8192,16384,18692,24586,10264,10280,272,18693,1,10280,26649,2,8192,16,10509,10265,10264,24877,16404,10281,256,32,10248,512]

theorem envBound38168 : H12AffineFastState.Bounded env38168 := by
  intro p hp
  have h : env38168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38167_38168 : H12AffineEnvironment.transform 5 16 env38167 = env38168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38167 == env38168) = true)

theorem identity38168 : scanCanonicalize (H12AffineFastState.compose env38168 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound38168 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env38169 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,8192,10508,8200,2310,10264,10280,272,8201,1,10280,277,2,8192,16,10509,10265,10264,2081,10520,10281,256,32,10248,512]

theorem envBound38169 : H12AffineFastState.Bounded env38169 := by
  intro p hp
  have h : env38169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38168_38169 : H12AffineEnvironment.transform 13 10508 env38168 = env38169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env38168 == env38169) = true)

theorem identity38169 : scanCanonicalize (H12AffineFastState.compose env38169 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound38169 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env38170 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,9,2309,1,2310,2065,2081,272,0,1,2081,277,2,9,16,2308,2064,2065,2081,2321,2080,256,32,2049,512]

theorem envBound38170 : H12AffineFastState.Bounded env38170 := by
  intro p hp
  have h : env38170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38169_38170 : H12AffineEnvironment.transform 12 9 env38169 = env38170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env38169 == env38170) = true)

theorem identity38170 : scanCanonicalize (H12AffineFastState.compose env38170 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38170 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env38171 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,9,260,1,263,16,32,272,0,1,32,277,2,9,16,261,17,16,32,272,33,256,32,0,512]

theorem envBound38171 : H12AffineFastState.Bounded env38171 := by
  intro p hp
  have h : env38171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38170_38171 : H12AffineEnvironment.transform 10 1 env38170 = env38171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38170 == env38171) = true)

theorem identity38171 : scanCanonicalize (H12AffineFastState.compose env38171 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38171 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38172 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,17,9,33,1,34,16,32,53,0,1,32,48,2,9,16,32,17,16,32,53,33,37,32,0,512]

theorem envBound38172 : H12AffineFastState.Bounded env38172 := by
  intro p hp
  have h : env38172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38171_38172 : H12AffineEnvironment.transform 7 37 env38171 = env38172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38171 == env38172) = true)

theorem identity38172 : scanCanonicalize (H12AffineFastState.compose env38172 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38173 : List Nat := [2,4,8,16,0,16,8,5,512,21,1,17,9,1,1,2,16,0,21,0,1,0,16,2,9,16,0,17,16,0,21,1,5,0,0,512]

theorem envBound38173 : H12AffineFastState.Bounded env38173 := by
  intro p hp
  have h : env38173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38172_38173 : H12AffineEnvironment.transform 4 0 env38172 = env38173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38172 == env38173) = true)

theorem identity38173 : scanCanonicalize (H12AffineFastState.compose env38173 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound38173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38174 : List Nat := [2,4,8,16,0,16,8,5,30,21,1,17,9,1,1,2,16,0,21,0,1,0,16,2,9,16,0,17,16,0,21,1,5,0,0,30]

theorem envBound38174 : H12AffineFastState.Bounded env38174 := by
  intro p hp
  have h : env38174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38173_38174 : H12AffineEnvironment.transform 8 30 env38173 = env38174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env38173 == env38174) = true)

theorem identity38174 : scanCanonicalize (H12AffineFastState.compose env38174 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound38174 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38175 : List Nat := [2,4,8,14,0,14,8,5,0,11,1,15,9,1,1,2,14,0,11,0,1,0,14,2,9,14,0,15,14,0,11,1,5,0,0,0]

theorem envBound38175 : H12AffineFastState.Bounded env38175 := by
  intro p hp
  have h : env38175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38174_38175 : H12AffineEnvironment.transform 3 14 env38174 = env38175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env38174 == env38175) = true)

theorem identity38175 : scanCanonicalize (H12AffineFastState.compose env38175 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound38175 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38176 : List Nat := [2,4,6,0,0,0,6,5,0,5,1,1,7,1,1,2,0,0,5,0,1,0,0,2,7,0,0,1,0,0,5,1,5,0,0,0]

theorem envBound38176 : H12AffineFastState.Bounded env38176 := by
  intro p hp
  have h : env38176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38175_38176 : H12AffineEnvironment.transform 2 6 env38175 = env38176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env38175 == env38176) = true)

def env38177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119878,16777216,8192,64,16959506,16880708,102743,212079,16797783,16875893,256,16777250,16834830,16873225]

theorem envBound38177 : H12AffineFastState.Bounded env38177 := by
  intro p hp
  have h : env38177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38154_38177 : H12AffineEnvironment.transform 17 10281 env38154 = env38177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38154 == env38177) = true)

theorem identity38177 : scanCanonicalize (H12AffineFastState.compose env38177 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound38177 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4160,62589,16,16777216,8192,64,16959506,16793618,17665,190521,16797783,16799011,256,16777250,16834830,16819039]

theorem envBound38178 : H12AffineFastState.Bounded env38178 := by
  intro p hp
  have h : env38178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38177_38178 : H12AffineEnvironment.transform 15 54358 env38177 = env38178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env38177 == env38178) = true)

theorem identity38178 : scanCanonicalize (H12AffineFastState.compose env38178 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 136467) := by decide +kernel

theorem selectedBound38178 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4160,62589,16,136467,8192,64,56577,152833,17665,190521,148804,147504,256,136497,193565,177740]

theorem envBound38179 : H12AffineFastState.Bounded env38179 := by
  intro p hp
  have h : env38179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38178_38179 : H12AffineEnvironment.transform 23 136467 env38178 = env38179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136467 env38178 == env38179) = true)

theorem identity38179 : scanCanonicalize (H12AffineFastState.compose env38179 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound38179 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,4096,10281,1024,32769,4160,62589,16,1299,8192,64,56577,17665,17665,63545,21828,20528,256,1329,58397,42572]

theorem envBound38180 : H12AffineFastState.Bounded env38180 := by
  intro p hp
  have h : env38180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38179_38180 : H12AffineEnvironment.transform 16 4096 env38179 = env38180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env38179 == env38180) = true)

theorem identity38180 : scanCanonicalize (H12AffineFastState.compose env38180 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 28728) := by decide +kernel

theorem selectedBound38180 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env38181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,28728,9326,4096,10281,1024,28729,4160,1093,16,1299,8192,64,11577,17665,17665,2049,21828,20528,256,1329,5157,22132]

theorem envBound38181 : H12AffineFastState.Bounded env38181 := by
  intro p hp
  have h : env38181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38180_38181 : H12AffineEnvironment.transform 14 28728 env38180 = env38181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28728 env38180 == env38181) = true)

theorem identity38181 : scanCanonicalize (H12AffineFastState.compose env38181 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound38181 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env38182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,9293,9326,4096,10281,1024,9292,4160,1093,16,1299,8192,64,11577,4468,4468,2049,305,1093,256,1329,5157,513]

theorem envBound38182 : H12AffineFastState.Bounded env38182 := by
  intro p hp
  have h : env38182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38181_38182 : H12AffineEnvironment.transform 13 5237 env38181 = env38182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env38181 == env38182) = true)

theorem identity38182 : scanCanonicalize (H12AffineFastState.compose env38182 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound38182 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5237,1,34,4096,3173,1024,0,4160,1093,16,1299,1100,64,2421,4468,4468,2049,305,1093,256,1329,5157,513]

theorem envBound38183 : H12AffineFastState.Bounded env38183 := by
  intro p hp
  have h : env38183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38182_38183 : H12AffineEnvironment.transform 12 1100 env38182 = env38183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env38182 == env38183) = true)

theorem identity38183 : scanCanonicalize (H12AffineFastState.compose env38183 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound38183 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,1100,1077,1,34,64,3173,1024,0,0,1093,16,1299,1100,64,2421,308,308,2049,305,1093,256,1329,1125,513]

theorem envBound38184 : H12AffineFastState.Bounded env38184 := by
  intro p hp
  have h : env38184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38183_38184 : H12AffineEnvironment.transform 11 64 env38183 = env38184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env38183 == env38184) = true)

theorem identity38184 : scanCanonicalize (H12AffineFastState.compose env38184 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound38184 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env38185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,64,1100,1077,1,34,64,1344,1024,0,0,1093,16,1299,1100,64,80,308,308,292,305,1093,256,1329,1125,513]

theorem envBound38185 : H12AffineFastState.Bounded env38185 := by
  intro p hp
  have h : env38185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38184_38185 : H12AffineEnvironment.transform 10 293 env38184 = env38185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env38184 == env38185) = true)

theorem identity38185 : scanCanonicalize (H12AffineFastState.compose env38185 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound38185 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38186 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,64,41,80,1,34,64,293,101,0,0,32,16,374,41,64,80,308,308,292,305,32,256,340,0,513]

theorem envBound38186 : H12AffineFastState.Bounded env38186 := by
  intro p hp
  have h : env38186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38185_38186 : H12AffineEnvironment.transform 9 101 env38185 = env38186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env38185 == env38186) = true)

theorem identity38186 : scanCanonicalize (H12AffineFastState.compose env38186 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38187 : List Nat := [2,4,8,16,32,64,8,37,512,101,0,64,41,80,1,34,64,0,101,0,0,32,16,83,41,64,80,17,17,1,20,32,37,113,0,513]

theorem envBound38187 : H12AffineFastState.Bounded env38187 := by
  intro p hp
  have h : env38187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38186_38187 : H12AffineEnvironment.transform 7 37 env38186 = env38187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38186 == env38187) = true)

theorem identity38187 : scanCanonicalize (H12AffineFastState.compose env38187 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38187 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38188 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,41,0,1,34,16,0,53,0,0,32,16,3,41,16,0,17,17,1,20,32,37,33,0,513]

theorem envBound38188 : H12AffineFastState.Bounded env38188 := by
  intro p hp
  have h : env38188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38187_38188 : H12AffineEnvironment.transform 5 16 env38187 = env38188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38187 == env38188) = true)

theorem identity38188 : scanCanonicalize (H12AffineFastState.compose env38188 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38188 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38189 : List Nat := [2,4,8,16,16,16,8,21,512,5,0,16,25,0,1,18,16,0,5,0,0,16,16,3,25,16,0,17,17,1,20,16,21,17,0,513]

theorem envBound38189 : H12AffineFastState.Bounded env38189 := by
  intro p hp
  have h : env38189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38188_38189 : H12AffineEnvironment.transform 4 16 env38188 = env38189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38188 == env38189) = true)

def env38190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62588,119879,16777216,8192,64,17227835,16880709,102743,463943,16797782,16875893,256,16777250,16834830,16873224]

theorem envBound38190 : H12AffineFastState.Bounded env38190 := by
  intro p hp
  have h : env38190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38153_38190 : H12AffineEnvironment.transform 20 4161 env38153 = env38190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38153 == env38190) = true)

theorem identity38190 : scanCanonicalize (H12AffineFastState.compose env38190 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound38190 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62588,119879,95497,8192,64,496946,57676,102743,463943,75103,62588,256,95531,103431,513]

theorem envBound38191 : H12AffineFastState.Bounded env38191 := by
  intro p hp
  have h : env38191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38190_38191 : H12AffineEnvironment.transform 23 95497 env38190 = env38191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env38190 == env38191) = true)

def env38192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119879,95497,8192,64,245018,57676,102743,212079,75103,62588,256,95531,103431,513]

theorem envBound38192 : H12AffineFastState.Bounded env38192 := by
  intro p hp
  have h : env38192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38191_38192 : H12AffineEnvironment.transform 17 10280 env38191 = env38192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38191 == env38192) = true)

theorem identity38192 : scanCanonicalize (H12AffineFastState.compose env38192 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38192 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env38193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,4161,21793,95514,95497,8192,64,203847,16401,77834,212079,75103,21793,256,95531,79194,513]

theorem envBound38193 : H12AffineFastState.Bounded env38193 := by
  intro p hp
  have h : env38193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38192_38193 : H12AffineEnvironment.transform 14 8541 env38192 = env38193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38192 == env38193) = true)

theorem identity38193 : scanCanonicalize (H12AffineFastState.compose env38193 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound38193 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env38194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,65536,131072,10280,1024,8540,4161,113,73802,73817,8192,64,203847,5441,77834,212079,75103,113,256,73851,79194,513]

theorem envBound38194 : H12AffineFastState.Bounded env38194 := by
  intro p hp
  have h : env38194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38193_38194 : H12AffineEnvironment.transform 13 5456 env38193 = env38194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env38193 == env38194) = true)

theorem identity38194 : scanCanonicalize (H12AffineFastState.compose env38194 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38194 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38195 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,131072,10280,1024,8460,4113,33,73754,73737,8192,16,203799,5393,77834,212031,75023,33,256,73771,79114,513]

theorem envBound38195 : H12AffineFastState.Bounded env38195 := by
  intro p hp
  have h : env38195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38194_38195 : H12AffineEnvironment.transform 5 16 env38194 = env38195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38194 == env38195) = true)

theorem identity38195 : scanCanonicalize (H12AffineFastState.compose env38195 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound38195 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38196 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,70678,10280,1024,8460,4113,33,73754,73737,8192,16,2049,5393,77834,10281,75023,33,256,73771,79114,513]

theorem envBound38196 : H12AffineFastState.Bounded env38196 := by
  intro p hp
  have h : env38196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38195_38196 : H12AffineEnvironment.transform 16 70678 env38195 = env38196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env38195 == env38196) = true)

theorem identity38196 : scanCanonicalize (H12AffineFastState.compose env38196 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38196 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38197 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10280,1024,8460,4113,33,16,3,8192,16,2049,5393,4096,10281,1285,33,256,33,5376,513]

theorem envBound38197 : H12AffineFastState.Bounded env38197 := by
  intro p hp
  have h : env38197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38196_38197 : H12AffineEnvironment.transform 15 8202 env38196 = env38197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38196 == env38197) = true)

def env38198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62588,119879,95497,8192,64,245019,57676,102743,212078,75103,62588,256,95531,103431,513]

theorem envBound38198 : H12AffineFastState.Bounded env38198 := by
  intro p hp
  have h : env38198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38191_38198 : H12AffineEnvironment.transform 17 10281 env38191 = env38198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38191 == env38198) = true)

theorem identity38198 : scanCanonicalize (H12AffineFastState.compose env38198 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38198 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,4161,62588,119879,95497,8192,64,56576,57676,102743,23669,75103,62588,256,95531,103431,513]

theorem envBound38199 : H12AffineFastState.Bounded env38199 := by
  intro p hp
  have h : env38199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38198_38199 : H12AffineEnvironment.transform 16 90139 env38198 = env38199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38198 == env38199) = true)

theorem identity38199 : scanCanonicalize (H12AffineFastState.compose env38199 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound38199 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,65536,90139,10281,1024,9293,4161,20528,94219,95497,8192,64,31052,17664,79131,23669,75103,20528,256,95531,77899,513]

theorem envBound38200 : H12AffineFastState.Bounded env38200 := by
  intro p hp
  have h : env38200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38199_38200 : H12AffineEnvironment.transform 14 9292 env38199 = env38200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env38199 == env38200) = true)

theorem identity38200 : scanCanonicalize (H12AffineFastState.compose env38200 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound38200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,28699,4096,10281,1024,9293,4161,20528,16,1298,8192,64,31052,17664,17664,23669,21828,20528,256,1328,16464,513]

theorem envBound38201 : H12AffineFastState.Bounded env38201 := by
  intro p hp
  have h : env38201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38200_38201 : H12AffineEnvironment.transform 15 28699 env38200 = env38201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env38200 == env38201) = true)

theorem identity38201 : scanCanonicalize (H12AffineFastState.compose env38201 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound38201 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,16384,4160,17431,4096,7205,1024,4161,4161,20528,16,1298,5132,64,19776,17664,17664,23669,21828,20528,256,1328,16464,513]

theorem envBound38202 : H12AffineFastState.Bounded env38202 := by
  intro p hp
  have h : env38202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38201_38202 : H12AffineEnvironment.transform 12 5132 env38201 = env38202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env38201 == env38202) = true)

theorem identity38202 : scanCanonicalize (H12AffineFastState.compose env38202 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound38202 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env38203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,41,16384,1125,17431,1061,2048,1024,1124,1124,17429,16,1298,41,64,19776,17664,17664,18512,16737,17429,256,1328,16464,513]

theorem envBound38203 : H12AffineFastState.Bounded env38203 := by
  intro p hp
  have h : env38203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38202_38203 : H12AffineEnvironment.transform 11 1061 env38202 = env38203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env38202 == env38203) = true)

theorem identity38203 : scanCanonicalize (H12AffineFastState.compose env38203 (packedSelected [0,1,2,3,5,7,8,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound38203 : packedSelected [0,1,2,3,5,7,8,15,18] rootPS < 2^1333 := by decide +kernel

def env38204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,16384,1125,17431,1061,373,1024,1124,1124,17429,16,1298,41,64,17461,17664,17664,16677,16737,17429,256,1328,16464,513]

theorem envBound38204 : H12AffineFastState.Bounded env38204 := by
  intro p hp
  have h : env38204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38203_38204 : H12AffineEnvironment.transform 10 373 env38203 = env38204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env38203 == env38204) = true)

theorem identity38204 : scanCanonicalize (H12AffineFastState.compose env38204 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound38204 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env38205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,1345,1125,342,1061,373,1024,1124,1124,340,16,1298,41,64,372,65,65,1124,1056,340,256,1328,1297,513]

theorem envBound38205 : H12AffineFastState.Bounded env38205 := by
  intro p hp
  have h : env38205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38204_38205 : H12AffineEnvironment.transform 13 1345 env38204 = env38205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env38204 == env38205) = true)

theorem identity38205 : scanCanonicalize (H12AffineFastState.compose env38205 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38205 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env38206 : List Nat := [2,4,8,16,32,17,8,256,512,1024,292,1061,41,1296,1076,263,1061,292,1024,1077,1077,261,16,1298,41,17,293,16,16,1077,1056,261,256,1328,1297,513]

theorem envBound38206 : H12AffineFastState.Bounded env38206 := by
  intro p hp
  have h : env38206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38205_38206 : H12AffineEnvironment.transform 5 17 env38205 = env38206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38205 == env38206) = true)

def env38207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8193,64,17227835,18973701,102743,2556934,18890775,16875892,256,16777251,16834830,18966344]

theorem envBound38207 : H12AffineFastState.Bounded env38207 := by
  intro p hp
  have h : env38207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38152_38207 : H12AffineEnvironment.transform 6 9 env38152 = env38207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38152 == env38207) = true)

theorem identity38207 : scanCanonicalize (H12AffineFastState.compose env38207 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound38207 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env38208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,147475,8193,64,303144,2343958,102743,2556934,2228228,246119,256,147504,172317,2303835]

theorem envBound38208 : H12AffineFastState.Bounded env38208 := by
  intro p hp
  have h : env38208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38207_38208 : H12AffineEnvironment.transform 23 147475 env38207 = env38208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env38207 == env38208) = true)

def env38209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62589,119878,147475,8193,64,303144,250966,102743,463942,135236,246119,256,147504,172317,210715]

theorem envBound38209 : H12AffineFastState.Bounded env38209 := by
  intro p hp
  have h : env38209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38208_38209 : H12AffineEnvironment.transform 20 4160 env38208 = env38209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38208 == env38209) = true)

theorem identity38209 : scanCanonicalize (H12AffineFastState.compose env38209 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38209 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,4160,62589,119878,73736,8193,64,303144,46157,102743,291933,94303,41340,256,73771,114950,22272]

theorem envBound38210 : H12AffineFastState.Bounded env38210 := by
  intro p hp
  have h : env38210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38209_38210 : H12AffineEnvironment.transform 16 90139 env38209 = env38210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38209 == env38210) = true)

theorem identity38210 : scanCanonicalize (H12AffineFastState.compose env38210 (packedSelected [1,3,5,8,10,11,12,15,18,19,21,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38210 : packedSelected [1,3,5,8,10,11,12,15,18,19,21,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env38211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90139,262144,1024,8541,4160,21793,95514,73736,8193,64,262516,5393,77835,291933,94303,32,256,73771,90202,22272]

theorem envBound38211 : H12AffineFastState.Bounded env38211 := by
  intro p hp
  have h : env38211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38210_38211 : H12AffineEnvironment.transform 14 8540 env38210 = env38211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38210 == env38211) = true)

theorem identity38211 : scanCanonicalize (H12AffineFastState.compose env38211 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound38211 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env38212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90139,89378,1024,8541,4160,21793,95514,73736,8193,64,89174,5393,77835,76159,94303,32,256,73771,90202,22272]

theorem envBound38212 : H12AffineFastState.Bounded env38212 := by
  intro p hp
  have h : env38212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38211_38212 : H12AffineEnvironment.transform 17 89378 env38211 = env38212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env38211 == env38212) = true)

theorem identity38212 : scanCanonicalize (H12AffineFastState.compose env38212 (packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38212 : packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env38213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,263,24860,23589,1024,8541,4160,21793,29725,8463,8193,64,23889,5393,12556,10360,29016,32,256,8492,24925,22272]

theorem envBound38213 : H12AffineFastState.Bounded env38213 := by
  intro p hp
  have h : env38213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38212_38213 : H12AffineEnvironment.transform 15 263 env38212 = env38213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38212 == env38213) = true)

theorem identity38213 : scanCanonicalize (H12AffineFastState.compose env38213 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38213 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env38214 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,114,24681,23589,1024,8232,4160,21588,29725,8314,8193,64,23588,5220,12409,10360,28717,32,117,8281,24616,22133]

theorem envBound38214 : H12AffineFastState.Bounded env38214 := by
  intro p hp
  have h : env38214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38213_38214 : H12AffineEnvironment.transform 7 117 env38213 = env38214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38213 == env38214) = true)

theorem identity38214 : scanCanonicalize (H12AffineFastState.compose env38214 (packedSelected [1,2,4,6,7,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 8232) := by decide +kernel

theorem selectedBound38214 : packedSelected [1,2,4,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env38215 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,8232,8233,114,65,15373,1024,8232,4160,13436,5173,8314,8193,64,15372,5220,12409,10360,4101,32,117,8281,0,13917]

theorem envBound38215 : H12AffineFastState.Bounded env38215 := by
  intro p hp
  have h : env38215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38214_38215 : H12AffineEnvironment.transform 13 8232 env38214 = env38215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8232 env38214 == env38215) = true)

theorem identity38215 : scanCanonicalize (H12AffineFastState.compose env38215 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound38215 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env38216 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,8192,8232,8233,114,65,8232,1024,8232,3173,10329,2064,8314,8193,64,8233,2113,11356,10360,3104,32,117,8281,0,10872]

theorem envBound38216 : H12AffineFastState.Bounded env38216 := by
  intro p hp
  have h : env38216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38215_38216 : H12AffineEnvironment.transform 11 3109 env38215 = env38216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env38215 == env38216) = true)

theorem identity38216 : scanCanonicalize (H12AffineFastState.compose env38216 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38216 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env38217 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,2065,8192,8232,8233,114,65,8232,52,8232,2129,10329,2064,8314,8193,64,8233,2113,10344,10360,2068,32,117,8281,0,10872]

theorem envBound38217 : H12AffineFastState.Bounded env38217 := by
  intro p hp
  have h : env38217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38216_38217 : H12AffineEnvironment.transform 9 52 env38216 = env38217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38216 == env38217) = true)

theorem identity38217 : scanCanonicalize (H12AffineFastState.compose env38217 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38217 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env38218 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,2065,40,0,1,114,65,0,52,0,2129,2161,2064,82,41,64,1,2113,2112,2128,2068,32,117,113,0,2640]

theorem envBound38218 : H12AffineFastState.Bounded env38218 := by
  intro p hp
  have h : env38218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38217_38218 : H12AffineEnvironment.transform 12 40 env38217 = env38218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38217 == env38218) = true)

theorem identity38218 : scanCanonicalize (H12AffineFastState.compose env38218 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound38218 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38219 : List Nat := [2,4,8,16,32,64,9,117,512,52,80,65,40,0,1,114,65,0,52,0,1,33,64,82,41,64,1,17,16,0,68,32,117,113,0,512]

theorem envBound38219 : H12AffineFastState.Bounded env38219 := by
  intro p hp
  have h : env38219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38218_38219 : H12AffineEnvironment.transform 10 80 env38218 = env38219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env38218 == env38219) = true)

theorem identity38219 : scanCanonicalize (H12AffineFastState.compose env38219 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38219 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38220 : List Nat := [2,4,8,16,1,64,9,84,512,21,80,65,9,0,1,83,65,0,21,0,1,0,64,82,8,64,1,17,16,0,68,1,84,80,0,512]

theorem envBound38220 : H12AffineFastState.Bounded env38220 := by
  intro p hp
  have h : env38220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38219_38220 : H12AffineEnvironment.transform 4 1 env38219 = env38220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38219 == env38220) = true)

theorem identity38220 : scanCanonicalize (H12AffineFastState.compose env38220 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound38220 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38221 : List Nat := [2,4,8,16,1,64,9,84,11,21,80,65,9,0,1,83,65,0,21,0,1,0,64,82,8,64,1,17,16,0,68,1,84,80,0,11]

theorem envBound38221 : H12AffineFastState.Bounded env38221 := by
  intro p hp
  have h : env38221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38220_38221 : H12AffineEnvironment.transform 8 11 env38220 = env38221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env38220 == env38221) = true)

theorem identity38221 : scanCanonicalize (H12AffineFastState.compose env38221 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound38221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38222 : List Nat := [2,4,8,13,1,64,9,73,11,8,77,65,9,0,1,78,65,0,8,0,1,0,64,79,8,64,1,12,13,0,68,1,73,77,0,11]

theorem envBound38222 : H12AffineFastState.Bounded env38222 := by
  intro p hp
  have h : env38222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38221_38222 : H12AffineEnvironment.transform 3 13 env38221 = env38222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env38221 == env38222) = true)

theorem identity38222 : scanCanonicalize (H12AffineFastState.compose env38222 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound38222 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38223 : List Nat := [2,4,8,13,1,12,9,5,11,8,1,13,9,0,1,2,13,0,8,0,1,0,12,3,8,12,1,12,13,0,8,1,5,1,0,11]

theorem envBound38223 : H12AffineFastState.Bounded env38223 := by
  intro p hp
  have h : env38223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38222_38223 : H12AffineEnvironment.transform 5 12 env38222 = env38223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env38222 == env38223) = true)

theorem identity38223 : scanCanonicalize (H12AffineFastState.compose env38223 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38224 : List Nat := [2,4,1,4,1,5,0,5,2,1,1,4,0,0,1,2,4,0,1,0,1,0,5,3,1,5,1,5,4,0,1,1,5,1,0,2]

theorem envBound38224 : H12AffineFastState.Bounded env38224 := by
  intro p hp
  have h : env38224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38223_38224 : H12AffineEnvironment.transform 2 1 env38223 = env38224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38223 == env38224) = true)

def env38225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62588,119879,147475,8193,64,303144,250967,102743,463943,135237,246119,256,147504,172317,210714]

theorem envBound38225 : H12AffineFastState.Bounded env38225 := by
  intro p hp
  have h : env38225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38208_38225 : H12AffineEnvironment.transform 20 4161 env38208 = env38225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38208 == env38225) = true)

theorem identity38225 : scanCanonicalize (H12AffineFastState.compose env38225 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38225 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,41340,98631,136467,8193,64,303144,229719,102743,463943,135237,234599,256,136496,172317,210714]

theorem envBound38226 : H12AffineFastState.Bounded env38226 := by
  intro p hp
  have h : env38226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38225_38226 : H12AffineEnvironment.transform 13 5376 env38225 = env38226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38225 == env38226) = true)

theorem identity38226 : scanCanonicalize (H12AffineFastState.compose env38226 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound38226 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,4161,41340,98631,73736,8193,64,303144,46156,102743,270684,75102,41340,256,73771,103430,513]

theorem envBound38227 : H12AffineFastState.Bounded env38227 := by
  intro p hp
  have h : env38227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38226_38227 : H12AffineEnvironment.transform 16 79131 env38226 = env38227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env38226 == env38227) = true)

theorem identity38227 : scanCanonicalize (H12AffineFastState.compose env38227 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound38227 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,9498,4097,262144,1024,32769,4161,41340,42077,1298,8193,64,303144,46156,46157,270684,68,41340,256,1329,45340,513]

theorem envBound38228 : H12AffineFastState.Bounded env38228 := by
  intro p hp
  have h : env38228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38227_38228 : H12AffineEnvironment.transform 15 9498 env38227 = env38228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env38227 == env38228) = true)

theorem identity38228 : scanCanonicalize (H12AffineFastState.compose env38228 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound38228 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,9498,4097,35189,1024,32769,4161,41340,42077,1298,8193,64,10589,46156,46157,43049,68,41340,256,1329,45340,513]

theorem envBound38229 : H12AffineFastState.Bounded env38229 := by
  intro p hp
  have h : env38229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38228_38229 : H12AffineEnvironment.transform 17 35189 env38228 = env38229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env38228 == env38229) = true)

def env38230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound38230 : H12AffineFastState.Bounded env38230 := by
  intro p hp
  have h : env38230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38096_38230 : H12AffineEnvironment.transform 18 1025 env38096 = env38230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env38096 == env38230) = true)

theorem identity38230 : scanCanonicalize (H12AffineFastState.compose env38230 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237574) := by decide +kernel

theorem selectedBound38230 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237574,8328,64,15066247,237579,10507601,8830977,10723479,4407622,257,8642603,8585614,10651456]

theorem envBound38231 : H12AffineFastState.Bounded env38231 := by
  intro p hp
  have h : env38231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38230_38231 : H12AffineEnvironment.transform 23 2237574 env38230 = env38231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237574 env38230 == env38231) = true)

def env38232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066247,115151,10507601,8692165,10600787,4268162,257,8487407,8478794,10544772]

theorem envBound38232 : H12AffineFastState.Bounded env38232 := by
  intro p hp
  have h : env38232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38231_38232 : H12AffineEnvironment.transform 16 25028 env38231 = env38232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env38231 == env38232) = true)

def env38233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4584663,115151,17665,2404757,119043,4268162,257,2199999,2191386,63188]

theorem envBound38233 : H12AffineFastState.Bounded env38233 := by
  intro p hp
  have h : env38233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38232_38233 : H12AffineEnvironment.transform 22 2101328 env38232 = env38233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38232 == env38233) = true)

def env38234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,121943,115151,17665,2404757,119043,329730,257,2199999,2191386,63188]

theorem envBound38234 : H12AffineFastState.Bounded env38234 := by
  intro p hp
  have h : env38234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38233_38234 : H12AffineEnvironment.transform 21 272512 env38233 = env38234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38233 == env38234) = true)

def env38235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,121943,115015,17665,2404637,119043,329730,257,2199863,2191386,63068]

theorem envBound38235 : H12AffineFastState.Bounded env38235 := by
  intro p hp
  have h : env38235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38234_38235 : H12AffineEnvironment.transform 6 8 env38234 = env38235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38234 == env38235) = true)

def env38236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272392,16,21762,8192,64,121943,115015,17665,303453,119043,329730,257,98679,90202,63068]

theorem envBound38236 : H12AffineFastState.Bounded env38236 := by
  intro p hp
  have h : env38236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38235_38236 : H12AffineEnvironment.transform 20 4160 env38235 = env38236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38235 == env38236) = true)

theorem identity38236 : scanCanonicalize (H12AffineFastState.compose env38236 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1025,8540,4160,272392,16,21762,8192,64,97546,90138,17665,262144,94302,329730,257,73770,90202,22273]

theorem envBound38237 : H12AffineFastState.Bounded env38237 := by
  intro p hp
  have h : env38237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38236_38237 : H12AffineEnvironment.transform 14 8541 env38236 = env38237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38236 == env38237) = true)

theorem identity38237 : scanCanonicalize (H12AffineFastState.compose env38237 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound38237 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,2421,1025,8540,4160,8573,16,21762,8192,64,97546,90138,17665,2421,94302,65911,257,73770,90202,22273]

theorem envBound38238 : H12AffineFastState.Bounded env38238 := by
  intro p hp
  have h : env38238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38237_38238 : H12AffineEnvironment.transform 17 2421 env38237 = env38238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env38237 == env38238) = true)

theorem identity38238 : scanCanonicalize (H12AffineFastState.compose env38238 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound38238 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env38239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30043,24908,2421,1025,8540,4160,8573,16,21762,8192,64,2129,5441,17665,2421,1285,29740,257,21873,5377,22273]

theorem envBound38239 : H12AffineFastState.Bounded env38239 := by
  intro p hp
  have h : env38239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38238_38239 : H12AffineEnvironment.transform 15 30043 env38238 = env38239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env38238 == env38239) = true)

theorem identity38239 : scanCanonicalize (H12AffineFastState.compose env38239 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound38239 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env38240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8541,35,5172,2421,1025,8540,4160,8573,16,8314,8192,64,2129,5441,12409,2421,1285,340,257,8201,5377,8825]

theorem envBound38240 : H12AffineFastState.Bounded env38240 := by
  intro p hp
  have h : env38240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38239_38240 : H12AffineEnvironment.transform 13 13688 env38239 = env38240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env38239 == env38240) = true)

theorem identity38240 : scanCanonicalize (H12AffineFastState.compose env38240 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38240 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,372,35,5172,2421,1025,373,4160,340,16,83,41,64,2129,5441,4176,2421,1285,340,257,32,5377,592]

theorem envBound38241 : H12AffineFastState.Bounded env38241 := by
  intro p hp
  have h : env38241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38240_38241 : H12AffineEnvironment.transform 12 41 env38240 = env38241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38240 == env38241) = true)

theorem identity38241 : scanCanonicalize (H12AffineFastState.compose env38241 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38241 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38242 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5237,80,35,5172,2129,1025,81,4160,112,16,83,41,64,2129,5221,4176,2129,1057,112,37,32,5157,592]

theorem envBound38242 : H12AffineFastState.Bounded env38242 := by
  intro p hp
  have h : env38242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38241_38242 : H12AffineEnvironment.transform 7 36 env38241 = env38242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38241 == env38242) = true)

theorem identity38242 : scanCanonicalize (H12AffineFastState.compose env38242 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound38242 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38243 : List Nat := [2,4,8,16,32,64,8,36,512,1024,10,4096,41,5237,80,35,5172,91,1025,81,4160,112,16,83,41,64,91,5221,4176,91,1057,112,37,32,5157,592]

theorem envBound38243 : H12AffineFastState.Bounded env38243 := by
  intro p hp
  have h : env38243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38242_38243 : H12AffineEnvironment.transform 10 10 env38242 = env38243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env38242 == env38243) = true)

theorem identity38243 : scanCanonicalize (H12AffineFastState.compose env38243 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound38243 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38244 : List Nat := [2,4,8,16,32,64,8,36,512,1024,10,32,41,1109,80,35,1044,91,1025,81,96,112,16,83,41,64,91,1093,112,91,1057,112,37,32,1029,592]

theorem envBound38244 : H12AffineFastState.Bounded env38244 := by
  intro p hp
  have h : env38244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38243_38244 : H12AffineEnvironment.transform 11 32 env38243 = env38244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env38243 == env38244) = true)

theorem identity38244 : scanCanonicalize (H12AffineFastState.compose env38244 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38244 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env38245 : List Nat := [2,4,8,16,32,64,8,36,512,53,10,32,41,96,80,35,33,91,52,81,96,112,16,83,41,64,91,112,112,91,20,112,37,32,48,592]

theorem envBound38245 : H12AffineFastState.Bounded env38245 := by
  intro p hp
  have h : env38245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38244_38245 : H12AffineEnvironment.transform 9 53 env38244 = env38245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38244 == env38245) = true)

theorem identity38245 : scanCanonicalize (H12AffineFastState.compose env38245 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 46) := by decide +kernel

theorem selectedBound38245 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env38246 : List Nat := [2,4,8,16,32,46,8,36,512,53,10,32,41,14,62,35,33,53,52,63,14,30,16,61,41,46,53,30,30,53,20,30,37,32,48,574]

theorem envBound38246 : H12AffineFastState.Bounded env38246 := by
  intro p hp
  have h : env38246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38245_38246 : H12AffineEnvironment.transform 5 46 env38245 = env38246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 46 env38245 == env38246) = true)

theorem identity38246 : scanCanonicalize (H12AffineFastState.compose env38246 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38246 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38247 : List Nat := [2,4,8,16,1,15,8,5,512,20,10,1,8,14,31,2,0,20,21,30,14,30,16,28,8,15,20,30,30,20,20,30,4,1,17,543]

theorem envBound38247 : H12AffineFastState.Bounded env38247 := by
  intro p hp
  have h : env38247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38246_38247 : H12AffineEnvironment.transform 4 1 env38246 = env38247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38246 == env38247) = true)

theorem identity38247 : scanCanonicalize (H12AffineFastState.compose env38247 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound38247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38248 : List Nat := [2,4,8,15,1,15,8,5,512,11,10,1,8,14,0,2,0,11,10,1,14,1,15,3,8,15,11,1,1,11,11,1,4,1,14,512]

theorem envBound38248 : H12AffineFastState.Bounded env38248 := by
  intro p hp
  have h : env38248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38247_38248 : H12AffineEnvironment.transform 3 15 env38247 = env38248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env38247 == env38248) = true)

theorem identity38248 : scanCanonicalize (H12AffineFastState.compose env38248 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38249 : List Nat := [2,0,8,11,1,11,8,1,512,11,10,1,8,10,0,2,0,11,10,1,10,1,11,3,8,11,11,1,1,11,11,1,0,1,10,512]

theorem envBound38249 : H12AffineFastState.Bounded env38249 := by
  intro p hp
  have h : env38249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38248_38249 : H12AffineEnvironment.transform 1 0 env38248 = env38249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38248 == env38249) = true)

theorem identity38249 : scanCanonicalize (H12AffineFastState.compose env38249 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound38249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38250 : List Nat := [2,0,8,11,1,11,8,1,9,11,10,1,8,10,0,2,0,11,10,1,10,1,11,3,8,11,11,1,1,11,11,1,0,1,10,9]

theorem envBound38250 : H12AffineFastState.Bounded env38250 := by
  intro p hp
  have h : env38250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38249_38250 : H12AffineEnvironment.transform 8 9 env38249 = env38250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env38249 == env38250) = true)

theorem identity38250 : scanCanonicalize (H12AffineFastState.compose env38250 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38250 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38251 : List Nat := [2,0,2,1,1,1,2,1,3,1,0,1,2,0,0,2,0,1,0,1,0,1,1,3,2,1,1,1,1,1,1,1,0,1,0,3]

theorem envBound38251 : H12AffineFastState.Bounded env38251 := by
  intro p hp
  have h : env38251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38250_38251 : H12AffineEnvironment.transform 2 2 env38250 = env38251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38250 == env38251) = true)

def env38252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272392,17,21763,8192,64,121943,115015,17665,303452,119043,329730,257,98678,90203,63068]

theorem envBound38252 : H12AffineFastState.Bounded env38252 := by
  intro p hp
  have h : env38252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38235_38252 : H12AffineEnvironment.transform 20 4161 env38235 = env38252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38235 == env38252) = true)

theorem identity38252 : scanCanonicalize (H12AffineFastState.compose env38252 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound38252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4161,41340,17,21763,8192,64,121943,115015,17665,10280,119043,98678,257,98678,90203,63068]

theorem envBound38253 : H12AffineFastState.Bounded env38253 := by
  intro p hp
  have h : env38253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38252_38253 : H12AffineEnvironment.transform 17 35188 env38252 = env38253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env38252 == env38253) = true)

theorem identity38253 : scanCanonicalize (H12AffineFastState.compose env38253 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38253 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,5392,35188,1025,32769,4161,41340,17,8543,8192,64,108555,111899,12637,10280,107871,98678,257,98678,70663,33280]

theorem envBound38254 : H12AffineFastState.Bounded env38254 := by
  intro p hp
  have h : env38254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38253_38254 : H12AffineEnvironment.transform 13 13404 env38253 = env38254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38253 == env38254) = true)

theorem identity38254 : scanCanonicalize (H12AffineFastState.compose env38254 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound38254 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,5392,35188,1025,32769,4161,41340,17,8543,8192,64,43356,46156,12637,10280,41992,32801,257,32801,5456,33280]

theorem envBound38255 : H12AffineFastState.Bounded env38255 := by
  intro p hp
  have h : env38255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38254_38255 : H12AffineEnvironment.transform 15 343 env38254 = env38255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env38254 == env38255) = true)

theorem identity38255 : scanCanonicalize (H12AffineFastState.compose env38255 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38255 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,343,5392,2421,1025,0,4161,8573,17,8543,8192,64,10589,13389,12637,10280,9225,32,257,32,5456,513]

theorem envBound38256 : H12AffineFastState.Bounded env38256 := by
  intro p hp
  have h : env38256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38255_38256 : H12AffineEnvironment.transform 14 1 env38255 = env38256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38255 == env38256) = true)

theorem identity38256 : scanCanonicalize (H12AffineFastState.compose env38256 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound38256 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1,343,5392,2421,1025,0,4161,1328,17,1298,1101,64,3344,4096,5392,3173,68,32,257,32,5456,513]

theorem envBound38257 : H12AffineFastState.Bounded env38257 := by
  intro p hp
  have h : env38257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38256_38257 : H12AffineEnvironment.transform 12 1101 env38256 = env38257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env38256 == env38257) = true)

theorem identity38257 : scanCanonicalize (H12AffineFastState.compose env38257 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38257 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env38258 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,121,4113,1,343,4388,2421,53,0,4161,260,17,294,121,64,2340,4096,4388,2129,68,32,257,32,4452,513]

theorem envBound38258 : H12AffineFastState.Bounded env38258 := by
  intro p hp
  have h : env38258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38257_38258 : H12AffineEnvironment.transform 9 52 env38257 = env38258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38257 == env38258) = true)

theorem identity38258 : scanCanonicalize (H12AffineFastState.compose env38258 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound38258 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38259 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,17,121,0,1,343,309,2421,53,0,80,260,17,294,121,64,2340,17,309,2129,68,32,257,32,373,513]

theorem envBound38259 : H12AffineFastState.Bounded env38259 := by
  intro p hp
  have h : env38259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38258_38259 : H12AffineEnvironment.transform 11 17 env38258 = env38259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env38258 == env38259) = true)

theorem identity38259 : scanCanonicalize (H12AffineFastState.compose env38259 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound38259 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env38260 : List Nat := [2,4,8,16,32,64,8,256,372,52,2048,17,121,0,1,343,309,2421,53,0,80,260,17,294,121,64,2340,17,309,2129,68,32,257,32,373,373]

theorem envBound38260 : H12AffineFastState.Bounded env38260 := by
  intro p hp
  have h : env38260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38259_38260 : H12AffineEnvironment.transform 8 372 env38259 = env38260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env38259 == env38260) = true)

theorem identity38260 : scanCanonicalize (H12AffineFastState.compose env38260 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound38260 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env38261 : List Nat := [2,4,8,16,32,64,8,256,372,52,112,17,121,0,1,343,309,261,53,0,80,260,17,294,121,64,340,17,309,33,68,32,257,32,373,373]

theorem envBound38261 : H12AffineFastState.Bounded env38261 := by
  intro p hp
  have h : env38261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38260_38261 : H12AffineEnvironment.transform 10 112 env38260 = env38261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env38260 == env38261) = true)

theorem identity38261 : scanCanonicalize (H12AffineFastState.compose env38261 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38261 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env38262 : List Nat := [2,4,8,16,32,64,8,117,1,52,112,17,121,0,1,34,64,112,53,0,80,113,17,83,121,64,33,17,64,33,68,32,116,32,0,0]

theorem envBound38262 : H12AffineFastState.Bounded env38262 := by
  intro p hp
  have h : env38262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38261_38262 : H12AffineEnvironment.transform 7 117 env38261 = env38262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38261 == env38262) = true)

theorem identity38262 : scanCanonicalize (H12AffineFastState.compose env38262 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38263 : List Nat := [2,4,8,0,32,64,8,101,1,36,96,1,105,0,1,34,64,96,37,0,64,97,1,67,105,64,33,1,64,33,68,32,100,32,0,0]

theorem envBound38263 : H12AffineFastState.Bounded env38263 := by
  intro p hp
  have h : env38263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38262_38263 : H12AffineEnvironment.transform 3 0 env38262 = env38263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38262 == env38263) = true)

theorem identity38263 : scanCanonicalize (H12AffineFastState.compose env38263 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound38263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38264 : List Nat := [2,4,8,0,32,1,8,36,1,36,33,1,40,0,1,34,1,33,37,0,1,32,1,2,40,1,33,1,1,33,5,32,37,32,0,0]

theorem envBound38264 : H12AffineFastState.Bounded env38264 := by
  intro p hp
  have h : env38264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38263_38264 : H12AffineEnvironment.transform 5 1 env38263 = env38264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env38263 == env38264) = true)

def env38265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,121943,115014,17665,2404636,119043,329730,257,2199862,2191386,63069]

theorem envBound38265 : H12AffineFastState.Bounded env38265 := by
  intro p hp
  have h : env38265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38234_38265 : H12AffineEnvironment.transform 6 9 env38234 = env38265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38234 == env38265) = true)

def env38266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272393,16,21762,8193,64,121943,115014,17665,303452,119043,329730,257,98678,90202,63069]

theorem envBound38266 : H12AffineFastState.Bounded env38266 := by
  intro p hp
  have h : env38266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38265_38266 : H12AffineEnvironment.transform 20 4160 env38265 = env38266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38265 == env38266) = true)

theorem identity38266 : scanCanonicalize (H12AffineFastState.compose env38266 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound38266 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67619,1025,32769,4160,73770,16,21762,8193,64,121943,115014,17665,108927,119043,33,257,98678,90202,63069]

theorem envBound38267 : H12AffineFastState.Bounded env38267 := by
  intro p hp
  have h : env38267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38266_38267 : H12AffineEnvironment.transform 17 67619 env38266 = env38267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env38266 == env38267) = true)

theorem identity38267 : scanCanonicalize (H12AffineFastState.compose env38267 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound38267 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24909,64809,1025,32769,4160,54560,16,21762,8193,64,10589,13388,17665,23669,9225,33,257,29820,38224,63069]

theorem envBound38268 : H12AffineFastState.Bounded env38268 := by
  intro p hp
  have h : env38268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38267_38268 : H12AffineEnvironment.transform 15 62730 env38267 = env38268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env38267 == env38268) = true)

theorem identity38268 : scanCanonicalize (H12AffineFastState.compose env38268 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38268 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env38269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29963,24909,32040,1025,0,4160,21793,16,21762,8193,64,10589,13388,17665,23669,9225,33,257,29820,5457,30300]

theorem envBound38269 : H12AffineFastState.Bounded env38269 := by
  intro p hp
  have h : env38269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38268_38269 : H12AffineEnvironment.transform 14 1 env38268 = env38269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38268 == env38269) = true)

theorem identity38269 : scanCanonicalize (H12AffineFastState.compose env38269 (packedSelected [3,5,7,10,12,14,15,16,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38269 : packedSelected [3,5,7,10,12,14,15,16,27] rootPS < 2^1333 := by decide +kernel

def env38270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8202,13388,10281,1025,0,4160,32,16,3,8193,64,10589,13388,4096,2420,9225,33,257,8573,5457,9053]

theorem envBound38270 : H12AffineFastState.Bounded env38270 := by
  intro p hp
  have h : env38270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38269_38270 : H12AffineEnvironment.transform 13 5377 env38269 = env38270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38269 == env38270) = true)

theorem identity38270 : scanCanonicalize (H12AffineFastState.compose env38270 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38270 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env38271 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,1,8202,12636,10281,273,0,4160,32,16,3,8193,64,10589,12636,4096,2420,8473,33,257,8573,4161,9053]

theorem envBound38271 : H12AffineFastState.Bounded env38271 := by
  intro p hp
  have h : env38271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38270_38271 : H12AffineEnvironment.transform 9 272 env38270 = env38271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38270 == env38271) = true)

theorem identity38271 : scanCanonicalize (H12AffineFastState.compose env38271 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38271 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38272 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,41,4113,1,35,4469,2048,273,0,4160,32,16,3,40,64,2420,4469,4096,2420,304,33,257,340,4161,884]

theorem envBound38272 : H12AffineFastState.Bounded env38272 := by
  intro p hp
  have h : env38272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38271_38272 : H12AffineEnvironment.transform 12 41 env38271 = env38272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38271 == env38272) = true)

theorem identity38272 : scanCanonicalize (H12AffineFastState.compose env38272 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38272 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38273 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4113,1,35,4388,2048,273,0,4113,32,16,3,40,17,2341,4388,4096,2341,304,33,257,261,4112,805]

theorem envBound38273 : H12AffineFastState.Bounded env38273 := by
  intro p hp
  have h : env38273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38272_38273 : H12AffineEnvironment.transform 5 17 env38272 = env38273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38272 == env38273) = true)

theorem identity38273 : scanCanonicalize (H12AffineFastState.compose env38273 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound38273 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38274 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2357,41,2340,1,35,2065,2048,273,0,2340,32,16,3,40,17,2341,2065,2357,2341,304,33,257,261,2341,805]

theorem envBound38274 : H12AffineFastState.Bounded env38274 := by
  intro p hp
  have h : env38274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38273_38274 : H12AffineEnvironment.transform 11 2357 env38273 = env38274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env38273 == env38274) = true)

theorem identity38274 : scanCanonicalize (H12AffineFastState.compose env38274 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38274 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env38275 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2065,41,2048,1,35,2065,2048,53,0,2048,32,16,3,40,17,2049,2065,2065,2049,20,33,37,33,2049,513]

theorem envBound38275 : H12AffineFastState.Bounded env38275 := by
  intro p hp
  have h : env38275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38274_38275 : H12AffineEnvironment.transform 7 36 env38274 = env38275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38274 == env38275) = true)

theorem identity38275 : scanCanonicalize (H12AffineFastState.compose env38275 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound38275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38276 : List Nat := [2,4,8,16,32,17,9,36,512,52,17,0,41,17,1,35,0,17,53,0,17,32,16,3,40,17,16,0,0,16,20,33,37,33,16,513]

theorem envBound38276 : H12AffineFastState.Bounded env38276 := by
  intro p hp
  have h : env38276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38275_38276 : H12AffineEnvironment.transform 10 17 env38275 = env38276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env38275 == env38276) = true)

theorem identity38276 : scanCanonicalize (H12AffineFastState.compose env38276 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38277 : List Nat := [2,4,8,16,11,17,9,15,512,31,17,0,2,17,1,8,0,17,30,0,17,11,16,3,3,17,16,0,0,16,20,10,14,10,16,513]

theorem envBound38277 : H12AffineFastState.Bounded env38277 := by
  intro p hp
  have h : env38277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38276_38277 : H12AffineEnvironment.transform 4 11 env38276 = env38277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38276 == env38277) = true)

def env38278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272393,17,21763,8193,64,121943,115014,17665,303453,119043,329730,257,98679,90203,63069]

theorem envBound38278 : H12AffineFastState.Bounded env38278 := by
  intro p hp
  have h : env38278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38265_38278 : H12AffineEnvironment.transform 20 4161 env38265 = env38278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38265 == env38278) = true)

theorem identity38278 : scanCanonicalize (H12AffineFastState.compose env38278 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38278 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,4161,33,17,21763,8193,64,121943,115014,17665,35189,119043,73770,257,98679,90203,63069]

theorem envBound38279 : H12AffineFastState.Bounded env38279 := by
  intro p hp
  have h : env38279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38278_38279 : H12AffineEnvironment.transform 17 10280 env38278 = env38279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38278 == env38279) = true)

theorem identity38279 : scanCanonicalize (H12AffineFastState.compose env38279 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound38279 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env38280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,24909,10280,1025,32769,4161,33,17,21763,8193,64,31837,24908,17665,35189,28937,32800,257,8573,49233,63069]

theorem envBound38280 : H12AffineFastState.Bounded env38280 := by
  intro p hp
  have h : env38280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38279_38280 : H12AffineEnvironment.transform 15 40970 env38279 = env38280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env38279 == env38280) = true)

theorem identity38280 : scanCanonicalize (H12AffineFastState.compose env38280 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound38280 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,24909,10280,1025,29789,4161,33,17,21763,8193,64,31837,24908,17665,32041,28937,29820,257,8573,13325,513]

end H12CloudChart0