import H12CloudChart0Data053

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity13551 : scanCanonicalize (H12AffineFastState.compose env13551 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13551 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env13552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,8574,5172,10280,1025,1,4453,340,17,2,8192,65,10280,13340,12328,2048,9597,8200,257,32,5376,9053]

theorem envBound13552 : H12AffineFastState.Bounded env13552 := by
  intro p hp
  have h : env13552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13551_13552 : H12AffineEnvironment.transform 13 13325 env13551 = env13552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13551 == env13552) = true)

theorem identity13552 : scanCanonicalize (H12AffineFastState.compose env13552 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13552 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env13553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,0,35,5172,2421,1025,1,4453,340,17,2,349,65,2421,5441,4469,2048,1056,341,257,32,5376,512]

theorem envBound13553 : H12AffineFastState.Bounded env13553 := by
  intro p hp
  have h : env13553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13552_13553 : H12AffineEnvironment.transform 12 349 env13552 = env13553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13552 == env13553) = true)

theorem identity13553 : scanCanonicalize (H12AffineFastState.compose env13553 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13553 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13554 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,35,5172,2341,1025,1,4405,260,17,2,269,17,2341,5393,4389,2048,1056,261,257,32,5376,512]

theorem envBound13554 : H12AffineFastState.Bounded env13554 := by
  intro p hp
  have h : env13554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13553_13554 : H12AffineEnvironment.transform 5 16 env13553 = env13554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13553 == env13554) = true)

theorem identity13554 : scanCanonicalize (H12AffineFastState.compose env13554 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13554 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13555 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,0,3,5140,2309,1025,1,4373,260,17,2,269,17,2309,5393,4357,2048,1024,261,257,0,5376,512]

theorem envBound13555 : H12AffineFastState.Bounded env13555 := by
  intro p hp
  have h : env13555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13554_13555 : H12AffineEnvironment.transform 4 0 env13554 = env13555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13554 == env13555) = true)

theorem identity13555 : scanCanonicalize (H12AffineFastState.compose env13555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13556 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,0,3,5140,2049,1025,1,4113,0,17,2,9,17,2049,5141,4097,2048,1024,1,5,0,5124,512]

theorem envBound13556 : H12AffineFastState.Bounded env13556 := by
  intro p hp
  have h : env13556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13555_13556 : H12AffineEnvironment.transform 7 4 env13555 = env13556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13555 == env13556) = true)

def env13557 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1044,0,3,1028,2049,1025,1,1,0,17,2,9,17,2049,1029,17,2048,1024,1,5,0,1044,512]

theorem envBound13557 : H12AffineFastState.Bounded env13557 := by
  intro p hp
  have h : env13557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13556_13557 : H12AffineEnvironment.transform 11 16 env13556 = env13557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13556 == env13557) = true)

theorem identity13557 : scanCanonicalize (H12AffineFastState.compose env13557 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound13557 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13558 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,16,9,1044,0,3,1028,1045,1025,1,1,0,17,2,9,17,1045,1029,17,1044,1024,1,5,0,1044,512]

theorem envBound13558 : H12AffineFastState.Bounded env13558 := by
  intro p hp
  have h : env13558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13557_13558 : H12AffineEnvironment.transform 10 1044 env13557 = env13558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env13557 == env13558) = true)

def env13559 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,0,0,3,16,1,21,1,1,0,17,2,9,17,1,17,17,0,20,1,5,0,0,512]

theorem envBound13559 : H12AffineFastState.Bounded env13559 := by
  intro p hp
  have h : env13559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13558_13559 : H12AffineEnvironment.transform 9 20 env13558 = env13559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13558 == env13559) = true)

theorem identity13559 : scanCanonicalize (H12AffineFastState.compose env13559 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound13559 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13560 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,9,0,0,3,4,1,1,1,1,0,5,2,9,5,1,5,5,0,0,1,5,0,0,512]

theorem envBound13560 : H12AffineFastState.Bounded env13560 := by
  intro p hp
  have h : env13560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13559_13560 : H12AffineEnvironment.transform 3 4 env13559 = env13560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env13559 == env13560) = true)

def leafEnv13560 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,9,0,0,3,4,1,1,1,1,0,5,2,1,9,1,5,1,5,5,0,0,1,5,0,5,3,0,512,1,1,0]

def active13560 : List Nat := [0,1,2,8]

def tree13560 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13560 : H12WitnessSearch.Good tree13560 := H12GlobalWitnessIndex.good

theorem leafIdentity13560 : H12AffineFastState.composeSystem env13560 rootObs = leafEnv13560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13560 rootObs == leafEnv13560) = true)

theorem terminalChecked13560 : H12PackedTerminal.terminalCheckFast leafEnv13560 active13560 tree13560 = true := by decide +kernel

def env13561 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,9,1,0,3,17,0,20,1,1,0,17,2,9,17,0,16,17,1,21,1,5,0,1,512]

theorem envBound13561 : H12AffineFastState.Bounded env13561 := by
  intro p hp
  have h : env13561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13558_13561 : H12AffineEnvironment.transform 9 21 env13558 = env13561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13558 == env13561) = true)

theorem identity13561 : scanCanonicalize (H12AffineFastState.compose env13561 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound13561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13562 : List Nat := [2,4,8,16,0,16,8,4,30,21,1,16,9,1,0,3,17,0,20,1,1,0,17,2,9,17,0,16,17,1,21,1,5,0,1,30]

theorem envBound13562 : H12AffineFastState.Bounded env13562 := by
  intro p hp
  have h : env13562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13561_13562 : H12AffineEnvironment.transform 8 30 env13561 = env13562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env13561 == env13562) = true)

def leafEnv13562 : List Nat := [2,4,8,16,0,16,8,4,30,21,1,16,9,1,0,3,17,0,20,1,1,0,17,2,20,9,1,17,0,16,17,1,21,1,5,0,5,3,1,30,1,1,0]

def active13562 : List Nat := [0,1,2,3]

def tree13562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13562 : H12WitnessSearch.Good tree13562 := H12GlobalWitnessIndex.good

theorem leafIdentity13562 : H12AffineFastState.composeSystem env13562 rootObs = leafEnv13562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13562 rootObs == leafEnv13562) = true)

theorem terminalChecked13562 : H12PackedTerminal.terminalCheckFast leafEnv13562 active13562 tree13562 = true := by decide +kernel

def env13563 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1045,0,3,1029,2049,1025,1,0,0,17,2,9,17,2049,1028,16,2048,1024,1,5,0,1045,512]

theorem envBound13563 : H12AffineFastState.Bounded env13563 := by
  intro p hp
  have h : env13563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13556_13563 : H12AffineEnvironment.transform 11 17 env13556 = env13563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13556 == env13563) = true)

theorem identity13563 : scanCanonicalize (H12AffineFastState.compose env13563 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13564 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,9,1045,0,3,1029,1,1025,1,0,0,17,2,9,17,1,1028,16,0,1024,1,5,0,1045,512]

theorem envBound13564 : H12AffineFastState.Bounded env13564 := by
  intro p hp
  have h : env13564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13563_13564 : H12AffineEnvironment.transform 10 0 env13563 = env13564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13563 == env13564) = true)

def env13565 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,1,0,3,17,1,21,1,0,0,17,2,9,17,1,16,16,0,20,1,5,0,1,512]

theorem envBound13565 : H12AffineFastState.Bounded env13565 := by
  intro p hp
  have h : env13565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13564_13565 : H12AffineEnvironment.transform 9 20 env13564 = env13565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13564 == env13565) = true)

theorem identity13565 : scanCanonicalize (H12AffineFastState.compose env13565 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound13565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13566 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,0,3,5,1,1,1,0,0,5,2,9,5,1,4,4,0,0,1,5,0,1,512]

theorem envBound13566 : H12AffineFastState.Bounded env13566 := by
  intro p hp
  have h : env13566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13565_13566 : H12AffineEnvironment.transform 3 4 env13565 = env13566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env13565 == env13566) = true)

def leafEnv13566 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,0,3,5,1,1,1,0,0,5,2,1,9,1,5,1,4,4,0,0,1,5,0,5,3,1,512,1,0,0]

def active13566 : List Nat := [0,1,2,8]

def tree13566 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13566 : H12WitnessSearch.Good tree13566 := H12GlobalWitnessIndex.good

theorem leafIdentity13566 : H12AffineFastState.composeSystem env13566 rootObs = leafEnv13566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13566 rootObs == leafEnv13566) = true)

theorem terminalChecked13566 : H12PackedTerminal.terminalCheckFast leafEnv13566 active13566 tree13566 = true := by decide +kernel

def env13567 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,0,0,3,16,1,20,1,0,0,17,2,9,17,1,17,16,0,21,1,5,0,0,512]

theorem envBound13567 : H12AffineFastState.Bounded env13567 := by
  intro p hp
  have h : env13567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13564_13567 : H12AffineEnvironment.transform 9 21 env13564 = env13567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13564 == env13567) = true)

theorem identity13567 : scanCanonicalize (H12AffineFastState.compose env13567 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound13567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13568 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,9,0,0,3,16,1,20,1,0,0,17,2,9,17,1,17,16,0,21,1,5,0,0,31]

theorem envBound13568 : H12AffineFastState.Bounded env13568 := by
  intro p hp
  have h : env13568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13567_13568 : H12AffineEnvironment.transform 8 31 env13567 = env13568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env13567 == env13568) = true)

def leafEnv13568 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,9,0,0,3,16,1,20,1,0,0,17,2,20,9,1,17,1,17,16,0,21,1,5,0,5,3,0,31,1,0,0]

def active13568 : List Nat := [0,1,2,3]

def tree13568 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13568 : H12WitnessSearch.Good tree13568 := H12GlobalWitnessIndex.good

theorem leafIdentity13568 : H12AffineFastState.composeSystem env13568 rootObs = leafEnv13568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13568 rootObs == leafEnv13568) = true)

theorem terminalChecked13568 : H12PackedTerminal.terminalCheckFast leafEnv13568 active13568 tree13568 = true := by decide +kernel

def env13569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,16777216,8192,65,16959507,18973701,102743,2305071,18890774,16875892,257,16777251,16834830,18966344]

theorem envBound13569 : H12AffineFastState.Bounded env13569 := by
  intro p hp
  have h : env13569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13545_13569 : H12AffineEnvironment.transform 17 10281 env13545 = env13569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13545 == env13569) = true)

theorem identity13569 : scanCanonicalize (H12AffineFastState.compose env13569 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound13569 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,2212885,8192,65,2296838,16400,102743,2305071,99331,2114913,257,2212918,2172187,41821]

theorem envBound13570 : H12AffineFastState.Bounded env13570 := by
  intro p hp
  have h : env13570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13569_13570 : H12AffineEnvironment.transform 23 2212885 env13569 = env13570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env13569 == env13570) = true)

theorem identity13570 : scanCanonicalize (H12AffineFastState.compose env13570 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13570 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,2114912,2188634,2188617,8192,65,2296838,16400,77835,2305071,75103,2114913,257,2188650,2172187,513]

theorem envBound13571 : H12AffineFastState.Bounded env13571 := by
  intro p hp
  have h : env13571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13570_13571 : H12AffineEnvironment.transform 14 8540 env13570 = env13571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13570 == env13571) = true)

theorem identity13571 : scanCanonicalize (H12AffineFastState.compose env13571 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13571 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,10281,1025,8541,2097152,2114912,2114896,2114883,8192,65,2239500,16400,4097,2231333,1365,2114913,257,2114912,2098449,513]

theorem envBound13572 : H12AffineFastState.Bounded env13572 := by
  intro p hp
  have h : env13572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13571_13572 : H12AffineEnvironment.transform 15 8202 env13571 = env13572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13571 == env13572) = true)

theorem identity13572 : scanCanonicalize (H12AffineFastState.compose env13572 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13572 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,131072,10281,1025,8541,2097152,2101525,2101541,2101558,8192,65,2239500,5221,4097,2231333,1365,2101524,257,2101525,2098449,513]

theorem envBound13573 : H12AffineFastState.Bounded env13573 := by
  intro p hp
  have h : env13573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13572_13573 : H12AffineEnvironment.transform 13 5237 env13572 = env13573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13572 == env13573) = true)

theorem identity13573 : scanCanonicalize (H12AffineFastState.compose env13573 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 13324) := by decide +kernel

theorem selectedBound13573 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,131072,10281,1025,8541,13324,9497,9513,9530,8192,65,137216,5221,4097,145449,1365,9496,257,9497,12573,513]

theorem envBound13574 : H12AffineFastState.Bounded env13574 := by
  intro p hp
  have h : env13574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13573_13574 : H12AffineEnvironment.transform 20 13324 env13573 = env13574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13324 env13573 == env13574) = true)

theorem identity13574 : scanCanonicalize (H12AffineFastState.compose env13574 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 12636) := by decide +kernel

theorem selectedBound13574 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,12636,10281,1025,8541,13324,9497,9513,9530,8192,65,10588,5221,4097,2421,1365,9496,257,9497,12573,513]

theorem envBound13575 : H12AffineFastState.Bounded env13575 := by
  intro p hp
  have h : env13575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13574_13575 : H12AffineEnvironment.transform 16 12636 env13574 = env13575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12636 env13574 == env13575) = true)

theorem identity13575 : scanCanonicalize (H12AffineFastState.compose env13575 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound13575 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env13576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,8192,3125,8540,8202,10524,10281,1025,8541,11340,9497,9513,9530,8192,65,10588,3109,2113,2421,1365,9496,257,9497,10589,513]

theorem envBound13576 : H12AffineFastState.Bounded env13576 := by
  intro p hp
  have h : env13576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13575_13576 : H12AffineEnvironment.transform 11 2112 env13575 = env13576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env13575 == env13576) = true)

theorem identity13576 : scanCanonicalize (H12AffineFastState.compose env13576 (packedSelected [4,9,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13576 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env13577 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,2112,8192,2049,8540,8202,10524,10281,53,8541,10360,8493,8477,8462,8192,65,10588,2065,2113,2421,353,8492,257,8493,10589,513]

theorem envBound13577 : H12AffineFastState.Bounded env13577 := by
  intro p hp
  have h : env13577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13576_13577 : H12AffineEnvironment.transform 9 52 env13576 = env13577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13576 == env13577) = true)

theorem identity13577 : scanCanonicalize (H12AffineFastState.compose env13577 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13578 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2064,8192,2049,8460,8202,10524,10281,53,8461,10280,8493,8477,8462,8192,17,10508,2065,2065,2341,305,8492,257,8493,10509,513]

theorem envBound13578 : H12AffineFastState.Bounded env13578 := by
  intro p hp
  have h : env13578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13577_13578 : H12AffineEnvironment.transform 5 16 env13577 = env13578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13577 == env13578) = true)

def env13579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,16777216,8193,65,16959506,18973700,375167,2305070,19163198,16875893,257,17049610,17090854,19222369]

theorem envBound13579 : H12AffineFastState.Bounded env13579 := by
  intro p hp
  have h : env13579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13544_13579 : H12AffineEnvironment.transform 6 9 env13544 = env13579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13544 == env13579) = true)

theorem identity13579 : scanCanonicalize (H12AffineFastState.compose env13579 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound13579 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env13580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329731,17,16777216,8193,65,16959506,17066043,375167,442385,16876545,16875893,257,17049610,17090854,16819038]

theorem envBound13580 : H12AffineFastState.Bounded env13580 := by
  intro p hp
  have h : env13580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13579_13580 : H12AffineEnvironment.transform 20 388159 env13579 = env13580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env13579 == env13580) = true)

theorem identity13580 : scanCanonicalize (H12AffineFastState.compose env13580 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound13580 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329731,17,41311,8193,65,158029,313700,375167,442385,75102,73770,257,297301,288889,513]

theorem envBound13581 : H12AffineFastState.Bounded env13581 := by
  intro p hp
  have h : env13581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13580_13581 : H12AffineEnvironment.transform 23 41311 env13580 = env13581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env13580 == env13581) = true)

def env13582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,73771,17,41311,8193,65,158029,57676,102743,190521,75102,73770,257,41341,16465,513]

theorem envBound13582 : H12AffineFastState.Bounded env13582 := by
  intro p hp
  have h : env13582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13581_13582 : H12AffineEnvironment.transform 17 10280 env13581 = env13582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13581 == env13582) = true)

theorem identity13582 : scanCanonicalize (H12AffineFastState.compose env13582 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13582 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env13583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58396,32,17,41311,8193,65,158029,57676,45404,190521,1365,33,257,41341,16465,513]

theorem envBound13583 : H12AffineFastState.Bounded env13583 := by
  intro p hp
  have h : env13583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13582_13583 : H12AffineEnvironment.transform 15 8203 env13582 = env13583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13582 == env13583) = true)

theorem identity13583 : scanCanonicalize (H12AffineFastState.compose env13583 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound13583 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10280,1025,32769,58396,32,17,41311,8193,65,43357,57676,45404,10281,1365,33,257,41341,16465,513]

theorem envBound13584 : H12AffineFastState.Bounded env13584 := by
  intro p hp
  have h : env13584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13583_13584 : H12AffineEnvironment.transform 16 49168 env13583 = env13584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13583 == env13584) = true)

theorem identity13584 : scanCanonicalize (H12AffineFastState.compose env13584 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13584 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1025,1,25628,32,17,8543,8193,65,10589,24908,12636,10281,1365,33,257,8573,16465,513]

theorem envBound13585 : H12AffineFastState.Bounded env13585 := by
  intro p hp
  have h : env13585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13584_13585 : H12AffineEnvironment.transform 14 0 env13584 = env13585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13584 == env13585) = true)

theorem identity13585 : scanCanonicalize (H12AffineFastState.compose env13585 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13585 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,342,16400,2421,1025,1,17729,32,17,2,348,65,2048,16401,4097,2420,1365,33,257,32,16465,513]

theorem envBound13586 : H12AffineFastState.Bounded env13586 := by
  intro p hp
  have h : env13586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13585_13586 : H12AffineEnvironment.transform 12 349 env13585 = env13586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13585 == env13586) = true)

theorem identity13586 : scanCanonicalize (H12AffineFastState.compose env13586 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1636) := by decide +kernel

theorem selectedBound13586 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1636,0,342,1652,2421,1025,1,805,32,17,2,348,65,2048,1653,4097,2420,1365,33,257,32,1589,513]

theorem envBound13587 : H12AffineFastState.Bounded env13587 := by
  intro p hp
  have h : env13587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13586_13587 : H12AffineEnvironment.transform 13 1636 env13586 = env13587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1636 env13586 == env13587) = true)

theorem identity13587 : scanCanonicalize (H12AffineFastState.compose env13587 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound13587 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,528,4096,349,1636,0,342,1652,869,1025,1,805,32,17,2,348,65,528,1653,4097,868,1365,33,257,32,1589,513]

theorem envBound13588 : H12AffineFastState.Bounded env13588 := by
  intro p hp
  have h : env13588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13587_13588 : H12AffineEnvironment.transform 10 528 env13587 = env13588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env13587 == env13588) = true)

theorem identity13588 : scanCanonicalize (H12AffineFastState.compose env13588 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound13588 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,528,868,349,1636,0,342,1652,869,1025,1,805,32,17,2,348,65,528,1653,869,868,1365,33,257,32,1589,513]

theorem envBound13589 : H12AffineFastState.Bounded env13589 := by
  intro p hp
  have h : env13589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13588_13589 : H12AffineEnvironment.transform 11 868 env13588 = env13589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env13588 == env13589) = true)

theorem identity13589 : scanCanonicalize (H12AffineFastState.compose env13589 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13589 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env13590 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,821,268,1589,0,263,1573,820,1025,1,805,32,17,2,269,16,528,1572,820,821,1284,33,257,32,1589,513]

theorem envBound13590 : H12AffineFastState.Bounded env13590 := by
  intro p hp
  have h : env13590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13589_13590 : H12AffineEnvironment.transform 5 17 env13589 = env13590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13589 == env13590) = true)

theorem identity13590 : scanCanonicalize (H12AffineFastState.compose env13590 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound13590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13591 : List Nat := [2,4,8,16,32,17,9,256,512,37,528,821,268,528,0,263,512,820,36,1,805,32,17,2,269,16,528,513,820,821,289,33,257,32,528,513]

theorem envBound13591 : H12AffineFastState.Bounded env13591 := by
  intro p hp
  have h : env13591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13590_13591 : H12AffineEnvironment.transform 9 37 env13590 = env13591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env13590 == env13591) = true)

theorem identity13591 : scanCanonicalize (H12AffineFastState.compose env13591 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound13591 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13592 : List Nat := [2,4,8,16,32,17,9,256,293,37,309,16,268,309,0,263,293,17,36,1,0,32,17,2,269,16,309,292,17,16,289,33,257,32,309,292]

theorem envBound13592 : H12AffineFastState.Bounded env13592 := by
  intro p hp
  have h : env13592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13591_13592 : H12AffineEnvironment.transform 8 293 env13591 = env13592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env13591 == env13592) = true)

def env13593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,73770,17,41311,8193,65,158029,57677,102742,190520,75102,73770,257,41340,16464,513]

theorem envBound13593 : H12AffineFastState.Bounded env13593 := by
  intro p hp
  have h : env13593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13581_13593 : H12AffineEnvironment.transform 17 10281 env13581 = env13593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13581 == env13593) = true)

theorem identity13593 : scanCanonicalize (H12AffineFastState.compose env13593 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13593 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58396,32,17,41311,8193,65,158029,57677,45404,190520,1364,32,257,41340,16464,513]

theorem envBound13594 : H12AffineFastState.Bounded env13594 := by
  intro p hp
  have h : env13594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13593_13594 : H12AffineEnvironment.transform 15 8202 env13593 = env13594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13593 == env13594) = true)

theorem identity13594 : scanCanonicalize (H12AffineFastState.compose env13594 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 54545) := by decide +kernel

theorem selectedBound13594 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,54545,10281,1025,32769,58396,32,17,41311,8193,65,48220,57677,45404,15657,1364,32,257,41340,16464,513]

theorem envBound13595 : H12AffineFastState.Bounded env13595 := by
  intro p hp
  have h : env13595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13594_13595 : H12AffineEnvironment.transform 16 54545 env13594 = env13595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 54545 env13594 == env13595) = true)

theorem identity13595 : scanCanonicalize (H12AffineFastState.compose env13595 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound13595 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1361,8192,16384,32768,8202,49216,10281,1025,32769,58396,32,17,41311,8193,65,43277,57677,41997,10360,1364,32,257,41340,16464,513]

theorem envBound13596 : H12AffineFastState.Bounded env13596 := by
  intro p hp
  have h : env13596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13595_13596 : H12AffineEnvironment.transform 11 1361 env13595 = env13596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env13595 == env13596) = true)

theorem identity13596 : scanCanonicalize (H12AffineFastState.compose env13596 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound13596 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,8192,16384,32768,8202,49216,8312,1025,32769,58396,32,17,41311,8193,65,41308,57677,41997,8233,1364,32,257,41340,16464,513]

theorem envBound13597 : H12AffineFastState.Bounded env13597 := by
  intro p hp
  have h : env13597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13596_13597 : H12AffineEnvironment.transform 10 81 env13596 = env13597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env13596 == env13597) = true)

theorem identity13597 : scanCanonicalize (H12AffineFastState.compose env13597 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound13597 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env13598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,1052,16384,32768,1046,49216,1124,1025,32769,49152,32,17,34115,1053,65,34112,50513,32785,1077,1364,32,257,34144,16464,513]

theorem envBound13598 : H12AffineFastState.Bounded env13598 := by
  intro p hp
  have h : env13598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13597_13598 : H12AffineEnvironment.transform 12 1052 env13597 = env13598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env13597 == env13598) = true)

theorem identity13598 : scanCanonicalize (H12AffineFastState.compose env13598 (packedSelected [1,3,5,6,7,8,9,10,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13598 : packedSelected [1,3,5,6,7,8,9,10,18] rootPS < 2^1333 := by decide +kernel

def env13599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,1052,16384,1,1046,16449,1124,1025,0,16385,32,17,1346,1053,65,1345,17744,16,1077,1364,32,257,1377,16464,513]

theorem envBound13599 : H12AffineFastState.Bounded env13599 := by
  intro p hp
  have h : env13599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13598_13599 : H12AffineEnvironment.transform 14 1 env13598 = env13599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13598 == env13599) = true)

theorem identity13599 : scanCanonicalize (H12AffineFastState.compose env13599 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13599 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13600 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1280,1052,16384,1,1046,16400,1077,1025,0,16385,32,17,1299,1053,16,1296,17665,16,1077,1285,32,257,1328,16385,513]

theorem envBound13600 : H12AffineFastState.Bounded env13600 := by
  intro p hp
  have h : env13600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13599_13600 : H12AffineEnvironment.transform 5 17 env13599 = env13600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13599 == env13600) = true)

theorem identity13600 : scanCanonicalize (H12AffineFastState.compose env13600 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1070) := by decide +kernel

theorem selectedBound13600 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13601 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1280,1052,1070,1,1046,1086,1077,1025,0,1071,32,17,1299,1053,16,1296,303,16,1077,1285,32,257,1328,1071,513]

theorem envBound13601 : H12AffineFastState.Bounded env13601 := by
  intro p hp
  have h : env13601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13600_13601 : H12AffineEnvironment.transform 13 1070 env13600 = env13601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1070 env13600 == env13601) = true)

theorem identity13601 : scanCanonicalize (H12AffineFastState.compose env13601 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound13601 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13602 : List Nat := [2,4,8,16,32,17,9,256,512,30,0,286,2,48,1,8,32,43,31,0,49,32,17,269,3,16,270,303,16,43,283,32,257,302,49,513]

theorem envBound13602 : H12AffineFastState.Bounded env13602 := by
  intro p hp
  have h : env13602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13601_13602 : H12AffineEnvironment.transform 9 30 env13601 = env13602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env13601 == env13602) = true)

theorem identity13602 : scanCanonicalize (H12AffineFastState.compose env13602 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound13602 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env13603 : List Nat := [2,4,8,16,32,17,9,62,512,30,0,32,2,48,1,8,32,43,31,0,49,32,17,51,3,16,48,17,16,43,37,32,63,16,49,513]

theorem envBound13603 : H12AffineFastState.Bounded env13603 := by
  intro p hp
  have h : env13603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13602_13603 : H12AffineEnvironment.transform 7 62 env13602 = env13603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env13602 == env13603) = true)

theorem identity13603 : scanCanonicalize (H12AffineFastState.compose env13603 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13603 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13604 : List Nat := [2,4,8,16,17,17,9,15,512,30,0,17,2,1,1,8,17,26,31,0,0,17,17,2,3,16,1,17,16,26,20,17,14,16,0,513]

theorem envBound13604 : H12AffineFastState.Bounded env13604 := by
  intro p hp
  have h : env13604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13603_13604 : H12AffineEnvironment.transform 4 17 env13603 = env13604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13603 == env13604) = true)

theorem identity13604 : scanCanonicalize (H12AffineFastState.compose env13604 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13605 : List Nat := [2,4,8,1,0,0,9,15,512,15,0,0,2,1,1,8,0,11,14,0,0,0,0,2,3,1,1,0,1,11,5,0,14,1,0,513]

theorem envBound13605 : H12AffineFastState.Bounded env13605 := by
  intro p hp
  have h : env13605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13604_13605 : H12AffineEnvironment.transform 3 1 env13604 = env13605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13604 == env13605) = true)

theorem identity13605 : scanCanonicalize (H12AffineFastState.compose env13605 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound13605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13606 : List Nat := [2,4,8,1,0,0,9,15,2,15,0,0,2,1,1,8,0,11,14,0,0,0,0,2,3,1,1,0,1,11,5,0,14,1,0,3]

theorem envBound13606 : H12AffineFastState.Bounded env13606 := by
  intro p hp
  have h : env13606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13605_13606 : H12AffineEnvironment.transform 8 2 env13605 = env13606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env13605 == env13606) = true)

theorem identity13606 : scanCanonicalize (H12AffineFastState.compose env13606 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13606 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env13607 : List Nat := [2,4,3,1,0,0,2,4,2,4,0,0,2,1,1,3,0,0,5,0,0,0,0,2,3,1,1,0,1,0,5,0,5,1,0,3]

theorem envBound13607 : H12AffineFastState.Bounded env13607 := by
  intro p hp
  have h : env13607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13606_13607 : H12AffineEnvironment.transform 2 3 env13606 = env13607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13606 == env13607) = true)

theorem identity13607 : scanCanonicalize (H12AffineFastState.compose env13607 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13607 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13608 : List Nat := [2,0,3,1,0,0,2,0,2,0,0,0,2,1,1,3,0,0,1,0,0,0,0,2,3,1,1,0,1,0,1,0,1,1,0,3]

theorem envBound13608 : H12AffineFastState.Bounded env13608 := by
  intro p hp
  have h : env13608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13607_13608 : H12AffineEnvironment.transform 1 0 env13607 = env13608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13607 == env13608) = true)

def env13609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485415,16777216,8328,65,16959642,18973837,375286,2305191,19163319,16876029,257,17049610,17090991,19222369]

theorem envBound13609 : H12AffineFastState.Bounded env13609 := by
  intro p hp
  have h : env13609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13543_13609 : H12AffineEnvironment.transform 21 2155581 env13543 = env13609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env13543 == env13609) = true)

def env13610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,16777216,8192,65,16959506,18973701,375166,2305071,19163199,16875893,257,17049610,17090855,19222369]

theorem envBound13610 : H12AffineFastState.Bounded env13610 := by
  intro p hp
  have h : env13610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13609_13610 : H12AffineEnvironment.transform 6 8 env13609 = env13610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13609 == env13610) = true)

theorem identity13610 : scanCanonicalize (H12AffineFastState.compose env13610 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound13610 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env13611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,16,16777216,8192,65,16959506,17066042,375166,442384,16876544,16875893,257,17049610,17090855,16819038]

theorem envBound13611 : H12AffineFastState.Bounded env13611 := by
  intro p hp
  have h : env13611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13610_13611 : H12AffineEnvironment.transform 20 388159 env13610 = env13611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env13610 == env13611) = true)

theorem identity13611 : scanCanonicalize (H12AffineFastState.compose env13611 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound13611 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,16,272426,8192,65,450616,16400,375166,442384,371754,371039,257,32,57613,297844]

theorem envBound13612 : H12AffineFastState.Bounded env13612 := by
  intro p hp
  have h : env13612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13611_13612 : H12AffineEnvironment.transform 23 272426 env13611 = env13612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env13611 == env13612) = true)

theorem identity13612 : scanCanonicalize (H12AffineFastState.compose env13612 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound13612 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,388159,329730,16,272426,8192,65,360483,16400,375166,368651,371754,371039,257,32,57613,297844]

theorem envBound13613 : H12AffineFastState.Bounded env13613 := by
  intro p hp
  have h : env13613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13612_13613 : H12AffineEnvironment.transform 16 90139 env13612 = env13613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env13612 == env13613) = true)

theorem identity13613 : scanCanonicalize (H12AffineFastState.compose env13613 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound13613 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env13614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1025,32769,58397,32,16,73736,8192,65,34817,16400,45404,43049,41992,41341,257,32,57613,99158]

theorem envBound13614 : H12AffineFastState.Bounded env13614 := by
  intro p hp
  have h : env13614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13613_13614 : H12AffineEnvironment.transform 17 67618 env13613 = env13614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env13613 == env13614) = true)

theorem identity13614 : scanCanonicalize (H12AffineFastState.compose env13614 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound13614 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env13615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,32803,57400,34817,1025,32769,58397,32,16,41003,8192,65,34817,16400,45404,43049,41992,41341,257,32,57613,885]

theorem envBound13615 : H12AffineFastState.Bounded env13615 := by
  intro p hp
  have h : env13615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13614_13615 : H12AffineEnvironment.transform 15 32803 env13614 = env13615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env13614 == env13615) = true)

theorem identity13615 : scanCanonicalize (H12AffineFastState.compose env13615 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13615 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env13616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32803,46157,34817,1025,32769,45160,32,16,41003,8192,65,34817,5221,45404,43049,41992,41341,257,32,46456,885]

theorem envBound13616 : H12AffineFastState.Bounded env13616 := by
  intro p hp
  have h : env13616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13615_13616 : H12AffineEnvironment.transform 13 5237 env13615 = env13616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13615 == env13616) = true)

theorem identity13616 : scanCanonicalize (H12AffineFastState.compose env13616 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13616 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8575,5393,10589,1025,8541,4404,32,16,375,8192,65,10589,5221,4096,2421,1364,33,257,32,5156,885]

theorem envBound13617 : H12AffineFastState.Bounded env13617 := by
  intro p hp
  have h : env13617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13616_13617 : H12AffineEnvironment.transform 14 8540 env13616 = env13617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13616 == env13617) = true)

theorem identity13617 : scanCanonicalize (H12AffineFastState.compose env13617 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13617 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,1,34,5393,2048,1025,0,4404,32,16,375,349,65,2048,5221,4096,2421,1364,33,257,32,5156,885]

theorem envBound13618 : H12AffineFastState.Bounded env13618 := by
  intro p hp
  have h : env13618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13617_13618 : H12AffineEnvironment.transform 12 349 env13617 = env13618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13617 == env13618) = true)

theorem identity13618 : scanCanonicalize (H12AffineFastState.compose env13618 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13618 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env13619 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,349,4113,1,34,4469,2048,101,0,4404,32,16,375,349,65,2048,4097,4096,2421,304,33,257,32,4160,885]

theorem envBound13619 : H12AffineFastState.Bounded env13619 := by
  intro p hp
  have h : env13619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13618_13619 : H12AffineEnvironment.transform 9 100 env13618 = env13619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13618 == env13619) = true)

def env13620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,16777216,8193,65,16959507,18973700,375167,2305070,19163198,16875892,257,17049610,17090854,19222369]

theorem envBound13620 : H12AffineFastState.Bounded env13620 := by
  intro p hp
  have h : env13620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13609_13620 : H12AffineEnvironment.transform 6 9 env13609 = env13620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13609 == env13620) = true)

def env13621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,16777216,8193,65,16959507,18973700,102743,2305070,18890774,16875892,257,16777250,16834830,18966345]

theorem envBound13621 : H12AffineFastState.Bounded env13621 := by
  intro p hp
  have h : env13621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13620_13621 : H12AffineEnvironment.transform 17 10280 env13620 = env13621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13620 == env13621) = true)

theorem identity13621 : scanCanonicalize (H12AffineFastState.compose env13621 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound13621 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,2188616,8193,65,2338139,57676,102743,2305070,75102,2155580,257,2188650,2196550,513]

theorem envBound13622 : H12AffineFastState.Bounded env13622 := by
  intro p hp
  have h : env13622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13621_13622 : H12AffineEnvironment.transform 23 2188616 env13621 = env13622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env13621 == env13622) = true)

theorem identity13622 : scanCanonicalize (H12AffineFastState.compose env13622 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound13622 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env13623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,2097152,2155581,2212870,2188616,8193,65,2182166,57676,102743,2215267,75102,2155580,257,2188650,2196550,513]

theorem envBound13623 : H12AffineFastState.Bounded env13623 := by
  intro p hp
  have h : env13623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13622_13623 : H12AffineEnvironment.transform 16 57677 env13622 = env13623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env13622 == env13623) = true)

theorem identity13623 : scanCanonicalize (H12AffineFastState.compose env13623 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound13623 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,124187,65830,8477,32851,8193,65,43277,57676,102743,10360,75102,65831,257,32881,24925,513]

theorem envBound13624 : H12AffineFastState.Bounded env13624 := by
  intro p hp
  have h : env13624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13623_13624 : H12AffineEnvironment.transform 20 124187 env13623 = env13624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env13623 == env13624) = true)

theorem identity13624 : scanCanonicalize (H12AffineFastState.compose env13624 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13624 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env13625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57677,10280,1025,32769,58445,112,8477,32851,8193,65,43277,57676,36865,10360,9224,113,257,32881,24925,513]

theorem envBound13625 : H12AffineFastState.Bounded env13625 := by
  intro p hp
  have h : env13625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13624_13625 : H12AffineEnvironment.transform 15 342 env13624 = env13625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13624 == env13625) = true)

theorem identity13625 : scanCanonicalize (H12AffineFastState.compose env13625 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13625 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,342,49216,2341,1025,32769,50496,112,16,32851,268,65,34816,49217,36865,2421,1285,113,257,32881,16464,513]

theorem envBound13626 : H12AffineFastState.Bounded env13626 := by
  intro p hp
  have h : env13626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13625_13626 : H12AffineEnvironment.transform 12 269 env13625 = env13626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13625 == env13626) = true)

def env13627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,16777216,8193,65,16959507,18973700,102742,2305070,18890775,16875892,257,16777251,16834831,18966344]

theorem envBound13627 : H12AffineFastState.Bounded env13627 := by
  intro p hp
  have h : env13627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13620_13627 : H12AffineEnvironment.transform 17 10281 env13620 = env13627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13620 == env13627) = true)

theorem identity13627 : scanCanonicalize (H12AffineFastState.compose env13627 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound13627 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,41311,8193,65,158028,2172251,102742,2305070,2154824,73771,257,41340,16464,2213399]

theorem envBound13628 : H12AffineFastState.Bounded env13628 := by
  intro p hp
  have h : env13628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13627_13628 : H12AffineEnvironment.transform 23 41311 env13627 = env13628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env13627 == env13628) = true)

theorem identity13628 : scanCanonicalize (H12AffineFastState.compose env13628 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 173069) := by decide +kernel

theorem selectedBound13628 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,173069,147504,221194,41311,8193,65,158028,229718,102742,100387,148805,73771,257,41340,16464,221722]

theorem envBound13629 : H12AffineFastState.Bounded env13629 := by
  intro p hp
  have h : env13629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13628_13629 : H12AffineEnvironment.transform 20 173069 env13628 = env13629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173069 env13628 == env13629) = true)

theorem identity13629 : scanCanonicalize (H12AffineFastState.compose env13629 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound13629 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env13630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,131072,10281,1025,29004,152896,147504,221194,20498,8193,65,158028,225307,90139,96622,148805,73771,257,20529,16464,221722]

theorem envBound13630 : H12AffineFastState.Bounded env13630 := by
  intro p hp
  have h : env13630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13629_13630 : H12AffineEnvironment.transform 14 29005 env13629 = env13630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env13629 == env13630) = true)

theorem identity13630 : scanCanonicalize (H12AffineFastState.compose env13630 (packedSelected [1,3,5,10,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13630 : packedSelected [1,3,5,10,19,28,31] rootPS < 2^1333 := by decide +kernel

def env13631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,16401,10281,1025,29004,5457,33,73755,20498,8193,65,10589,77834,90139,96622,1364,73771,257,20529,16464,74251]

theorem envBound13631 : H12AffineFastState.Bounded env13631 := by
  intro p hp
  have h : env13631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13630_13631 : H12AffineEnvironment.transform 16 16401 env13630 = env13631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13630 == env13631) = true)

theorem identity13631 : scanCanonicalize (H12AffineFastState.compose env13631 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound13631 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env13632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,80,65536,12556,10281,1025,81,5457,33,73755,8463,8193,65,10589,77834,69894,67699,1364,73771,257,8492,12621,74251]

theorem envBound13632 : H12AffineFastState.Bounded env13632 := by
  intro p hp
  have h : env13632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13631_13632 : H12AffineEnvironment.transform 13 12573 env13631 = env13632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env13631 == env13632) = true)

theorem identity13632 : scanCanonicalize (H12AffineFastState.compose env13632 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound13632 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env13633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5236,80,65536,5221,3392,1025,81,5457,33,66930,1126,1384,65,3124,71011,69894,67699,1364,66882,257,1093,5156,67426]

theorem envBound13633 : H12AffineFastState.Bounded env13633 := by
  intro p hp
  have h : env13633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13632_13633 : H12AffineEnvironment.transform 12 1385 env13632 = env13633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env13632 == env13633) = true)

theorem identity13633 : scanCanonicalize (H12AffineFastState.compose env13633 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13633 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env13634 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,1353,5204,80,65536,5189,3392,1025,81,5457,1,66898,1094,1352,65,3092,70979,69894,67667,1364,66882,257,1093,5124,67394]

theorem envBound13634 : H12AffineFastState.Bounded env13634 := by
  intro p hp
  have h : env13634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13633_13634 : H12AffineEnvironment.transform 4 0 env13633 = env13634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13633 == env13634) = true)

theorem identity13634 : scanCanonicalize (H12AffineFastState.compose env13634 (packedSelected [0,1,2,5,6,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2372) := by decide +kernel

theorem selectedBound13634 : packedSelected [0,1,2,5,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13635 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,2372,1353,3344,80,65536,3329,3392,1025,81,3093,1,66898,1094,1352,65,3092,68615,67650,67667,1364,66882,257,1093,3392,67394]

theorem envBound13635 : H12AffineFastState.Bounded env13635 := by
  intro p hp
  have h : env13635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13634_13635 : H12AffineEnvironment.transform 11 2372 env13634 = env13635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2372 env13634 == env13635) = true)

theorem identity13635 : scanCanonicalize (H12AffineFastState.compose env13635 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13635 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env13636 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,2372,1353,3344,80,342,3329,3392,1025,81,3093,1,1028,1094,1352,65,3092,3409,2324,2309,1364,1044,257,1093,3392,1556]

theorem envBound13636 : H12AffineFastState.Bounded env13636 := by
  intro p hp
  have h : env13636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13635_13636 : H12AffineEnvironment.transform 15 342 env13635 = env13636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13635 == env13636) = true)

theorem identity13636 : scanCanonicalize (H12AffineFastState.compose env13636 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13636 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13637 : List Nat := [2,4,8,16,0,64,9,256,512,21,2048,2372,348,2309,80,342,2324,2389,20,81,2048,1,17,83,349,65,2049,2372,2324,2309,321,1,257,80,2389,513]

theorem envBound13637 : H12AffineFastState.Bounded env13637 := by
  intro p hp
  have h : env13637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13636_13637 : H12AffineEnvironment.transform 9 21 env13636 = env13637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13636 == env13637) = true)

theorem identity13637 : scanCanonicalize (H12AffineFastState.compose env13637 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13638 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,2113,89,2048,80,83,2065,2128,20,81,2048,1,17,83,88,65,2049,2113,2065,2048,68,1,4,80,2128,513]

theorem envBound13638 : H12AffineFastState.Bounded env13638 := by
  intro p hp
  have h : env13638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13637_13638 : H12AffineEnvironment.transform 7 5 env13637 = env13638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13637 == env13638) = true)

theorem identity13638 : scanCanonicalize (H12AffineFastState.compose env13638 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13638 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13639 : List Nat := [2,4,8,16,0,64,9,5,1,21,2048,2113,89,2048,80,83,2065,2128,20,81,2048,1,17,83,88,65,2049,2113,2065,2048,68,1,4,80,2128,0]

theorem envBound13639 : H12AffineFastState.Bounded env13639 := by
  intro p hp
  have h : env13639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13638_13639 : H12AffineEnvironment.transform 8 1 env13638 = env13639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13638 == env13639) = true)

theorem identity13639 : scanCanonicalize (H12AffineFastState.compose env13639 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound13639 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13640 : List Nat := [2,4,8,16,0,64,9,5,1,21,17,80,89,17,80,83,0,65,20,81,17,1,17,83,88,65,16,80,0,17,68,1,4,80,65,0]

theorem envBound13640 : H12AffineFastState.Bounded env13640 := by
  intro p hp
  have h : env13640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13639_13640 : H12AffineEnvironment.transform 10 17 env13639 = env13640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13639 == env13640) = true)

theorem identity13640 : scanCanonicalize (H12AffineFastState.compose env13640 (packedSelected [1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13640 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env13641 : List Nat := [2,4,8,16,0,17,9,5,1,21,17,1,8,17,1,2,0,16,20,0,17,1,17,2,9,16,16,1,0,17,21,1,4,1,16,0]

theorem envBound13641 : H12AffineFastState.Bounded env13641 := by
  intro p hp
  have h : env13641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13640_13641 : H12AffineEnvironment.transform 5 17 env13640 = env13641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13640 == env13641) = true)

theorem identity13641 : scanCanonicalize (H12AffineFastState.compose env13641 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13642 : List Nat := [2,4,3,16,0,17,2,5,1,21,17,1,3,17,1,2,0,16,20,0,17,1,17,2,2,16,16,1,0,17,21,1,4,1,16,0]

theorem envBound13642 : H12AffineFastState.Bounded env13642 := by
  intro p hp
  have h : env13642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13641_13642 : H12AffineEnvironment.transform 2 3 env13641 = env13642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13641 == env13642) = true)

theorem identity13642 : scanCanonicalize (H12AffineFastState.compose env13642 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13642 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13643 : List Nat := [2,4,3,0,0,1,2,5,1,5,1,1,3,1,1,2,0,0,4,0,1,1,1,2,2,0,0,1,0,1,5,1,4,1,0,0]

theorem envBound13643 : H12AffineFastState.Bounded env13643 := by
  intro p hp
  have h : env13643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13642_13643 : H12AffineEnvironment.transform 3 0 env13642 = env13643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13642 == env13643) = true)

def env13644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound13644 : H12AffineFastState.Bounded env13644 := by
  intro p hp
  have h : env13644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12477_13644 : H12AffineEnvironment.transform 29 155254785 env12477 = env13644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env12477 == env13644) = true)

def env13645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound13645 : H12AffineFastState.Bounded env13645 := by
  intro p hp
  have h : env13645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13644_13645 : H12AffineEnvironment.transform 25 64 env13644 = env13645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env13644 == env13645) = true)

def env13646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound13646 : H12AffineFastState.Bounded env13646 := by
  intro p hp
  have h : env13646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13645_13646 : H12AffineEnvironment.transform 26 30393344 env13645 = env13646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env13645 == env13646) = true)

def env13647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound13647 : H12AffineFastState.Bounded env13647 := by
  intro p hp
  have h : env13647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13646_13647 : H12AffineEnvironment.transform 18 1024 env13646 = env13647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13646 == env13647) = true)

theorem identity13647 : scanCanonicalize (H12AffineFastState.compose env13647 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41430) := by decide +kernel

theorem selectedBound13647 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41430,8328,64,13066710,2172250,10507600,8830977,8463815,6407191,256,10577275,10585310,8389137]

theorem envBound13648 : H12AffineFastState.Bounded env13648 := by
  intro p hp
  have h : env13648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13647_13648 : H12AffineEnvironment.transform 23 41430 env13647 = env13648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41430 env13647 == env13648) = true)

def env13649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,8388608,41430,8328,64,13066710,115150,8434116,8830977,8463815,4268163,256,8487407,8478794,8389137]

theorem envBound13649 : H12AffineFastState.Bounded env13649 := by
  intro p hp
  have h : env13649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13648_13649 : H12AffineEnvironment.transform 20 58516 env13648 = env13649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env13648 == env13649) = true)

def env13650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,16,41430,8328,64,4678086,115150,45524,442385,75223,4268163,256,98815,90202,513]

theorem envBound13650 : H12AffineFastState.Bounded env13650 := by
  intro p hp
  have h : env13650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13649_13650 : H12AffineEnvironment.transform 22 16 env13649 = env13650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env13649 == env13650) = true)

def env13651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677966,115014,45404,442385,75103,4268043,256,98679,90202,513]

theorem envBound13651 : H12AffineFastState.Bounded env13651 := by
  intro p hp
  have h : env13651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13650_13651 : H12AffineEnvironment.transform 6 8 env13650 = env13651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13650 == env13651) = true)

theorem identity13651 : scanCanonicalize (H12AffineFastState.compose env13651 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13651 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,17728,4194304,16,2,8192,64,4677966,90138,4096,418125,75103,4268043,256,73771,90202,513]

theorem envBound13652 : H12AffineFastState.Bounded env13652 := by
  intro p hp
  have h : env13652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13651_13652 : H12AffineEnvironment.transform 14 8540 env13651 = env13652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13651 == env13652) = true)

theorem identity13652 : scanCanonicalize (H12AffineFastState.compose env13652 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound13652 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,131072,262144,1024,8541,5457,4194304,16,2,8192,64,4665695,77835,4096,405852,75103,4268043,256,73771,77899,513]

theorem envBound13653 : H12AffineFastState.Bounded env13653 := by
  intro p hp
  have h : env13653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13652_13653 : H12AffineEnvironment.transform 13 4113 env13652 = env13653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env13652 == env13653) = true)

theorem identity13653 : scanCanonicalize (H12AffineFastState.compose env13653 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 77835) := by decide +kernel

theorem selectedBound13653 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env13654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,77835,4096,328023,75103,4268043,256,73771,77899,513]

theorem envBound13654 : H12AffineFastState.Bounded env13654 := by
  intro p hp
  have h : env13654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13653_13654 : H12AffineEnvironment.transform 16 77835 env13653 = env13654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77835 env13653 == env13654) = true)

theorem identity13654 : scanCanonicalize (H12AffineFastState.compose env13654 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound13654 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env13655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,262144,1024,8541,5457,33,16,2,8192,64,262517,77835,4096,328023,75103,73770,256,73771,77899,513]

theorem envBound13655 : H12AffineFastState.Bounded env13655 := by
  intro p hp
  have h : env13655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13654_13655 : H12AffineEnvironment.transform 21 33 env13654 = env13655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13654 == env13655) = true)

theorem identity13655 : scanCanonicalize (H12AffineFastState.compose env13655 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13655 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env13656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77835,10280,1024,8541,5457,33,16,2,8192,64,10589,77835,4096,76159,75103,73770,256,73771,77899,513]

theorem envBound13656 : H12AffineFastState.Bounded env13656 := by
  intro p hp
  have h : env13656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13655_13656 : H12AffineEnvironment.transform 17 10280 env13655 = env13656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13655 == env13656) = true)

theorem identity13656 : scanCanonicalize (H12AffineFastState.compose env13656 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15487) := by decide +kernel

theorem selectedBound13656 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,15487,3188,10280,1024,8541,5457,33,16,2,8192,64,10589,3188,4096,5376,6432,7253,256,7252,3124,513]

theorem envBound13657 : H12AffineFastState.Bounded env13657 := by
  intro p hp
  have h : env13657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13656_13657 : H12AffineEnvironment.transform 15 15487 env13656 = env13657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15487 env13656 == env13657) = true)

theorem identity13657 : scanCanonicalize (H12AffineFastState.compose env13657 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13657 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env13658 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8540,14362,2065,10280,101,8541,4404,33,16,2,8192,64,10589,2065,4096,4453,6432,6192,256,6193,2129,513]

theorem envBound13658 : H12AffineFastState.Bounded env13658 := by
  intro p hp
  have h : env13658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13657_13658 : H12AffineEnvironment.transform 9 101 env13657 = env13658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13657 == env13658) = true)

theorem identity13658 : scanCanonicalize (H12AffineFastState.compose env13658 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13658 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env13659 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4113,0,6470,2065,2420,101,1,4404,33,16,2,348,64,2049,2065,4096,4453,6432,6192,256,6193,2129,513]

theorem envBound13659 : H12AffineFastState.Bounded env13659 := by
  intro p hp
  have h : env13659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13658_13659 : H12AffineEnvironment.transform 12 348 env13658 = env13659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13658 == env13659) = true)

theorem identity13659 : scanCanonicalize (H12AffineFastState.compose env13659 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound13659 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13660 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,348,2049,0,342,2065,2420,101,1,2340,33,16,2,348,64,2049,2065,2064,2421,304,32,256,33,2129,513]

theorem envBound13660 : H12AffineFastState.Bounded env13660 := by
  intro p hp
  have h : env13660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13659_13660 : H12AffineEnvironment.transform 11 2064 env13659 = env13660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env13659 == env13660) = true)

theorem identity13660 : scanCanonicalize (H12AffineFastState.compose env13660 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound13660 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env13661 : List Nat := [2,4,8,16,32,64,8,256,512,101,302,318,348,303,0,342,319,90,101,1,10,33,16,2,348,64,303,319,318,91,304,32,256,33,383,513]

theorem envBound13661 : H12AffineFastState.Bounded env13661 := by
  intro p hp
  have h : env13661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13660_13661 : H12AffineEnvironment.transform 10 302 env13660 = env13661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env13660 == env13661) = true)

theorem identity13661 : scanCanonicalize (H12AffineFastState.compose env13661 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13661 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13662 : List Nat := [2,4,8,16,32,16,8,256,512,53,302,318,268,303,0,262,319,10,53,1,10,33,16,2,268,16,303,319,318,11,304,32,256,33,303,513]

theorem envBound13662 : H12AffineFastState.Bounded env13662 := by
  intro p hp
  have h : env13662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13661_13662 : H12AffineEnvironment.transform 5 16 env13661 = env13662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13661 == env13662) = true)

theorem identity13662 : scanCanonicalize (H12AffineFastState.compose env13662 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13662 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13663 : List Nat := [2,4,8,16,32,16,8,37,512,53,11,27,41,10,0,35,26,10,53,1,10,33,16,2,41,16,10,26,27,11,21,32,37,33,10,513]

theorem envBound13663 : H12AffineFastState.Bounded env13663 := by
  intro p hp
  have h : env13663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13662_13663 : H12AffineEnvironment.transform 7 37 env13662 = env13663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13662 == env13663) = true)

theorem identity13663 : scanCanonicalize (H12AffineFastState.compose env13663 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13663 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13664 : List Nat := [2,4,8,1,32,1,8,37,512,36,11,10,41,10,0,35,11,10,36,1,10,33,1,2,41,1,10,11,10,11,4,32,37,33,10,513]

theorem envBound13664 : H12AffineFastState.Bounded env13664 := by
  intro p hp
  have h : env13664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13663_13664 : H12AffineEnvironment.transform 3 1 env13663 = env13664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13663 == env13664) = true)

theorem identity13664 : scanCanonicalize (H12AffineFastState.compose env13664 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13664 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13665 : List Nat := [2,4,2,1,32,1,2,37,512,36,1,0,35,0,0,35,1,0,36,1,0,33,1,2,35,1,0,1,0,1,4,32,37,33,0,513]

theorem envBound13665 : H12AffineFastState.Bounded env13665 := by
  intro p hp
  have h : env13665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13664_13665 : H12AffineEnvironment.transform 2 2 env13664 = env13665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13664 == env13665) = true)

def env13666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8193,64,4677967,115015,45405,442385,75102,4268042,256,98678,90202,513]

theorem envBound13666 : H12AffineFastState.Bounded env13666 := by
  intro p hp
  have h : env13666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13650_13666 : H12AffineEnvironment.transform 6 9 env13650 = env13666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13650 == env13666) = true)

def env13667 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8193,16,4677919,114967,45325,442385,75022,4268042,256,98598,90122,513]

theorem envBound13667 : H12AffineFastState.Bounded env13667 := by
  intro p hp
  have h : env13667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13666_13667 : H12AffineEnvironment.transform 5 16 env13666 = env13667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13666 == env13667) = true)

def env13668 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8193,16,4409655,114967,45325,190521,75022,4268042,256,98598,90122,513]

theorem envBound13668 : H12AffineFastState.Bounded env13668 := by
  intro p hp
  have h : env13668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13667_13668 : H12AffineEnvironment.transform 17 10280 env13667 = env13668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13667 == env13668) = true)

theorem identity13668 : scanCanonicalize (H12AffineFastState.compose env13668 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound13668 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env13669 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118035,16,41231,8193,16,164900,114967,45325,190521,75022,60697,256,98598,90122,513]

theorem envBound13669 : H12AffineFastState.Bounded env13669 := by
  intro p hp
  have h : env13669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13668_13669 : H12AffineEnvironment.transform 21 118035 env13668 = env13669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env13668 == env13669) = true)

theorem identity13669 : scanCanonicalize (H12AffineFastState.compose env13669 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound13669 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env13670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,58397,118035,16,41231,8193,16,123966,114967,45325,100387,75022,60697,256,98598,90122,513]

theorem envBound13670 : H12AffineFastState.Bounded env13670 := by
  intro p hp
  have h : env13670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13669_13670 : H12AffineEnvironment.transform 16 90138 env13669 = env13670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env13669 == env13670) = true)

theorem identity13670 : scanCanonicalize (H12AffineFastState.compose env13670 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11292) := by decide +kernel

theorem selectedBound13670 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env13671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11292,65536,90138,10280,1024,11293,18433,90383,16,3347,8193,16,84002,93451,7441,74815,75022,16645,256,77114,90122,513]

theorem envBound13671 : H12AffineFastState.Bounded env13671 := by
  intro p hp
  have h : env13671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13670_13671 : H12AffineEnvironment.transform 14 11292 env13670 = env13671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11292 env13670 == env13671) = true)

theorem identity13671 : scanCanonicalize (H12AffineFastState.compose env13671 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13671 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13672 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11292,8203,16401,10280,1024,11293,18433,16644,16,3347,8193,16,26665,19712,7441,1076,1285,16645,256,3377,16385,513]

theorem envBound13672 : H12AffineFastState.Bounded env13672 := by
  intro p hp
  have h : env13672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13671_13672 : H12AffineEnvironment.transform 15 8203 env13671 = env13672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13671 == env13672) = true)

theorem identity13672 : scanCanonicalize (H12AffineFastState.compose env13672 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound13672 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13673 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,4113,11292,8203,4096,10280,1024,11293,6160,4373,16,3347,8193,16,14392,7441,7441,1076,1285,4372,256,3377,4112,513]

theorem envBound13673 : H12AffineFastState.Bounded env13673 := by
  intro p hp
  have h : env13673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13672_13673 : H12AffineEnvironment.transform 13 4113 env13672 = env13673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env13672 == env13673) = true)

theorem identity13673 : scanCanonicalize (H12AffineFastState.compose env13673 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound13673 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env13674 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,4113,6452,5411,4096,7424,1024,6453,6160,4373,16,3347,5417,16,3344,7441,7441,1076,1285,4372,256,3377,4112,513]

theorem envBound13674 : H12AffineFastState.Bounded env13674 := by
  intro p hp
  have h : env13674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13673_13674 : H12AffineEnvironment.transform 12 5416 env13673 = env13674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env13673 == env13674) = true)

theorem identity13674 : scanCanonicalize (H12AffineFastState.compose env13674 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound13674 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13675 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,2089,3344,1077,2082,3329,1,1024,1076,1297,3092,16,3347,2088,16,3344,16,16,1076,1285,3093,256,3377,3345,513]

theorem envBound13675 : H12AffineFastState.Bounded env13675 := by
  intro p hp
  have h : env13675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13674_13675 : H12AffineEnvironment.transform 11 3329 env13674 = env13675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env13674 == env13675) = true)

theorem identity13675 : scanCanonicalize (H12AffineFastState.compose env13675 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13675 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env13676 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,3329,2089,3344,1077,2082,3329,1,1024,1076,1297,3092,16,3347,2088,16,3344,16,16,1076,1285,3093,256,3377,3345,0]

theorem envBound13676 : H12AffineFastState.Bounded env13676 := by
  intro p hp
  have h : env13676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13675_13676 : H12AffineEnvironment.transform 8 1 env13675 = env13676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13675 == env13676) = true)

theorem identity13676 : scanCanonicalize (H12AffineFastState.compose env13676 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound13676 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13677 : List Nat := [2,4,8,16,32,16,9,256,1,273,2048,2064,2089,2049,292,2082,2064,1,273,293,0,2309,16,2050,2088,16,2049,16,16,293,20,2308,256,2080,2048,0]

theorem envBound13677 : H12AffineFastState.Bounded env13677 := by
  intro p hp
  have h : env13677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13676_13677 : H12AffineEnvironment.transform 9 273 env13676 = env13677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13676 == env13677) = true)

theorem identity13677 : scanCanonicalize (H12AffineFastState.compose env13677 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound13677 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13678 : List Nat := [2,4,8,16,32,16,9,256,1,273,293,309,268,292,292,263,309,1,273,293,0,32,16,295,269,16,292,16,16,293,20,33,256,261,293,0]

theorem envBound13678 : H12AffineFastState.Bounded env13678 := by
  intro p hp
  have h : env13678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13677_13678 : H12AffineEnvironment.transform 10 293 env13677 = env13678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env13677 == env13678) = true)

theorem identity13678 : scanCanonicalize (H12AffineFastState.compose env13678 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13678 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13679 : List Nat := [2,4,8,16,16,16,9,256,1,273,277,261,268,276,276,263,261,1,273,277,0,16,16,279,269,16,276,16,16,277,20,17,256,261,277,0]

theorem envBound13679 : H12AffineFastState.Bounded env13679 := by
  intro p hp
  have h : env13679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13678_13679 : H12AffineEnvironment.transform 4 16 env13678 = env13679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13678 == env13679) = true)

theorem identity13679 : scanCanonicalize (H12AffineFastState.compose env13679 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound13679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13680 : List Nat := [2,4,8,16,16,16,9,20,1,5,1,17,24,0,0,19,17,1,5,1,0,16,16,3,25,16,0,16,16,1,20,17,20,17,1,0]

theorem envBound13680 : H12AffineFastState.Bounded env13680 := by
  intro p hp
  have h : env13680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13679_13680 : H12AffineEnvironment.transform 7 20 env13679 = env13680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env13679 == env13680) = true)

def env13681 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8193,16,4409654,114967,45325,190520,75022,4268042,256,98598,90122,513]

theorem envBound13681 : H12AffineFastState.Bounded env13681 := by
  intro p hp
  have h : env13681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13667_13681 : H12AffineEnvironment.transform 17 10281 env13667 = env13681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13667 == env13681) = true)

theorem identity13681 : scanCanonicalize (H12AffineFastState.compose env13681 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound13681 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env13682 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246070,16,41231,8193,16,34816,114967,45325,190520,75022,188732,256,98598,90122,513]

theorem envBound13682 : H12AffineFastState.Bounded env13682 := by
  intro p hp
  have h : env13682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13681_13682 : H12AffineEnvironment.transform 21 246070 env13681 = env13682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env13681 == env13682) = true)

theorem identity13682 : scanCanonicalize (H12AffineFastState.compose env13682 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound13682 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env13683 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,114967,10281,1024,32769,58397,33,16,41231,8193,16,34816,114967,45325,76079,75022,73771,256,98598,90122,513]

theorem envBound13683 : H12AffineFastState.Bounded env13683 := by
  intro p hp
  have h : env13683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13682_13683 : H12AffineEnvironment.transform 16 114967 env13682 = env13683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env13682 == env13683) = true)

theorem identity13683 : scanCanonicalize (H12AffineFastState.compose env13683 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound13683 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13684 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,49169,10281,1024,32769,58397,33,16,41231,8193,16,34816,49169,45325,10281,9224,8493,256,32800,24844,513]

theorem envBound13684 : H12AffineFastState.Bounded env13684 := by
  intro p hp
  have h : env13684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13683_13684 : H12AffineEnvironment.transform 15 262 env13683 = env13684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env13683 == env13684) = true)

theorem identity13684 : scanCanonicalize (H12AffineFastState.compose env13684 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13684 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13685 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,262,24860,10281,1024,8460,17680,33,16,2,8193,16,10509,24860,4096,10281,9224,8493,256,8493,24844,513]

theorem envBound13685 : H12AffineFastState.Bounded env13685 := by
  intro p hp
  have h : env13685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13684_13685 : H12AffineEnvironment.transform 14 8461 env13684 = env13685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13684 == env13685) = true)

theorem identity13685 : scanCanonicalize (H12AffineFastState.compose env13685 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13685 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13686 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1024,0,17680,33,16,2,269,16,2049,16400,4096,2341,1284,33,256,33,16384,513]

theorem envBound13686 : H12AffineFastState.Bounded env13686 := by
  intro p hp
  have h : env13686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13685_13686 : H12AffineEnvironment.transform 12 268 env13685 = env13686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13685 == env13686) = true)

theorem identity13686 : scanCanonicalize (H12AffineFastState.compose env13686 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13687 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,16,268,16384,1,262,16400,2341,1024,0,17680,33,16,2,269,16,2049,16400,16,2341,1284,33,256,33,16384,513]

theorem envBound13687 : H12AffineFastState.Bounded env13687 := by
  intro p hp
  have h : env13687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13686_13687 : H12AffineEnvironment.transform 11 16 env13686 = env13687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13686 == env13687) = true)

def env13688 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8193,17,4677918,114966,45324,442385,75023,4268042,256,98599,90123,513]

theorem envBound13688 : H12AffineFastState.Bounded env13688 := by
  intro p hp
  have h : env13688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13666_13688 : H12AffineEnvironment.transform 5 17 env13666 = env13688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13666 == env13688) = true)

theorem identity13688 : scanCanonicalize (H12AffineFastState.compose env13688 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound13688 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env13689 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4409655,114966,45324,190520,75023,4268042,256,98599,90123,513]

theorem envBound13689 : H12AffineFastState.Bounded env13689 := by
  intro p hp
  have h : env13689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13688_13689 : H12AffineEnvironment.transform 17 10281 env13688 = env13689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13688 == env13689) = true)

theorem identity13689 : scanCanonicalize (H12AffineFastState.compose env13689 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound13689 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env13690 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4385084,24861,45324,190520,34052,4227073,256,8492,49152,513]

theorem envBound13690 : H12AffineFastState.Bounded env13690 := by
  intro p hp
  have h : env13690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13689_13690 : H12AffineEnvironment.transform 15 40971 env13689 = env13690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env13689 == env13690) = true)

theorem identity13690 : scanCanonicalize (H12AffineFastState.compose env13690 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound13690 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13691 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58397,147505,16,41230,8193,17,43277,24861,45324,190520,34052,180272,256,8492,49152,513]

theorem envBound13691 : H12AffineFastState.Bounded env13691 := by
  intro p hp
  have h : env13691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13690_13691 : H12AffineEnvironment.transform 21 147505 env13690 = env13691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env13690 == env13691) = true)

theorem identity13691 : scanCanonicalize (H12AffineFastState.compose env13691 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound13691 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13692 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,24861,10281,1024,32769,58397,8492,16,41230,8193,17,43277,24861,45324,35109,34052,41261,256,8492,49152,513]

theorem envBound13692 : H12AffineFastState.Bounded env13692 := by
  intro p hp
  have h : env13692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13691_13692 : H12AffineEnvironment.transform 16 24861 env13691 = env13692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env13691 == env13692) = true)

def env13693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,17,41430,8328,64,4678087,115150,45525,442384,75222,4268163,256,98814,90203,512]

theorem envBound13693 : H12AffineFastState.Bounded env13693 := by
  intro p hp
  have h : env13693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13649_13693 : H12AffineEnvironment.transform 22 17 env13649 = env13693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env13649 == env13693) = true)

theorem identity13693 : scanCanonicalize (H12AffineFastState.compose env13693 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10709) := by decide +kernel

theorem selectedBound13693 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58516,4194304,17,41430,8328,64,4409362,115150,45525,190917,75222,4268163,256,98814,90203,512]

theorem envBound13694 : H12AffineFastState.Bounded env13694 := by
  intro p hp
  have h : env13694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13693_13694 : H12AffineEnvironment.transform 17 10709 env13693 = env13694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10709 env13693 == env13694) = true)

theorem identity13694 : scanCanonicalize (H12AffineFastState.compose env13694 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62849) := by decide +kernel

theorem selectedBound13694 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58516,62849,17,41430,8328,64,245139,115150,45525,190917,75222,120066,256,98814,90203,512]

theorem envBound13695 : H12AffineFastState.Bounded env13695 := by
  intro p hp
  have h : env13695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13694_13695 : H12AffineEnvironment.transform 21 62849 env13694 = env13695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62849 env13694 == env13695) = true)

theorem identity13695 : scanCanonicalize (H12AffineFastState.compose env13695 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound13695 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10709,1024,32769,58516,62849,17,41430,8328,64,130435,115150,45525,43477,75222,120066,256,98814,90203,512]

theorem envBound13696 : H12AffineFastState.Bounded env13696 := by
  intro p hp
  have h : env13696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13695_13696 : H12AffineEnvironment.transform 16 16400 env13695 = env13696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13695 == env13696) = true)

theorem identity13696 : scanCanonicalize (H12AffineFastState.compose env13696 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound13696 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env13697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16400,10709,1024,32769,58516,62849,17,41430,8328,64,10588,5393,45525,43477,61705,477,256,21793,46212,512]

theorem envBound13697 : H12AffineFastState.Bounded env13697 := by
  intro p hp
  have h : env13697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13696_13697 : H12AffineEnvironment.transform 15 54495 env13696 = env13697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env13696 == env13697) = true)

theorem identity13697 : scanCanonicalize (H12AffineFastState.compose env13697 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound13697 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env13698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,32768,32939,5220,10709,1024,32769,45280,41461,17,41430,8328,64,10588,5393,45525,43477,42365,477,256,341,46212,512]

theorem envBound13698 : H12AffineFastState.Bounded env13698 := by
  intro p hp
  have h : env13698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13697_13698 : H12AffineEnvironment.transform 13 5236 env13697 = env13698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env13697 == env13698) = true)

theorem identity13698 : scanCanonicalize (H12AffineFastState.compose env13698 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 396) := by decide +kernel

theorem selectedBound13698 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,396,295,5220,10709,1024,397,12652,8313,17,8282,8328,64,10588,5393,12377,10329,9457,477,256,341,13576,512]

theorem envBound13699 : H12AffineFastState.Bounded env13699 := by
  intro p hp
  have h : env13699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13698_13699 : H12AffineEnvironment.transform 14 396 env13698 = env13699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 396 env13698 == env13699) = true)

theorem identity13699 : scanCanonicalize (H12AffineFastState.compose env13699 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound13699 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env13700 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,112,219,5220,10281,1024,113,12432,8313,17,8282,8328,64,10400,5357,12377,10329,9457,33,252,169,13556,512]

theorem envBound13700 : H12AffineFastState.Bounded env13700 := by
  intro p hp
  have h : env13700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13699_13700 : H12AffineEnvironment.transform 7 252 env13699 = env13700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env13699 == env13700) = true)

theorem identity13700 : scanCanonicalize (H12AffineFastState.compose env13700 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound13700 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env13701 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,88,5236,112,219,5220,2161,1024,113,4296,33,17,2,208,64,2296,5357,4097,2049,1193,33,252,169,5292,512]

theorem envBound13701 : H12AffineFastState.Bounded env13701 := by
  intro p hp
  have h : env13701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13700_13701 : H12AffineEnvironment.transform 12 88 env13700 = env13701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env13700 == env13701) = true)

theorem identity13701 : scanCanonicalize (H12AffineFastState.compose env13701 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13701 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env13702 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,88,5236,112,82,5220,2161,1024,113,4161,33,17,2,89,64,2161,5220,4097,2049,1056,33,117,32,5157,512]

theorem envBound13702 : H12AffineFastState.Bounded env13702 := by
  intro p hp
  have h : env13702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13701_13702 : H12AffineEnvironment.transform 6 9 env13701 = env13702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13701 == env13702) = true)

theorem identity13702 : scanCanonicalize (H12AffineFastState.compose env13702 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13702 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13703 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8,5156,32,2,5172,2081,1024,33,4113,33,17,2,9,16,2081,5172,4097,2049,1056,33,37,32,5157,512]

theorem envBound13703 : H12AffineFastState.Bounded env13703 := by
  intro p hp
  have h : env13703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13702_13703 : H12AffineEnvironment.transform 5 16 env13702 = env13703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13702 == env13703) = true)

theorem identity13703 : scanCanonicalize (H12AffineFastState.compose env13703 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13703 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13704 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,8,4112,32,2,4096,2081,52,33,4113,33,17,2,9,16,2081,4096,4097,2049,20,33,37,32,4113,512]

theorem envBound13704 : H12AffineFastState.Bounded env13704 := by
  intro p hp
  have h : env13704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13703_13704 : H12AffineEnvironment.transform 9 52 env13703 = env13704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13703 == env13704) = true)

theorem identity13704 : scanCanonicalize (H12AffineFastState.compose env13704 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 516) := by decide +kernel

theorem selectedBound13704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13705 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,516,8,532,32,2,516,2081,52,33,533,33,17,2,9,16,2081,516,517,2049,20,33,37,32,533,512]

theorem envBound13705 : H12AffineFastState.Bounded env13705 := by
  intro p hp
  have h : env13705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13704_13705 : H12AffineEnvironment.transform 11 516 env13704 = env13705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 516 env13704 == env13705) = true)

theorem identity13705 : scanCanonicalize (H12AffineFastState.compose env13705 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound13705 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13706 : List Nat := [2,4,8,16,32,16,9,37,512,52,31,516,8,532,32,2,516,62,52,33,533,33,17,2,9,16,62,516,517,30,20,33,37,32,533,512]

theorem envBound13706 : H12AffineFastState.Bounded env13706 := by
  intro p hp
  have h : env13706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13705_13706 : H12AffineEnvironment.transform 10 31 env13705 = env13706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env13705 == env13706) = true)

theorem identity13706 : scanCanonicalize (H12AffineFastState.compose env13706 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound13706 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13707 : List Nat := [2,4,8,16,32,16,9,37,12,52,31,8,8,24,32,2,8,62,52,33,25,33,17,2,9,16,62,8,9,30,20,33,37,32,25,12]

theorem envBound13707 : H12AffineFastState.Bounded env13707 := by
  intro p hp
  have h : env13707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13706_13707 : H12AffineEnvironment.transform 8 12 env13706 = env13707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env13706 == env13707) = true)

theorem identity13707 : scanCanonicalize (H12AffineFastState.compose env13707 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound13707 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13708 : List Nat := [2,4,8,16,30,16,9,27,12,10,31,8,8,24,30,2,8,0,10,31,25,31,17,2,9,16,0,8,9,30,20,31,27,30,25,12]

theorem envBound13708 : H12AffineFastState.Bounded env13708 := by
  intro p hp
  have h : env13708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13707_13708 : H12AffineEnvironment.transform 4 30 env13707 = env13708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env13707 == env13708) = true)

theorem identity13708 : scanCanonicalize (H12AffineFastState.compose env13708 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound13708 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13709 : List Nat := [2,4,8,15,1,15,9,4,12,10,0,8,8,7,1,2,8,0,10,0,6,0,14,2,9,15,0,8,9,1,11,0,4,1,6,12]

theorem envBound13709 : H12AffineFastState.Bounded env13709 := by
  intro p hp
  have h : env13709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13708_13709 : H12AffineEnvironment.transform 3 15 env13708 = env13709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env13708 == env13709) = true)

theorem identity13709 : scanCanonicalize (H12AffineFastState.compose env13709 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13710 : List Nat := [2,2,8,9,1,9,9,2,10,10,0,8,8,1,1,2,8,0,10,0,0,0,8,2,9,9,0,8,9,1,11,0,2,1,0,10]

theorem envBound13710 : H12AffineFastState.Bounded env13710 := by
  intro p hp
  have h : env13710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13709_13710 : H12AffineEnvironment.transform 1 2 env13709 = env13710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13709 == env13710) = true)

def env13711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,8388608,41430,8328,64,13066710,115151,8434117,8830977,8463815,4268162,256,8487406,8478795,8389137]

theorem envBound13711 : H12AffineFastState.Bounded env13711 := by
  intro p hp
  have h : env13711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13648_13711 : H12AffineEnvironment.transform 20 58517 env13648 = env13711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env13648 == env13711) = true)

def env13712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,16,41430,8328,64,4678086,115151,45525,442385,75223,4268162,256,98814,90203,513]

theorem envBound13712 : H12AffineFastState.Bounded env13712 := by
  intro p hp
  have h : env13712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13711_13712 : H12AffineEnvironment.transform 22 16 env13711 = env13712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env13711 == env13712) = true)

theorem identity13712 : scanCanonicalize (H12AffineFastState.compose env13712 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13712 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58517,4194304,16,41430,8328,64,4604364,57797,45525,442385,1501,4194440,256,41460,16465,513]

theorem envBound13713 : H12AffineFastState.Bounded env13713 := by
  intro p hp
  have h : env13713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13712_13713 : H12AffineEnvironment.transform 15 8202 env13712 = env13713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13712 == env13713) = true)

theorem identity13713 : scanCanonicalize (H12AffineFastState.compose env13713 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound13713 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env13714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58517,419913,16,41430,8328,64,10629,57797,45525,442385,1501,420033,256,41460,16465,513]

theorem envBound13714 : H12AffineFastState.Bounded env13714 := by
  intro p hp
  have h : env13714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13713_13714 : H12AffineEnvironment.transform 21 419913 env13713 = env13714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env13713 == env13714) = true)

def env13715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419913,16,41310,8192,64,10509,57677,45405,442385,1365,419913,256,41340,16465,513]

theorem envBound13715 : H12AffineFastState.Bounded env13715 := by
  intro p hp
  have h : env13715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13714_13715 : H12AffineEnvironment.transform 6 8 env13714 = env13715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13714 == env13715) = true)

theorem identity13715 : scanCanonicalize (H12AffineFastState.compose env13715 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,262144,1024,8541,17729,419913,16,2,8192,64,10509,16401,4097,418125,1365,419913,256,32,16465,513]

theorem envBound13716 : H12AffineFastState.Bounded env13716 := by
  intro p hp
  have h : env13716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13715_13716 : H12AffineEnvironment.transform 14 8540 env13715 = env13716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13715 == env13716) = true)

theorem identity13716 : scanCanonicalize (H12AffineFastState.compose env13716 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound13716 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,10281,1024,8541,17729,147552,16,2,8192,64,10509,16401,4097,149860,1365,147552,256,32,16465,513]

theorem envBound13717 : H12AffineFastState.Bounded env13717 := by
  intro p hp
  have h : env13717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13716_13717 : H12AffineEnvironment.transform 17 10281 env13716 = env13717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13716 == env13717) = true)

theorem identity13717 : scanCanonicalize (H12AffineFastState.compose env13717 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 8477) := by decide +kernel

theorem selectedBound13717 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,8477,10281,1024,8541,17729,24957,16,2,8192,64,10509,16401,4097,26745,1365,24957,256,32,16465,513]

theorem envBound13718 : H12AffineFastState.Bounded env13718 := by
  intro p hp
  have h : env13718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13717_13718 : H12AffineEnvironment.transform 16 8477 env13717 = env13718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8477 env13717 == env13718) = true)

theorem identity13718 : scanCanonicalize (H12AffineFastState.compose env13718 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound13718 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,8192,16384,8540,8202,8477,8461,1024,8541,17729,24957,16,2,8192,64,8233,16401,4097,24925,1365,24957,256,32,16465,513]

theorem envBound13719 : H12AffineFastState.Bounded env13719 := by
  intro p hp
  have h : env13719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13718_13719 : H12AffineEnvironment.transform 10 292 env13718 = env13719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env13718 == env13719) = true)

theorem identity13719 : scanCanonicalize (H12AffineFastState.compose env13719 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound13719 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env13720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,8192,16384,8540,8202,8477,8461,1024,8541,17729,24957,16,2,8192,64,8233,16401,1281,24925,1365,24957,256,32,16465,513]

theorem envBound13720 : H12AffineFastState.Bounded env13720 := by
  intro p hp
  have h : env13720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13719_13720 : H12AffineEnvironment.transform 11 1280 env13719 = env13720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env13719 == env13720) = true)

theorem identity13720 : scanCanonicalize (H12AffineFastState.compose env13720 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13720 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,8192,1296,8540,8202,8477,8461,1024,8541,81,9325,16,2,8192,64,8233,1281,1281,9293,1365,9325,256,32,1345,513]

theorem envBound13721 : H12AffineFastState.Bounded env13721 := by
  intro p hp
  have h : env13721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13720_13721 : H12AffineEnvironment.transform 13 1296 env13720 = env13721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env13720 == env13721) = true)

theorem identity13721 : scanCanonicalize (H12AffineFastState.compose env13721 (packedSelected [9,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound13721 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env13722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,1053,1296,1345,1047,1280,1296,1024,1344,81,112,16,2,1053,64,1076,1281,1281,80,1365,112,256,32,1345,513]

theorem envBound13722 : H12AffineFastState.Bounded env13722 := by
  intro p hp
  have h : env13722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13721_13722 : H12AffineEnvironment.transform 12 1053 env13721 = env13722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env13721 == env13722) = true)

theorem identity13722 : scanCanonicalize (H12AffineFastState.compose env13722 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13722 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13723 : List Nat := [2,4,8,16,32,64,8,256,512,52,292,308,41,292,373,35,308,292,52,372,81,112,16,2,41,64,0,309,309,80,353,112,256,32,373,513]

theorem envBound13723 : H12AffineFastState.Bounded env13723 := by
  intro p hp
  have h : env13723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13722_13723 : H12AffineEnvironment.transform 9 52 env13722 = env13723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13722 == env13723) = true)

theorem identity13723 : scanCanonicalize (H12AffineFastState.compose env13723 (packedSelected [5,7] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound13723 : packedSelected [5,7] rootPS < 2^1333 := by decide +kernel

def env13724 : List Nat := [2,4,8,16,32,64,8,68,512,52,96,112,41,96,49,35,112,96,52,48,81,112,16,2,41,64,0,113,113,80,37,112,68,32,49,513]

theorem envBound13724 : H12AffineFastState.Bounded env13724 := by
  intro p hp
  have h : env13724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13723_13724 : H12AffineEnvironment.transform 7 68 env13723 = env13724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env13723 == env13724) = true)

theorem identity13724 : scanCanonicalize (H12AffineFastState.compose env13724 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound13724 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env13725 : List Nat := [2,4,8,16,32,33,8,37,512,52,1,17,41,1,49,35,17,1,52,48,48,17,16,2,41,33,0,16,16,49,37,17,37,32,49,513]

theorem envBound13725 : H12AffineFastState.Bounded env13725 := by
  intro p hp
  have h : env13725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13724_13725 : H12AffineEnvironment.transform 5 33 env13724 = env13725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env13724 == env13725) = true)

theorem identity13725 : scanCanonicalize (H12AffineFastState.compose env13725 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13726 : List Nat := [2,4,8,16,32,33,8,37,49,52,1,17,41,1,49,35,17,1,52,48,48,17,16,2,41,33,0,16,16,49,37,17,37,32,49,48]

theorem envBound13726 : H12AffineFastState.Bounded env13726 := by
  intro p hp
  have h : env13726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13725_13726 : H12AffineEnvironment.transform 8 49 env13725 = env13726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13725 == env13726) = true)

theorem identity13726 : scanCanonicalize (H12AffineFastState.compose env13726 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13726 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env13727 : List Nat := [2,4,8,16,17,16,8,20,0,5,1,17,24,1,0,18,17,1,5,1,1,17,16,2,24,16,0,16,16,0,20,17,20,17,0,1]

theorem envBound13727 : H12AffineFastState.Bounded env13727 := by
  intro p hp
  have h : env13727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13726_13727 : H12AffineEnvironment.transform 4 17 env13726 = env13727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13726 == env13727) = true)

def env13728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419913,16,41311,8193,64,10508,57676,45404,442385,1364,419912,256,41341,16465,513]

theorem envBound13728 : H12AffineFastState.Bounded env13728 := by
  intro p hp
  have h : env13728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13714_13728 : H12AffineEnvironment.transform 6 9 env13714 = env13728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13714 == env13728) = true)

def env13729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58396,272393,16,41311,8193,64,10508,57676,45404,294993,1364,272392,256,41341,16465,513]

theorem envBound13729 : H12AffineFastState.Bounded env13729 := by
  intro p hp
  have h : env13729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13728_13729 : H12AffineEnvironment.transform 16 16448 env13728 = env13729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env13728 == env13729) = true)

theorem identity13729 : scanCanonicalize (H12AffineFastState.compose env13729 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound13729 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,35109,1024,32769,58396,41260,16,41311,8193,64,10508,57676,45404,2420,1364,41261,256,41341,16465,513]

theorem envBound13730 : H12AffineFastState.Bounded env13730 := by
  intro p hp
  have h : env13730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13729_13730 : H12AffineEnvironment.transform 17 35109 env13729 = env13730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env13729 == env13730) = true)

theorem identity13730 : scanCanonicalize (H12AffineFastState.compose env13730 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13730 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env13731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16448,35109,1024,32769,50497,32881,16,32770,348,64,2129,49169,36865,2420,1364,32880,256,32800,16465,513]

theorem envBound13731 : H12AffineFastState.Bounded env13731 := by
  intro p hp
  have h : env13731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13730_13731 : H12AffineEnvironment.transform 12 349 env13730 = env13731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13730 == env13731) = true)

theorem identity13731 : scanCanonicalize (H12AffineFastState.compose env13731 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound13731 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,81,343,16448,2420,1024,80,17680,32,16,83,348,64,2129,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound13732 : H12AffineFastState.Bounded env13732 := by
  intro p hp
  have h : env13732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13731_13732 : H12AffineEnvironment.transform 14 81 env13731 = env13732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env13731 == env13732) = true)

theorem identity13732 : scanCanonicalize (H12AffineFastState.compose env13732 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13732 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13733 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,263,16400,2340,1024,0,17680,32,16,3,268,16,2049,16400,4096,2340,1284,33,256,33,16385,513]

theorem envBound13733 : H12AffineFastState.Bounded env13733 := by
  intro p hp
  have h : env13733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13732_13733 : H12AffineEnvironment.transform 5 16 env13732 = env13733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13732 == env13733) = true)

theorem identity13733 : scanCanonicalize (H12AffineFastState.compose env13733 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13733 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13734 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,1,263,16400,2309,1024,0,17680,1,16,3,268,16,2049,16400,4096,2309,1284,0,256,0,16385,513]

theorem envBound13734 : H12AffineFastState.Bounded env13734 := by
  intro p hp
  have h : env13734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13733_13734 : H12AffineEnvironment.transform 4 1 env13733 = env13734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13733 == env13734) = true)

theorem identity13734 : scanCanonicalize (H12AffineFastState.compose env13734 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13734 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13735 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,16,269,16384,1,263,16400,2309,1024,0,17680,1,16,3,268,16,2049,16400,16,2309,1284,0,256,0,16385,513]

theorem envBound13735 : H12AffineFastState.Bounded env13735 := by
  intro p hp
  have h : env13735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13734_13735 : H12AffineEnvironment.transform 11 16 env13734 = env13735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13734 == env13735) = true)

theorem identity13735 : scanCanonicalize (H12AffineFastState.compose env13735 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound13735 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13736 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,16,269,1808,1,263,1792,2309,1024,0,512,1,16,3,268,16,2049,1792,16,2309,1284,0,256,0,1809,513]

theorem envBound13736 : H12AffineFastState.Bounded env13736 := by
  intro p hp
  have h : env13736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13735_13736 : H12AffineEnvironment.transform 13 1808 env13735 = env13736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env13735 == env13736) = true)

theorem identity13736 : scanCanonicalize (H12AffineFastState.compose env13736 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound13736 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13737 : List Nat := [2,4,8,16,1,16,9,256,512,1024,528,16,269,1808,1,263,1792,789,1024,0,512,1,16,3,268,16,529,1792,16,789,1284,0,256,0,1809,513]

theorem envBound13737 : H12AffineFastState.Bounded env13737 := by
  intro p hp
  have h : env13737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13736_13737 : H12AffineEnvironment.transform 10 528 env13736 = env13737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env13736 == env13737) = true)

theorem identity13737 : scanCanonicalize (H12AffineFastState.compose env13737 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound13737 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13738 : List Nat := [2,4,8,16,1,16,9,256,512,256,528,16,269,528,1,263,512,789,256,0,512,1,16,3,268,16,529,512,16,789,4,0,256,0,529,513]

theorem envBound13738 : H12AffineFastState.Bounded env13738 := by
  intro p hp
  have h : env13738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13737_13738 : H12AffineEnvironment.transform 9 256 env13737 = env13738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env13737 == env13738) = true)

theorem identity13738 : scanCanonicalize (H12AffineFastState.compose env13738 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13738 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13739 : List Nat := [2,4,8,16,1,16,9,256,261,256,277,16,269,277,1,263,261,16,256,0,261,1,16,3,268,16,276,261,16,16,4,0,256,0,276,260]

theorem envBound13739 : H12AffineFastState.Bounded env13739 := by
  intro p hp
  have h : env13739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13738_13739 : H12AffineEnvironment.transform 8 261 env13738 = env13739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13738 == env13739) = true)

def env13740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58396,272392,16,41311,8193,64,10508,57676,45404,294992,1364,272393,256,41341,16465,513]

theorem envBound13740 : H12AffineFastState.Bounded env13740 := by
  intro p hp
  have h : env13740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13728_13740 : H12AffineEnvironment.transform 16 16449 env13728 = env13740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env13728 == env13740) = true)

theorem identity13740 : scanCanonicalize (H12AffineFastState.compose env13740 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound13740 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,43049,1024,32769,58396,32801,16,41311,8193,64,10508,57676,45404,10361,1364,32800,256,41341,16465,513]

theorem envBound13741 : H12AffineFastState.Bounded env13741 := by
  intro p hp
  have h : env13741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13740_13741 : H12AffineEnvironment.transform 17 43049 env13740 = env13741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env13740 == env13741) = true)

theorem identity13741 : scanCanonicalize (H12AffineFastState.compose env13741 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13741 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env13742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16449,10281,1024,1,25628,33,16,8543,8193,64,10508,24908,12636,10361,1364,32,256,8573,16465,513]

theorem envBound13742 : H12AffineFastState.Bounded env13742 := by
  intro p hp
  have h : env13742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13741_13742 : H12AffineEnvironment.transform 14 0 env13741 = env13742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13741 == env13742) = true)

theorem identity13742 : scanCanonicalize (H12AffineFastState.compose env13742 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13743 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,16401,10281,1024,1,25628,33,16,8463,8193,16,10508,24860,12556,10281,1284,32,256,8493,16385,513]

theorem envBound13743 : H12AffineFastState.Bounded env13743 := by
  intro p hp
  have h : env13743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13742_13743 : H12AffineEnvironment.transform 5 16 env13742 = env13743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13742 == env13743) = true)

theorem identity13743 : scanCanonicalize (H12AffineFastState.compose env13743 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11271) := by decide +kernel

theorem selectedBound13743 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env13744 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,11271,0,8202,11286,10281,1024,1,2075,33,16,8463,8193,16,10508,3355,12556,10281,1284,32,256,8493,11270,513]

theorem envBound13744 : H12AffineFastState.Bounded env13744 := by
  intro p hp
  have h : env13744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13743_13744 : H12AffineEnvironment.transform 13 11271 env13743 = env13744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11271 env13743 == env13744) = true)

theorem identity13744 : scanCanonicalize (H12AffineFastState.compose env13744 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound13744 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13745 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2090,8192,11271,0,8202,11286,10281,1024,1,2075,33,16,8463,8193,16,10508,3355,10534,10281,1284,32,256,8493,11270,513]

theorem envBound13745 : H12AffineFastState.Bounded env13745 := by
  intro p hp
  have h : env13745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13744_13745 : H12AffineEnvironment.transform 11 2090 env13744 = env13745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env13744 == env13745) = true)

theorem identity13745 : scanCanonicalize (H12AffineFastState.compose env13745 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13745 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13746 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2090,268,3339,0,262,3354,2341,1024,1,2075,33,16,3,269,16,2048,3355,2090,2341,1284,32,256,33,3338,513]

theorem envBound13746 : H12AffineFastState.Bounded env13746 := by
  intro p hp
  have h : env13746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13745_13746 : H12AffineEnvironment.transform 12 268 env13745 = env13746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13745 == env13746) = true)

theorem identity13746 : scanCanonicalize (H12AffineFastState.compose env13746 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound13746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13747 : List Nat := [2,4,8,16,32,16,9,256,512,1024,270,292,268,1029,0,262,1044,43,1024,1,277,33,16,3,269,16,270,1045,292,43,1284,32,256,33,1028,513]

theorem envBound13747 : H12AffineFastState.Bounded env13747 := by
  intro p hp
  have h : env13747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13746_13747 : H12AffineEnvironment.transform 10 270 env13746 = env13747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env13746 == env13747) = true)

theorem identity13747 : scanCanonicalize (H12AffineFastState.compose env13747 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13747 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13748 : List Nat := [2,4,8,16,32,16,9,37,512,1024,43,1,41,1029,0,35,1044,43,1024,1,48,33,16,3,40,16,43,1045,1,43,1057,32,37,33,1028,513]

theorem envBound13748 : H12AffineFastState.Bounded env13748 := by
  intro p hp
  have h : env13748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13747_13748 : H12AffineEnvironment.transform 7 37 env13747 = env13748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13747 == env13748) = true)

theorem identity13748 : scanCanonicalize (H12AffineFastState.compose env13748 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13748 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13749 : List Nat := [2,4,8,16,32,16,9,37,512,21,43,1,41,16,0,35,1,43,21,1,48,33,16,3,40,16,43,0,1,43,52,32,37,33,17,513]

theorem envBound13749 : H12AffineFastState.Bounded env13749 := by
  intro p hp
  have h : env13749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13748_13749 : H12AffineEnvironment.transform 9 21 env13748 = env13749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13748 == env13749) = true)

theorem identity13749 : scanCanonicalize (H12AffineFastState.compose env13749 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13749 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13750 : List Nat := [2,4,8,16,0,16,9,5,512,21,11,1,9,16,0,3,1,11,21,1,16,1,16,3,8,16,11,0,1,11,20,0,5,1,17,513]

theorem envBound13750 : H12AffineFastState.Bounded env13750 := by
  intro p hp
  have h : env13750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13749_13750 : H12AffineEnvironment.transform 4 0 env13749 = env13750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13749 == env13750) = true)

theorem identity13750 : scanCanonicalize (H12AffineFastState.compose env13750 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound13750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13751 : List Nat := [2,4,8,16,0,16,9,5,30,21,11,1,9,16,0,3,1,11,21,1,16,1,16,3,8,16,11,0,1,11,20,0,5,1,17,31]

theorem envBound13751 : H12AffineFastState.Bounded env13751 := by
  intro p hp
  have h : env13751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13750_13751 : H12AffineEnvironment.transform 8 30 env13750 = env13751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env13750 == env13751) = true)

theorem identity13751 : scanCanonicalize (H12AffineFastState.compose env13751 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound13751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13752 : List Nat := [2,4,8,7,0,7,9,5,9,2,11,1,9,7,0,3,1,11,2,1,7,1,7,3,8,7,11,0,1,11,3,0,5,1,6,8]

theorem envBound13752 : H12AffineFastState.Bounded env13752 := by
  intro p hp
  have h : env13752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13751_13752 : H12AffineEnvironment.transform 3 7 env13751 = env13752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env13751 == env13752) = true)

def env13753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,17,41430,8328,64,4678087,115151,45524,442384,75222,4268162,256,98815,90202,512]

theorem envBound13753 : H12AffineFastState.Bounded env13753 := by
  intro p hp
  have h : env13753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13711_13753 : H12AffineEnvironment.transform 22 17 env13711 = env13753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env13711 == env13753) = true)

theorem identity13753 : scanCanonicalize (H12AffineFastState.compose env13753 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound13753 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58517,4194304,17,41430,8328,64,4409363,115151,45524,190916,75222,4268162,256,98815,90202,512]

theorem envBound13754 : H12AffineFastState.Bounded env13754 := by
  intro p hp
  have h : env13754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13753_13754 : H12AffineEnvironment.transform 17 10708 env13753 = env13754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env13753 == env13754) = true)

theorem identity13754 : scanCanonicalize (H12AffineFastState.compose env13754 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 120203) := by decide +kernel

theorem selectedBound13754 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58517,120203,17,41430,8328,64,171416,115151,45524,190916,75222,62729,256,98815,90202,512]

theorem envBound13755 : H12AffineFastState.Bounded env13755 := by
  intro p hp
  have h : env13755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13754_13755 : H12AffineEnvironment.transform 21 120203 env13754 = env13755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 120203 env13754 == env13755) = true)

theorem identity13755 : scanCanonicalize (H12AffineFastState.compose env13755 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound13755 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10708,1024,32769,58517,120203,17,41430,8328,64,56712,115151,45524,43476,75222,62729,256,98815,90202,512]

theorem envBound13756 : H12AffineFastState.Bounded env13756 := by
  intro p hp
  have h : env13756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13755_13756 : H12AffineEnvironment.transform 16 16400 env13755 = env13756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13755 == env13756) = true)

theorem identity13756 : scanCanonicalize (H12AffineFastState.compose env13756 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13756 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env13757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16400,10708,1024,29909,4161,74079,17,21762,8328,64,10588,79131,17664,23808,75222,477,256,95531,90202,512]

theorem envBound13757 : H12AffineFastState.Bounded env13757 := by
  intro p hp
  have h : env13757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13756_13757 : H12AffineEnvironment.transform 14 29908 env13756 = env13757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13756 == env13757) = true)

theorem identity13757 : scanCanonicalize (H12AffineFastState.compose env13757 (packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound13757 : packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env13758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8322,16400,10708,1024,29909,4161,477,17,21762,8328,64,10588,5529,17664,23808,1364,477,256,21929,16600,512]

theorem envBound13758 : H12AffineFastState.Bounded env13758 := by
  intro p hp
  have h : env13758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13757_13758 : H12AffineEnvironment.transform 15 8322 env13757 = env13758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env13757 == env13758) = true)

theorem identity13758 : scanCanonicalize (H12AffineFastState.compose env13758 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13777) := by decide +kernel

theorem selectedBound13758 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env13759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13777,261,8322,13761,10708,1024,260,4161,477,17,8403,8328,64,10588,5529,12497,10449,1364,477,256,8312,13577,512]

theorem envBound13759 : H12AffineFastState.Bounded env13759 := by
  intro p hp
  have h : env13759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13758_13759 : H12AffineEnvironment.transform 13 13777 env13758 = env13759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13777 env13758 == env13759) = true)

theorem identity13759 : scanCanonicalize (H12AffineFastState.compose env13759 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound13759 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env13760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5237,261,294,5221,2160,1024,260,4161,477,17,375,300,64,2296,5529,4469,2421,1364,477,256,476,5293,512]

theorem envBound13760 : H12AffineFastState.Bounded env13760 := by
  intro p hp
  have h : env13760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13759_13760 : H12AffineEnvironment.transform 12 420 env13759 = env13760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env13759 == env13760) = true)

theorem identity13760 : scanCanonicalize (H12AffineFastState.compose env13760 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13760 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env13761 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,209,5237,112,83,5221,2160,1024,113,4161,168,17,2,89,64,2296,5356,4096,2048,1057,168,117,169,5293,512]

theorem envBound13761 : H12AffineFastState.Bounded env13761 := by
  intro p hp
  have h : env13761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13760_13761 : H12AffineEnvironment.transform 7 117 env13760 = env13761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13760 == env13761) = true)

theorem identity13761 : scanCanonicalize (H12AffineFastState.compose env13761 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound13761 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13762 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,121,5237,112,83,5221,2160,1024,113,4161,0,17,2,89,64,2128,5188,4096,2048,1057,0,117,1,5125,512]

theorem envBound13762 : H12AffineFastState.Bounded env13762 := by
  intro p hp
  have h : env13762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13761_13762 : H12AffineEnvironment.transform 6 40 env13761 = env13762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13761 == env13762) = true)

theorem identity13762 : scanCanonicalize (H12AffineFastState.compose env13762 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13762 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13763 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,81,83,5188,2129,1024,80,4161,0,17,2,89,64,2128,5188,4096,2048,1024,0,84,1,5125,512]

theorem envBound13763 : H12AffineFastState.Bounded env13763 := by
  intro p hp
  have h : env13763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13762_13763 : H12AffineEnvironment.transform 4 1 env13762 = env13763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13762 == env13763) = true)

theorem identity13763 : scanCanonicalize (H12AffineFastState.compose env13763 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound13763 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13764 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1045,4096,88,5204,81,83,5188,1092,1024,80,4161,0,17,2,89,64,1093,5188,4096,1045,1024,0,84,1,5125,512]

theorem envBound13764 : H12AffineFastState.Bounded env13764 := by
  intro p hp
  have h : env13764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13763_13764 : H12AffineEnvironment.transform 10 1045 env13763 = env13764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env13763 == env13764) = true)

theorem identity13764 : scanCanonicalize (H12AffineFastState.compose env13764 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound13764 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env13765 : List Nat := [2,4,8,16,1,64,9,84,512,69,80,4096,88,4113,81,83,4097,1,69,80,4161,0,17,2,89,64,0,4097,4096,80,69,0,84,1,4160,512]

theorem envBound13765 : H12AffineFastState.Bounded env13765 := by
  intro p hp
  have h : env13765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13764_13765 : H12AffineEnvironment.transform 9 69 env13764 = env13765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env13764 == env13765) = true)

theorem identity13765 : scanCanonicalize (H12AffineFastState.compose env13765 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 69) := by decide +kernel

theorem selectedBound13765 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13766 : List Nat := [2,4,8,16,1,64,9,84,512,69,80,69,88,84,81,83,68,1,69,80,4,0,17,2,89,64,0,68,69,80,69,0,84,1,5,512]

theorem envBound13766 : H12AffineFastState.Bounded env13766 := by
  intro p hp
  have h : env13766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13765_13766 : H12AffineEnvironment.transform 11 69 env13765 = env13766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 69 env13765 == env13766) = true)

theorem identity13766 : scanCanonicalize (H12AffineFastState.compose env13766 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound13766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13767 : List Nat := [2,1,8,16,1,64,9,81,512,64,80,64,88,81,81,83,65,1,64,80,1,0,17,2,89,64,0,65,64,80,64,0,81,1,0,512]

theorem envBound13767 : H12AffineFastState.Bounded env13767 := by
  intro p hp
  have h : env13767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13766_13767 : H12AffineEnvironment.transform 1 1 env13766 = env13767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env13766 == env13767) = true)

theorem identity13767 : scanCanonicalize (H12AffineFastState.compose env13767 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13768 : List Nat := [2,1,8,16,1,16,9,1,512,16,0,16,8,1,1,3,17,1,16,0,1,0,17,2,9,16,0,17,16,0,16,0,1,1,0,512]

theorem envBound13768 : H12AffineFastState.Bounded env13768 := by
  intro p hp
  have h : env13768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13767_13768 : H12AffineEnvironment.transform 5 16 env13767 = env13768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13767 == env13768) = true)

def env13769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound13769 : H12AffineFastState.Bounded env13769 := by
  intro p hp
  have h : env13769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13646_13769 : H12AffineEnvironment.transform 18 1025 env13646 = env13769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13646 == env13769) = true)

theorem identity13769 : scanCanonicalize (H12AffineFastState.compose env13769 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213335) := by decide +kernel

theorem selectedBound13769 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213335,16777216,8328,64,21266774,18973837,2298887,360791,16958790,23160257,257,19039739,19031135,17031825]

theorem envBound13770 : H12AffineFastState.Bounded env13770 := by
  intro p hp
  have h : env13770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13769_13770 : H12AffineEnvironment.transform 22 213335 env13769 = env13770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213335 env13769 == env13770) = true)

def env13771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412108,213335,16777216,8328,64,16959642,18973837,2298887,360791,16958790,19344397,257,19039739,19031135,17031825]

theorem envBound13771 : H12AffineFastState.Bounded env13771 := by
  intro p hp
  have h : env13771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13770_13771 : H12AffineEnvironment.transform 21 412108 env13770 = env13771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412108 env13770 == env13771) = true)

def env13772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213335,16777216,8328,64,16959642,16974165,102879,360791,16958790,17148373,257,16777251,16834951,17031825]

theorem envBound13772 : H12AffineFastState.Bounded env13772 := by
  intro p hp
  have h : env13772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13771_13772 : H12AffineEnvironment.transform 20 165336 env13771 = env13772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env13771 == env13772) = true)

theorem identity13772 : scanCanonicalize (H12AffineFastState.compose env13772 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound13772 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env13773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213335,188870,8328,64,10588,123027,102879,360791,9344,477203,257,188901,131137,66391]

theorem envBound13773 : H12AffineFastState.Bounded env13773 := by
  intro p hp
  have h : env13773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13772_13773 : H12AffineEnvironment.transform 23 188870 env13772 = env13773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env13772 == env13773) = true)

def env13774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,318548,120015,29790,8328,64,10588,123027,102879,360791,9344,384395,257,29821,38361,66391]

theorem envBound13774 : H12AffineFastState.Bounded env13774 := by
  intro p hp
  have h : env13774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13773_13774 : H12AffineEnvironment.transform 16 38296 env13773 = env13774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env13773 == env13774) = true)

theorem identity13774 : scanCanonicalize (H12AffineFastState.compose env13774 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound13774 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,38296,262144,1025,32769,4160,318548,8525,29790,8328,64,10588,5393,25693,292053,9344,272393,257,29821,38361,63189]

theorem envBound13775 : H12AffineFastState.Bounded env13775 := by
  intro p hp
  have h : env13775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13774_13775 : H12AffineEnvironment.transform 15 62850 env13774 = env13775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env13774 == env13775) = true)

def env13776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4160,318548,8525,29790,8192,64,10588,5393,25693,291933,9224,272393,257,29821,38225,63069]

theorem envBound13776 : H12AffineFastState.Bounded env13776 := by
  intro p hp
  have h : env13776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13775_13776 : H12AffineEnvironment.transform 6 8 env13775 = env13776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13775 == env13776) = true)

theorem identity13776 : scanCanonicalize (H12AffineFastState.compose env13776 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13776 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env13777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54359,38160,262144,1025,32769,4160,318548,16,21763,349,64,2049,5393,17664,283904,1365,264532,257,21792,38225,55040]

theorem envBound13777 : H12AffineFastState.Bounded env13777 := by
  intro p hp
  have h : env13777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13776_13777 : H12AffineEnvironment.transform 12 349 env13776 = env13777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13776 == env13777) = true)

theorem identity13777 : scanCanonicalize (H12AffineFastState.compose env13777 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13777 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,16401,262144,1025,21760,4160,264533,16,21763,349,64,2049,5393,17664,283904,1365,264532,257,21792,16464,513]

theorem envBound13778 : H12AffineFastState.Bounded env13778 := by
  intro p hp
  have h : env13778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13777_13778 : H12AffineEnvironment.transform 14 21761 env13777 = env13778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13777 == env13778) = true)

theorem identity13778 : scanCanonicalize (H12AffineFastState.compose env13778 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound13778 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,342,16401,23668,1025,21760,4160,21793,16,21763,349,64,2049,5393,17664,2420,1365,21792,257,21792,16464,513]

theorem envBound13779 : H12AffineFastState.Bounded env13779 := by
  intro p hp
  have h : env13779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13778_13779 : H12AffineEnvironment.transform 17 23668 env13778 = env13779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env13778 == env13779) = true)

theorem identity13779 : scanCanonicalize (H12AffineFastState.compose env13779 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3172) := by decide +kernel

theorem selectedBound13779 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env13780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,3172,6501,342,3189,4112,1025,6500,4160,6469,16,6503,349,64,2049,5393,2404,2420,1365,6468,257,6468,3124,513]

theorem envBound13780 : H12AffineFastState.Bounded env13780 := by
  intro p hp
  have h : env13780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13779_13780 : H12AffineEnvironment.transform 13 3172 env13779 = env13780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3172 env13779 == env13780) = true)

theorem identity13780 : scanCanonicalize (H12AffineFastState.compose env13780 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13780 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env13781 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,3172,6161,34,3189,4112,1025,6160,4160,6193,16,6163,41,64,2049,5221,2064,2048,1057,6192,117,6192,3124,513]

theorem envBound13781 : H12AffineFastState.Bounded env13781 := by
  intro p hp
  have h : env13781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13780_13781 : H12AffineEnvironment.transform 7 116 env13780 = env13781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13780 == env13781) = true)

theorem identity13781 : scanCanonicalize (H12AffineFastState.compose env13781 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13781 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env13782 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,3125,6161,34,3108,4112,1025,6160,4113,6193,16,6163,41,17,2049,5172,2064,2048,1057,6192,36,6192,3124,513]

theorem envBound13782 : H12AffineFastState.Bounded env13782 := by
  intro p hp
  have h : env13782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13781_13782 : H12AffineEnvironment.transform 5 17 env13781 = env13782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13781 == env13782) = true)

theorem identity13782 : scanCanonicalize (H12AffineFastState.compose env13782 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound13782 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13783 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,41,3125,1077,34,3108,3124,1025,1076,3125,1045,16,1079,41,17,2049,2064,2064,2048,1057,1044,36,1044,3124,513]

theorem envBound13783 : H12AffineFastState.Bounded env13783 := by
  intro p hp
  have h : env13783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13782_13783 : H12AffineEnvironment.transform 11 3108 env13782 = env13783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env13782 == env13783) = true)

def env13784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4160,318548,8525,29790,8193,64,10588,5393,25693,291932,9225,272393,257,29821,38224,63068]

theorem envBound13784 : H12AffineFastState.Bounded env13784 := by
  intro p hp
  have h : env13784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13775_13784 : H12AffineEnvironment.transform 6 9 env13775 = env13784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13775 == env13784) = true)

theorem identity13784 : scanCanonicalize (H12AffineFastState.compose env13784 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13784 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env13785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24908,262144,1025,29788,4160,272393,8525,29790,8193,64,10588,5393,25693,291932,9225,272393,257,29821,24845,513]

theorem envBound13785 : H12AffineFastState.Bounded env13785 := by
  intro p hp
  have h : env13785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13784_13785 : H12AffineEnvironment.transform 14 29789 env13784 = env13785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13784 == env13785) = true)

theorem identity13785 : scanCanonicalize (H12AffineFastState.compose env13785 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound13785 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24908,11576,1025,29788,4160,1329,8525,29790,8193,64,10588,5393,25693,22884,9225,1329,257,29821,24845,513]

theorem envBound13786 : H12AffineFastState.Bounded env13786 := by
  intro p hp
  have h : env13786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13785_13786 : H12AffineEnvironment.transform 17 11576 env13785 = env13786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env13785 == env13786) = true)

theorem identity13786 : scanCanonicalize (H12AffineFastState.compose env13786 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound13786 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env13787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,342,5392,11576,1025,0,4160,1329,8525,2,8193,64,10588,5393,4097,11576,9225,1329,257,33,5457,513]

theorem envBound13787 : H12AffineFastState.Bounded env13787 := by
  intro p hp
  have h : env13787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13786_13787 : H12AffineEnvironment.transform 13 13404 env13786 = env13787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env13786 == env13787) = true)

theorem identity13787 : scanCanonicalize (H12AffineFastState.compose env13787 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound13787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,1,342,5392,2421,1025,0,4160,1329,1280,2,1100,64,3345,5393,4097,2421,68,1329,257,33,5457,513]

theorem envBound13788 : H12AffineFastState.Bounded env13788 := by
  intro p hp
  have h : env13788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13787_13788 : H12AffineEnvironment.transform 12 1101 env13787 = env13788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env13787 == env13788) = true)

theorem identity13788 : scanCanonicalize (H12AffineFastState.compose env13788 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13788 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13789 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4113,1,342,4096,2421,273,0,4160,33,16,2,348,64,2049,4097,4097,2421,68,33,257,33,4161,513]

theorem envBound13789 : H12AffineFastState.Bounded env13789 := by
  intro p hp
  have h : env13789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13788_13789 : H12AffineEnvironment.transform 9 272 env13788 = env13789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13788 == env13789) = true)

theorem identity13789 : scanCanonicalize (H12AffineFastState.compose env13789 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13790 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4113,1,35,4096,2048,100,0,4160,33,16,2,41,64,2049,4097,4097,2048,68,33,116,33,4161,513]

theorem envBound13790 : H12AffineFastState.Bounded env13790 := by
  intro p hp
  have h : env13790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13789_13790 : H12AffineEnvironment.transform 7 117 env13789 = env13790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13789 == env13790) = true)

theorem identity13790 : scanCanonicalize (H12AffineFastState.compose env13790 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound13790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13791 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,65,40,80,1,35,65,2048,100,0,1,33,16,2,41,64,2049,64,64,2048,68,33,116,33,0,513]

theorem envBound13791 : H12AffineFastState.Bounded env13791 := by
  intro p hp
  have h : env13791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13790_13791 : H12AffineEnvironment.transform 11 65 env13790 = env13791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env13790 == env13791) = true)

theorem identity13791 : scanCanonicalize (H12AffineFastState.compose env13791 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound13791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13792 : List Nat := [2,4,8,16,32,64,9,117,512,101,80,65,40,80,1,35,65,80,100,0,1,33,16,2,41,64,81,64,64,80,68,33,116,33,0,513]

theorem envBound13792 : H12AffineFastState.Bounded env13792 := by
  intro p hp
  have h : env13792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13791_13792 : H12AffineEnvironment.transform 10 80 env13791 = env13792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env13791 == env13792) = true)

theorem identity13792 : scanCanonicalize (H12AffineFastState.compose env13792 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound13792 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13793 : List Nat := [2,4,8,16,10,64,9,95,512,79,80,65,2,80,1,9,65,80,78,0,1,11,16,2,3,64,81,64,64,80,68,11,94,11,0,513]

theorem envBound13793 : H12AffineFastState.Bounded env13793 := by
  intro p hp
  have h : env13793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13792_13793 : H12AffineEnvironment.transform 4 10 env13792 = env13793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env13792 == env13793) = true)

theorem identity13793 : scanCanonicalize (H12AffineFastState.compose env13793 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13793 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13794 : List Nat := [2,4,8,16,10,16,9,15,512,31,0,17,2,0,1,9,17,0,30,0,1,11,16,2,3,16,1,16,16,0,20,11,14,11,0,513]

theorem envBound13794 : H12AffineFastState.Bounded env13794 := by
  intro p hp
  have h : env13794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13793_13794 : H12AffineEnvironment.transform 5 16 env13793 = env13794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13793 == env13794) = true)

def env13795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,318549,120014,29791,8328,64,10588,123027,102879,360791,9344,384394,257,29820,38360,66391]

theorem envBound13795 : H12AffineFastState.Bounded env13795 := by
  intro p hp
  have h : env13795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13773_13795 : H12AffineEnvironment.transform 16 38297 env13773 = env13795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env13773 == env13795) = true)

theorem identity13795 : scanCanonicalize (H12AffineFastState.compose env13795 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound13795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,262144,1025,29908,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29820,24845,66391]

theorem envBound13796 : H12AffineFastState.Bounded env13796 := by
  intro p hp
  have h : env13796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13795_13796 : H12AffineEnvironment.transform 14 29909 env13795 = env13796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env13795 == env13796) = true)

def env13797 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,262144,1025,29908,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29788,24845,66391]

theorem envBound13797 : H12AffineFastState.Bounded env13797 := by
  intro p hp
  have h : env13797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13796_13797 : H12AffineEnvironment.transform 4 0 env13796 = env13797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13796 == env13797) = true)

theorem identity13797 : scanCanonicalize (H12AffineFastState.compose env13797 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 10368) := by decide +kernel

theorem selectedBound13797 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env13798 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,10368,1025,29908,4161,0,73755,29791,8328,64,10588,70726,91402,89346,9344,66015,257,29788,24845,66391]

theorem envBound13798 : H12AffineFastState.Bounded env13798 := by
  intro p hp
  have h : env13798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13797_13798 : H12AffineEnvironment.transform 17 10368 env13797 = env13798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10368 env13797 == env13798) = true)

theorem identity13798 : scanCanonicalize (H12AffineFastState.compose env13798 (packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound13798 : packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env13799 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,478,24908,10368,1025,29908,4161,0,8645,29791,8328,64,10588,5528,25812,23772,9344,1,257,29788,24845,649]

theorem envBound13799 : H12AffineFastState.Bounded env13799 := by
  intro p hp
  have h : env13799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13798_13799 : H12AffineEnvironment.transform 15 478 env13798 = env13799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env13798 == env13799) = true)

theorem identity13799 : scanCanonicalize (H12AffineFastState.compose env13799 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13799 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env13800 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,5376,8661,478,13388,10368,1025,8660,4161,0,8645,8543,8328,64,10588,5528,12756,2524,9344,1,257,8540,13325,649]

theorem envBound13800 : H12AffineFastState.Bounded env13800 := by
  intro p hp
  have h : env13800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13799_13800 : H12AffineEnvironment.transform 13 5376 env13799 = env13800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13799 == env13800) = true)

theorem identity13800 : scanCanonicalize (H12AffineFastState.compose env13800 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13800 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13801 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,349,5376,136,478,5393,2525,1025,137,4161,0,152,2,469,64,2049,5528,4233,2524,1501,1,257,1,5456,649]

theorem envBound13801 : H12AffineFastState.Bounded env13801 := by
  intro p hp
  have h : env13801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13800_13801 : H12AffineEnvironment.transform 12 349 env13800 = env13801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13800 == env13801) = true)

theorem identity13801 : scanCanonicalize (H12AffineFastState.compose env13801 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound13801 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13802 : List Nat := [2,4,8,16,0,64,128,256,512,205,2048,4096,349,4557,136,478,4572,2525,204,137,4161,0,152,2,469,64,2049,4437,4233,2524,272,1,257,1,4509,649]

theorem envBound13802 : H12AffineFastState.Bounded env13802 := by
  intro p hp
  have h : env13802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13801_13802 : H12AffineEnvironment.transform 9 205 env13801 = env13802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env13801 == env13802) = true)

theorem identity13802 : scanCanonicalize (H12AffineFastState.compose env13802 (packedSelected [0,1,3,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2461) := by decide +kernel

theorem selectedBound13802 : packedSelected [0,1,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env13803 : List Nat := [2,4,8,16,0,64,128,256,512,205,2048,2461,349,2128,136,478,2113,2525,204,137,2524,0,152,2,469,64,2049,2248,2324,2524,272,1,257,1,2048,649]

theorem envBound13803 : H12AffineFastState.Bounded env13803 := by
  intro p hp
  have h : env13803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13802_13803 : H12AffineEnvironment.transform 11 2461 env13802 = env13803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2461 env13802 == env13803) = true)

theorem identity13803 : scanCanonicalize (H12AffineFastState.compose env13803 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13803 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0