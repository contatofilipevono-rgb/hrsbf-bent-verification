import H12CloudChart0Data108

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity27621 : scanCanonicalize (H12AffineFastState.compose env27621 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound27621 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env27622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,23669,1024,32769,151633,29821,177244,21762,8192,65,10589,172380,45405,10280,148804,144493,256,21792,46092,147985]

theorem envBound27622 : H12AffineFastState.Bounded env27622 := by
  intro p hp
  have h : env27622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27621_27622 : H12AffineEnvironment.transform 17 23669 env27621 = env27622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env27621 == env27622) = true)

theorem identity27622 : scanCanonicalize (H12AffineFastState.compose env27622 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound27622 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env27623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,131072,23669,1024,21760,151633,29821,155997,21762,8192,65,10589,160861,25692,10280,148804,144493,256,21792,24845,147985]

theorem envBound27623 : H12AffineFastState.Bounded env27623 := by
  intro p hp
  have h : env27623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27622_27623 : H12AffineEnvironment.transform 14 21761 env27622 = env27623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env27622 == env27623) = true)

def env27624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396325,272393,452649,21762,8193,65,292137,458025,45404,10280,399665,144492,256,21792,46093,400997]

theorem envBound27624 : H12AffineFastState.Bounded env27624 := by
  intro p hp
  have h : env27624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27620_27624 : H12AffineEnvironment.transform 6 9 env27620 = env27624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27620 == env27624) = true)

theorem identity27624 : scanCanonicalize (H12AffineFastState.compose env27624 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 182337) := by decide +kernel

theorem selectedBound27624 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env27625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182337,1024,32769,50276,188488,8296,21762,8193,65,179560,13672,45404,10280,53616,144492,256,21792,46093,54820]

theorem envBound27625 : H12AffineFastState.Bounded env27625 := by
  intro p hp
  have h : env27625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27624_27625 : H12AffineEnvironment.transform 17 182337 env27624 = env27625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182337 env27624 == env27625) = true)

theorem identity27625 : scanCanonicalize (H12AffineFastState.compose env27625 (packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound27625 : packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env27626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8202,131072,149520,1024,80,17461,155673,8296,21762,8193,65,146745,13672,12557,10280,20769,144492,256,21792,13404,22133]

theorem envBound27626 : H12AffineFastState.Bounded env27626 := by
  intro p hp
  have h : env27626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27625_27626 : H12AffineEnvironment.transform 14 81 env27625 = env27626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env27625 == env27626) = true)

theorem identity27626 : scanCanonicalize (H12AffineFastState.compose env27626 (packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound27626 : packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,81,8202,131072,146792,1024,80,12621,136545,8296,8314,8193,65,146745,13672,12557,10280,9305,144492,256,8280,13404,8973]

theorem envBound27627 : H12AffineFastState.Bounded env27627 := by
  intro p hp
  have h : env27627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27626_27627 : H12AffineEnvironment.transform 13 13688 env27626 = env27627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env27626 == env27627) = true)

theorem identity27627 : scanCanonicalize (H12AffineFastState.compose env27627 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound27627 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,81,115,131072,138513,1024,80,4404,136545,17,3,120,65,138560,5393,4468,2129,1056,136213,256,33,5157,884]

theorem envBound27628 : H12AffineFastState.Bounded env27628 := by
  intro p hp
  have h : env27628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27627_27628 : H12AffineEnvironment.transform 12 121 env27627 = env27628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env27627 == env27628) = true)

theorem identity27628 : scanCanonicalize (H12AffineFastState.compose env27628 (packedSelected [0,1,4,6,7,8,9,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound27628 : packedSelected [0,1,4,6,7,8,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env27629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,121,5377,81,115,131072,135541,1024,80,4404,136545,17,3,120,65,135460,5393,4468,1077,1056,136213,256,33,5157,884]

theorem envBound27629 : H12AffineFastState.Bounded env27629 := by
  intro p hp
  have h : env27629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27628_27629 : H12AffineEnvironment.transform 10 1124 env27628 = env27629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env27628 == env27629) = true)

theorem identity27629 : scanCanonicalize (H12AffineFastState.compose env27629 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound27629 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env27630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,121,5377,81,115,4469,0,1024,80,4404,1044,17,3,120,65,81,5393,4468,1077,1056,1376,256,33,5157,884]

theorem envBound27630 : H12AffineFastState.Bounded env27630 := by
  intro p hp
  have h : env27630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27629_27630 : H12AffineEnvironment.transform 16 4469 env27629 = env27630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env27629 == env27630) = true)

theorem identity27630 : scanCanonicalize (H12AffineFastState.compose env27630 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27630 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27631 : List Nat := [2,4,8,16,32,64,9,256,512,272,372,4096,121,4113,81,115,4469,0,272,80,4404,260,17,3,120,65,81,4097,4468,293,304,112,256,33,4405,884]

theorem envBound27631 : H12AffineFastState.Bounded env27631 := by
  intro p hp
  have h : env27631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27630_27631 : H12AffineEnvironment.transform 9 272 env27630 = env27631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27630 == env27631) = true)

theorem identity27631 : scanCanonicalize (H12AffineFastState.compose env27631 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27631 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27632 : List Nat := [2,4,8,16,32,0,9,256,512,272,308,4096,57,4113,17,51,4405,0,272,16,4404,260,17,3,56,1,17,4097,4404,293,304,48,256,33,4405,820]

theorem envBound27632 : H12AffineFastState.Bounded env27632 := by
  intro p hp
  have h : env27632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27631_27632 : H12AffineEnvironment.transform 5 0 env27631 = env27632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27631 == env27632) = true)

theorem identity27632 : scanCanonicalize (H12AffineFastState.compose env27632 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound27632 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env27633 : List Nat := [2,4,8,16,32,0,9,256,512,272,308,528,57,513,17,51,805,0,272,16,804,260,17,3,56,1,17,529,804,293,304,48,256,33,805,820]

theorem envBound27633 : H12AffineFastState.Bounded env27633 := by
  intro p hp
  have h : env27633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27632_27633 : H12AffineEnvironment.transform 11 528 env27632 = env27633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env27632 == env27633) = true)

theorem identity27633 : scanCanonicalize (H12AffineFastState.compose env27633 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27633 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27634 : List Nat := [2,4,8,16,32,0,9,256,0,272,308,16,57,1,17,51,293,0,272,16,292,260,17,3,56,1,17,17,292,293,304,48,256,33,293,308]

theorem envBound27634 : H12AffineFastState.Bounded env27634 := by
  intro p hp
  have h : env27634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27633_27634 : H12AffineEnvironment.transform 8 0 env27633 = env27634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27633 == env27634) = true)

theorem identity27634 : scanCanonicalize (H12AffineFastState.compose env27634 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27634 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env27635 : List Nat := [2,4,8,16,32,0,9,36,0,52,16,16,57,1,17,51,1,0,52,16,0,32,17,3,56,1,17,17,0,1,20,48,36,33,1,16]

theorem envBound27635 : H12AffineFastState.Bounded env27635 := by
  intro p hp
  have h : env27635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27634_27635 : H12AffineEnvironment.transform 7 36 env27634 = env27635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27634 == env27635) = true)

def env27636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452649,95496,8328,65,292257,458025,45525,10280,399665,144612,256,21792,46212,474854]

theorem envBound27636 : H12AffineFastState.Bounded env27636 := by
  intro p hp
  have h : env27636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27618_27636 : H12AffineEnvironment.transform 21 272513 env27618 = env27636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27618 == env27636) = true)

theorem identity27636 : scanCanonicalize (H12AffineFastState.compose env27636 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound27636 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115871,254130,73754,95496,8328,65,245138,79130,45525,10280,119042,144612,256,21792,46212,63189]

theorem envBound27637 : H12AffineFastState.Bounded env27637 := by
  intro p hp
  have h : env27637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27636_27637 : H12AffineEnvironment.transform 17 247859 env27636 = env27637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env27636 == env27637) = true)

def env27638 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115871,254130,73754,95496,8328,17,245138,79130,45445,10280,119042,144564,256,21792,46212,63109]

theorem envBound27638 : H12AffineFastState.Bounded env27638 := by
  intro p hp
  have h : env27638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27637_27638 : H12AffineEnvironment.transform 5 16 env27637 = env27638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27637 == env27638) = true)

theorem identity27638 : scanCanonicalize (H12AffineFastState.compose env27638 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound27638 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27639 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57629,76078,1024,32769,115871,65967,73754,95496,8328,17,89231,79130,45445,10280,119042,54697,256,21792,46212,63109]

theorem envBound27639 : H12AffineFastState.Bounded env27639 := by
  intro p hp
  have h : env27639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27638_27639 : H12AffineEnvironment.transform 16 57629 env27638 = env27639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env27638 == env27639) = true)

theorem identity27639 : scanCanonicalize (H12AffineFastState.compose env27639 (packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27639 : packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27640 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,57629,76078,1024,32769,115735,65831,73754,95496,8192,17,89095,79130,45325,10280,119042,54561,256,21792,46092,62989]

theorem envBound27640 : H12AffineFastState.Bounded env27640 := by
  intro p hp
  have h : env27640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27639_27640 : H12AffineEnvironment.transform 6 8 env27639 = env27640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27639 == env27640) = true)

def env27641 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115871,254130,73754,95496,8328,16,245138,79130,45444,10280,119042,144565,256,21792,46212,63108]

theorem envBound27641 : H12AffineFastState.Bounded env27641 := by
  intro p hp
  have h : env27641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27637_27641 : H12AffineEnvironment.transform 5 17 env27637 = env27641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27637 == env27641) = true)

theorem identity27641 : scanCanonicalize (H12AffineFastState.compose env27641 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound27641 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79131,64808,1024,32769,115871,54697,73754,95496,8328,16,34953,79130,45444,10280,119042,65966,256,21792,46212,63108]

theorem envBound27642 : H12AffineFastState.Bounded env27642 := by
  intro p hp
  have h : env27642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27641_27642 : H12AffineEnvironment.transform 16 79131 env27641 = env27642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env27641 == env27642) = true)

theorem identity27642 : scanCanonicalize (H12AffineFastState.compose env27642 (packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound27642 : packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS < 2^1333 := by decide +kernel

def env27643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,57749,64808,1024,32769,4113,54697,62612,41350,8328,16,34953,57748,45444,10280,1420,54560,256,21792,46212,63108]

theorem envBound27643 : H12AffineFastState.Bounded env27643 := by
  intro p hp
  have h : env27643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27642_27643 : H12AffineEnvironment.transform 15 54414 env27642 = env27643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env27642 == env27643) = true)

theorem identity27643 : scanCanonicalize (H12AffineFastState.compose env27643 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound27643 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env27644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,5392,2477,1024,29828,4113,8492,17,21763,8328,16,31756,5393,17665,10280,1420,8613,256,21792,16385,513]

theorem envBound27644 : H12AffineFastState.Bounded env27644 := by
  intro p hp
  have h : env27644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27643_27644 : H12AffineEnvironment.transform 14 29829 env27643 = env27644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env27643 == env27644) = true)

theorem identity27644 : scanCanonicalize (H12AffineFastState.compose env27644 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27644 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27645 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,8203,5392,2477,1024,8580,4113,8492,17,3,8328,16,10508,5393,4097,10280,1420,8613,256,32,5377,513]

theorem envBound27645 : H12AffineFastState.Bounded env27645 := by
  intro p hp
  have h : env27645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27644_27645 : H12AffineEnvironment.transform 13 5376 env27644 = env27645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27644 == env27645) = true)

theorem identity27645 : scanCanonicalize (H12AffineFastState.compose env27645 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27645 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,398,5392,2477,1024,1,4113,169,17,3,269,16,2185,5393,4097,2477,1420,32,256,32,5377,513]

theorem envBound27646 : H12AffineFastState.Bounded env27646 := by
  intro p hp
  have h : env27646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27645_27646 : H12AffineEnvironment.transform 12 389 env27645 = env27646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27645 == env27646) = true)

theorem identity27646 : scanCanonicalize (H12AffineFastState.compose env27646 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound27646 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27647 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,389,2185,0,398,2201,2477,1024,1,3480,169,17,3,269,16,2185,2200,3464,2477,1420,32,256,32,2184,513]

theorem envBound27647 : H12AffineFastState.Bounded env27647 := by
  intro p hp
  have h : env27647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27646_27647 : H12AffineEnvironment.transform 11 3465 env27646 = env27647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env27646 == env27647) = true)

theorem identity27647 : scanCanonicalize (H12AffineFastState.compose env27647 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound27647 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27648 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1061,389,293,0,398,309,1,1024,1,1076,169,17,3,269,16,293,308,1060,1,1420,32,256,32,292,513]

theorem envBound27648 : H12AffineFastState.Bounded env27648 := by
  intro p hp
  have h : env27648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27647_27648 : H12AffineEnvironment.transform 10 428 env27647 = env27648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env27647 == env27648) = true)

theorem identity27648 : scanCanonicalize (H12AffineFastState.compose env27648 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound27648 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27649 : List Nat := [2,4,8,16,32,17,128,256,512,188,428,153,389,293,0,398,309,1,188,1,136,169,17,3,269,16,293,308,152,1,304,32,256,32,292,513]

theorem envBound27649 : H12AffineFastState.Bounded env27649 := by
  intro p hp
  have h : env27649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27648_27649 : H12AffineEnvironment.transform 9 188 env27648 = env27649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env27648 == env27649) = true)

theorem identity27649 : scanCanonicalize (H12AffineFastState.compose env27649 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27649 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27650 : List Nat := [2,4,8,16,32,17,9,256,512,53,293,16,268,293,0,263,309,1,53,1,1,32,17,3,269,16,293,308,17,1,304,32,256,32,292,513]

theorem envBound27650 : H12AffineFastState.Bounded env27650 := by
  intro p hp
  have h : env27650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27649_27650 : H12AffineEnvironment.transform 6 9 env27649 = env27650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27649 == env27650) = true)

def env27651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound27651 : H12AffineFastState.Bounded env27651 := by
  intro p hp
  have h : env27651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27458_27651 : H12AffineEnvironment.transform 18 1025 env27458 = env27651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env27458 == env27651) = true)

theorem identity27651 : scanCanonicalize (H12AffineFastState.compose env27651 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10873900) := by decide +kernel

theorem selectedBound27651 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10873900,8328,65,6433836,8677536,10507600,8830976,2385980,12880365,257,272512,313637,2445290]

theorem envBound27652 : H12AffineFastState.Bounded env27652 := by
  intro p hp
  have h : env27652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27651_27652 : H12AffineEnvironment.transform 23 10873900 env27651 = env27652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10873900 env27651 == env27652) = true)

def env27653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433836,8393984,10507600,8568224,2102684,12645453,257,21792,46213,2175562]

theorem envBound27653 : H12AffineFastState.Bounded env27653 := by
  intro p hp
  have h : env27653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27652_27653 : H12AffineEnvironment.transform 17 32160 env27652 = env27653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env27652 == env27653) = true)

def env27654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101328,98780,8328,65,6433836,2098512,17664,2272752,2102684,6349853,257,21792,46213,2175562]

theorem envBound27654 : H12AffineFastState.Bounded env27654 := by
  intro p hp
  have h : env27654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27653_27654 : H12AffineEnvironment.transform 22 2101328 env27653 = env27654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env27653 == env27654) = true)

def env27655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,16,98780,8328,65,4340844,5392,17664,179632,1500,4256861,257,21792,46213,74250]

theorem envBound27655 : H12AffineFastState.Bounded env27655 := by
  intro p hp
  have h : env27655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27654_27655 : H12AffineEnvironment.transform 20 4160 env27654 = env27655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27654 == env27655) = true)

theorem identity27655 : scanCanonicalize (H12AffineFastState.compose env27655 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound27655 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21793,16,98780,8328,65,158029,5392,17664,179632,1500,41340,257,21792,46213,74250]

theorem envBound27656 : H12AffineFastState.Bounded env27656 := by
  intro p hp
  have h : env27656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27655_27656 : H12AffineEnvironment.transform 21 21793 env27655 = env27656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env27655 == env27656) = true)

theorem identity27656 : scanCanonicalize (H12AffineFastState.compose env27656 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27656 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1025,32769,4160,21793,16,41431,8328,65,158029,5392,17664,179632,1500,41340,257,21792,46213,513]

theorem envBound27657 : H12AffineFastState.Bounded env27657 := by
  intro p hp
  have h : env27657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27656_27657 : H12AffineEnvironment.transform 15 8203 env27656 = env27657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27656 == env27657) = true)

theorem identity27657 : scanCanonicalize (H12AffineFastState.compose env27657 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27657 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,32160,1025,32769,4160,21793,16,41431,8328,65,10589,5392,17664,64928,1500,41340,257,21792,46213,513]

theorem envBound27658 : H12AffineFastState.Bounded env27658 := by
  intro p hp
  have h : env27658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27657_27658 : H12AffineEnvironment.transform 16 16400 env27657 = env27658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27657 == env27658) = true)

theorem identity27658 : scanCanonicalize (H12AffineFastState.compose env27658 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound27658 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env27659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,8203,16400,32160,1025,216,4160,21793,16,8462,8328,65,10589,5392,17664,32121,1500,8613,257,21792,13404,513]

theorem envBound27659 : H12AffineFastState.Bounded env27659 := by
  intro p hp
  have h : env27659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27658_27659 : H12AffineEnvironment.transform 14 217 env27658 = env27659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env27658 == env27659) = true)

def env27660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,17,98780,8328,65,4340845,5393,17664,179633,1501,4256860,257,21792,46213,74251]

theorem envBound27660 : H12AffineFastState.Bounded env27660 := by
  intro p hp
  have h : env27660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27654_27660 : H12AffineEnvironment.transform 20 4161 env27654 = env27660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27654 == env27660) = true)

def env27661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98644,8192,65,4340845,5393,17664,179513,1365,4256860,257,21792,46093,74251]

theorem envBound27661 : H12AffineFastState.Bounded env27661 := by
  intro p hp
  have h : env27661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27660_27661 : H12AffineEnvironment.transform 6 8 env27660 = env27661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27660 == env27661) = true)

theorem identity27661 : scanCanonicalize (H12AffineFastState.compose env27661 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound27661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,32040,1025,32769,4161,4194304,17,2,8192,65,4340845,5393,17664,179513,1365,4256860,257,21792,46093,41821]

theorem envBound27662 : H12AffineFastState.Bounded env27662 := by
  intro p hp
  have h : env27662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27661_27662 : H12AffineEnvironment.transform 15 33110 env27661 = env27662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env27661 == env27662) = true)

theorem identity27662 : scanCanonicalize (H12AffineFastState.compose env27662 (packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27662 : packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env27663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16401,32040,1025,32769,4161,4194304,17,2,8192,65,4226172,5393,17664,64808,1365,4256860,257,21792,46093,41821]

theorem envBound27663 : H12AffineFastState.Bounded env27663 := by
  intro p hp
  have h : env27663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27662_27663 : H12AffineEnvironment.transform 16 16401 env27662 = env27663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27662 == env27663) = true)

theorem identity27663 : scanCanonicalize (H12AffineFastState.compose env27663 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27663 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,32040,1025,8541,4161,4194304,17,2,8192,65,4226172,5393,17664,23668,1365,4216064,257,21792,5457,513]

theorem envBound27664 : H12AffineFastState.Bounded env27664 := by
  intro p hp
  have h : env27664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27663_27664 : H12AffineEnvironment.transform 14 8540 env27663 = env27664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27663 == env27664) = true)

theorem identity27664 : scanCanonicalize (H12AffineFastState.compose env27664 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27664 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27665 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,8202,16401,30777,272,8541,4161,4194304,17,2,8192,65,4225389,4096,16401,22885,68,4214801,257,20529,4160,513]

theorem envBound27665 : H12AffineFastState.Bounded env27665 := by
  intro p hp
  have h : env27665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27664_27665 : H12AffineEnvironment.transform 9 273 env27664 = env27665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27664 == env27665) = true)

theorem identity27665 : scanCanonicalize (H12AffineFastState.compose env27665 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound27665 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27666 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8202,4096,10280,272,8541,4161,4194304,17,2,8192,65,4204924,4096,4096,2420,68,4194304,257,32,4160,513]

theorem envBound27666 : H12AffineFastState.Bounded env27666 := by
  intro p hp
  have h : env27666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27665_27666 : H12AffineEnvironment.transform 13 4113 env27665 = env27666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env27665 == env27666) = true)

theorem identity27666 : scanCanonicalize (H12AffineFastState.compose env27666 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound27666 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27667 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8202,4096,10280,272,8541,4161,113,17,2,8192,65,10509,4096,4096,2420,68,113,257,32,4160,513]

theorem envBound27667 : H12AffineFastState.Bounded env27667 := by
  intro p hp
  have h : env27667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27666_27667 : H12AffineEnvironment.transform 21 113 env27666 = env27667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env27666 == env27667) = true)

theorem identity27667 : scanCanonicalize (H12AffineFastState.compose env27667 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound27667 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27668 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,65,8192,80,8540,8202,65,10280,272,8541,0,113,17,2,8192,65,10509,65,65,2420,68,113,257,32,1,513]

theorem envBound27668 : H12AffineFastState.Bounded env27668 := by
  intro p hp
  have h : env27668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27667_27668 : H12AffineEnvironment.transform 11 65 env27667 = env27668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env27667 == env27668) = true)

theorem identity27668 : scanCanonicalize (H12AffineFastState.compose env27668 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27668 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27669 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,65,8192,80,8312,8202,65,10280,52,8313,0,113,17,2,8192,65,10281,65,65,2128,68,113,37,32,1,513]

theorem envBound27669 : H12AffineFastState.Bounded env27669 := by
  intro p hp
  have h : env27669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27668_27669 : H12AffineEnvironment.transform 7 36 env27668 = env27669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27668 == env27669) = true)

theorem identity27669 : scanCanonicalize (H12AffineFastState.compose env27669 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound27669 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27670 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,65,8192,80,8312,8202,65,8201,52,8313,0,113,17,2,8192,65,8200,65,65,113,68,113,37,32,1,513]

theorem envBound27670 : H12AffineFastState.Bounded env27670 := by
  intro p hp
  have h : env27670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27669_27670 : H12AffineEnvironment.transform 10 33 env27669 = env27670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env27669 == env27670) = true)

theorem identity27670 : scanCanonicalize (H12AffineFastState.compose env27670 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound27670 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27671 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,65,520,80,624,514,65,513,52,625,0,113,17,2,520,65,512,65,65,113,68,113,37,32,1,513]

theorem envBound27671 : H12AffineFastState.Bounded env27671 := by
  intro p hp
  have h : env27671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27670_27671 : H12AffineEnvironment.transform 12 520 env27670 = env27671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env27670 == env27671) = true)

theorem identity27671 : scanCanonicalize (H12AffineFastState.compose env27671 (packedSelected [1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound27671 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env27672 : List Nat := [2,4,8,16,32,64,8,36,113,53,33,65,121,80,1,115,65,112,52,0,0,113,17,2,121,65,113,65,65,113,68,113,37,32,1,112]

theorem envBound27672 : H12AffineFastState.Bounded env27672 := by
  intro p hp
  have h : env27672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27671_27672 : H12AffineEnvironment.transform 8 113 env27671 = env27672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env27671 == env27672) = true)

theorem identity27672 : scanCanonicalize (H12AffineFastState.compose env27672 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27672 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27673 : List Nat := [2,4,8,16,1,64,8,5,80,20,0,65,88,80,1,82,65,81,21,0,0,80,17,2,88,65,80,65,65,80,68,80,4,1,1,81]

theorem envBound27673 : H12AffineFastState.Bounded env27673 := by
  intro p hp
  have h : env27673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27672_27673 : H12AffineEnvironment.transform 4 1 env27672 = env27673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27672 == env27673) = true)

def env27674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98645,8193,65,4340845,5393,17664,179512,1364,4256860,257,21792,46092,74251]

theorem envBound27674 : H12AffineFastState.Bounded env27674 := by
  intro p hp
  have h : env27674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27660_27674 : H12AffineEnvironment.transform 6 9 env27660 = env27674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27660 == env27674) = true)

theorem identity27674 : scanCanonicalize (H12AffineFastState.compose env27674 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4161,4194304,17,41311,8193,65,4340845,5393,17664,179512,1364,4256860,257,21792,46092,513]

theorem envBound27675 : H12AffineFastState.Bounded env27675 := by
  intro p hp
  have h : env27675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27674_27675 : H12AffineEnvironment.transform 15 8202 env27674 = env27675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27674 == env27675) = true)

theorem identity27675 : scanCanonicalize (H12AffineFastState.compose env27675 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27675 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env27676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4161,4194304,17,21762,8193,65,4340845,5393,17664,149861,1364,4194305,257,21792,16465,513]

theorem envBound27676 : H12AffineFastState.Bounded env27676 := by
  intro p hp
  have h : env27676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27675_27676 : H12AffineEnvironment.transform 14 29789 env27675 = env27676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27675 == env27676) = true)

theorem identity27676 : scanCanonicalize (H12AffineFastState.compose env27676 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound27676 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env27677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4161,21873,17,21762,8193,65,157980,5393,17664,149861,1364,21872,257,21792,16465,513]

theorem envBound27677 : H12AffineFastState.Bounded env27677 := by
  intro p hp
  have h : env27677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27676_27677 : H12AffineEnvironment.transform 21 21873 env27676 = env27677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env27676 == env27677) = true)

theorem identity27677 : scanCanonicalize (H12AffineFastState.compose env27677 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound27677 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env27678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,5393,32041,1025,29788,4161,21873,17,21762,8193,65,31757,5393,17664,23668,1364,21872,257,21792,16465,513]

theorem envBound27678 : H12AffineFastState.Bounded env27678 := by
  intro p hp
  have h : env27678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27677_27678 : H12AffineEnvironment.transform 16 5393 env27677 = env27678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env27677 == env27678) = true)

theorem identity27678 : scanCanonicalize (H12AffineFastState.compose env27678 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27678 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,5393,23669,1025,21760,4161,21873,17,21762,349,65,23889,5393,17664,23668,1364,21872,257,21792,16465,513]

theorem envBound27679 : H12AffineFastState.Bounded env27679 := by
  intro p hp
  have h : env27679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27678_27679 : H12AffineEnvironment.transform 12 348 env27678 = env27679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27678 == env27679) = true)

theorem identity27679 : scanCanonicalize (H12AffineFastState.compose env27679 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27679 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,80,342,5393,2340,1025,81,4161,32,17,83,349,65,2048,5393,4177,2341,1364,33,257,113,5376,513]

theorem envBound27680 : H12AffineFastState.Bounded env27680 := by
  intro p hp
  have h : env27680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27679_27680 : H12AffineEnvironment.transform 13 5457 env27679 = env27680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env27679 == env27680) = true)

theorem identity27680 : scanCanonicalize (H12AffineFastState.compose env27680 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound27680 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env27681 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4112,80,342,4176,2340,320,81,4161,32,17,83,349,65,2048,4176,4177,2341,21,33,257,113,4161,513]

theorem envBound27681 : H12AffineFastState.Bounded env27681 := by
  intro p hp
  have h : env27681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27680_27681 : H12AffineEnvironment.transform 9 321 env27680 = env27681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27680 == env27681) = true)

theorem identity27681 : scanCanonicalize (H12AffineFastState.compose env27681 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27681 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27682 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,4112,1,263,4097,2340,273,0,4112,32,17,2,268,16,2048,4097,4096,2341,21,33,257,32,4112,513]

theorem envBound27682 : H12AffineFastState.Bounded env27682 := by
  intro p hp
  have h : env27682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27681_27682 : H12AffineEnvironment.transform 5 17 env27681 = env27682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27681 == env27682) = true)

theorem identity27682 : scanCanonicalize (H12AffineFastState.compose env27682 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound27682 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27683 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,16,269,0,1,263,17,2340,273,0,0,32,17,2,268,16,2048,17,16,2341,21,33,257,32,0,513]

theorem envBound27683 : H12AffineFastState.Bounded env27683 := by
  intro p hp
  have h : env27683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27682_27683 : H12AffineEnvironment.transform 11 16 env27682 = env27683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27682 == env27683) = true)

theorem identity27683 : scanCanonicalize (H12AffineFastState.compose env27683 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound27683 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27684 : List Nat := [2,4,8,16,32,17,9,256,512,272,292,16,269,0,1,263,17,0,273,0,0,32,17,2,268,16,292,17,16,1,21,33,257,32,0,513]

theorem envBound27684 : H12AffineFastState.Bounded env27684 := by
  intro p hp
  have h : env27684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27683_27684 : H12AffineEnvironment.transform 10 292 env27683 = env27684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env27683 == env27684) = true)

def env27685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101329,98781,8328,65,6433836,2098513,17665,2272753,2102684,6349852,257,21792,46213,2175562]

theorem envBound27685 : H12AffineFastState.Bounded env27685 := by
  intro p hp
  have h : env27685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27653_27685 : H12AffineEnvironment.transform 22 2101329 env27653 = env27685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env27653 == env27685) = true)

def env27686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,17,98781,8328,65,4340844,5393,17665,179633,1500,4256860,257,21792,46213,74250]

theorem envBound27686 : H12AffineFastState.Bounded env27686 := by
  intro p hp
  have h : env27686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27685_27686 : H12AffineEnvironment.transform 20 4160 env27685 = env27686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27685 == env27686) = true)

theorem identity27686 : scanCanonicalize (H12AffineFastState.compose env27686 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound27686 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32160,1025,29909,4160,4194304,17,95497,8328,65,4340844,5393,17665,149861,1500,4194440,257,21792,16465,74250]

theorem envBound27687 : H12AffineFastState.Bounded env27687 := by
  intro p hp
  have h : env27687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27686_27687 : H12AffineEnvironment.transform 14 29908 env27686 = env27687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env27686 == env27687) = true)

def env27688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,4160,4194304,17,73737,8328,65,4340844,5393,4097,138341,1500,4194440,257,32,5457,74250]

theorem envBound27688 : H12AffineFastState.Bounded env27688 := by
  intro p hp
  have h : env27688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27687_27688 : H12AffineEnvironment.transform 13 5376 env27687 = env27688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27687 == env27688) = true)

theorem identity27688 : scanCanonicalize (H12AffineFastState.compose env27688 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27688 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,131072,10400,1025,8661,4160,4194304,17,2,8328,65,4340844,5393,4097,138341,1500,4194440,257,32,5457,513]

theorem envBound27689 : H12AffineFastState.Bounded env27689 := by
  intro p hp
  have h : env27689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27688_27689 : H12AffineEnvironment.transform 15 8203 env27688 = env27689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27688 == env27689) = true)

theorem identity27689 : scanCanonicalize (H12AffineFastState.compose env27689 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound27689 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,5392,10400,1025,8661,4160,4194304,17,2,8328,65,4204924,5393,4097,2421,1500,4194440,257,32,5457,513]

theorem envBound27690 : H12AffineFastState.Bounded env27690 := by
  intro p hp
  have h : env27690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27689_27690 : H12AffineEnvironment.transform 16 5392 env27689 = env27690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env27689 == env27690) = true)

theorem identity27690 : scanCanonicalize (H12AffineFastState.compose env27690 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(21+1) ^^^ 15484) := by decide +kernel

theorem selectedBound27690 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,5392,10400,1025,8661,4160,15484,17,2,8328,65,5376,5393,4097,2421,1500,15604,257,32,5457,513]

theorem envBound27691 : H12AffineFastState.Bounded env27691 := by
  intro p hp
  have h : env27691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27690_27691 : H12AffineEnvironment.transform 21 15484 env27690 = env27691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 15484 env27690 == env27691) = true)

theorem identity27691 : scanCanonicalize (H12AffineFastState.compose env27691 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27691 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27692 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4112,8660,8203,4096,10400,273,8661,4160,14700,17,2,8328,65,4112,4097,4097,2421,204,14820,257,32,4161,513]

theorem envBound27692 : H12AffineFastState.Bounded env27692 := by
  intro p hp
  have h : env27692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27691_27692 : H12AffineEnvironment.transform 9 272 env27691 = env27692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27691 == env27692) = true)

theorem identity27692 : scanCanonicalize (H12AffineFastState.compose env27692 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound27692 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env27693 : List Nat := [2,4,8,16,32,64,128,100,512,116,2048,4096,8192,4112,8368,8203,4096,10400,117,8369,4160,14344,17,2,8328,65,4112,4097,4097,2065,204,14464,101,32,4161,513]

theorem envBound27693 : H12AffineFastState.Bounded env27693 := by
  intro p hp
  have h : env27693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27692_27693 : H12AffineEnvironment.transform 7 100 env27692 = env27693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env27692 == env27693) = true)

theorem identity27693 : scanCanonicalize (H12AffineFastState.compose env27693 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 6304) := by decide +kernel

theorem selectedBound27693 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env27694 : List Nat := [2,4,8,16,32,64,128,100,512,116,2048,4096,6304,4112,6160,6315,4096,4096,117,6161,4160,168,17,2,6184,65,4112,4097,4097,2065,204,32,101,32,4161,513]

theorem envBound27694 : H12AffineFastState.Bounded env27694 := by
  intro p hp
  have h : env27694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27693_27694 : H12AffineEnvironment.transform 12 6304 env27693 = env27694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6304 env27693 == env27694) = true)

def env27695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1025,8660,4160,4194304,17,73736,8328,65,4340844,5393,4096,138340,1500,4194440,257,33,5456,74250]

theorem envBound27695 : H12AffineFastState.Bounded env27695 := by
  intro p hp
  have h : env27695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27687_27695 : H12AffineEnvironment.transform 13 5377 env27687 = env27695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27687 == env27695) = true)

theorem identity27695 : scanCanonicalize (H12AffineFastState.compose env27695 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound27695 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,10401,1025,8660,4160,4194304,17,138,8328,65,4340844,5393,4096,138340,1500,4194440,257,33,5456,648]

theorem envBound27696 : H12AffineFastState.Bounded env27696 := by
  intro p hp
  have h : env27696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27695_27696 : H12AffineEnvironment.transform 15 8322 env27695 = env27696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env27695 == env27696) = true)

theorem identity27696 : scanCanonicalize (H12AffineFastState.compose env27696 (packedSelected [0,2,4,6,9,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound27696 : packedSelected [0,2,4,6,9,16,27] rootPS < 2^1333 := by decide +kernel

def env27697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,5529,10401,1025,8660,4160,4194304,17,138,8328,65,4205045,5393,4096,2557,1500,4194440,257,33,5456,648]

theorem envBound27697 : H12AffineFastState.Bounded env27697 := by
  intro p hp
  have h : env27697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27696_27697 : H12AffineEnvironment.transform 16 5529 env27696 = env27697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env27696 == env27697) = true)

theorem identity27697 : scanCanonicalize (H12AffineFastState.compose env27697 (packedSelected [0,7,9,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27697 : packedSelected [0,7,9,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env27698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5529,2556,1025,137,4160,4194304,17,138,469,65,4196520,5393,4096,2557,1500,4194440,257,33,5456,648]

theorem envBound27698 : H12AffineFastState.Bounded env27698 := by
  intro p hp
  have h : env27698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27697_27698 : H12AffineEnvironment.transform 12 349 env27697 = env27698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27697 == env27698) = true)

theorem identity27698 : scanCanonicalize (H12AffineFastState.compose env27698 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27698 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env27699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5529,2556,1025,137,4160,32,17,138,469,65,2184,5393,4096,2557,1500,168,257,33,5456,648]

theorem envBound27699 : H12AffineFastState.Bounded env27699 := by
  intro p hp
  have h : env27699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27698_27699 : H12AffineEnvironment.transform 21 32 env27698 = env27699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27698 == env27699) = true)

theorem identity27699 : scanCanonicalize (H12AffineFastState.compose env27699 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27699 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27700 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5236,136,170,5356,2185,1025,137,4160,32,17,138,160,65,2184,5220,4096,2184,1193,168,116,33,5157,648]

theorem envBound27700 : H12AffineFastState.Bounded env27700 := by
  intro p hp
  have h : env27700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27699_27700 : H12AffineEnvironment.transform 7 117 env27699 = env27700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27699 == env27700) = true)

theorem identity27700 : scanCanonicalize (H12AffineFastState.compose env27700 (packedSelected [0,3,5,6,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound27700 : packedSelected [0,3,5,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27701 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1125,4096,40,5236,136,170,5356,1260,1025,137,4160,32,17,138,160,65,1261,5220,4096,1261,1193,168,116,33,5157,648]

theorem envBound27701 : H12AffineFastState.Bounded env27701 := by
  intro p hp
  have h : env27701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27700_27701 : H12AffineEnvironment.transform 10 1125 env27700 = env27701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env27700 == env27701) = true)

theorem identity27701 : scanCanonicalize (H12AffineFastState.compose env27701 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound27701 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27702 : List Nat := [2,4,8,16,32,64,128,117,512,100,1,4096,40,4112,136,170,4232,136,101,137,4160,32,17,138,160,65,137,4096,4096,137,205,168,116,33,4161,648]

theorem envBound27702 : H12AffineFastState.Bounded env27702 := by
  intro p hp
  have h : env27702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27701_27702 : H12AffineEnvironment.transform 9 100 env27701 = env27702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env27701 == env27702) = true)

def env27703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,16,98781,8328,65,4340845,5392,17665,179632,1501,4256861,257,21792,46213,74251]

theorem envBound27703 : H12AffineFastState.Bounded env27703 := by
  intro p hp
  have h : env27703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27685_27703 : H12AffineEnvironment.transform 20 4161 env27685 = env27703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27685 == env27703) = true)

theorem identity27703 : scanCanonicalize (H12AffineFastState.compose env27703 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41461) := by decide +kernel

theorem selectedBound27703 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,41461,16,98781,8328,65,171416,5392,17665,179632,1501,21928,257,21792,46213,74251]

theorem envBound27704 : H12AffineFastState.Bounded env27704 := by
  intro p hp
  have h : env27704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27703_27704 : H12AffineEnvironment.transform 21 41461 env27703 = env27704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41461 env27703 == env27704) = true)

def env27705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,41341,16,98645,8192,65,171280,5392,17665,179512,1365,21792,257,21792,46093,74251]

theorem envBound27705 : H12AffineFastState.Bounded env27705 := by
  intro p hp
  have h : env27705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27704_27705 : H12AffineEnvironment.transform 6 8 env27704 = env27705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27704 == env27705) = true)

theorem identity27705 : scanCanonicalize (H12AffineFastState.compose env27705 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27705 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,4161,41341,16,21762,8192,65,171280,5392,17665,179512,1365,21792,257,21792,46093,63068]

theorem envBound27706 : H12AffineFastState.Bounded env27706 := by
  intro p hp
  have h : env27706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27705_27706 : H12AffineEnvironment.transform 15 54359 env27705 = env27706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27705 == env27706) = true)

theorem identity27706 : scanCanonicalize (H12AffineFastState.compose env27706 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound27706 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env27707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5221,32040,1025,32769,4161,41341,16,21762,8192,65,35189,5392,17665,43357,1365,21792,257,21792,46093,63068]

theorem envBound27707 : H12AffineFastState.Bounded env27707 := by
  intro p hp
  have h : env27707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27706_27707 : H12AffineEnvironment.transform 16 5221 env27706 = env27707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env27706 == env27707) = true)

theorem identity27707 : scanCanonicalize (H12AffineFastState.compose env27707 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound27707 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,29822,5221,32040,1025,8232,4161,340,16,21762,8192,65,10588,5392,17665,2420,1365,21792,257,21792,5156,22133]

theorem envBound27708 : H12AffineFastState.Bounded env27708 := by
  intro p hp
  have h : env27708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27707_27708 : H12AffineEnvironment.transform 14 8233 env27707 = env27708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env27707 == env27708) = true)

theorem identity27708 : scanCanonicalize (H12AffineFastState.compose env27708 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27708 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27709 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,29822,5221,31837,1025,8232,4161,33,16,21623,8192,65,10281,5221,17524,2049,1056,21589,116,21589,5156,22133]

theorem envBound27709 : H12AffineFastState.Bounded env27709 := by
  intro p hp
  have h : env27709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27708_27709 : H12AffineEnvironment.transform 7 117 env27708 = env27709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27708 == env27709) = true)

theorem identity27709 : scanCanonicalize (H12AffineFastState.compose env27709 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound27709 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env27710 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,16384,81,21510,5221,23589,1025,80,4161,33,16,21623,120,65,2129,5221,17524,2049,1056,21589,116,21589,5156,22133]

theorem envBound27710 : H12AffineFastState.Bounded env27710 := by
  intro p hp
  have h : env27710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27709_27710 : H12AffineEnvironment.transform 12 120 env27709 = env27710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env27709 == env27710) = true)

theorem identity27710 : scanCanonicalize (H12AffineFastState.compose env27710 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27710 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27711 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,0,21510,5172,23589,1025,1,4112,33,16,21542,41,16,2048,5172,17445,2049,1056,21508,37,21508,5156,22052]

theorem envBound27711 : H12AffineFastState.Bounded env27711 := by
  intro p hp
  have h : env27711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27710_27711 : H12AffineEnvironment.transform 5 17 env27710 = env27711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27710 == env27711) = true)

theorem identity27711 : scanCanonicalize (H12AffineFastState.compose env27711 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound27711 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27712 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,41,16384,0,19479,3109,17460,1025,1,2049,33,16,19511,41,16,2048,3109,17445,2049,1056,19477,37,19477,3125,20021]

theorem envBound27712 : H12AffineFastState.Bounded env27712 := by
  intro p hp
  have h : env27712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27711_27712 : H12AffineEnvironment.transform 11 2065 env27711 = env27712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env27711 == env27712) = true)

theorem identity27712 : scanCanonicalize (H12AffineFastState.compose env27712 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27712 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env27713 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1,16,41,16384,0,17430,1060,17460,1025,1,0,33,16,17462,41,16,1,1060,17445,0,1056,17428,37,17428,1076,17972]

theorem envBound27713 : H12AffineFastState.Bounded env27713 := by
  intro p hp
  have h : env27713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27712_27713 : H12AffineEnvironment.transform 10 1 env27712 = env27713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27712 == env27713) = true)

theorem identity27713 : scanCanonicalize (H12AffineFastState.compose env27713 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 1060) := by decide +kernel

theorem selectedBound27713 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env27714 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1,16,41,1060,0,50,1060,16,1025,1,0,33,16,18,41,16,1,1060,1,0,1056,48,37,48,1076,528]

theorem envBound27714 : H12AffineFastState.Bounded env27714 := by
  intro p hp
  have h : env27714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27713_27714 : H12AffineEnvironment.transform 13 1060 env27713 = env27714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1060 env27713 == env27714) = true)

theorem identity27714 : scanCanonicalize (H12AffineFastState.compose env27714 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27714 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27715 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1,1,41,1060,0,35,1060,1,1025,1,0,33,1,3,41,1,1,1060,1,0,1056,33,37,33,1061,513]

theorem envBound27715 : H12AffineFastState.Bounded env27715 := by
  intro p hp
  have h : env27715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27714_27715 : H12AffineEnvironment.transform 3 1 env27714 = env27715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27714 == env27715) = true)

def env27716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,41340,16,98644,8193,65,171281,5392,17665,179513,1364,21793,257,21792,46092,74251]

theorem envBound27716 : H12AffineFastState.Bounded env27716 := by
  intro p hp
  have h : env27716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27704_27716 : H12AffineEnvironment.transform 6 9 env27704 = env27716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27704 == env27716) = true)

theorem identity27716 : scanCanonicalize (H12AffineFastState.compose env27716 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound27716 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32041,1025,32769,4161,41340,16,62559,8193,65,171281,5392,17665,179513,1364,21793,257,21792,46092,22272]

theorem envBound27717 : H12AffineFastState.Bounded env27717 := by
  intro p hp
  have h : env27717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27716_27717 : H12AffineEnvironment.transform 15 29963 env27716 = env27717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env27716 == env27717) = true)

theorem identity27717 : scanCanonicalize (H12AffineFastState.compose env27717 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound27717 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env27718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,262,131072,2340,1025,32769,4161,41340,16,32850,8193,65,171281,5392,12556,179513,1364,8492,257,8493,46092,8973]

theorem envBound27718 : H12AffineFastState.Bounded env27718 := by
  intro p hp
  have h : env27718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27717_27718 : H12AffineEnvironment.transform 13 13325 env27717 = env27718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env27717 == env27718) = true)

def env27719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433836,8393985,10507600,8568225,2102685,12645452,257,21793,46212,2175563]

theorem envBound27719 : H12AffineFastState.Bounded env27719 := by
  intro p hp
  have h : env27719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27652_27719 : H12AffineEnvironment.transform 17 32161 env27652 = env27719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env27652 == env27719) = true)

def env27720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101328,98781,8328,65,6433836,2098513,17664,2272753,2102685,6349852,257,21793,46212,2175563]

theorem envBound27720 : H12AffineFastState.Bounded env27720 := by
  intro p hp
  have h : env27720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27719_27720 : H12AffineEnvironment.transform 22 2101328 env27719 = env27720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env27719 == env27720) = true)

def env27721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,16,98781,8328,65,4340844,5393,17664,179633,1501,4256860,257,21793,46212,74251]

theorem envBound27721 : H12AffineFastState.Bounded env27721 := by
  intro p hp
  have h : env27721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27720_27721 : H12AffineEnvironment.transform 20 4160 env27720 = env27721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27720 == env27721) = true)

theorem identity27721 : scanCanonicalize (H12AffineFastState.compose env27721 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98815) := by decide +kernel

theorem selectedBound27721 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,98815,16,98781,8328,65,245139,5393,17664,179633,1501,95651,257,21793,46212,74251]

theorem envBound27722 : H12AffineFastState.Bounded env27722 := by
  intro p hp
  have h : env27722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27721_27722 : H12AffineEnvironment.transform 21 98815 env27721 = env27722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98815 env27721 == env27722) = true)

def env27723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,98679,16,98645,8192,65,245019,5393,17664,179513,1365,95531,257,21793,46092,74251]

theorem envBound27723 : H12AffineFastState.Bounded env27723 := by
  intro p hp
  have h : env27723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27722_27723 : H12AffineEnvironment.transform 6 8 env27722 = env27723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27722 == env27723) = true)

theorem identity27723 : scanCanonicalize (H12AffineFastState.compose env27723 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound27723 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4160,21793,16,21763,8192,65,158029,5393,17664,179513,1365,41341,257,21793,46092,63069]

theorem envBound27724 : H12AffineFastState.Bounded env27724 := by
  intro p hp
  have h : env27724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27723_27724 : H12AffineEnvironment.transform 15 54358 env27723 = env27724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env27723 == env27724) = true)

theorem identity27724 : scanCanonicalize (H12AffineFastState.compose env27724 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound27724 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46157,32041,1025,32769,4160,21793,16,21763,8192,65,56576,5393,17664,2420,1365,41341,257,21793,46092,63069]

theorem envBound27725 : H12AffineFastState.Bounded env27725 := by
  intro p hp
  have h : env27725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27724_27725 : H12AffineEnvironment.transform 16 46157 env27724 = env27725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env27724 == env27725) = true)

theorem identity27725 : scanCanonicalize (H12AffineFastState.compose env27725 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27725 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16401,32041,1025,29789,4160,21793,16,21763,8192,65,10588,5393,17664,2420,1365,21793,257,21793,16464,513]

theorem envBound27726 : H12AffineFastState.Bounded env27726 := by
  intro p hp
  have h : env27726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27725_27726 : H12AffineEnvironment.transform 14 29788 env27725 = env27726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27725 == env27726) = true)

theorem identity27726 : scanCanonicalize (H12AffineFastState.compose env27726 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound27726 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,1297,8202,12636,3172,1025,1296,4160,9324,16,9294,8192,65,10588,5393,13389,2420,1365,9324,257,9324,12573,513]

theorem envBound27727 : H12AffineFastState.Bounded env27727 := by
  intro p hp
  have h : env27727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27726_27727 : H12AffineEnvironment.transform 13 12621 env27726 = env27727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env27726 == env27727) = true)

theorem identity27727 : scanCanonicalize (H12AffineFastState.compose env27727 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound27727 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,1297,1094,5392,3172,1025,1296,4160,32,16,2,1100,65,3344,5393,4097,2420,1365,32,257,32,5457,513]

theorem envBound27728 : H12AffineFastState.Bounded env27728 := by
  intro p hp
  have h : env27728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27727_27728 : H12AffineEnvironment.transform 12 1100 env27727 = env27728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env27727 == env27728) = true)

theorem identity27728 : scanCanonicalize (H12AffineFastState.compose env27728 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1808) := by decide +kernel

theorem selectedBound27728 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1808,1100,529,1297,1094,512,3172,1025,1296,1872,32,16,2,1100,65,3344,513,1809,2420,1365,32,257,32,577,513]

theorem envBound27729 : H12AffineFastState.Bounded env27729 := by
  intro p hp
  have h : env27729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27728_27729 : H12AffineEnvironment.transform 11 1808 env27728 = env27729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1808 env27728 == env27729) = true)

def env27730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98678,16,98644,8193,65,245018,5393,17664,179512,1364,95530,257,21793,46093,74251]

theorem envBound27730 : H12AffineFastState.Bounded env27730 := by
  intro p hp
  have h : env27730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27722_27730 : H12AffineEnvironment.transform 6 9 env27722 = env27730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27722 == env27730) = true)

theorem identity27730 : scanCanonicalize (H12AffineFastState.compose env27730 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound27730 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,32040,1025,32769,4160,62588,16,62558,8193,65,182288,5393,17664,179512,1364,32,257,21793,46093,22273]

theorem envBound27731 : H12AffineFastState.Bounded env27731 := by
  intro p hp
  have h : env27731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27730_27731 : H12AffineEnvironment.transform 15 29962 env27730 = env27731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env27730 == env27731) = true)

theorem identity27731 : scanCanonicalize (H12AffineFastState.compose env27731 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound27731 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,13388,32040,1025,32769,4160,62588,16,62558,8193,65,64604,5393,17664,35188,1364,32,257,21793,46093,22273]

theorem envBound27732 : H12AffineFastState.Bounded env27732 := by
  intro p hp
  have h : env27732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27731_27732 : H12AffineEnvironment.transform 16 13388 env27731 = env27732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env27731 == env27732) = true)

theorem identity27732 : scanCanonicalize (H12AffineFastState.compose env27732 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27732 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env27733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8283,13388,10361,1025,32769,4160,41261,16,41231,8193,65,43277,5393,4177,35188,1364,32,257,112,46093,592]

theorem envBound27733 : H12AffineFastState.Bounded env27733 := by
  intro p hp
  have h : env27733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27732_27733 : H12AffineEnvironment.transform 13 5457 env27732 = env27733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env27732 == env27733) = true)

theorem identity27733 : scanCanonicalize (H12AffineFastState.compose env27733 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27733 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27734 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,8203,13340,10281,1025,32769,4112,41261,16,41231,8193,17,43277,5393,4097,35108,1284,32,257,32,46093,512]

theorem envBound27734 : H12AffineFastState.Bounded env27734 := by
  intro p hp
  have h : env27734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27733_27734 : H12AffineEnvironment.transform 5 16 env27733 = env27734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27733 == env27734) = true)

theorem identity27734 : scanCanonicalize (H12AffineFastState.compose env27734 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound27734 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27735 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,33,8203,13340,10281,1025,32,4112,8460,16,8494,8193,17,10540,5393,4097,2309,1284,32,257,32,13356,512]

theorem envBound27735 : H12AffineFastState.Bounded env27735 := by
  intro p hp
  have h : env27735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27734_27735 : H12AffineEnvironment.transform 14 33 env27734 = env27735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env27734 == env27735) = true)

theorem identity27735 : scanCanonicalize (H12AffineFastState.compose env27735 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound27735 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27736 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5377,33,1047,4096,3125,1025,32,4112,1296,16,1330,1053,17,3376,5393,4097,2309,1284,32,257,32,4144,512]

theorem envBound27736 : H12AffineFastState.Bounded env27736 := by
  intro p hp
  have h : env27736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27735_27736 : H12AffineEnvironment.transform 12 1052 env27735 = env27736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env27735 == env27736) = true)

theorem identity27736 : scanCanonicalize (H12AffineFastState.compose env27736 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3361) := by decide +kernel

theorem selectedBound27736 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27737 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3361,1052,2080,33,1047,3361,3125,1025,32,3377,1296,16,1330,1053,17,3376,2096,3360,2309,1284,32,257,32,3345,512]

theorem envBound27737 : H12AffineFastState.Bounded env27737 := by
  intro p hp
  have h : env27737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27736_27737 : H12AffineEnvironment.transform 11 3361 env27736 = env27737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3361 env27736 == env27737) = true)

theorem identity27737 : scanCanonicalize (H12AffineFastState.compose env27737 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound27737 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27738 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,2356,9,2080,33,2,2356,2080,20,32,2340,261,16,295,8,17,2341,2096,2357,2309,273,32,257,32,2308,512]

theorem envBound27738 : H12AffineFastState.Bounded env27738 := by
  intro p hp
  have h : env27738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27737_27738 : H12AffineEnvironment.transform 9 21 env27737 = env27738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27737 == env27738) = true)

theorem identity27738 : scanCanonicalize (H12AffineFastState.compose env27738 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27738 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27739 : List Nat := [2,4,8,16,32,16,9,256,512,21,0,308,9,32,33,2,308,32,20,32,292,261,16,295,8,17,293,48,309,261,273,32,257,32,260,512]

theorem envBound27739 : H12AffineFastState.Bounded env27739 := by
  intro p hp
  have h : env27739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27738_27739 : H12AffineEnvironment.transform 10 0 env27738 = env27739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27738 == env27739) = true)

theorem identity27739 : scanCanonicalize (H12AffineFastState.compose env27739 (packedSelected [0,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27739 : packedSelected [0,7,14] rootPS < 2^1333 := by decide +kernel

def env27740 : List Nat := [2,4,8,16,32,16,9,4,512,21,0,48,9,32,33,2,48,32,20,32,32,1,16,35,8,17,33,48,49,1,21,32,5,32,0,512]

theorem envBound27740 : H12AffineFastState.Bounded env27740 := by
  intro p hp
  have h : env27740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27739_27740 : H12AffineEnvironment.transform 7 4 env27739 = env27740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27739 == env27740) = true)

theorem identity27740 : scanCanonicalize (H12AffineFastState.compose env27740 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound27740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27741 : List Nat := [2,4,8,16,4,16,9,4,512,21,0,20,9,4,5,2,20,4,20,4,4,1,16,7,8,17,5,20,21,1,21,4,5,4,0,512]

theorem envBound27741 : H12AffineFastState.Bounded env27741 := by
  intro p hp
  have h : env27741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27740_27741 : H12AffineEnvironment.transform 4 4 env27740 = env27741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env27740 == env27741) = true)

theorem identity27741 : scanCanonicalize (H12AffineFastState.compose env27741 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27741 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27742 : List Nat := [2,4,8,5,4,5,9,4,512,0,0,1,9,4,5,2,1,4,1,4,4,1,5,7,8,4,5,1,0,1,0,4,5,4,0,512]

theorem envBound27742 : H12AffineFastState.Bounded env27742 := by
  intro p hp
  have h : env27742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27741_27742 : H12AffineEnvironment.transform 3 5 env27741 = env27742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27741 == env27742) = true)

theorem identity27742 : scanCanonicalize (H12AffineFastState.compose env27742 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound27742 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27743 : List Nat := [2,4,7,5,4,5,6,4,512,0,0,1,6,4,5,2,1,4,1,4,4,1,5,7,7,4,5,1,0,1,0,4,5,4,0,512]

theorem envBound27743 : H12AffineFastState.Bounded env27743 := by
  intro p hp
  have h : env27743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27742_27743 : H12AffineEnvironment.transform 2 7 env27742 = env27743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env27742 == env27743) = true)

theorem identity27743 : scanCanonicalize (H12AffineFastState.compose env27743 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27743 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env27744 : List Nat := [0,4,5,5,4,5,4,4,512,0,0,1,4,4,5,0,1,4,1,4,4,1,5,5,5,4,5,1,0,1,0,4,5,4,0,512]

theorem envBound27744 : H12AffineFastState.Bounded env27744 := by
  intro p hp
  have h : env27744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27743_27744 : H12AffineEnvironment.transform 0 0 env27743 = env27744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27743 == env27744) = true)

theorem identity27744 : scanCanonicalize (H12AffineFastState.compose env27744 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27744 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27745 : List Nat := [0,0,1,1,0,1,0,0,512,0,0,1,0,0,1,0,1,0,1,0,0,1,1,1,1,0,1,1,0,1,0,0,1,0,0,512]

theorem envBound27745 : H12AffineFastState.Bounded env27745 := by
  intro p hp
  have h : env27745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27744_27745 : H12AffineEnvironment.transform 1 0 env27744 = env27745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27744 == env27745) = true)

def env27746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,17,98781,8328,65,4340845,5392,17664,179632,1500,4256861,257,21793,46212,74250]

theorem envBound27746 : H12AffineFastState.Bounded env27746 := by
  intro p hp
  have h : env27746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27720_27746 : H12AffineEnvironment.transform 20 4161 env27720 = env27746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27720 == env27746) = true)

theorem identity27746 : scanCanonicalize (H12AffineFastState.compose env27746 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound27746 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32161,1025,32769,4161,4194304,17,21763,8328,65,4340845,5392,17664,179632,1500,4256861,257,21793,46212,63188]

theorem envBound27747 : H12AffineFastState.Bounded env27747 := by
  intro p hp
  have h : env27747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27746_27747 : H12AffineEnvironment.transform 15 54494 env27746 = env27747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env27746 == env27747) = true)

def env27748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4161,4194304,17,21763,8192,65,4340845,5392,17664,179512,1364,4256861,257,21793,46092,63068]

theorem envBound27748 : H12AffineFastState.Bounded env27748 := by
  intro p hp
  have h : env27748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27747_27748 : H12AffineEnvironment.transform 6 8 env27747 = env27748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27747 == env27748) = true)

theorem identity27748 : scanCanonicalize (H12AffineFastState.compose env27748 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1025,32769,4161,4194304,17,2,8192,65,4340845,5392,4097,179512,1364,4235612,257,32,46092,41821]

theorem envBound27749 : H12AffineFastState.Bounded env27749 := by
  intro p hp
  have h : env27749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27748_27749 : H12AffineEnvironment.transform 13 5377 env27748 = env27749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27748 == env27749) = true)

theorem identity27749 : scanCanonicalize (H12AffineFastState.compose env27749 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound27749 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1025,32769,4161,41261,17,2,8192,65,171328,5392,4097,179512,1364,113,257,32,46092,41821]

theorem envBound27750 : H12AffineFastState.Bounded env27750 := by
  intro p hp
  have h : env27750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27749_27750 : H12AffineEnvironment.transform 21 41261 env27749 = env27750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env27749 == env27750) = true)

theorem identity27750 : scanCanonicalize (H12AffineFastState.compose env27750 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 38209) := by decide +kernel

theorem selectedBound27750 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env27751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38209,10280,1025,32769,4161,41261,17,2,8192,65,2049,5392,4097,10361,1364,113,257,32,46092,41821]

theorem envBound27751 : H12AffineFastState.Bounded env27751 := by
  intro p hp
  have h : env27751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27750_27751 : H12AffineEnvironment.transform 16 38209 env27750 = env27751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38209 env27750 == env27751) = true)

theorem identity27751 : scanCanonicalize (H12AffineFastState.compose env27751 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27751 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env27752 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33031,38161,10280,1025,32769,4113,41261,17,2,8192,17,2049,5392,4097,10281,1284,33,257,32,46092,41741]

theorem envBound27752 : H12AffineFastState.Bounded env27752 := by
  intro p hp
  have h : env27752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27751_27752 : H12AffineEnvironment.transform 5 16 env27751 = env27752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27751 == env27752) = true)

theorem identity27752 : scanCanonicalize (H12AffineFastState.compose env27752 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27752 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27753 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,0,263,5393,10280,1025,1,4113,8493,17,2,8192,17,2049,5392,4097,10281,1284,33,257,32,13324,8973]

theorem envBound27753 : H12AffineFastState.Bounded env27753 := by
  intro p hp
  have h : env27753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27752_27753 : H12AffineEnvironment.transform 14 0 env27752 = env27753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27752 == env27753) = true)

theorem identity27753 : scanCanonicalize (H12AffineFastState.compose env27753 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27753 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env27754 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,0,35,5173,10280,1025,1,4113,8201,17,2,8192,17,2049,5172,4097,10281,1056,33,37,32,13324,8745]

theorem envBound27754 : H12AffineFastState.Bounded env27754 := by
  intro p hp
  have h : env27754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27753_27754 : H12AffineEnvironment.transform 7 36 env27753 = env27754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27753 == env27754) = true)

theorem identity27754 : scanCanonicalize (H12AffineFastState.compose env27754 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound27754 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env27755 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4113,32,17,2,41,17,2049,5172,4097,2048,1056,33,37,32,5157,512]

theorem envBound27755 : H12AffineFastState.Bounded env27755 := by
  intro p hp
  have h : env27755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27754_27755 : H12AffineEnvironment.transform 12 41 env27754 = env27755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env27754 == env27755) = true)

theorem identity27755 : scanCanonicalize (H12AffineFastState.compose env27755 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27756 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5125,0,3,5141,2049,1025,1,4113,0,17,2,9,17,2049,5140,4097,2048,1024,1,5,0,5125,512]

theorem envBound27756 : H12AffineFastState.Bounded env27756 := by
  intro p hp
  have h : env27756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27755_27756 : H12AffineEnvironment.transform 4 0 env27755 = env27756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27755 == env27756) = true)

def env27757 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1045,0,3,1029,2049,1025,1,1,0,17,2,9,17,2049,1028,17,2048,1024,1,5,0,1045,512]

theorem envBound27757 : H12AffineFastState.Bounded env27757 := by
  intro p hp
  have h : env27757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27756_27757 : H12AffineEnvironment.transform 11 16 env27756 = env27757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27756 == env27757) = true)

theorem identity27757 : scanCanonicalize (H12AffineFastState.compose env27757 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27757 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27758 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,9,1045,0,3,1029,1,1025,1,1,0,17,2,9,17,1,1028,17,0,1024,1,5,0,1045,512]

theorem envBound27758 : H12AffineFastState.Bounded env27758 := by
  intro p hp
  have h : env27758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27757_27758 : H12AffineEnvironment.transform 10 0 env27757 = env27758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27757 == env27758) = true)

def env27759 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,1,0,3,17,1,21,1,1,0,17,2,9,17,1,16,17,0,20,1,5,0,1,512]

theorem envBound27759 : H12AffineFastState.Bounded env27759 := by
  intro p hp
  have h : env27759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27758_27759 : H12AffineEnvironment.transform 9 20 env27758 = env27759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27758 == env27759) = true)

theorem identity27759 : scanCanonicalize (H12AffineFastState.compose env27759 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound27759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27760 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,9,1,0,3,17,1,21,1,1,0,17,2,9,17,1,16,17,0,20,1,5,0,1,30]

theorem envBound27760 : H12AffineFastState.Bounded env27760 := by
  intro p hp
  have h : env27760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27759_27760 : H12AffineEnvironment.transform 8 30 env27759 = env27760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env27759 == env27760) = true)

def leafEnv27760 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,9,1,0,3,17,1,21,1,1,0,17,2,21,9,1,17,1,16,17,0,20,1,5,0,5,3,1,30,1,1,0]

def active27760 : List Nat := [0,1,2,3]

def tree27760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27760 : H12WitnessSearch.Good tree27760 := H12GlobalWitnessIndex.good

theorem leafIdentity27760 : H12AffineFastState.composeSystem env27760 rootObs = leafEnv27760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27760 rootObs == leafEnv27760) = true)

theorem terminalChecked27760 : H12PackedTerminal.terminalCheckFast leafEnv27760 active27760 tree27760 = true := by decide +kernel

def env27761 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,0,0,3,16,1,20,1,1,0,17,2,9,17,1,17,17,0,21,1,5,0,0,512]

theorem envBound27761 : H12AffineFastState.Bounded env27761 := by
  intro p hp
  have h : env27761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27758_27761 : H12AffineEnvironment.transform 9 21 env27758 = env27761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27758 == env27761) = true)

theorem identity27761 : scanCanonicalize (H12AffineFastState.compose env27761 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27762 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,0,3,5,1,1,1,1,0,4,2,9,4,1,4,4,0,0,1,5,0,0,512]

theorem envBound27762 : H12AffineFastState.Bounded env27762 := by
  intro p hp
  have h : env27762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27761_27762 : H12AffineEnvironment.transform 3 5 env27761 = env27762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27761 == env27762) = true)

def leafEnv27762 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,0,3,5,1,1,1,1,0,4,2,1,9,1,4,1,4,4,0,0,1,5,0,5,3,0,512,1,1,0]

def active27762 : List Nat := [0,1,2,8]

def tree27762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27762 : H12WitnessSearch.Good tree27762 := H12GlobalWitnessIndex.good

theorem leafIdentity27762 : H12AffineFastState.composeSystem env27762 rootObs = leafEnv27762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27762 rootObs == leafEnv27762) = true)

theorem terminalChecked27762 : H12PackedTerminal.terminalCheckFast leafEnv27762 active27762 tree27762 = true := by decide +kernel

def env27763 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1044,0,3,1028,2049,1025,1,0,0,17,2,9,17,2049,1029,16,2048,1024,1,5,0,1044,512]

theorem envBound27763 : H12AffineFastState.Bounded env27763 := by
  intro p hp
  have h : env27763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27756_27763 : H12AffineEnvironment.transform 11 17 env27756 = env27763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27756 == env27763) = true)

theorem identity27763 : scanCanonicalize (H12AffineFastState.compose env27763 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound27763 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27764 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,17,9,1044,0,3,1028,1044,1025,1,0,0,17,2,9,17,1044,1029,16,1045,1024,1,5,0,1044,512]

theorem envBound27764 : H12AffineFastState.Bounded env27764 := by
  intro p hp
  have h : env27764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27763_27764 : H12AffineEnvironment.transform 10 1045 env27763 = env27764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env27763 == env27764) = true)

def env27765 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,9,0,0,3,16,0,21,1,0,0,17,2,9,17,0,17,16,1,20,1,5,0,0,512]

theorem envBound27765 : H12AffineFastState.Bounded env27765 := by
  intro p hp
  have h : env27765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27764_27765 : H12AffineEnvironment.transform 9 20 env27764 = env27765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27764 == env27765) = true)

theorem identity27765 : scanCanonicalize (H12AffineFastState.compose env27765 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound27765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27766 : List Nat := [2,4,8,16,0,16,8,4,31,20,1,17,9,0,0,3,16,0,21,1,0,0,17,2,9,17,0,17,16,1,20,1,5,0,0,31]

theorem envBound27766 : H12AffineFastState.Bounded env27766 := by
  intro p hp
  have h : env27766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27765_27766 : H12AffineEnvironment.transform 8 31 env27765 = env27766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env27765 == env27766) = true)

def leafEnv27766 : List Nat := [2,4,8,16,0,16,8,4,31,20,1,17,9,0,0,3,16,0,21,1,0,0,17,2,21,9,1,17,0,17,16,1,20,1,5,0,5,3,0,31,1,0,0]

def active27766 : List Nat := [0,1,2,3]

def tree27766 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27766 : H12WitnessSearch.Good tree27766 := H12GlobalWitnessIndex.good

theorem leafIdentity27766 : H12AffineFastState.composeSystem env27766 rootObs = leafEnv27766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27766 rootObs == leafEnv27766) = true)

theorem terminalChecked27766 : H12PackedTerminal.terminalCheckFast leafEnv27766 active27766 tree27766 = true := by decide +kernel

def env27767 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,1,0,3,17,1,20,1,0,0,17,2,9,17,1,16,16,0,21,1,5,0,1,512]

theorem envBound27767 : H12AffineFastState.Bounded env27767 := by
  intro p hp
  have h : env27767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27764_27767 : H12AffineEnvironment.transform 9 21 env27764 = env27767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27764 == env27767) = true)

theorem identity27767 : scanCanonicalize (H12AffineFastState.compose env27767 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27767 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27768 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,9,1,0,3,4,1,1,1,0,0,4,2,9,4,1,5,5,0,0,1,5,0,1,512]

theorem envBound27768 : H12AffineFastState.Bounded env27768 := by
  intro p hp
  have h : env27768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27767_27768 : H12AffineEnvironment.transform 3 5 env27767 = env27768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27767 == env27768) = true)

def leafEnv27768 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,9,1,0,3,4,1,1,1,0,0,4,2,1,9,1,4,1,5,5,0,0,1,5,0,5,3,1,512,1,0,0]

def active27768 : List Nat := [0,1,2,8]

def tree27768 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27768 : H12WitnessSearch.Good tree27768 := H12GlobalWitnessIndex.good

theorem leafIdentity27768 : H12AffineFastState.composeSystem env27768 rootObs = leafEnv27768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27768 rootObs == leafEnv27768) = true)

theorem terminalChecked27768 : H12PackedTerminal.terminalCheckFast leafEnv27768 active27768 tree27768 = true := by decide +kernel

def env27769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,4161,4194304,17,21763,8193,65,4340845,5392,17664,179513,1365,4256861,257,21793,46093,63069]

theorem envBound27769 : H12AffineFastState.Bounded env27769 := by
  intro p hp
  have h : env27769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27747_27769 : H12AffineEnvironment.transform 6 9 env27747 = env27769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27747 == env27769) = true)

theorem identity27769 : scanCanonicalize (H12AffineFastState.compose env27769 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27769 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4161,4194304,17,21763,8193,65,4340845,5392,17664,149861,1365,4194305,257,21793,16465,513]

theorem envBound27770 : H12AffineFastState.Bounded env27770 := by
  intro p hp
  have h : env27770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27769_27770 : H12AffineEnvironment.transform 14 29788 env27769 = env27770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27769 == env27770) = true)

theorem identity27770 : scanCanonicalize (H12AffineFastState.compose env27770 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound27770 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env27771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4161,147505,17,21763,8193,65,31836,5392,17664,149861,1365,147504,257,21793,16465,513]

theorem envBound27771 : H12AffineFastState.Bounded env27771 := by
  intro p hp
  have h : env27771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27770_27771 : H12AffineEnvironment.transform 21 147505 env27770 = env27771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env27770 == env27771) = true)

theorem identity27771 : scanCanonicalize (H12AffineFastState.compose env27771 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound27771 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env27772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,5393,32040,1025,29789,4161,21792,17,21763,8193,65,31836,5392,17664,23668,1365,21793,257,21793,16465,513]

theorem envBound27772 : H12AffineFastState.Bounded env27772 := by
  intro p hp
  have h : env27772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27771_27772 : H12AffineEnvironment.transform 16 5393 env27771 = env27772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env27771 == env27772) = true)

theorem identity27772 : scanCanonicalize (H12AffineFastState.compose env27772 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27772 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5393,2421,1025,0,4161,8573,17,8542,8193,65,2049,5392,12637,10281,1365,8572,257,8572,13324,513]

theorem envBound27773 : H12AffineFastState.Bounded env27773 := by
  intro p hp
  have h : env27773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27772_27773 : H12AffineEnvironment.transform 13 13405 env27772 = env27773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27772 == env27773) = true)

theorem identity27773 : scanCanonicalize (H12AffineFastState.compose env27773 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27773 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2421,1025,0,4161,32,17,3,348,65,2049,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound27774 : H12AffineFastState.Bounded env27774 := by
  intro p hp
  have h : env27774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27773_27774 : H12AffineEnvironment.transform 12 349 env27773 = env27774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27773 == env27774) = true)

theorem identity27774 : scanCanonicalize (H12AffineFastState.compose env27774 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound27774 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,602,4096,349,5376,1,342,5393,815,1025,0,4161,32,17,3,348,65,603,5392,4096,814,1365,33,257,33,5457,513]

theorem envBound27775 : H12AffineFastState.Bounded env27775 := by
  intro p hp
  have h : env27775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27774_27775 : H12AffineEnvironment.transform 10 602 env27774 = env27775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env27774 == env27775) = true)

theorem identity27775 : scanCanonicalize (H12AffineFastState.compose env27775 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27775 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27776 : List Nat := [2,4,8,16,32,64,9,256,512,273,602,4096,349,4113,1,342,4096,815,272,0,4161,32,17,3,348,65,603,4097,4096,814,68,33,257,33,4160,513]

theorem envBound27776 : H12AffineFastState.Bounded env27776 := by
  intro p hp
  have h : env27776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27775_27776 : H12AffineEnvironment.transform 9 273 env27775 = env27776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27775 == env27776) = true)

theorem identity27776 : scanCanonicalize (H12AffineFastState.compose env27776 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound27776 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27777 : List Nat := [2,4,8,16,32,64,9,256,512,273,602,17,349,0,1,342,17,815,272,0,80,32,17,3,348,65,603,16,17,814,68,33,257,33,81,513]

theorem envBound27777 : H12AffineFastState.Bounded env27777 := by
  intro p hp
  have h : env27777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27776_27777 : H12AffineEnvironment.transform 11 17 env27776 = env27777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27776 == env27777) = true)

theorem identity27777 : scanCanonicalize (H12AffineFastState.compose env27777 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound27777 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27778 : List Nat := [2,4,8,16,32,64,9,256,42,273,112,17,349,0,1,342,17,261,272,0,80,32,17,3,348,65,113,16,17,260,68,33,257,33,81,43]

theorem envBound27778 : H12AffineFastState.Bounded env27778 := by
  intro p hp
  have h : env27778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27777_27778 : H12AffineEnvironment.transform 8 42 env27777 = env27778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env27777 == env27778) = true)

theorem identity27778 : scanCanonicalize (H12AffineFastState.compose env27778 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27778 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27779 : List Nat := [2,4,8,16,32,64,9,116,42,101,112,17,41,0,1,34,17,113,100,0,80,32,17,3,40,65,113,16,17,112,68,33,117,33,81,43]

theorem envBound27779 : H12AffineFastState.Bounded env27779 := by
  intro p hp
  have h : env27779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27778_27779 : H12AffineEnvironment.transform 7 116 env27778 = env27779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27778 == env27779) = true)

theorem identity27779 : scanCanonicalize (H12AffineFastState.compose env27779 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound27779 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27780 : List Nat := [2,4,8,16,32,62,9,10,42,27,14,17,41,0,1,34,17,15,26,0,46,32,17,3,40,63,15,16,17,14,58,33,11,33,47,43]

theorem envBound27780 : H12AffineFastState.Bounded env27780 := by
  intro p hp
  have h : env27780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27779_27780 : H12AffineEnvironment.transform 5 62 env27779 = env27780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env27779 == env27780) = true)

theorem identity27780 : scanCanonicalize (H12AffineFastState.compose env27780 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27780 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27781 : List Nat := [1,4,8,16,32,61,9,9,41,24,13,17,41,0,1,33,17,12,25,0,45,32,17,0,40,60,12,16,17,13,57,33,8,33,44,40]

theorem envBound27781 : H12AffineFastState.Bounded env27781 := by
  intro p hp
  have h : env27781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27780_27781 : H12AffineEnvironment.transform 0 1 env27780 = env27781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27780 == env27781) = true)

theorem identity27781 : scanCanonicalize (H12AffineFastState.compose env27781 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27781 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env27782 : List Nat := [1,4,8,16,0,29,9,9,9,24,13,17,9,0,1,1,17,12,25,0,13,0,17,0,8,28,12,16,17,13,25,1,8,1,12,8]

theorem envBound27782 : H12AffineFastState.Bounded env27782 := by
  intro p hp
  have h : env27782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27781_27782 : H12AffineEnvironment.transform 4 0 env27781 = env27782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27781 == env27782) = true)

def env27783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101329,98780,8328,65,6433836,2098512,17665,2272752,2102685,6349853,257,21793,46212,2175563]

theorem envBound27783 : H12AffineFastState.Bounded env27783 := by
  intro p hp
  have h : env27783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27719_27783 : H12AffineEnvironment.transform 22 2101329 env27719 = env27783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env27719 == env27783) = true)

def env27784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,17,98780,8328,65,4340844,5392,17665,179632,1501,4256861,257,21793,46212,74251]

theorem envBound27784 : H12AffineFastState.Bounded env27784 := by
  intro p hp
  have h : env27784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27783_27784 : H12AffineEnvironment.transform 20 4160 env27783 = env27784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27783 == env27784) = true)

theorem identity27784 : scanCanonicalize (H12AffineFastState.compose env27784 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27784 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,4194304,17,41430,8328,65,4340844,5392,17665,179632,1501,4256861,257,21793,46212,513]

theorem envBound27785 : H12AffineFastState.Bounded env27785 := by
  intro p hp
  have h : env27785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27784_27785 : H12AffineEnvironment.transform 15 8202 env27784 = env27785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27784 == env27785) = true)

theorem identity27785 : scanCanonicalize (H12AffineFastState.compose env27785 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound27785 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,41260,17,41430,8328,65,171328,5392,17665,179632,1501,21873,257,21793,46212,513]

theorem envBound27786 : H12AffineFastState.Bounded env27786 := by
  intro p hp
  have h : env27786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27785_27786 : H12AffineEnvironment.transform 21 41260 env27785 = env27786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env27785 == env27786) = true)

def env27787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,41260,17,41310,8192,65,171328,5392,17665,179512,1365,21873,257,21793,46092,513]

theorem envBound27787 : H12AffineFastState.Bounded env27787 := by
  intro p hp
  have h : env27787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27786_27787 : H12AffineEnvironment.transform 6 8 env27786 = env27787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27786 == env27787) = true)

theorem identity27787 : scanCanonicalize (H12AffineFastState.compose env27787 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27787 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,32041,1025,8541,4160,112,17,2,8192,65,146460,5392,17665,138340,1365,21873,257,21793,5456,513]

theorem envBound27788 : H12AffineFastState.Bounded env27788 := by
  intro p hp
  have h : env27788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27787_27788 : H12AffineEnvironment.transform 14 8540 env27787 = env27788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27787 == env27788) = true)

theorem identity27788 : scanCanonicalize (H12AffineFastState.compose env27788 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound27788 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,17665,32041,1025,8541,4160,112,17,2,8192,65,31005,5392,17665,22885,1365,21873,257,21793,5456,513]

theorem envBound27789 : H12AffineFastState.Bounded env27789 := by
  intro p hp
  have h : env27789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27788_27789 : H12AffineEnvironment.transform 16 17665 env27788 = env27789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env27788 == env27789) = true)

theorem identity27789 : scanCanonicalize (H12AffineFastState.compose env27789 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27789 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env27790 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,8202,16401,30777,273,8541,4160,112,17,2,8192,65,31005,4096,16401,22885,69,20577,257,20529,4160,513]

theorem envBound27790 : H12AffineFastState.Bounded env27790 := by
  intro p hp
  have h : env27790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27789_27790 : H12AffineEnvironment.transform 9 272 env27789 = env27790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27789 == env27790) = true)

theorem identity27790 : scanCanonicalize (H12AffineFastState.compose env27790 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound27790 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27791 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,8202,4096,10280,273,8541,4160,112,17,2,8192,65,10508,4096,4096,2420,69,112,257,32,4160,513]

theorem envBound27791 : H12AffineFastState.Bounded env27791 := by
  intro p hp
  have h : env27791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27790_27791 : H12AffineEnvironment.transform 13 4113 env27790 = env27791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env27790 == env27791) = true)

def env27792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4160,41260,17,41311,8193,65,171328,5392,17665,179513,1364,21873,257,21793,46093,513]

theorem envBound27792 : H12AffineFastState.Bounded env27792 := by
  intro p hp
  have h : env27792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27786_27792 : H12AffineEnvironment.transform 6 9 env27786 = env27792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27786 == env27792) = true)

theorem identity27792 : scanCanonicalize (H12AffineFastState.compose env27792 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27792 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env27793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4160,21872,17,21763,8193,65,157980,5392,17665,149861,1364,21873,257,21793,16465,513]

theorem envBound27793 : H12AffineFastState.Bounded env27793 := by
  intro p hp
  have h : env27793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27792_27793 : H12AffineEnvironment.transform 14 29788 env27792 = env27793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27792 == env27793) = true)

theorem identity27793 : scanCanonicalize (H12AffineFastState.compose env27793 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound27793 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env27794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,5392,32040,1025,29789,4160,21872,17,21763,8193,65,31756,5392,17665,23669,1364,21873,257,21793,16465,513]

theorem envBound27794 : H12AffineFastState.Bounded env27794 := by
  intro p hp
  have h : env27794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27793_27794 : H12AffineEnvironment.transform 16 5392 env27793 = env27794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env27793 == env27794) = true)

theorem identity27794 : scanCanonicalize (H12AffineFastState.compose env27794 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27794 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,5392,2420,1025,1,4160,8492,17,8543,8193,65,2128,5392,12637,10281,1364,8493,257,8573,13325,513]

theorem envBound27795 : H12AffineFastState.Bounded env27795 := by
  intro p hp
  have h : env27795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27794_27795 : H12AffineEnvironment.transform 13 13404 env27794 = env27795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27794 == env27795) = true)

def env27796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,16,98780,8328,65,4340845,5393,17665,179633,1500,4256860,257,21793,46212,74250]

theorem envBound27796 : H12AffineFastState.Bounded env27796 := by
  intro p hp
  have h : env27796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27783_27796 : H12AffineEnvironment.transform 20 4161 env27783 = env27796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27783 == env27796) = true)

theorem identity27796 : scanCanonicalize (H12AffineFastState.compose env27796 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound27796 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,95531,16,98780,8328,65,215366,5393,17665,179633,1500,98679,257,21793,46212,74250]

theorem envBound27797 : H12AffineFastState.Bounded env27797 := by
  intro p hp
  have h : env27797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27796_27797 : H12AffineEnvironment.transform 21 95531 env27796 = env27797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env27796 == env27797) = true)

def env27798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,95531,16,98644,8192,65,215366,5393,17665,179513,1364,98679,257,21793,46092,74250]

theorem envBound27798 : H12AffineFastState.Bounded env27798 := by
  intro p hp
  have h : env27798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27797_27798 : H12AffineEnvironment.transform 6 8 env27797 = env27798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27797 == env27798) = true)

theorem identity27798 : scanCanonicalize (H12AffineFastState.compose env27798 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27798 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4161,41340,16,21763,8192,65,171281,5393,17665,179513,1364,21792,257,21793,46092,63069]

theorem envBound27799 : H12AffineFastState.Bounded env27799 := by
  intro p hp
  have h : env27799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27798_27799 : H12AffineEnvironment.transform 15 54359 env27798 = env27799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27798 == env27799) = true)

def env27800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95531,16,98645,8193,65,215366,5393,17665,179512,1365,98679,257,21793,46093,74250]

theorem envBound27800 : H12AffineFastState.Bounded env27800 := by
  intro p hp
  have h : env27800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27797_27800 : H12AffineEnvironment.transform 6 9 env27797 = env27800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27797 == env27800) = true)

theorem identity27800 : scanCanonicalize (H12AffineFastState.compose env27800 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound27800 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27801 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32040,1025,32769,4161,32,16,62558,8193,65,146509,5393,17665,179512,1365,62588,257,21793,46093,22273]

theorem envBound27801 : H12AffineFastState.Bounded env27801 := by
  intro p hp
  have h : env27801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27800_27801 : H12AffineEnvironment.transform 15 29963 env27800 = env27801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env27800 == env27801) = true)

theorem identity27801 : scanCanonicalize (H12AffineFastState.compose env27801 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound27801 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env27802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,46157,32040,1025,32769,4161,32,16,62558,8193,65,34816,5393,17665,2421,1365,62588,257,21793,46093,22273]

theorem envBound27802 : H12AffineFastState.Bounded env27802 := by
  intro p hp
  have h : env27802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27801_27802 : H12AffineEnvironment.transform 16 46157 env27801 = env27802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env27801 == env27802) = true)

theorem identity27802 : scanCanonicalize (H12AffineFastState.compose env27802 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27802 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,16400,32040,1025,29788,4161,32,16,3,8193,65,31837,5393,17665,2421,1365,33,257,21793,16464,22273]

theorem envBound27803 : H12AffineFastState.Bounded env27803 := by
  intro p hp
  have h : env27803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27802_27803 : H12AffineEnvironment.transform 14 29789 env27802 = env27803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27802 == env27803) = true)

theorem identity27803 : scanCanonicalize (H12AffineFastState.compose env27803 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound27803 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21541,21875,16400,23888,1025,21540,4161,32,16,3,121,65,23589,5393,17665,2421,1365,33,257,21793,16464,22273]

theorem envBound27804 : H12AffineFastState.Bounded env27804 := by
  intro p hp
  have h : env27804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27803_27804 : H12AffineEnvironment.transform 12 120 env27803 = env27804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env27803 == env27804) = true)

theorem identity27804 : scanCanonicalize (H12AffineFastState.compose env27804 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27804 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27805 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,21541,21591,16400,23668,1025,21540,4161,32,16,3,121,65,23589,5173,17445,2129,1137,33,37,21509,16464,22053]

theorem envBound27805 : H12AffineFastState.Bounded env27805 := by
  intro p hp
  have h : env27805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27804_27805 : H12AffineEnvironment.transform 7 36 env27804 = env27805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27804 == env27805) = true)

theorem identity27805 : scanCanonicalize (H12AffineFastState.compose env27805 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27805 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27806 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21541,21511,16400,23588,1025,21540,4113,32,16,3,41,17,23589,5173,17445,2049,1057,33,37,21509,16384,22053]

theorem envBound27806 : H12AffineFastState.Bounded env27806 := by
  intro p hp
  have h : env27806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27805_27806 : H12AffineEnvironment.transform 5 16 env27805 = env27806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27805 == env27806) = true)

theorem identity27806 : scanCanonicalize (H12AffineFastState.compose env27806 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound27806 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env27807 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,2048,7205,7175,2064,5156,1025,7204,4113,32,16,3,41,17,5157,5173,3109,2049,1057,33,37,7173,2048,7717]

theorem envBound27807 : H12AffineFastState.Bounded env27807 := by
  intro p hp
  have h : env27807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27806_27807 : H12AffineEnvironment.transform 13 2048 env27806 = env27807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env27806 == env27807) = true)

def env27808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound27808 : H12AffineFastState.Bounded env27808 := by
  intro p hp
  have h : env27808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26529_27808 : H12AffineEnvironment.transform 29 155254785 env26529 = env27808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env26529 == env27808) = true)

def env27809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound27809 : H12AffineFastState.Bounded env27809 := by
  intro p hp
  have h : env27809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27808_27809 : H12AffineEnvironment.transform 25 64 env27808 = env27809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env27808 == env27809) = true)

def env27810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound27810 : H12AffineFastState.Bounded env27810 := by
  intro p hp
  have h : env27810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27809_27810 : H12AffineEnvironment.transform 26 30393344 env27809 = env27810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env27809 == env27810) = true)

def env27811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound27811 : H12AffineFastState.Bounded env27811 := by
  intro p hp
  have h : env27811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27810_27811 : H12AffineEnvironment.transform 18 1024 env27810 = env27811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env27810 == env27811) = true)

theorem identity27811 : scanCanonicalize (H12AffineFastState.compose env27811 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27811 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,8388608,16777216,8328,64,29843804,18949585,10507601,8806749,25240909,23160256,256,27354608,27337993,25166491]

theorem envBound27812 : H12AffineFastState.Bounded env27812 := by
  intro p hp
  have h : env27812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27811_27812 : H12AffineEnvironment.transform 14 8540 env27811 = env27812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27811 == env27812) = true)

def env27813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147456,16777216,8328,64,21307740,18949585,2233681,270685,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound27813 : H12AffineFastState.Bounded env27813 := by
  intro p hp
  have h : env27813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27812_27813 : H12AffineEnvironment.transform 22 147456 env27812 = env27813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env27812 == env27813) = true)

theorem identity27813 : scanCanonicalize (H12AffineFastState.compose env27813 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147610) := by decide +kernel

theorem selectedBound27813 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147456,147610,8328,64,4678086,2319691,2233681,270685,75223,6497626,256,2188650,2172307,513]

theorem envBound27814 : H12AffineFastState.Bounded env27814 := by
  intro p hp
  have h : env27814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27813_27814 : H12AffineEnvironment.transform 23 147610 env27813 = env27814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147610 env27813 == env27814) = true)

def env27815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147456,147610,8328,64,4409702,2319691,2233681,2557,75223,6497626,256,2188650,2172307,513]

theorem envBound27815 : H12AffineFastState.Bounded env27815 := by
  intro p hp
  have h : env27815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27814_27815 : H12AffineEnvironment.transform 17 10400 env27814 = env27815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27814 == env27815) = true)

def env27816 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147456,147610,8328,16,4409654,2319643,2233601,2477,75143,6497546,256,2188602,2172307,513]

theorem envBound27816 : H12AffineFastState.Bounded env27816 := by
  intro p hp
  have h : env27816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27815_27816 : H12AffineEnvironment.transform 5 16 env27815 = env27816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27815 == env27816) = true)

theorem identity27816 : scanCanonicalize (H12AffineFastState.compose env27816 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27816 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,1,65536,131072,2477,1024,0,2097152,4194304,147456,147610,389,16,4409654,2311190,2233601,2477,66698,6489095,256,2180151,2163870,513]

theorem envBound27817 : H12AffineFastState.Bounded env27817 := by
  intro p hp
  have h : env27817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27816_27817 : H12AffineEnvironment.transform 12 269 env27816 = env27817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27816 == env27817) = true)

theorem identity27817 : scanCanonicalize (H12AffineFastState.compose env27817 (packedSelected [0,1,3,5,7,8,9,12,16,18,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound27817 : packedSelected [0,1,3,5,7,8,9,12,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env27818 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,1,65536,131072,2477,1024,0,132352,4194304,147456,147610,389,16,4409654,82198,4097,2477,66698,4260103,256,213303,197022,513]

theorem envBound27818 : H12AffineFastState.Bounded env27818 := by
  intro p hp
  have h : env27818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27817_27818 : H12AffineEnvironment.transform 20 132352 env27817 = env27818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env27817 == env27818) = true)

theorem identity27818 : scanCanonicalize (H12AffineFastState.compose env27818 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27818 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env27819 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,131072,2340,1024,0,132352,4194304,147456,147475,268,16,4409654,82198,4097,2340,66563,4260103,256,213303,196887,513]

theorem envBound27819 : H12AffineFastState.Bounded env27819 := by
  intro p hp
  have h : env27819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27818_27819 : H12AffineEnvironment.transform 6 9 env27818 = env27819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27818 == env27819) = true)

theorem identity27819 : scanCanonicalize (H12AffineFastState.compose env27819 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27819 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env27820 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,16400,2340,1024,0,17680,4194304,16,3,268,16,4262182,82198,4097,2340,66563,4260103,256,65831,82183,513]

theorem envBound27820 : H12AffineFastState.Bounded env27820 := by
  intro p hp
  have h : env27820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27819_27820 : H12AffineEnvironment.transform 16 16400 env27819 = env27820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27819 == env27820) = true)

theorem identity27820 : scanCanonicalize (H12AffineFastState.compose env27820 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound27820 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27821 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,16400,2340,1024,0,17680,65830,16,3,268,16,2048,82198,4097,2340,66563,33,256,65831,82183,513]

theorem envBound27821 : H12AffineFastState.Bounded env27821 := by
  intro p hp
  have h : env27821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27820_27821 : H12AffineEnvironment.transform 21 65830 env27820 = env27821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env27820 == env27821) = true)

theorem identity27821 : scanCanonicalize (H12AffineFastState.compose env27821 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 20758) := by decide +kernel

theorem selectedBound27821 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27822 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,20758,16400,2340,1024,0,17680,20528,16,3,268,16,2048,4096,4097,2340,21781,33,256,20529,4113,513]

theorem envBound27822 : H12AffineFastState.Bounded env27822 := by
  intro p hp
  have h : env27822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27821_27822 : H12AffineEnvironment.transform 15 20758 env27821 = env27822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20758 env27821 == env27822) = true)

def env27823 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147456,147610,8328,17,4409655,2319642,2233600,2476,75142,6497547,256,2188603,2172307,513]

theorem envBound27823 : H12AffineFastState.Bounded env27823 := by
  intro p hp
  have h : env27823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27815_27823 : H12AffineEnvironment.transform 5 17 env27815 = env27823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27815 == env27823) = true)

theorem identity27823 : scanCanonicalize (H12AffineFastState.compose env27823 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound27823 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27824 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,82967,4194304,147456,147610,8328,17,4409655,139533,217367,2476,75142,4350236,256,8492,24964,513]

theorem envBound27824 : H12AffineFastState.Bounded env27824 := by
  intro p hp
  have h : env27824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27823_27824 : H12AffineEnvironment.transform 20 82967 env27823 = env27824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env27823 == env27824) = true)

theorem identity27824 : scanCanonicalize (H12AffineFastState.compose env27824 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound27824 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27825 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,82967,147505,147456,147610,8328,17,67846,139533,217367,2476,75142,8493,256,8492,24964,513]

theorem envBound27825 : H12AffineFastState.Bounded env27825 := by
  intro p hp
  have h : env27825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27824_27825 : H12AffineEnvironment.transform 21 147505 env27824 = env27825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env27824 == env27825) = true)

theorem identity27825 : scanCanonicalize (H12AffineFastState.compose env27825 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound27825 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27826 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,8322,131072,10400,1024,8460,25749,147505,147456,147610,8328,17,10628,139533,160149,2476,1284,8493,256,8492,24964,513]

theorem envBound27826 : H12AffineFastState.Bounded env27826 := by
  intro p hp
  have h : env27826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27825_27826 : H12AffineEnvironment.transform 15 8322 env27825 = env27826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env27825 == env27826) = true)

theorem identity27826 : scanCanonicalize (H12AffineFastState.compose env27826 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27826 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27827 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,263,131072,2341,1024,137,17680,147505,147456,147610,269,17,2049,131208,151568,2476,1284,168,256,169,16385,513]

theorem envBound27827 : H12AffineFastState.Bounded env27827 := by
  intro p hp
  have h : env27827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27826_27827 : H12AffineEnvironment.transform 12 389 env27826 = env27827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27826 == env27827) = true)

theorem identity27827 : scanCanonicalize (H12AffineFastState.compose env27827 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound27827 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env27828 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,136,263,16536,2341,1024,137,17680,169,152,2,269,17,2049,16400,4232,2476,1284,168,256,169,16385,513]

theorem envBound27828 : H12AffineFastState.Bounded env27828 := by
  intro p hp
  have h : env27828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27827_27828 : H12AffineEnvironment.transform 16 16536 env27827 = env27828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env27827 == env27828) = true)

theorem identity27828 : scanCanonicalize (H12AffineFastState.compose env27828 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound27828 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27829 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5292,136,263,5172,2341,1024,137,4540,169,152,2,269,17,2049,5308,4232,2476,1284,168,256,169,5293,513]

theorem envBound27829 : H12AffineFastState.Bounded env27829 := by
  intro p hp
  have h : env27829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27828_27829 : H12AffineEnvironment.transform 13 5292 env27828 = env27829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env27828 == env27829) = true)

theorem identity27829 : scanCanonicalize (H12AffineFastState.compose env27829 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27830 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,0,263,5172,2341,1024,1,4404,33,16,2,269,17,2049,5172,4096,2340,1284,32,256,33,5157,513]

theorem envBound27830 : H12AffineFastState.Bounded env27830 := by
  intro p hp
  have h : env27830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27829_27830 : H12AffineEnvironment.transform 6 8 env27829 = env27830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27829 == env27830) = true)

def env27831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147456,147610,8328,64,4409703,2319691,2233681,2556,75223,6497626,256,2188650,2172307,513]

theorem envBound27831 : H12AffineFastState.Bounded env27831 := by
  intro p hp
  have h : env27831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27814_27831 : H12AffineEnvironment.transform 17 10401 env27814 = env27831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27814 == env27831) = true)

theorem identity27831 : scanCanonicalize (H12AffineFastState.compose env27831 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27831 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10401,1024,8541,2097152,4194304,16,138,8328,64,4262263,2172251,2118977,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound27832 : H12AffineFastState.Bounded env27832 := by
  intro p hp
  have h : env27832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27831_27832 : H12AffineEnvironment.transform 16 16400 env27831 = env27832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27831 == env27832) = true)

theorem identity27832 : scanCanonicalize (H12AffineFastState.compose env27832 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27832 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10401,1024,8541,2097152,4194304,16,138,8328,64,4204925,2098513,2118977,2556,1501,6309184,256,2114912,2098585,513]

theorem envBound27833 : H12AffineFastState.Bounded env27833 := by
  intro p hp
  have h : env27833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27832_27833 : H12AffineEnvironment.transform 15 8202 env27832 = env27833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27832 == env27833) = true)

theorem identity27833 : scanCanonicalize (H12AffineFastState.compose env27833 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27833 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8540,8202,4096,10401,1024,8541,2097152,4194304,16,138,8328,64,4204925,2098513,2098513,2556,1501,6296912,256,2102640,2098585,513]

theorem envBound27834 : H12AffineFastState.Bounded env27834 := by
  intro p hp
  have h : env27834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27833_27834 : H12AffineEnvironment.transform 13 4112 env27833 = env27834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27833 == env27834) = true)

theorem identity27834 : scanCanonicalize (H12AffineFastState.compose env27834 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5592) := by decide +kernel

theorem selectedBound27834 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8540,8202,4096,10401,1024,8541,5592,4194304,16,138,8328,64,4204925,4233,4233,2556,1501,4194440,256,168,4161,513]

theorem envBound27835 : H12AffineFastState.Bounded env27835 := by
  intro p hp
  have h : env27835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27834_27835 : H12AffineEnvironment.transform 20 5592 env27834 = env27835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5592 env27834 == env27835) = true)

theorem identity27835 : scanCanonicalize (H12AffineFastState.compose env27835 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound27835 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env27836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8540,8202,4096,10401,1024,8541,5592,248,16,138,8328,64,10629,4233,4233,2556,1501,112,256,168,4161,513]

theorem envBound27836 : H12AffineFastState.Bounded env27836 := by
  intro p hp
  have h : env27836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27835_27836 : H12AffineEnvironment.transform 21 248 env27835 = env27836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env27835 == env27836) = true)

theorem identity27836 : scanCanonicalize (H12AffineFastState.compose env27836 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7585) := by decide +kernel

theorem selectedBound27836 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env27837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7585,4112,7421,7595,4096,5376,1024,7420,5592,248,16,138,7465,64,5156,4233,4233,2556,1501,112,256,168,4161,513]

theorem envBound27837 : H12AffineFastState.Bounded env27837 := by
  intro p hp
  have h : env27837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27836_27837 : H12AffineEnvironment.transform 12 7585 env27836 = env27837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7585 env27836 == env27837) = true)

theorem identity27837 : scanCanonicalize (H12AffineFastState.compose env27837 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound27837 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env27838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1360,2289,1344,2477,2299,1360,80,1024,2476,136,248,16,138,2169,64,372,1497,1497,2556,1501,112,256,168,1297,513]

theorem envBound27838 : H12AffineFastState.Bounded env27838 := by
  intro p hp
  have h : env27838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27837_27838 : H12AffineEnvironment.transform 11 1360 env27837 = env27838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env27837 == env27838) = true)

theorem identity27838 : scanCanonicalize (H12AffineFastState.compose env27838 (packedSelected [1,2,3,5,6,8,11,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27838 : packedSelected [1,2,3,5,6,8,11,15,23] rootPS < 2^1333 := by decide +kernel

def env27839 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,309,2289,293,2477,2299,309,80,101,2476,136,248,16,138,2169,64,372,444,444,2556,440,112,256,168,372,513]

theorem envBound27839 : H12AffineFastState.Bounded env27839 := by
  intro p hp
  have h : env27839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27838_27839 : H12AffineEnvironment.transform 9 101 env27838 = env27839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27838 == env27839) = true)

theorem identity27839 : scanCanonicalize (H12AffineFastState.compose env27839 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound27839 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27840 : List Nat := [2,4,8,16,32,64,128,256,512,101,136,309,121,293,293,115,309,80,101,292,136,248,16,138,241,64,372,444,444,372,440,112,256,168,372,513]

theorem envBound27840 : H12AffineFastState.Bounded env27840 := by
  intro p hp
  have h : env27840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27839_27840 : H12AffineEnvironment.transform 10 136 env27839 = env27840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env27839 == env27840) = true)

theorem identity27840 : scanCanonicalize (H12AffineFastState.compose env27840 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound27840 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27841 : List Nat := [2,4,8,16,32,64,88,256,512,101,80,309,121,293,293,115,309,80,101,292,80,32,16,82,41,64,372,356,356,372,352,112,256,112,372,513]

theorem envBound27841 : H12AffineFastState.Bounded env27841 := by
  intro p hp
  have h : env27841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27840_27841 : H12AffineEnvironment.transform 6 88 env27840 = env27841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env27840 == env27841) = true)

theorem identity27841 : scanCanonicalize (H12AffineFastState.compose env27841 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27841 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27842 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,309,41,293,293,35,309,0,53,292,0,32,16,2,41,16,292,308,308,292,304,32,256,32,292,513]

theorem envBound27842 : H12AffineFastState.Bounded env27842 := by
  intro p hp
  have h : env27842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27841_27842 : H12AffineEnvironment.transform 5 16 env27841 = env27842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27841 == env27842) = true)

theorem identity27842 : scanCanonicalize (H12AffineFastState.compose env27842 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27842 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27843 : List Nat := [2,4,8,16,16,16,8,256,512,5,0,261,25,277,277,19,261,0,5,276,0,16,16,2,25,16,276,260,260,276,256,16,256,16,276,513]

theorem envBound27843 : H12AffineFastState.Bounded env27843 := by
  intro p hp
  have h : env27843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27842_27843 : H12AffineEnvironment.transform 4 16 env27842 = env27843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27842 == env27843) = true)

theorem identity27843 : scanCanonicalize (H12AffineFastState.compose env27843 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27844 : List Nat := [2,4,8,16,16,16,8,21,512,5,0,16,25,0,0,19,16,0,5,1,0,16,16,2,25,16,1,17,17,1,21,16,21,16,1,513]

theorem envBound27844 : H12AffineFastState.Bounded env27844 := by
  intro p hp
  have h : env27844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27843_27844 : H12AffineEnvironment.transform 7 21 env27843 = env27844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27843 == env27844) = true)

theorem identity27844 : scanCanonicalize (H12AffineFastState.compose env27844 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27845 : List Nat := [2,4,8,16,16,16,8,21,1,5,0,16,25,0,0,19,16,0,5,1,0,16,16,2,25,16,1,17,17,1,21,16,21,16,1,0]

theorem envBound27845 : H12AffineFastState.Bounded env27845 := by
  intro p hp
  have h : env27845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27844_27845 : H12AffineEnvironment.transform 8 1 env27844 = env27845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27844 == env27845) = true)

def env27846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147457,16777216,8328,64,21307741,18949585,2233680,270684,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound27846 : H12AffineFastState.Bounded env27846 := by
  intro p hp
  have h : env27846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27812_27846 : H12AffineEnvironment.transform 22 147457 env27812 = env27846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env27812 == env27846) = true)

def env27847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147457,16777216,8328,64,21039613,18949585,2233680,2556,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound27847 : H12AffineFastState.Bounded env27847 := by
  intro p hp
  have h : env27847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27846_27847 : H12AffineEnvironment.transform 17 10400 env27846 = env27847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27846 == env27847) = true)

theorem identity27847 : scanCanonicalize (H12AffineFastState.compose env27847 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 147611) := by decide +kernel

theorem selectedBound27847 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147457,147611,8328,64,4409702,2319690,2233680,2556,75223,6497627,256,2188650,2172307,513]

theorem envBound27848 : H12AffineFastState.Bounded env27848 := by
  intro p hp
  have h : env27848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27847_27848 : H12AffineEnvironment.transform 23 147611 env27847 = env27848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147611 env27847 == env27848) = true)

def env27849 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147457,147611,8328,16,4409654,2319642,2233600,2476,75143,6497547,256,2188602,2172307,513]

theorem envBound27849 : H12AffineFastState.Bounded env27849 := by
  intro p hp
  have h : env27849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27848_27849 : H12AffineEnvironment.transform 5 16 env27848 = env27849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27848 == env27849) = true)

theorem identity27849 : scanCanonicalize (H12AffineFastState.compose env27849 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 2180286) := by decide +kernel

theorem selectedBound27849 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27850 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,2180286,147457,147611,8328,16,2231688,2319642,2233600,2476,75143,156085,256,2188602,2172307,513]

theorem envBound27850 : H12AffineFastState.Bounded env27850 := by
  intro p hp
  have h : env27850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27849_27850 : H12AffineEnvironment.transform 21 2180286 env27849 = env27850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2180286 env27849 == env27850) = true)

theorem identity27850 : scanCanonicalize (H12AffineFastState.compose env27850 (packedSelected [3,4,5,11,14,15,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound27850 : packedSelected [3,4,5,11,14,15,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27851 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,131072,10400,1024,8461,2097152,2114864,147457,147611,8328,16,2231688,2253972,2233600,2476,9225,156085,256,2122932,2106397,513]

theorem envBound27851 : H12AffineFastState.Bounded env27851 := by
  intro p hp
  have h : env27851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27850_27851 : H12AffineEnvironment.transform 15 398 env27850 = env27851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env27850 == env27851) = true)

theorem identity27851 : scanCanonicalize (H12AffineFastState.compose env27851 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27851 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,16401,10400,1024,8461,2097152,2114864,16,138,8328,16,2117017,2106501,2118929,2476,9225,8612,256,2122932,2106397,513]

theorem envBound27852 : H12AffineFastState.Bounded env27852 := by
  intro p hp
  have h : env27852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27851_27852 : H12AffineEnvironment.transform 16 16401 env27851 = env27852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27851 == env27852) = true)

theorem identity27852 : scanCanonicalize (H12AffineFastState.compose env27852 (packedSelected [0,1,7,8,10,11,14,15,17] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound27852 : packedSelected [0,1,7,8,10,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env27853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,398,16401,10400,1024,8461,25628,8492,16,138,8328,16,10629,16537,12557,2476,9225,8612,256,168,16385,513]

theorem envBound27853 : H12AffineFastState.Bounded env27853 := by
  intro p hp
  have h : env27853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27852_27853 : H12AffineEnvironment.transform 20 25628 env27852 = env27853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env27852 == env27853) = true)

theorem identity27853 : scanCanonicalize (H12AffineFastState.compose env27853 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27853 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27854 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,137,398,16401,2341,1024,136,17817,169,16,138,269,16,2048,16537,4232,2476,1420,33,256,168,16385,513]

theorem envBound27854 : H12AffineFastState.Bounded env27854 := by
  intro p hp
  have h : env27854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27853_27854 : H12AffineEnvironment.transform 12 389 env27853 = env27854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27853 == env27854) = true)

def env27855 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147457,147611,8328,17,4409655,2319643,2233601,2477,75142,6497546,256,2188603,2172307,513]

theorem envBound27855 : H12AffineFastState.Bounded env27855 := by
  intro p hp
  have h : env27855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27848_27855 : H12AffineEnvironment.transform 5 17 env27848 = env27855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27848 == env27855) = true)

theorem identity27855 : scanCanonicalize (H12AffineFastState.compose env27855 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound27855 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27856 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,8613,147457,147611,8328,17,223378,2319643,2233601,2477,75142,2294959,256,2188603,2172307,513]

theorem envBound27856 : H12AffineFastState.Bounded env27856 := by
  intro p hp
  have h : env27856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27855_27856 : H12AffineEnvironment.transform 21 8613 env27855 = env27856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env27855 == env27856) = true)

theorem identity27856 : scanCanonicalize (H12AffineFastState.compose env27856 (packedSelected [0,2,3,4,5,6,7,9,11,15,16,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 197774) := by decide +kernel

theorem selectedBound27856 : packedSelected [0,2,3,4,5,6,7,9,11,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env27857 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,197774,8613,147457,147611,8328,17,223378,24981,70031,2477,75142,33,256,156085,139549,513]

theorem envBound27857 : H12AffineFastState.Bounded env27857 := by
  intro p hp
  have h : env27857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27856_27857 : H12AffineEnvironment.transform 20 197774 env27856 = env27857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197774 env27856 == env27857) = true)

theorem identity27857 : scanCanonicalize (H12AffineFastState.compose env27857 (packedSelected [0,1,2,4,6,7,8,9,10,12,16,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound27857 : packedSelected [0,1,2,4,6,7,8,9,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,82199,10400,1024,8460,17817,8613,65814,65932,8328,17,10629,24981,70031,2477,75142,33,256,73890,90122,513]

theorem envBound27858 : H12AffineFastState.Bounded env27858 := by
  intro p hp
  have h : env27858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27857_27858 : H12AffineEnvironment.transform 16 82199 env27857 = env27858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env27857 == env27858) = true)

def env27859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147457,16777216,8328,64,21039612,18949585,2233680,2557,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound27859 : H12AffineFastState.Bounded env27859 := by
  intro p hp
  have h : env27859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27846_27859 : H12AffineEnvironment.transform 17 10401 env27846 = env27859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27846 == env27859) = true)

theorem identity27859 : scanCanonicalize (H12AffineFastState.compose env27859 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound27859 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,2097152,4194304,147457,138,8328,64,4262262,2172251,2233680,2557,222662,6382922,256,2303355,2319746,147984]

theorem envBound27860 : H12AffineFastState.Bounded env27860 := by
  intro p hp
  have h : env27860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27859_27860 : H12AffineEnvironment.transform 23 138 env27859 = env27860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env27859 == env27860) = true)

def env27861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147457,2,8192,64,4262262,2172251,2233680,2421,222542,6382922,256,2303355,2319626,147984]

theorem envBound27861 : H12AffineFastState.Bounded env27861 := by
  intro p hp
  have h : env27861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27860_27861 : H12AffineEnvironment.transform 6 8 env27860 = env27861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27860 == env27861) = true)

theorem identity27861 : scanCanonicalize (H12AffineFastState.compose env27861 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound27861 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env27862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,17461,4194304,147457,2,8192,64,4262262,90478,151909,2421,222542,4268415,256,221518,205119,147984]

theorem envBound27862 : H12AffineFastState.Bounded env27862 := by
  intro p hp
  have h : env27862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27861_27862 : H12AffineEnvironment.transform 20 17461 env27861 = env27862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env27861 == env27862) = true)

theorem identity27862 : scanCanonicalize (H12AffineFastState.compose env27862 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound27862 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env27863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1024,8541,17461,4194304,73755,2,8192,64,4262262,90478,78207,2421,1364,4268415,256,340,16677,74250]

theorem envBound27863 : H12AffineFastState.Bounded env27863 := by
  intro p hp
  have h : env27863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27862_27863 : H12AffineEnvironment.transform 16 90138 env27862 = env27863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env27862 == env27863) = true)

theorem identity27863 : scanCanonicalize (H12AffineFastState.compose env27863 (packedSelected [1,3,4,5,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound27863 : packedSelected [1,3,4,5,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env27864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1024,8541,17461,260,73755,2,8192,64,67698,90478,78207,2421,1364,73851,256,340,16677,74250]

theorem envBound27864 : H12AffineFastState.Bounded env27864 := by
  intro p hp
  have h : env27864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27863_27864 : H12AffineEnvironment.transform 21 260 env27863 = env27864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env27863 == env27864) = true)

theorem identity27864 : scanCanonicalize (H12AffineFastState.compose env27864 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27864 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,65536,82247,2420,1024,0,17461,260,65862,2,349,64,67698,81971,69666,2421,1364,65830,256,340,16677,66391]

theorem envBound27865 : H12AffineFastState.Bounded env27865 := by
  intro p hp
  have h : env27865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27864_27865 : H12AffineEnvironment.transform 12 349 env27864 = env27865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27864 == env27865) = true)

theorem identity27865 : scanCanonicalize (H12AffineFastState.compose env27865 (packedSelected [1,4,8,9,14,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27865 : packedSelected [1,4,8,9,14,19,20] rootPS < 2^1333 := by decide +kernel

def env27866 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,1,65536,82019,2128,1024,0,17461,32,65634,2,121,64,67698,81971,69666,2129,1136,65538,36,112,16385,66163]

theorem envBound27866 : H12AffineFastState.Bounded env27866 := by
  intro p hp
  have h : env27866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27865_27866 : H12AffineEnvironment.transform 7 36 env27865 = env27866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27865 == env27866) = true)

def env27867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,2097152,4194304,147457,3,8193,64,4262262,2172251,2233680,2420,222543,6382922,256,2303355,2319627,147984]

theorem envBound27867 : H12AffineFastState.Bounded env27867 := by
  intro p hp
  have h : env27867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27860_27867 : H12AffineEnvironment.transform 6 9 env27860 = env27867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27860 == env27867) = true)

theorem identity27867 : scanCanonicalize (H12AffineFastState.compose env27867 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound27867 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,2097152,4194304,73755,3,8193,64,4262262,2172251,2192714,2420,1365,6382922,256,2114913,2098449,74250]

theorem envBound27868 : H12AffineFastState.Bounded env27868 := by
  intro p hp
  have h : env27868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27867_27868 : H12AffineEnvironment.transform 16 90138 env27867 = env27868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env27867 == env27868) = true)

theorem identity27868 : scanCanonicalize (H12AffineFastState.compose env27868 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound27868 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env27869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,2097152,65911,73755,3,8193,64,2049,2172251,2192714,2420,1365,2122813,256,2114913,2098449,74250]

theorem envBound27869 : H12AffineFastState.Bounded env27869 := by
  intro p hp
  have h : env27869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27868_27869 : H12AffineEnvironment.transform 21 65911 env27868 = env27869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env27868 == env27869) = true)

theorem identity27869 : scanCanonicalize (H12AffineFastState.compose env27869 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27869 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,65536,82246,2420,1024,1,2097152,65911,65863,3,349,64,2049,2163719,2184214,2420,1365,2114913,256,2114913,2098449,66390]

theorem envBound27870 : H12AffineFastState.Bounded env27870 := by
  intro p hp
  have h : env27870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27869_27870 : H12AffineEnvironment.transform 12 348 env27869 = env27870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27869 == env27870) = true)

theorem identity27870 : scanCanonicalize (H12AffineFastState.compose env27870 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 20806) := by decide +kernel

theorem selectedBound27870 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env27871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,20806,4096,2420,1024,1,2097152,20529,20481,3,349,64,2049,2118977,2098512,2420,1365,2114913,256,2114913,2098449,21008]

theorem envBound27871 : H12AffineFastState.Bounded env27871 := by
  intro p hp
  have h : env27871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27870_27871 : H12AffineEnvironment.transform 15 20806 env27870 = env27871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20806 env27870 == env27871) = true)

theorem identity27871 : scanCanonicalize (H12AffineFastState.compose env27871 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound27871 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env27872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,20806,4096,2420,1024,1,17728,20529,20481,3,349,64,2049,4097,16400,2420,1365,33,256,33,16465,21008]

theorem envBound27872 : H12AffineFastState.Bounded env27872 := by
  intro p hp
  have h : env27872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27871_27872 : H12AffineEnvironment.transform 20 17728 env27871 = env27872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env27871 == env27872) = true)

theorem identity27872 : scanCanonicalize (H12AffineFastState.compose env27872 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27872 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,1094,4096,2420,1024,1,4160,1329,1281,3,349,64,2049,4097,5392,2420,1365,33,256,33,5457,1808]

theorem envBound27873 : H12AffineFastState.Bounded env27873 := by
  intro p hp
  have h : env27873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27872_27873 : H12AffineEnvironment.transform 13 5376 env27872 = env27873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27872 == env27873) = true)

theorem identity27873 : scanCanonicalize (H12AffineFastState.compose env27873 (packedSelected [6,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound27873 : packedSelected [6,11,14] rootPS < 2^1333 := by decide +kernel

def env27874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,276,348,1044,0,1094,276,2420,1024,1,340,1329,1281,3,349,64,2049,277,1028,2420,1365,33,256,33,1093,1808]

theorem envBound27874 : H12AffineFastState.Bounded env27874 := by
  intro p hp
  have h : env27874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27873_27874 : H12AffineEnvironment.transform 11 276 env27873 = env27874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env27873 == env27874) = true)

theorem identity27874 : scanCanonicalize (H12AffineFastState.compose env27874 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound27874 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env27875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1329,276,348,1044,0,1094,276,1093,1024,1,340,1329,1281,3,349,64,1328,277,1028,1093,1365,33,256,33,1093,1808]

theorem envBound27875 : H12AffineFastState.Bounded env27875 := by
  intro p hp
  have h : env27875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27874_27875 : H12AffineEnvironment.transform 10 1329 env27874 = env27875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env27874 == env27875) = true)

theorem identity27875 : scanCanonicalize (H12AffineFastState.compose env27875 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound27875 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env27876 : List Nat := [2,4,8,16,32,64,9,256,49,1024,1329,276,348,1044,0,1094,276,1093,1024,1,340,1329,1281,3,349,64,1328,277,1028,1093,1365,33,256,33,1093,1313]

theorem envBound27876 : H12AffineFastState.Bounded env27876 := by
  intro p hp
  have h : env27876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27875_27876 : H12AffineEnvironment.transform 8 49 env27875 = env27876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env27875 == env27876) = true)

theorem identity27876 : scanCanonicalize (H12AffineFastState.compose env27876 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound27876 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env27877 : List Nat := [2,4,8,16,32,64,9,256,49,69,372,276,348,81,0,3,276,0,69,1,340,372,324,3,349,64,373,277,65,0,272,33,256,33,0,356]

theorem envBound27877 : H12AffineFastState.Bounded env27877 := by
  intro p hp
  have h : env27877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27876_27877 : H12AffineEnvironment.transform 9 69 env27876 = env27877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env27876 == env27877) = true)

theorem identity27877 : scanCanonicalize (H12AffineFastState.compose env27877 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27877 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env27878 : List Nat := [2,4,8,16,17,64,9,256,0,69,325,276,348,81,0,3,276,0,69,1,340,325,324,3,349,64,324,277,65,0,272,16,256,16,0,341]

theorem envBound27878 : H12AffineFastState.Bounded env27878 := by
  intro p hp
  have h : env27878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27877_27878 : H12AffineEnvironment.transform 4 17 env27877 = env27878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27877 == env27878) = true)

theorem identity27878 : scanCanonicalize (H12AffineFastState.compose env27878 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

end H12CloudChart0