import H12CloudChart0Data146

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans37279_37280 : H12AffineEnvironment.transform 17 76079 env37279 = env37280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env37279 == env37280) = true)

theorem identity37280 : scanCanonicalize (H12AffineFastState.compose env37280 (packedSelected [1,3,10,24,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 12692) := by decide +kernel

theorem selectedBound37280 : packedSelected [1,3,10,24,28,31] rootPS < 2^1333 := by decide +kernel

def env37281 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70679,76079,1025,29829,12692,65966,8597,95496,8328,16,89231,13461,17665,10280,9224,73890,257,21792,16384,66447]

theorem envBound37281 : H12AffineFastState.Bounded env37281 := by
  intro p hp
  have h : env37281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37280_37281 : H12AffineEnvironment.transform 20 12692 env37280 = env37281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12692 env37280 == env37281) = true)

theorem identity37281 : scanCanonicalize (H12AffineFastState.compose env37281 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37281 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env37282 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,16384,27796,65536,68615,76079,1025,27797,10628,65966,8597,93464,8328,16,83103,11397,17665,10280,9224,73890,257,19760,16384,66447]

theorem envBound37282 : H12AffineFastState.Bounded env37282 := by
  intro p hp
  have h : env37282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37281_37282 : H12AffineEnvironment.transform 11 2064 env37281 = env37282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37281 == env37282) = true)

theorem identity37282 : scanCanonicalize (H12AffineFastState.compose env37282 (packedSelected [0,1,4,7,8,10,11,12,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 11326) := by decide +kernel

theorem selectedBound37282 : packedSelected [0,1,4,7,8,10,11,12,18,22] rootPS < 2^1333 := by decide +kernel

def env37283 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,16384,27796,11326,8249,1297,1025,27797,10628,11664,8597,16678,8328,16,26785,11397,17665,10280,9224,3228,257,19760,16384,12209]

theorem envBound37283 : H12AffineFastState.Bounded env37283 := by
  intro p hp
  have h : env37283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37282_37283 : H12AffineEnvironment.transform 15 11326 env37282 = env37283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11326 env37282 == env37283) = true)

theorem identity37283 : scanCanonicalize (H12AffineFastState.compose env37283 (packedSelected [0,1,2,6,7,8,11,12,15,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 8581) := by decide +kernel

theorem selectedBound37283 : packedSelected [0,1,2,6,7,8,11,12,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37284 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,8581,3345,11326,8249,1297,1025,3344,10628,11664,8597,8355,8328,16,2340,11397,9348,10280,9224,3228,257,11445,8581,12209]

theorem envBound37284 : H12AffineFastState.Bounded env37284 := by
  intro p hp
  have h : env37284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37283_37284 : H12AffineEnvironment.transform 13 8581 env37283 = env37284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8581 env37283 == env37284) = true)

theorem identity37284 : scanCanonicalize (H12AffineFastState.compose env37284 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound37284 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env37285 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1296,1280,8192,8581,1,8494,8249,1297,1025,0,9364,8320,8597,8355,8328,16,1076,8597,9348,9528,9224,396,257,8613,8581,8865]

theorem envBound37285 : H12AffineFastState.Bounded env37285 := by
  intro p hp
  have h : env37285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37284_37285 : H12AffineEnvironment.transform 10 1296 env37284 = env37285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env37284 == env37285) = true)

theorem identity37285 : scanCanonicalize (H12AffineFastState.compose env37285 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound37285 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env37286 : List Nat := [2,4,8,16,32,16,128,256,512,408,136,152,8192,8581,1,8494,8249,137,409,0,8460,8320,8597,8355,8328,16,428,8597,8476,8352,8592,396,257,8613,8581,8865]

theorem envBound37286 : H12AffineFastState.Bounded env37286 := by
  intro p hp
  have h : env37286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37285_37286 : H12AffineEnvironment.transform 9 408 env37285 = env37286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env37285 == env37286) = true)

theorem identity37286 : scanCanonicalize (H12AffineFastState.compose env37286 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37286 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37287 : List Nat := [2,4,8,16,32,16,128,256,512,408,136,152,41,428,1,263,16,137,409,0,293,169,444,138,161,16,428,444,309,137,441,396,257,396,428,648]

theorem envBound37287 : H12AffineFastState.Bounded env37287 := by
  intro p hp
  have h : env37287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37286_37287 : H12AffineEnvironment.transform 12 41 env37286 = env37287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37286 == env37287) = true)

theorem identity37287 : scanCanonicalize (H12AffineFastState.compose env37287 (packedSelected [0,1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 167) := by decide +kernel

theorem selectedBound37287 : packedSelected [0,1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env37288 : List Nat := [2,4,8,16,32,16,128,256,167,408,136,152,41,428,1,263,16,137,409,0,293,169,444,138,161,16,428,444,309,137,441,396,257,396,428,47]

theorem envBound37288 : H12AffineFastState.Bounded env37288 := by
  intro p hp
  have h : env37288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37287_37288 : H12AffineEnvironment.transform 8 167 env37287 = env37288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 167 env37287 == env37288) = true)

theorem identity37288 : scanCanonicalize (H12AffineFastState.compose env37288 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37288 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env37289 : List Nat := [2,4,8,16,32,16,9,256,46,273,1,17,41,293,1,263,16,0,272,0,293,32,309,3,40,16,293,309,309,0,304,261,257,261,293,47]

theorem envBound37289 : H12AffineFastState.Bounded env37289 := by
  intro p hp
  have h : env37289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37288_37289 : H12AffineEnvironment.transform 6 9 env37288 = env37289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37288 == env37289) = true)

theorem identity37289 : scanCanonicalize (H12AffineFastState.compose env37289 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound37289 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37290 : List Nat := [2,4,8,16,32,16,9,1,46,16,1,17,41,36,1,6,16,0,17,0,36,32,52,3,40,16,36,52,52,0,49,4,0,4,36,47]

theorem envBound37290 : H12AffineFastState.Bounded env37290 := by
  intro p hp
  have h : env37290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37289_37290 : H12AffineEnvironment.transform 7 1 env37289 = env37290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env37289 == env37290) = true)

theorem identity37290 : scanCanonicalize (H12AffineFastState.compose env37290 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound37290 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env37291 : List Nat := [2,4,8,16,4,16,9,1,10,16,1,17,13,0,1,6,16,0,17,0,0,4,16,3,12,16,0,16,16,0,21,4,0,4,0,11]

theorem envBound37291 : H12AffineFastState.Bounded env37291 := by
  intro p hp
  have h : env37291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37290_37291 : H12AffineEnvironment.transform 4 4 env37290 = env37291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env37290 == env37291) = true)

theorem identity37291 : scanCanonicalize (H12AffineFastState.compose env37291 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37292 : List Nat := [2,4,3,16,4,16,2,1,1,16,1,17,6,0,1,6,16,0,17,0,0,4,16,3,7,16,0,16,16,0,21,4,0,4,0,0]

theorem envBound37292 : H12AffineFastState.Bounded env37292 := by
  intro p hp
  have h : env37292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37291_37292 : H12AffineEnvironment.transform 2 3 env37291 = env37292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37291 == env37292) = true)

theorem identity37292 : scanCanonicalize (H12AffineFastState.compose env37292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound37292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37293 : List Nat := [2,4,3,2,4,2,2,1,1,2,1,3,6,0,1,6,2,0,3,0,0,4,2,3,7,2,0,2,2,0,7,4,0,4,0,0]

theorem envBound37293 : H12AffineFastState.Bounded env37293 := by
  intro p hp
  have h : env37293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37292_37293 : H12AffineEnvironment.transform 3 2 env37292 = env37293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env37292 == env37293) = true)

theorem identity37293 : scanCanonicalize (H12AffineFastState.compose env37293 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37294 : List Nat := [2,0,3,2,0,2,2,1,1,2,1,3,2,0,1,2,2,0,3,0,0,0,2,3,3,2,0,2,2,0,3,0,0,0,0,0]

theorem envBound37294 : H12AffineFastState.Bounded env37294 := by
  intro p hp
  have h : env37294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37293_37294 : H12AffineEnvironment.transform 1 0 env37293 = env37294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37293 == env37294) = true)

theorem identity37294 : scanCanonicalize (H12AffineFastState.compose env37294 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37294 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37295 : List Nat := [0,0,1,0,0,0,0,1,1,0,1,1,0,0,1,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,0,0]

theorem envBound37295 : H12AffineFastState.Bounded env37295 := by
  intro p hp
  have h : env37295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37294_37295 : H12AffineEnvironment.transform 0 0 env37294 = env37295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37294 == env37295) = true)

def env37296 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70678,262144,1025,29828,2097152,272513,2101248,95496,8328,17,2190618,2098432,17665,2437266,2102684,2373656,257,21792,16385,2175514]

theorem envBound37296 : H12AffineFastState.Bounded env37296 := by
  intro p hp
  have h : env37296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37278_37296 : H12AffineEnvironment.transform 5 17 env37278 = env37296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37278 == env37296) = true)

theorem identity37296 : scanCanonicalize (H12AffineFastState.compose env37296 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37296 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env37297 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,65536,70678,262144,1025,21896,2097152,264589,2101248,87044,388,17,2182166,2098432,17665,2429342,2102684,2365716,257,21792,16385,2167574]

theorem envBound37297 : H12AffineFastState.Bounded env37297 := by
  intro p hp
  have h : env37297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37296_37297 : H12AffineEnvironment.transform 12 268 env37296 = env37297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37296 == env37297) = true)

theorem identity37297 : scanCanonicalize (H12AffineFastState.compose env37297 (packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 69911) := by decide +kernel

theorem selectedBound37297 : packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37298 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,65536,70678,262144,1025,21896,69911,264589,65815,87044,388,17,23809,70679,17665,262281,66699,329731,257,21792,16385,513]

theorem envBound37298 : H12AffineFastState.Bounded env37298 := by
  intro p hp
  have h : env37298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37297_37298 : H12AffineEnvironment.transform 20 69911 env37297 = env37298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69911 env37297 == env37298) = true)

theorem identity37298 : scanCanonicalize (H12AffineFastState.compose env37298 (packedSelected [0,2,6,7,9,14,16,17,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound37298 : packedSelected [0,2,6,7,9,14,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env37299 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5512,1,65536,70678,262144,1025,0,69911,264589,65815,65932,388,17,2185,70679,4233,262281,66699,329731,257,168,5513,513]

theorem envBound37299 : H12AffineFastState.Bounded env37299 := by
  intro p hp
  have h : env37299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37298_37299 : H12AffineEnvironment.transform 13 5512 env37298 = env37299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env37298 == env37299) = true)

theorem identity37299 : scanCanonicalize (H12AffineFastState.compose env37299 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37299 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env37300 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,65536,70678,262144,1025,0,69911,264452,65815,65797,269,17,2048,70679,4096,262144,66562,329731,257,33,5376,513]

theorem envBound37300 : H12AffineFastState.Bounded env37300 := by
  intro p hp
  have h : env37300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37299_37300 : H12AffineEnvironment.transform 6 9 env37299 = env37300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37299 == env37300) = true)

theorem identity37300 : scanCanonicalize (H12AffineFastState.compose env37300 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound37300 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37301 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,65536,70678,67619,1025,0,69911,65831,65815,65797,269,17,2048,70679,4096,67619,66562,32,257,33,5376,513]

theorem envBound37301 : H12AffineFastState.Bounded env37301 := by
  intro p hp
  have h : env37301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37300_37301 : H12AffineEnvironment.transform 17 67619 env37300 = env37301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env37300 == env37301) = true)

theorem identity37301 : scanCanonicalize (H12AffineFastState.compose env37301 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound37301 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37302 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1025,0,4113,33,17,3,269,17,2048,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound37302 : H12AffineFastState.Bounded env37302 := by
  intro p hp
  have h : env37302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37301_37302 : H12AffineEnvironment.transform 15 262 env37301 = env37302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env37301 == env37302) = true)

theorem identity37302 : scanCanonicalize (H12AffineFastState.compose env37302 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37303 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2049,1025,0,4113,33,17,3,41,17,2048,5173,4096,2049,1056,32,37,33,5156,513]

theorem envBound37303 : H12AffineFastState.Bounded env37303 := by
  intro p hp
  have h : env37303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37302_37303 : H12AffineEnvironment.transform 7 36 env37302 = env37303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37302 == env37303) = true)

theorem identity37303 : scanCanonicalize (H12AffineFastState.compose env37303 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37303 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37304 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5157,1,34,5172,522,1025,0,4113,33,17,3,41,17,523,5173,4096,522,1056,32,37,33,5156,513]

theorem envBound37304 : H12AffineFastState.Bounded env37304 := by
  intro p hp
  have h : env37304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37303_37304 : H12AffineEnvironment.transform 10 523 env37303 = env37304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37303 == env37304) = true)

theorem identity37304 : scanCanonicalize (H12AffineFastState.compose env37304 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37304 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37305 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,9,5124,1,3,5141,522,1025,0,4113,0,17,3,8,17,523,5140,4096,522,1025,1,4,0,5125,513]

theorem envBound37305 : H12AffineFastState.Bounded env37305 := by
  intro p hp
  have h : env37305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37304_37305 : H12AffineEnvironment.transform 4 1 env37304 = env37305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37304 == env37305) = true)

def env37306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound37306 : H12AffineFastState.Bounded env37306 := by
  intro p hp
  have h : env37306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36619_37306 : H12AffineEnvironment.transform 25 65 env36619 = env37306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env36619 == env37306) = true)

def env37307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound37307 : H12AffineFastState.Bounded env37307 := by
  intro p hp
  have h : env37307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37306_37307 : H12AffineEnvironment.transform 26 30393344 env37306 = env37307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env37306 == env37307) = true)

def env37308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound37308 : H12AffineFastState.Bounded env37308 := by
  intro p hp
  have h : env37308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37307_37308 : H12AffineEnvironment.transform 18 1024 env37307 = env37308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37307 == env37308) = true)

theorem identity37308 : scanCanonicalize (H12AffineFastState.compose env37308 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534898) := by decide +kernel

theorem selectedBound37308 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534898,8328,65,14773746,469374,10507601,8830977,10955234,4704307,256,8874335,8882427,10882613]

theorem envBound37309 : H12AffineFastState.Bounded env37309 := by
  intro p hp
  have h : env37309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37308_37309 : H12AffineEnvironment.transform 23 2534898 env37308 = env37309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534898 env37308 == env37309) = true)

def env37310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773746,115150,10507601,8399025,10600786,4268163,256,8487407,8478795,10544773]

theorem envBound37310 : H12AffineFastState.Bounded env37310 := by
  intro p hp
  have h : env37310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37309_37310 : H12AffineEnvironment.transform 17 190640 env37309 = env37310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env37309 == env37310) = true)

def env37311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,2114882,8328,65,4292002,115150,17665,2111713,119042,4268163,256,2199999,2191387,63189]

theorem envBound37311 : H12AffineFastState.Bounded env37311 := by
  intro p hp
  have h : env37311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37310_37311 : H12AffineEnvironment.transform 22 2101328 env37310 = env37311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env37310 == env37311) = true)

def env37312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,21762,8328,65,4292002,115150,17665,10401,119042,4268163,256,98815,90203,63189]

theorem envBound37312 : H12AffineFastState.Bounded env37312 := by
  intro p hp
  have h : env37312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37311_37312 : H12AffineEnvironment.transform 20 4160 env37311 = env37312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37311 == env37312) = true)

theorem identity37312 : scanCanonicalize (H12AffineFastState.compose env37312 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37312 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,4194304,16,21762,8328,65,4218281,57797,17665,10401,61705,4194440,256,41460,16464,63189]

theorem envBound37313 : H12AffineFastState.Bounded env37313 := by
  intro p hp
  have h : env37313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37312_37313 : H12AffineEnvironment.transform 15 8203 env37312 = env37313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37312 == env37313) = true)

theorem identity37313 : scanCanonicalize (H12AffineFastState.compose env37313 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37313 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,157872,1024,1,4160,4194304,16,21762,8328,65,4218281,25029,17665,10401,28937,4194440,256,8692,16464,30421]

theorem envBound37314 : H12AffineFastState.Bounded env37314 := by
  intro p hp
  have h : env37314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37313_37314 : H12AffineEnvironment.transform 14 0 env37313 = env37314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37313 == env37314) = true)

def env37315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,131072,157752,1024,1,4160,4194304,16,21762,8192,65,4218145,24909,17665,10281,28937,4194304,256,8572,16464,30301]

theorem envBound37315 : H12AffineFastState.Bounded env37315 := by
  intro p hp
  have h : env37315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37314_37315 : H12AffineEnvironment.transform 6 8 env37314 = env37315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37314 == env37315) = true)

theorem identity37315 : scanCanonicalize (H12AffineFastState.compose env37315 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound37315 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,24909,2421,1024,1,4160,4194304,16,21762,8192,65,4218145,24909,17665,10281,28937,4194304,256,8572,16464,30301]

theorem envBound37316 : H12AffineFastState.Bounded env37316 := by
  intro p hp
  have h : env37316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37315_37316 : H12AffineEnvironment.transform 16 24909 env37315 = env37316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env37315 == env37316) = true)

theorem identity37316 : scanCanonicalize (H12AffineFastState.compose env37316 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound37316 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env37317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,24909,2421,1024,1,4160,8572,16,21762,8192,65,31837,24909,17665,10281,28937,8572,256,8572,16464,30301]

theorem envBound37317 : H12AffineFastState.Bounded env37317 := by
  intro p hp
  have h : env37317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37316_37317 : H12AffineEnvironment.transform 21 8572 env37316 = env37317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env37316 == env37317) = true)

theorem identity37317 : scanCanonicalize (H12AffineFastState.compose env37317 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound37317 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env37318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13576,0,8203,5189,2421,1024,1,4160,8572,16,8202,8192,65,2389,5189,12297,10281,1025,8572,256,8572,13656,853]

theorem envBound37318 : H12AffineFastState.Bounded env37318 := by
  intro p hp
  have h : env37318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37317_37318 : H12AffineEnvironment.transform 13 13576 env37317 = env37318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env37317 == env37318) = true)

theorem identity37318 : scanCanonicalize (H12AffineFastState.compose env37318 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37318 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5205,0,342,5189,2421,1024,1,4160,33,16,343,349,65,2389,5189,4436,2420,1025,33,256,33,5125,853]

theorem envBound37319 : H12AffineFastState.Bounded env37319 := by
  intro p hp
  have h : env37319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37318_37319 : H12AffineEnvironment.transform 12 349 env37318 = env37319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37318 == env37319) = true)

theorem identity37319 : scanCanonicalize (H12AffineFastState.compose env37319 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37319 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37320 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5205,0,35,5189,2048,1024,1,4160,33,16,34,40,65,2080,5189,4129,2049,1025,33,117,33,5125,544]

theorem envBound37320 : H12AffineFastState.Bounded env37320 := by
  intro p hp
  have h : env37320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37319_37320 : H12AffineEnvironment.transform 7 117 env37319 = env37320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37319 == env37320) = true)

theorem identity37320 : scanCanonicalize (H12AffineFastState.compose env37320 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound37320 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37321 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4145,0,35,4129,2048,100,1,4160,33,16,34,40,65,2080,4129,4129,2049,101,33,117,33,4193,544]

theorem envBound37321 : H12AffineFastState.Bounded env37321 := by
  intro p hp
  have h : env37321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37320_37321 : H12AffineEnvironment.transform 9 100 env37320 = env37321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env37320 == env37321) = true)

theorem identity37321 : scanCanonicalize (H12AffineFastState.compose env37321 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound37321 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env37322 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,2113,40,2160,0,35,2144,2048,100,1,2049,33,16,34,40,65,2080,2144,2144,2049,101,33,117,33,2080,544]

theorem envBound37322 : H12AffineFastState.Bounded env37322 := by
  intro p hp
  have h : env37322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37321_37322 : H12AffineEnvironment.transform 11 2113 env37321 = env37322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env37321 == env37322) = true)

theorem identity37322 : scanCanonicalize (H12AffineFastState.compose env37322 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound37322 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37323 : List Nat := [2,4,8,16,32,64,8,117,512,100,560,625,40,576,0,35,592,560,100,1,561,33,16,34,40,65,528,592,592,561,101,33,117,33,528,544]

theorem envBound37323 : H12AffineFastState.Bounded env37323 := by
  intro p hp
  have h : env37323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37322_37323 : H12AffineEnvironment.transform 10 560 env37322 = env37323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env37322 == env37323) = true)

def env37324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,131072,157753,1024,1,4160,4194304,16,21762,8193,65,4218144,24908,17665,10280,28937,4194305,256,8573,16464,30300]

theorem envBound37324 : H12AffineFastState.Bounded env37324 := by
  intro p hp
  have h : env37324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37314_37324 : H12AffineEnvironment.transform 6 9 env37314 = env37324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37314 == env37324) = true)

theorem identity37324 : scanCanonicalize (H12AffineFastState.compose env37324 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10281,1024,1,4160,4194304,16,21762,8193,65,4218144,24908,17665,10280,28937,4194305,256,8573,16464,30300]

theorem envBound37325 : H12AffineFastState.Bounded env37325 := by
  intro p hp
  have h : env37325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37324_37325 : H12AffineEnvironment.transform 16 16400 env37324 = env37325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37324 == env37325) = true)

theorem identity37325 : scanCanonicalize (H12AffineFastState.compose env37325 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37325 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,13389,10281,1024,1,4160,4194304,16,8543,8193,65,4204925,5393,12636,10280,1364,4194305,256,8573,13325,513]

theorem envBound37326 : H12AffineFastState.Bounded env37326 := by
  intro p hp
  have h : env37326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37325_37326 : H12AffineEnvironment.transform 13 13405 env37325 = env37326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37325 == env37326) = true)

theorem identity37326 : scanCanonicalize (H12AffineFastState.compose env37326 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound37326 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,13389,10281,1024,1,4160,33,16,8543,8193,65,10588,5393,12636,10280,1364,32,256,8573,13325,513]

theorem envBound37327 : H12AffineFastState.Bounded env37327 := by
  intro p hp
  have h : env37327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37326_37327 : H12AffineEnvironment.transform 21 33 env37326 = env37327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env37326 == env37327) = true)

theorem identity37327 : scanCanonicalize (H12AffineFastState.compose env37327 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37327 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4160,33,16,2,348,65,2049,5393,4097,2421,1364,32,256,32,5456,513]

theorem envBound37328 : H12AffineFastState.Bounded env37328 := by
  intro p hp
  have h : env37328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37327_37328 : H12AffineEnvironment.transform 12 349 env37327 = env37328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37327 == env37328) = true)

theorem identity37328 : scanCanonicalize (H12AffineFastState.compose env37328 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37328 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37329 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4113,33,16,2,269,16,2049,5393,4097,2340,1285,32,256,32,5377,513]

theorem envBound37329 : H12AffineFastState.Bounded env37329 := by
  intro p hp
  have h : env37329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37328_37329 : H12AffineEnvironment.transform 5 17 env37328 = env37329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37328 == env37329) = true)

theorem identity37329 : scanCanonicalize (H12AffineFastState.compose env37329 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound37329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37330 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,268,1328,0,263,1312,2341,1024,1,33,33,16,2,269,16,2049,1313,49,2340,1285,32,256,32,1329,513]

theorem envBound37330 : H12AffineFastState.Bounded env37330 := by
  intro p hp
  have h : env37330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37329_37330 : H12AffineEnvironment.transform 11 48 env37329 = env37330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37329 == env37330) = true)

theorem identity37330 : scanCanonicalize (H12AffineFastState.compose env37330 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound37330 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37331 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1556,48,268,1328,0,263,1312,1841,1024,1,33,33,16,2,269,16,1557,1313,49,1840,1285,32,256,32,1329,513]

theorem envBound37331 : H12AffineFastState.Bounded env37331 := by
  intro p hp
  have h : env37331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37330_37331 : H12AffineEnvironment.transform 10 1556 env37330 = env37331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env37330 == env37331) = true)

theorem identity37331 : scanCanonicalize (H12AffineFastState.compose env37331 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound37331 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37332 : List Nat := [2,4,8,16,32,17,9,256,512,37,561,48,268,277,0,263,261,788,37,1,33,33,16,2,269,16,560,260,49,789,288,32,256,32,276,513]

theorem envBound37332 : H12AffineFastState.Bounded env37332 := by
  intro p hp
  have h : env37332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37331_37332 : H12AffineEnvironment.transform 9 37 env37331 = env37332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env37331 == env37332) = true)

theorem identity37332 : scanCanonicalize (H12AffineFastState.compose env37332 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound37332 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37333 : List Nat := [2,4,8,16,32,17,9,52,512,37,561,48,56,33,0,51,49,544,37,1,33,33,16,2,57,16,560,48,49,545,20,32,52,32,32,513]

theorem envBound37333 : H12AffineFastState.Bounded env37333 := by
  intro p hp
  have h : env37333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37332_37333 : H12AffineEnvironment.transform 7 52 env37332 = env37333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env37332 == env37333) = true)

theorem identity37333 : scanCanonicalize (H12AffineFastState.compose env37333 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound37333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37334 : List Nat := [2,4,8,16,32,17,9,52,43,37,26,48,56,33,0,51,49,11,37,1,33,33,16,2,57,16,27,48,49,10,20,32,52,32,32,42]

theorem envBound37334 : H12AffineFastState.Bounded env37334 := by
  intro p hp
  have h : env37334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37333_37334 : H12AffineEnvironment.transform 8 43 env37333 = env37334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env37333 == env37334) = true)

theorem identity37334 : scanCanonicalize (H12AffineFastState.compose env37334 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37334 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env37335 : List Nat := [2,4,2,16,32,17,3,52,33,37,16,48,50,33,0,51,49,1,37,1,33,33,16,2,51,16,17,48,49,0,20,32,52,32,32,32]

theorem envBound37335 : H12AffineFastState.Bounded env37335 := by
  intro p hp
  have h : env37335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37334_37335 : H12AffineEnvironment.transform 2 2 env37334 = env37335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37334 == env37335) = true)

theorem identity37335 : scanCanonicalize (H12AffineFastState.compose env37335 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37335 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env37336 : List Nat := [2,4,2,16,17,17,3,5,16,20,16,1,3,16,0,2,0,1,20,1,16,16,16,2,2,16,17,1,0,0,20,17,5,17,17,17]

theorem envBound37336 : H12AffineFastState.Bounded env37336 := by
  intro p hp
  have h : env37336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37335_37336 : H12AffineEnvironment.transform 4 17 env37335 = env37336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37335 == env37336) = true)

def env37337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,21763,8328,65,4292002,115150,17665,10400,119042,4268163,256,98814,90202,63189]

theorem envBound37337 : H12AffineFastState.Bounded env37337 := by
  intro p hp
  have h : env37337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37311_37337 : H12AffineEnvironment.transform 20 4161 env37311 = env37337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37311 == env37337) = true)

theorem identity37337 : scanCanonicalize (H12AffineFastState.compose env37337 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound37337 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,254011,17,21763,8328,65,171417,115150,17665,10400,119042,180408,256,98814,90202,63189]

theorem envBound37338 : H12AffineFastState.Bounded env37338 := by
  intro p hp
  have h : env37338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37337_37338 : H12AffineEnvironment.transform 21 254011 env37337 = env37338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env37337 == env37338) = true)

def env37339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254011,17,21763,8192,65,171281,115014,17665,10280,119042,180272,256,98678,90202,63069]

theorem envBound37339 : H12AffineFastState.Bounded env37339 := by
  intro p hp
  have h : env37339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37338_37339 : H12AffineEnvironment.transform 6 8 env37338 = env37339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37338 == env37339) = true)

theorem identity37339 : scanCanonicalize (H12AffineFastState.compose env37339 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37339 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149861,1024,8540,4161,213350,17,21763,8192,65,146508,90139,17665,10280,94303,156013,256,73771,90202,22272]

theorem envBound37340 : H12AffineFastState.Bounded env37340 := by
  intro p hp
  have h : env37340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37339_37340 : H12AffineEnvironment.transform 14 8541 env37339 = env37340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37339 == env37340) = true)

theorem identity37340 : scanCanonicalize (H12AffineFastState.compose env37340 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound37340 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,76159,1024,8540,4161,8572,17,21763,8192,65,89174,90139,17665,10280,94303,65911,256,73771,90202,22272]

theorem envBound37341 : H12AffineFastState.Bounded env37341 := by
  intro p hp
  have h : env37341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37340_37341 : H12AffineEnvironment.transform 16 90138 env37340 = env37341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env37340 == env37341) = true)

theorem identity37341 : scanCanonicalize (H12AffineFastState.compose env37341 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37341 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,24909,10280,1024,8540,4161,8572,17,21763,8192,65,23809,24908,17665,10280,28936,32,256,8572,24845,22272]

theorem envBound37342 : H12AffineFastState.Bounded env37342 := by
  intro p hp
  have h : env37342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37341_37342 : H12AffineEnvironment.transform 15 343 env37341 = env37342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37341 == env37342) = true)

theorem identity37342 : scanCanonicalize (H12AffineFastState.compose env37342 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound37342 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1296,343,17664,3173,1024,1297,4161,1329,17,21763,1101,65,23809,17665,17665,3173,21829,32,256,1329,17728,22272]

theorem envBound37343 : H12AffineFastState.Bounded env37343 := by
  intro p hp
  have h : env37343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37342_37343 : H12AffineEnvironment.transform 12 1101 env37342 = env37343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env37342 == env37343) = true)

theorem identity37343 : scanCanonicalize (H12AffineFastState.compose env37343 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37343 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37344 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,16384,0,343,16400,2421,272,1,4161,33,17,20499,349,65,22545,16401,16401,2421,20565,32,256,33,16464,21008]

theorem envBound37344 : H12AffineFastState.Bounded env37344 := by
  intro p hp
  have h : env37344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37343_37344 : H12AffineEnvironment.transform 9 272 env37343 = env37344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37343 == env37344) = true)

theorem identity37344 : scanCanonicalize (H12AffineFastState.compose env37344 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound37344 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37345 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4405,0,343,4389,2421,272,1,4161,33,17,294,349,65,2340,4388,4388,2421,352,32,256,33,4453,805]

theorem envBound37345 : H12AffineFastState.Bounded env37345 := by
  intro p hp
  have h : env37345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37344_37345 : H12AffineEnvironment.transform 13 4405 env37344 = env37345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env37344 == env37345) = true)

theorem identity37345 : scanCanonicalize (H12AffineFastState.compose env37345 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound37345 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37346 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,349,2128,0,343,2112,2421,272,1,2340,33,17,294,349,65,2340,2113,2113,2421,352,32,256,33,2048,805]

theorem envBound37346 : H12AffineFastState.Bounded env37346 := by
  intro p hp
  have h : env37346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37345_37346 : H12AffineEnvironment.transform 11 2405 env37345 = env37346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env37345 == env37346) = true)

theorem identity37346 : scanCanonicalize (H12AffineFastState.compose env37346 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37346 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37347 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2356,268,2049,0,262,2065,2340,272,1,2340,33,17,294,268,16,2340,2064,2064,2340,305,32,256,33,2048,805]

theorem envBound37347 : H12AffineFastState.Bounded env37347 := by
  intro p hp
  have h : env37347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37346_37347 : H12AffineEnvironment.transform 5 17 env37346 = env37347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37346 == env37347) = true)

theorem identity37347 : scanCanonicalize (H12AffineFastState.compose env37347 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37347 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37348 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,2324,268,2049,0,262,2065,2308,272,1,2308,1,17,262,268,16,2308,2064,2064,2308,273,0,256,1,2048,773]

theorem envBound37348 : H12AffineFastState.Bounded env37348 := by
  intro p hp
  have h : env37348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37347_37348 : H12AffineEnvironment.transform 4 0 env37347 = env37348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37347 == env37348) = true)

theorem identity37348 : scanCanonicalize (H12AffineFastState.compose env37348 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37348 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37349 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2065,9,2049,0,3,2065,2049,21,1,2049,1,17,3,9,16,2049,2064,2064,2049,20,0,5,1,2048,512]

theorem envBound37349 : H12AffineFastState.Bounded env37349 := by
  intro p hp
  have h : env37349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37348_37349 : H12AffineEnvironment.transform 7 5 env37348 = env37349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37348 == env37349) = true)

def env37350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254011,17,21763,8193,65,171280,115015,17665,10281,119042,180273,256,98679,90202,63068]

theorem envBound37350 : H12AffineFastState.Bounded env37350 := by
  intro p hp
  have h : env37350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37338_37350 : H12AffineEnvironment.transform 6 9 env37338 = env37350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37338 == env37350) = true)

theorem identity37350 : scanCanonicalize (H12AffineFastState.compose env37350 (packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 115014) := by decide +kernel

theorem selectedBound37350 : packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env37351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,115014,76159,1024,32769,4161,8573,17,21763,8193,65,89174,115015,17665,10281,119042,65911,256,98679,90202,63068]

theorem envBound37351 : H12AffineFastState.Bounded env37351 := by
  intro p hp
  have h : env37351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37350_37351 : H12AffineEnvironment.transform 16 115014 env37350 = env37351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115014 env37350 == env37351) = true)

theorem identity37351 : scanCanonicalize (H12AffineFastState.compose env37351 (packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound37351 : packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS < 2^1333 := by decide +kernel

def env37352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,5393,64808,1024,32769,4161,8573,17,21763,8193,65,34817,5392,17665,10281,1365,54560,256,21792,46093,63068]

theorem envBound37352 : H12AffineFastState.Bounded env37352 := by
  intro p hp
  have h : env37352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37351_37352 : H12AffineEnvironment.transform 15 54359 env37351 = env37352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env37351 == env37352) = true)

theorem identity37352 : scanCanonicalize (H12AffineFastState.compose env37352 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37352 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,5393,23669,1024,8540,4161,8573,17,21763,8193,65,10588,5392,17665,10281,1365,29821,256,21792,5456,22273]

theorem envBound37353 : H12AffineFastState.Bounded env37353 := by
  intro p hp
  have h : env37353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37352_37353 : H12AffineEnvironment.transform 14 8541 env37352 = env37353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37352 == env37353) = true)

theorem identity37353 : scanCanonicalize (H12AffineFastState.compose env37353 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37353 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5393,2421,1024,8540,4161,8573,17,3,8193,65,10588,5392,4097,10281,1365,8573,256,32,5456,513]

theorem envBound37354 : H12AffineFastState.Bounded env37354 := by
  intro p hp
  have h : env37354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37353_37354 : H12AffineEnvironment.transform 13 5376 env37353 = env37354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37353 == env37354) = true)

theorem identity37354 : scanCanonicalize (H12AffineFastState.compose env37354 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37354 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1024,0,4161,33,17,3,349,65,2048,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound37355 : H12AffineFastState.Bounded env37355 := by
  intro p hp
  have h : env37355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37354_37355 : H12AffineEnvironment.transform 12 348 env37354 = env37355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37354 == env37355) = true)

theorem identity37355 : scanCanonicalize (H12AffineFastState.compose env37355 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37355 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37356 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,35,5220,2048,1024,0,4161,33,17,3,40,65,2048,5221,4097,2048,1056,33,117,32,5157,513]

theorem envBound37356 : H12AffineFastState.Bounded env37356 := by
  intro p hp
  have h : env37356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37355_37356 : H12AffineEnvironment.transform 7 117 env37355 = env37356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37355 == env37356) = true)

theorem identity37356 : scanCanonicalize (H12AffineFastState.compose env37356 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37356 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37357 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5172,2048,1024,0,4113,33,17,3,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound37357 : H12AffineFastState.Bounded env37357 := by
  intro p hp
  have h : env37357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37356_37357 : H12AffineEnvironment.transform 5 16 env37356 = env37357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37356 == env37357) = true)

def env37358 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,1,35,1028,2048,1024,0,33,33,17,3,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound37358 : H12AffineFastState.Bounded env37358 := by
  intro p hp
  have h : env37358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37357_37358 : H12AffineEnvironment.transform 11 48 env37357 = env37358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37357 == env37358) = true)

theorem identity37358 : scanCanonicalize (H12AffineFastState.compose env37358 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound37358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37359 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,48,41,1045,1,35,1028,1540,1024,0,33,33,17,3,40,17,1540,1029,49,1540,1056,33,37,32,1045,513]

theorem envBound37359 : H12AffineFastState.Bounded env37359 := by
  intro p hp
  have h : env37359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37358_37359 : H12AffineEnvironment.transform 10 1540 env37358 = env37359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env37358 == env37359) = true)

def env37360 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,41,33,1,35,48,560,52,0,33,33,17,3,40,17,560,49,49,560,20,33,37,32,33,513]

theorem envBound37360 : H12AffineFastState.Bounded env37360 := by
  intro p hp
  have h : env37360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37359_37360 : H12AffineEnvironment.transform 9 52 env37359 = env37360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37359 == env37360) = true)

theorem identity37360 : scanCanonicalize (H12AffineFastState.compose env37360 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37361 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,11,18,26,1,24,11,523,15,0,26,26,17,3,19,17,523,10,10,523,20,26,30,27,26,513]

theorem envBound37361 : H12AffineFastState.Bounded env37361 := by
  intro p hp
  have h : env37361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37360_37361 : H12AffineEnvironment.transform 4 27 env37360 = env37361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37360 == env37361) = true)

def leafEnv37361 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,11,18,26,1,24,11,523,15,0,26,26,17,3,20,19,1,17,523,10,10,523,20,26,30,27,4,25,26,513,1,26,0]

def active37361 : List Nat := [0,1,2,3,8]

def tree37361 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37361 : H12WitnessSearch.Good tree37361 := H12GlobalWitnessIndex.good

theorem leafIdentity37361 : H12AffineFastState.composeSystem env37361 rootObs = leafEnv37361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37361 rootObs == leafEnv37361) = true)

theorem terminalChecked37361 : H12PackedTerminal.terminalCheckFast leafEnv37361 active37361 tree37361 = true := by decide +kernel

def env37362 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,41,32,1,35,49,561,53,0,33,33,17,3,40,17,561,48,49,561,21,33,37,32,32,513]

theorem envBound37362 : H12AffineFastState.Bounded env37362 := by
  intro p hp
  have h : env37362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37359_37362 : H12AffineEnvironment.transform 9 53 env37359 = env37362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37359 == env37362) = true)

theorem identity37362 : scanCanonicalize (H12AffineFastState.compose env37362 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37363 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,48,41,32,1,35,49,32,53,0,33,33,17,3,40,17,32,48,49,32,21,33,37,32,32,16]

theorem envBound37363 : H12AffineFastState.Bounded env37363 := by
  intro p hp
  have h : env37363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37362_37363 : H12AffineEnvironment.transform 8 17 env37362 = env37363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37362 == env37363) = true)

def leafEnv37363 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,48,41,32,1,35,49,32,53,0,33,33,17,3,21,40,1,17,32,48,49,32,21,33,37,32,4,34,32,16,1,33,0]

def active37363 : List Nat := [0,1,2,3,4]

def tree37363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37363 : H12WitnessSearch.Good tree37363 := H12GlobalWitnessIndex.good

theorem leafIdentity37363 : H12AffineFastState.composeSystem env37363 rootObs = leafEnv37363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37363 rootObs == leafEnv37363) = true)

theorem terminalChecked37363 : H12PackedTerminal.terminalCheckFast leafEnv37363 active37363 tree37363 = true := by decide +kernel

def env37364 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,1,35,1029,2048,1024,0,32,33,17,3,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound37364 : H12AffineFastState.Bounded env37364 := by
  intro p hp
  have h : env37364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37357_37364 : H12AffineEnvironment.transform 11 49 env37357 = env37364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37357 == env37364) = true)

theorem identity37364 : scanCanonicalize (H12AffineFastState.compose env37364 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound37364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37365 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,49,41,1044,1,35,1029,561,1024,0,32,33,17,3,40,17,561,1028,48,561,1056,33,37,32,1044,513]

theorem envBound37365 : H12AffineFastState.Bounded env37365 := by
  intro p hp
  have h : env37365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37364_37365 : H12AffineEnvironment.transform 10 561 env37364 = env37365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env37364 == env37365) = true)

def env37366 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,41,32,1,35,49,561,52,0,32,33,17,3,40,17,561,48,48,561,20,33,37,32,32,513]

theorem envBound37366 : H12AffineFastState.Bounded env37366 := by
  intro p hp
  have h : env37366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37365_37366 : H12AffineEnvironment.transform 9 52 env37365 = env37366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37365 == env37366) = true)

theorem identity37366 : scanCanonicalize (H12AffineFastState.compose env37366 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37367 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,11,19,26,1,25,11,523,14,0,26,27,17,3,18,17,523,10,10,523,20,27,31,26,26,513]

theorem envBound37367 : H12AffineFastState.Bounded env37367 := by
  intro p hp
  have h : env37367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37366_37367 : H12AffineEnvironment.transform 4 26 env37366 = env37367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37366 == env37367) = true)

def leafEnv37367 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,11,19,26,1,25,11,523,14,0,26,27,17,3,20,18,1,17,523,10,10,523,20,27,31,26,4,24,26,513,1,26,0]

def active37367 : List Nat := [0,1,2,3,8]

def tree37367 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37367 : H12WitnessSearch.Good tree37367 := H12GlobalWitnessIndex.good

theorem leafIdentity37367 : H12AffineFastState.composeSystem env37367 rootObs = leafEnv37367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37367 rootObs == leafEnv37367) = true)

theorem terminalChecked37367 : H12PackedTerminal.terminalCheckFast leafEnv37367 active37367 tree37367 = true := by decide +kernel

def env37368 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,41,33,1,35,48,561,53,0,32,33,17,3,40,17,561,49,48,561,21,33,37,32,33,513]

theorem envBound37368 : H12AffineFastState.Bounded env37368 := by
  intro p hp
  have h : env37368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37365_37368 : H12AffineEnvironment.transform 9 53 env37365 = env37368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37365 == env37368) = true)

theorem identity37368 : scanCanonicalize (H12AffineFastState.compose env37368 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37369 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,49,41,33,1,35,48,33,53,0,32,33,17,3,40,17,33,49,48,33,21,33,37,32,33,17]

theorem envBound37369 : H12AffineFastState.Bounded env37369 := by
  intro p hp
  have h : env37369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37368_37369 : H12AffineEnvironment.transform 8 16 env37368 = env37369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37368 == env37369) = true)

def leafEnv37369 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,49,41,33,1,35,48,33,53,0,32,33,17,3,21,40,1,17,33,49,48,33,21,33,37,32,4,34,33,17,1,32,0]

def active37369 : List Nat := [0,1,2,3,4]

def tree37369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37369 : H12WitnessSearch.Good tree37369 := H12GlobalWitnessIndex.good

theorem leafIdentity37369 : H12AffineFastState.composeSystem env37369 rootObs = leafEnv37369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37369 rootObs == leafEnv37369) = true)

theorem terminalChecked37369 : H12PackedTerminal.terminalCheckFast leafEnv37369 active37369 tree37369 = true := by decide +kernel

def env37370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,2114882,8328,65,4292003,115150,17664,2111712,119043,4268163,256,2199998,2191386,63188]

theorem envBound37370 : H12AffineFastState.Bounded env37370 := by
  intro p hp
  have h : env37370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37310_37370 : H12AffineEnvironment.transform 22 2101329 env37310 = env37370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env37310 == env37370) = true)

def env37371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,21762,8328,65,4292003,115150,17664,10400,119043,4268163,256,98814,90202,63188]

theorem envBound37371 : H12AffineFastState.Bounded env37371 := by
  intro p hp
  have h : env37371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37370_37371 : H12AffineEnvironment.transform 20 4160 env37370 = env37371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37370 == env37371) = true)

theorem identity37371 : scanCanonicalize (H12AffineFastState.compose env37371 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201966) := by decide +kernel

theorem selectedBound37371 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,201966,17,21762,8328,65,158029,115150,17664,10400,119043,144493,256,98814,90202,63188]

theorem envBound37372 : H12AffineFastState.Bounded env37372 := by
  intro p hp
  have h : env37372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37371_37372 : H12AffineEnvironment.transform 21 201966 env37371 = env37372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201966 env37371 == env37372) = true)

theorem identity37372 : scanCanonicalize (H12AffineFastState.compose env37372 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37372 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138341,1024,29908,4160,201966,17,21762,8328,65,158029,79131,17664,10400,75222,144493,256,95531,90202,513]

theorem envBound37373 : H12AffineFastState.Bounded env37373 := by
  intro p hp
  have h : env37373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37372_37373 : H12AffineEnvironment.transform 14 29909 env37372 = env37373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37372 == env37373) = true)

theorem identity37373 : scanCanonicalize (H12AffineFastState.compose env37373 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound37373 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,97406,1024,29908,4160,29941,17,21762,8328,65,67926,79131,17664,10400,75222,87158,256,95531,90202,513]

theorem envBound37374 : H12AffineFastState.Bounded env37374 := by
  intro p hp
  have h : env37374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37373_37374 : H12AffineEnvironment.transform 16 90139 env37373 = env37374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env37373 == env37374) = true)

def env37375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79131,76158,1024,8660,4160,8693,17,2,8328,65,67926,79131,4096,10400,75222,65910,256,73771,79194,513]

theorem envBound37375 : H12AffineFastState.Bounded env37375 := by
  intro p hp
  have h : env37375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37374_37375 : H12AffineEnvironment.transform 13 5376 env37374 = env37375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37374 == env37375) = true)

theorem identity37375 : scanCanonicalize (H12AffineFastState.compose env37375 (packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37375 : packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env37376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,70863,67754,1024,0,4160,33,17,2,348,65,67926,70863,4096,2420,66562,65910,256,66047,70798,513]

theorem envBound37376 : H12AffineFastState.Bounded env37376 := by
  intro p hp
  have h : env37376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37375_37376 : H12AffineEnvironment.transform 12 468 env37375 = env37376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37375 == env37376) = true)

theorem identity37376 : scanCanonicalize (H12AffineFastState.compose env37376 (packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound37376 : packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env37377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,114,5309,2264,1024,0,4160,33,17,2,348,65,2340,5309,4096,2420,1136,260,256,397,5372,513]

theorem envBound37377 : H12AffineFastState.Bounded env37377 := by
  intro p hp
  have h : env37377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37376_37377 : H12AffineEnvironment.transform 15 114 env37376 = env37377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env37376 == env37377) = true)

def env37378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79130,76159,1024,8661,4160,8692,17,3,8328,65,67926,79131,4097,10400,75222,65911,256,73770,79195,513]

theorem envBound37378 : H12AffineFastState.Bounded env37378 := by
  intro p hp
  have h : env37378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37374_37378 : H12AffineEnvironment.transform 13 5377 env37374 = env37378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37374 == env37378) = true)

theorem identity37378 : scanCanonicalize (H12AffineFastState.compose env37378 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37378 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,76159,1024,8540,4160,8573,17,3,8193,65,67926,79131,4097,10281,75103,65911,256,73770,79195,513]

theorem envBound37379 : H12AffineFastState.Bounded env37379 := by
  intro p hp
  have h : env37379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37378_37379 : H12AffineEnvironment.transform 6 9 env37378 = env37379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37378 == env37379) = true)

theorem identity37379 : scanCanonicalize (H12AffineFastState.compose env37379 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37379 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5392,2421,1024,8540,4160,8573,17,3,8193,65,10588,5393,4097,10281,1365,8573,256,32,5457,513]

theorem envBound37380 : H12AffineFastState.Bounded env37380 := by
  intro p hp
  have h : env37380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37379_37380 : H12AffineEnvironment.transform 15 8202 env37379 = env37380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37379 == env37380) = true)

theorem identity37380 : scanCanonicalize (H12AffineFastState.compose env37380 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37380 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2421,1024,0,4160,33,17,3,349,65,2048,5393,4097,2421,1365,33,256,32,5457,513]

theorem envBound37381 : H12AffineFastState.Bounded env37381 := by
  intro p hp
  have h : env37381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37380_37381 : H12AffineEnvironment.transform 12 348 env37380 = env37381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37380 == env37381) = true)

theorem identity37381 : scanCanonicalize (H12AffineFastState.compose env37381 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37381 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37382 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,1,34,5220,2049,1024,0,4160,33,17,3,41,65,2048,5221,4097,2049,1057,33,116,32,5157,513]

theorem envBound37382 : H12AffineFastState.Bounded env37382 := by
  intro p hp
  have h : env37382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37381_37382 : H12AffineEnvironment.transform 7 116 env37381 = env37382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37381 == env37382) = true)

theorem identity37382 : scanCanonicalize (H12AffineFastState.compose env37382 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37382 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37383 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,1,34,5172,2049,1024,0,4112,33,17,3,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound37383 : H12AffineFastState.Bounded env37383 := by
  intro p hp
  have h : env37383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37382_37383 : H12AffineEnvironment.transform 5 16 env37382 = env37383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37382 == env37383) = true)

def env37384 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,1,34,1028,2049,1024,0,32,33,17,3,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound37384 : H12AffineFastState.Bounded env37384 := by
  intro p hp
  have h : env37384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37383_37384 : H12AffineEnvironment.transform 11 48 env37383 = env37384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37383 == env37384) = true)

theorem identity37384 : scanCanonicalize (H12AffineFastState.compose env37384 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37385 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,16,8,1045,1,2,1028,2049,1024,0,0,1,17,3,9,17,2048,1029,17,2049,1025,1,4,0,1045,513]

theorem envBound37385 : H12AffineFastState.Bounded env37385 := by
  intro p hp
  have h : env37385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37384_37385 : H12AffineEnvironment.transform 4 0 env37384 = env37385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37384 == env37385) = true)

def env37386 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,8,1,1,2,16,2049,20,0,0,1,17,3,9,17,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound37386 : H12AffineFastState.Bounded env37386 := by
  intro p hp
  have h : env37386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37385_37386 : H12AffineEnvironment.transform 9 20 env37385 = env37386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37385 == env37386) = true)

theorem identity37386 : scanCanonicalize (H12AffineFastState.compose env37386 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37386 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37387 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,16,8,1,1,2,16,523,20,0,0,1,17,3,9,17,522,17,17,523,21,1,4,0,1,513]

theorem envBound37387 : H12AffineFastState.Bounded env37387 := by
  intro p hp
  have h : env37387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37386_37387 : H12AffineEnvironment.transform 10 522 env37386 = env37387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37386 == env37387) = true)

def leafEnv37387 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,16,8,1,1,2,16,523,20,0,0,1,17,3,21,9,1,17,522,17,17,523,21,1,4,0,4,3,1,513,1,0,0]

def active37387 : List Nat := [0,1,2,3,8]

def tree37387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37387 : H12WitnessSearch.Good tree37387 := H12GlobalWitnessIndex.good

theorem leafIdentity37387 : H12AffineFastState.composeSystem env37387 rootObs = leafEnv37387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37387 rootObs == leafEnv37387) = true)

theorem terminalChecked37387 : H12PackedTerminal.terminalCheckFast leafEnv37387 active37387 tree37387 = true := by decide +kernel

def env37388 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,8,0,1,2,17,2049,21,0,0,1,17,3,9,17,2048,16,17,2049,20,1,4,0,0,513]

theorem envBound37388 : H12AffineFastState.Bounded env37388 := by
  intro p hp
  have h : env37388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37385_37388 : H12AffineEnvironment.transform 9 21 env37385 = env37388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37385 == env37388) = true)

theorem identity37388 : scanCanonicalize (H12AffineFastState.compose env37388 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37389 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,8,0,1,2,17,1,21,0,0,1,17,3,9,17,0,16,17,1,20,1,4,0,0,513]

theorem envBound37389 : H12AffineFastState.Bounded env37389 := by
  intro p hp
  have h : env37389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37388_37389 : H12AffineEnvironment.transform 10 0 env37388 = env37389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37388 == env37389) = true)

def leafEnv37389 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,8,0,1,2,17,1,21,0,0,1,17,3,20,9,1,17,0,16,17,1,20,1,4,0,4,3,0,513,1,0,0]

def active37389 : List Nat := [0,1,2,3,8]

def tree37389 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37389 : H12WitnessSearch.Good tree37389 := H12GlobalWitnessIndex.good

theorem leafIdentity37389 : H12AffineFastState.composeSystem env37389 rootObs = leafEnv37389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37389 rootObs == leafEnv37389) = true)

theorem terminalChecked37389 : H12PackedTerminal.terminalCheckFast leafEnv37389 active37389 tree37389 = true := by decide +kernel

def env37390 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,1,34,1029,2049,1024,0,33,33,17,3,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound37390 : H12AffineFastState.Bounded env37390 := by
  intro p hp
  have h : env37390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37383_37390 : H12AffineEnvironment.transform 11 49 env37383 = env37390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37383 == env37390) = true)

theorem identity37390 : scanCanonicalize (H12AffineFastState.compose env37390 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound37390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37391 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,49,40,1,1,34,16,2049,21,0,33,33,17,3,41,17,2048,17,48,2049,52,33,36,32,1,513]

theorem envBound37391 : H12AffineFastState.Bounded env37391 := by
  intro p hp
  have h : env37391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37390_37391 : H12AffineEnvironment.transform 9 21 env37390 = env37391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37390 == env37391) = true)

def env37392 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,8,1,1,2,16,2049,21,0,1,1,17,3,9,17,2048,17,16,2049,20,1,4,0,1,513]

theorem envBound37392 : H12AffineFastState.Bounded env37392 := by
  intro p hp
  have h : env37392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37391_37392 : H12AffineEnvironment.transform 4 0 env37391 = env37392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37391 == env37392) = true)

theorem identity37392 : scanCanonicalize (H12AffineFastState.compose env37392 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37393 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,8,1,1,2,16,0,21,0,1,1,17,3,9,17,1,17,16,0,20,1,4,0,1,513]

theorem envBound37393 : H12AffineFastState.Bounded env37393 := by
  intro p hp
  have h : env37393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37392_37393 : H12AffineEnvironment.transform 10 1 env37392 = env37393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37392 == env37393) = true)

def leafEnv37393 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,8,1,1,2,16,0,21,0,1,1,17,3,20,9,1,17,1,17,16,0,20,1,4,0,4,3,1,513,1,1,0]

def active37393 : List Nat := [0,1,2,3,8]

def tree37393 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37393 : H12WitnessSearch.Good tree37393 := H12GlobalWitnessIndex.good

theorem leafIdentity37393 : H12AffineFastState.composeSystem env37393 rootObs = leafEnv37393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37393 rootObs == leafEnv37393) = true)

theorem terminalChecked37393 : H12PackedTerminal.terminalCheckFast leafEnv37393 active37393 tree37393 = true := by decide +kernel

def env37394 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,9,1,1,3,16,2049,21,0,0,0,17,3,8,17,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound37394 : H12AffineFastState.Bounded env37394 := by
  intro p hp
  have h : env37394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37391_37394 : H12AffineEnvironment.transform 4 1 env37391 = env37394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37391 == env37394) = true)

theorem identity37394 : scanCanonicalize (H12AffineFastState.compose env37394 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37395 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,16,9,1,1,3,16,523,21,0,0,0,17,3,8,17,522,17,17,523,21,0,5,1,1,513]

theorem envBound37395 : H12AffineFastState.Bounded env37395 := by
  intro p hp
  have h : env37395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37394_37395 : H12AffineEnvironment.transform 10 522 env37394 = env37395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37394 == env37395) = true)

def leafEnv37395 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,16,9,1,1,3,16,523,21,0,0,0,17,3,21,8,1,17,522,17,17,523,21,0,5,1,4,2,1,513,1,0,0]

def active37395 : List Nat := [0,1,2,3,8]

def tree37395 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37395 : H12WitnessSearch.Good tree37395 := H12GlobalWitnessIndex.good

theorem leafIdentity37395 : H12AffineFastState.composeSystem env37395 rootObs = leafEnv37395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37395 rootObs == leafEnv37395) = true)

theorem terminalChecked37395 : H12PackedTerminal.terminalCheckFast leafEnv37395 active37395 tree37395 = true := by decide +kernel

def env37396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,21763,8328,65,4292003,115150,17664,10401,119043,4268163,256,98815,90203,63188]

theorem envBound37396 : H12AffineFastState.Bounded env37396 := by
  intro p hp
  have h : env37396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37370_37396 : H12AffineEnvironment.transform 20 4161 env37370 = env37396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37370 == env37396) = true)

theorem identity37396 : scanCanonicalize (H12AffineFastState.compose env37396 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound37396 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190640,1024,32769,4161,4194304,16,21763,8328,65,4237693,5392,17664,10401,1501,4256861,256,21793,46213,63188]

theorem envBound37397 : H12AffineFastState.Bounded env37397 := by
  intro p hp
  have h : env37397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37396_37397 : H12AffineEnvironment.transform 15 54494 env37396 = env37397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env37396 == env37397) = true)

def env37398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21763,8192,65,4237693,5392,17664,10281,1365,4256861,256,21793,46093,63068]

theorem envBound37398 : H12AffineFastState.Bounded env37398 := by
  intro p hp
  have h : env37398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37397_37398 : H12AffineEnvironment.transform 6 8 env37397 = env37398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37397 == env37398) = true)

theorem identity37398 : scanCanonicalize (H12AffineFastState.compose env37398 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound37398 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4161,4194304,16,21763,8192,65,4237693,5392,17664,10281,1365,4256861,256,21793,46093,63068]

theorem envBound37399 : H12AffineFastState.Bounded env37399 := by
  intro p hp
  have h : env37399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37398_37399 : H12AffineEnvironment.transform 16 24909 env37398 = env37399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env37398 == env37399) = true)

theorem identity37399 : scanCanonicalize (H12AffineFastState.compose env37399 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32881) := by decide +kernel

theorem selectedBound37399 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4161,32881,16,21763,8192,65,10508,5392,17664,10281,1365,29740,256,21793,46093,63068]

theorem envBound37400 : H12AffineFastState.Bounded env37400 := by
  intro p hp
  have h : env37400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37399_37400 : H12AffineEnvironment.transform 21 32881 env37399 = env37400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32881 env37399 == env37400) = true)

theorem identity37400 : scanCanonicalize (H12AffineFastState.compose env37400 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound37400 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env37401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,21875,24909,2128,1024,292,4161,340,16,21763,8192,65,10508,5392,17664,10281,1365,29740,256,21793,13608,30585]

theorem envBound37401 : H12AffineFastState.Bounded env37401 := by
  intro p hp
  have h : env37401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37400_37401 : H12AffineEnvironment.transform 14 293 env37400 = env37401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env37400 == env37401) = true)

theorem identity37401 : scanCanonicalize (H12AffineFastState.compose env37401 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37401 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env37402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,293,21875,16400,2128,1024,292,4161,340,16,21763,349,65,2129,5392,17664,2420,1365,21873,256,21793,5237,22052]

theorem envBound37402 : H12AffineFastState.Bounded env37402 := by
  intro p hp
  have h : env37402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37401_37402 : H12AffineEnvironment.transform 12 349 env37401 = env37402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37401 == env37402) = true)

theorem identity37402 : scanCanonicalize (H12AffineFastState.compose env37402 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37402 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env37403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,293,114,5393,2128,1024,292,4161,340,16,2,349,65,2129,5392,4097,2420,1365,112,256,32,5237,805]

theorem envBound37403 : H12AffineFastState.Bounded env37403 := by
  intro p hp
  have h : env37403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37402_37403 : H12AffineEnvironment.transform 13 5377 env37402 = env37403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37402 == env37403) = true)

theorem identity37403 : scanCanonicalize (H12AffineFastState.compose env37403 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37403 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env37404 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4404,293,114,4388,2128,53,292,4161,340,16,2,349,65,2129,4389,4097,2420,352,112,256,32,4160,805]

theorem envBound37404 : H12AffineFastState.Bounded env37404 := by
  intro p hp
  have h : env37404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37403_37404 : H12AffineEnvironment.transform 9 53 env37403 = env37404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37403 == env37404) = true)

theorem identity37404 : scanCanonicalize (H12AffineFastState.compose env37404 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37404 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37405 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,121,4112,1,114,4096,2128,53,0,4161,112,16,2,121,65,2129,4097,4097,2128,68,112,36,32,4160,513]

theorem envBound37405 : H12AffineFastState.Bounded env37405 := by
  intro p hp
  have h : env37405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37404_37405 : H12AffineEnvironment.transform 7 36 env37404 = env37405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37404 == env37405) = true)

theorem identity37405 : scanCanonicalize (H12AffineFastState.compose env37405 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37405 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env37406 : List Nat := [2,4,8,16,17,64,8,21,512,4,2048,4096,72,4112,1,67,4096,2128,4,0,4161,65,16,2,72,65,2129,4097,4097,2128,68,65,21,17,4160,513]

theorem envBound37406 : H12AffineFastState.Bounded env37406 := by
  intro p hp
  have h : env37406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37405_37406 : H12AffineEnvironment.transform 4 17 env37405 = env37406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37405 == env37406) = true)

theorem identity37406 : scanCanonicalize (H12AffineFastState.compose env37406 (packedSelected [0,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound37406 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env37407 : List Nat := [2,4,8,16,17,64,8,21,512,4,2048,528,72,512,1,67,528,2128,4,0,593,65,16,2,72,65,2129,529,529,2128,68,65,21,17,592,513]

theorem envBound37407 : H12AffineFastState.Bounded env37407 := by
  intro p hp
  have h : env37407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37406_37407 : H12AffineEnvironment.transform 11 528 env37406 = env37407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env37406 == env37407) = true)

theorem identity37407 : scanCanonicalize (H12AffineFastState.compose env37407 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37407 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37408 : List Nat := [2,4,8,16,17,64,8,21,0,4,2048,16,72,0,1,67,16,2128,4,0,81,65,16,2,72,65,2129,17,17,2128,68,65,21,17,80,1]

theorem envBound37408 : H12AffineFastState.Bounded env37408 := by
  intro p hp
  have h : env37408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37407_37408 : H12AffineEnvironment.transform 8 0 env37407 = env37408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37407 == env37408) = true)

theorem identity37408 : scanCanonicalize (H12AffineFastState.compose env37408 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37408 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env37409 : List Nat := [2,4,8,16,17,16,8,21,0,4,2048,16,24,0,1,19,16,2048,4,0,1,17,16,2,24,17,2049,17,17,2048,20,17,21,17,0,1]

theorem envBound37409 : H12AffineFastState.Bounded env37409 := by
  intro p hp
  have h : env37409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37408_37409 : H12AffineEnvironment.transform 5 16 env37408 = env37409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37408 == env37409) = true)

theorem identity37409 : scanCanonicalize (H12AffineFastState.compose env37409 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37410 : List Nat := [2,4,8,16,17,16,8,21,0,4,1,16,24,0,1,19,16,1,4,0,1,17,16,2,24,17,0,17,17,1,20,17,21,17,0,1]

theorem envBound37410 : H12AffineFastState.Bounded env37410 := by
  intro p hp
  have h : env37410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37409_37410 : H12AffineEnvironment.transform 10 1 env37409 = env37410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37409 == env37410) = true)

theorem identity37410 : scanCanonicalize (H12AffineFastState.compose env37410 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37411 : List Nat := [2,4,8,1,0,1,8,4,0,4,1,1,9,0,1,2,1,1,4,0,1,0,1,2,9,0,0,0,0,1,5,0,4,0,0,1]

theorem envBound37411 : H12AffineFastState.Bounded env37411 := by
  intro p hp
  have h : env37411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37410_37411 : H12AffineEnvironment.transform 3 1 env37410 = env37411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37410 == env37411) = true)

def env37412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4161,4194304,16,21763,8193,65,4237693,5392,17664,10280,1364,4256861,256,21793,46092,63069]

theorem envBound37412 : H12AffineFastState.Bounded env37412 := by
  intro p hp
  have h : env37412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37397_37412 : H12AffineEnvironment.transform 6 9 env37397 = env37412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37397 == env37412) = true)

theorem identity37412 : scanCanonicalize (H12AffineFastState.compose env37412 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound37412 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10281,1024,32769,4161,4194304,16,21763,8193,65,4237693,5392,17664,10280,1364,4256861,256,21793,46092,63069]

theorem envBound37413 : H12AffineFastState.Bounded env37413 := by
  intro p hp
  have h : env37413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37412_37413 : H12AffineEnvironment.transform 16 49168 env37412 = env37413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env37412 == env37413) = true)

theorem identity37413 : scanCanonicalize (H12AffineFastState.compose env37413 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound37413 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40971,46156,10281,1024,32769,4161,4194304,16,8543,8193,65,4237693,5392,12636,10280,1364,4227073,256,8573,46092,33281]

theorem envBound37414 : H12AffineFastState.Bounded env37414 := by
  intro p hp
  have h : env37414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37413_37414 : H12AffineEnvironment.transform 13 13404 env37413 = env37414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env37413 == env37414) = true)

theorem identity37414 : scanCanonicalize (H12AffineFastState.compose env37414 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37414 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,13388,10281,1024,1,4161,4194304,16,8543,8193,65,4204925,5392,12636,10280,1364,4194305,256,8573,13324,513]

theorem envBound37415 : H12AffineFastState.Bounded env37415 := by
  intro p hp
  have h : env37415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37414_37415 : H12AffineEnvironment.transform 14 0 env37414 = env37415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37414 == env37415) = true)

theorem identity37415 : scanCanonicalize (H12AffineFastState.compose env37415 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound37415 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,13388,10281,1024,1,4161,33,16,8543,8193,65,10588,5392,12636,10280,1364,32,256,8573,13324,513]

theorem envBound37416 : H12AffineFastState.Bounded env37416 := by
  intro p hp
  have h : env37416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37415_37416 : H12AffineEnvironment.transform 21 33 env37415 = env37416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env37415 == env37416) = true)

theorem identity37416 : scanCanonicalize (H12AffineFastState.compose env37416 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37416 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5393,2420,1024,1,4161,33,16,2,348,65,2049,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound37417 : H12AffineFastState.Bounded env37417 := by
  intro p hp
  have h : env37417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37416_37417 : H12AffineEnvironment.transform 12 349 env37416 = env37417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37416 == env37417) = true)

theorem identity37417 : scanCanonicalize (H12AffineFastState.compose env37417 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37418 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,263,5393,2341,1024,1,4112,33,16,2,269,16,2049,5392,4097,2340,1285,32,256,32,5376,513]

theorem envBound37418 : H12AffineFastState.Bounded env37418 := by
  intro p hp
  have h : env37418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37417_37418 : H12AffineEnvironment.transform 5 17 env37417 = env37418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37417 == env37418) = true)

theorem identity37418 : scanCanonicalize (H12AffineFastState.compose env37418 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound37418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37419 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,268,1329,0,263,1313,2341,1024,1,32,33,16,2,269,16,2049,1312,49,2340,1285,32,256,32,1328,513]

theorem envBound37419 : H12AffineFastState.Bounded env37419 := by
  intro p hp
  have h : env37419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37418_37419 : H12AffineEnvironment.transform 11 48 env37418 = env37419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37418 == env37419) = true)

theorem identity37419 : scanCanonicalize (H12AffineFastState.compose env37419 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound37419 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37420 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1557,48,268,1329,0,263,1313,1840,1024,1,32,33,16,2,269,16,1556,1312,49,1841,1285,32,256,32,1328,513]

theorem envBound37420 : H12AffineFastState.Bounded env37420 := by
  intro p hp
  have h : env37420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37419_37420 : H12AffineEnvironment.transform 10 1557 env37419 = env37420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env37419 == env37420) = true)

theorem identity37420 : scanCanonicalize (H12AffineFastState.compose env37420 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound37420 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37421 : List Nat := [2,4,8,16,32,17,9,256,512,36,561,48,268,277,0,263,261,788,36,1,32,33,16,2,269,16,560,260,49,789,289,32,256,32,276,513]

theorem envBound37421 : H12AffineFastState.Bounded env37421 := by
  intro p hp
  have h : env37421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37420_37421 : H12AffineEnvironment.transform 9 36 env37420 = env37421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env37420 == env37421) = true)

theorem identity37421 : scanCanonicalize (H12AffineFastState.compose env37421 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound37421 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37422 : List Nat := [2,4,8,16,32,17,9,52,512,36,561,48,56,33,0,51,49,544,36,1,32,33,16,2,57,16,560,48,49,545,21,32,52,32,32,513]

theorem envBound37422 : H12AffineFastState.Bounded env37422 := by
  intro p hp
  have h : env37422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37421_37422 : H12AffineEnvironment.transform 7 52 env37421 = env37422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env37421 == env37422) = true)

theorem identity37422 : scanCanonicalize (H12AffineFastState.compose env37422 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound37422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37423 : List Nat := [2,4,8,16,32,17,9,52,26,36,43,48,56,33,0,51,49,58,36,1,32,33,16,2,57,16,42,48,49,59,21,32,52,32,32,27]

theorem envBound37423 : H12AffineFastState.Bounded env37423 := by
  intro p hp
  have h : env37423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37422_37423 : H12AffineEnvironment.transform 8 26 env37422 = env37423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env37422 == env37423) = true)

theorem identity37423 : scanCanonicalize (H12AffineFastState.compose env37423 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37423 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env37424 : List Nat := [2,4,8,16,26,17,9,14,26,30,17,10,2,27,0,9,11,0,30,1,26,27,16,2,3,16,16,10,11,1,21,26,14,26,26,27]

theorem envBound37424 : H12AffineFastState.Bounded env37424 := by
  intro p hp
  have h : env37424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37423_37424 : H12AffineEnvironment.transform 4 26 env37423 = env37424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37423 == env37424) = true)

theorem identity37424 : scanCanonicalize (H12AffineFastState.compose env37424 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37424 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env37425 : List Nat := [2,4,2,16,16,17,3,4,16,20,17,0,2,17,0,3,1,0,20,1,16,17,16,2,3,16,16,0,1,1,21,16,4,16,16,17]

theorem envBound37425 : H12AffineFastState.Bounded env37425 := by
  intro p hp
  have h : env37425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37424_37425 : H12AffineEnvironment.transform 2 2 env37424 = env37425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37424 == env37425) = true)

def env37426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773746,115151,10507601,8399024,10600787,4268162,256,8487406,8478794,10544772]

theorem envBound37426 : H12AffineFastState.Bounded env37426 := by
  intro p hp
  have h : env37426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37309_37426 : H12AffineEnvironment.transform 17 190641 env37309 = env37426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env37309 == env37426) = true)

def env37427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,2114883,8328,65,4292002,115151,17665,2111712,119043,4268162,256,2199998,2191386,63188]

theorem envBound37427 : H12AffineFastState.Bounded env37427 := by
  intro p hp
  have h : env37427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37426_37427 : H12AffineEnvironment.transform 22 2101328 env37426 = env37427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env37426 == env37427) = true)

def env37428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,21763,8328,65,4292002,115151,17665,10400,119043,4268162,256,98814,90202,63188]

theorem envBound37428 : H12AffineFastState.Bounded env37428 := by
  intro p hp
  have h : env37428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37427_37428 : H12AffineEnvironment.transform 20 4160 env37427 = env37428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37427 == env37428) = true)

theorem identity37428 : scanCanonicalize (H12AffineFastState.compose env37428 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37428 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138340,1024,29908,4160,4194304,16,21763,8328,65,4292002,79130,17665,10400,75222,4268162,256,95531,90202,513]

theorem envBound37429 : H12AffineFastState.Bounded env37429 := by
  intro p hp
  have h : env37429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37428_37429 : H12AffineEnvironment.transform 14 29909 env37428 = env37429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37428 == env37429) = true)

def env37430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138340,1024,8660,4160,4194304,16,3,8328,65,4270242,79130,4097,10400,75222,4268162,256,73771,79194,513]

theorem envBound37430 : H12AffineFastState.Bounded env37430 := by
  intro p hp
  have h : env37430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37429_37430 : H12AffineEnvironment.transform 13 5376 env37429 = env37430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37429 == env37430) = true)

theorem identity37430 : scanCanonicalize (H12AffineFastState.compose env37430 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound37430 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,10400,1024,8660,4160,4194304,16,3,8328,65,4270242,79130,4097,10400,75222,4268162,256,73771,79194,513]

theorem envBound37431 : H12AffineFastState.Bounded env37431 := by
  intro p hp
  have h : env37431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37430_37431 : H12AffineEnvironment.transform 16 13508 env37430 = env37431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env37430 == env37431) = true)

theorem identity37431 : scanCanonicalize (H12AffineFastState.compose env37431 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37431 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1024,8541,4160,4194304,16,3,8193,65,4270123,79130,4097,10281,75103,4268043,256,73771,79194,513]

theorem envBound37432 : H12AffineFastState.Bounded env37432 := by
  intro p hp
  have h : env37432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37431_37432 : H12AffineEnvironment.transform 6 9 env37431 = env37432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37431 == env37432) = true)

theorem identity37432 : scanCanonicalize (H12AffineFastState.compose env37432 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37432 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13389,10281,1024,8541,4160,4194304,16,3,8193,65,4196385,5392,4097,10281,1365,4194305,256,33,5456,513]

theorem envBound37433 : H12AffineFastState.Bounded env37433 := by
  intro p hp
  have h : env37433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37432_37433 : H12AffineEnvironment.transform 15 8202 env37432 = env37433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37432 == env37433) = true)

theorem identity37433 : scanCanonicalize (H12AffineFastState.compose env37433 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37433 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,262,5441,2341,1024,81,4160,4194304,16,3,269,65,4196385,5392,4097,2341,1365,4194305,256,33,5456,513]

theorem envBound37434 : H12AffineFastState.Bounded env37434 := by
  intro p hp
  have h : env37434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37433_37434 : H12AffineEnvironment.transform 12 268 env37433 = env37434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37433 == env37434) = true)

theorem identity37434 : scanCanonicalize (H12AffineFastState.compose env37434 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound37434 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env37435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,262,5441,2341,1024,81,4160,33,16,3,269,65,2048,5392,4097,2341,1365,32,256,33,5456,513]

theorem envBound37435 : H12AffineFastState.Bounded env37435 := by
  intro p hp
  have h : env37435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37434_37435 : H12AffineEnvironment.transform 21 33 env37434 = env37435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env37434 == env37435) = true)

theorem identity37435 : scanCanonicalize (H12AffineFastState.compose env37435 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37435 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37436 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,80,115,5172,2128,1024,81,4160,33,16,3,120,65,2048,5221,4097,2128,1056,32,117,33,5157,513]

theorem envBound37436 : H12AffineFastState.Bounded env37436 := by
  intro p hp
  have h : env37436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37435_37436 : H12AffineEnvironment.transform 7 117 env37435 = env37436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37435 == env37436) = true)

theorem identity37436 : scanCanonicalize (H12AffineFastState.compose env37436 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37436 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37437 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4113,33,16,3,41,16,2048,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound37437 : H12AffineFastState.Bounded env37437 := by
  intro p hp
  have h : env37437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37436_37437 : H12AffineEnvironment.transform 5 17 env37436 = env37437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37436 == env37437) = true)

theorem identity37437 : scanCanonicalize (H12AffineFastState.compose env37437 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37437 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37438 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5156,1,34,5172,522,1024,0,4113,33,16,3,41,16,523,5172,4097,522,1056,32,36,33,5157,513]

theorem envBound37438 : H12AffineFastState.Bounded env37438 := by
  intro p hp
  have h : env37438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37437_37438 : H12AffineEnvironment.transform 10 523 env37437 = env37438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37437 == env37438) = true)

theorem identity37438 : scanCanonicalize (H12AffineFastState.compose env37438 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37438 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37439 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,8,5124,1,2,5140,522,1024,0,4113,1,16,3,9,16,523,5140,4097,522,1024,0,4,1,5125,513]

theorem envBound37439 : H12AffineFastState.Bounded env37439 := by
  intro p hp
  have h : env37439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37438_37439 : H12AffineEnvironment.transform 4 0 env37438 = env37439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37438 == env37439) = true)

def env37440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138340,1024,8661,4160,4194304,16,2,8328,65,4270243,79130,4096,10400,75222,4268162,256,73770,79195,513]

theorem envBound37440 : H12AffineFastState.Bounded env37440 := by
  intro p hp
  have h : env37440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37429_37440 : H12AffineEnvironment.transform 13 5377 env37429 = env37440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37429 == env37440) = true)

theorem identity37440 : scanCanonicalize (H12AffineFastState.compose env37440 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound37440 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10281,1024,8661,4160,4194304,16,2,8328,65,4270243,79130,4096,10400,75222,4268162,256,73770,79195,513]

theorem envBound37441 : H12AffineFastState.Bounded env37441 := by
  intro p hp
  have h : env37441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37440_37441 : H12AffineEnvironment.transform 16 13389 env37440 = env37441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env37440 == env37441) = true)

theorem identity37441 : scanCanonicalize (H12AffineFastState.compose env37441 (packedSelected [2,6,7,14,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound37441 : packedSelected [2,6,7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env37442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,342,13389,10281,1024,8661,4160,4194304,16,2,8328,65,4205045,13388,4096,10400,9344,4202964,256,8572,13325,513]

theorem envBound37442 : H12AffineFastState.Bounded env37442 := by
  intro p hp
  have h : env37442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37441_37442 : H12AffineEnvironment.transform 15 342 env37441 = env37442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env37441 == env37442) = true)

theorem identity37442 : scanCanonicalize (H12AffineFastState.compose env37442 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37442 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,342,5393,2421,1024,137,4160,4194304,16,2,468,65,4196521,5392,4096,2556,1500,4194440,256,32,5457,513]

theorem envBound37443 : H12AffineFastState.Bounded env37443 := by
  intro p hp
  have h : env37443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37442_37443 : H12AffineEnvironment.transform 12 348 env37442 = env37443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37442 == env37443) = true)

theorem identity37443 : scanCanonicalize (H12AffineFastState.compose env37443 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound37443 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,342,5393,2421,1024,137,4160,248,16,2,468,65,2129,5392,4096,2556,1500,112,256,32,5457,513]

theorem envBound37444 : H12AffineFastState.Bounded env37444 := by
  intro p hp
  have h : env37444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37443_37444 : H12AffineEnvironment.transform 21 248 env37443 = env37444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env37443 == env37444) = true)

theorem identity37444 : scanCanonicalize (H12AffineFastState.compose env37444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5393,2421,1024,1,4160,112,16,2,348,65,2129,5392,4096,2420,1364,112,256,32,5457,513]

theorem envBound37445 : H12AffineFastState.Bounded env37445 := by
  intro p hp
  have h : env37445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37444_37445 : H12AffineEnvironment.transform 6 8 env37444 = env37445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37444 == env37445) = true)

theorem identity37445 : scanCanonicalize (H12AffineFastState.compose env37445 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound37445 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env37446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,348,1,0,342,17,2421,1024,1,1344,112,16,2,348,65,2129,16,1280,2420,1364,112,256,32,81,513]

theorem envBound37446 : H12AffineFastState.Bounded env37446 := by
  intro p hp
  have h : env37446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37445_37446 : H12AffineEnvironment.transform 11 1280 env37445 = env37446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env37445 == env37446) = true)

theorem identity37446 : scanCanonicalize (H12AffineFastState.compose env37446 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound37446 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1818,1280,348,1,0,342,17,1647,1024,1,1344,112,16,2,348,65,1867,16,1280,1646,1364,112,256,32,81,513]

theorem envBound37447 : H12AffineFastState.Bounded env37447 := by
  intro p hp
  have h : env37447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37446_37447 : H12AffineEnvironment.transform 10 1818 env37446 = env37447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env37446 == env37447) = true)

theorem identity37447 : scanCanonicalize (H12AffineFastState.compose env37447 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound37447 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env37448 : List Nat := [2,4,8,16,32,64,8,256,512,574,292,830,348,1,0,342,17,81,574,1,894,112,16,2,348,65,373,16,830,80,874,112,256,32,81,513]

theorem envBound37448 : H12AffineFastState.Bounded env37448 := by
  intro p hp
  have h : env37448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37447_37448 : H12AffineEnvironment.transform 9 574 env37447 = env37448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env37447 == env37448) = true)

theorem identity37448 : scanCanonicalize (H12AffineFastState.compose env37448 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37448 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37449 : List Nat := [2,4,8,16,32,16,8,256,512,574,292,830,268,1,0,262,17,1,574,1,814,32,16,2,268,17,293,16,830,0,826,32,256,32,1,513]

theorem envBound37449 : H12AffineFastState.Bounded env37449 := by
  intro p hp
  have h : env37449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37448_37449 : H12AffineEnvironment.transform 5 16 env37448 = env37449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37448 == env37449) = true)

theorem identity37449 : scanCanonicalize (H12AffineFastState.compose env37449 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound37449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37450 : List Nat := [2,4,8,16,32,16,8,256,302,272,292,16,268,1,0,262,17,1,272,1,0,32,16,2,268,17,293,16,16,0,20,32,256,32,1,303]

theorem envBound37450 : H12AffineFastState.Bounded env37450 := by
  intro p hp
  have h : env37450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37449_37450 : H12AffineEnvironment.transform 8 302 env37449 = env37450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env37449 == env37450) = true)

theorem identity37450 : scanCanonicalize (H12AffineFastState.compose env37450 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37450 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37451 : List Nat := [2,4,8,16,32,16,8,36,10,52,0,16,40,1,0,34,17,1,52,1,0,32,16,2,40,17,1,16,16,0,20,32,36,32,1,11]

theorem envBound37451 : H12AffineFastState.Bounded env37451 := by
  intro p hp
  have h : env37451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37450_37451 : H12AffineEnvironment.transform 7 36 env37450 = env37451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37450 == env37451) = true)

theorem identity37451 : scanCanonicalize (H12AffineFastState.compose env37451 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound37451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37452 : List Nat := [2,4,8,5,32,5,8,36,10,33,0,5,40,1,0,34,4,1,33,1,0,32,5,2,40,4,1,5,5,0,1,32,36,32,1,11]

theorem envBound37452 : H12AffineFastState.Bounded env37452 := by
  intro p hp
  have h : env37452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37451_37452 : H12AffineEnvironment.transform 3 5 env37451 = env37452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37451 == env37452) = true)

theorem identity37452 : scanCanonicalize (H12AffineFastState.compose env37452 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37453 : List Nat := [2,4,4,5,32,5,4,36,6,33,0,5,36,1,0,34,4,1,33,1,0,32,5,2,36,4,1,5,5,0,1,32,36,32,1,7]

theorem envBound37453 : H12AffineFastState.Bounded env37453 := by
  intro p hp
  have h : env37453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37452_37453 : H12AffineEnvironment.transform 2 4 env37452 = env37453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37452 == env37453) = true)

theorem identity37453 : scanCanonicalize (H12AffineFastState.compose env37453 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37453 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37454 : List Nat := [2,4,4,5,1,5,4,5,6,0,0,5,5,1,0,3,4,1,0,1,0,1,5,2,5,4,1,5,5,0,1,1,5,1,1,7]

theorem envBound37454 : H12AffineFastState.Bounded env37454 := by
  intro p hp
  have h : env37454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37453_37454 : H12AffineEnvironment.transform 4 1 env37453 = env37454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37453 == env37454) = true)

def env37455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,21762,8328,65,4292002,115151,17665,10401,119043,4268162,256,98815,90203,63188]

theorem envBound37455 : H12AffineFastState.Bounded env37455 := by
  intro p hp
  have h : env37455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37427_37455 : H12AffineEnvironment.transform 20 4161 env37427 = env37455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37427 == env37455) = true)

theorem identity37455 : scanCanonicalize (H12AffineFastState.compose env37455 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound37455 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,144613,17,21762,8328,65,215367,115151,17665,10401,119043,201831,256,98815,90203,63188]

theorem envBound37456 : H12AffineFastState.Bounded env37456 := by
  intro p hp
  have h : env37456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37455_37456 : H12AffineEnvironment.transform 21 144613 env37455 = env37456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env37455 == env37456) = true)

def env37457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144493,17,21762,8192,65,215367,115015,17665,10281,119043,201831,256,98679,90203,63068]

theorem envBound37457 : H12AffineFastState.Bounded env37457 := by
  intro p hp
  have h : env37457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37456_37457 : H12AffineEnvironment.transform 6 8 env37456 = env37457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37456 == env37457) = true)

theorem identity37457 : scanCanonicalize (H12AffineFastState.compose env37457 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37457 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4161,144493,17,21762,8192,65,215367,90138,17665,10281,94302,201831,256,73770,90203,22273]

theorem envBound37458 : H12AffineFastState.Bounded env37458 := by
  intro p hp
  have h : env37458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37457_37458 : H12AffineEnvironment.transform 14 8541 env37457 = env37458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37457 == env37458) = true)

theorem identity37458 : scanCanonicalize (H12AffineFastState.compose env37458 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound37458 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,65536,131072,138512,1024,8540,4161,144493,17,374,8192,65,204083,78958,4469,10281,74794,201831,256,73770,78895,885]

theorem envBound37459 : H12AffineFastState.Bounded env37459 := by
  intro p hp
  have h : env37459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37458_37459 : H12AffineEnvironment.transform 13 5236 env37458 = env37459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env37458 == env37459) = true)

theorem identity37459 : scanCanonicalize (H12AffineFastState.compose env37459 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37459 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env37460 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,65536,131072,138340,1024,8232,4161,144493,17,2,8192,65,203847,78958,4097,10281,74794,201831,116,73770,78895,513]

theorem envBound37460 : H12AffineFastState.Bounded env37460 := by
  intro p hp
  have h : env37460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37459_37460 : H12AffineEnvironment.transform 7 116 env37459 = env37460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37459 == env37460) = true)

theorem identity37460 : scanCanonicalize (H12AffineFastState.compose env37460 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound37460 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37461 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,65536,78959,75787,1024,8232,4161,65538,17,2,8192,65,10280,78958,4097,10281,74794,8200,116,73770,78895,513]

theorem envBound37461 : H12AffineFastState.Bounded env37461 := by
  intro p hp
  have h : env37461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37460_37461 : H12AffineEnvironment.transform 16 78959 env37460 = env37461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env37460 == env37461) = true)

theorem identity37461 : scanCanonicalize (H12AffineFastState.compose env37461 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37461 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env37462 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,4161,8233,65536,77914,75787,53,8232,4161,65538,17,2,8192,65,10280,77915,4097,10281,73759,8200,116,73770,77850,513]

theorem envBound37462 : H12AffineFastState.Bounded env37462 := by
  intro p hp
  have h : env37462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37461_37462 : H12AffineEnvironment.transform 9 53 env37461 = env37462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37461 == env37462) = true)

theorem identity37462 : scanCanonicalize (H12AffineFastState.compose env37462 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound37462 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37463 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,4161,8233,114,12328,10361,53,8232,4161,112,17,2,8192,65,10280,12329,4097,10281,8301,8200,116,8280,12392,513]

theorem envBound37463 : H12AffineFastState.Bounded env37463 := by
  intro p hp
  have h : env37463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37462_37463 : H12AffineEnvironment.transform 15 114 env37462 = env37463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env37462 == env37463) = true)

theorem identity37463 : scanCanonicalize (H12AffineFastState.compose env37463 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37463 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37464 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,8192,4113,8233,34,12328,10281,53,8232,4113,32,17,2,8192,17,10280,12329,4097,10281,8253,8200,36,8200,12344,513]

theorem envBound37464 : H12AffineFastState.Bounded env37464 := by
  intro p hp
  have h : env37464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37463_37464 : H12AffineEnvironment.transform 5 16 env37463 = env37464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37463 == env37464) = true)

theorem identity37464 : scanCanonicalize (H12AffineFastState.compose env37464 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound37464 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37465 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,16,8192,1,8233,34,8248,10281,53,8232,1,32,17,2,8192,17,10280,8249,17,10281,8253,8200,36,8200,8232,513]

theorem envBound37465 : H12AffineFastState.Bounded env37465 := by
  intro p hp
  have h : env37465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37464_37465 : H12AffineEnvironment.transform 11 16 env37464 = env37465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37464 == env37465) = true)

theorem identity37465 : scanCanonicalize (H12AffineFastState.compose env37465 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound37465 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env37466 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,16,2617,1,2576,34,2561,528,53,2577,1,32,17,2,2617,17,529,2560,17,528,2564,2609,36,2609,2577,513]

theorem envBound37466 : H12AffineFastState.Bounded env37466 := by
  intro p hp
  have h : env37466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37465_37466 : H12AffineEnvironment.transform 12 2617 env37465 = env37466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env37465 == env37466) = true)

def env37467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,21762,8193,65,215367,115014,17665,10280,119043,201831,256,98678,90203,63069]

theorem envBound37467 : H12AffineFastState.Bounded env37467 := by
  intro p hp
  have h : env37467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37456_37467 : H12AffineEnvironment.transform 6 9 env37456 = env37467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37456 == env37467) = true)

theorem identity37467 : scanCanonicalize (H12AffineFastState.compose env37467 (packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound37467 : packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS < 2^1333 := by decide +kernel

def env37468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,131072,190520,1024,32769,4161,144492,17,21762,8193,65,182336,16449,17665,10280,20484,169312,256,113,57692,63069]

theorem envBound37468 : H12AffineFastState.Bounded env37468 := by
  intro p hp
  have h : env37468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37467_37468 : H12AffineEnvironment.transform 15 33031 env37467 = env37468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env37467 == env37468) = true)

theorem identity37468 : scanCanonicalize (H12AffineFastState.compose env37468 (packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound37468 : packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,49216,10360,1024,32769,4161,62508,17,21762,8193,65,2048,16449,17665,10280,20484,21792,256,113,57692,63069]

theorem envBound37469 : H12AffineFastState.Bounded env37469 := by
  intro p hp
  have h : env37469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37468_37469 : H12AffineEnvironment.transform 16 49216 env37468 = env37469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env37468 == env37469) = true)

theorem identity37469 : scanCanonicalize (H12AffineFastState.compose env37469 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound37469 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env37470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,21591,5392,10360,1024,21841,4161,8572,17,21762,8193,65,2048,16449,17665,10280,20484,21792,256,113,13324,8973]

theorem envBound37470 : H12AffineFastState.Bounded env37470 := by
  intro p hp
  have h : env37470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37469_37470 : H12AffineEnvironment.transform 14 21840 env37469 = env37470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env37469 == env37470) = true)

theorem identity37470 : scanCanonicalize (H12AffineFastState.compose env37470 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37470 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,21591,5392,2421,1024,21841,4161,113,17,21762,268,65,2048,16449,17665,2341,20484,21792,256,113,5377,512]

theorem envBound37471 : H12AffineFastState.Bounded env37471 := by
  intro p hp
  have h : env37471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37470_37471 : H12AffineEnvironment.transform 12 269 env37470 = env37471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37470 == env37471) = true)

theorem identity37471 : scanCanonicalize (H12AffineFastState.compose env37471 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4420) := by decide +kernel

theorem selectedBound37471 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4420,1044,1299,5392,2421,1024,1045,4161,113,17,1094,268,65,2048,4357,5189,2341,320,1124,256,113,5377,512]

theorem envBound37472 : H12AffineFastState.Bounded env37472 := by
  intro p hp
  have h : env37472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37471_37472 : H12AffineEnvironment.transform 13 4420 env37471 = env37472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4420 env37471 == env37472) = true)

theorem identity37472 : scanCanonicalize (H12AffineFastState.compose env37472 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound37472 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37473 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,4096,269,4420,293,34,4129,2421,305,292,4161,113,17,375,268,65,2048,4357,4468,2341,320,341,256,113,4144,512]

theorem envBound37473 : H12AffineFastState.Bounded env37473 := by
  intro p hp
  have h : env37473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37472_37473 : H12AffineEnvironment.transform 9 305 env37472 = env37473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env37472 == env37473) = true)

theorem identity37473 : scanCanonicalize (H12AffineFastState.compose env37473 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37473 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env37474 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,4096,41,4192,1,34,4129,2129,21,0,4161,113,17,83,40,65,2048,4129,4176,2049,100,113,36,113,4144,512]

theorem envBound37474 : H12AffineFastState.Bounded env37474 := by
  intro p hp
  have h : env37474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37473_37474 : H12AffineEnvironment.transform 7 36 env37473 = env37474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37473 == env37474) = true)

theorem identity37474 : scanCanonicalize (H12AffineFastState.compose env37474 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37474 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37475 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,2064,41,2160,1,34,2097,2129,21,0,2129,113,17,83,40,65,2048,2097,2112,2049,100,113,36,113,2080,512]

theorem envBound37475 : H12AffineFastState.Bounded env37475 := by
  intro p hp
  have h : env37475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37474_37475 : H12AffineEnvironment.transform 11 2064 env37474 = env37475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37474 == env37475) = true)

theorem identity37475 : scanCanonicalize (H12AffineFastState.compose env37475 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37475 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37476 : List Nat := [2,4,8,16,0,64,9,4,512,21,2048,2064,9,2128,1,2,2065,2129,21,0,2129,81,17,83,8,65,2048,2065,2112,2049,68,81,4,81,2048,512]

theorem envBound37476 : H12AffineFastState.Bounded env37476 := by
  intro p hp
  have h : env37476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37475_37476 : H12AffineEnvironment.transform 4 0 env37475 = env37476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37475 == env37476) = true)

theorem identity37476 : scanCanonicalize (H12AffineFastState.compose env37476 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37476 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env37477 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,2064,9,2048,1,2,2065,2049,21,0,2049,1,17,3,8,17,2048,2065,2064,2049,20,1,4,1,2048,512]

theorem envBound37477 : H12AffineFastState.Bounded env37477 := by
  intro p hp
  have h : env37477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37476_37477 : H12AffineEnvironment.transform 5 16 env37476 = env37477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37476 == env37477) = true)

theorem identity37477 : scanCanonicalize (H12AffineFastState.compose env37477 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37478 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,1,1,2,16,0,21,0,0,1,17,3,8,17,1,16,17,0,20,1,4,1,1,512]

theorem envBound37478 : H12AffineFastState.Bounded env37478 := by
  intro p hp
  have h : env37478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37477_37478 : H12AffineEnvironment.transform 10 1 env37477 = env37478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37477 == env37478) = true)

theorem identity37478 : scanCanonicalize (H12AffineFastState.compose env37478 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound37478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37479 : List Nat := [2,4,8,5,0,5,9,4,512,0,1,4,9,1,1,2,5,0,0,0,0,1,4,3,8,4,1,5,4,0,1,1,4,1,1,512]

theorem envBound37479 : H12AffineFastState.Bounded env37479 := by
  intro p hp
  have h : env37479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37478_37479 : H12AffineEnvironment.transform 3 5 env37478 = env37479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37478 == env37479) = true)

theorem identity37479 : scanCanonicalize (H12AffineFastState.compose env37479 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37480 : List Nat := [2,1,8,0,0,0,9,1,512,0,1,1,9,1,1,2,0,0,0,0,0,1,1,3,8,1,1,0,1,0,1,1,1,1,1,512]

theorem envBound37480 : H12AffineFastState.Bounded env37480 := by
  intro p hp
  have h : env37480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37479_37480 : H12AffineEnvironment.transform 1 1 env37479 = env37480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37479 == env37480) = true)

theorem identity37480 : scanCanonicalize (H12AffineFastState.compose env37480 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37480 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37481 : List Nat := [2,1,8,0,0,0,9,1,0,0,1,1,9,1,1,2,0,0,0,0,0,1,1,3,8,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound37481 : H12AffineFastState.Bounded env37481 := by
  intro p hp
  have h : env37481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37480_37481 : H12AffineEnvironment.transform 8 0 env37480 = env37481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37480 == env37481) = true)

def env37482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,2114883,8328,65,4292003,115151,17664,2111713,119042,4268162,256,2199999,2191387,63189]

theorem envBound37482 : H12AffineFastState.Bounded env37482 := by
  intro p hp
  have h : env37482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37426_37482 : H12AffineEnvironment.transform 22 2101329 env37426 = env37482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env37426 == env37482) = true)

def env37483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,21763,8328,65,4292003,115151,17664,10401,119042,4268162,256,98815,90203,63189]

theorem envBound37483 : H12AffineFastState.Bounded env37483 := by
  intro p hp
  have h : env37483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37482_37483 : H12AffineEnvironment.transform 20 4160 env37482 = env37483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37482 == env37483) = true)

theorem identity37483 : scanCanonicalize (H12AffineFastState.compose env37483 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound37483 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,180272,17,21763,8328,65,245139,115151,17664,10401,119042,254130,256,98815,90203,63189]

theorem envBound37484 : H12AffineFastState.Bounded env37484 := by
  intro p hp
  have h : env37484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37483_37484 : H12AffineEnvironment.transform 21 180272 env37483 = env37484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env37483 == env37484) = true)

def env37485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180272,17,21763,8192,65,245019,115015,17664,10281,119042,254010,256,98679,90203,63069]

theorem envBound37485 : H12AffineFastState.Bounded env37485 := by
  intro p hp
  have h : env37485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37484_37485 : H12AffineEnvironment.transform 6 8 env37484 = env37485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37484 == env37485) = true)

theorem identity37485 : scanCanonicalize (H12AffineFastState.compose env37485 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37485 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4160,156013,17,21763,8192,65,203846,90138,17664,10281,94303,213351,256,73770,90203,22272]

theorem envBound37486 : H12AffineFastState.Bounded env37486 := by
  intro p hp
  have h : env37486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37485_37486 : H12AffineEnvironment.transform 14 8541 env37485 = env37486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37485 == env37486) = true)

theorem identity37486 : scanCanonicalize (H12AffineFastState.compose env37486 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound37486 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env37487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,76159,1024,8540,4160,65910,17,21763,8192,65,31837,90138,17664,10281,94303,8572,256,73770,90203,22272]

theorem envBound37487 : H12AffineFastState.Bounded env37487 := by
  intro p hp
  have h : env37487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37486_37487 : H12AffineEnvironment.transform 16 90139 env37486 = env37487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env37486 == env37487) = true)

theorem identity37487 : scanCanonicalize (H12AffineFastState.compose env37487 (packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound37487 : packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS < 2^1333 := by decide +kernel

def env37488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21875,13672,31756,1024,8540,4160,21509,17,21763,8192,65,31837,13673,17664,10281,9516,8572,256,30041,13608,22272]

theorem envBound37488 : H12AffineFastState.Bounded env37488 := by
  intro p hp
  have h : env37488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37487_37488 : H12AffineEnvironment.transform 15 21875 env37487 = env37488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env37487 == env37488) = true)

theorem identity37488 : scanCanonicalize (H12AffineFastState.compose env37488 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound37488 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env37489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8202,13672,2421,1024,8540,4160,8572,17,8314,8192,65,2340,13673,12409,10281,9516,8572,256,32,13608,8825]

theorem envBound37489 : H12AffineFastState.Bounded env37489 := by
  intro p hp
  have h : env37489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37488_37489 : H12AffineEnvironment.transform 13 13689 env37488 = env37489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env37488 == env37489) = true)

theorem identity37489 : scanCanonicalize (H12AffineFastState.compose env37489 (packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37489 : packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env37490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,0,343,5173,2421,1024,1,4160,33,17,295,349,65,2340,5172,4388,2420,1137,33,256,32,5237,804]

theorem envBound37490 : H12AffineFastState.Bounded env37490 := by
  intro p hp
  have h : env37490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37489_37490 : H12AffineEnvironment.transform 12 349 env37489 = env37490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37489 == env37490) = true)

theorem identity37490 : scanCanonicalize (H12AffineFastState.compose env37490 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37490 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37491 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4404,0,343,4389,2421,272,1,4160,33,17,295,349,65,2340,4388,4388,2420,353,33,256,32,4453,804]

theorem envBound37491 : H12AffineFastState.Bounded env37491 := by
  intro p hp
  have h : env37491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37490_37491 : H12AffineEnvironment.transform 9 272 env37490 = env37491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37490 == env37491) = true)

theorem identity37491 : scanCanonicalize (H12AffineFastState.compose env37491 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound37491 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37492 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,349,2129,0,343,2112,2421,272,1,2341,33,17,295,349,65,2340,2113,2113,2420,353,33,256,32,2048,804]

theorem envBound37492 : H12AffineFastState.Bounded env37492 := by
  intro p hp
  have h : env37492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37491_37492 : H12AffineEnvironment.transform 11 2405 env37491 = env37492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env37491 == env37492) = true)

theorem identity37492 : scanCanonicalize (H12AffineFastState.compose env37492 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37492 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37493 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,41,2129,0,35,2112,2049,100,1,2129,33,17,83,41,65,2128,2113,2113,2048,21,33,116,32,2048,592]

theorem envBound37493 : H12AffineFastState.Bounded env37493 := by
  intro p hp
  have h : env37493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37492_37493 : H12AffineEnvironment.transform 7 116 env37492 = env37493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37492 == env37493) = true)

theorem identity37493 : scanCanonicalize (H12AffineFastState.compose env37493 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound37493 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env37494 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,64,41,0,0,35,17,80,100,1,0,33,17,83,41,65,1,16,16,81,21,33,116,32,81,592]

theorem envBound37494 : H12AffineFastState.Bounded env37494 := by
  intro p hp
  have h : env37494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37493_37494 : H12AffineEnvironment.transform 10 81 env37493 = env37494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env37493 == env37494) = true)

theorem identity37494 : scanCanonicalize (H12AffineFastState.compose env37494 (packedSelected [2,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37494 : packedSelected [2,16] rootPS < 2^1333 := by decide +kernel

def env37495 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,41,0,0,35,17,1,53,1,0,33,17,2,41,16,1,16,16,0,21,33,37,32,0,513]

theorem envBound37495 : H12AffineFastState.Bounded env37495 := by
  intro p hp
  have h : env37495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37494_37495 : H12AffineEnvironment.transform 5 17 env37494 = env37495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37494 == env37495) = true)

theorem identity37495 : scanCanonicalize (H12AffineFastState.compose env37495 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37495 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37496 : List Nat := [2,4,8,16,27,17,8,30,512,14,0,17,18,0,0,24,17,1,14,1,0,26,17,2,18,16,1,16,16,0,21,26,30,27,0,513]

theorem envBound37496 : H12AffineFastState.Bounded env37496 := by
  intro p hp
  have h : env37496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37495_37496 : H12AffineEnvironment.transform 4 27 env37495 = env37496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37495 == env37496) = true)

def env37497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180272,17,21763,8193,65,245018,115014,17664,10280,119042,254011,256,98678,90203,63068]

theorem envBound37497 : H12AffineFastState.Bounded env37497 := by
  intro p hp
  have h : env37497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37484_37497 : H12AffineEnvironment.transform 6 9 env37484 = env37497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37484 == env37497) = true)

theorem identity37497 : scanCanonicalize (H12AffineFastState.compose env37497 (packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound37497 : packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env37498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82198,108846,1024,32769,4160,98598,17,21763,8193,65,64524,115014,17664,10280,119042,41261,256,98678,90203,63068]

theorem envBound37498 : H12AffineFastState.Bounded env37498 := by
  intro p hp
  have h : env37498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37497_37498 : H12AffineEnvironment.transform 16 82198 env37497 = env37498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env37497 == env37498) = true)

theorem identity37498 : scanCanonicalize (H12AffineFastState.compose env37498 (packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound37498 : packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env37499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,13388,56436,1024,32769,4160,62588,17,21763,8193,65,64524,46108,17664,10280,42072,41261,256,62508,5377,63068]

theorem envBound37499 : H12AffineFastState.Bounded env37499 := by
  intro p hp
  have h : env37499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37498_37499 : H12AffineEnvironment.transform 15 30042 env37498 = env37499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env37498 == env37499) = true)

theorem identity37499 : scanCanonicalize (H12AffineFastState.compose env37499 (packedSelected [4,10,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound37499 : packedSelected [4,10,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env37500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,30042,13388,2420,1024,21761,4160,8572,17,21763,8193,65,10508,24860,17664,10280,29016,29741,256,8492,5377,9052]

theorem envBound37500 : H12AffineFastState.Bounded env37500 := by
  intro p hp
  have h : env37500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37499_37500 : H12AffineEnvironment.transform 14 21760 env37499 = env37500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env37499 == env37500) = true)

def env37501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,21762,8328,65,4292003,115151,17664,10400,119042,4268162,256,98814,90202,63189]

theorem envBound37501 : H12AffineFastState.Bounded env37501 := by
  intro p hp
  have h : env37501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37482_37501 : H12AffineEnvironment.transform 20 4161 env37482 = env37501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37482 == env37501) = true)

def env37502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21762,8192,65,4291883,115015,17664,10280,119042,4268042,256,98678,90202,63069]

theorem envBound37502 : H12AffineFastState.Bounded env37502 := by
  intro p hp
  have h : env37502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37501_37502 : H12AffineEnvironment.transform 6 8 env37501 = env37502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37501 == env37502) = true)

theorem identity37502 : scanCanonicalize (H12AffineFastState.compose env37502 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound37502 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4161,4194304,16,21762,8192,65,4291883,115015,17664,10280,119042,4268042,256,98678,90202,63069]

theorem envBound37503 : H12AffineFastState.Bounded env37503 := by
  intro p hp
  have h : env37503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37502_37503 : H12AffineEnvironment.transform 16 24908 env37502 = env37503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env37502 == env37503) = true)

theorem identity37503 : scanCanonicalize (H12AffineFastState.compose env37503 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound37503 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env37504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24908,35189,1024,32769,4161,4194304,16,21762,8192,65,4229152,13388,17664,10280,9225,4248833,256,29821,38225,63069]

theorem envBound37504 : H12AffineFastState.Bounded env37504 := by
  intro p hp
  have h : env37504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37503_37504 : H12AffineEnvironment.transform 15 62731 env37503 = env37504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env37503 == env37504) = true)

theorem identity37504 : scanCanonicalize (H12AffineFastState.compose env37504 (packedSelected [1,4,8,9,12,14,19,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound37504 : packedSelected [1,4,8,9,12,14,19,20,38] rootPS < 2^1333 := by decide +kernel

def env37505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,35,24908,31837,1024,29993,4161,4194304,16,21762,8192,65,4226312,13388,17664,10280,9225,4202537,256,29821,24697,885]

theorem envBound37505 : H12AffineFastState.Bounded env37505 := by
  intro p hp
  have h : env37505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37504_37505 : H12AffineEnvironment.transform 14 29992 env37504 = env37505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env37504 == env37505) = true)

theorem identity37505 : scanCanonicalize (H12AffineFastState.compose env37505 (packedSelected [3,4,5,8,9,10,14,16,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37505 : packedSelected [3,4,5,8,9,10,14,16,28,31] rootPS < 2^1333 := by decide +kernel

def env37506 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,35,24632,31837,1024,29789,4161,4194304,16,21622,8192,65,4226172,13388,17524,10280,9225,4202537,116,29821,24697,513]

theorem envBound37506 : H12AffineFastState.Bounded env37506 := by
  intro p hp
  have h : env37506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37505_37506 : H12AffineEnvironment.transform 7 116 env37505 = env37506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37505 == env37506) = true)

theorem identity37506 : scanCanonicalize (H12AffineFastState.compose env37506 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound37506 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37507 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4113,9293,35,12329,11340,1024,9292,4161,4194304,16,1127,8192,65,4205677,13388,5221,10280,9225,4202537,116,9324,12392,513]

theorem envBound37507 : H12AffineFastState.Bounded env37507 := by
  intro p hp
  have h : env37507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37506_37507 : H12AffineEnvironment.transform 13 4113 env37506 = env37507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env37506 == env37507) = true)

theorem identity37507 : scanCanonicalize (H12AffineFastState.compose env37507 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37507 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env37508 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,8192,4113,8313,35,12329,10360,52,8312,4161,4194304,16,83,8192,65,4204633,12408,4177,10280,8253,4202537,116,8280,12392,513]

theorem envBound37508 : H12AffineFastState.Bounded env37508 := by
  intro p hp
  have h : env37508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37507_37508 : H12AffineEnvironment.transform 9 52 env37507 = env37508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37507 == env37508) = true)

theorem identity37508 : scanCanonicalize (H12AffineFastState.compose env37508 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound37508 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37509 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,8192,4113,8313,35,12329,10360,52,8312,4161,8201,16,83,8192,65,2128,12408,4177,10280,8253,32,116,8280,12392,513]

theorem envBound37509 : H12AffineFastState.Bounded env37509 := by
  intro p hp
  have h : env37509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37508_37509 : H12AffineEnvironment.transform 21 8201 env37508 = env37509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env37508 == env37509) = true)

theorem identity37509 : scanCanonicalize (H12AffineFastState.compose env37509 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37509 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37510 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4113,0,35,4176,2049,52,1,4161,112,16,83,121,65,2128,4097,4177,2129,68,32,116,33,4113,513]

theorem envBound37510 : H12AffineFastState.Bounded env37510 := by
  intro p hp
  have h : env37510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37509_37510 : H12AffineEnvironment.transform 12 121 env37509 = env37510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37509 == env37510) = true)

theorem identity37510 : scanCanonicalize (H12AffineFastState.compose env37510 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37510 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env37511 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,0,35,4096,2049,52,1,4113,32,16,3,41,17,2048,4097,4097,2049,20,32,36,33,4113,513]

theorem envBound37511 : H12AffineFastState.Bounded env37511 := by
  intro p hp
  have h : env37511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37510_37511 : H12AffineEnvironment.transform 5 16 env37510 = env37511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37510 == env37511) = true)

theorem identity37511 : scanCanonicalize (H12AffineFastState.compose env37511 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound37511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37512 : List Nat := [2,4,8,16,32,16,8,36,32,52,2048,4096,41,4113,0,35,4096,2049,52,1,4113,32,16,3,41,17,2048,4097,4097,2049,20,32,36,33,4113,33]

theorem envBound37512 : H12AffineFastState.Bounded env37512 := by
  intro p hp
  have h : env37512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37511_37512 : H12AffineEnvironment.transform 8 32 env37511 = env37512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env37511 == env37512) = true)

theorem identity37512 : scanCanonicalize (H12AffineFastState.compose env37512 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound37512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37513 : List Nat := [2,4,8,16,32,16,8,36,32,52,2048,16,41,1,0,35,16,2049,52,1,1,32,16,3,41,17,2048,17,17,2049,20,32,36,33,1,33]

theorem envBound37513 : H12AffineFastState.Bounded env37513 := by
  intro p hp
  have h : env37513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37512_37513 : H12AffineEnvironment.transform 11 16 env37512 = env37513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37512 == env37513) = true)

theorem identity37513 : scanCanonicalize (H12AffineFastState.compose env37513 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37513 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37514 : List Nat := [2,4,8,16,16,16,8,20,16,4,2048,16,25,1,0,19,16,2049,4,1,1,16,16,3,25,17,2048,17,17,2049,20,16,20,17,1,17]

theorem envBound37514 : H12AffineFastState.Bounded env37514 := by
  intro p hp
  have h : env37514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37513_37514 : H12AffineEnvironment.transform 4 16 env37513 = env37514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37513 == env37514) = true)

theorem identity37514 : scanCanonicalize (H12AffineFastState.compose env37514 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37514 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37515 : List Nat := [2,4,8,0,0,0,8,4,0,4,2048,0,9,1,0,3,0,2049,4,1,1,0,0,3,9,1,2048,1,1,2049,4,0,4,1,1,1]

theorem envBound37515 : H12AffineFastState.Bounded env37515 := by
  intro p hp
  have h : env37515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37514_37515 : H12AffineEnvironment.transform 3 0 env37514 = env37515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37514 == env37515) = true)

def env37516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21762,8193,65,4291882,115014,17664,10281,119042,4268043,256,98679,90202,63068]

theorem envBound37516 : H12AffineFastState.Bounded env37516 := by
  intro p hp
  have h : env37516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37501_37516 : H12AffineEnvironment.transform 6 9 env37501 = env37516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37501 == env37516) = true)

theorem identity37516 : scanCanonicalize (H12AffineFastState.compose env37516 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound37516 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,4194304,16,21762,8193,65,4291882,115014,17664,10281,119042,4268043,256,98679,90202,63068]

theorem envBound37517 : H12AffineFastState.Bounded env37517 := by
  intro p hp
  have h : env37517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37516_37517 : H12AffineEnvironment.transform 16 49169 env37516 = env37517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env37516 == env37517) = true)

theorem identity37517 : scanCanonicalize (H12AffineFastState.compose env37517 (packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37517 : packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS < 2^1333 := by decide +kernel

def env37518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1024,29788,4161,4194304,16,21762,8193,65,4291882,79131,17664,10281,75103,4268043,256,95530,90202,513]

theorem envBound37518 : H12AffineFastState.Bounded env37518 := by
  intro p hp
  have h : env37518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37517_37518 : H12AffineEnvironment.transform 14 29789 env37517 = env37518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37517 == env37518) = true)

theorem identity37518 : scanCanonicalize (H12AffineFastState.compose env37518 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37518 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env37519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13388,10281,1024,29788,4161,4194304,16,21762,8193,65,4218144,5393,17664,10281,1365,4194305,256,21792,16464,513]

theorem envBound37519 : H12AffineFastState.Bounded env37519 := by
  intro p hp
  have h : env37519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37518_37519 : H12AffineEnvironment.transform 15 8202 env37518 = env37519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37518 == env37519) = true)

theorem identity37519 : scanCanonicalize (H12AffineFastState.compose env37519 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37519 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env37520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,262,5440,2341,1024,21840,4161,4194304,16,21762,269,65,4218144,5393,17664,2341,1365,4194305,256,21792,16464,513]

theorem envBound37520 : H12AffineFastState.Bounded env37520 := by
  intro p hp
  have h : env37520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37519_37520 : H12AffineEnvironment.transform 12 268 env37519 = env37520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37519 == env37520) = true)

theorem identity37520 : scanCanonicalize (H12AffineFastState.compose env37520 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound37520 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env37521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,262,5440,2341,1024,21840,4161,21792,16,21762,269,65,2048,5393,17664,2341,1365,21793,256,21792,16464,513]

theorem envBound37521 : H12AffineFastState.Bounded env37521 := by
  intro p hp
  have h : env37521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37520_37521 : H12AffineEnvironment.transform 21 21792 env37520 = env37521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env37520 == env37521) = true)

theorem identity37521 : scanCanonicalize (H12AffineFastState.compose env37521 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound37521 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env37522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,1,262,5440,2341,1024,0,4161,112,16,82,269,65,2048,5393,4176,2341,1365,113,256,112,5376,513]

theorem envBound37522 : H12AffineFastState.Bounded env37522 := by
  intro p hp
  have h : env37522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37521_37522 : H12AffineEnvironment.transform 13 5456 env37521 = env37522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env37521 == env37522) = true)

theorem identity37522 : scanCanonicalize (H12AffineFastState.compose env37522 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37522 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37523 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4112,33,16,3,269,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound37523 : H12AffineFastState.Bounded env37523 := by
  intro p hp
  have h : env37523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37522_37523 : H12AffineEnvironment.transform 5 17 env37522 = env37523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37522 == env37523) = true)

theorem identity37523 : scanCanonicalize (H12AffineFastState.compose env37523 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37523 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37524 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5173,2049,1024,0,4112,33,16,3,41,16,2048,5173,4097,2049,1056,32,36,33,5156,513]

theorem envBound37524 : H12AffineFastState.Bounded env37524 := by
  intro p hp
  have h : env37524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37523_37524 : H12AffineEnvironment.transform 7 36 env37523 = env37524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37523 == env37524) = true)

theorem identity37524 : scanCanonicalize (H12AffineFastState.compose env37524 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37524 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37525 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5157,1,34,5173,523,1024,0,4112,33,16,3,41,16,522,5173,4097,523,1056,32,36,33,5156,513]

theorem envBound37525 : H12AffineFastState.Bounded env37525 := by
  intro p hp
  have h : env37525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37524_37525 : H12AffineEnvironment.transform 10 522 env37524 = env37525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37524 == env37525) = true)

theorem identity37525 : scanCanonicalize (H12AffineFastState.compose env37525 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37525 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37526 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,9,5124,1,3,5140,523,1024,0,4112,0,16,3,8,16,522,5140,4097,523,1025,1,5,0,5125,513]

theorem envBound37526 : H12AffineFastState.Bounded env37526 := by
  intro p hp
  have h : env37526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37525_37526 : H12AffineEnvironment.transform 4 1 env37525 = env37526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37525 == env37526) = true)

def env37527 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,16,9,1044,1,3,1028,523,1024,0,0,0,16,3,8,16,522,1028,17,523,1025,1,5,0,1045,513]

theorem envBound37527 : H12AffineFastState.Bounded env37527 := by
  intro p hp
  have h : env37527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37526_37527 : H12AffineEnvironment.transform 11 16 env37526 = env37527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37526 == env37527) = true)

theorem identity37527 : scanCanonicalize (H12AffineFastState.compose env37527 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound37527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37528 : List Nat := [2,4,8,16,1,17,9,5,512,0,522,16,9,20,1,3,4,523,0,0,0,0,16,3,8,16,522,4,17,523,1,1,5,0,21,513]

theorem envBound37528 : H12AffineFastState.Bounded env37528 := by
  intro p hp
  have h : env37528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37527_37528 : H12AffineEnvironment.transform 9 0 env37527 = env37528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env37527 == env37528) = true)

def env37529 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,4,9,0,1,3,4,523,0,0,0,0,4,3,8,4,522,4,5,523,1,1,5,0,1,513]

theorem envBound37529 : H12AffineFastState.Bounded env37529 := by
  intro p hp
  have h : env37529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37528_37529 : H12AffineEnvironment.transform 3 4 env37528 = env37529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37528 == env37529) = true)

theorem identity37529 : scanCanonicalize (H12AffineFastState.compose env37529 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound37529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0