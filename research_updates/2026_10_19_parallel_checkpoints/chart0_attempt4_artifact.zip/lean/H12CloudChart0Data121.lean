import H12CloudChart0Data120

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound30694 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30695 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4373,260,263,4096,2309,273,261,4112,1,17,262,269,16,2308,4097,4357,2309,21,1,257,293,4372,512]

theorem envBound30695 : H12AffineFastState.Bounded env30695 := by
  intro p hp
  have h : env30695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30694_30695 : H12AffineEnvironment.transform 9 272 env30694 = env30695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30694 == env30695) = true)

theorem identity30695 : scanCanonicalize (H12AffineFastState.compose env30695 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30695 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30696 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4145,32,35,4096,2081,53,33,4112,1,17,34,41,16,2080,4097,4129,2081,21,1,37,1,4144,512]

theorem envBound30696 : H12AffineFastState.Bounded env30696 := by
  intro p hp
  have h : env30696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30695_30696 : H12AffineEnvironment.transform 7 36 env30695 = env30696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30695 == env30696) = true)

theorem identity30696 : scanCanonicalize (H12AffineFastState.compose env30696 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound30696 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30697 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2096,41,2049,32,35,2096,2081,53,33,2080,1,17,34,41,16,2080,2097,2065,2081,21,1,37,1,2048,512]

theorem envBound30697 : H12AffineFastState.Bounded env30697 := by
  intro p hp
  have h : env30697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30696_30697 : H12AffineEnvironment.transform 11 2096 env30696 = env30697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env30696 == env30697) = true)

theorem identity30697 : scanCanonicalize (H12AffineFastState.compose env30697 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound30697 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30698 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,17,41,32,32,35,17,0,53,33,1,1,17,34,41,16,1,16,48,0,21,1,37,1,33,512]

theorem envBound30698 : H12AffineFastState.Bounded env30698 := by
  intro p hp
  have h : env30698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30697_30698 : H12AffineEnvironment.transform 10 33 env30697 = env30698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env30697 == env30698) = true)

theorem identity30698 : scanCanonicalize (H12AffineFastState.compose env30698 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30699 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,9,0,0,3,17,0,21,1,1,1,17,2,9,16,1,16,16,0,21,1,5,1,1,512]

theorem envBound30699 : H12AffineFastState.Bounded env30699 := by
  intro p hp
  have h : env30699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30698_30699 : H12AffineEnvironment.transform 4 0 env30698 = env30699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30698 == env30699) = true)

theorem identity30699 : scanCanonicalize (H12AffineFastState.compose env30699 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30700 : List Nat := [2,4,8,16,0,16,8,4,16,20,1,17,9,0,0,3,17,0,21,1,1,1,17,2,9,16,1,16,16,0,21,1,5,1,1,16]

theorem envBound30700 : H12AffineFastState.Bounded env30700 := by
  intro p hp
  have h : env30700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30699_30700 : H12AffineEnvironment.transform 8 16 env30699 = env30700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30699 == env30700) = true)

theorem identity30700 : scanCanonicalize (H12AffineFastState.compose env30700 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30701 : List Nat := [2,0,8,16,0,16,8,0,16,16,1,17,9,0,0,3,17,0,17,1,1,1,17,2,9,16,1,16,16,0,17,1,1,1,1,16]

theorem envBound30701 : H12AffineFastState.Bounded env30701 := by
  intro p hp
  have h : env30701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30700_30701 : H12AffineEnvironment.transform 1 0 env30700 = env30701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30700 == env30701) = true)

def env30702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,400405,144517,213405,8328,17,23945,139653,160148,262144,1420,272393,257,21792,16384,74250]

theorem envBound30702 : H12AffineFastState.Bounded env30702 := by
  intro p hp
  have h : env30702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30687_30702 : H12AffineEnvironment.transform 5 17 env30687 = env30702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30687 == env30702) = true)

theorem identity30702 : scanCanonicalize (H12AffineFastState.compose env30702 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound30702 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30703 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79251,262144,1025,29828,4113,338310,65814,29710,8328,17,23945,70678,82951,262144,1420,272393,257,21792,16384,74250]

theorem envBound30703 : H12AffineFastState.Bounded env30703 := by
  intro p hp
  have h : env30703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30702_30703 : H12AffineEnvironment.transform 16 79251 env30702 = env30703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env30702 == env30703) = true)

theorem identity30703 : scanCanonicalize (H12AffineFastState.compose env30703 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound30703 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30704 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79251,67754,1025,29828,4113,8492,65814,29710,8328,17,23945,70678,82951,67754,1420,73891,257,21792,16384,74250]

theorem envBound30704 : H12AffineFastState.Bounded env30704 := by
  intro p hp
  have h : env30704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30703_30704 : H12AffineEnvironment.transform 17 67754 env30703 = env30704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env30703 == env30704) = true)

theorem identity30704 : scanCanonicalize (H12AffineFastState.compose env30704 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound30704 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env30705 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,29962,16537,32160,1025,29828,4113,8492,29724,29710,8328,17,23945,24860,12557,32160,1420,21929,257,21792,16384,22272]

theorem envBound30705 : H12AffineFastState.Bounded env30705 := by
  intro p hp
  have h : env30705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30704_30705 : H12AffineEnvironment.transform 15 29962 env30704 = env30705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env30704 == env30705) = true)

theorem identity30705 : scanCanonicalize (H12AffineFastState.compose env30705 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30705 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env30706 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,8202,5529,10400,1025,8580,4113,8492,8476,8462,8328,17,2185,13340,12557,10400,1420,169,257,32,5376,512]

theorem envBound30706 : H12AffineFastState.Bounded env30706 := by
  intro p hp
  have h : env30706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30705_30706 : H12AffineEnvironment.transform 13 5376 env30705 = env30706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30705 == env30706) = true)

theorem identity30706 : scanCanonicalize (H12AffineFastState.compose env30706 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound30706 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30707 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,5376,8492,8202,5424,10249,1025,8493,4113,8492,8476,8462,8225,17,2080,13340,12557,10249,1317,0,257,32,5376,512]

theorem envBound30707 : H12AffineFastState.Bounded env30707 := by
  intro p hp
  have h : env30707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30706_30707 : H12AffineEnvironment.transform 6 41 env30706 = env30707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env30706 == env30707) = true)

theorem identity30707 : scanCanonicalize (H12AffineFastState.compose env30707 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30707 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30708 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,40,5376,260,34,5424,2081,1025,261,4113,260,308,294,9,17,2080,5172,4389,2081,1317,0,257,32,5376,512]

theorem envBound30708 : H12AffineFastState.Bounded env30708 := by
  intro p hp
  have h : env30708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30707_30708 : H12AffineEnvironment.transform 12 40 env30707 = env30708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30707 == env30708) = true)

theorem identity30708 : scanCanonicalize (H12AffineFastState.compose env30708 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound30708 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env30709 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,3077,40,2309,260,34,2357,2081,1025,261,3092,260,308,294,9,17,2080,2097,3360,2081,1317,0,257,32,2309,512]

theorem envBound30709 : H12AffineFastState.Bounded env30709 := by
  intro p hp
  have h : env30709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30708_30709 : H12AffineEnvironment.transform 11 3077 env30708 = env30709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env30708 == env30709) = true)

theorem identity30709 : scanCanonicalize (H12AffineFastState.compose env30709 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30709 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env30710 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,3077,9,2309,260,3,2324,2048,1025,261,3092,260,277,263,9,17,2049,2064,3329,2048,1284,0,257,1,2309,512]

theorem envBound30710 : H12AffineFastState.Bounded env30710 := by
  intro p hp
  have h : env30710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30709_30710 : H12AffineEnvironment.transform 4 1 env30709 = env30710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30709 == env30710) = true)

theorem identity30710 : scanCanonicalize (H12AffineFastState.compose env30710 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30710 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30711 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3077,9,2049,0,3,2064,2048,1025,1,3092,0,17,3,9,17,2049,2064,3077,2048,1024,0,5,1,2049,512]

theorem envBound30711 : H12AffineFastState.Bounded env30711 := by
  intro p hp
  have h : env30711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30710_30711 : H12AffineEnvironment.transform 7 4 env30710 = env30711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30710 == env30711) = true)

theorem identity30711 : scanCanonicalize (H12AffineFastState.compose env30711 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30712 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1,1028,9,0,0,3,17,1,1025,1,1045,0,17,3,9,17,0,17,1028,1,1024,0,5,1,0,512]

theorem envBound30712 : H12AffineFastState.Bounded env30712 := by
  intro p hp
  have h : env30712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30711_30712 : H12AffineEnvironment.transform 10 1 env30711 = env30712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30711 == env30712) = true)

theorem identity30712 : scanCanonicalize (H12AffineFastState.compose env30712 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30713 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1,1028,9,0,0,3,17,1,1025,1,1045,0,17,3,9,17,0,17,1028,1,1024,0,5,1,0,1]

theorem envBound30713 : H12AffineFastState.Bounded env30713 := by
  intro p hp
  have h : env30713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30712_30713 : H12AffineEnvironment.transform 8 1 env30712 = env30713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30712 == env30713) = true)

theorem identity30713 : scanCanonicalize (H12AffineFastState.compose env30713 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30713 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30714 : List Nat := [2,4,8,16,1,17,8,4,1,20,1,16,9,0,0,3,17,1,21,1,1,0,17,3,9,17,0,17,16,1,20,0,5,1,0,1]

theorem envBound30714 : H12AffineFastState.Bounded env30714 := by
  intro p hp
  have h : env30714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30713_30714 : H12AffineEnvironment.transform 9 20 env30713 = env30714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30713 == env30714) = true)

theorem identity30714 : scanCanonicalize (H12AffineFastState.compose env30714 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound30714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30715 : List Nat := [2,4,8,14,1,15,8,4,1,10,1,14,9,0,0,3,15,1,11,1,1,0,15,3,9,15,0,15,14,1,10,0,5,1,0,1]

theorem envBound30715 : H12AffineFastState.Bounded env30715 := by
  intro p hp
  have h : env30715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30714_30715 : H12AffineEnvironment.transform 3 14 env30714 = env30715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env30714 == env30715) = true)

def env30716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144597,242968,8328,64,43356,139733,160197,324821,1500,272392,257,21792,46213,74251]

theorem envBound30716 : H12AffineFastState.Bounded env30716 := by
  intro p hp
  have h : env30716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30685_30716 : H12AffineEnvironment.transform 20 4161 env30685 = env30716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30685 == env30716) = true)

theorem identity30716 : scanCanonicalize (H12AffineFastState.compose env30716 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound30716 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4161,318548,17,98780,8328,64,43356,5393,17665,324821,1500,272392,257,21792,46213,74251]

theorem envBound30717 : H12AffineFastState.Bounded env30717 := by
  intro p hp
  have h : env30717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30716_30717 : H12AffineEnvironment.transform 16 13508 env30716 = env30717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env30716 == env30717) = true)

def env30718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,17,98644,8192,64,43356,5393,17665,324701,1364,272392,257,21792,46093,74251]

theorem envBound30718 : H12AffineFastState.Bounded env30718 := by
  intro p hp
  have h : env30718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30717_30718 : H12AffineEnvironment.transform 6 8 env30717 = env30718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30717 == env30718) = true)

theorem identity30718 : scanCanonicalize (H12AffineFastState.compose env30718 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound30718 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67619,1025,32769,4161,119927,17,98644,8192,64,43356,5393,17665,130174,1364,73771,257,21792,46093,74251]

theorem envBound30719 : H12AffineFastState.Bounded env30719 := by
  intro p hp
  have h : env30719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30718_30719 : H12AffineEnvironment.transform 17 67619 env30718 = env30719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env30718 == env30719) = true)

theorem identity30719 : scanCanonicalize (H12AffineFastState.compose env30719 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound30719 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env30720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,13388,23669,1025,32769,4161,32801,17,54530,8192,64,43356,5393,17665,43048,1364,29821,257,21792,46093,30301]

theorem envBound30720 : H12AffineFastState.Bounded env30720 := by
  intro p hp
  have h : env30720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30719_30720 : H12AffineEnvironment.transform 15 21590 env30719 = env30720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env30719 == env30720) = true)

theorem identity30720 : scanCanonicalize (H12AffineFastState.compose env30720 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30720 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env30721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21590,5392,23669,1025,32769,4161,32801,17,54530,348,64,34816,5393,17665,35188,1364,21793,257,21792,38225,22273]

theorem envBound30721 : H12AffineFastState.Bounded env30721 := by
  intro p hp
  have h : env30721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30720_30721 : H12AffineEnvironment.transform 12 348 env30720 = env30721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30720 == env30721) = true)

theorem identity30721 : scanCanonicalize (H12AffineFastState.compose env30721 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30721 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,32768,263,5392,2340,1025,32769,4161,32801,17,32851,348,64,34816,5393,4176,35188,1364,112,257,113,38225,592]

theorem envBound30722 : H12AffineFastState.Bounded env30722 := by
  intro p hp
  have h : env30722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30721_30722 : H12AffineEnvironment.transform 13 5457 env30721 = env30722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30721 == env30722) = true)

theorem identity30722 : scanCanonicalize (H12AffineFastState.compose env30722 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30722 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30723 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,32768,263,5392,2340,1025,32769,4113,32801,17,32771,268,16,34816,5393,4096,35108,1284,32,257,33,38145,512]

theorem envBound30723 : H12AffineFastState.Bounded env30723 := by
  intro p hp
  have h : env30723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30722_30723 : H12AffineEnvironment.transform 5 16 env30722 = env30723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30722 == env30723) = true)

theorem identity30723 : scanCanonicalize (H12AffineFastState.compose env30723 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound30723 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30724 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,32,263,5392,2340,1025,33,4113,1,17,35,268,16,2080,5393,4096,2308,1284,32,257,33,5409,512]

theorem envBound30724 : H12AffineFastState.Bounded env30724 := by
  intro p hp
  have h : env30724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30723_30724 : H12AffineEnvironment.transform 14 32 env30723 = env30724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env30723 == env30724) = true)

theorem identity30724 : scanCanonicalize (H12AffineFastState.compose env30724 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30725 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,32,34,5173,2049,1025,33,4113,1,17,35,41,16,2080,5172,4096,2081,1057,32,36,33,5124,512]

theorem envBound30725 : H12AffineFastState.Bounded env30725 := by
  intro p hp
  have h : env30725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30724_30725 : H12AffineEnvironment.transform 7 37 env30724 = env30725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30724 == env30725) = true)

theorem identity30725 : scanCanonicalize (H12AffineFastState.compose env30725 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound30725 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env30726 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1566,4096,41,5156,32,34,5173,1567,1025,33,4113,1,17,35,41,16,1598,5172,4096,1599,1057,32,36,33,5124,512]

theorem envBound30726 : H12AffineFastState.Bounded env30726 := by
  intro p hp
  have h : env30726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30725_30726 : H12AffineEnvironment.transform 10 1566 env30725 = env30726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env30725 == env30726) = true)

def env30727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4161,318548,17,98645,8193,64,43356,5393,17665,324700,1365,272392,257,21792,46092,74251]

theorem envBound30727 : H12AffineFastState.Bounded env30727 := by
  intro p hp
  have h : env30727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30717_30727 : H12AffineEnvironment.transform 6 9 env30717 = env30727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30717 == env30727) = true)

theorem identity30727 : scanCanonicalize (H12AffineFastState.compose env30727 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound30727 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,108927,1025,32769,4161,95531,17,98645,8193,64,43356,5393,17665,89379,1365,98679,257,21792,46092,74251]

theorem envBound30728 : H12AffineFastState.Bounded env30728 := by
  intro p hp
  have h : env30728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30727_30728 : H12AffineEnvironment.transform 17 108927 env30727 = env30728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env30727 == env30728) = true)

theorem identity30728 : scanCanonicalize (H12AffineFastState.compose env30728 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound30728 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,13389,10361,1025,32769,4161,62509,17,83,8193,64,43356,5393,17665,56357,1365,113,257,21792,46092,41741]

theorem envBound30729 : H12AffineFastState.Bounded env30729 := by
  intro p hp
  have h : env30729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30728_30729 : H12AffineEnvironment.transform 15 33030 env30728 = env30729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env30728 == env30729) = true)

theorem identity30729 : scanCanonicalize (H12AffineFastState.compose env30729 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound30729 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env30730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,293,35,13389,10361,1025,292,4161,29960,17,83,8193,64,10361,5393,17665,23808,1365,113,257,21792,13609,8744]

theorem envBound30730 : H12AffineFastState.Bounded env30730 := by
  intro p hp
  have h : env30730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30729_30730 : H12AffineEnvironment.transform 14 293 env30729 = env30730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env30729 == env30730) = true)

theorem identity30730 : scanCanonicalize (H12AffineFastState.compose env30730 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30730 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS < 2^1333 := by decide +kernel

def env30731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,293,35,5221,2129,1025,292,4161,21792,17,83,41,64,2129,5393,17665,23808,1365,113,257,21792,5377,512]

theorem envBound30731 : H12AffineFastState.Bounded env30731 := by
  intro p hp
  have h : env30731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30730_30731 : H12AffineEnvironment.transform 12 40 env30730 = env30731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30730 == env30731) = true)

theorem identity30731 : scanCanonicalize (H12AffineFastState.compose env30731 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30731 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5456,293,35,5221,2129,1025,292,4161,112,17,83,41,64,2129,5393,4177,2128,1365,113,257,112,5377,512]

theorem envBound30732 : H12AffineFastState.Bounded env30732 := by
  intro p hp
  have h : env30732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30731_30732 : H12AffineEnvironment.transform 13 5456 env30731 = env30732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30731 == env30732) = true)

theorem identity30732 : scanCanonicalize (H12AffineFastState.compose env30732 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30732 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30733 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,80,35,5221,2129,1025,81,4161,112,17,83,41,64,2129,5220,4177,2128,1056,113,116,112,5236,512]

theorem envBound30733 : H12AffineFastState.Bounded env30733 := by
  intro p hp
  have h : env30733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30732_30733 : H12AffineEnvironment.transform 7 117 env30732 = env30733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30732 == env30733) = true)

theorem identity30733 : scanCanonicalize (H12AffineFastState.compose env30733 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30733 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30734 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5125,80,3,5189,2129,1025,81,4161,80,17,83,9,64,2129,5188,4177,2128,1024,81,84,80,5204,512]

theorem envBound30734 : H12AffineFastState.Bounded env30734 := by
  intro p hp
  have h : env30734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30733_30734 : H12AffineEnvironment.transform 4 0 env30733 = env30734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30733 == env30734) = true)

theorem identity30734 : scanCanonicalize (H12AffineFastState.compose env30734 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

theorem selectedBound30734 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30735 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,3157,8,2128,80,3,2064,2129,1025,81,3092,80,17,83,9,64,2129,2065,3076,2128,1024,81,84,80,2049,512]

theorem envBound30735 : H12AffineFastState.Bounded env30735 := by
  intro p hp
  have h : env30735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30734_30735 : H12AffineEnvironment.transform 11 3157 env30734 = env30735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env30734 == env30735) = true)

theorem identity30735 : scanCanonicalize (H12AffineFastState.compose env30735 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound30735 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env30736 : List Nat := [2,4,8,16,0,64,9,85,512,1024,81,1028,8,1,80,3,65,0,1025,81,1093,80,17,83,9,64,0,64,1109,1,1024,81,84,80,80,512]

theorem envBound30736 : H12AffineFastState.Bounded env30736 := by
  intro p hp
  have h : env30736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30735_30736 : H12AffineEnvironment.transform 10 81 env30735 = env30736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env30735 == env30736) = true)

theorem identity30736 : scanCanonicalize (H12AffineFastState.compose env30736 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30736 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30737 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1,1028,8,1,0,3,17,0,1025,1,1045,0,17,3,9,16,0,16,1029,1,1024,1,4,0,0,512]

theorem envBound30737 : H12AffineFastState.Bounded env30737 := by
  intro p hp
  have h : env30737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30736_30737 : H12AffineEnvironment.transform 5 16 env30736 = env30737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30736 == env30737) = true)

theorem identity30737 : scanCanonicalize (H12AffineFastState.compose env30737 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound30737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30738 : List Nat := [2,4,8,16,0,16,9,5,512,516,1,512,8,1,0,3,17,0,517,1,529,0,17,3,9,16,0,16,513,1,516,1,4,0,0,512]

theorem envBound30738 : H12AffineFastState.Bounded env30738 := by
  intro p hp
  have h : env30738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30737_30738 : H12AffineEnvironment.transform 9 516 env30737 = env30738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env30737 == env30738) = true)

theorem identity30738 : scanCanonicalize (H12AffineFastState.compose env30738 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30739 : List Nat := [2,4,8,16,0,16,9,5,0,4,1,0,8,1,0,3,17,0,5,1,17,0,17,3,9,16,0,16,1,1,4,1,4,0,0,0]

theorem envBound30739 : H12AffineFastState.Bounded env30739 := by
  intro p hp
  have h : env30739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30738_30739 : H12AffineEnvironment.transform 8 0 env30738 = env30739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30738 == env30739) = true)

def env30740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237588,242968,8328,64,2144540,2240916,160197,2417812,2102685,2373704,257,21792,46213,2175562]

theorem envBound30740 : H12AffineFastState.Bounded env30740 := by
  intro p hp
  have h : env30740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30684_30740 : H12AffineEnvironment.transform 21 452753 env30684 = env30740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env30684 == env30740) = true)

def env30741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144596,242968,8328,64,43356,139732,160197,324820,1501,272392,257,21792,46213,74250]

theorem envBound30741 : H12AffineFastState.Bounded env30741 := by
  intro p hp
  have h : env30741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30740_30741 : H12AffineEnvironment.transform 20 4160 env30740 = env30741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30740 == env30741) = true)

theorem identity30741 : scanCanonicalize (H12AffineFastState.compose env30741 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound30741 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272512,62661,95497,8328,64,43356,57797,45524,324820,1501,272392,257,21792,46213,74250]

theorem envBound30742 : H12AffineFastState.Bounded env30742 := by
  intro p hp
  have h : env30742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30741_30742 : H12AffineEnvironment.transform 16 49169 env30741 = env30742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env30741 == env30742) = true)

theorem identity30742 : scanCanonicalize (H12AffineFastState.compose env30742 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30742 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,4160,272512,62661,21762,8328,64,43356,57797,45524,324820,1501,272392,257,21792,46213,513]

theorem envBound30743 : H12AffineFastState.Bounded env30743 := by
  intro p hp
  have h : env30743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30742_30743 : H12AffineEnvironment.transform 15 8203 env30742 = env30743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30742 == env30743) = true)

theorem identity30743 : scanCanonicalize (H12AffineFastState.compose env30743 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound30743 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10280,1025,32769,4160,168,62661,21762,8328,64,43356,57797,45524,56572,1501,32,257,21792,46213,513]

theorem envBound30744 : H12AffineFastState.Bounded env30744 := by
  intro p hp
  have h : env30744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30743_30744 : H12AffineEnvironment.transform 17 10280 env30743 = env30744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30743 == env30744) = true)

theorem identity30744 : scanCanonicalize (H12AffineFastState.compose env30744 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound30744 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env30745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,293,8203,16692,10280,1025,292,4160,168,30176,21762,8328,64,10361,24800,12529,24025,1501,32,257,21792,13728,513]

theorem envBound30745 : H12AffineFastState.Bounded env30745 := by
  intro p hp
  have h : env30745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30744_30745 : H12AffineEnvironment.transform 14 293 env30744 = env30745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env30744 == env30745) = true)

theorem identity30745 : scanCanonicalize (H12AffineFastState.compose env30745 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30745 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30746 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,16384,0,8203,16401,10280,1025,1,4160,168,29893,21543,8328,64,10361,24800,12529,23804,1272,32,36,21509,13445,513]

theorem envBound30746 : H12AffineFastState.Bounded env30746 := by
  intro p hp
  have h : env30746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30745_30746 : H12AffineEnvironment.transform 7 37 env30745 = env30746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30745 == env30746) = true)

theorem identity30746 : scanCanonicalize (H12AffineFastState.compose env30746 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound30746 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30747 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4113,0,8203,4096,10280,1025,1,4160,168,9428,1078,8328,64,10361,12529,12529,3309,1272,32,36,1044,13445,513]

theorem envBound30747 : H12AffineFastState.Bounded env30747 := by
  intro p hp
  have h : env30747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30746_30747 : H12AffineEnvironment.transform 13 4113 env30746 = env30747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env30746 == env30747) = true)

theorem identity30747 : scanCanonicalize (H12AffineFastState.compose env30747 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound30747 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30748 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1101,4113,0,1094,4096,3173,1025,1,4160,168,153,1078,1221,64,3124,5308,5308,3309,1272,32,36,1044,4296,513]

theorem envBound30748 : H12AffineFastState.Bounded env30748 := by
  intro p hp
  have h : env30748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30747_30748 : H12AffineEnvironment.transform 12 1101 env30747 = env30748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env30747 == env30748) = true)

theorem identity30748 : scanCanonicalize (H12AffineFastState.compose env30748 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30748 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env30749 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1101,4113,0,1094,4096,3173,1025,1,4160,33,16,1078,1100,64,3124,5173,5173,3172,1137,32,36,1044,4161,513]

theorem envBound30749 : H12AffineFastState.Bounded env30749 := by
  intro p hp
  have h : env30749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30748_30749 : H12AffineEnvironment.transform 6 9 env30748 = env30749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30748 == env30749) = true)

theorem identity30749 : scanCanonicalize (H12AffineFastState.compose env30749 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30749 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30750 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,0,115,4096,2128,52,1,4160,33,16,3,121,64,2049,4096,4096,2129,68,32,36,33,4161,513]

theorem envBound30750 : H12AffineFastState.Bounded env30750 := by
  intro p hp
  have h : env30750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30749_30750 : H12AffineEnvironment.transform 9 53 env30749 = env30750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30749 == env30750) = true)

theorem identity30750 : scanCanonicalize (H12AffineFastState.compose env30750 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30750 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30751 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,0,34,4096,2049,52,1,4113,33,16,3,40,17,2049,4096,4096,2048,21,32,36,33,4112,513]

theorem envBound30751 : H12AffineFastState.Bounded env30751 := by
  intro p hp
  have h : env30751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30750_30751 : H12AffineEnvironment.transform 5 17 env30750 = env30751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30750 == env30751) = true)

theorem identity30751 : scanCanonicalize (H12AffineFastState.compose env30751 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound30751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30752 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,4096,41,4113,0,34,4096,529,52,1,4113,33,16,3,40,17,529,4096,4096,528,21,32,36,33,4112,513]

theorem envBound30752 : H12AffineFastState.Bounded env30752 := by
  intro p hp
  have h : env30752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30751_30752 : H12AffineEnvironment.transform 10 528 env30751 = env30752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env30751 == env30752) = true)

theorem identity30752 : scanCanonicalize (H12AffineFastState.compose env30752 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound30752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30753 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,26,41,11,0,34,26,529,52,1,11,33,16,3,40,17,529,26,26,528,21,32,36,33,10,513]

theorem envBound30753 : H12AffineFastState.Bounded env30753 := by
  intro p hp
  have h : env30753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30752_30753 : H12AffineEnvironment.transform 11 26 env30752 = env30753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env30752 == env30753) = true)

theorem identity30753 : scanCanonicalize (H12AffineFastState.compose env30753 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound30753 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30754 : List Nat := [2,4,8,16,32,17,9,37,27,53,11,26,41,11,0,34,26,10,52,1,11,33,16,3,40,17,10,26,26,11,21,32,36,33,10,26]

theorem envBound30754 : H12AffineFastState.Bounded env30754 := by
  intro p hp
  have h : env30754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30753_30754 : H12AffineEnvironment.transform 8 27 env30753 = env30754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env30753 == env30754) = true)

def env30755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144597,242968,8328,64,43357,139733,160197,324821,1500,272393,257,21792,46213,74251]

theorem envBound30755 : H12AffineFastState.Bounded env30755 := by
  intro p hp
  have h : env30755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30740_30755 : H12AffineEnvironment.transform 20 4161 env30740 = env30755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30740 == env30755) = true)

def env30756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180409,144597,242968,8328,64,43357,139733,160197,56573,1500,33,257,21792,46213,74251]

theorem envBound30756 : H12AffineFastState.Bounded env30756 := by
  intro p hp
  have h : env30756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30755_30756 : H12AffineEnvironment.transform 17 10280 env30755 = env30756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30755 == env30756) = true)

def env30757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,21929,41413,73736,8328,64,43357,46277,58581,56573,1500,33,257,21792,46213,74251]

theorem envBound30757 : H12AffineFastState.Bounded env30757 := by
  intro p hp
  have h : env30757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30756_30757 : H12AffineEnvironment.transform 16 38160 env30756 = env30757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env30756 == env30757) = true)

theorem identity30757 : scanCanonicalize (H12AffineFastState.compose env30757 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30757 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,38160,10280,1025,32769,4161,21929,41413,41311,8328,64,43357,46277,58581,56573,1500,33,257,21792,46213,41820]

theorem envBound30758 : H12AffineFastState.Bounded env30758 := by
  intro p hp
  have h : env30758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30757_30758 : H12AffineEnvironment.transform 15 33111 env30757 = env30758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30757 == env30758) = true)

theorem identity30758 : scanCanonicalize (H12AffineFastState.compose env30758 (packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound30758 : packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,33111,38160,3172,1025,32769,4161,21929,34185,34067,1220,64,36113,37001,49305,56573,1500,33,257,21792,37065,34576]

theorem envBound30759 : H12AffineFastState.Bounded env30759 := by
  intro p hp
  have h : env30759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30758_30759 : H12AffineEnvironment.transform 12 1100 env30758 = env30759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env30758 == env30759) = true)

theorem identity30759 : scanCanonicalize (H12AffineFastState.compose env30759 (packedSelected [1,3,4,5,7,8,9,10,11,16,19,20,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound30759 : packedSelected [1,3,4,5,7,8,9,10,11,16,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env30760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,5293,32768,33111,38160,3172,1025,32769,4161,260,34185,34067,1220,64,36113,37001,37940,34896,1500,33,257,397,37065,34576]

theorem envBound30760 : H12AffineFastState.Bounded env30760 := by
  intro p hp
  have h : env30760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30759_30760 : H12AffineEnvironment.transform 13 5293 env30759 = env30760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env30759 == env30760) = true)

theorem identity30760 : scanCanonicalize (H12AffineFastState.compose env30760 (packedSelected [1,2,3,6,8,9,10,12,14,15,16,20,22,24] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30760 : packedSelected [1,2,3,6,8,9,10,12,14,15,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env30761 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,4540,32768,33111,36865,2421,272,32769,4161,260,32920,32770,469,64,34816,37001,37157,34896,205,33,257,397,37065,33281]

theorem envBound30761 : H12AffineFastState.Bounded env30761 := by
  intro p hp
  have h : env30761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30760_30761 : H12AffineEnvironment.transform 9 273 env30760 = env30761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30760 == env30761) = true)

def env30762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,21928,41412,73737,8328,64,43357,46276,58580,56573,1500,33,257,21792,46213,74251]

theorem envBound30762 : H12AffineFastState.Bounded env30762 := by
  intro p hp
  have h : env30762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30756_30762 : H12AffineEnvironment.transform 16 38161 env30756 = env30762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env30756 == env30762) = true)

theorem identity30762 : scanCanonicalize (H12AffineFastState.compose env30762 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound30762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,38161,10280,1025,32769,4161,21928,41412,41431,8328,64,43357,46276,58580,56573,1500,33,257,21792,46213,41941]

theorem envBound30763 : H12AffineFastState.Bounded env30763 := by
  intro p hp
  have h : env30763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30762_30763 : H12AffineEnvironment.transform 15 33246 env30762 = env30763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env30762 == env30763) = true)

theorem identity30763 : scanCanonicalize (H12AffineFastState.compose env30763 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound30763 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8574,13745,10280,1025,8353,4161,21928,356,375,8328,64,2557,5220,17524,31837,1500,33,257,21792,5157,885]

theorem envBound30764 : H12AffineFastState.Bounded env30764 := by
  intro p hp
  have h : env30764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30763_30764 : H12AffineEnvironment.transform 14 8352 env30763 = env30764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env30763 == env30764) = true)

theorem identity30764 : scanCanonicalize (H12AffineFastState.compose env30764 (packedSelected [3,10,12,15,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound30764 : packedSelected [3,10,12,15,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env30765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12344,8352,8574,13745,10280,1025,8353,4161,9616,356,375,8328,64,2557,5220,13388,3173,1500,33,257,9496,5157,885]

theorem envBound30765 : H12AffineFastState.Bounded env30765 := by
  intro p hp
  have h : env30765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30764_30765 : H12AffineEnvironment.transform 13 12344 env30764 = env30765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env30764 == env30765) = true)

theorem identity30765 : scanCanonicalize (H12AffineFastState.compose env30765 (packedSelected [2,4,6,12,15,16,18,19,22,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound30765 : packedSelected [2,4,6,12,15,16,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env30766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5157,1213,1379,4524,3125,1025,1212,4161,397,356,375,1173,64,2557,5220,4177,3173,1500,33,257,261,5157,885]

theorem envBound30766 : H12AffineFastState.Bounded env30766 := by
  intro p hp
  have h : env30766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30765_30766 : H12AffineEnvironment.transform 12 1053 env30765 = env30766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env30765 == env30766) = true)

theorem identity30766 : scanCanonicalize (H12AffineFastState.compose env30766 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30766 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5157,1077,1379,4388,3125,1025,1076,4161,261,356,375,1053,64,2421,5220,4177,3173,1364,33,257,261,5157,885]

theorem envBound30767 : H12AffineFastState.Bounded env30767 := by
  intro p hp
  have h : env30767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30766_30767 : H12AffineEnvironment.transform 6 8 env30766 = env30767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30766 == env30767) = true)

theorem identity30767 : scanCanonicalize (H12AffineFastState.compose env30767 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound30767 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30768 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,121,4161,81,263,4388,2129,101,80,4161,261,356,375,121,64,2421,4096,4177,2049,304,33,257,261,4161,885]

theorem envBound30768 : H12AffineFastState.Bounded env30768 := by
  intro p hp
  have h : env30768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30767_30768 : H12AffineEnvironment.transform 9 100 env30767 = env30768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env30767 == env30768) = true)

theorem identity30768 : scanCanonicalize (H12AffineFastState.compose env30768 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30768 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30769 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,121,4161,81,114,4177,2129,101,80,4161,112,17,2,121,64,2048,4096,4177,2049,69,33,116,112,4161,512]

theorem envBound30769 : H12AffineFastState.Bounded env30769 := by
  intro p hp
  have h : env30769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30768_30769 : H12AffineEnvironment.transform 7 117 env30768 = env30769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30768 == env30769) = true)

theorem identity30769 : scanCanonicalize (H12AffineFastState.compose env30769 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30769 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30770 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,4096,9,4145,33,2,4129,2081,21,32,4145,0,17,2,9,48,2048,4096,4129,2049,53,33,4,0,4145,512]

theorem envBound30770 : H12AffineFastState.Bounded env30770 := by
  intro p hp
  have h : env30770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30769_30770 : H12AffineEnvironment.transform 5 48 env30769 = env30770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30769 == env30770) = true)

theorem identity30770 : scanCanonicalize (H12AffineFastState.compose env30770 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound30770 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30771 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,1,9,48,33,2,32,2081,21,32,48,0,17,2,9,48,2048,1,32,2049,53,33,4,0,48,512]

theorem envBound30771 : H12AffineFastState.Bounded env30771 := by
  intro p hp
  have h : env30771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30770_30771 : H12AffineEnvironment.transform 11 1 env30770 = env30771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env30770 == env30771) = true)

theorem identity30771 : scanCanonicalize (H12AffineFastState.compose env30771 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30771 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30772 : List Nat := [2,4,8,16,16,0,8,5,512,20,2048,1,9,0,17,2,16,2065,21,16,0,0,17,2,9,0,2048,1,16,2049,5,17,4,0,0,512]

theorem envBound30772 : H12AffineFastState.Bounded env30772 := by
  intro p hp
  have h : env30772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30771_30772 : H12AffineEnvironment.transform 4 16 env30771 = env30772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30771 == env30772) = true)

theorem identity30772 : scanCanonicalize (H12AffineFastState.compose env30772 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30772 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30773 : List Nat := [2,4,8,16,16,0,8,5,0,20,2048,1,9,0,17,2,16,2065,21,16,0,0,17,2,9,0,2048,1,16,2049,5,17,4,0,0,0]

theorem envBound30773 : H12AffineFastState.Bounded env30773 := by
  intro p hp
  have h : env30773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30772_30773 : H12AffineEnvironment.transform 8 0 env30772 = env30773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30772 == env30773) = true)

theorem identity30773 : scanCanonicalize (H12AffineFastState.compose env30773 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30774 : List Nat := [2,4,8,1,1,0,8,5,0,5,2048,1,9,0,0,2,1,2048,4,1,0,0,0,2,9,0,2048,1,1,2049,5,0,4,0,0,0]

theorem envBound30774 : H12AffineFastState.Bounded env30774 := by
  intro p hp
  have h : env30774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30773_30774 : H12AffineEnvironment.transform 3 1 env30773 = env30774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30773 == env30774) = true)

theorem identity30774 : scanCanonicalize (H12AffineFastState.compose env30774 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30775 : List Nat := [2,1,8,1,1,0,8,0,0,0,2048,1,9,0,0,2,1,2048,1,1,0,0,0,2,9,0,2048,1,1,2049,0,0,1,0,0,0]

theorem envBound30775 : H12AffineFastState.Bounded env30775 := by
  intro p hp
  have h : env30775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30774_30775 : H12AffineEnvironment.transform 1 1 env30774 = env30775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30774 == env30775) = true)

def env30776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180408,144597,242968,8328,64,43357,139733,160197,56572,1500,32,257,21792,46213,74251]

theorem envBound30776 : H12AffineFastState.Bounded env30776 := by
  intro p hp
  have h : env30776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30755_30776 : H12AffineEnvironment.transform 17 10281 env30755 = env30776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30755 == env30776) = true)

def env30777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,21928,41413,73736,8328,64,43357,46277,58581,56572,1500,32,257,21792,46213,74251]

theorem envBound30777 : H12AffineFastState.Bounded env30777 := by
  intro p hp
  have h : env30777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30776_30777 : H12AffineEnvironment.transform 16 38160 env30776 = env30777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env30776 == env30777) = true)

theorem identity30777 : scanCanonicalize (H12AffineFastState.compose env30777 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30777 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1025,32769,4161,21928,41413,138,8328,64,43357,46277,58581,56572,1500,32,257,21792,46213,649]

theorem envBound30778 : H12AffineFastState.Bounded env30778 := by
  intro p hp
  have h : env30778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30777_30778 : H12AffineEnvironment.transform 15 8322 env30777 = env30778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30777 == env30778) = true)

theorem identity30778 : scanCanonicalize (H12AffineFastState.compose env30778 (packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound30778 : packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env30779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29829,8322,24981,10281,1025,29828,4161,21928,21824,138,8328,64,24024,16448,4176,10361,1500,32,257,21792,16384,649]

theorem envBound30779 : H12AffineFastState.Bounded env30779 := by
  intro p hp
  have h : env30779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30778_30779 : H12AffineEnvironment.transform 14 29829 env30778 = env30779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env30778 == env30779) = true)

theorem identity30779 : scanCanonicalize (H12AffineFastState.compose env30779 (packedSelected [10,11,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound30779 : packedSelected [10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env30780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21760,263,16400,2476,1025,21761,4161,21928,21824,138,269,64,24024,16448,4176,2556,1500,32,257,21792,16384,649]

theorem envBound30780 : H12AffineFastState.Bounded env30780 := by
  intro p hp
  have h : env30780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30779_30780 : H12AffineEnvironment.transform 12 389 env30779 = env30780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env30779 == env30780) = true)

theorem identity30780 : scanCanonicalize (H12AffineFastState.compose env30780 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30780 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30781 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,263,16400,2476,1025,21761,4112,21928,21777,138,269,17,23945,16401,4097,2477,1421,32,257,21792,16384,649]

theorem envBound30781 : H12AffineFastState.Bounded env30781 := by
  intro p hp
  have h : env30781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30780_30781 : H12AffineEnvironment.transform 5 17 env30780 = env30781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30780 == env30781) = true)

theorem identity30781 : scanCanonicalize (H12AffineFastState.compose env30781 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound30781 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30782 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,136,263,5528,2476,1025,137,4112,32,153,138,269,17,2049,5529,4097,2477,1421,32,257,168,5512,649]

theorem envBound30782 : H12AffineFastState.Bounded env30782 := by
  intro p hp
  have h : env30782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30781_30782 : H12AffineEnvironment.transform 13 5512 env30781 = env30782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env30781 == env30782) = true)

theorem identity30782 : scanCanonicalize (H12AffineFastState.compose env30782 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30782 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env30783 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,263,5392,2340,1025,1,4112,32,17,2,269,17,2049,5393,4097,2341,1285,32,257,32,5376,513]

theorem envBound30783 : H12AffineFastState.Bounded env30783 := by
  intro p hp
  have h : env30783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30782_30783 : H12AffineEnvironment.transform 6 8 env30782 = env30783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30782 == env30783) = true)

theorem identity30783 : scanCanonicalize (H12AffineFastState.compose env30783 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound30783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30784 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,269,0,0,263,16,2340,1025,1,1296,32,17,2,269,17,2049,17,1281,2341,1285,32,257,32,0,513]

theorem envBound30784 : H12AffineFastState.Bounded env30784 := by
  intro p hp
  have h : env30784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30783_30784 : H12AffineEnvironment.transform 11 1280 env30783 = env30784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env30783 == env30784) = true)

def env30785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,21929,41412,73737,8328,64,43357,46276,58580,56572,1500,32,257,21792,46213,74251]

theorem envBound30785 : H12AffineFastState.Bounded env30785 := by
  intro p hp
  have h : env30785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30776_30785 : H12AffineEnvironment.transform 16 38161 env30776 = env30785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env30776 == env30785) = true)

theorem identity30785 : scanCanonicalize (H12AffineFastState.compose env30785 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30785 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4161,21929,41412,3,8328,64,43357,46276,58580,56572,1500,32,257,21792,46213,513]

theorem envBound30786 : H12AffineFastState.Bounded env30786 := by
  intro p hp
  have h : env30786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30785_30786 : H12AffineEnvironment.transform 15 8202 env30785 = env30786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30785 == env30786) = true)

theorem identity30786 : scanCanonicalize (H12AffineFastState.compose env30786 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound30786 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env30787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8202,38161,10281,1025,32769,4161,32,41412,3,8328,64,43357,46276,45405,35189,1500,32,257,169,46213,513]

theorem envBound30787 : H12AffineFastState.Bounded env30787 := by
  intro p hp
  have h : env30787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30786_30787 : H12AffineEnvironment.transform 13 5513 env30786 = env30787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env30786 == env30787) = true)

theorem identity30787 : scanCanonicalize (H12AffineFastState.compose env30787 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound30787 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env30788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,32768,479,38161,2556,1025,32769,4161,32,32785,3,349,64,34952,38161,37000,35189,1500,32,257,169,38224,513]

theorem envBound30788 : H12AffineFastState.Bounded env30788 := by
  intro p hp
  have h : env30788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30787_30788 : H12AffineEnvironment.transform 12 469 env30787 = env30788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env30787 == env30788) = true)

theorem identity30788 : scanCanonicalize (H12AffineFastState.compose env30788 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound30788 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,479,5529,2556,1025,137,4161,32,153,3,349,64,2048,5529,4096,2557,1500,32,257,169,5592,513]

theorem envBound30789 : H12AffineFastState.Bounded env30789 := by
  intro p hp
  have h : env30789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30788_30789 : H12AffineEnvironment.transform 14 136 env30788 = env30789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env30788 == env30789) = true)

theorem identity30789 : scanCanonicalize (H12AffineFastState.compose env30789 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30789 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env30790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5392,2421,1025,0,4161,32,16,3,349,64,2048,5392,4096,2420,1365,32,257,32,5457,513]

theorem envBound30790 : H12AffineFastState.Bounded env30790 := by
  intro p hp
  have h : env30790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30789_30790 : H12AffineEnvironment.transform 6 9 env30789 = env30790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30789 == env30790) = true)

theorem identity30790 : scanCanonicalize (H12AffineFastState.compose env30790 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound30790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1793,348,513,1,342,529,2421,1025,0,1856,32,16,3,349,64,2048,529,1793,2420,1365,32,257,32,592,513]

theorem envBound30791 : H12AffineFastState.Bounded env30791 := by
  intro p hp
  have h : env30791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30790_30791 : H12AffineEnvironment.transform 11 1793 env30790 = env30791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env30790 == env30791) = true)

theorem identity30791 : scanCanonicalize (H12AffineFastState.compose env30791 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30791 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30792 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1793,269,513,1,263,529,2340,1025,0,1809,32,16,3,268,17,2048,529,1793,2341,1284,32,257,32,513,513]

theorem envBound30792 : H12AffineFastState.Bounded env30792 := by
  intro p hp
  have h : env30792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30791_30792 : H12AffineEnvironment.transform 5 17 env30791 = env30792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30791 == env30792) = true)

theorem identity30792 : scanCanonicalize (H12AffineFastState.compose env30792 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30793 : List Nat := [2,4,8,16,16,17,9,256,512,1024,2048,1793,269,513,1,263,529,2324,1025,0,1809,16,16,3,268,17,2048,529,1793,2325,1284,16,257,16,513,513]

theorem envBound30793 : H12AffineFastState.Bounded env30793 := by
  intro p hp
  have h : env30793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30792_30793 : H12AffineEnvironment.transform 4 16 env30792 = env30793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30792 == env30793) = true)

theorem identity30793 : scanCanonicalize (H12AffineFastState.compose env30793 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound30793 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30794 : List Nat := [2,4,8,16,16,17,9,256,512,1024,1809,1793,269,513,1,263,529,1541,1025,0,1809,16,16,3,268,17,1809,529,1793,1540,1284,16,257,16,513,513]

theorem envBound30794 : H12AffineFastState.Bounded env30794 := by
  intro p hp
  have h : env30794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30793_30794 : H12AffineEnvironment.transform 10 1809 env30793 = env30794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env30793 == env30794) = true)

theorem identity30794 : scanCanonicalize (H12AffineFastState.compose env30794 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound30794 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30795 : List Nat := [2,4,8,16,16,17,9,256,512,257,528,512,269,513,1,263,529,772,256,0,528,16,16,3,268,17,528,529,512,773,5,16,257,16,513,513]

theorem envBound30795 : H12AffineFastState.Bounded env30795 := by
  intro p hp
  have h : env30795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30794_30795 : H12AffineEnvironment.transform 9 257 env30794 = env30795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env30794 == env30795) = true)

theorem identity30795 : scanCanonicalize (H12AffineFastState.compose env30795 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30795 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30796 : List Nat := [2,4,8,16,16,17,9,21,512,20,528,512,24,513,1,18,529,529,21,0,528,16,16,3,25,17,528,529,512,528,5,16,20,16,513,513]

theorem envBound30796 : H12AffineFastState.Bounded env30796 := by
  intro p hp
  have h : env30796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30795_30796 : H12AffineEnvironment.transform 7 21 env30795 = env30796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30795 == env30796) = true)

theorem identity30796 : scanCanonicalize (H12AffineFastState.compose env30796 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30796 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30797 : List Nat := [2,4,8,0,0,1,9,5,512,4,512,512,8,513,1,2,513,513,5,0,512,0,0,3,9,1,512,513,512,512,5,0,4,0,513,513]

theorem envBound30797 : H12AffineFastState.Bounded env30797 := by
  intro p hp
  have h : env30797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30796_30797 : H12AffineEnvironment.transform 3 0 env30796 = env30797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30796 == env30797) = true)

theorem identity30797 : scanCanonicalize (H12AffineFastState.compose env30797 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30798 : List Nat := [2,4,8,0,0,1,9,5,1,4,1,1,8,0,1,2,0,0,5,0,1,0,0,3,9,1,1,0,1,1,5,0,4,0,0,0]

theorem envBound30798 : H12AffineFastState.Bounded env30798 := by
  intro p hp
  have h : env30798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30797_30798 : H12AffineEnvironment.transform 8 1 env30797 = env30798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30797 == env30798) = true)

def env30799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,242969,8328,64,6705548,2240917,160197,2417812,2102684,6475992,257,21793,46212,2175563]

theorem envBound30799 : H12AffineFastState.Bounded env30799 := by
  intro p hp
  have h : env30799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30683_30799 : H12AffineEnvironment.transform 23 242969 env30683 = env30799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env30683 == env30799) = true)

def env30800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237588,242969,8328,64,2144540,2240917,160197,2417812,2102684,2373704,257,21793,46212,2175563]

theorem envBound30800 : H12AffineFastState.Bounded env30800 := by
  intro p hp
  have h : env30800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30799_30800 : H12AffineEnvironment.transform 21 452752 env30799 = env30800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env30799 == env30800) = true)

def env30801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144596,242969,8328,64,43356,139733,160197,324820,1500,272392,257,21793,46212,74251]

theorem envBound30801 : H12AffineFastState.Bounded env30801 := by
  intro p hp
  have h : env30801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30800_30801 : H12AffineEnvironment.transform 20 4160 env30800 = env30801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30800 == env30801) = true)

theorem identity30801 : scanCanonicalize (H12AffineFastState.compose env30801 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound30801 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,4160,392287,73755,41430,8328,64,43356,79130,91402,324820,1500,272392,257,21793,46212,74251]

theorem envBound30802 : H12AffineFastState.Bounded env30802 := by
  intro p hp
  have h : env30802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30801_30802 : H12AffineEnvironment.transform 16 70863 env30801 = env30802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env30801 == env30802) = true)

def env30803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4160,392287,73755,41310,8192,64,43356,79130,91402,324700,1364,272392,257,21793,46092,74251]

theorem envBound30803 : H12AffineFastState.Bounded env30803 := by
  intro p hp
  have h : env30803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30802_30803 : H12AffineEnvironment.transform 6 8 env30802 = env30803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30802 == env30803) = true)

theorem identity30803 : scanCanonicalize (H12AffineFastState.compose env30803 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound30803 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env30804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67619,1025,32769,4160,62588,73755,41310,8192,64,43356,79130,91402,130175,1364,73771,257,21793,46092,74251]

theorem envBound30804 : H12AffineFastState.Bounded env30804 := by
  intro p hp
  have h : env30804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30803_30804 : H12AffineEnvironment.transform 17 67619 env30803 = env30804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env30803 == env30804) = true)

theorem identity30804 : scanCanonicalize (H12AffineFastState.compose env30804 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30804 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,10281,1025,32769,4160,62588,17,41310,8192,64,43356,5392,17664,56437,1364,33,257,21793,46092,513]

theorem envBound30805 : H12AffineFastState.Bounded env30805 := by
  intro p hp
  have h : env30805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30804_30805 : H12AffineEnvironment.transform 15 8202 env30804 = env30805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30804 == env30805) = true)

theorem identity30805 : scanCanonicalize (H12AffineFastState.compose env30805 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound30805 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env30806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,13389,10281,1025,21760,4160,8573,17,29791,8192,64,31837,5392,17664,2420,1364,33,257,21793,24845,513]

theorem envBound30806 : H12AffineFastState.Bounded env30806 := by
  intro p hp
  have h : env30806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30805_30806 : H12AffineEnvironment.transform 14 21761 env30805 = env30806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env30805 == env30806) = true)

theorem identity30806 : scanCanonicalize (H12AffineFastState.compose env30806 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30806 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,13389,10281,1025,1,4160,8573,17,8542,8192,64,10588,5392,4097,2420,1364,33,257,32,13324,513]

theorem envBound30807 : H12AffineFastState.Bounded env30807 := by
  intro p hp
  have h : env30807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30806_30807 : H12AffineEnvironment.transform 13 5377 env30806 = env30807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30806 == env30807) = true)

def env30808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4160,392287,73755,41311,8193,64,43356,79130,91402,324701,1365,272392,257,21793,46093,74251]

theorem envBound30808 : H12AffineFastState.Bounded env30808 := by
  intro p hp
  have h : env30808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30802_30808 : H12AffineEnvironment.transform 6 9 env30802 = env30808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30802 == env30808) = true)

theorem identity30808 : scanCanonicalize (H12AffineFastState.compose env30808 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound30808 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env30809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,4160,54561,73755,41311,8193,64,43356,79130,91402,122147,1365,65910,257,21793,46093,74251]

theorem envBound30809 : H12AffineFastState.Bounded env30809 := by
  intro p hp
  have h : env30809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30808_30809 : H12AffineEnvironment.transform 17 76158 env30808 = env30809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env30808 == env30809) = true)

theorem identity30809 : scanCanonicalize (H12AffineFastState.compose env30809 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound30809 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,16400,32040,1025,32769,4160,54561,29773,41311,8193,64,43356,24908,12636,35189,1365,21792,257,21793,46093,30301]

theorem envBound30810 : H12AffineFastState.Bounded env30810 := by
  intro p hp
  have h : env30810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30809_30810 : H12AffineEnvironment.transform 15 21590 env30809 = env30810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env30809 == env30810) = true)

theorem identity30810 : scanCanonicalize (H12AffineFastState.compose env30810 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30810 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env30811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,16400,32040,1025,29788,4160,8572,29773,21762,8193,64,23809,24908,12636,32040,1365,21792,257,21793,16464,30301]

theorem envBound30811 : H12AffineFastState.Bounded env30811 := by
  intro p hp
  have h : env30811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30810_30811 : H12AffineEnvironment.transform 14 29789 env30810 = env30811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30810 == env30811) = true)

theorem identity30811 : scanCanonicalize (H12AffineFastState.compose env30811 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound30811 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,373,8574,13624,2048,1025,372,4160,8572,357,8234,8193,64,10281,5220,12636,2048,1365,8200,257,8201,13688,885]

theorem envBound30812 : H12AffineFastState.Bounded env30812 := by
  intro p hp
  have h : env30812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30811_30812 : H12AffineEnvironment.transform 13 13608 env30811 = env30812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env30811 == env30812) = true)

theorem identity30812 : scanCanonicalize (H12AffineFastState.compose env30812 (packedSelected [2,3,5,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound30812 : packedSelected [2,3,5,10,12,14] rootPS < 2^1333 := by decide +kernel

def env30813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4160,373,1046,4176,2048,1025,372,4160,1044,357,1346,1385,64,3393,5220,5172,2048,1365,1376,257,1377,4112,885]

theorem envBound30813 : H12AffineFastState.Bounded env30813 := by
  intro p hp
  have h : env30813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30812_30813 : H12AffineEnvironment.transform 12 1384 env30812 = env30813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env30812 == env30813) = true)

theorem identity30813 : scanCanonicalize (H12AffineFastState.compose env30813 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30813 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30814 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,121,4160,373,263,4176,2048,272,372,4160,261,357,83,120,64,2128,4469,4389,2048,68,113,257,112,4112,885]

theorem envBound30814 : H12AffineFastState.Bounded env30814 := by
  intro p hp
  have h : env30814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30813_30814 : H12AffineEnvironment.transform 9 273 env30813 = env30814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30813 == env30814) = true)

theorem identity30814 : scanCanonicalize (H12AffineFastState.compose env30814 (packedSelected [0,1,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound30814 : packedSelected [0,1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30815 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,64,121,0,373,263,16,2048,272,372,0,261,357,83,120,64,2128,309,357,2048,68,113,257,112,80,885]

theorem envBound30815 : H12AffineFastState.Bounded env30815 := by
  intro p hp
  have h : env30815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30814_30815 : H12AffineEnvironment.transform 11 64 env30814 = env30815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env30814 == env30815) = true)

theorem identity30815 : scanCanonicalize (H12AffineFastState.compose env30815 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30815 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30816 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,16,41,0,293,263,16,2048,272,292,0,261,309,3,40,16,2048,309,309,2048,20,33,257,32,0,805]

theorem envBound30816 : H12AffineFastState.Bounded env30816 := by
  intro p hp
  have h : env30816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30815_30816 : H12AffineEnvironment.transform 5 16 env30815 = env30816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30815 == env30816) = true)

theorem identity30816 : scanCanonicalize (H12AffineFastState.compose env30816 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound30816 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30817 : List Nat := [2,4,8,16,32,16,9,256,512,273,545,16,41,0,293,263,16,545,272,292,0,261,309,3,40,16,545,309,309,545,20,33,257,32,0,805]

theorem envBound30817 : H12AffineFastState.Bounded env30817 := by
  intro p hp
  have h : env30817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30816_30817 : H12AffineEnvironment.transform 10 545 env30816 = env30817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env30816 == env30817) = true)

theorem identity30817 : scanCanonicalize (H12AffineFastState.compose env30817 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound30817 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env30818 : List Nat := [2,4,8,16,32,16,9,256,32,273,1,16,41,0,293,263,16,1,272,292,0,261,309,3,40,16,1,309,309,1,20,33,257,32,0,261]

theorem envBound30818 : H12AffineFastState.Bounded env30818 := by
  intro p hp
  have h : env30818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30817_30818 : H12AffineEnvironment.transform 8 32 env30817 = env30818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env30817 == env30818) = true)

theorem identity30818 : scanCanonicalize (H12AffineFastState.compose env30818 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30818 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30819 : List Nat := [2,4,8,16,32,16,9,36,32,53,1,16,41,0,1,35,16,1,52,0,0,33,17,3,40,16,1,17,17,1,20,33,37,32,0,33]

theorem envBound30819 : H12AffineFastState.Bounded env30819 := by
  intro p hp
  have h : env30819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30818_30819 : H12AffineEnvironment.transform 7 36 env30818 = env30819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30818 == env30819) = true)

theorem identity30819 : scanCanonicalize (H12AffineFastState.compose env30819 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30820 : List Nat := [2,4,8,16,17,16,9,21,17,4,1,16,24,0,1,18,16,1,5,0,0,16,17,3,25,16,1,17,17,1,20,16,20,17,0,16]

theorem envBound30820 : H12AffineFastState.Bounded env30820 := by
  intro p hp
  have h : env30820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30819_30820 : H12AffineEnvironment.transform 4 17 env30819 = env30820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30819 == env30820) = true)

def env30821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144597,242969,8328,64,43357,139732,160197,324821,1501,272393,257,21793,46212,74250]

theorem envBound30821 : H12AffineFastState.Bounded env30821 := by
  intro p hp
  have h : env30821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30800_30821 : H12AffineEnvironment.transform 20 4161 env30800 = env30821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30800 == env30821) = true)

theorem identity30821 : scanCanonicalize (H12AffineFastState.compose env30821 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound30821 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,452752,144597,156103,8328,64,43357,139732,160197,324821,1501,272393,257,21793,46212,63188]

theorem envBound30822 : H12AffineFastState.Bounded env30822 := by
  intro p hp
  have h : env30822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30821_30822 : H12AffineEnvironment.transform 15 54494 env30821 = env30822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env30821 == env30822) = true)

def env30823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1025,32769,4161,305360,29845,8583,8328,64,43357,24980,12677,324821,1501,272393,257,21793,46212,63188]

theorem envBound30823 : H12AffineFastState.Bounded env30823 := by
  intro p hp
  have h : env30823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30822_30823 : H12AffineEnvironment.transform 16 16448 env30822 = env30823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env30822 == env30823) = true)

theorem identity30823 : scanCanonicalize (H12AffineFastState.compose env30823 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30823 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30083,16448,262144,1025,8540,4161,264589,29845,8583,8328,64,2048,24980,12677,284040,1501,272393,257,21793,5593,22409]

theorem envBound30824 : H12AffineFastState.Bounded env30824 := by
  intro p hp
  have h : env30824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30823_30824 : H12AffineEnvironment.transform 14 8541 env30823 = env30824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30823 == env30824) = true)

theorem identity30824 : scanCanonicalize (H12AffineFastState.compose env30824 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound30824 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env30825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30083,16448,32041,1025,8540,4161,29860,29845,8583,8328,64,2048,24980,12677,10401,1501,21792,257,21793,5593,22409]

theorem envBound30825 : H12AffineFastState.Bounded env30825 := by
  intro p hp
  have h : env30825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30824_30825 : H12AffineEnvironment.transform 17 32041 env30824 = env30825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env30824 == env30825) = true)

theorem identity30825 : scanCanonicalize (H12AffineFastState.compose env30825 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound30825 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env30826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8541,343,13460,2557,1025,8540,4161,112,65,8583,8328,64,2048,5440,12677,10401,1501,8692,257,8693,5593,9053]

theorem envBound30826 : H12AffineFastState.Bounded env30826 := by
  intro p hp
  have h : env30826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30825_30826 : H12AffineEnvironment.transform 13 13524 env30825 = env30826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env30825 == env30826) = true)

theorem identity30826 : scanCanonicalize (H12AffineFastState.compose env30826 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound30826 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env30827 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13324,8541,343,13388,2341,1025,8540,4161,112,65,8543,8272,64,2048,5440,12637,10361,1285,8492,257,8493,5377,9053]

theorem envBound30827 : H12AffineFastState.Bounded env30827 := by
  intro p hp
  have h : env30827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30826_30827 : H12AffineEnvironment.transform 6 88 env30826 = env30827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env30826 == env30827) = true)

theorem identity30827 : scanCanonicalize (H12AffineFastState.compose env30827 (packedSelected [2,4,6,9,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound30827 : packedSelected [2,4,6,9,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env30828 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1337,4405,1124,343,4469,2341,1025,1125,4161,112,65,1126,1385,64,2048,5440,5220,3392,1285,1045,257,1044,5377,1636]

theorem envBound30828 : H12AffineFastState.Bounded env30828 := by
  intro p hp
  have h : env30828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30827_30828 : H12AffineEnvironment.transform 12 1337 env30827 = env30828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env30827 == env30828) = true)

theorem identity30828 : scanCanonicalize (H12AffineFastState.compose env30828 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30828 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env30829 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,268,4405,81,343,4469,2341,52,80,4161,112,65,83,348,64,2048,4469,4177,2421,304,32,257,33,4404,593]

theorem envBound30829 : H12AffineFastState.Bounded env30829 := by
  intro p hp
  have h : env30829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30828_30829 : H12AffineEnvironment.transform 9 53 env30828 = env30829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30828 == env30829) = true)

theorem identity30829 : scanCanonicalize (H12AffineFastState.compose env30829 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound30829 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30830 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,261,268,48,81,343,112,2341,52,80,324,112,65,83,348,64,2048,112,340,2421,304,32,257,33,49,593]

theorem envBound30830 : H12AffineFastState.Bounded env30830 := by
  intro p hp
  have h : env30830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30829_30830 : H12AffineEnvironment.transform 11 261 env30829 = env30830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env30829 == env30830) = true)

theorem identity30830 : scanCanonicalize (H12AffineFastState.compose env30830 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound30830 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30831 : List Nat := [2,4,8,16,32,49,41,256,512,53,2048,261,268,48,32,294,1,2341,52,33,309,1,48,34,301,49,2048,1,293,2308,304,32,257,33,49,544]

theorem envBound30831 : H12AffineFastState.Bounded env30831 := by
  intro p hp
  have h : env30831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30830_30831 : H12AffineEnvironment.transform 5 49 env30830 = env30831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env30830 == env30831) = true)

theorem identity30831 : scanCanonicalize (H12AffineFastState.compose env30831 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30832 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,261,268,17,1,263,1,2308,21,0,276,1,17,3,268,16,2048,1,260,2308,273,1,257,0,16,513]

theorem envBound30832 : H12AffineFastState.Bounded env30832 := by
  intro p hp
  have h : env30832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30831_30832 : H12AffineEnvironment.transform 4 1 env30831 = env30832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30831 == env30832) = true)

theorem identity30832 : scanCanonicalize (H12AffineFastState.compose env30832 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30833 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,0,9,17,1,2,1,2049,21,0,17,1,17,3,9,16,2048,1,1,2049,20,1,4,0,16,513]

theorem envBound30833 : H12AffineFastState.Bounded env30833 := by
  intro p hp
  have h : env30833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30832_30833 : H12AffineEnvironment.transform 7 5 env30832 = env30833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30832 == env30833) = true)

theorem identity30833 : scanCanonicalize (H12AffineFastState.compose env30833 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound30833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30834 : List Nat := [2,4,8,16,1,16,8,5,20,20,2048,0,9,17,1,2,1,2049,21,0,17,1,17,3,9,16,2048,1,1,2049,20,1,4,0,16,21]

theorem envBound30834 : H12AffineFastState.Bounded env30834 := by
  intro p hp
  have h : env30834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30833_30834 : H12AffineEnvironment.transform 8 20 env30833 = env30834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env30833 == env30834) = true)

theorem identity30834 : scanCanonicalize (H12AffineFastState.compose env30834 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 19) := by decide +kernel

theorem selectedBound30834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30835 : List Nat := [2,4,8,16,1,16,8,5,20,20,19,0,9,17,1,2,1,18,21,0,17,1,17,3,9,16,19,1,1,18,20,1,4,0,16,21]

theorem envBound30835 : H12AffineFastState.Bounded env30835 := by
  intro p hp
  have h : env30835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30834_30835 : H12AffineEnvironment.transform 10 19 env30834 = env30835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 19 env30834 == env30835) = true)

theorem identity30835 : scanCanonicalize (H12AffineFastState.compose env30835 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30835 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30836 : List Nat := [2,4,5,16,1,16,5,5,20,20,19,0,4,17,1,2,1,18,21,0,17,1,17,3,4,16,19,1,1,18,20,1,4,0,16,21]

theorem envBound30836 : H12AffineFastState.Bounded env30836 := by
  intro p hp
  have h : env30836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30835_30836 : H12AffineEnvironment.transform 2 5 env30835 = env30836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30835 == env30836) = true)

theorem identity30836 : scanCanonicalize (H12AffineFastState.compose env30836 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30836 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30837 : List Nat := [2,4,5,4,1,4,5,5,0,0,7,0,4,5,1,2,1,6,1,0,5,1,5,3,4,4,7,1,1,6,0,1,4,0,4,1]

theorem envBound30837 : H12AffineFastState.Bounded env30837 := by
  intro p hp
  have h : env30837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30836_30837 : H12AffineEnvironment.transform 3 4 env30836 = env30837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30836 == env30837) = true)

def env30838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1025,32769,4161,305361,29844,8582,8328,64,43357,24981,12676,324821,1501,272393,257,21793,46212,63188]

theorem envBound30838 : H12AffineFastState.Bounded env30838 := by
  intro p hp
  have h : env30838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30822_30838 : H12AffineEnvironment.transform 16 16449 env30822 = env30838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env30822 == env30838) = true)

theorem identity30838 : scanCanonicalize (H12AffineFastState.compose env30838 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound30838 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,16449,262144,1025,8661,4161,264453,29844,8582,8328,64,2185,24981,12676,283905,1501,272393,257,21793,5456,22272]

theorem envBound30839 : H12AffineFastState.Bounded env30839 := by
  intro p hp
  have h : env30839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30838_30839 : H12AffineEnvironment.transform 14 8660 env30838 = env30839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env30838 == env30839) = true)

theorem identity30839 : scanCanonicalize (H12AffineFastState.compose env30839 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound30839 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env30840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,16449,10281,1025,8661,4161,8492,29844,8582,8328,64,2185,24981,12676,32040,1501,32,257,21793,5456,22272]

theorem envBound30840 : H12AffineFastState.Bounded env30840 := by
  intro p hp
  have h : env30840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30839_30840 : H12AffineEnvironment.transform 17 10281 env30839 = env30840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30839 == env30840) = true)

theorem identity30840 : scanCanonicalize (H12AffineFastState.compose env30840 (packedSelected [0,1,4,7,8,18,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30840 : packedSelected [0,1,4,7,8,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env30841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,5441,10281,1025,8661,4161,8492,8596,8582,8328,64,2185,13461,12676,10280,1501,32,257,33,5456,512]

theorem envBound30841 : H12AffineFastState.Bounded env30841 := by
  intro p hp
  have h : env30841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30840_30841 : H12AffineEnvironment.transform 13 5376 env30840 = env30841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30840 == env30841) = true)

theorem identity30841 : scanCanonicalize (H12AffineFastState.compose env30841 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30841 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30842 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,8192,5376,8612,8202,5425,10281,1025,8613,4145,8492,8596,8582,8328,48,2185,13461,12676,10280,1453,32,257,33,5408,512]

theorem envBound30842 : H12AffineFastState.Bounded env30842 := by
  intro p hp
  have h : env30842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30841_30842 : H12AffineEnvironment.transform 5 48 env30841 = env30842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30841 == env30842) = true)

theorem identity30842 : scanCanonicalize (H12AffineFastState.compose env30842 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30842 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env30843 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,40,5376,396,34,5425,2049,1025,397,4145,260,444,430,160,48,2185,5309,4524,2048,1453,32,257,33,5408,512]

theorem envBound30843 : H12AffineFastState.Bounded env30843 := by
  intro p hp
  have h : env30843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30842_30843 : H12AffineEnvironment.transform 12 40 env30842 = env30843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30842 == env30843) = true)

theorem identity30843 : scanCanonicalize (H12AffineFastState.compose env30843 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30843 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30844 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,5376,396,3,5392,2049,1025,397,4112,260,413,399,129,17,2185,5276,4493,2048,1420,1,257,0,5377,512]

theorem envBound30844 : H12AffineFastState.Bounded env30844 := by
  intro p hp
  have h : env30844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30843_30844 : H12AffineEnvironment.transform 4 1 env30843 = env30844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30843 == env30844) = true)

theorem identity30844 : scanCanonicalize (H12AffineFastState.compose env30844 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound30844 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30845 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,539,9,1819,396,3,1803,2049,1025,397,523,260,413,399,129,17,2185,1671,918,2048,1420,1,257,0,1818,512]

theorem envBound30845 : H12AffineFastState.Bounded env30845 := by
  intro p hp
  have h : env30845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30844_30845 : H12AffineEnvironment.transform 11 539 env30844 = env30845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env30844 == env30845) = true)

theorem identity30845 : scanCanonicalize (H12AffineFastState.compose env30845 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound30845 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30846 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,539,9,1686,1,3,1670,2049,1025,0,523,137,16,2,129,17,2185,1671,539,2048,1025,1,140,0,1687,512]

theorem envBound30846 : H12AffineFastState.Bounded env30846 := by
  intro p hp
  have h : env30846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30845_30846 : H12AffineEnvironment.transform 7 141 env30845 = env30846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env30845 == env30846) = true)

theorem identity30846 : scanCanonicalize (H12AffineFastState.compose env30846 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 670) := by decide +kernel

theorem selectedBound30846 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30847 : List Nat := [2,4,8,16,1,17,128,141,512,670,2048,539,9,8,1,3,24,2049,671,0,523,137,16,2,129,17,2185,25,539,2048,671,1,140,0,9,512]

theorem envBound30847 : H12AffineFastState.Bounded env30847 := by
  intro p hp
  have h : env30847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30846_30847 : H12AffineEnvironment.transform 9 670 env30846 = env30847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 670 env30846 == env30847) = true)

theorem identity30847 : scanCanonicalize (H12AffineFastState.compose env30847 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30847 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30848 : List Nat := [2,4,8,16,1,17,8,5,512,534,2048,539,9,8,1,3,24,2049,535,0,523,1,16,2,9,17,2049,25,539,2048,535,1,4,0,9,512]

theorem envBound30848 : H12AffineFastState.Bounded env30848 := by
  intro p hp
  have h : env30848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30847_30848 : H12AffineEnvironment.transform 6 8 env30847 = env30848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30847 == env30848) = true)

theorem identity30848 : scanCanonicalize (H12AffineFastState.compose env30848 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound30848 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30849 : List Nat := [2,4,8,16,1,17,8,5,512,534,522,539,9,8,1,3,24,523,535,0,523,1,16,2,9,17,523,25,539,522,535,1,4,0,9,512]

theorem envBound30849 : H12AffineFastState.Bounded env30849 := by
  intro p hp
  have h : env30849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30848_30849 : H12AffineEnvironment.transform 10 522 env30848 = env30849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env30848 == env30849) = true)

theorem identity30849 : scanCanonicalize (H12AffineFastState.compose env30849 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound30849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30850 : List Nat := [2,4,8,16,1,17,8,5,11,29,1,16,9,8,1,3,24,0,28,0,0,1,16,2,9,17,0,25,16,1,28,1,4,0,9,11]

theorem envBound30850 : H12AffineFastState.Bounded env30850 := by
  intro p hp
  have h : env30850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30849_30850 : H12AffineEnvironment.transform 8 11 env30849 = env30850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env30849 == env30850) = true)

theorem identity30850 : scanCanonicalize (H12AffineFastState.compose env30850 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound30850 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30851 : List Nat := [2,4,8,5,1,4,8,5,11,8,1,5,9,8,1,3,13,0,9,0,0,1,5,2,9,4,0,12,5,1,9,1,4,0,9,11]

theorem envBound30851 : H12AffineFastState.Bounded env30851 := by
  intro p hp
  have h : env30851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30850_30851 : H12AffineEnvironment.transform 3 5 env30850 = env30851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env30850 == env30851) = true)

def env30852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237588,242969,8328,64,2144541,2240917,160197,2417812,2102684,2373705,257,21793,46212,2175563]

theorem envBound30852 : H12AffineFastState.Bounded env30852 := by
  intro p hp
  have h : env30852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30799_30852 : H12AffineEnvironment.transform 21 452753 env30799 = env30852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env30799 == env30852) = true)

def env30853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144596,242969,8328,64,43357,139733,160197,324820,1500,272393,257,21793,46212,74251]

theorem envBound30853 : H12AffineFastState.Bounded env30853 := by
  intro p hp
  have h : env30853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30852_30853 : H12AffineEnvironment.transform 20 4160 env30852 = env30853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30852 == env30853) = true)

theorem identity30853 : scanCanonicalize (H12AffineFastState.compose env30853 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30853 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452753,144596,169235,8328,64,43357,139733,160197,324820,1500,272393,257,21793,46212,513]

theorem envBound30854 : H12AffineFastState.Bounded env30854 := by
  intro p hp
  have h : env30854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30853_30854 : H12AffineEnvironment.transform 15 8202 env30853 = env30854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30853 == env30854) = true)

def env30855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305281,29892,54531,8328,64,43357,25029,12757,324820,1500,272393,257,21793,46212,513]

theorem envBound30855 : H12AffineFastState.Bounded env30855 := by
  intro p hp
  have h : env30855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30854_30855 : H12AffineEnvironment.transform 16 16400 env30854 = env30855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30854 == env30855) = true)

def env30856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305161,29772,54531,8192,64,43357,24909,12637,324700,1364,272393,257,21793,46092,513]

theorem envBound30856 : H12AffineFastState.Bounded env30856 := by
  intro p hp
  have h : env30856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30855_30856 : H12AffineEnvironment.transform 6 8 env30855 = env30856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30855 == env30856) = true)

def env30857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305160,29773,54531,8193,64,43357,24908,12636,324701,1365,272393,257,21793,46093,513]

theorem envBound30857 : H12AffineFastState.Bounded env30857 := by
  intro p hp
  have h : env30857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30855_30857 : H12AffineEnvironment.transform 6 9 env30855 = env30857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30855 == env30857) = true)

theorem identity30857 : scanCanonicalize (H12AffineFastState.compose env30857 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound30857 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env30858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16400,262144,1025,32769,4160,298053,20480,54531,1100,64,36112,17665,5393,315408,1365,265284,257,21793,36928,513]

theorem envBound30858 : H12AffineFastState.Bounded env30858 := by
  intro p hp
  have h : env30858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30857_30858 : H12AffineEnvironment.transform 12 1101 env30857 = env30858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env30857 == env30858) = true)

theorem identity30858 : scanCanonicalize (H12AffineFastState.compose env30858 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound30858 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env30859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16400,22884,1025,32769,4160,54561,20480,54531,1100,64,36112,17665,5393,35188,1365,21792,257,21793,36928,513]

theorem envBound30859 : H12AffineFastState.Bounded env30859 := by
  intro p hp
  have h : env30859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30858_30859 : H12AffineEnvironment.transform 17 22884 env30858 = env30859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env30858 == env30859) = true)

def env30860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,305280,29893,54530,8328,64,43357,25028,12756,324820,1500,272393,257,21793,46212,513]

theorem envBound30860 : H12AffineFastState.Bounded env30860 := by
  intro p hp
  have h : env30860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30854_30860 : H12AffineEnvironment.transform 16 16401 env30854 = env30860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30854 == env30860) = true)

theorem identity30860 : scanCanonicalize (H12AffineFastState.compose env30860 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound30860 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13509,262144,1025,32769,4160,305280,17,41430,8328,64,43357,5392,12756,294912,1500,272393,257,8693,46212,513]

theorem envBound30861 : H12AffineFastState.Bounded env30861 := by
  intro p hp
  have h : env30861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30860_30861 : H12AffineEnvironment.transform 13 13524 env30860 = env30861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env30860 == env30861) = true)

theorem identity30861 : scanCanonicalize (H12AffineFastState.compose env30861 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound30861 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13509,43048,1025,32769,4160,168,17,41430,8328,64,43357,5392,12756,10280,1500,32801,257,8693,46212,513]

theorem envBound30862 : H12AffineFastState.Bounded env30862 := by
  intro p hp
  have h : env30862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30861_30862 : H12AffineEnvironment.transform 17 43048 env30861 = env30862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env30861 == env30862) = true)

theorem identity30862 : scanCanonicalize (H12AffineFastState.compose env30862 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30862 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env30863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,13389,43048,1025,32769,4160,32,17,41310,8192,64,43357,5392,12636,10280,1364,32801,257,8573,46092,513]

theorem envBound30863 : H12AffineFastState.Bounded env30863 := by
  intro p hp
  have h : env30863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30862_30863 : H12AffineEnvironment.transform 6 8 env30862 = env30863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30862 == env30863) = true)

theorem identity30863 : scanCanonicalize (H12AffineFastState.compose env30863 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound30863 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,13389,10281,1025,0,4160,32,17,8543,8192,64,10588,5392,12636,10280,1364,32,257,8573,13325,513]

theorem envBound30864 : H12AffineFastState.Bounded env30864 := by
  intro p hp
  have h : env30864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30863_30864 : H12AffineEnvironment.transform 14 1 env30863 = env30864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env30863 == env30864) = true)

theorem identity30864 : scanCanonicalize (H12AffineFastState.compose env30864 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30864 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5392,2420,1025,0,4160,32,17,2,349,64,2049,5392,4097,2421,1364,32,257,32,5456,513]

theorem envBound30865 : H12AffineFastState.Bounded env30865 := by
  intro p hp
  have h : env30865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30864_30865 : H12AffineEnvironment.transform 12 349 env30864 = env30865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30864 == env30865) = true)

theorem identity30865 : scanCanonicalize (H12AffineFastState.compose env30865 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound30865 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,4096,349,5377,1,343,5392,302,1025,0,4160,32,17,2,349,64,91,5392,4097,303,1364,32,257,32,5456,513]

theorem envBound30866 : H12AffineFastState.Bounded env30866 := by
  intro p hp
  have h : env30866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30865_30866 : H12AffineEnvironment.transform 10 90 env30865 = env30866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env30865 == env30866) = true)

theorem identity30866 : scanCanonicalize (H12AffineFastState.compose env30866 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound30866 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,1297,349,16,1,343,1,302,1025,0,1361,32,17,2,349,64,91,1,1296,303,1364,32,257,32,65,513]

theorem envBound30867 : H12AffineFastState.Bounded env30867 := by
  intro p hp
  have h : env30867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30866_30867 : H12AffineEnvironment.transform 11 1297 env30866 = env30867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env30866 == env30867) = true)

theorem identity30867 : scanCanonicalize (H12AffineFastState.compose env30867 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30867 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30868 : List Nat := [2,4,8,16,32,64,8,117,512,1024,90,1124,40,16,1,34,1,91,1025,0,1060,32,17,2,40,64,91,1,1125,90,1057,32,116,32,65,513]

theorem envBound30868 : H12AffineFastState.Bounded env30868 := by
  intro p hp
  have h : env30868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30867_30868 : H12AffineEnvironment.transform 7 117 env30867 = env30868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30867 == env30868) = true)

theorem identity30868 : scanCanonicalize (H12AffineFastState.compose env30868 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound30868 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30869 : List Nat := [2,4,8,16,32,64,8,117,512,110,90,10,40,16,1,34,1,91,111,0,74,32,17,2,40,64,91,1,11,90,79,32,116,32,65,513]

theorem envBound30869 : H12AffineFastState.Bounded env30869 := by
  intro p hp
  have h : env30869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30868_30869 : H12AffineEnvironment.transform 9 110 env30868 = env30869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env30868 == env30869) = true)

theorem identity30869 : scanCanonicalize (H12AffineFastState.compose env30869 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30869 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30870 : List Nat := [2,4,8,16,1,64,8,84,512,79,90,10,9,16,1,3,1,91,78,0,74,1,17,2,9,64,91,1,11,90,79,1,85,1,65,513]

theorem envBound30870 : H12AffineFastState.Bounded env30870 := by
  intro p hp
  have h : env30870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30869_30870 : H12AffineEnvironment.transform 4 1 env30869 = env30870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30869 == env30870) = true)

def env30871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144597,242969,8328,64,43356,139732,160197,324821,1501,272392,257,21793,46212,74250]

theorem envBound30871 : H12AffineFastState.Bounded env30871 := by
  intro p hp
  have h : env30871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30852_30871 : H12AffineEnvironment.transform 20 4161 env30852 = env30871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30852 == env30871) = true)

theorem identity30871 : scanCanonicalize (H12AffineFastState.compose env30871 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound30871 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329867,120015,21763,8328,64,43356,115150,102879,324821,1501,272392,257,21793,46212,74250]

theorem envBound30872 : H12AffineFastState.Bounded env30872 := by
  intro p hp
  have h : env30872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30871_30872 : H12AffineEnvironment.transform 16 122906 env30871 = env30872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env30871 == env30872) = true)

def env30873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10400,1025,32769,4161,73771,120015,21763,8328,64,43356,115150,102879,56437,1501,168,257,21793,46212,74250]

theorem envBound30873 : H12AffineFastState.Bounded env30873 := by
  intro p hp
  have h : env30873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30872_30873 : H12AffineEnvironment.transform 17 10400 env30872 = env30873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30872 == env30873) = true)

theorem identity30873 : scanCanonicalize (H12AffineFastState.compose env30873 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound30873 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,90258,10400,1025,137,4161,73771,87111,21763,8328,64,10708,82246,69975,23805,1501,168,257,21793,13324,74250]

theorem envBound30874 : H12AffineFastState.Bounded env30874 := by
  intro p hp
  have h : env30874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30873_30874 : H12AffineEnvironment.transform 14 136 env30873 = env30874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env30873 == env30874) = true)

theorem identity30874 : scanCanonicalize (H12AffineFastState.compose env30874 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30874 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90138,10280,1025,1,4161,73771,87111,21763,8192,64,10588,82246,69975,23669,1365,32,257,21793,13324,74250]

theorem envBound30875 : H12AffineFastState.Bounded env30875 := by
  intro p hp
  have h : env30875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30874_30875 : H12AffineEnvironment.transform 6 8 env30874 = env30875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30874 == env30875) = true)

theorem identity30875 : scanCanonicalize (H12AffineFastState.compose env30875 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound30875 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,70726,10280,1025,1,4161,73771,73755,8543,8192,64,10588,79130,69975,10281,1365,32,257,8573,13324,74250]

theorem envBound30876 : H12AffineFastState.Bounded env30876 := by
  intro p hp
  have h : env30876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30875_30876 : H12AffineEnvironment.transform 13 13404 env30875 = env30876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env30875 == env30876) = true)

theorem identity30876 : scanCanonicalize (H12AffineFastState.compose env30876 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound30876 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env30877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,1094,4096,10280,1025,1,4161,9325,9309,8543,8192,64,10588,12636,5393,10281,1365,32,257,8573,13324,9804]

theorem envBound30877 : H12AffineFastState.Bounded env30877 := by
  intro p hp
  have h : env30877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30876_30877 : H12AffineEnvironment.transform 15 1094 env30876 = env30877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env30876 == env30877) = true)

theorem identity30877 : scanCanonicalize (H12AffineFastState.compose env30877 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30877 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,1094,4096,2420,1025,1,4161,1329,1281,3,348,64,2048,4096,5393,2421,1365,32,257,33,5456,1808]

theorem envBound30878 : H12AffineFastState.Bounded env30878 := by
  intro p hp
  have h : env30878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30877_30878 : H12AffineEnvironment.transform 12 348 env30877 = env30878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30877 == env30878) = true)

theorem identity30878 : scanCanonicalize (H12AffineFastState.compose env30878 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30878 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30879 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,0,343,4096,2420,272,1,4161,32,16,3,348,64,2048,4096,4096,2421,68,32,257,33,4161,513]

theorem envBound30879 : H12AffineFastState.Bounded env30879 := by
  intro p hp
  have h : env30879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30878_30879 : H12AffineEnvironment.transform 9 273 env30878 = env30879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30878 == env30879) = true)

theorem identity30879 : scanCanonicalize (H12AffineFastState.compose env30879 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30880 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4113,0,262,4096,2341,272,1,4112,32,16,3,269,17,2048,4096,4096,2340,21,32,257,33,4112,513]

theorem envBound30880 : H12AffineFastState.Bounded env30880 := by
  intro p hp
  have h : env30880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30879_30880 : H12AffineEnvironment.transform 5 17 env30879 = env30880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30879 == env30880) = true)

theorem identity30880 : scanCanonicalize (H12AffineFastState.compose env30880 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound30880 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30881 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,16,269,1,0,262,16,2341,272,1,0,32,16,3,269,17,2048,16,16,2340,21,32,257,33,0,513]

theorem envBound30881 : H12AffineFastState.Bounded env30881 := by
  intro p hp
  have h : env30881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30880_30881 : H12AffineEnvironment.transform 11 16 env30880 = env30881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30880 == env30881) = true)

theorem identity30881 : scanCanonicalize (H12AffineFastState.compose env30881 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30881 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30882 : List Nat := [2,4,8,16,32,17,8,256,512,273,292,16,269,1,0,262,16,1,272,1,0,32,16,3,269,17,292,16,16,0,21,32,257,33,0,513]

theorem envBound30882 : H12AffineFastState.Bounded env30882 := by
  intro p hp
  have h : env30882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30881_30882 : H12AffineEnvironment.transform 10 292 env30881 = env30882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30881 == env30882) = true)

theorem identity30882 : scanCanonicalize (H12AffineFastState.compose env30882 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30882 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30883 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,1,0,34,16,1,52,1,0,32,16,3,41,17,0,16,16,0,21,32,37,33,0,513]

theorem envBound30883 : H12AffineFastState.Bounded env30883 := by
  intro p hp
  have h : env30883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30882_30883 : H12AffineEnvironment.transform 7 36 env30882 = env30883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30882 == env30883) = true)

theorem identity30883 : scanCanonicalize (H12AffineFastState.compose env30883 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30884 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,16,41,1,0,34,16,1,52,1,0,32,16,3,41,17,0,16,16,0,21,32,37,33,0,0]

theorem envBound30884 : H12AffineFastState.Bounded env30884 := by
  intro p hp
  have h : env30884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30883_30884 : H12AffineEnvironment.transform 8 1 env30883 = env30884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30883 == env30884) = true)

theorem identity30884 : scanCanonicalize (H12AffineFastState.compose env30884 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30885 : List Nat := [2,4,8,16,11,17,8,15,1,30,0,16,2,1,0,9,16,1,31,1,0,11,16,3,2,17,0,16,16,0,21,11,14,10,0,0]

theorem envBound30885 : H12AffineFastState.Bounded env30885 := by
  intro p hp
  have h : env30885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30884_30885 : H12AffineEnvironment.transform 4 11 env30884 = env30885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30884 == env30885) = true)

def env30886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10401,1025,32769,4161,73770,120015,21763,8328,64,43356,115150,102879,56436,1501,169,257,21793,46212,74250]

theorem envBound30886 : H12AffineFastState.Bounded env30886 := by
  intro p hp
  have h : env30886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30872_30886 : H12AffineEnvironment.transform 17 10401 env30872 = env30886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30872 == env30886) = true)

theorem identity30886 : scanCanonicalize (H12AffineFastState.compose env30886 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30886 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49304,10401,1025,32769,4161,168,62541,21763,8328,64,43356,57676,45405,56436,1501,169,257,21793,46212,648]

theorem envBound30887 : H12AffineFastState.Bounded env30887 := by
  intro p hp
  have h : env30887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30886_30887 : H12AffineEnvironment.transform 15 8322 env30886 = env30887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30886 == env30887) = true)

theorem identity30887 : scanCanonicalize (H12AffineFastState.compose env30887 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound30887 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env30888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,342,49304,2421,1025,32769,4161,168,54681,21763,348,64,34952,49304,37001,56436,1501,169,257,21793,38224,648]

theorem envBound30888 : H12AffineFastState.Bounded env30888 := by
  intro p hp
  have h : env30888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30887_30888 : H12AffineEnvironment.transform 12 468 env30887 = env30888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env30887 == env30888) = true)

theorem identity30888 : scanCanonicalize (H12AffineFastState.compose env30888 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound30888 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,342,16401,2421,1025,136,4161,168,21776,21763,348,64,2049,16401,4096,23805,1501,169,257,21793,5593,648]

theorem envBound30889 : H12AffineFastState.Bounded env30889 := by
  intro p hp
  have h : env30889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30888_30889 : H12AffineEnvironment.transform 14 137 env30888 = env30889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env30888 == env30889) = true)

theorem identity30889 : scanCanonicalize (H12AffineFastState.compose env30889 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30889 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,342,16401,2421,1025,1,4161,33,21776,21763,348,64,2049,16401,4096,23668,1364,32,257,21793,5456,513]

theorem envBound30890 : H12AffineFastState.Bounded env30890 := by
  intro p hp
  have h : env30890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30889_30890 : H12AffineEnvironment.transform 6 9 env30889 = env30890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30889 == env30890) = true)

theorem identity30890 : scanCanonicalize (H12AffineFastState.compose env30890 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound30890 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,0,342,4096,2421,1025,1,4161,33,1281,1298,348,64,2049,4096,4096,3173,1364,32,257,1328,5456,513]

theorem envBound30891 : H12AffineFastState.Bounded env30891 := by
  intro p hp
  have h : env30891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30890_30891 : H12AffineEnvironment.transform 13 4113 env30890 = env30891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env30890 == env30891) = true)

theorem identity30891 : scanCanonicalize (H12AffineFastState.compose env30891 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound30891 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,349,2128,0,342,2113,2421,1025,1,2048,33,1281,1298,348,64,2049,2113,2113,3173,1364,32,257,1328,3345,513]

theorem envBound30892 : H12AffineFastState.Bounded env30892 := by
  intro p hp
  have h : env30892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30891_30892 : H12AffineEnvironment.transform 11 2113 env30891 = env30892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env30891 == env30892) = true)

theorem identity30892 : scanCanonicalize (H12AffineFastState.compose env30892 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30892 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30893 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,349,2128,0,342,2113,2421,52,1,2048,33,308,295,348,64,2049,2113,2113,2128,353,32,257,261,2340,513]

theorem envBound30893 : H12AffineFastState.Bounded env30893 := by
  intro p hp
  have h : env30893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30892_30893 : H12AffineEnvironment.transform 9 53 env30892 = env30893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30892 == env30893) = true)

theorem identity30893 : scanCanonicalize (H12AffineFastState.compose env30893 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30893 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env30894 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2113,121,2128,0,114,2113,2129,52,1,2048,33,16,3,120,64,2049,2113,2113,2128,69,32,37,33,2048,513]

theorem envBound30894 : H12AffineFastState.Bounded env30894 := by
  intro p hp
  have h : env30894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30893_30894 : H12AffineEnvironment.transform 7 36 env30893 = env30894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30893 == env30894) = true)

theorem identity30894 : scanCanonicalize (H12AffineFastState.compose env30894 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30894 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30895 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2049,0,35,2064,2048,52,1,2048,33,16,3,41,17,2049,2064,2064,2049,20,32,37,33,2048,513]

theorem envBound30895 : H12AffineFastState.Bounded env30895 := by
  intro p hp
  have h : env30895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30894_30895 : H12AffineEnvironment.transform 5 17 env30894 = env30895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30894 == env30895) = true)

def env30896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound30896 : H12AffineFastState.Bounded env30896 := by
  intro p hp
  have h : env30896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30477_30896 : H12AffineEnvironment.transform 26 30393345 env30477 = env30896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env30477 == env30896) = true)

def env30897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound30897 : H12AffineFastState.Bounded env30897 := by
  intro p hp
  have h : env30897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30896_30897 : H12AffineEnvironment.transform 18 1024 env30896 = env30897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env30896 == env30897) = true)

theorem identity30897 : scanCanonicalize (H12AffineFastState.compose env30897 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound30897 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,8388608,16777216,8328,64,29843925,18949465,10507601,8806868,25241029,23160256,256,27354488,27337993,25166355]

theorem envBound30898 : H12AffineFastState.Bounded env30898 := by
  intro p hp
  have h : env30898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30897_30898 : H12AffineEnvironment.transform 14 8660 env30897 = env30898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env30897 == env30898) = true)

def env30899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147456,16777216,8328,64,21307861,18949465,2233681,270804,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound30899 : H12AffineFastState.Bounded env30899 := by
  intro p hp
  have h : env30899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30898_30899 : H12AffineEnvironment.transform 22 147456 env30898 = env30899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env30898 == env30899) = true)

def env30900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1024,8661,2097152,4194304,147456,16777216,8328,64,21039477,18949465,2233681,2420,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound30900 : H12AffineFastState.Bounded env30900 := by
  intro p hp
  have h : env30900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30899_30900 : H12AffineEnvironment.transform 17 10400 env30899 = env30900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30899 == env30900) = true)

theorem identity30900 : scanCanonicalize (H12AffineFastState.compose env30900 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound30900 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1024,8661,2097152,4194304,147456,138,8328,64,4262399,2172371,2233681,2420,222543,6382922,256,2303474,2319747,148121]

theorem envBound30901 : H12AffineFastState.Bounded env30901 := by
  intro p hp
  have h : env30901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30900_30901 : H12AffineEnvironment.transform 23 138 env30900 = env30901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env30900 == env30901) = true)

theorem identity30901 : scanCanonicalize (H12AffineFastState.compose env30901 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30901 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env30902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,131072,10400,1024,8661,2097152,4194304,147456,138,8328,64,4204925,2098513,2233681,2420,148941,6309320,256,2229616,2245889,148121]

theorem envBound30902 : H12AffineFastState.Bounded env30902 := by
  intro p hp
  have h : env30902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30901_30902 : H12AffineEnvironment.transform 15 8322 env30901 = env30902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30901 == env30902) = true)

theorem identity30902 : scanCanonicalize (H12AffineFastState.compose env30902 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30902 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env30903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,131072,10400,1024,8661,2097152,32,147456,138,8328,64,10589,2098513,2233681,2420,148941,2115048,256,2229616,2245889,148121]

theorem envBound30903 : H12AffineFastState.Bounded env30903 := by
  intro p hp
  have h : env30903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30902_30903 : H12AffineEnvironment.transform 21 32 env30902 = env30903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30902 == env30903) = true)

theorem identity30903 : scanCanonicalize (H12AffineFastState.compose env30903 (packedSelected [0,2,3,5,6,10,11,12,14,15,16,17,18,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 12512) := by decide +kernel

theorem selectedBound30903 : packedSelected [0,2,3,5,6,10,11,12,14,15,16,17,18,20,27] rootPS < 2^1333 := by decide +kernel

def env30904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,131072,10400,1024,8661,12512,32,147456,138,8328,64,10589,13745,140721,2420,148941,29960,256,144784,161249,148121]

theorem envBound30904 : H12AffineFastState.Bounded env30904 := by
  intro p hp
  have h : env30904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30903_30904 : H12AffineEnvironment.transform 20 12512 env30903 = env30904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12512 env30903 == env30904) = true)

theorem identity30904 : scanCanonicalize (H12AffineFastState.compose env30904 (packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,16,17,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound30904 : packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,16,17,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env30905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,5309,10400,1024,8661,12512,32,21693,138,8328,64,10589,13745,12556,2420,20848,29960,256,8493,24924,22052]

theorem envBound30905 : H12AffineFastState.Bounded env30905 := by
  intro p hp
  have h : env30905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30904_30905 : H12AffineEnvironment.transform 16 5309 env30904 = env30905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env30904 == env30905) = true)

theorem identity30905 : scanCanonicalize (H12AffineFastState.compose env30905 (packedSelected [10,12,14,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound30905 : packedSelected [10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env30906 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,8312,8322,5309,10400,1024,8313,12512,32,21693,138,8328,64,10481,13341,12448,2264,20700,29860,172,8321,24816,22052]

theorem envBound30906 : H12AffineFastState.Bounded env30906 := by
  intro p hp
  have h : env30906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30905_30906 : H12AffineEnvironment.transform 7 172 env30905 = env30906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30905 == env30906) = true)

theorem identity30906 : scanCanonicalize (H12AffineFastState.compose env30906 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound30906 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env30907 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,13405,8312,8322,5309,10400,1024,8313,12512,32,8416,138,8328,64,10481,13341,12448,2264,9345,249,172,8321,5293,8825]

theorem envBound30907 : H12AffineFastState.Bounded env30907 := by
  intro p hp
  have h : env30907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30906_30907 : H12AffineEnvironment.transform 13 13405 env30906 = env30907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env30906 == env30907) = true)

theorem identity30907 : scanCanonicalize (H12AffineFastState.compose env30907 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30907 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env30908 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,8312,8203,5172,10281,1024,8313,12393,32,8297,3,8193,64,10360,13341,12329,2129,9224,112,37,8200,5156,8825]

theorem envBound30908 : H12AffineFastState.Bounded env30908 := by
  intro p hp
  have h : env30908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30907_30908 : H12AffineEnvironment.transform 6 9 env30907 = env30908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30907 == env30908) = true)

theorem identity30908 : scanCanonicalize (H12AffineFastState.compose env30908 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30908 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env30909 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,8232,8203,5172,10281,1024,8233,12345,32,8249,3,8193,16,10280,13341,12329,2049,9224,32,37,8200,5156,8745]

theorem envBound30909 : H12AffineFastState.Bounded env30909 := by
  intro p hp
  have h : env30909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30908_30909 : H12AffineEnvironment.transform 5 16 env30908 = env30909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30908 == env30909) = true)

theorem identity30909 : scanCanonicalize (H12AffineFastState.compose env30909 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30909 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30910 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,34,5172,2048,1024,0,4112,32,16,3,40,16,2049,5172,4096,2049,1057,32,37,33,5156,512]

theorem envBound30910 : H12AffineFastState.Bounded env30910 := by
  intro p hp
  have h : env30910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30909_30910 : H12AffineEnvironment.transform 12 41 env30909 = env30910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30909 == env30910) = true)

theorem identity30910 : scanCanonicalize (H12AffineFastState.compose env30910 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30910 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30911 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5125,1,3,5141,2048,1024,0,4112,1,16,3,9,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound30911 : H12AffineFastState.Bounded env30911 := by
  intro p hp
  have h : env30911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30910_30911 : H12AffineEnvironment.transform 4 1 env30910 = env30911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30910 == env30911) = true)

def env30912 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1045,1,3,1029,2048,1024,0,0,1,16,3,9,16,2049,1029,16,2049,1024,1,4,0,1045,512]

theorem envBound30912 : H12AffineFastState.Bounded env30912 := by
  intro p hp
  have h : env30912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30911_30912 : H12AffineEnvironment.transform 11 16 env30911 = env30912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30911 == env30912) = true)

def env30913 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,1,3,17,2048,20,0,0,1,16,3,9,16,2049,17,16,2049,20,1,4,0,1,512]

theorem envBound30913 : H12AffineFastState.Bounded env30913 := by
  intro p hp
  have h : env30913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30912_30913 : H12AffineEnvironment.transform 9 20 env30912 = env30913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30912 == env30913) = true)

theorem identity30913 : scanCanonicalize (H12AffineFastState.compose env30913 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound30913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30914 : List Nat := [2,4,8,16,1,16,9,4,31,20,2048,16,8,1,1,3,17,2048,20,0,0,1,16,3,9,16,2049,17,16,2049,20,1,4,0,1,31]

theorem envBound30914 : H12AffineFastState.Bounded env30914 := by
  intro p hp
  have h : env30914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30913_30914 : H12AffineEnvironment.transform 8 31 env30913 = env30914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env30913 == env30914) = true)

def leafEnv30914 : List Nat := [2,4,8,16,1,16,9,4,31,20,2048,16,8,1,1,3,17,2048,20,0,0,1,16,3,20,9,1,16,2049,17,16,2049,20,1,4,0,4,2,1,31,1,0,0]

def active30914 : List Nat := [0,1,2,3,10]

def tree30914 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30914 : H12WitnessSearch.Good tree30914 := H12GlobalWitnessIndex.good

theorem leafIdentity30914 : H12AffineFastState.composeSystem env30914 rootObs = leafEnv30914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30914 rootObs == leafEnv30914) = true)

theorem terminalChecked30914 : H12PackedTerminal.terminalCheckFast leafEnv30914 active30914 tree30914 = true := by decide +kernel

def env30915 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,0,1,3,16,2048,21,0,0,1,16,3,9,16,2049,16,16,2049,21,1,4,0,0,512]

theorem envBound30915 : H12AffineFastState.Bounded env30915 := by
  intro p hp
  have h : env30915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30912_30915 : H12AffineEnvironment.transform 9 21 env30912 = env30915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30912 == env30915) = true)

theorem identity30915 : scanCanonicalize (H12AffineFastState.compose env30915 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound30915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30916 : List Nat := [2,4,8,4,1,4,9,4,512,1,2048,4,8,0,1,3,4,2048,1,0,0,1,4,3,9,4,2049,4,4,2049,1,1,4,0,0,512]

theorem envBound30916 : H12AffineFastState.Bounded env30916 := by
  intro p hp
  have h : env30916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30915_30916 : H12AffineEnvironment.transform 3 4 env30915 = env30916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env30915 == env30916) = true)

def leafEnv30916 : List Nat := [2,4,8,4,1,4,9,4,512,1,2048,4,8,0,1,3,4,2048,1,0,0,1,4,3,1,9,1,4,2049,4,4,2049,1,1,4,0,4,2,0,512,1,0,0]

def active30916 : List Nat := [0,1,2,8,10]

def tree30916 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30916 : H12WitnessSearch.Good tree30916 := H12GlobalWitnessIndex.good

theorem leafIdentity30916 : H12AffineFastState.composeSystem env30916 rootObs = leafEnv30916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30916 rootObs == leafEnv30916) = true)

theorem terminalChecked30916 : H12PackedTerminal.terminalCheckFast leafEnv30916 active30916 tree30916 = true := by decide +kernel

def env30917 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,1,3,1028,2048,1024,0,1,1,16,3,9,16,2049,1028,17,2049,1024,1,4,0,1044,512]

theorem envBound30917 : H12AffineFastState.Bounded env30917 := by
  intro p hp
  have h : env30917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30911_30917 : H12AffineEnvironment.transform 11 17 env30911 = env30917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30911 == env30917) = true)

theorem identity30917 : scanCanonicalize (H12AffineFastState.compose env30917 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30918 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,0,1,3,16,2048,20,0,1,1,16,3,9,16,2049,16,17,2049,20,1,4,0,0,512]

theorem envBound30918 : H12AffineFastState.Bounded env30918 := by
  intro p hp
  have h : env30918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30917_30918 : H12AffineEnvironment.transform 9 20 env30917 = env30918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30917 == env30918) = true)

theorem identity30918 : scanCanonicalize (H12AffineFastState.compose env30918 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound30918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30919 : List Nat := [2,4,8,16,1,16,9,4,30,20,2048,17,8,0,1,3,16,2048,20,0,1,1,16,3,9,16,2049,16,17,2049,20,1,4,0,0,30]

theorem envBound30919 : H12AffineFastState.Bounded env30919 := by
  intro p hp
  have h : env30919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30918_30919 : H12AffineEnvironment.transform 8 30 env30918 = env30919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env30918 == env30919) = true)

def leafEnv30919 : List Nat := [2,4,8,16,1,16,9,4,30,20,2048,17,8,0,1,3,16,2048,20,0,1,1,16,3,20,9,1,16,2049,16,17,2049,20,1,4,0,4,2,0,30,1,1,0]

def active30919 : List Nat := [0,1,2,3,10]

def tree30919 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30919 : H12WitnessSearch.Good tree30919 := H12GlobalWitnessIndex.good

theorem leafIdentity30919 : H12AffineFastState.composeSystem env30919 rootObs = leafEnv30919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30919 rootObs == leafEnv30919) = true)

theorem terminalChecked30919 : H12PackedTerminal.terminalCheckFast leafEnv30919 active30919 tree30919 = true := by decide +kernel

def env30920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1024,8661,2097152,4194304,147456,16777216,8328,64,21039476,18949465,2233681,2421,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound30920 : H12AffineFastState.Bounded env30920 := by
  intro p hp
  have h : env30920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30899_30920 : H12AffineEnvironment.transform 17 10401 env30899 = env30920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30899 == env30920) = true)

theorem identity30920 : scanCanonicalize (H12AffineFastState.compose env30920 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 147610) := by decide +kernel

theorem selectedBound30920 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1024,8661,2097152,4194304,147456,147610,8328,64,4409838,2319811,2233681,2421,75103,6497626,256,2188770,2172307,649]

theorem envBound30921 : H12AffineFastState.Bounded env30921 := by
  intro p hp
  have h : env30921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30920_30921 : H12AffineEnvironment.transform 23 147610 env30920 = env30921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147610 env30920 == env30921) = true)

theorem identity30921 : scanCanonicalize (H12AffineFastState.compose env30921 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30921 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env30922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147474,8192,64,4409702,2319691,2233681,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound30922 : H12AffineFastState.Bounded env30922 := by
  intro p hp
  have h : env30922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30921_30922 : H12AffineEnvironment.transform 6 8 env30921 = env30922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30921 == env30922) = true)

theorem identity30922 : scanCanonicalize (H12AffineFastState.compose env30922 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound30922 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env30923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,25629,4194304,147456,147474,8192,64,4409702,196950,160076,2421,75103,4407623,256,65911,82182,513]

theorem envBound30923 : H12AffineFastState.Bounded env30923 := by
  intro p hp
  have h : env30923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30922_30923 : H12AffineEnvironment.transform 20 25629 env30922 = env30923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env30922 == env30923) = true)

theorem identity30923 : scanCanonicalize (H12AffineFastState.compose env30923 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30923 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env30924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,25629,4194304,16,2,8192,64,4262262,82246,12636,2421,75103,4260183,256,65911,82182,513]

theorem envBound30924 : H12AffineFastState.Bounded env30924 := by
  intro p hp
  have h : env30924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30923_30924 : H12AffineEnvironment.transform 16 16400 env30923 = env30924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30923 == env30924) = true)

theorem identity30924 : scanCanonicalize (H12AffineFastState.compose env30924 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound30924 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env30925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,25629,8572,16,2,8192,64,75786,82246,12636,2421,75103,73771,256,65911,82182,513]

theorem envBound30925 : H12AffineFastState.Bounded env30925 := by
  intro p hp
  have h : env30925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30924_30925 : H12AffineEnvironment.transform 21 8572 env30924 = env30925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env30924 == env30925) = true)

theorem identity30925 : scanCanonicalize (H12AffineFastState.compose env30925 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound30925 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env30926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,16400,10281,1024,8541,25629,8572,16,2,8192,64,10588,16400,12636,2421,9225,8573,256,33,16464,513]

theorem envBound30926 : H12AffineFastState.Bounded env30926 := by
  intro p hp
  have h : env30926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30925_30926 : H12AffineEnvironment.transform 15 342 env30925 = env30926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env30925 == env30926) = true)

theorem identity30926 : scanCanonicalize (H12AffineFastState.compose env30926 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 8525) := by decide +kernel

theorem selectedBound30926 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8525,8540,342,8541,10281,1024,8541,1360,8572,16,2,8192,64,10588,8541,12636,2421,9225,8573,256,33,8477,513]

theorem envBound30927 : H12AffineFastState.Bounded env30927 := by
  intro p hp
  have h : env30927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30926_30927 : H12AffineEnvironment.transform 13 8525 env30926 = env30927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8525 env30926 == env30927) = true)

theorem identity30927 : scanCanonicalize (H12AffineFastState.compose env30927 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30927 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16,1,342,0,2420,1024,0,1360,33,16,2,349,64,2049,0,4097,2421,1364,32,256,33,64,513]

theorem envBound30928 : H12AffineFastState.Bounded env30928 := by
  intro p hp
  have h : env30928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30927_30928 : H12AffineEnvironment.transform 12 349 env30927 = env30928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30927 == env30928) = true)

theorem identity30928 : scanCanonicalize (H12AffineFastState.compose env30928 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound30928 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2350,349,16,1,342,0,2420,1024,0,1360,33,16,2,349,64,2049,0,2351,2421,1364,32,256,33,64,513]

theorem envBound30929 : H12AffineFastState.Bounded env30929 := by
  intro p hp
  have h : env30929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30928_30929 : H12AffineEnvironment.transform 11 2350 env30928 = env30929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env30928 == env30929) = true)

theorem identity30929 : scanCanonicalize (H12AffineFastState.compose env30929 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30929 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30930 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2350,268,16,1,263,0,2341,1024,0,1281,33,16,2,268,17,2049,0,2351,2340,1285,32,256,33,17,513]

theorem envBound30930 : H12AffineFastState.Bounded env30930 := by
  intro p hp
  have h : env30930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30929_30930 : H12AffineEnvironment.transform 5 17 env30929 = env30930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30929 == env30930) = true)

theorem identity30930 : scanCanonicalize (H12AffineFastState.compose env30930 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30931 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2350,268,16,1,263,0,2341,53,0,308,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,17,513]

theorem envBound30931 : H12AffineFastState.Bounded env30931 := by
  intro p hp
  have h : env30931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30930_30931 : H12AffineEnvironment.transform 9 53 env30930 = env30931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30930 == env30931) = true)

theorem identity30931 : scanCanonicalize (H12AffineFastState.compose env30931 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 290) := by decide +kernel

theorem selectedBound30931 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30932 : List Nat := [2,4,8,16,32,17,8,256,290,53,2048,2350,268,16,1,263,0,2341,53,0,308,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,17,291]

theorem envBound30932 : H12AffineFastState.Bounded env30932 := by
  intro p hp
  have h : env30932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30931_30932 : H12AffineEnvironment.transform 8 290 env30931 = env30932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 290 env30931 == env30932) = true)

theorem identity30932 : scanCanonicalize (H12AffineFastState.compose env30932 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound30932 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30933 : List Nat := [2,4,8,16,32,17,8,14,44,53,2048,2080,2,16,1,9,0,2091,53,0,58,33,16,2,2,17,2049,0,2081,2090,62,32,14,33,17,45]

theorem envBound30933 : H12AffineFastState.Bounded env30933 := by
  intro p hp
  have h : env30933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30932_30933 : H12AffineEnvironment.transform 7 14 env30932 = env30933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env30932 == env30933) = true)

theorem identity30933 : scanCanonicalize (H12AffineFastState.compose env30933 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30933 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env30934 : List Nat := [2,4,8,16,16,17,8,14,28,5,2048,2064,2,16,1,9,0,2075,5,0,10,17,16,2,2,17,2049,0,2065,2074,14,16,14,17,17,29]

theorem envBound30934 : H12AffineFastState.Bounded env30934 := by
  intro p hp
  have h : env30934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30933_30934 : H12AffineEnvironment.transform 4 16 env30933 = env30934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30933 == env30934) = true)

def env30935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147457,16777216,8328,64,21307860,18949465,2233680,270805,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound30935 : H12AffineFastState.Bounded env30935 := by
  intro p hp
  have h : env30935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30898_30935 : H12AffineEnvironment.transform 22 147457 env30898 = env30935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env30898 == env30935) = true)

theorem identity30935 : scanCanonicalize (H12AffineFastState.compose env30935 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound30935 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,262144,1024,8661,2097152,4194304,147457,147475,8328,64,4678087,2319690,2233680,270805,75223,6497747,256,2188650,2172187,513]

theorem envBound30936 : H12AffineFastState.Bounded env30936 := by
  intro p hp
  have h : env30936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30935_30936 : H12AffineEnvironment.transform 23 147475 env30935 = env30936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env30935 == env30936) = true)

def env30937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1024,8661,2097152,4194304,147457,147475,8328,64,4409703,2319690,2233680,2421,75223,6497747,256,2188650,2172187,513]

theorem envBound30937 : H12AffineFastState.Bounded env30937 := by
  intro p hp
  have h : env30937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30936_30937 : H12AffineEnvironment.transform 17 10400 env30936 = env30937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30936 == env30937) = true)

theorem identity30937 : scanCanonicalize (H12AffineFastState.compose env30937 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound30937 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1024,8661,2097152,4194304,152,138,8328,64,4262398,2172371,2119113,2421,75223,6382922,256,2188650,2172187,513]

theorem envBound30938 : H12AffineFastState.Bounded env30938 := by
  intro p hp
  have h : env30938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30937_30938 : H12AffineEnvironment.transform 16 16537 env30937 = env30938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env30937 == env30938) = true)

theorem identity30938 : scanCanonicalize (H12AffineFastState.compose env30938 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound30938 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,16537,10400,1024,8661,2097152,4194304,152,138,8328,64,4204925,2098512,2119113,2421,1364,6309321,256,2115049,2098584,513]

theorem envBound30939 : H12AffineFastState.Bounded env30939 := by
  intro p hp
  have h : env30939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30938_30939 : H12AffineEnvironment.transform 15 8323 env30938 = env30939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env30938 == env30939) = true)

theorem identity30939 : scanCanonicalize (H12AffineFastState.compose env30939 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound30939 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env30940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8660,8323,4232,10400,1024,8661,2097152,4194304,152,138,8328,64,4204925,2098512,2098648,2421,1364,6297048,256,2102776,2098584,513]

theorem envBound30940 : H12AffineFastState.Bounded env30940 := by
  intro p hp
  have h : env30940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30939_30940 : H12AffineEnvironment.transform 13 4113 env30939 = env30940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env30939 == env30940) = true)

theorem identity30940 : scanCanonicalize (H12AffineFastState.compose env30940 (packedSelected [1,5,10,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 2101661) := by decide +kernel

theorem selectedBound30940 : packedSelected [1,5,10,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8660,8323,4232,10400,1024,8661,2097152,2101661,152,138,8328,64,2111712,2098512,2098648,2421,1364,1093,256,2102776,2098584,513]

theorem envBound30941 : H12AffineFastState.Bounded env30941 := by
  intro p hp
  have h : env30941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30940_30941 : H12AffineEnvironment.transform 21 2101661 env30940 = env30941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101661 env30940 == env30941) = true)

theorem identity30941 : scanCanonicalize (H12AffineFastState.compose env30941 (packedSelected [1,2,5,6,10,11,12,14,17,23] rootPS)) = affineNative (2^(20+1) ^^^ 429) := by decide +kernel

theorem selectedBound30941 : packedSelected [1,2,5,6,10,11,12,14,17,23] rootPS < 2^1333 := by decide +kernel

def env30942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8660,8323,4232,10400,1024,8661,429,4144,152,138,8328,64,14669,1277,1141,2421,1364,1093,256,5205,1077,513]

theorem envBound30942 : H12AffineFastState.Bounded env30942 := by
  intro p hp
  have h : env30942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30941_30942 : H12AffineEnvironment.transform 20 429 env30941 = env30942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 429 env30941 == env30942) = true)

theorem identity30942 : scanCanonicalize (H12AffineFastState.compose env30942 (packedSelected [3,4,5,7,9,10,11,18,27] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound30942 : packedSelected [3,4,5,7,9,10,11,18,27] rootPS < 2^1333 := by decide +kernel

def env30943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,4200,4113,4540,4331,4232,6344,1024,4541,429,4144,152,138,4320,64,2341,1277,1141,2421,1364,1093,256,5205,1077,513]

theorem envBound30943 : H12AffineFastState.Bounded env30943 := by
  intro p hp
  have h : env30943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30942_30943 : H12AffineEnvironment.transform 12 4200 env30942 = env30943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env30942 == env30943) = true)

theorem identity30943 : scanCanonicalize (H12AffineFastState.compose env30943 (packedSelected [0,1,2,4,5,6,7,8,9,12,14,24] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound30943 : packedSelected [0,1,2,4,5,6,7,8,9,12,14,24] rootPS < 2^1333 := by decide +kernel

def env30944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1061,1101,1076,1433,1230,1197,3309,1024,1432,429,1045,152,138,1221,64,2341,1277,1141,2421,1364,1093,256,112,1077,513]

theorem envBound30944 : H12AffineFastState.Bounded env30944 := by
  intro p hp
  have h : env30944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30943_30944 : H12AffineEnvironment.transform 11 1061 env30943 = env30944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env30943 == env30944) = true)

theorem identity30944 : scanCanonicalize (H12AffineFastState.compose env30944 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30944 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,1061,1101,1076,1433,1230,1197,1481,1024,1432,429,1045,152,138,1221,64,1,1277,1141,81,1364,1093,256,112,1077,513]

theorem envBound30945 : H12AffineFastState.Bounded env30945 := by
  intro p hp
  have h : env30945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30944_30945 : H12AffineEnvironment.transform 10 292 env30944 = env30945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30944 == env30945) = true)

theorem identity30945 : scanCanonicalize (H12AffineFastState.compose env30945 (packedSelected [0,1,2,5,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound30945 : packedSelected [0,1,2,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env30946 : List Nat := [2,4,8,16,32,64,128,256,512,409,292,444,468,429,0,343,308,80,409,1,429,396,152,138,348,64,1,356,492,81,205,476,256,112,428,513]

theorem envBound30946 : H12AffineFastState.Bounded env30946 := by
  intro p hp
  have h : env30946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30945_30946 : H12AffineEnvironment.transform 9 409 env30945 = env30946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env30945 == env30946) = true)

def env30947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1024,8661,2097152,4194304,147457,147475,8328,64,4409702,2319690,2233680,2420,75223,6497747,256,2188650,2172187,513]

theorem envBound30947 : H12AffineFastState.Bounded env30947 := by
  intro p hp
  have h : env30947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30936_30947 : H12AffineEnvironment.transform 17 10401 env30936 = env30947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30936 == env30947) = true)

theorem identity30947 : scanCanonicalize (H12AffineFastState.compose env30947 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30947 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0