import H12CloudChart0Data061

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env15592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,169234,8328,64,245139,115151,17664,262145,119042,329731,257,213487,237642,63189]

theorem envBound15592 : H12AffineFastState.Bounded env15592 := by
  intro p hp
  have h : env15592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15591_15592 : H12AffineEnvironment.transform 21 272512 env15591 = env15592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15591 == env15592) = true)

theorem identity15592 : scanCanonicalize (H12AffineFastState.compose env15592 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound15592 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272512,17,21762,8328,64,97667,115151,17664,262145,119042,329731,257,98815,90202,63189]

theorem envBound15593 : H12AffineFastState.Bounded env15593 := by
  intro p hp
  have h : env15593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15592_15593 : H12AffineEnvironment.transform 16 49168 env15592 = env15593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15592 == env15593) = true)

def env15594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21762,8192,64,97547,115015,17664,262145,119042,329731,257,98679,90202,63069]

theorem envBound15594 : H12AffineFastState.Bounded env15594 := by
  intro p hp
  have h : env15594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15593_15594 : H12AffineEnvironment.transform 6 8 env15593 = env15594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15593 == env15594) = true)

theorem identity15594 : scanCanonicalize (H12AffineFastState.compose env15594 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound15594 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56436,1025,32769,4160,62588,17,21762,8192,64,97547,115015,17664,56437,119042,119927,257,98679,90202,63069]

theorem envBound15595 : H12AffineFastState.Bounded env15595 := by
  intro p hp
  have h : env15595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15594_15595 : H12AffineEnvironment.transform 17 56436 env15594 = env15595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env15594 == env15595) = true)

theorem identity15595 : scanCanonicalize (H12AffineFastState.compose env15595 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound15595 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,49168,56436,1025,32769,4160,62588,17,21762,8192,64,2128,46108,17664,56437,42073,41260,257,62508,5377,63069]

theorem envBound15596 : H12AffineFastState.Bounded env15596 := by
  intro p hp
  have h : env15596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15595_15596 : H12AffineEnvironment.transform 15 30043 env15595 = env15596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env15595 == env15596) = true)

theorem identity15596 : scanCanonicalize (H12AffineFastState.compose env15596 (packedSelected [0,7,10,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15596 : packedSelected [0,7,10,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env15597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30043,24909,32041,1025,8540,4160,21793,17,21762,8192,64,2128,5441,17664,32040,1284,113,257,21873,5377,22272]

theorem envBound15597 : H12AffineFastState.Bounded env15597 := by
  intro p hp
  have h : env15597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15596_15597 : H12AffineEnvironment.transform 14 8541 env15596 = env15597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15596 == env15597) = true)

theorem identity15597 : scanCanonicalize (H12AffineFastState.compose env15597 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15597 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env15598 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29962,24860,32041,1025,8461,4113,21793,17,21762,8192,17,2049,5392,17664,32040,1284,32,257,21792,5377,22272]

theorem envBound15598 : H12AffineFastState.Bounded env15598 := by
  intro p hp
  have h : env15598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15597_15598 : H12AffineEnvironment.transform 5 17 env15597 = env15598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15597 == env15598) = true)

theorem identity15598 : scanCanonicalize (H12AffineFastState.compose env15598 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound15598 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env15599 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4405,8460,9279,12329,11292,1025,8461,4113,1044,17,1079,8192,17,2049,5392,5173,11293,1284,32,257,1045,5377,1589]

theorem envBound15599 : H12AffineFastState.Bounded env15599 := by
  intro p hp
  have h : env15599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15598_15599 : H12AffineEnvironment.transform 13 4405 env15598 = env15599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env15598 == env15599) = true)

theorem identity15599 : scanCanonicalize (H12AffineFastState.compose env15599 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound15599 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env15600 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,4405,1076,263,5393,2340,1025,1077,4113,1044,17,1079,1336,17,2049,5392,5173,2341,1284,32,257,1045,5377,1589]

theorem envBound15600 : H12AffineFastState.Bounded env15600 := by
  intro p hp
  have h : env15600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15599_15600 : H12AffineEnvironment.transform 12 1336 env15599 = env15600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env15599 == env15600) = true)

theorem identity15600 : scanCanonicalize (H12AffineFastState.compose env15600 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound15600 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15601 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,0,1336,309,1076,263,1297,2340,1025,1077,17,1044,17,1079,1336,17,2049,1296,1077,2341,1284,32,257,1045,1281,1589]

theorem envBound15601 : H12AffineFastState.Bounded env15601 := by
  intro p hp
  have h : env15601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15600_15601 : H12AffineEnvironment.transform 11 0 env15600 = env15601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env15600 == env15601) = true)

theorem identity15601 : scanCanonicalize (H12AffineFastState.compose env15601 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15601 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15602 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,0,301,309,33,263,260,2340,20,32,17,1,17,34,301,17,2049,261,32,2341,273,32,257,0,276,544]

theorem envBound15602 : H12AffineFastState.Bounded env15602 := by
  intro p hp
  have h : env15602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15601_15602 : H12AffineEnvironment.transform 9 21 env15601 = env15602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15601 == env15602) = true)

theorem identity15602 : scanCanonicalize (H12AffineFastState.compose env15602 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15602 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env15603 : List Nat := [2,4,8,16,17,17,8,256,512,21,2048,0,284,260,16,263,260,2325,20,17,17,1,17,19,284,17,2049,261,17,2324,273,17,257,0,276,529]

theorem envBound15603 : H12AffineFastState.Bounded env15603 := by
  intro p hp
  have h : env15603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15602_15603 : H12AffineEnvironment.transform 4 17 env15602 = env15603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15602 == env15603) = true)

theorem identity15603 : scanCanonicalize (H12AffineFastState.compose env15603 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15603 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15604 : List Nat := [2,4,8,0,1,1,8,256,512,5,2048,0,268,260,0,263,260,2309,4,1,1,1,1,3,268,1,2049,261,1,2308,257,1,257,0,260,513]

theorem envBound15604 : H12AffineFastState.Bounded env15604 := by
  intro p hp
  have h : env15604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15603_15604 : H12AffineEnvironment.transform 3 0 env15603 = env15604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15603 == env15604) = true)

theorem identity15604 : scanCanonicalize (H12AffineFastState.compose env15604 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound15604 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15605 : List Nat := [2,4,8,0,1,1,8,256,261,5,2048,0,268,260,0,263,260,2309,4,1,1,1,1,3,268,1,2049,261,1,2308,257,1,257,0,260,260]

theorem envBound15605 : H12AffineFastState.Bounded env15605 := by
  intro p hp
  have h : env15605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15604_15605 : H12AffineEnvironment.transform 8 261 env15604 = env15605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env15604 == env15605) = true)

theorem identity15605 : scanCanonicalize (H12AffineFastState.compose env15605 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15605 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15606 : List Nat := [2,4,8,0,1,1,8,256,261,5,1,0,268,260,0,263,260,260,4,1,1,1,1,3,268,1,0,261,1,261,257,1,257,0,260,260]

theorem envBound15606 : H12AffineFastState.Bounded env15606 := by
  intro p hp
  have h : env15606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15605_15606 : H12AffineEnvironment.transform 10 1 env15605 = env15606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15605 == env15606) = true)

theorem identity15606 : scanCanonicalize (H12AffineFastState.compose env15606 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15606 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15607 : List Nat := [2,4,8,0,1,1,8,4,1,5,1,0,8,0,0,3,0,0,4,1,1,1,1,3,8,1,0,1,1,1,5,1,5,0,0,0]

theorem envBound15607 : H12AffineFastState.Bounded env15607 := by
  intro p hp
  have h : env15607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15606_15607 : H12AffineEnvironment.transform 7 4 env15606 = env15607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15606 == env15607) = true)

def env15608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21762,8193,64,97546,115014,17664,262145,119042,329731,257,98678,90202,63068]

theorem envBound15608 : H12AffineFastState.Bounded env15608 := by
  intro p hp
  have h : env15608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15593_15608 : H12AffineEnvironment.transform 6 9 env15593 = env15608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15593 == env15608) = true)

theorem identity15608 : scanCanonicalize (H12AffineFastState.compose env15608 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound15608 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32041,1025,32769,4160,21792,17,21762,8193,64,97546,115014,17664,32040,119042,95530,257,98678,90202,63068]

theorem envBound15609 : H12AffineFastState.Bounded env15609 := by
  intro p hp
  have h : env15609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15608_15609 : H12AffineEnvironment.transform 17 32041 env15608 = env15609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env15608 == env15609) = true)

theorem identity15609 : scanCanonicalize (H12AffineFastState.compose env15609 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound15609 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8575,49168,32041,1025,32769,4160,21792,17,21762,8193,64,23669,57401,17664,32040,61565,21589,257,40969,16677,63068]

theorem envBound15610 : H12AffineFastState.Bounded env15610 := by
  intro p hp
  have h : env15610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15609_15610 : H12AffineEnvironment.transform 15 8575 env15609 = env15610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env15609 == env15610) = true)

theorem identity15610 : scanCanonicalize (H12AffineFastState.compose env15610 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15610 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,35,49168,23669,1025,32769,4160,21792,17,21762,349,64,23669,49509,17664,23668,53537,21589,257,33109,16677,55040]

theorem envBound15611 : H12AffineFastState.Bounded env15611 := by
  intro p hp
  have h : env15611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15610_15611 : H12AffineEnvironment.transform 12 348 env15610 = env15611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15610 == env15611) = true)

theorem identity15611 : scanCanonicalize (H12AffineFastState.compose env15611 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound15611 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,35,5393,23669,1025,21760,4160,21792,17,21762,349,64,23669,5220,17664,23668,1056,21589,257,21588,16677,513]

theorem envBound15612 : H12AffineFastState.Bounded env15612 := by
  intro p hp
  have h : env15612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15611_15612 : H12AffineEnvironment.transform 14 21761 env15611 = env15612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env15611 == env15612) = true)

theorem identity15612 : scanCanonicalize (H12AffineFastState.compose env15612 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound15612 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1296,35,5393,3172,1025,1297,4160,1329,17,1299,349,64,3172,5220,5393,3173,1056,1092,257,1093,4404,513]

theorem envBound15613 : H12AffineFastState.Bounded env15613 := by
  intro p hp
  have h : env15613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15612_15613 : H12AffineEnvironment.transform 13 4113 env15612 = env15613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env15612 == env15613) = true)

theorem identity15613 : scanCanonicalize (H12AffineFastState.compose env15613 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15613 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15614 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,348,4113,372,35,4469,2048,101,373,4160,341,17,375,349,64,2048,4096,4469,2049,68,32,257,33,4404,513]

theorem envBound15614 : H12AffineFastState.Bounded env15614 := by
  intro p hp
  have h : env15614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15613_15614 : H12AffineEnvironment.transform 9 100 env15613 = env15614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15613 == env15614) = true)

theorem identity15614 : scanCanonicalize (H12AffineFastState.compose env15614 (packedSelected [0,1,3,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2657) := by decide +kernel

theorem selectedBound15614 : packedSelected [0,1,3,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15615 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2657,348,2672,372,35,2836,2048,101,373,2593,341,17,375,349,64,2048,2657,2836,2049,68,32,257,33,2901,513]

theorem envBound15615 : H12AffineFastState.Bounded env15615 := by
  intro p hp
  have h : env15615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15614_15615 : H12AffineEnvironment.transform 11 2657 env15614 = env15615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2657 env15614 == env15615) = true)

theorem identity15615 : scanCanonicalize (H12AffineFastState.compose env15615 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound15615 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15616 : List Nat := [2,4,8,16,32,64,9,256,512,100,545,64,348,81,372,35,309,545,101,373,0,341,17,375,349,64,545,64,309,544,68,32,257,33,372,513]

theorem envBound15616 : H12AffineFastState.Bounded env15616 := by
  intro p hp
  have h : env15616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15615_15616 : H12AffineEnvironment.transform 10 545 env15615 = env15616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env15615 == env15616) = true)

theorem identity15616 : scanCanonicalize (H12AffineFastState.compose env15616 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound15616 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15617 : List Nat := [2,4,8,16,32,64,9,256,340,100,373,64,348,81,372,35,309,373,101,373,0,341,17,375,349,64,373,64,309,372,68,32,257,33,372,341]

theorem envBound15617 : H12AffineFastState.Bounded env15617 := by
  intro p hp
  have h : env15617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15616_15617 : H12AffineEnvironment.transform 8 340 env15616 = env15617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env15616 == env15617) = true)

def env15618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,169234,8328,64,245138,115151,17664,262145,119042,329730,257,213487,237642,63189]

theorem envBound15618 : H12AffineFastState.Bounded env15618 := by
  intro p hp
  have h : env15618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15591_15618 : H12AffineEnvironment.transform 21 272513 env15591 = env15618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15591 == env15618) = true)

def env15619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180225,169234,8192,64,245018,115015,17664,262145,119042,329730,257,213351,237642,63069]

theorem envBound15619 : H12AffineFastState.Bounded env15619 := by
  intro p hp
  have h : env15619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15618_15619 : H12AffineEnvironment.transform 6 8 env15618 = env15619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15618 == env15619) = true)

def env15620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21762,8192,64,97546,115015,17664,262145,119042,329730,257,98679,90202,63069]

theorem envBound15620 : H12AffineFastState.Bounded env15620 := by
  intro p hp
  have h : env15620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15619_15620 : H12AffineEnvironment.transform 16 49168 env15619 = env15620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15619 == env15620) = true)

theorem identity15620 : scanCanonicalize (H12AffineFastState.compose env15620 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound15620 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56436,1025,32769,4160,62589,17,21762,8192,64,97546,115015,17664,56437,119042,119926,257,98679,90202,63069]

theorem envBound15621 : H12AffineFastState.Bounded env15621 := by
  intro p hp
  have h : env15621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15620_15621 : H12AffineEnvironment.transform 17 56436 env15620 = env15621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env15620 == env15621) = true)

theorem identity15621 : scanCanonicalize (H12AffineFastState.compose env15621 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15621 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,65536,49168,56436,1025,32769,4160,54641,17,21762,268,64,89094,115015,17664,56437,119042,119926,257,98679,82262,55121]

theorem envBound15622 : H12AffineFastState.Bounded env15622 := by
  intro p hp
  have h : env15622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15621_15622 : H12AffineEnvironment.transform 12 268 env15621 = env15622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15621 == env15622) = true)

theorem identity15622 : scanCanonicalize (H12AffineFastState.compose env15622 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15622 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env15623 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,49168,56356,1025,32769,4112,54561,17,21762,268,16,89094,114967,17664,56357,119042,119846,257,98599,82182,55041]

theorem envBound15623 : H12AffineFastState.Bounded env15623 := by
  intro p hp
  have h : env15623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15622_15623 : H12AffineEnvironment.transform 5 16 env15622 = env15623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15622 == env15623) = true)

theorem identity15623 : scanCanonicalize (H12AffineFastState.compose env15623 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound15623 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15624 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,33031,49168,56356,1025,32769,4112,54561,17,21762,268,16,56577,16400,17664,56357,20485,21793,257,32,49153,55041]

theorem envBound15624 : H12AffineFastState.Bounded env15624 := by
  intro p hp
  have h : env15624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15623_15624 : H12AffineEnvironment.transform 15 33031 env15623 = env15624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env15623 == env15624) = true)

theorem identity15624 : scanCanonicalize (H12AffineFastState.compose env15624 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15624 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env15625 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16400,23588,1025,1,4112,21793,17,21762,268,16,23809,16400,17664,23589,20485,21793,257,32,16385,22273]

theorem envBound15625 : H12AffineFastState.Bounded env15625 := by
  intro p hp
  have h : env15625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15624_15625 : H12AffineEnvironment.transform 14 0 env15624 = env15625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15624 == env15625) = true)

theorem identity15625 : scanCanonicalize (H12AffineFastState.compose env15625 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound15625 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env15626 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,0,263,5172,2048,1025,1,4112,261,17,294,268,16,2341,5172,4388,2049,1057,261,257,32,5157,805]

theorem envBound15626 : H12AffineFastState.Bounded env15626 := by
  intro p hp
  have h : env15626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15625_15626 : H12AffineEnvironment.transform 13 5156 env15625 = env15626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env15625 == env15626) = true)

theorem identity15626 : scanCanonicalize (H12AffineFastState.compose env15626 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound15626 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15627 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,2048,0,263,2064,2048,1025,1,3124,261,17,294,268,16,2341,2064,3328,2049,1057,261,257,32,2049,805]

theorem envBound15627 : H12AffineFastState.Bounded env15627 := by
  intro p hp
  have h : env15627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15626_15627 : H12AffineEnvironment.transform 11 3108 env15626 = env15627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env15626 == env15627) = true)

theorem identity15627 : scanCanonicalize (H12AffineFastState.compose env15627 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15627 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env15628 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,41,2048,0,34,2064,2048,1025,1,3124,32,17,3,41,16,2048,2064,3109,2049,1057,32,36,32,2049,512]

theorem envBound15628 : H12AffineFastState.Bounded env15628 := by
  intro p hp
  have h : env15628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15627_15628 : H12AffineEnvironment.transform 7 37 env15627 = env15628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15627 == env15628) = true)

theorem identity15628 : scanCanonicalize (H12AffineFastState.compose env15628 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound15628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15629 : List Nat := [2,4,8,16,32,16,8,37,512,20,2048,2096,41,2048,0,34,2064,2048,21,1,2080,32,17,3,41,16,2048,2064,2097,2049,53,32,36,32,2049,512]

theorem envBound15629 : H12AffineFastState.Bounded env15629 := by
  intro p hp
  have h : env15629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15628_15629 : H12AffineEnvironment.transform 9 20 env15628 = env15629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env15628 == env15629) = true)

theorem identity15629 : scanCanonicalize (H12AffineFastState.compose env15629 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound15629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15630 : List Nat := [2,4,8,16,32,16,8,37,43,20,2048,2096,41,2048,0,34,2064,2048,21,1,2080,32,17,3,41,16,2048,2064,2097,2049,53,32,36,32,2049,43]

theorem envBound15630 : H12AffineFastState.Bounded env15630 := by
  intro p hp
  have h : env15630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15629_15630 : H12AffineEnvironment.transform 8 43 env15629 = env15630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env15629 == env15630) = true)

theorem identity15630 : scanCanonicalize (H12AffineFastState.compose env15630 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound15630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15631 : List Nat := [2,4,8,16,32,16,8,37,43,20,29,45,41,29,0,34,13,29,21,1,61,32,17,3,41,16,29,13,44,28,53,32,36,32,28,43]

theorem envBound15631 : H12AffineFastState.Bounded env15631 := by
  intro p hp
  have h : env15631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15630_15631 : H12AffineEnvironment.transform 10 29 env15630 = env15631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env15630 == env15631) = true)

theorem identity15631 : scanCanonicalize (H12AffineFastState.compose env15631 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound15631 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15632 : List Nat := [2,4,8,16,29,16,8,24,22,20,29,16,20,29,0,31,13,29,21,1,0,29,17,3,20,16,29,13,17,28,8,29,25,29,28,22]

theorem envBound15632 : H12AffineFastState.Bounded env15632 := by
  intro p hp
  have h : env15632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15631_15632 : H12AffineEnvironment.transform 4 29 env15631 = env15632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env15631 == env15632) = true)

theorem identity15632 : scanCanonicalize (H12AffineFastState.compose env15632 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound15632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15633 : List Nat := [2,4,8,8,5,8,8,0,14,12,5,8,12,5,0,7,13,5,13,1,0,5,9,3,12,8,5,13,9,4,8,5,1,5,4,14]

theorem envBound15633 : H12AffineFastState.Bounded env15633 := by
  intro p hp
  have h : env15633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15632_15633 : H12AffineEnvironment.transform 3 8 env15632 = env15633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env15632 == env15633) = true)

theorem identity15633 : scanCanonicalize (H12AffineFastState.compose env15633 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15633 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15634 : List Nat := [2,1,8,8,0,8,8,0,11,9,0,8,9,0,0,2,8,0,8,1,0,0,9,3,9,8,0,8,9,1,8,0,1,0,1,11]

theorem envBound15634 : H12AffineFastState.Bounded env15634 := by
  intro p hp
  have h : env15634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15633_15634 : H12AffineEnvironment.transform 1 1 env15633 = env15634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15633 == env15634) = true)

def env15635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,16,21763,8192,64,97547,115015,17664,262145,119042,329730,257,98678,90203,63069]

theorem envBound15635 : H12AffineFastState.Bounded env15635 := by
  intro p hp
  have h : env15635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15619_15635 : H12AffineEnvironment.transform 16 49169 env15619 = env15635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15619 == env15635) = true)

theorem identity15635 : scanCanonicalize (H12AffineFastState.compose env15635 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound15635 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,262144,1025,29789,4161,272393,16,21763,8192,64,97547,79131,17664,262145,75102,329730,257,95530,90203,513]

theorem envBound15636 : H12AffineFastState.Bounded env15636 := by
  intro p hp
  have h : env15636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15635_15636 : H12AffineEnvironment.transform 14 29788 env15635 = env15636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env15635 == env15636) = true)

theorem identity15636 : scanCanonicalize (H12AffineFastState.compose env15636 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound15636 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,13389,262144,1025,29789,4161,272393,16,21763,8192,64,10589,24909,17664,262145,28936,285780,257,8572,13325,513]

theorem envBound15637 : H12AffineFastState.Bounded env15637 := by
  intro p hp
  have h : env15637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15636_15637 : H12AffineEnvironment.transform 15 21590 env15636 = env15637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env15636 == env15637) = true)

theorem identity15637 : scanCanonicalize (H12AffineFastState.compose env15637 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15637 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,5392,262144,1025,21760,4161,264532,16,21763,349,64,2048,16400,17664,262145,20565,285780,257,33,5456,513]

theorem envBound15638 : H12AffineFastState.Bounded env15638 := by
  intro p hp
  have h : env15638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15637_15638 : H12AffineEnvironment.transform 12 349 env15637 = env15638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15637 == env15638) = true)

theorem identity15638 : scanCanonicalize (H12AffineFastState.compose env15638 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound15638 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,5392,2420,1025,21760,4161,32,16,21763,349,64,2048,16400,17664,2421,20565,21792,257,33,5456,513]

theorem envBound15639 : H12AffineFastState.Bounded env15639 := by
  intro p hp
  have h : env15639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15638_15639 : H12AffineEnvironment.transform 17 2420 env15638 = env15639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env15638 == env15639) = true)

theorem identity15639 : scanCanonicalize (H12AffineFastState.compose env15639 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15639 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1297,1094,5392,2420,1025,1296,4161,32,16,1299,349,64,2048,4096,5392,2421,69,1328,257,33,5456,513]

theorem envBound15640 : H12AffineFastState.Bounded env15640 := by
  intro p hp
  have h : env15640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15639_15640 : H12AffineEnvironment.transform 13 4112 env15639 = env15640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15639 == env15640) = true)

theorem identity15640 : scanCanonicalize (H12AffineFastState.compose env15640 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15640 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,349,4112,1297,1094,5392,1076,1025,1296,4161,32,16,1299,349,64,1344,4096,5392,1077,69,1328,257,33,5456,513]

theorem envBound15641 : H12AffineFastState.Bounded env15641 := by
  intro p hp
  have h : env15641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15640_15641 : H12AffineEnvironment.transform 10 1344 env15640 = env15641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env15640 == env15641) = true)

theorem identity15641 : scanCanonicalize (H12AffineFastState.compose env15641 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound15641 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15642 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,4096,349,4112,372,35,4469,81,100,373,4161,32,16,374,349,64,293,4096,4469,80,69,341,257,33,4405,513]

theorem envBound15642 : H12AffineFastState.Bounded env15642 := by
  intro p hp
  have h : env15642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15641_15642 : H12AffineEnvironment.transform 9 101 env15641 = env15642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env15641 == env15642) = true)

theorem identity15642 : scanCanonicalize (H12AffineFastState.compose env15642 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound15642 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15643 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,357,349,373,372,35,16,81,100,373,292,32,16,374,349,64,293,357,16,80,69,341,257,33,80,513]

theorem envBound15643 : H12AffineFastState.Bounded env15643 := by
  intro p hp
  have h : env15643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15642_15643 : H12AffineEnvironment.transform 11 357 env15642 = env15643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env15642 == env15643) = true)

theorem identity15643 : scanCanonicalize (H12AffineFastState.compose env15643 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15643 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15644 : List Nat := [2,4,8,16,32,64,8,116,512,101,81,17,41,1,0,35,16,81,100,1,80,32,16,2,41,64,81,17,16,80,69,33,117,33,80,513]

theorem envBound15644 : H12AffineFastState.Bounded env15644 := by
  intro p hp
  have h : env15644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15643_15644 : H12AffineEnvironment.transform 7 116 env15643 = env15644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15643 == env15644) = true)

theorem identity15644 : scanCanonicalize (H12AffineFastState.compose env15644 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound15644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15645 : List Nat := [2,4,8,16,32,32,8,20,512,5,49,17,41,1,0,35,16,49,4,1,48,32,16,2,41,32,49,17,16,48,37,33,21,33,48,513]

theorem envBound15645 : H12AffineFastState.Bounded env15645 := by
  intro p hp
  have h : env15645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15644_15645 : H12AffineEnvironment.transform 5 32 env15644 = env15645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env15644 == env15645) = true)

theorem identity15645 : scanCanonicalize (H12AffineFastState.compose env15645 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15645 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15646 : List Nat := [2,4,8,16,32,32,8,20,1,5,49,17,41,1,0,35,16,49,4,1,48,32,16,2,41,32,49,17,16,48,37,33,21,33,48,0]

theorem envBound15646 : H12AffineFastState.Bounded env15646 := by
  intro p hp
  have h : env15646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15645_15646 : H12AffineEnvironment.transform 8 1 env15645 = env15646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15645 == env15646) = true)

theorem identity15646 : scanCanonicalize (H12AffineFastState.compose env15646 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15646 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15647 : List Nat := [2,4,8,0,32,32,8,4,1,5,33,1,41,1,0,35,0,33,4,1,32,32,0,2,41,32,33,1,0,32,37,33,5,33,32,0]

theorem envBound15647 : H12AffineFastState.Bounded env15647 := by
  intro p hp
  have h : env15647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15646_15647 : H12AffineEnvironment.transform 3 0 env15646 = env15647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15646 == env15647) = true)

theorem identity15647 : scanCanonicalize (H12AffineFastState.compose env15647 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15647 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15648 : List Nat := [2,4,8,0,1,1,8,4,1,5,0,1,8,1,0,2,0,0,4,1,1,1,0,2,8,1,0,1,0,1,4,0,5,0,1,0]

theorem envBound15648 : H12AffineFastState.Bounded env15648 := by
  intro p hp
  have h : env15648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15647_15648 : H12AffineEnvironment.transform 4 1 env15647 = env15648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15647 == env15648) = true)

def env15649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180225,169234,8193,64,245019,115014,17664,262145,119042,329730,257,213350,237642,63068]

theorem envBound15649 : H12AffineFastState.Bounded env15649 := by
  intro p hp
  have h : env15649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15618_15649 : H12AffineEnvironment.transform 6 9 env15618 = env15649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15618 == env15649) = true)

def env15650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21762,8193,64,97547,115014,17664,262145,119042,329730,257,98678,90202,63068]

theorem envBound15650 : H12AffineFastState.Bounded env15650 := by
  intro p hp
  have h : env15650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15649_15650 : H12AffineEnvironment.transform 16 49168 env15649 = env15650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15649 == env15650) = true)

theorem identity15650 : scanCanonicalize (H12AffineFastState.compose env15650 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound15650 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32041,1025,32769,4160,21793,17,21762,8193,64,97547,115014,17664,32040,119042,95531,257,98678,90202,63068]

theorem envBound15651 : H12AffineFastState.Bounded env15651 := by
  intro p hp
  have h : env15651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15650_15651 : H12AffineEnvironment.transform 17 32041 env15650 = env15651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env15650 == env15651) = true)

theorem identity15651 : scanCanonicalize (H12AffineFastState.compose env15651 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound15651 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32882,49168,32041,1025,32769,4160,21793,17,21762,8193,64,64889,16692,17664,32040,20848,62809,257,260,57384,63068]

theorem envBound15652 : H12AffineFastState.Bounded env15652 := by
  intro p hp
  have h : env15652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15651_15652 : H12AffineEnvironment.transform 15 32882 env15651 = env15652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env15651 == env15652) = true)

theorem identity15652 : scanCanonicalize (H12AffineFastState.compose env15652 (packedSelected [4,9,14,19,20,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound15652 : packedSelected [4,9,14,19,20,26] rootPS < 2^1333 := by decide +kernel

def env15653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,21795,5441,32041,1025,21840,4160,21793,17,21762,8193,64,10280,16692,17664,32040,20848,8200,257,260,13689,8973]

theorem envBound15653 : H12AffineFastState.Bounded env15653 := by
  intro p hp
  have h : env15653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15652_15653 : H12AffineEnvironment.transform 14 21841 env15652 = env15653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env15652 == env15653) = true)

theorem identity15653 : scanCanonicalize (H12AffineFastState.compose env15653 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15653 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env15654 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,21795,5393,32041,1025,21760,4112,21793,17,21762,8193,16,10280,16692,17664,32040,20768,8200,257,260,13609,8973]

theorem envBound15654 : H12AffineFastState.Bounded env15654 := by
  intro p hp
  have h : env15654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15653_15654 : H12AffineEnvironment.transform 5 16 env15653 = env15654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15653 == env15654) = true)

theorem identity15654 : scanCanonicalize (H12AffineFastState.compose env15654 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound15654 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15655 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,8495,5393,2341,1025,8460,4112,8493,17,8462,8193,16,10280,13624,12556,2340,9516,8200,257,260,13609,8973]

theorem envBound15655 : H12AffineFastState.Bounded env15655 := by
  intro p hp
  have h : env15655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15654_15655 : H12AffineEnvironment.transform 13 13324 env15654 = env15655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env15654 == env15655) = true)

def env15656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,16,21763,8193,64,97546,115014,17664,262145,119042,329730,257,98679,90203,63068]

theorem envBound15656 : H12AffineFastState.Bounded env15656 := by
  intro p hp
  have h : env15656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15649_15656 : H12AffineEnvironment.transform 16 49169 env15649 = env15656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15649 == env15656) = true)

theorem identity15656 : scanCanonicalize (H12AffineFastState.compose env15656 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15656 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,262144,1025,32769,4161,272392,16,3,8193,64,75786,103494,4096,262145,99330,329730,257,98679,79195,41820]

theorem envBound15657 : H12AffineFastState.Bounded env15657 := by
  intro p hp
  have h : env15657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15656_15657 : H12AffineEnvironment.transform 13 5376 env15656 = env15657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15656 == env15657) = true)

theorem identity15657 : scanCanonicalize (H12AffineFastState.compose env15657 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound15657 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env15658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10360,1025,32769,4161,112,16,3,8193,64,75786,103494,4096,10361,99330,73850,257,98679,79195,41820]

theorem envBound15658 : H12AffineFastState.Bounded env15658 := by
  intro p hp
  have h : env15658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15657_15658 : H12AffineEnvironment.transform 17 10360 env15657 = env15658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env15657 == env15658) = true)

theorem identity15658 : scanCanonicalize (H12AffineFastState.compose env15658 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound15658 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env15659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,65536,38161,2049,1025,32769,4161,112,16,3,120,64,67699,103494,4096,2048,99330,65539,257,98679,70946,33573]

theorem envBound15659 : H12AffineFastState.Bounded env15659 := by
  intro p hp
  have h : env15659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15658_15659 : H12AffineEnvironment.transform 12 121 env15658 = env15659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env15658 == env15659) = true)

theorem identity15659 : scanCanonicalize (H12AffineFastState.compose env15659 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound15659 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,80,65536,5441,2049,1025,81,4161,112,16,3,120,64,67699,70678,4096,2048,66642,65539,257,65831,70946,885]

theorem envBound15660 : H12AffineFastState.Bounded env15660 := by
  intro p hp
  have h : env15660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15659_15660 : H12AffineEnvironment.transform 14 80 env15659 = env15660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env15659 == env15660) = true)

theorem identity15660 : scanCanonicalize (H12AffineFastState.compose env15660 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound15660 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,80,343,5441,2049,1025,81,4161,112,16,3,120,64,2340,5441,4096,2048,1285,340,257,112,5237,885]

theorem envBound15661 : H12AffineFastState.Bounded env15661 := by
  intro p hp
  have h : env15661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15660_15661 : H12AffineEnvironment.transform 15 343 env15660 = env15661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env15660 == env15661) = true)

def env15662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,169235,8328,64,4691218,115151,17665,262145,119043,4268163,257,213487,237642,63188]

theorem envBound15662 : H12AffineFastState.Bounded env15662 := by
  intro p hp
  have h : env15662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15590_15662 : H12AffineEnvironment.transform 20 184401 env15590 = env15662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env15590 == env15662) = true)

def env15663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,169235,8328,64,245138,115151,17665,262145,119043,329731,257,213487,237642,63188]

theorem envBound15663 : H12AffineFastState.Bounded env15663 := by
  intro p hp
  have h : env15663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15662_15663 : H12AffineEnvironment.transform 21 272512 env15662 = env15663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15662 == env15663) = true)

theorem identity15663 : scanCanonicalize (H12AffineFastState.compose env15663 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound15663 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58516,272512,62660,41430,8328,64,100695,115151,17665,262145,119043,329731,257,95530,103567,63188]

theorem envBound15664 : H12AffineFastState.Bounded env15664 := by
  intro p hp
  have h : env15664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15663_15664 : H12AffineEnvironment.transform 16 13509 env15663 = env15664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env15663 == env15664) = true)

def env15665 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58516,272512,62612,41350,8328,16,100615,115103,17665,262145,119043,329731,257,95530,103567,63108]

theorem envBound15665 : H12AffineFastState.Bounded env15665 := by
  intro p hp
  have h : env15665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15664_15665 : H12AffineEnvironment.transform 5 16 env15664 = env15665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15664 == env15665) = true)

theorem identity15665 : scanCanonicalize (H12AffineFastState.compose env15665 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound15665 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env15666 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,100523,1025,32769,58516,106539,62612,41350,8328,16,100615,115103,17665,100522,119043,32936,257,95530,103567,63108]

theorem envBound15666 : H12AffineFastState.Bounded env15666 := by
  intro p hp
  have h : env15666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15665_15666 : H12AffineEnvironment.transform 17 100523 env15665 = env15666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env15665 == env15666) = true)

theorem identity15666 : scanCanonicalize (H12AffineFastState.compose env15666 (packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound15666 : packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env15667 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,13461,76198,1025,8460,17817,65830,21913,139,8328,16,75786,90258,17665,76199,94222,8613,257,95530,79234,22409]

theorem envBound15667 : H12AffineFastState.Bounded env15667 := by
  intro p hp
  have h : env15667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15666_15667 : H12AffineEnvironment.transform 14 8461 env15666 = env15667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env15666 == env15667) = true)

theorem identity15667 : scanCanonicalize (H12AffineFastState.compose env15667 (packedSelected [17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15667 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env15668 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,262,13461,10400,1025,8460,17817,32,21913,139,8328,16,10508,24980,17665,10401,28936,8613,257,29740,13444,22409]

theorem envBound15668 : H12AffineFastState.Bounded env15668 := by
  intro p hp
  have h : env15668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15667_15668 : H12AffineEnvironment.transform 15 262 env15667 = env15668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15667 == env15668) = true)

theorem identity15668 : scanCanonicalize (H12AffineFastState.compose env15668 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound15668 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15669 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,262,13461,10400,1025,8460,4113,32,17,139,8328,16,10508,13340,4233,10401,9344,8613,257,8612,13444,513]

theorem envBound15669 : H12AffineFastState.Bounded env15669 := by
  intro p hp
  have h : env15669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15668_15669 : H12AffineEnvironment.transform 13 5512 env15668 = env15669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env15668 == env15669) = true)

theorem identity15669 : scanCanonicalize (H12AffineFastState.compose env15669 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15669 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,262,13340,10281,1025,8460,4113,32,17,2,8193,16,10508,13340,4096,10280,9225,8492,257,8493,13325,513]

theorem envBound15670 : H12AffineFastState.Bounded env15670 := by
  intro p hp
  have h : env15670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15669_15670 : H12AffineEnvironment.transform 6 9 env15669 = env15670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15669 == env15670) = true)

theorem identity15670 : scanCanonicalize (H12AffineFastState.compose env15670 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15670 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4113,32,17,2,268,16,2049,5393,4096,2341,1284,33,257,32,5376,513]

theorem envBound15671 : H12AffineFastState.Bounded env15671 := by
  intro p hp
  have h : env15671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15670_15671 : H12AffineEnvironment.transform 12 269 env15670 = env15671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15670 == env15671) = true)

theorem identity15671 : scanCanonicalize (H12AffineFastState.compose env15671 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound15671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15672 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,33,269,1312,0,262,1328,2340,1025,1,48,32,17,2,268,16,2049,1328,33,2341,1284,33,257,32,1313,513]

theorem envBound15672 : H12AffineFastState.Bounded env15672 := by
  intro p hp
  have h : env15672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15671_15672 : H12AffineEnvironment.transform 11 33 env15671 = env15672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env15671 == env15672) = true)

theorem identity15672 : scanCanonicalize (H12AffineFastState.compose env15672 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15672 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15673 : List Nat := [2,4,8,16,32,16,9,256,292,1024,2048,33,269,1312,0,262,1328,2340,1025,1,48,32,17,2,268,16,2049,1328,33,2341,1284,33,257,32,1313,293]

theorem envBound15673 : H12AffineFastState.Bounded env15673 := by
  intro p hp
  have h : env15673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15672_15673 : H12AffineEnvironment.transform 8 292 env15672 = env15673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15672 == env15673) = true)

theorem identity15673 : scanCanonicalize (H12AffineFastState.compose env15673 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound15673 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15674 : List Nat := [2,4,8,16,32,16,9,256,292,1024,277,33,269,1312,0,262,1328,49,1025,1,48,32,17,2,268,16,276,1328,33,48,1284,33,257,32,1313,293]

theorem envBound15674 : H12AffineFastState.Bounded env15674 := by
  intro p hp
  have h : env15674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15673_15674 : H12AffineEnvironment.transform 10 277 env15673 = env15674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env15673 == env15674) = true)

theorem identity15674 : scanCanonicalize (H12AffineFastState.compose env15674 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15674 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15675 : List Nat := [2,4,8,16,32,16,9,5,33,1024,16,33,8,1061,0,3,1077,49,1025,1,48,32,17,2,9,16,17,1077,33,48,1025,33,4,32,1060,32]

theorem envBound15675 : H12AffineFastState.Bounded env15675 := by
  intro p hp
  have h : env15675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15674_15675 : H12AffineEnvironment.transform 7 5 env15674 = env15675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15674 == env15675) = true)

theorem identity15675 : scanCanonicalize (H12AffineFastState.compose env15675 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15675 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15676 : List Nat := [2,4,8,16,1,16,9,5,0,1024,16,0,8,1028,0,3,1044,16,1025,1,17,1,17,2,9,16,17,1044,0,17,1025,0,4,1,1029,1]

theorem envBound15676 : H12AffineFastState.Bounded env15676 := by
  intro p hp
  have h : env15676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15675_15676 : H12AffineEnvironment.transform 4 1 env15675 = env15676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15675 == env15676) = true)

def env15677 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58516,272512,62613,41351,8328,17,100614,115102,17665,262145,119043,329731,257,95530,103567,63109]

theorem envBound15677 : H12AffineFastState.Bounded env15677 := by
  intro p hp
  have h : env15677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15664_15677 : H12AffineEnvironment.transform 5 17 env15664 = env15677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15664 == env15677) = true)

theorem identity15677 : scanCanonicalize (H12AffineFastState.compose env15677 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound15677 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env15678 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,23725,1025,32769,58516,29741,62613,41351,8328,17,100614,115102,17665,23724,119043,87214,257,95530,103567,63109]

theorem envBound15678 : H12AffineFastState.Bounded env15678 := by
  intro p hp
  have h : env15678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15677_15678 : H12AffineEnvironment.transform 17 23725 env15677 = env15678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env15677 == env15678) = true)

theorem identity15678 : scanCanonicalize (H12AffineFastState.compose env15678 (packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound15678 : packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS < 2^1333 := by decide +kernel

def env15679 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13460,23725,1025,32769,58516,29741,62613,41351,8328,17,23944,5392,17665,23724,1421,32800,257,41380,16385,63109]

theorem envBound15679 : H12AffineFastState.Bounded env15679 := by
  intro p hp
  have h : env15679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15678_15679 : H12AffineEnvironment.transform 15 54414 env15678 = env15679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env15678 == env15679) = true)

theorem identity15679 : scanCanonicalize (H12AffineFastState.compose env15679 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound15679 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env15680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,21510,13460,23725,1025,137,25628,29741,29725,8463,8328,17,23944,5392,17665,23724,1421,168,257,8492,16385,30221]

theorem envBound15680 : H12AffineFastState.Bounded env15680 := by
  intro p hp
  have h : env15680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15679_15680 : H12AffineEnvironment.transform 14 136 env15679 = env15680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env15679 == env15680) = true)

theorem identity15680 : scanCanonicalize (H12AffineFastState.compose env15680 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound15680 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env15681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,8192,16384,136,18831,10525,16676,1025,137,25628,27044,27028,8463,8328,17,16385,2201,17665,16677,1421,168,257,8492,16385,27524]

theorem envBound15681 : H12AffineFastState.Bounded env15681 := by
  intro p hp
  have h : env15681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15680_15681 : H12AffineEnvironment.transform 11 3465 env15680 = env15681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env15680 == env15681) = true)

theorem identity15681 : scanCanonicalize (H12AffineFastState.compose env15681 (packedSelected [2,4,6,9,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound15681 : packedSelected [2,4,6,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env15682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,3384,16384,136,18831,1061,16676,1025,137,18724,17564,17580,3127,3504,17,16385,2201,17665,16677,1421,168,257,3092,16385,18108]

theorem envBound15682 : H12AffineFastState.Bounded env15682 := by
  intro p hp
  have h : env15682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15681_15682 : H12AffineEnvironment.transform 12 3384 env15681 = env15682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env15681 == env15682) = true)

theorem identity15682 : scanCanonicalize (H12AffineFastState.compose env15682 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound15682 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env15683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,3384,2340,136,171,1061,2048,1025,137,0,3512,3464,3127,3504,17,2341,2201,3109,2049,1421,168,257,3092,2341,3992]

theorem envBound15683 : H12AffineFastState.Bounded env15683 := by
  intro p hp
  have h : env15683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15682_15683 : H12AffineEnvironment.transform 13 2340 env15682 = env15683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env15682 == env15683) = true)

theorem identity15683 : scanCanonicalize (H12AffineFastState.compose env15683 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15683 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15684 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3108,3221,2185,136,171,1061,2048,1025,137,0,3093,3109,3127,3101,17,2184,2201,3109,2049,1056,168,172,3092,2184,3637]

theorem envBound15684 : H12AffineFastState.Bounded env15684 := by
  intro p hp
  have h : env15684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15683_15684 : H12AffineEnvironment.transform 7 173 env15683 = env15684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15683 == env15684) = true)

theorem identity15684 : scanCanonicalize (H12AffineFastState.compose env15684 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound15684 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env15685 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,153,40,1076,136,171,1061,1213,1025,137,0,168,152,138,160,17,1077,1060,152,1212,1056,168,172,169,1077,648]

theorem envBound15685 : H12AffineFastState.Bounded env15685 := by
  intro p hp
  have h : env15685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15684_15685 : H12AffineEnvironment.transform 10 1213 env15684 = env15685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env15684 == env15685) = true)

theorem identity15685 : scanCanonicalize (H12AffineFastState.compose env15685 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15685 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env15686 : List Nat := [2,4,8,16,32,17,128,173,512,52,137,153,40,0,136,171,17,137,53,137,0,168,152,138,160,17,1,16,152,136,20,168,172,169,1,648]

theorem envBound15686 : H12AffineFastState.Bounded env15686 := by
  intro p hp
  have h : env15686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15685_15686 : H12AffineEnvironment.transform 9 52 env15685 = env15686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15685 == env15686) = true)

def env15687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,169235,8328,64,245139,115151,17665,262145,119043,329730,257,213487,237642,63188]

theorem envBound15687 : H12AffineFastState.Bounded env15687 := by
  intro p hp
  have h : env15687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15662_15687 : H12AffineEnvironment.transform 21 272513 env15662 = env15687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15662 == env15687) = true)

theorem identity15687 : scanCanonicalize (H12AffineFastState.compose env15687 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15687 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140420,272513,144596,156102,8328,64,215366,79130,17665,262145,75222,329730,257,213487,218271,513]

theorem envBound15688 : H12AffineFastState.Bounded env15688 := by
  intro p hp
  have h : env15688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15687_15688 : H12AffineEnvironment.transform 14 29909 env15687 = env15688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15687 == env15688) = true)

def env15689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272393,144476,155982,8192,64,215366,79130,17665,262145,75102,329730,257,213351,218135,513]

theorem envBound15689 : H12AffineFastState.Bounded env15689 := by
  intro p hp
  have h : env15689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15688_15689 : H12AffineEnvironment.transform 6 8 env15688 = env15689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15688 == env15689) = true)

def env15690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,140300,33,144476,155982,8192,64,215366,79130,17665,10281,75102,73770,257,213351,218135,513]

theorem envBound15690 : H12AffineFastState.Bounded env15690 := by
  intro p hp
  have h : env15690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15689_15690 : H12AffineEnvironment.transform 17 10280 env15689 = env15690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15689 == env15690) = true)

theorem identity15690 : scanCanonicalize (H12AffineFastState.compose env15690 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15690 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env15691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1025,8541,140300,33,144476,144463,8192,64,203847,79130,4096,10281,75102,73770,257,201830,196886,513]

theorem envBound15691 : H12AffineFastState.Bounded env15691 := by
  intro p hp
  have h : env15691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15690_15691 : H12AffineEnvironment.transform 13 5377 env15690 = env15691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15690 == env15691) = true)

theorem identity15691 : scanCanonicalize (H12AffineFastState.compose env15691 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15691 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,5393,10280,1025,8541,12573,33,8525,8542,8192,64,67926,79130,4096,10281,75102,73770,257,65911,70663,513]

theorem envBound15692 : H12AffineFastState.Bounded env15692 := by
  intro p hp
  have h : env15692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15691_15692 : H12AffineEnvironment.transform 16 5393 env15691 = env15692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15691 == env15692) = true)

theorem identity15692 : scanCanonicalize (H12AffineFastState.compose env15692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,5393,2420,1025,1,4161,33,17,2,348,64,67926,70726,4096,2421,66562,65910,257,65911,70663,513]

theorem envBound15693 : H12AffineFastState.Bounded env15693 := by
  intro p hp
  have h : env15693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15692_15693 : H12AffineEnvironment.transform 12 348 env15692 = env15693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15692 == env15693) = true)

theorem identity15693 : scanCanonicalize (H12AffineFastState.compose env15693 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound15693 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5393,2420,1025,1,4161,33,17,2,348,64,2049,5393,4096,2421,1365,33,257,32,5456,513]

theorem envBound15694 : H12AffineFastState.Bounded env15694 := by
  intro p hp
  have h : env15694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15693_15694 : H12AffineEnvironment.transform 15 343 env15693 = env15694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env15693 == env15694) = true)

theorem identity15694 : scanCanonicalize (H12AffineFastState.compose env15694 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound15694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15695 : List Nat := [2,4,8,16,32,64,8,256,512,565,2048,4096,348,4916,0,343,4900,2420,564,1,4161,33,17,2,348,64,2049,4900,4096,2421,864,33,257,32,4965,513]

theorem envBound15695 : H12AffineFastState.Bounded env15695 := by
  intro p hp
  have h : env15695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15694_15695 : H12AffineEnvironment.transform 9 565 env15694 = env15695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env15694 == env15695) = true)

theorem identity15695 : scanCanonicalize (H12AffineFastState.compose env15695 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15695 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15696 : List Nat := [2,4,8,16,32,16,8,256,512,565,2048,4096,268,4916,0,263,4900,2340,564,1,4113,33,17,2,268,16,2049,4900,4096,2341,816,33,257,32,4917,513]

theorem envBound15696 : H12AffineFastState.Bounded env15696 := by
  intro p hp
  have h : env15696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15695_15696 : H12AffineEnvironment.transform 5 16 env15695 = env15696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15695 == env15696) = true)

theorem identity15696 : scanCanonicalize (H12AffineFastState.compose env15696 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound15696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15697 : List Nat := [2,4,8,16,32,16,8,256,512,565,2048,512,268,308,0,263,292,2340,564,1,529,33,17,2,268,16,2049,292,512,2341,816,33,257,32,309,513]

theorem envBound15697 : H12AffineFastState.Bounded env15697 := by
  intro p hp
  have h : env15697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15696_15697 : H12AffineEnvironment.transform 11 512 env15696 = env15697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env15696 == env15697) = true)

theorem identity15697 : scanCanonicalize (H12AffineFastState.compose env15697 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound15697 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15698 : List Nat := [2,4,8,16,32,16,8,256,512,565,820,512,268,308,0,263,292,528,564,1,529,33,17,2,268,16,821,292,512,529,816,33,257,32,309,513]

theorem envBound15698 : H12AffineFastState.Bounded env15698 := by
  intro p hp
  have h : env15698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15697_15698 : H12AffineEnvironment.transform 10 820 env15697 = env15698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env15697 == env15698) = true)

theorem identity15698 : scanCanonicalize (H12AffineFastState.compose env15698 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15698 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15699 : List Nat := [2,4,8,16,32,16,8,256,292,273,16,292,268,308,0,263,292,308,272,1,309,33,17,2,268,16,17,292,292,309,20,33,257,32,309,293]

theorem envBound15699 : H12AffineFastState.Bounded env15699 := by
  intro p hp
  have h : env15699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15698_15699 : H12AffineEnvironment.transform 8 292 env15698 = env15699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15698 == env15699) = true)

theorem identity15699 : scanCanonicalize (H12AffineFastState.compose env15699 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15699 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15700 : List Nat := [2,4,8,16,17,16,8,256,277,273,16,277,268,261,0,263,277,261,272,1,260,16,17,2,268,16,17,277,277,260,20,16,257,17,260,276]

theorem envBound15700 : H12AffineFastState.Bounded env15700 := by
  intro p hp
  have h : env15700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15699_15700 : H12AffineEnvironment.transform 4 17 env15699 = env15700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15699 == env15700) = true)

theorem identity15700 : scanCanonicalize (H12AffineFastState.compose env15700 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound15700 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15701 : List Nat := [2,4,8,16,17,16,8,20,1,5,16,1,24,17,0,19,1,17,4,1,16,16,17,2,24,16,17,1,1,16,20,16,21,17,16,0]

theorem envBound15701 : H12AffineFastState.Bounded env15701 := by
  intro p hp
  have h : env15701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15700_15701 : H12AffineEnvironment.transform 7 20 env15700 = env15701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env15700 == env15701) = true)

def env15702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,140300,32,144476,155982,8192,64,215366,79130,17665,10280,75102,73771,257,213351,218135,513]

theorem envBound15702 : H12AffineFastState.Bounded env15702 := by
  intro p hp
  have h : env15702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15689_15702 : H12AffineEnvironment.transform 17 10281 env15689 = env15702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15689 == env15702) = true)

theorem identity15702 : scanCanonicalize (H12AffineFastState.compose env15702 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15702 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1025,29788,4160,32,16,21762,8192,64,97546,79130,17665,10280,75102,73771,257,95531,90203,513]

theorem envBound15703 : H12AffineFastState.Bounded env15703 := by
  intro p hp
  have h : env15703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15702_15703 : H12AffineEnvironment.transform 16 13388 env15702 = env15703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15702 == env15703) = true)

theorem identity15703 : scanCanonicalize (H12AffineFastState.compose env15703 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15372) := by decide +kernel

theorem selectedBound15703 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env15704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15372,2129,65536,13388,10281,1025,2128,4160,32,16,10510,8192,64,65798,79130,14605,10280,75102,73771,257,67879,72791,513]

theorem envBound15704 : H12AffineFastState.Bounded env15704 := by
  intro p hp
  have h : env15704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15703_15704 : H12AffineEnvironment.transform 13 15372 env15703 = env15704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15372 env15703 == env15704) = true)

theorem identity15704 : scanCanonicalize (H12AffineFastState.compose env15704 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 10331) := by decide +kernel

theorem selectedBound15704 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15372,2129,10331,13388,10281,1025,2128,4160,32,16,10510,8192,64,10589,7489,14605,10280,3333,2160,257,8572,13324,513]

theorem envBound15705 : H12AffineFastState.Bounded env15705 := by
  intro p hp
  have h : env15705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15704_15705 : H12AffineEnvironment.transform 15 10331 env15704 = env15705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10331 env15704 == env15705) = true)

theorem identity15705 : scanCanonicalize (H12AffineFastState.compose env15705 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound15705 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env15706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4429,3393,2129,6422,1281,6500,1025,2128,4160,32,16,6211,4429,64,6160,7489,2112,6501,3333,2160,257,4145,1345,513]

theorem envBound15706 : H12AffineFastState.Bounded env15706 := by
  intro p hp
  have h : env15706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15705_15706 : H12AffineEnvironment.transform 12 4429 env15705 = env15706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env15705 == env15706) = true)

theorem identity15706 : scanCanonicalize (H12AffineFastState.compose env15706 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15706 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,4429,0,1296,5207,1281,5157,1025,1297,4160,32,16,5378,4429,64,5457,4096,1281,5156,68,1329,257,4145,1345,513]

theorem envBound15707 : H12AffineFastState.Bounded env15707 := by
  intro p hp
  have h : env15707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15706_15707 : H12AffineEnvironment.transform 10 1345 env15706 = env15707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env15706 == env15707) = true)

theorem identity15707 : scanCanonicalize (H12AffineFastState.compose env15707 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound15707 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,356,41,0,1296,1331,1281,1345,1025,1297,292,32,16,1126,41,64,1077,356,1281,1344,68,1329,257,341,1345,513]

theorem envBound15708 : H12AffineFastState.Bounded env15708 := by
  intro p hp
  have h : env15708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15707_15708 : H12AffineEnvironment.transform 11 356 env15707 = env15708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env15707 == env15708) = true)

theorem identity15708 : scanCanonicalize (H12AffineFastState.compose env15708 (packedSelected [0,2,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15708 : packedSelected [0,2,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env15709 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,356,41,0,372,343,357,293,101,373,292,32,16,2,41,64,81,356,357,292,68,341,257,341,293,513]

theorem envBound15709 : H12AffineFastState.Bounded env15709 := by
  intro p hp
  have h : env15709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15708_15709 : H12AffineEnvironment.transform 9 100 env15708 = env15709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15708 == env15709) = true)

theorem identity15709 : scanCanonicalize (H12AffineFastState.compose env15709 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound15709 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env15710 : List Nat := [2,4,8,16,32,64,8,20,512,100,49,112,41,0,96,67,113,49,101,97,48,32,16,2,41,64,81,112,113,48,68,65,21,65,49,513]

theorem envBound15710 : H12AffineFastState.Bounded env15710 := by
  intro p hp
  have h : env15710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15709_15710 : H12AffineEnvironment.transform 7 20 env15709 = env15710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env15709 == env15710) = true)

theorem identity15710 : scanCanonicalize (H12AffineFastState.compose env15710 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound15710 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env15711 : List Nat := [2,4,8,16,32,32,8,20,512,4,49,16,41,0,0,35,17,49,5,1,48,32,16,2,41,32,49,16,17,48,36,33,21,33,49,513]

theorem envBound15711 : H12AffineFastState.Bounded env15711 := by
  intro p hp
  have h : env15711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15710_15711 : H12AffineEnvironment.transform 5 32 env15710 = env15711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env15710 == env15711) = true)

theorem identity15711 : scanCanonicalize (H12AffineFastState.compose env15711 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15712 : List Nat := [2,4,8,1,32,32,8,5,512,4,32,1,41,0,0,35,0,32,5,1,33,32,1,2,41,32,32,1,0,33,36,33,4,33,32,513]

theorem envBound15712 : H12AffineFastState.Bounded env15712 := by
  intro p hp
  have h : env15712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15711_15712 : H12AffineEnvironment.transform 3 1 env15711 = env15712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15711 == env15712) = true)

theorem identity15712 : scanCanonicalize (H12AffineFastState.compose env15712 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound15712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15713 : List Nat := [2,4,8,1,32,32,8,5,32,4,32,1,41,0,0,35,0,32,5,1,33,32,1,2,41,32,32,1,0,33,36,33,4,33,32,33]

theorem envBound15713 : H12AffineFastState.Bounded env15713 := by
  intro p hp
  have h : env15713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15712_15713 : H12AffineEnvironment.transform 8 32 env15712 = env15713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15712 == env15713) = true)

theorem identity15713 : scanCanonicalize (H12AffineFastState.compose env15713 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15714 : List Nat := [2,4,8,1,1,1,8,5,1,4,1,1,8,0,0,2,0,1,5,1,0,1,1,2,8,1,1,1,0,0,5,0,4,0,1,0]

theorem envBound15714 : H12AffineFastState.Bounded env15714 := by
  intro p hp
  have h : env15714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15713_15714 : H12AffineEnvironment.transform 4 1 env15713 = env15714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15713 == env15714) = true)

def env15715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272392,144477,155983,8193,64,215366,79130,17665,262145,75103,329730,257,213350,218134,513]

theorem envBound15715 : H12AffineFastState.Bounded env15715 := by
  intro p hp
  have h : env15715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15688_15715 : H12AffineEnvironment.transform 6 9 env15688 = env15715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15688 == env15715) = true)

theorem identity15715 : scanCanonicalize (H12AffineFastState.compose env15715 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound15715 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,82966,272392,87110,65876,8193,64,10589,79130,17665,262145,75103,329730,257,8573,13325,513]

theorem envBound15716 : H12AffineFastState.Bounded env15716 := by
  intro p hp
  have h : env15716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15715_15716 : H12AffineEnvironment.transform 16 90139 env15715 = env15716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env15715 == env15716) = true)

theorem identity15716 : scanCanonicalize (H12AffineFastState.compose env15716 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound15716 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env15717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21511,13340,262144,1025,29789,4113,272392,65,21843,8193,64,10589,24861,17665,262145,29016,285701,257,8573,13325,513]

theorem envBound15717 : H12AffineFastState.Bounded env15717 := by
  intro p hp
  have h : env15717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15716_15717 : H12AffineEnvironment.transform 15 21511 env15716 = env15717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env15716 == env15717) = true)

theorem identity15717 : scanCanonicalize (H12AffineFastState.compose env15717 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 22593) := by decide +kernel

theorem selectedBound15717 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env15718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21511,13340,22593,1025,29789,4113,28745,65,21843,8193,64,10589,24861,17665,22592,29016,1092,257,8573,13325,513]

theorem envBound15718 : H12AffineFastState.Bounded env15718 := by
  intro p hp
  have h : env15718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15717_15718 : H12AffineEnvironment.transform 17 22593 env15717 = env15718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22593 env15717 == env15718) = true)

theorem identity15718 : scanCanonicalize (H12AffineFastState.compose env15718 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound15718 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,1076,9327,13340,10281,1025,1077,4113,33,65,9531,8193,64,10589,4469,13673,10280,304,1092,257,8573,13325,513]

theorem envBound15719 : H12AffineFastState.Bounded env15719 := by
  intro p hp
  have h : env15719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15718_15719 : H12AffineEnvironment.transform 13 12392 env15718 = env15719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env15718 == env15719) = true)

theorem identity15719 : scanCanonicalize (H12AffineFastState.compose env15719 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound15719 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,8192,11625,1076,9327,10525,10281,1025,1077,3344,33,65,9531,8193,64,10589,3188,10344,10280,304,1092,257,8573,10508,513]

theorem envBound15720 : H12AffineFastState.Bounded env15720 := by
  intro p hp
  have h : env15720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15719_15720 : H12AffineEnvironment.transform 11 3329 env15719 = env15720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env15719 == env15720) = true)

theorem identity15720 : scanCanonicalize (H12AffineFastState.compose env15720 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15720 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,269,3172,1076,1378,2064,2340,1025,1077,3344,33,65,1078,268,64,2128,3188,2405,2341,304,1092,257,112,2049,513]

theorem envBound15721 : H12AffineFastState.Bounded env15721 := by
  intro p hp
  have h : env15721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15720_15721 : H12AffineEnvironment.transform 12 269 env15720 = env15721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15720 == env15721) = true)

theorem identity15721 : scanCanonicalize (H12AffineFastState.compose env15721 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15721 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15722 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3188,120,3172,1076,1047,2064,2129,1025,1077,3173,33,65,1078,121,64,2128,3188,2064,2128,69,1092,116,112,2049,513]

theorem envBound15722 : H12AffineFastState.Bounded env15722 := by
  intro p hp
  have h : env15722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15721_15722 : H12AffineEnvironment.transform 7 117 env15721 = env15722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15721 == env15722) = true)

theorem identity15722 : scanCanonicalize (H12AffineFastState.compose env15722 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15722 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env15723 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,3125,1076,1047,2064,2048,1025,1077,3124,33,16,1078,40,17,2049,3109,2064,2049,20,1045,37,33,2049,513]

theorem envBound15723 : H12AffineFastState.Bounded env15723 := by
  intro p hp
  have h : env15723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15722_15723 : H12AffineEnvironment.transform 5 17 env15722 = env15723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15722 == env15723) = true)

def env15724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound15724 : H12AffineFastState.Bounded env15724 := by
  intro p hp
  have h : env15724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14986_15724 : H12AffineEnvironment.transform 25 65 env14986 = env15724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env14986 == env15724) = true)

def env15725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound15725 : H12AffineFastState.Bounded env15725 := by
  intro p hp
  have h : env15725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15724_15725 : H12AffineEnvironment.transform 26 30393344 env15724 = env15725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env15724 == env15725) = true)

def env15726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound15726 : H12AffineFastState.Bounded env15726 := by
  intro p hp
  have h : env15726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15725_15726 : H12AffineEnvironment.transform 18 1024 env15725 = env15726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15725 == env15726) = true)

theorem identity15726 : scanCanonicalize (H12AffineFastState.compose env15726 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 509986) := by decide +kernel

theorem selectedBound15726 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,509986,16777216,8328,65,20973602,18973836,2596210,67618,17189938,23160256,256,19270798,19328299,17263589]

theorem envBound15727 : H12AffineFastState.Bounded env15727 := by
  intro p hp
  have h : env15727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15726_15727 : H12AffineEnvironment.transform 22 509986 env15726 = env15727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 509986 env15726 == env15727) = true)

def env15728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,16777216,8328,65,16959642,18973836,2596210,67618,17189938,19113336,256,19270798,19328299,17263589]

theorem envBound15728 : H12AffineFastState.Bounded env15728 := by
  intro p hp
  have h : env15728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15727_15728 : H12AffineEnvironment.transform 21 180408 env15727 = env15728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env15727 == env15728) = true)

def env15729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,498992,8328,65,349610,2496956,2596210,67618,119042,2373704,256,2199998,2191387,63189]

theorem envBound15729 : H12AffineFastState.Bounded env15729 := by
  intro p hp
  have h : env15729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15728_15729 : H12AffineEnvironment.transform 23 498992 env15728 = env15729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env15728 == env15729) = true)

def env15730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509986,498992,8328,65,349610,395772,494898,67618,119042,272392,256,98814,90203,63189]

theorem envBound15730 : H12AffineFastState.Bounded env15730 := by
  intro p hp
  have h : env15730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15729_15730 : H12AffineEnvironment.transform 20 4160 env15729 = env15730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15729 == env15730) = true)

theorem identity15730 : scanCanonicalize (H12AffineFastState.compose env15730 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound15730 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,180408,400636,412142,8328,65,295284,395772,416236,56572,1500,272392,256,21792,46213,63189]

theorem envBound15731 : H12AffineFastState.Bounded env15731 := by
  intro p hp
  have h : env15731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15730_15731 : H12AffineEnvironment.transform 15 54494 env15730 = env15731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env15730 == env15731) = true)

def env15732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180272,400500,412006,8192,65,295284,395636,416100,56436,1364,272392,256,21792,46093,63069]

theorem envBound15732 : H12AffineFastState.Bounded env15732 := by
  intro p hp
  have h : env15732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15731_15732 : H12AffineEnvironment.transform 6 8 env15731 = env15732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15731 == env15732) = true)

theorem identity15732 : scanCanonicalize (H12AffineFastState.compose env15732 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound15732 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env15733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,182629,1024,32769,4160,180272,54545,32771,8192,65,149521,49169,36865,56436,1364,188781,256,21792,46093,63069]

theorem envBound15733 : H12AffineFastState.Bounded env15733 := by
  intro p hp
  have h : env15733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15732_15733 : H12AffineEnvironment.transform 17 182629 env15732 = env15733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env15732 == env15733) = true)

theorem identity15733 : scanCanonicalize (H12AffineFastState.compose env15733 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound15733 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,146745,1024,29789,4160,144492,8525,29791,8192,65,149521,13389,25693,10280,1364,136497,256,21792,16465,513]

theorem envBound15734 : H12AffineFastState.Bounded env15734 := by
  intro p hp
  have h : env15734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15733_15734 : H12AffineEnvironment.transform 14 29788 env15733 = env15734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env15733 == env15734) = true)

theorem identity15734 : scanCanonicalize (H12AffineFastState.compose env15734 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15734 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env15735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,146745,1024,8541,4160,144492,8525,8543,8192,65,138513,13389,12637,10280,1364,136497,256,32,5457,513]

theorem envBound15735 : H12AffineFastState.Bounded env15735 := by
  intro p hp
  have h : env15735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15734_15735 : H12AffineEnvironment.transform 13 5376 env15734 = env15735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15734 == env15735) = true)

theorem identity15735 : scanCanonicalize (H12AffineFastState.compose env15735 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15735 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env15736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,13388,2421,1024,8541,4160,32,8525,8543,8192,65,10589,13389,12637,10280,1364,8573,256,32,5457,513]

theorem envBound15736 : H12AffineFastState.Bounded env15736 := by
  intro p hp
  have h : env15736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15735_15736 : H12AffineEnvironment.transform 16 13388 env15735 = env15736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15735 == env15736) = true)

def env15737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180273,400501,412007,8193,65,295284,395637,416101,56437,1365,272392,256,21792,46092,63068]

theorem envBound15737 : H12AffineFastState.Bounded env15737 := by
  intro p hp
  have h : env15737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15731_15737 : H12AffineEnvironment.transform 6 9 env15731 = env15737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15731 == env15737) = true)

theorem identity15737 : scanCanonicalize (H12AffineFastState.compose env15737 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23888) := by decide +kernel

theorem selectedBound15737 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env15738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,23888,1024,32769,4160,180273,147749,136247,8193,65,56356,152613,132149,56437,1365,30040,256,21792,46092,63068]

theorem envBound15738 : H12AffineFastState.Bounded env15738 := by
  intro p hp
  have h : env15738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15737_15738 : H12AffineEnvironment.transform 17 23888 env15737 = env15738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23888 env15737 == env15738) = true)

theorem identity15738 : scanCanonicalize (H12AffineFastState.compose env15738 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15738 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env15739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,131072,23888,1024,8461,4160,155965,147749,136247,8193,65,32040,152613,132149,32121,1365,30040,256,21792,5376,22352]

theorem envBound15739 : H12AffineFastState.Bounded env15739 := by
  intro p hp
  have h : env15739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15738_15739 : H12AffineEnvironment.transform 14 8460 env15738 = env15739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env15738 == env15739) = true)

theorem identity15739 : scanCanonicalize (H12AffineFastState.compose env15739 (packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound15739 : packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,5441,23888,1024,8461,4160,29820,21604,374,8193,65,32040,16740,4468,32121,1365,30040,256,21792,5376,22352]

theorem envBound15740 : H12AffineFastState.Bounded env15740 := by
  intro p hp
  have h : env15740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15739_15740 : H12AffineEnvironment.transform 16 5441 env15739 = env15740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env15739 == env15740) = true)

theorem identity15740 : scanCanonicalize (H12AffineFastState.compose env15740 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15740 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env15741 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29962,5392,23809,1024,8461,4113,29741,21557,295,8193,16,32040,16693,4389,32040,1284,29961,256,21792,5376,22273]

theorem envBound15741 : H12AffineFastState.Bounded env15741 := by
  intro p hp
  have h : env15741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15740_15741 : H12AffineEnvironment.transform 5 17 env15740 = env15741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15740 == env15741) = true)

theorem identity15741 : scanCanonicalize (H12AffineFastState.compose env15741 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound15741 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15742 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,263,5392,10508,1024,8461,4113,32,8248,295,8193,16,2341,13624,4389,2341,1284,260,256,8493,5376,8972]

theorem envBound15742 : H12AffineFastState.Bounded env15742 := by
  intro p hp
  have h : env15742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15741_15742 : H12AffineEnvironment.transform 13 13325 env15741 = env15742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env15741 == env15742) = true)

theorem identity15742 : scanCanonicalize (H12AffineFastState.compose env15742 (packedSelected [0,1,2,4,6,7,8,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15742 : packedSelected [0,1,2,4,6,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env15743 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5157,292,263,5392,2340,1024,293,4113,32,16,295,41,16,2341,5392,4389,2341,1284,260,256,261,5376,804]

theorem envBound15743 : H12AffineFastState.Bounded env15743 := by
  intro p hp
  have h : env15743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15742_15743 : H12AffineEnvironment.transform 12 40 env15742 = env15743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15742 == env15743) = true)

theorem identity15743 : scanCanonicalize (H12AffineFastState.compose env15743 (packedSelected [0,1,3,4,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15743 : packedSelected [0,1,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env15744 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4113,32,16,3,41,16,2049,5172,4097,2049,1056,32,36,33,5156,512]

theorem envBound15744 : H12AffineFastState.Bounded env15744 := by
  intro p hp
  have h : env15744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15743_15744 : H12AffineEnvironment.transform 7 36 env15743 = env15744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15743 == env15744) = true)

theorem identity15744 : scanCanonicalize (H12AffineFastState.compose env15744 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15745 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,0,2,5141,2048,1024,1,4113,1,16,3,8,16,2049,5141,4097,2049,1025,1,5,0,5125,512]

theorem envBound15745 : H12AffineFastState.Bounded env15745 := by
  intro p hp
  have h : env15745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15744_15745 : H12AffineEnvironment.transform 4 1 env15744 = env15745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15744 == env15745) = true)

theorem identity15745 : scanCanonicalize (H12AffineFastState.compose env15745 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound15745 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15746 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,9,5124,0,2,5141,523,1024,1,4113,1,16,3,8,16,522,5141,4097,522,1025,1,5,0,5125,512]

theorem envBound15746 : H12AffineFastState.Bounded env15746 := by
  intro p hp
  have h : env15746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15745_15746 : H12AffineEnvironment.transform 10 523 env15745 = env15746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env15745 == env15746) = true)

def env15747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509986,498992,8328,65,349610,395773,494899,67618,119042,272393,256,98815,90202,63189]

theorem envBound15747 : H12AffineFastState.Bounded env15747 := by
  intro p hp
  have h : env15747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15729_15747 : H12AffineEnvironment.transform 20 4161 env15729 = env15747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15729 == env15747) = true)

theorem identity15747 : scanCanonicalize (H12AffineFastState.compose env15747 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound15747 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4161,180408,62660,41430,8328,65,158028,79131,45525,67618,119042,201967,256,98815,90202,63189]

theorem envBound15748 : H12AffineFastState.Bounded env15748 := by
  intro p hp
  have h : env15748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15747_15748 : H12AffineEnvironment.transform 17 212198 env15747 = env15748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env15747 == env15748) = true)

theorem identity15748 : scanCanonicalize (H12AffineFastState.compose env15748 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound15748 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212198,1024,29909,4161,144492,16,21762,8328,65,158028,79131,17665,67618,75222,201967,256,95531,90202,513]

theorem envBound15749 : H12AffineFastState.Bounded env15749 := by
  intro p hp
  have h : env15749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15748_15749 : H12AffineEnvironment.transform 14 29908 env15748 = env15749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env15748 == env15749) = true)

theorem identity15749 : scanCanonicalize (H12AffineFastState.compose env15749 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound15749 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env15750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,5528,76158,1024,29909,4161,8692,16,21762,8328,65,31956,79131,17665,67618,75222,65911,256,95531,90202,513]

theorem envBound15750 : H12AffineFastState.Bounded env15750 := by
  intro p hp
  have h : env15750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15749_15750 : H12AffineEnvironment.transform 16 5528 env15749 = env15750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env15749 == env15750) = true)

theorem identity15750 : scanCanonicalize (H12AffineFastState.compose env15750 (packedSelected [4,5,7,8,9,10,15,17,24,26,27,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound15750 : packedSelected [4,5,7,8,9,10,15,17,24,26,27,28,38] rootPS < 2^1333 := by decide +kernel

def env15751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21591,5528,32041,1024,29909,4161,8692,16,21762,8328,65,31956,24908,17665,23669,29057,21792,256,8572,13325,513]

theorem envBound15751 : H12AffineFastState.Bounded env15751 := by
  intro p hp
  have h : env15751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15750_15751 : H12AffineEnvironment.transform 15 21591 env15750 = env15751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env15750 == env15751) = true)

theorem identity15751 : scanCanonicalize (H12AffineFastState.compose env15751 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15751 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env15752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,21591,5528,23668,1024,21896,4161,169,16,21762,469,65,23945,16401,17665,23669,20700,21792,256,33,5456,513]

theorem envBound15752 : H12AffineFastState.Bounded env15752 := by
  intro p hp
  have h : env15752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15751_15752 : H12AffineEnvironment.transform 12 349 env15751 = env15752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15751 == env15752) = true)

theorem identity15752 : scanCanonicalize (H12AffineFastState.compose env15752 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15752 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15753 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,16384,21757,21591,5356,23668,1024,21756,4161,169,16,21622,161,65,23805,16401,17525,23669,20700,21588,116,33,5156,513]

theorem envBound15753 : H12AffineFastState.Bounded env15753 := by
  intro p hp
  have h : env15753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15752_15753 : H12AffineEnvironment.transform 7 116 env15752 = env15753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15752 == env15753) = true)

theorem identity15753 : scanCanonicalize (H12AffineFastState.compose env15753 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound15753 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15754 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5372,1,171,5356,2184,1024,0,4161,169,16,138,161,65,2049,5357,4233,2185,1056,168,116,33,5156,513]

theorem envBound15754 : H12AffineFastState.Bounded env15754 := by
  intro p hp
  have h : env15754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15753_15754 : H12AffineEnvironment.transform 13 5372 env15753 = env15754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env15753 == env15754) = true)

theorem identity15754 : scanCanonicalize (H12AffineFastState.compose env15754 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound15754 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15755 : List Nat := [2,4,8,16,32,64,128,116,512,236,2048,4096,41,4112,1,171,4096,2184,236,0,4161,169,16,138,161,65,2049,4097,4233,2185,204,168,116,33,4296,513]

theorem envBound15755 : H12AffineFastState.Bounded env15755 := by
  intro p hp
  have h : env15755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15754_15755 : H12AffineEnvironment.transform 9 236 env15754 = env15755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env15754 == env15755) = true)

theorem identity15755 : scanCanonicalize (H12AffineFastState.compose env15755 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15755 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15756 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,4112,1,35,4096,2048,100,0,4161,33,16,2,41,65,2049,4097,4097,2049,68,32,116,33,4160,513]

theorem envBound15756 : H12AffineFastState.Bounded env15756 := by
  intro p hp
  have h : env15756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15755_15756 : H12AffineEnvironment.transform 6 8 env15755 = env15756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15755 == env15756) = true)

theorem identity15756 : scanCanonicalize (H12AffineFastState.compose env15756 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound15756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15757 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,16,41,0,1,35,16,2048,100,0,81,33,16,2,41,65,2049,17,17,2049,68,32,116,33,80,513]

theorem envBound15757 : H12AffineFastState.Bounded env15757 := by
  intro p hp
  have h : env15757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15756_15757 : H12AffineEnvironment.transform 11 16 env15756 = env15757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15756 == env15757) = true)

theorem identity15757 : scanCanonicalize (H12AffineFastState.compose env15757 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound15757 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15758 : List Nat := [2,4,8,16,32,64,8,116,48,100,2048,16,41,0,1,35,16,2048,100,0,81,33,16,2,41,65,2049,17,17,2049,68,32,116,33,80,49]

theorem envBound15758 : H12AffineFastState.Bounded env15758 := by
  intro p hp
  have h : env15758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15757_15758 : H12AffineEnvironment.transform 8 48 env15757 = env15758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env15757 == env15758) = true)

theorem identity15758 : scanCanonicalize (H12AffineFastState.compose env15758 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15758 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15759 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,16,41,0,1,35,16,2048,52,0,1,33,16,2,41,17,2049,17,17,2049,20,32,36,33,0,49]

theorem envBound15759 : H12AffineFastState.Bounded env15759 := by
  intro p hp
  have h : env15759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15758_15759 : H12AffineEnvironment.transform 5 16 env15758 = env15759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15758 == env15759) = true)

theorem identity15759 : scanCanonicalize (H12AffineFastState.compose env15759 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15760 : List Nat := [2,4,8,16,32,16,8,36,48,52,1,16,41,0,1,35,16,1,52,0,1,33,16,2,41,17,0,17,17,0,20,32,36,33,0,49]

theorem envBound15760 : H12AffineFastState.Bounded env15760 := by
  intro p hp
  have h : env15760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15759_15760 : H12AffineEnvironment.transform 10 1 env15759 = env15760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15759 == env15760) = true)

def env15761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,498993,8328,65,349611,2496957,2596210,67618,119043,2373705,256,2199999,2191386,63188]

theorem envBound15761 : H12AffineFastState.Bounded env15761 := by
  intro p hp
  have h : env15761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15728_15761 : H12AffineEnvironment.transform 23 498993 env15728 = env15761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env15728 == env15761) = true)

def env15762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509986,498993,8328,65,349611,395773,494898,67618,119043,272393,256,98815,90202,63188]

theorem envBound15762 : H12AffineFastState.Bounded env15762 := by
  intro p hp
  have h : env15762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15761_15762 : H12AffineEnvironment.transform 20 4160 env15761 = env15762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15761 == env15762) = true)

theorem identity15762 : scanCanonicalize (H12AffineFastState.compose env15762 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound15762 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180408,16,21763,8328,65,171417,115151,17664,67618,119043,254011,256,98815,90202,63188]

theorem envBound15763 : H12AffineFastState.Bounded env15763 := by
  intro p hp
  have h : env15763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15762_15763 : H12AffineEnvironment.transform 17 247858 env15762 = env15763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env15762 == env15763) = true)

def env15764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180272,16,21763,8192,65,171281,115015,17664,67618,119043,254011,256,98679,90202,63068]

theorem envBound15764 : H12AffineFastState.Bounded env15764 := by
  intro p hp
  have h : env15764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15763_15764 : H12AffineEnvironment.transform 6 8 env15763 = env15764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15763 == env15764) = true)

theorem identity15764 : scanCanonicalize (H12AffineFastState.compose env15764 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound15764 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,56437,1024,32769,4160,119927,16,21763,8192,65,100694,115015,17664,67618,119043,62588,256,98679,90202,63068]

theorem envBound15765 : H12AffineFastState.Bounded env15765 := by
  intro p hp
  have h : env15765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15764_15765 : H12AffineEnvironment.transform 16 70727 env15764 = env15765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env15764 == env15765) = true)

theorem identity15765 : scanCanonicalize (H12AffineFastState.compose env15765 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound15765 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,57676,56437,1024,32769,4160,8572,16,21763,8192,65,31837,13388,17664,64809,9224,62588,256,29820,38225,63068]

theorem envBound15766 : H12AffineFastState.Bounded env15766 := by
  intro p hp
  have h : env15766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15765_15766 : H12AffineEnvironment.transform 15 62731 env15765 = env15766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env15765 == env15766) = true)

theorem identity15766 : scanCanonicalize (H12AffineFastState.compose env15766 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15766 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,41051,46108,35109,1024,32769,4160,8572,16,83,8192,65,10509,13388,4176,43129,9224,41260,256,8492,38225,41740]

theorem envBound15767 : H12AffineFastState.Bounded env15767 := by
  intro p hp
  have h : env15767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15766_15767 : H12AffineEnvironment.transform 13 5456 env15766 = env15767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env15766 == env15767) = true)

theorem identity15767 : scanCanonicalize (H12AffineFastState.compose env15767 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15767 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,262,5441,10360,1024,8540,4160,8572,16,83,8192,65,10509,13388,4176,2340,9224,113,256,8492,13324,593]

theorem envBound15768 : H12AffineFastState.Bounded env15768 := by
  intro p hp
  have h : env15768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15767_15768 : H12AffineEnvironment.transform 14 8541 env15767 = env15768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15767 == env15768) = true)

theorem identity15768 : scanCanonicalize (H12AffineFastState.compose env15768 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15768 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,1,262,5441,2340,1024,0,4160,32,16,83,348,65,2129,5392,4176,2340,1364,113,256,112,5456,593]

theorem envBound15769 : H12AffineFastState.Bounded env15769 := by
  intro p hp
  have h : env15769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15768_15769 : H12AffineEnvironment.transform 12 348 env15768 = env15769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15768 == env15769) = true)

theorem identity15769 : scanCanonicalize (H12AffineFastState.compose env15769 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15769 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15770 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,348,4404,1,262,4389,2340,100,0,4160,32,16,83,348,65,2129,4468,4176,2340,304,113,256,112,4404,593]

theorem envBound15770 : H12AffineFastState.Bounded env15770 := by
  intro p hp
  have h : env15770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15769_15770 : H12AffineEnvironment.transform 9 100 env15769 = env15770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15769 == env15770) = true)

def env15771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180273,16,21763,8193,65,171280,115014,17664,67618,119043,254011,256,98678,90202,63069]

theorem envBound15771 : H12AffineFastState.Bounded env15771 := by
  intro p hp
  have h : env15771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15763_15771 : H12AffineEnvironment.transform 6 9 env15763 = env15771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15763 == env15771) = true)

theorem identity15771 : scanCanonicalize (H12AffineFastState.compose env15771 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound15771 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,32040,1024,32769,4160,95531,16,21763,8193,65,75786,115014,17664,67618,119043,21793,256,98678,90202,63069]

theorem envBound15772 : H12AffineFastState.Bounded env15772 := by
  intro p hp
  have h : env15772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15771_15772 : H12AffineEnvironment.transform 16 111898 env15771 = env15772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env15771 == env15772) = true)

theorem identity15772 : scanCanonicalize (H12AffineFastState.compose env15772 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound15772 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env15773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49217,32040,1024,32769,4160,112,16,21763,8193,65,23889,46109,17664,32121,42072,21793,256,62509,5377,63069]

theorem envBound15773 : H12AffineFastState.Bounded env15773 := by
  intro p hp
  have h : env15773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15772_15773 : H12AffineEnvironment.transform 15 30043 env15772 = env15773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env15772 == env15773) = true)

theorem identity15773 : scanCanonicalize (H12AffineFastState.compose env15773 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound15773 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env15774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,30043,13672,32040,1024,29992,4160,112,16,21763,8193,65,23889,16692,17664,32121,20849,21793,256,260,5377,884]

theorem envBound15774 : H12AffineFastState.Bounded env15774 := by
  intro p hp
  have h : env15774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15773_15774 : H12AffineEnvironment.transform 14 29993 env15773 = env15774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env15773 == env15774) = true)

theorem identity15774 : scanCanonicalize (H12AffineFastState.compose env15774 (packedSelected [0,3,4,5,6,7,9,10,12,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound15774 : packedSelected [0,3,4,5,6,7,9,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env15775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21841,21795,5392,23888,1024,21840,4160,112,16,21763,121,65,23889,16692,17664,23809,20849,21793,256,260,5377,884]

theorem envBound15775 : H12AffineFastState.Bounded env15775 := by
  intro p hp
  have h : env15775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15774_15775 : H12AffineEnvironment.transform 12 120 env15774 = env15775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env15774 == env15775) = true)

theorem identity15775 : scanCanonicalize (H12AffineFastState.compose env15775 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15775 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,81,35,5392,2128,1024,80,4160,112,16,3,121,65,2129,5172,4096,2049,1137,33,256,260,5377,884]

theorem envBound15776 : H12AffineFastState.Bounded env15776 := by
  intro p hp
  have h : env15776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15775_15776 : H12AffineEnvironment.transform 13 5376 env15775 = env15776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15775 == env15776) = true)

theorem identity15776 : scanCanonicalize (H12AffineFastState.compose env15776 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15776 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15777 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,0,35,5392,2049,1024,1,4113,33,16,3,40,16,2048,5172,4096,2049,1056,33,256,260,5377,805]

theorem envBound15777 : H12AffineFastState.Bounded env15777 := by
  intro p hp
  have h : env15777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15776_15777 : H12AffineEnvironment.transform 5 17 env15776 = env15777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15776 == env15777) = true)

theorem identity15777 : scanCanonicalize (H12AffineFastState.compose env15777 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound15777 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env15778 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,41,1,0,35,17,2049,1024,1,1296,33,16,3,40,16,2048,309,1281,2049,1056,33,256,260,0,805]

theorem envBound15778 : H12AffineFastState.Bounded env15778 := by
  intro p hp
  have h : env15778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15777_15778 : H12AffineEnvironment.transform 11 1281 env15777 = env15778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env15777 == env15778) = true)

theorem identity15778 : scanCanonicalize (H12AffineFastState.compose env15778 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15778 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env15779 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1281,41,1,0,35,17,1296,1024,1,1296,33,16,3,40,16,1297,309,1281,1296,1056,33,256,260,0,805]

theorem envBound15779 : H12AffineFastState.Bounded env15779 := by
  intro p hp
  have h : env15779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15778_15779 : H12AffineEnvironment.transform 10 1297 env15778 = env15779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env15778 == env15779) = true)

def env15780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509986,498993,8328,65,349611,395772,494899,67618,119043,272392,256,98814,90203,63188]

theorem envBound15780 : H12AffineFastState.Bounded env15780 := by
  intro p hp
  have h : env15780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15761_15780 : H12AffineEnvironment.transform 20 4161 env15761 = env15780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15761 == env15780) = true)

theorem identity15780 : scanCanonicalize (H12AffineFastState.compose env15780 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15780 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,180408,452648,441659,8328,65,292257,395772,437561,10280,61705,272392,256,41460,16465,63188]

theorem envBound15781 : H12AffineFastState.Bounded env15781 := by
  intro p hp
  have h : env15781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15780_15781 : H12AffineEnvironment.transform 15 8202 env15780 = env15781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15780 == env15781) = true)

def env15782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,262144,1024,32769,4161,180408,444632,433611,120,65,283985,395772,429513,2264,53753,264440,256,33028,16465,54820]

theorem envBound15782 : H12AffineFastState.Bounded env15782 := by
  intro p hp
  have h : env15782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15781_15782 : H12AffineEnvironment.transform 12 240 env15781 = env15782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env15781 == env15782) = true)

theorem identity15782 : scanCanonicalize (H12AffineFastState.compose env15782 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15782 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env15783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,114,131072,262144,1024,32769,4161,180272,444496,433475,120,65,283985,395636,429377,2128,53617,264304,256,33028,16465,54820]

theorem envBound15783 : H12AffineFastState.Bounded env15783 := by
  intro p hp
  have h : env15783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15782_15783 : H12AffineEnvironment.transform 6 8 env15782 = env15783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15782 == env15783) = true)

theorem identity15783 : scanCanonicalize (H12AffineFastState.compose env15783 (packedSelected [0,2,4,6,7,8,9,11,12,17,19,23,26,28,31,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 171328) := by decide +kernel

theorem selectedBound15783 : packedSelected [0,2,4,6,7,8,9,11,12,17,19,23,26,28,31,35,38] rootPS < 2^1333 := by decide +kernel

def env15784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,114,131072,171328,1024,32769,4161,180272,21776,3,120,65,182289,37940,4097,2128,53617,169264,256,33028,16465,54820]

theorem envBound15784 : H12AffineFastState.Bounded env15784 := by
  intro p hp
  have h : env15784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15783_15784 : H12AffineEnvironment.transform 17 171328 env15783 = env15784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171328 env15783 == env15784) = true)

theorem identity15784 : scanCanonicalize (H12AffineFastState.compose env15784 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound15784 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env15785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21760,114,131072,149568,1024,21761,4161,136496,21776,3,120,65,138513,16692,4097,2128,1137,147504,256,21508,16465,804]

theorem envBound15785 : H12AffineFastState.Bounded env15785 := by
  intro p hp
  have h : env15785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15784_15785 : H12AffineEnvironment.transform 14 21760 env15784 = env15785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env15784 == env15785) = true)

theorem identity15785 : scanCanonicalize (H12AffineFastState.compose env15785 (packedSelected [0,7,9,14,17,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound15785 : packedSelected [0,7,9,14,17,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env15786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21760,114,5173,23669,1024,21761,4161,261,21776,3,120,65,2340,16692,4097,2128,1137,21509,256,21508,16465,804]

theorem envBound15786 : H12AffineFastState.Bounded env15786 := by
  intro p hp
  have h : env15786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15785_15786 : H12AffineEnvironment.transform 16 5173 env15785 = env15786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env15785 == env15786) = true)

theorem identity15786 : scanCanonicalize (H12AffineFastState.compose env15786 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15786 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,80,114,5173,2341,1024,81,4161,261,64,3,120,65,2340,5220,4097,2128,1137,341,256,340,5377,804]

theorem envBound15787 : H12AffineFastState.Bounded env15787 := by
  intro p hp
  have h : env15787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15786_15787 : H12AffineEnvironment.transform 13 5456 env15786 = env15787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env15786 == env15787) = true)

theorem identity15787 : scanCanonicalize (H12AffineFastState.compose env15787 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15787 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15788 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5376,0,34,5173,2341,1024,1,4113,261,16,3,40,17,2340,5172,4097,2048,1057,261,256,260,5377,804]

theorem envBound15788 : H12AffineFastState.Bounded env15788 := by
  intro p hp
  have h : env15788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15787_15788 : H12AffineEnvironment.transform 5 16 env15787 = env15788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15787 == env15788) = true)

theorem identity15788 : scanCanonicalize (H12AffineFastState.compose env15788 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound15788 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env15789 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,40,1076,0,34,1281,2341,1024,1,293,261,16,3,40,17,2340,1280,309,2048,1057,261,256,260,1077,804]

theorem envBound15789 : H12AffineFastState.Bounded env15789 := by
  intro p hp
  have h : env15789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15788_15789 : H12AffineEnvironment.transform 11 308 env15788 = env15789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env15788 == env15789) = true)

theorem identity15789 : scanCanonicalize (H12AffineFastState.compose env15789 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound15789 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env15790 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,308,40,1076,0,34,1281,1296,1024,1,293,261,16,3,40,17,1297,1280,309,1077,1057,261,256,260,1077,804]

theorem envBound15790 : H12AffineFastState.Bounded env15790 := by
  intro p hp
  have h : env15790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15789_15790 : H12AffineEnvironment.transform 10 1077 env15789 = env15790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env15789 == env15790) = true)

theorem identity15790 : scanCanonicalize (H12AffineFastState.compose env15790 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound15790 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env15791 : List Nat := [2,4,8,16,32,16,8,256,512,272,293,308,40,292,0,34,17,0,272,1,293,261,16,3,40,17,1,16,309,293,305,261,256,260,293,804]

theorem envBound15791 : H12AffineFastState.Bounded env15791 := by
  intro p hp
  have h : env15791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15790_15791 : H12AffineEnvironment.transform 9 272 env15790 = env15791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15790 == env15791) = true)

theorem identity15791 : scanCanonicalize (H12AffineFastState.compose env15791 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15791 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env15792 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,16,40,0,0,34,17,0,52,1,1,33,16,3,40,17,1,16,17,1,21,33,36,32,1,512]

theorem envBound15792 : H12AffineFastState.Bounded env15792 := by
  intro p hp
  have h : env15792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15791_15792 : H12AffineEnvironment.transform 7 36 env15791 = env15792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15791 == env15792) = true)

theorem identity15792 : scanCanonicalize (H12AffineFastState.compose env15792 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15793 : List Nat := [2,4,8,16,32,16,8,36,0,52,1,16,40,0,0,34,17,0,52,1,1,33,16,3,40,17,1,16,17,1,21,33,36,32,1,0]

theorem envBound15793 : H12AffineFastState.Bounded env15793 := by
  intro p hp
  have h : env15793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15792_15793 : H12AffineEnvironment.transform 8 0 env15792 = env15793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15792 == env15793) = true)

theorem identity15793 : scanCanonicalize (H12AffineFastState.compose env15793 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound15793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15794 : List Nat := [2,4,8,16,30,16,8,26,0,10,1,16,22,0,0,28,17,0,10,1,1,31,16,3,22,17,1,16,17,1,21,31,26,30,1,0]

theorem envBound15794 : H12AffineFastState.Bounded env15794 := by
  intro p hp
  have h : env15794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15793_15794 : H12AffineEnvironment.transform 4 30 env15793 = env15794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env15793 == env15794) = true)

theorem identity15794 : scanCanonicalize (H12AffineFastState.compose env15794 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound15794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15795 : List Nat := [2,4,8,14,0,14,8,4,0,10,1,14,8,0,0,2,15,0,10,1,1,1,14,3,8,15,1,14,15,1,11,1,4,0,1,0]

theorem envBound15795 : H12AffineFastState.Bounded env15795 := by
  intro p hp
  have h : env15795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15794_15795 : H12AffineEnvironment.transform 3 14 env15794 = env15795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env15794 == env15795) = true)

def env15796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,262144,1024,32769,4161,180408,444633,433610,121,65,283984,395772,429512,2265,53752,264441,256,33029,16465,54821]

theorem envBound15796 : H12AffineFastState.Bounded env15796 := by
  intro p hp
  have h : env15796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15781_15796 : H12AffineEnvironment.transform 12 241 env15781 = env15796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env15781 == env15796) = true)

def env15797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,131072,262144,1024,32769,4113,180408,444553,433562,41,17,283904,395692,429464,2185,53672,264361,256,33029,16385,54821]

theorem envBound15797 : H12AffineFastState.Bounded env15797 := by
  intro p hp
  have h : env15797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15796_15797 : H12AffineEnvironment.transform 5 16 env15796 = env15797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15796 == env15797) = true)

theorem identity15797 : scanCanonicalize (H12AffineFastState.compose env15797 (packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound15797 : packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env15798 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,5528,262144,1024,32769,4113,54560,318737,296962,41,17,283904,269364,301056,2185,53672,264361,256,33029,16385,54821]

theorem envBound15798 : H12AffineFastState.Bounded env15798 := by
  intro p hp
  have h : env15798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15797_15798 : H12AffineEnvironment.transform 16 5528 env15797 = env15798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env15797 == env15798) = true)

theorem identity15798 : scanCanonicalize (H12AffineFastState.compose env15798 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56493) := by decide +kernel

theorem selectedBound15798 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,5528,56493,1024,32769,4113,54560,444,21679,41,17,35245,49305,17581,2185,53672,54276,256,33029,16385,54821]

theorem envBound15799 : H12AffineFastState.Bounded env15799 := by
  intro p hp
  have h : env15799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15798_15799 : H12AffineEnvironment.transform 17 56493 env15798 = env15799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56493 env15798 == env15799) = true)

theorem identity15799 : scanCanonicalize (H12AffineFastState.compose env15799 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound15799 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15800 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,5292,32768,171,5528,34817,1024,32769,4113,33164,444,3,41,17,35245,37941,4097,2185,34052,32936,256,33029,5293,33417]

theorem envBound15800 : H12AffineFastState.Bounded env15800 := by
  intro p hp
  have h : env15800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15799_15800 : H12AffineEnvironment.transform 13 5292 env15799 = env15800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env15799 == env15800) = true)

theorem identity15800 : scanCanonicalize (H12AffineFastState.compose env15800 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound15800 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env15801 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5292,32768,171,5172,34817,1024,32769,4113,32800,16,3,41,17,34817,37941,4097,2185,33960,32936,172,32937,5293,33417]

theorem envBound15801 : H12AffineFastState.Bounded env15801 := by
  intro p hp
  have h : env15801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15800_15801 : H12AffineEnvironment.transform 7 172 env15800 = env15801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env15800 == env15801) = true)

theorem identity15801 : scanCanonicalize (H12AffineFastState.compose env15801 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15801 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15802 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5292,0,171,5172,2049,1024,1,4113,32,16,3,41,17,2049,5173,4097,2185,1192,168,172,169,5293,649]

theorem envBound15802 : H12AffineFastState.Bounded env15802 := by
  intro p hp
  have h : env15802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15801_15802 : H12AffineEnvironment.transform 14 0 env15801 = env15802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15801 == env15802) = true)

theorem identity15802 : scanCanonicalize (H12AffineFastState.compose env15802 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound15802 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env15803 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,4096,161,4113,0,171,4233,2049,189,1,4113,32,16,3,41,17,2049,4232,4097,2185,21,168,172,169,4112,649]

theorem envBound15803 : H12AffineFastState.Bounded env15803 := by
  intro p hp
  have h : env15803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15802_15803 : H12AffineEnvironment.transform 9 189 env15802 = env15803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env15802 == env15803) = true)

theorem identity15803 : scanCanonicalize (H12AffineFastState.compose env15803 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound15803 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env15804 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,17,161,0,0,171,152,2049,189,1,0,32,16,3,41,17,2049,153,16,2185,21,168,172,169,1,649]

theorem envBound15804 : H12AffineFastState.Bounded env15804 := by
  intro p hp
  have h : env15804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15803_15804 : H12AffineEnvironment.transform 11 17 env15803 = env15804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15803 == env15804) = true)

def env15805 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,131072,262144,1024,32769,4112,180408,444552,433563,40,16,283905,395693,429465,2184,53673,264360,256,33029,16384,54821]

theorem envBound15805 : H12AffineFastState.Bounded env15805 := by
  intro p hp
  have h : env15805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15796_15805 : H12AffineEnvironment.transform 5 17 env15796 = env15805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15796 == env15805) = true)

theorem identity15805 : scanCanonicalize (H12AffineFastState.compose env15805 (packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 49596) := by decide +kernel

theorem selectedBound15805 : packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env15806 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,49596,262144,1024,32769,4112,260,264500,285735,40,16,283905,313361,281637,2184,53673,264360,256,33029,16384,54821]

theorem envBound15806 : H12AffineFastState.Bounded env15806 := by
  intro p hp
  have h : env15806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15805_15806 : H12AffineEnvironment.transform 16 49596 env15805 = env15806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49596 env15805 == env15806) = true)

theorem identity15806 : scanCanonicalize (H12AffineFastState.compose env15806 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound15806 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env15807 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,49596,2048,1024,32769,4112,260,308,21543,40,16,23809,49169,17445,2184,53673,168,256,33029,16384,54821]

theorem envBound15807 : H12AffineFastState.Bounded env15807 := by
  intro p hp
  have h : env15807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15806_15807 : H12AffineEnvironment.transform 17 2048 env15806 = env15807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env15806 == env15807) = true)

theorem identity15807 : scanCanonicalize (H12AffineFastState.compose env15807 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound15807 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env15808 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5292,32768,170,38160,2048,1024,32769,4112,260,308,139,40,16,2477,38077,4233,2184,34053,168,256,33029,5292,33417]

theorem envBound15808 : H12AffineFastState.Bounded env15808 := by
  intro p hp
  have h : env15808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15807_15808 : H12AffineEnvironment.transform 13 5292 env15807 = env15808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env15807 == env15808) = true)

theorem identity15808 : scanCanonicalize (H12AffineFastState.compose env15808 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound15808 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15809 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5292,428,170,5308,2048,1024,429,4112,260,308,139,40,16,2477,5393,4233,2184,1193,168,256,169,5292,805]

theorem envBound15809 : H12AffineFastState.Bounded env15809 := by
  intro p hp
  have h : env15809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15808_15809 : H12AffineEnvironment.transform 14 428 env15808 = env15809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env15808 == env15809) = true)

theorem identity15809 : scanCanonicalize (H12AffineFastState.compose env15809 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound15809 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15810 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,309,160,1433,428,170,1417,2048,1024,429,293,260,308,139,40,16,2477,1060,444,2184,1193,168,256,169,1433,805]

theorem envBound15810 : H12AffineFastState.Bounded env15810 := by
  intro p hp
  have h : env15810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15809_15810 : H12AffineEnvironment.transform 11 309 env15809 = env15810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env15809 == env15810) = true)

theorem identity15810 : scanCanonicalize (H12AffineFastState.compose env15810 (packedSelected [0,1,4,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound15810 : packedSelected [0,1,4,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env15811 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,309,160,1433,428,170,1417,293,1024,429,293,260,308,139,40,16,136,1060,444,429,1193,168,256,169,1433,805]

theorem envBound15811 : H12AffineFastState.Bounded env15811 := by
  intro p hp
  have h : env15811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15810_15811 : H12AffineEnvironment.transform 10 293 env15810 = env15811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env15810 == env15811) = true)

theorem identity15811 : scanCanonicalize (H12AffineFastState.compose env15811 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15811 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15812 : List Nat := [2,4,8,16,32,17,128,256,512,53,293,309,160,428,428,170,444,293,53,429,293,260,308,139,40,16,136,17,444,429,156,168,256,169,428,805]

theorem envBound15812 : H12AffineFastState.Bounded env15812 := by
  intro p hp
  have h : env15812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15811_15812 : H12AffineEnvironment.transform 9 53 env15811 = env15812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15811 == env15812) = true)

theorem identity15812 : scanCanonicalize (H12AffineFastState.compose env15812 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15812 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15813 : List Nat := [2,4,8,16,32,17,128,36,512,53,1,17,160,136,136,170,152,1,53,137,1,32,16,139,40,16,136,17,152,137,156,168,36,169,136,513]

theorem envBound15813 : H12AffineFastState.Bounded env15813 := by
  intro p hp
  have h : env15813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15812_15813 : H12AffineEnvironment.transform 7 36 env15812 = env15813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15812 == env15813) = true)

def env15814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,16777216,8328,65,16959643,18973836,2596210,67618,17189938,19113337,256,19270798,19328299,17263589]

theorem envBound15814 : H12AffineFastState.Bounded env15814 := by
  intro p hp
  have h : env15814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15727_15814 : H12AffineEnvironment.transform 21 180409 env15727 = env15814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env15727 == env15814) = true)

def env15815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,498992,8328,65,349611,2496956,2596210,67618,119042,2373705,256,2199998,2191387,63189]

theorem envBound15815 : H12AffineFastState.Bounded env15815 := by
  intro p hp
  have h : env15815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15814_15815 : H12AffineEnvironment.transform 23 498992 env15814 = env15815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env15814 == env15815) = true)

def env15816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509986,498992,8328,65,349611,395772,494898,67618,119042,272393,256,98814,90203,63189]

theorem envBound15816 : H12AffineFastState.Bounded env15816 := by
  intro p hp
  have h : env15816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15815_15816 : H12AffineEnvironment.transform 20 4160 env15815 = env15816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15815 == env15816) = true)

theorem identity15816 : scanCanonicalize (H12AffineFastState.compose env15816 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound15816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4160,180409,120014,98780,8328,65,215367,5392,102878,67618,119042,144613,256,98814,90203,63189]

theorem envBound15817 : H12AffineFastState.Bounded env15817 := by
  intro p hp
  have h : env15817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15816_15817 : H12AffineEnvironment.transform 17 138476 env15816 = env15817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env15816 == env15817) = true)

def env15818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1024,32769,4160,62709,120014,98780,8328,65,97547,5392,102878,67618,119042,169,256,98814,90203,63189]

theorem envBound15818 : H12AffineFastState.Bounded env15818 := by
  intro p hp
  have h : env15818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15817_15818 : H12AffineEnvironment.transform 16 13388 env15817 = env15818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15817 == env15818) = true)

theorem identity15818 : scanCanonicalize (H12AffineFastState.compose env15818 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound15818 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env15819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,13388,10400,1024,137,4160,29821,87110,65876,8328,65,97547,5392,69974,67618,86410,169,256,65910,90203,30301]

theorem envBound15819 : H12AffineFastState.Bounded env15819 := by
  intro p hp
  have h : env15819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15818_15819 : H12AffineEnvironment.transform 14 136 env15818 = env15819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env15818 == env15819) = true)

theorem identity15819 : scanCanonicalize (H12AffineFastState.compose env15819 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound15819 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env15820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,65536,5528,2420,1024,137,4160,21929,87110,65876,348,65,89311,5392,69974,67618,86410,169,256,65910,82319,22409]

theorem envBound15820 : H12AffineFastState.Bounded env15820 := by
  intro p hp
  have h : env15820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15819_15820 : H12AffineEnvironment.transform 12 468 env15819 = env15820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env15819 == env15820) = true)

theorem identity15820 : scanCanonicalize (H12AffineFastState.compose env15820 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15820 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,65536,5528,2420,1024,137,4160,169,65862,65876,348,65,68063,5392,69974,67618,66698,169,256,65910,70799,649]

theorem envBound15821 : H12AffineFastState.Bounded env15821 := by
  intro p hp
  have h : env15821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15820_15821 : H12AffineEnvironment.transform 13 5376 env15820 = env15821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15820 == env15821) = true)

theorem identity15821 : scanCanonicalize (H12AffineFastState.compose env15821 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15821 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,262,5528,2420,1024,137,4160,169,64,82,348,65,2265,5392,4176,2340,1420,169,256,112,5513,649]

theorem envBound15822 : H12AffineFastState.Bounded env15822 := by
  intro p hp
  have h : env15822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15821_15822 : H12AffineEnvironment.transform 15 262 env15821 = env15822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15821 == env15822) = true)

theorem identity15822 : scanCanonicalize (H12AffineFastState.compose env15822 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15822 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env15823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,262,5392,2420,1024,1,4160,33,64,82,348,65,2129,5392,4176,2340,1284,33,256,112,5377,513]

theorem envBound15823 : H12AffineFastState.Bounded env15823 := by
  intro p hp
  have h : env15823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15822_15823 : H12AffineEnvironment.transform 6 8 env15822 = env15823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15822 == env15823) = true)

theorem identity15823 : scanCanonicalize (H12AffineFastState.compose env15823 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15823 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15824 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1024,1,4112,33,16,2,268,17,2049,5392,4096,2340,1284,33,256,32,5377,513]

theorem envBound15824 : H12AffineFastState.Bounded env15824 := by
  intro p hp
  have h : env15824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15823_15824 : H12AffineEnvironment.transform 5 16 env15823 = env15824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15823 == env15824) = true)

theorem identity15824 : scanCanonicalize (H12AffineFastState.compose env15824 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound15824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15825 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,268,1044,0,262,1028,2340,1024,1,260,33,16,2,268,17,2049,1028,276,2340,1284,33,256,32,1045,513]

theorem envBound15825 : H12AffineFastState.Bounded env15825 := by
  intro p hp
  have h : env15825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15824_15825 : H12AffineEnvironment.transform 11 276 env15824 = env15825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env15824 == env15825) = true)

theorem identity15825 : scanCanonicalize (H12AffineFastState.compose env15825 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound15825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15826 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,276,268,293,0,262,309,2340,305,1,260,33,16,2,268,17,2049,309,276,2340,53,33,256,32,292,513]

theorem envBound15826 : H12AffineFastState.Bounded env15826 := by
  intro p hp
  have h : env15826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15825_15826 : H12AffineEnvironment.transform 9 305 env15825 = env15826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env15825 == env15826) = true)

theorem identity15826 : scanCanonicalize (H12AffineFastState.compose env15826 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15826 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15827 : List Nat := [2,4,8,16,32,16,8,256,292,305,2048,276,268,293,0,262,309,2340,305,1,260,33,16,2,268,17,2049,309,276,2340,53,33,256,32,292,293]

theorem envBound15827 : H12AffineFastState.Bounded env15827 := by
  intro p hp
  have h : env15827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15826_15827 : H12AffineEnvironment.transform 8 292 env15826 = env15827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15826 == env15827) = true)

theorem identity15827 : scanCanonicalize (H12AffineFastState.compose env15827 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15827 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15828 : List Nat := [2,4,8,16,17,16,8,256,277,256,2048,276,268,276,0,262,260,2325,256,1,260,16,16,2,268,17,2049,260,276,2325,4,16,256,17,277,276]

theorem envBound15828 : H12AffineFastState.Bounded env15828 := by
  intro p hp
  have h : env15828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15827_15828 : H12AffineEnvironment.transform 4 17 env15827 = env15828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15827 == env15828) = true)

theorem identity15828 : scanCanonicalize (H12AffineFastState.compose env15828 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound15828 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15829 : List Nat := [2,4,8,16,17,16,8,256,277,256,17,276,268,276,0,262,260,260,256,1,260,16,16,2,268,17,16,260,276,260,4,16,256,17,277,276]

theorem envBound15829 : H12AffineFastState.Bounded env15829 := by
  intro p hp
  have h : env15829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15828_15829 : H12AffineEnvironment.transform 10 17 env15828 = env15829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env15828 == env15829) = true)

def env15830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10401,1024,32769,4160,62708,120014,98780,8328,65,97546,5392,102878,67618,119042,168,256,98814,90203,63189]

theorem envBound15830 : H12AffineFastState.Bounded env15830 := by
  intro p hp
  have h : env15830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15817_15830 : H12AffineEnvironment.transform 16 13389 env15817 = env15830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env15817 == env15830) = true)

theorem identity15830 : scanCanonicalize (H12AffineFastState.compose env15830 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 41263) := by decide +kernel

theorem selectedBound15830 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env15831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41263,13389,10401,1024,32769,4160,62708,30177,8435,8328,65,56357,5392,12529,43277,28717,168,256,8401,49524,63189]

theorem envBound15831 : H12AffineFastState.Bounded env15831 := by
  intro p hp
  have h : env15831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15830_15831 : H12AffineEnvironment.transform 15 41263 env15830 = env15831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41263 env15830 == env15831) = true)

theorem identity15831 : scanCanonicalize (H12AffineFastState.compose env15831 (packedSelected [2,4,5,6,8,10,14,15,19,20,22,23,24,28,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound15831 : packedSelected [2,4,5,6,8,10,14,15,19,20,22,23,24,28,32,35,38] rootPS < 2^1333 := by decide +kernel

def env15832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,21875,13389,10401,1024,29789,4160,168,30177,8435,8328,65,10361,5392,12529,23889,28717,168,256,8401,13608,649]

theorem envBound15832 : H12AffineFastState.Bounded env15832 := by
  intro p hp
  have h : env15832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15831_15832 : H12AffineEnvironment.transform 14 29788 env15831 = env15832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env15831 == env15832) = true)

theorem identity15832 : scanCanonicalize (H12AffineFastState.compose env15832 (packedSelected [2,6,9,14,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13808) := by decide +kernel

theorem selectedBound15832 : packedSelected [2,6,9,14,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env15833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,428,8323,13389,10401,1024,429,4160,168,17,8435,8328,65,10361,5392,12529,10401,1501,168,256,8401,13608,649]

theorem envBound15833 : H12AffineFastState.Bounded env15833 := by
  intro p hp
  have h : env15833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15832_15833 : H12AffineEnvironment.transform 13 13808 env15832 = env15833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13808 env15832 == env15833) = true)

theorem identity15833 : scanCanonicalize (H12AffineFastState.compose env15833 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15833 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,292,8203,13389,10281,1024,293,4160,32,17,8315,8192,65,10361,5392,12409,10281,1365,32,256,8281,13608,513]

theorem envBound15834 : H12AffineFastState.Bounded env15834 := by
  intro p hp
  have h : env15834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15833_15834 : H12AffineEnvironment.transform 6 8 env15833 = env15834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15833 == env15834) = true)

theorem identity15834 : scanCanonicalize (H12AffineFastState.compose env15834 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound15834 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4404,292,1095,4097,3173,1024,293,4160,32,17,1079,1100,65,3125,5392,5173,3173,1365,32,256,1045,4452,513]

theorem envBound15835 : H12AffineFastState.Bounded env15835 := by
  intro p hp
  have h : env15835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15834_15835 : H12AffineEnvironment.transform 12 1100 env15834 = env15835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env15834 == env15835) = true)

theorem identity15835 : scanCanonicalize (H12AffineFastState.compose env15835 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound15835 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env15836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,1100,4404,292,1095,4097,1,1024,293,4160,32,17,1079,1100,65,81,5392,5173,1,1365,32,256,1045,4452,513]

theorem envBound15836 : H12AffineFastState.Bounded env15836 := by
  intro p hp
  have h : env15836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15835_15836 : H12AffineEnvironment.transform 10 1124 env15835 = env15836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env15835 == env15836) = true)

theorem identity15836 : scanCanonicalize (H12AffineFastState.compose env15836 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound15836 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,1281,1100,1077,292,1095,1280,1,1024,293,1345,32,17,1079,1100,65,81,17,308,1,1365,32,256,1045,1125,513]

theorem envBound15837 : H12AffineFastState.Bounded env15837 := by
  intro p hp
  have h : env15837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15836_15837 : H12AffineEnvironment.transform 11 1281 env15836 = env15837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env15836 == env15837) = true)

theorem identity15837 : scanCanonicalize (H12AffineFastState.compose env15837 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15837 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env15838 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1124,1060,1100,1077,1,1095,1061,1,1024,0,1124,32,17,1079,1100,65,81,17,17,1,1136,32,37,1045,1125,513]

theorem envBound15838 : H12AffineFastState.Bounded env15838 := by
  intro p hp
  have h : env15838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15837_15838 : H12AffineEnvironment.transform 7 37 env15837 = env15838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15837 == env15838) = true)

theorem identity15838 : scanCanonicalize (H12AffineFastState.compose env15838 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound15838 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15839 : List Nat := [2,4,8,16,32,64,8,37,512,111,11,75,35,90,1,40,74,1,111,0,11,32,17,88,35,65,81,17,17,1,31,32,37,122,10,513]

theorem envBound15839 : H12AffineFastState.Bounded env15839 := by
  intro p hp
  have h : env15839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15838_15839 : H12AffineEnvironment.transform 9 111 env15838 = env15839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env15838 == env15839) = true)

theorem identity15839 : scanCanonicalize (H12AffineFastState.compose env15839 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound15839 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15840 : List Nat := [2,4,8,16,32,58,8,37,512,21,11,49,35,32,1,40,48,1,21,0,11,32,17,34,35,59,43,17,17,1,31,32,37,0,10,513]

theorem envBound15840 : H12AffineFastState.Bounded env15840 := by
  intro p hp
  have h : env15840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15839_15840 : H12AffineEnvironment.transform 5 58 env15839 = env15840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env15839 == env15840) = true)

theorem identity15840 : scanCanonicalize (H12AffineFastState.compose env15840 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15840 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env15841 : List Nat := [2,4,8,0,32,42,8,37,512,5,11,33,35,32,1,40,32,1,5,0,11,32,1,34,35,43,43,1,1,1,15,32,37,0,10,513]

theorem envBound15841 : H12AffineFastState.Bounded env15841 := by
  intro p hp
  have h : env15841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15840_15841 : H12AffineEnvironment.transform 3 0 env15840 = env15841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15840 == env15841) = true)

theorem identity15841 : scanCanonicalize (H12AffineFastState.compose env15841 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound15841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15842 : List Nat := [2,4,8,0,32,42,8,37,35,5,11,33,35,32,1,40,32,1,5,0,11,32,1,34,35,43,43,1,1,1,15,32,37,0,10,34]

theorem envBound15842 : H12AffineFastState.Bounded env15842 := by
  intro p hp
  have h : env15842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15841_15842 : H12AffineEnvironment.transform 8 35 env15841 = env15842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env15841 == env15842) = true)

theorem identity15842 : scanCanonicalize (H12AffineFastState.compose env15842 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15842 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15843 : List Nat := [2,4,8,0,1,11,8,4,2,5,11,0,2,1,1,9,1,1,5,0,11,1,1,3,2,10,10,1,1,1,15,1,4,0,10,3]

theorem envBound15843 : H12AffineFastState.Bounded env15843 := by
  intro p hp
  have h : env15843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15842_15843 : H12AffineEnvironment.transform 4 1 env15842 = env15843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15842 == env15843) = true)

theorem identity15843 : scanCanonicalize (H12AffineFastState.compose env15843 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15843 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env15844 : List Nat := [2,4,3,0,1,0,3,4,2,5,0,0,2,1,1,2,1,1,5,0,0,1,1,3,2,1,1,1,1,1,4,1,4,0,1,3]

theorem envBound15844 : H12AffineFastState.Bounded env15844 := by
  intro p hp
  have h : env15844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15843_15844 : H12AffineEnvironment.transform 2 3 env15843 = env15844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15843 == env15844) = true)

theorem identity15844 : scanCanonicalize (H12AffineFastState.compose env15844 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15845 : List Nat := [2,1,3,0,1,0,3,1,2,0,0,0,2,1,1,2,1,1,0,0,0,1,1,3,2,1,1,1,1,1,1,1,1,0,1,3]

theorem envBound15845 : H12AffineFastState.Bounded env15845 := by
  intro p hp
  have h : env15845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15844_15845 : H12AffineEnvironment.transform 1 1 env15844 = env15845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15844 == env15845) = true)

def env15846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509986,498992,8328,65,349611,395773,494899,67618,119042,272392,256,98815,90202,63189]

theorem envBound15846 : H12AffineFastState.Bounded env15846 := by
  intro p hp
  have h : env15846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15815_15846 : H12AffineEnvironment.transform 20 4161 env15815 = env15846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15815 == env15846) = true)

theorem identity15846 : scanCanonicalize (H12AffineFastState.compose env15846 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound15846 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,144493,474358,485860,8328,65,349611,395773,489959,67618,75222,272392,256,95531,90202,513]

theorem envBound15847 : H12AffineFastState.Bounded env15847 := by
  intro p hp
  have h : env15847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15846_15847 : H12AffineEnvironment.transform 14 29908 env15846 = env15847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env15846 == env15847) = true)

def env15848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,474238,485740,8192,65,349475,395637,489839,67618,75102,272392,256,95531,90202,513]

theorem envBound15848 : H12AffineFastState.Bounded env15848 := by
  intro p hp
  have h : env15848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15847_15848 : H12AffineEnvironment.transform 6 8 env15847 = env15848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15847 == env15848) = true)

theorem identity15848 : scanCanonicalize (H12AffineFastState.compose env15848 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound15848 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env15849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1024,29789,4161,144493,213334,201796,8192,65,75787,160861,197703,67618,75102,21792,256,95531,90202,513]

end H12CloudChart0