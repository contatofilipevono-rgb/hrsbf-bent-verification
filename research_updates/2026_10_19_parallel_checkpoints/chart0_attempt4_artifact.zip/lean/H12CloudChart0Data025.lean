import H12CloudChart0Data024

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity6193 : scanCanonicalize (H12AffineFastState.compose env6193 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2728) := by decide +kernel

theorem selectedBound6193 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6194 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1677,8832,8234,1028,2728,1025,8832,1196,512,545,682,8329,545,2697,1677,1573,2561,1025,169,5,544,1197,137]

theorem envBound6194 : H12AffineFastState.Bounded env6194 := by
  intro p hp
  have h : env6194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6193_6194 : H12AffineEnvironment.transform 17 2728 env6193 = env6194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2728 env6193 == env6194) = true)

theorem identity6194 : scanCanonicalize (H12AffineFastState.compose env6194 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound6194 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6195 : List Nat := [2,4,8,0,32,0,128,4,137,1024,2048,1197,8192,1028,8201,8234,1028,2081,1025,8201,1196,137,168,35,8329,168,2048,1028,1196,2184,1025,169,5,169,1197,137]

theorem envBound6195 : H12AffineFastState.Bounded env6195 := by
  intro p hp
  have h : env6195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6194_6195 : H12AffineEnvironment.transform 8 137 env6194 = env6195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env6194 == env6195) = true)

theorem identity6195 : scanCanonicalize (H12AffineFastState.compose env6195 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound6195 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env6196 : List Nat := [2,4,8,0,32,0,128,4,137,47,2048,130,8192,43,8201,8234,43,2081,46,8201,131,137,168,35,8329,168,2048,43,131,2184,46,169,5,169,130,137]

theorem envBound6196 : H12AffineFastState.Bounded env6196 := by
  intro p hp
  have h : env6196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6195_6196 : H12AffineEnvironment.transform 9 47 env6195 = env6196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env6195 == env6196) = true)

theorem identity6196 : scanCanonicalize (H12AffineFastState.compose env6196 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound6196 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6197 : List Nat := [2,4,8,0,32,0,128,4,137,47,2048,130,2,43,11,40,43,2081,46,11,131,137,168,35,139,168,2048,43,131,2184,46,169,5,169,130,137]

theorem envBound6197 : H12AffineFastState.Bounded env6197 := by
  intro p hp
  have h : env6197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6196_6197 : H12AffineEnvironment.transform 12 2 env6196 = env6197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env6196 == env6197) = true)

theorem identity6197 : scanCanonicalize (H12AffineFastState.compose env6197 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6197 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6198 : List Nat := [2,4,2,0,32,0,128,4,131,37,2048,130,2,33,1,34,33,2081,36,1,131,131,162,35,129,162,2048,33,131,2178,36,163,5,163,130,131]

theorem envBound6198 : H12AffineFastState.Bounded env6198 := by
  intro p hp
  have h : env6198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6197_6198 : H12AffineEnvironment.transform 2 2 env6197 = env6198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6197 == env6198) = true)

theorem identity6198 : scanCanonicalize (H12AffineFastState.compose env6198 (packedSelected [1,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6198 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env6199 : List Nat := [2,4,2,0,1,0,128,4,131,4,2048,130,2,0,1,3,0,2048,5,1,131,131,131,2,129,131,2048,0,131,2178,5,130,5,130,130,131]

theorem envBound6199 : H12AffineFastState.Bounded env6199 := by
  intro p hp
  have h : env6199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6198_6199 : H12AffineEnvironment.transform 4 1 env6198 = env6199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6198 == env6199) = true)

theorem identity6199 : scanCanonicalize (H12AffineFastState.compose env6199 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound6199 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6200 : List Nat := [2,4,2,0,1,0,128,4,131,4,130,130,2,0,1,3,0,130,5,1,131,131,131,2,129,131,130,0,131,0,5,130,5,130,130,131]

theorem envBound6200 : H12AffineFastState.Bounded env6200 := by
  intro p hp
  have h : env6200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6199_6200 : H12AffineEnvironment.transform 10 130 env6199 = env6200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env6199 == env6200) = true)

def env6201 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50467,1028,262144,1025,32768,1448,41089,41120,41002,8329,41120,320808,16384,16812,19848,57608,58532,257,17833,1448,41740]

theorem envBound6201 : H12AffineFastState.Bounded env6201 := by
  intro p hp
  have h : env6201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6189_6201 : H12AffineEnvironment.transform 21 41089 env6189 = env6201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6189 == env6201) = true)

theorem identity6201 : scanCanonicalize (H12AffineFastState.compose env6201 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6201 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6202 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,8201,25898,1028,262144,1025,8201,1448,136,169,35,8329,169,279841,16384,16812,19848,16641,17581,257,17833,1448,773]

theorem envBound6202 : H12AffineFastState.Bounded env6202 := by
  intro p hp
  have h : env6202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6201_6202 : H12AffineEnvironment.transform 14 8201 env6201 = env6202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6201 == env6202) = true)

theorem identity6202 : scanCanonicalize (H12AffineFastState.compose env6202 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20140) := by decide +kernel

theorem selectedBound6202 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6203 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,8201,25898,1028,20140,1025,8201,1448,136,169,35,8329,169,2957,16384,16812,19848,16641,17581,257,17833,1448,773]

theorem envBound6203 : H12AffineFastState.Bounded env6203 := by
  intro p hp
  have h : env6203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6202_6203 : H12AffineEnvironment.transform 17 20140 env6202 = env6203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20140 env6202 == env6203) = true)

theorem identity6203 : scanCanonicalize (H12AffineFastState.compose env6203 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound6203 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env6204 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,1573,8201,8975,1028,2185,1025,8201,1448,136,169,35,8329,169,2957,1573,1929,2989,1828,648,257,908,1448,773]

theorem envBound6204 : H12AffineFastState.Bounded env6204 := by
  intro p hp
  have h : env6204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6203_6204 : H12AffineEnvironment.transform 13 1573 env6203 = env6204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env6203 == env6204) = true)

theorem identity6204 : scanCanonicalize (H12AffineFastState.compose env6204 (packedSelected [1,2,4,8,9,10,11,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound6204 : packedSelected [1,2,4,8,9,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env6205 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,2348,1573,2341,2595,1028,2185,1025,2341,1448,136,169,35,2469,169,2957,1573,1929,2989,1828,648,257,908,1448,773]

theorem envBound6205 : H12AffineFastState.Bounded env6205 := by
  intro p hp
  have h : env6205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6204_6205 : H12AffineEnvironment.transform 12 2348 env6204 = env6205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env6204 == env6205) = true)

theorem identity6205 : scanCanonicalize (H12AffineFastState.compose env6205 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6205 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6206 : List Nat := [2,4,8,0,32,0,128,5,512,1024,2048,1196,2089,1573,2080,2595,1028,2185,1025,2080,1197,136,169,35,2208,169,2696,1573,1676,2728,1569,648,4,649,1197,512]

theorem envBound6206 : H12AffineFastState.Bounded env6206 := by
  intro p hp
  have h : env6206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6205_6206 : H12AffineEnvironment.transform 7 5 env6205 = env6206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6205 == env6206) = true)

theorem identity6206 : scanCanonicalize (H12AffineFastState.compose env6206 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound6206 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6207 : List Nat := [2,4,8,0,32,0,128,5,168,1024,2048,1196,2089,1165,2080,2187,1028,2185,1025,2080,1197,136,169,35,2208,169,2080,1165,1060,2048,1161,32,4,33,1197,168]

theorem envBound6207 : H12AffineFastState.Bounded env6207 := by
  intro p hp
  have h : env6207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6206_6207 : H12AffineEnvironment.transform 8 168 env6206 = env6207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env6206 == env6207) = true)

theorem identity6207 : scanCanonicalize (H12AffineFastState.compose env6207 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound6207 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6208 : List Nat := [2,4,8,0,32,0,128,5,168,141,2048,33,2089,0,2080,2187,137,2185,140,2080,32,136,169,35,2208,169,2080,0,169,2048,4,32,4,33,32,168]

theorem envBound6208 : H12AffineFastState.Bounded env6208 := by
  intro p hp
  have h : env6208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6207_6208 : H12AffineEnvironment.transform 9 141 env6207 = env6208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env6207 == env6208) = true)

theorem identity6208 : scanCanonicalize (H12AffineFastState.compose env6208 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6208 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6209 : List Nat := [2,4,2,0,32,0,128,5,162,135,2048,33,2083,0,2080,2177,131,2179,134,2080,32,130,163,35,2208,163,2080,0,163,2048,4,32,4,33,32,162]

theorem envBound6209 : H12AffineFastState.Bounded env6209 := by
  intro p hp
  have h : env6209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6208_6209 : H12AffineEnvironment.transform 2 2 env6208 = env6209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6208 == env6209) = true)

theorem identity6209 : scanCanonicalize (H12AffineFastState.compose env6209 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound6209 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6210 : List Nat := [2,4,2,0,32,0,128,5,162,135,163,33,128,0,131,34,131,32,134,131,32,130,163,35,3,163,131,0,163,163,4,32,4,33,32,162]

theorem envBound6210 : H12AffineFastState.Bounded env6210 := by
  intro p hp
  have h : env6210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6209_6210 : H12AffineEnvironment.transform 10 163 env6209 = env6210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env6209 == env6210) = true)

theorem identity6210 : scanCanonicalize (H12AffineFastState.compose env6210 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound6210 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6211 : List Nat := [2,4,2,0,32,0,2,5,32,5,33,33,2,0,1,34,1,32,4,1,32,0,33,35,3,33,1,0,33,33,4,32,4,33,32,32]

theorem envBound6211 : H12AffineFastState.Bounded env6211 := by
  intro p hp
  have h : env6211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6210_6211 : H12AffineEnvironment.transform 6 2 env6210 = env6211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env6210 == env6211) = true)

theorem identity6211 : scanCanonicalize (H12AffineFastState.compose env6211 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6211 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env6212 : List Nat := [2,4,2,0,1,0,2,5,1,5,0,0,2,0,1,3,1,1,4,1,1,0,0,2,3,0,1,0,0,0,4,1,4,0,1,1]

theorem envBound6212 : H12AffineFastState.Bounded env6212 := by
  intro p hp
  have h : env6212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6211_6212 : H12AffineEnvironment.transform 4 1 env6211 = env6212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6211 == env6212) = true)

def env6213 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,32768,50466,1028,262144,1025,32768,1448,4194304,4194336,41002,8329,4194336,320808,16384,16812,19848,57609,58532,257,17833,4236585,4195213]

theorem envBound6213 : H12AffineFastState.Bounded env6213 := by
  intro p hp
  have h : env6213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6188_6213 : H12AffineEnvironment.transform 3 1 env6188 = env6213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6188 == env6213) = true)

theorem identity6213 : scanCanonicalize (H12AffineFastState.compose env6213 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound6213 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6214 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8461,25647,1028,262144,1025,8461,1448,4194304,4194336,295,8329,4194336,279589,16384,16812,19848,16388,17833,257,17833,4195364,4195213]

theorem envBound6214 : H12AffineFastState.Bounded env6214 := by
  intro p hp
  have h : env6214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6213_6214 : H12AffineEnvironment.transform 14 8461 env6213 = env6214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env6213 == env6214) = true)

theorem identity6214 : scanCanonicalize (H12AffineFastState.compose env6214 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6214 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6215 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1197,8192,16384,8201,25647,1028,262144,1025,8201,1196,4194304,4194336,35,8329,4194336,279589,16384,16552,19596,16388,17581,5,17581,4195364,4194953]

theorem envBound6215 : H12AffineFastState.Bounded env6215 := by
  intro p hp
  have h : env6215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6214_6215 : H12AffineEnvironment.transform 7 4 env6214 = env6215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6214 == env6215) = true)

theorem identity6215 : scanCanonicalize (H12AffineFastState.compose env6215 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6215 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6216 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1197,8192,16384,8201,25647,1028,2184,1025,8201,1196,4194304,4194336,35,8329,4194336,19629,16384,16552,19596,16388,17581,5,17581,4195364,4194953]

theorem envBound6216 : H12AffineFastState.Bounded env6216 := by
  intro p hp
  have h : env6216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6215_6216 : H12AffineEnvironment.transform 17 2184 env6215 = env6216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6215 == env6216) = true)

theorem identity6216 : scanCanonicalize (H12AffineFastState.compose env6216 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6216 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6217 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1164,8192,16384,8201,25614,1028,2184,1025,8201,1165,4194304,4194305,2,8329,4194305,19596,16384,16521,19596,16388,17548,5,17548,4195333,4194953]

theorem envBound6217 : H12AffineFastState.Bounded env6217 := by
  intro p hp
  have h : env6217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6216_6217 : H12AffineEnvironment.transform 4 1 env6216 = env6217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6216 == env6217) = true)

theorem identity6217 : scanCanonicalize (H12AffineFastState.compose env6217 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 10243) := by decide +kernel

theorem selectedBound6217 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6218 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1164,8192,16384,8201,25614,1028,2184,1025,8201,1165,10243,10242,2,8329,10242,19596,16384,16521,19596,16388,17548,5,17548,11270,10890]

theorem envBound6218 : H12AffineFastState.Bounded env6218 := by
  intro p hp
  have h : env6218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6217_6218 : H12AffineEnvironment.transform 21 10243 env6217 = env6218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10243 env6217 == env6218) = true)

theorem identity6218 : scanCanonicalize (H12AffineFastState.compose env6218 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6218 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6219 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,8192,16384,8201,25614,1028,2048,1025,8201,1029,10243,10242,2,8193,10242,19460,16384,16385,19460,16388,17412,5,17412,11270,10754]

theorem envBound6219 : H12AffineFastState.Bounded env6219 := by
  intro p hp
  have h : env6219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6218_6219 : H12AffineEnvironment.transform 6 8 env6218 = env6219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6218 == env6219) = true)

theorem identity6219 : scanCanonicalize (H12AffineFastState.compose env6219 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound6219 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6220 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,2563,16384,2570,19981,1028,2048,1025,2570,1029,512,513,2,2562,513,19460,16384,16385,19460,16388,17412,5,17412,1541,1]

theorem envBound6220 : H12AffineFastState.Bounded env6220 := by
  intro p hp
  have h : env6220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6219_6220 : H12AffineEnvironment.transform 12 2563 env6219 = env6220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env6219 == env6220) = true)

theorem identity6220 : scanCanonicalize (H12AffineFastState.compose env6220 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6220 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6221 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,2563,1028,2570,2569,1028,2048,1025,2570,1029,512,513,2,2562,513,2048,1028,1029,2048,1024,0,5,0,1541,1]

theorem envBound6221 : H12AffineFastState.Bounded env6221 := by
  intro p hp
  have h : env6221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6220_6221 : H12AffineEnvironment.transform 13 1028 env6220 = env6221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env6220 == env6221) = true)

theorem identity6221 : scanCanonicalize (H12AffineFastState.compose env6221 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound6221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6222 : List Nat := [2,4,8,1,1,1,8,4,512,1024,1039,1028,1548,1028,1541,1542,1028,1039,1025,1541,1029,512,513,2,1549,513,1039,1028,1029,1039,1024,0,5,0,1541,1]

theorem envBound6222 : H12AffineFastState.Bounded env6222 := by
  intro p hp
  have h : env6222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6221_6222 : H12AffineEnvironment.transform 10 1039 env6221 = env6222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env6221 == env6222) = true)

theorem identity6222 : scanCanonicalize (H12AffineFastState.compose env6222 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6222 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6223 : List Nat := [2,4,8,1,1,1,8,4,11,1024,1039,1028,1031,1028,1038,1037,1028,1039,1025,1038,1029,11,10,2,1030,10,1039,1028,1029,1039,1024,0,5,0,1038,1]

theorem envBound6223 : H12AffineFastState.Bounded env6223 := by
  intro p hp
  have h : env6223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6222_6223 : H12AffineEnvironment.transform 8 11 env6222 = env6223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6222 == env6223) = true)

theorem identity6223 : scanCanonicalize (H12AffineFastState.compose env6223 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6223 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6224 : List Nat := [2,4,3,1,1,1,3,4,0,1024,1028,1028,1031,1028,1029,1030,1028,1028,1025,1029,1029,0,1,2,1030,1,1028,1028,1029,1028,1024,0,5,0,1029,1]

theorem envBound6224 : H12AffineFastState.Bounded env6224 := by
  intro p hp
  have h : env6224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6223_6224 : H12AffineEnvironment.transform 2 3 env6223 = env6224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6223 == env6224) = true)

theorem identity6224 : scanCanonicalize (H12AffineFastState.compose env6224 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound6224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6225 : List Nat := [2,4,3,1,1,1,3,4,0,0,4,4,7,4,5,6,4,4,1,5,5,0,1,2,6,1,4,4,5,4,0,0,5,0,5,1]

theorem envBound6225 : H12AffineFastState.Bounded env6225 := by
  intro p hp
  have h : env6225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6224_6225 : H12AffineEnvironment.transform 9 0 env6224 = env6225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env6224 == env6225) = true)

theorem identity6225 : scanCanonicalize (H12AffineFastState.compose env6225 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6225 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6226 : List Nat := [2,1,3,1,1,1,3,1,0,0,1,1,2,1,0,3,1,1,1,0,0,0,1,2,3,1,1,1,0,1,0,0,0,0,0,1]

theorem envBound6226 : H12AffineFastState.Bounded env6226 := by
  intro p hp
  have h : env6226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6225_6226 : H12AffineEnvironment.transform 1 1 env6225 = env6226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6225 == env6226) = true)

def env6227 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4310275,41002,8329,4310274,323712,16384,16813,22560,74795,78911,257,20481,4239488,4310718]

theorem envBound6227 : H12AffineFastState.Bounded env6227 := by
  intro p hp
  have h : env6227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6156_6227 : H12AffineEnvironment.transform 5 17 env6156 = env6227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6156 == env6227) = true)

theorem identity6227 : scanCanonicalize (H12AffineFastState.compose env6227 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115902) := by decide +kernel

theorem selectedBound6227 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115902,445,41002,8329,444,323712,16384,16813,22560,74795,78911,257,20481,95294,512]

theorem envBound6228 : H12AffineFastState.Bounded env6228 := by
  intro p hp
  have h : env6228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6227_6228 : H12AffineEnvironment.transform 21 115902 env6227 = env6228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115902 env6227 == env6228) = true)

theorem identity6228 : scanCanonicalize (H12AffineFastState.compose env6228 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound6228 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6229 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1025,32768,4097,41348,445,41002,8329,444,323712,16384,16813,22560,16657,20741,257,20481,4356,512]

theorem envBound6229 : H12AffineFastState.Bounded env6229 := by
  intro p hp
  have h : env6229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6228_6229 : H12AffineEnvironment.transform 15 25914 env6228 = env6229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env6228 == env6229) = true)

theorem identity6229 : scanCanonicalize (H12AffineFastState.compose env6229 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6229 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6230 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25914,4524,262144,1025,26261,4097,18193,445,18111,8329,444,267797,16384,16813,22560,16657,20741,257,20481,4356,512]

theorem envBound6230 : H12AffineFastState.Bounded env6230 := by
  intro p hp
  have h : env6230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6229_6230 : H12AffineEnvironment.transform 14 26261 env6229 = env6230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6229 == env6230) = true)

theorem identity6230 : scanCanonicalize (H12AffineFastState.compose env6230 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound6230 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6231 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25914,1045,262144,1025,26261,1464,18193,445,18111,8329,444,263084,16384,16813,19865,16657,17596,257,17848,1213,512]

theorem envBound6231 : H12AffineFastState.Bounded env6231 := by
  intro p hp
  have h : env6231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6230_6231 : H12AffineEnvironment.transform 11 1465 env6230 = env6231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env6230 == env6231) = true)

theorem identity6231 : scanCanonicalize (H12AffineFastState.compose env6231 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6231 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6232 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25914,1045,2341,1025,26261,1464,18193,445,18111,8329,444,2697,16384,16813,19865,16657,17596,257,17848,1213,512]

theorem envBound6232 : H12AffineFastState.Bounded env6232 := by
  intro p hp
  have h : env6232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6231_6232 : H12AffineEnvironment.transform 17 2341 env6231 = env6232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6231 == env6232) = true)

theorem identity6232 : scanCanonicalize (H12AffineFastState.compose env6232 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound6232 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1841,8612,8715,1045,2341,1025,8612,1464,32,445,398,8329,444,2697,1841,1692,2728,1568,909,257,649,1213,512]

theorem envBound6233 : H12AffineFastState.Bounded env6233 := by
  intro p hp
  have h : env6233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6232_6233 : H12AffineEnvironment.transform 13 1841 env6232 = env6233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env6232 == env6233) = true)

theorem identity6233 : scanCanonicalize (H12AffineFastState.compose env6233 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6233 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6234 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1693,8200,8715,1045,2185,1025,8200,1044,32,17,34,8329,16,2697,1693,1692,2728,1568,545,173,649,1213,512]

theorem envBound6234 : H12AffineFastState.Bounded env6234 := by
  intro p hp
  have h : env6234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6233_6234 : H12AffineEnvironment.transform 7 172 env6233 = env6234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6233 == env6234) = true)

theorem identity6234 : scanCanonicalize (H12AffineFastState.compose env6234 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound6234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6235 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1045,8192,1693,8200,8715,1045,1583,1025,8200,1044,32,17,34,8329,16,1071,1693,1692,1038,1568,545,173,649,1213,512]

theorem envBound6235 : H12AffineFastState.Bounded env6235 := by
  intro p hp
  have h : env6235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6234_6235 : H12AffineEnvironment.transform 10 1702 env6234 = env6235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env6234 == env6235) = true)

theorem identity6235 : scanCanonicalize (H12AffineFastState.compose env6235 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1711) := by decide +kernel

theorem selectedBound6235 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env6236 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1045,1711,1693,1703,1188,1045,1583,1025,1703,1044,32,17,34,1574,16,1071,1693,1692,1038,1568,545,173,649,1213,512]

theorem envBound6236 : H12AffineFastState.Bounded env6236 := by
  intro p hp
  have h : env6236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6235_6236 : H12AffineEnvironment.transform 12 1711 env6235 = env6236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1711 env6235 == env6236) = true)

theorem identity6236 : scanCanonicalize (H12AffineFastState.compose env6236 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound6236 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6237 : List Nat := [2,4,8,16,32,17,128,172,512,646,32,659,41,27,33,546,659,169,647,33,658,32,17,34,160,16,681,27,26,648,166,545,173,649,571,512]

theorem envBound6237 : H12AffineFastState.Bounded env6237 := by
  intro p hp
  have h : env6237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6236_6237 : H12AffineEnvironment.transform 9 646 env6236 = env6237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env6236 == env6237) = true)

theorem identity6237 : scanCanonicalize (H12AffineFastState.compose env6237 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound6237 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env6238 : List Nat := [2,4,8,16,32,17,18,62,512,532,32,513,41,27,33,546,513,59,533,33,512,32,17,34,50,16,571,27,26,538,52,545,63,539,571,512]

theorem envBound6238 : H12AffineFastState.Bounded env6238 := by
  intro p hp
  have h : env6238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6237_6238 : H12AffineEnvironment.transform 6 18 env6237 = env6238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env6237 == env6238) = true)

theorem identity6238 : scanCanonicalize (H12AffineFastState.compose env6238 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound6238 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6239 : List Nat := [2,4,8,16,32,17,18,62,59,47,32,58,41,27,33,25,58,59,46,33,59,32,17,34,50,16,0,27,26,33,52,26,63,32,0,59]

theorem envBound6239 : H12AffineFastState.Bounded env6239 := by
  intro p hp
  have h : env6239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6238_6239 : H12AffineEnvironment.transform 8 59 env6238 = env6239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env6238 == env6239) = true)

theorem identity6239 : scanCanonicalize (H12AffineFastState.compose env6239 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6239 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6240 : List Nat := [2,4,8,16,0,17,18,30,27,15,0,26,9,27,1,25,26,27,14,1,27,0,17,2,18,16,0,27,26,1,20,26,31,0,0,27]

theorem envBound6240 : H12AffineFastState.Bounded env6240 := by
  intro p hp
  have h : env6240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6239_6240 : H12AffineEnvironment.transform 4 0 env6239 = env6240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6239 == env6240) = true)

def env6241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,77914241,76039249,76039597,77613089,75572347,73983341,525568,77611008,82355408,8914925]

theorem envBound6241 : H12AffineFastState.Bounded env6241 := by
  intro p hp
  have h : env6241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5715_6241 : H12AffineEnvironment.transform 26 77914241 env5715 = env6241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914241 env5715 == env6241) = true)

def env6242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914000,2942161,16385,16893,2641009,598059,14737725,525568,2638928,6332544,8914925]

theorem envBound6242 : H12AffineFastState.Bounded env6242 := by
  intro p hp
  have h : env6242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6241_6242 : H12AffineEnvironment.transform 25 8914000 env6241 = env6242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env6241 == env6242) = true)

def env6243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849105,16385,16893,547953,598059,12644669,525568,545872,4239488,8914925]

theorem envBound6243 : H12AffineFastState.Bounded env6243 := by
  intro p hp
  have h : env6243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6242_6243 : H12AffineEnvironment.transform 20 4096 env6242 = env6243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env6242 == env6243) = true)

def env6244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323793,16385,16893,22641,74795,12644669,256,20560,4239488,8389613]

theorem envBound6244 : H12AffineFastState.Bounded env6244 := by
  intro p hp
  have h : env6244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6243_6244 : H12AffineEnvironment.transform 18 1024 env6243 = env6244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6243 == env6244) = true)

theorem identity6244 : scanCanonicalize (H12AffineFastState.compose env6244 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91350) := by decide +kernel

theorem selectedBound6244 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,91350,41002,8329,91270,323793,16385,16893,22641,74795,4298219,256,20560,4239488,91963]

theorem envBound6245 : H12AffineFastState.Bounded env6245 := by
  intro p hp
  have h : env6245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6244_6245 : H12AffineEnvironment.transform 22 91350 env6244 = env6245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91350 env6244 == env6245) = true)

def env6246 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,91270,41002,8329,91270,323713,16385,16813,22561,74795,4298171,256,20480,4239488,91963]

theorem envBound6246 : H12AffineFastState.Bounded env6246 := by
  intro p hp
  have h : env6246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6245_6246 : H12AffineEnvironment.transform 5 16 env6245 = env6246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6245 == env6246) = true)

def env6247 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46480,91270,41002,8329,91270,323713,16385,16813,22561,74795,73771,256,20480,1296,91963]

theorem envBound6247 : H12AffineFastState.Bounded env6247 := by
  intro p hp
  have h : env6247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6246_6247 : H12AffineEnvironment.transform 21 46480 env6246 = env6247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46480 env6246 == env6247) = true)

theorem identity6247 : scanCanonicalize (H12AffineFastState.compose env6247 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 38195) := by decide +kernel

theorem selectedBound6247 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6248 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,38195,4525,262144,1024,32768,4096,46480,61877,41002,8329,61877,323713,16385,16813,22561,45336,46360,256,20480,1296,61960]

theorem envBound6248 : H12AffineFastState.Bounded env6248 := by
  intro p hp
  have h : env6248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6247_6248 : H12AffineEnvironment.transform 15 38195 env6247 = env6248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38195 env6247 == env6248) = true)

theorem identity6248 : scanCanonicalize (H12AffineFastState.compose env6248 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 63545) := by decide +kernel

theorem selectedBound6248 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6249 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,38195,4525,63545,1024,32768,4096,46480,61877,41002,8329,61877,2232,16385,16813,22561,45336,46360,256,20480,1296,61960]

theorem envBound6249 : H12AffineFastState.Bounded env6249 := by
  intro p hp
  have h : env6249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6248_6249 : H12AffineEnvironment.transform 17 63545 env6248 = env6249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63545 env6248 == env6249) = true)

theorem identity6249 : scanCanonicalize (H12AffineFastState.compose env6249 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound6249 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6250 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,33063,1465,60461,1024,32768,1044,41348,58785,41002,8329,58785,2232,16385,16813,19509,42252,41228,256,17428,1296,58908]

theorem envBound6250 : H12AffineFastState.Bounded env6250 := by
  intro p hp
  have h : env6250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6249_6250 : H12AffineEnvironment.transform 11 1044 env6249 = env6250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env6249 == env6250) = true)

theorem identity6250 : scanCanonicalize (H12AffineFastState.compose env6250 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28183) := by decide +kernel

theorem selectedBound6250 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env6251 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,28183,28464,1465,570,1024,28183,1044,20371,2998,20029,8329,2998,2232,16385,16813,19509,19227,20251,256,17428,1296,2059]

theorem envBound6251 : H12AffineFastState.Bounded env6251 := by
  intro p hp
  have h : env6251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6250_6251 : H12AffineEnvironment.transform 14 28183 env6250 = env6251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28183 env6250 == env6251) = true)

theorem identity6251 : scanCanonicalize (H12AffineFastState.compose env6251 (packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound6251 : packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS < 2^1333 := by decide +kernel

def env6252 : List Nat := [2,4,8,16,32,16,128,256,512,1024,523,1044,8192,16384,25628,25915,1465,570,1024,25628,1044,17816,445,17462,8329,445,691,16385,16813,17982,16656,17680,256,17428,1296,512]

theorem envBound6252 : H12AffineFastState.Bounded env6252 := by
  intro p hp
  have h : env6252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6251_6252 : H12AffineEnvironment.transform 10 523 env6251 = env6252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env6251 == env6252) = true)

theorem identity6252 : scanCanonicalize (H12AffineFastState.compose env6252 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6252 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6253 : List Nat := [2,4,8,16,32,16,128,172,512,1024,523,1044,8192,16384,25628,25751,1045,570,1024,25628,1044,17460,17,17462,8329,17,691,16385,16385,17982,16572,17596,172,17428,1212,512]

theorem envBound6253 : H12AffineFastState.Bounded env6253 := by
  intro p hp
  have h : env6253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6252_6253 : H12AffineEnvironment.transform 7 172 env6252 = env6253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6252 == env6253) = true)

theorem identity6253 : scanCanonicalize (H12AffineFastState.compose env6253 (packedSelected [1,3,6,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6253 : packedSelected [1,3,6,12,15] rootPS < 2^1333 := by decide +kernel

def env6254 : List Nat := [2,4,8,16,32,16,40,4,512,1024,523,1044,8192,16384,25628,25663,1045,570,1024,25628,1044,17460,17,17462,8225,17,539,16385,16385,17982,16404,17428,4,17428,1044,512]

theorem envBound6254 : H12AffineFastState.Bounded env6254 := by
  intro p hp
  have h : env6254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6253_6254 : H12AffineEnvironment.transform 6 40 env6253 = env6254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6253 == env6254) = true)

theorem identity6254 : scanCanonicalize (H12AffineFastState.compose env6254 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound6254 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6255 : List Nat := [2,4,8,16,32,16,40,4,512,1024,523,1044,8192,1572,8760,8731,1045,570,1024,8760,1044,528,17,530,8225,17,539,1573,1573,26,1584,560,4,560,1044,512]

theorem envBound6255 : H12AffineFastState.Bounded env6255 := by
  intro p hp
  have h : env6255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6254_6255 : H12AffineEnvironment.transform 13 1572 env6254 = env6255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env6254 == env6255) = true)

theorem identity6255 : scanCanonicalize (H12AffineFastState.compose env6255 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound6255 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6256 : List Nat := [2,4,8,16,32,16,40,4,512,1024,523,1044,19,1572,555,520,1045,570,1024,555,1044,528,17,530,50,17,539,1573,1573,26,1584,560,4,560,1044,512]

theorem envBound6256 : H12AffineFastState.Bounded env6256 := by
  intro p hp
  have h : env6256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6255_6256 : H12AffineEnvironment.transform 12 19 env6255 = env6256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env6255 == env6256) = true)

theorem identity6256 : scanCanonicalize (H12AffineFastState.compose env6256 (packedSelected [1,2,3,4,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6256 : packedSelected [1,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env6257 : List Nat := [2,4,8,16,32,16,40,4,33,1024,42,1044,19,1029,10,41,1045,27,1024,10,1044,49,17,51,50,17,58,1028,1028,26,1041,17,4,17,1044,33]

theorem envBound6257 : H12AffineFastState.Bounded env6257 := by
  intro p hp
  have h : env6257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6256_6257 : H12AffineEnvironment.transform 8 33 env6256 = env6257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6256 == env6257) = true)

theorem identity6257 : scanCanonicalize (H12AffineFastState.compose env6257 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6257 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env6258 : List Nat := [2,4,8,11,32,11,40,4,33,1024,42,1039,8,1029,10,41,1038,0,1024,10,1039,42,10,40,41,10,33,1028,1028,1,1034,10,4,10,1039,33]

theorem envBound6258 : H12AffineFastState.Bounded env6258 := by
  intro p hp
  have h : env6258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6257_6258 : H12AffineEnvironment.transform 3 11 env6257 = env6258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6257 == env6258) = true)

theorem identity6258 : scanCanonicalize (H12AffineFastState.compose env6258 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6258 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6259 : List Nat := [2,4,8,11,32,11,40,4,33,14,42,1,8,11,10,41,0,0,14,10,1,42,10,40,41,10,33,10,10,1,4,10,4,10,1,33]

theorem envBound6259 : H12AffineFastState.Bounded env6259 := by
  intro p hp
  have h : env6259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6258_6259 : H12AffineEnvironment.transform 9 14 env6258 = env6259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6258 == env6259) = true)

def env6260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46481,91270,41002,8329,91270,323713,16385,16813,22561,74795,73770,256,20480,1297,91963]

theorem envBound6260 : H12AffineFastState.Bounded env6260 := by
  intro p hp
  have h : env6260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6246_6260 : H12AffineEnvironment.transform 21 46481 env6246 = env6260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46481 env6246 == env6260) = true)

theorem identity6260 : scanCanonicalize (H12AffineFastState.compose env6260 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6260 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6261 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,46393,91182,41002,8225,91182,323625,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound6261 : H12AffineFastState.Bounded env6261 := by
  intro p hp
  have h : env6261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6260_6261 : H12AffineEnvironment.transform 6 40 env6260 = env6261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6260 == env6261) = true)

theorem identity6261 : scanCanonicalize (H12AffineFastState.compose env6261 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6261 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6262 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8201,65536,4357,262144,1024,8201,4096,5424,91182,35,8225,91182,282656,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound6262 : H12AffineFastState.Bounded env6262 := by
  intro p hp
  have h : env6262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6261_6262 : H12AffineEnvironment.transform 14 8201 env6261 = env6262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6261 == env6262) = true)

theorem identity6262 : scanCanonicalize (H12AffineFastState.compose env6262 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6262 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6263 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8201,65536,4357,2081,1024,8201,4096,5424,91182,35,8225,91182,22529,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound6263 : H12AffineFastState.Bounded env6263 := by
  intro p hp
  have h : env6263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6262_6263 : H12AffineEnvironment.transform 17 2081 env6262 = env6263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6262 == env6263) = true)

theorem identity6263 : scanCanonicalize (H12AffineFastState.compose env6263 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6263 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6264 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8201,65536,4357,2081,1024,8201,4096,5424,78863,35,8225,78863,2080,4128,4388,2048,74795,73770,256,33,1297,79642]

theorem envBound6264 : H12AffineFastState.Bounded env6264 := by
  intro p hp
  have h : env6264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6263_6264 : H12AffineEnvironment.transform 13 4129 env6263 = env6264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6263 == env6264) = true)

theorem identity6264 : scanCanonicalize (H12AffineFastState.compose env6264 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound6264 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6265 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,2088,4129,2081,65536,4357,2081,1024,2081,4096,5424,72743,35,2057,72743,2080,4128,4388,2048,68611,67586,256,33,1297,73522]

theorem envBound6265 : H12AffineFastState.Bounded env6265 := by
  intro p hp
  have h : env6265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6264_6265 : H12AffineEnvironment.transform 12 2088 env6264 = env6265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env6264 == env6265) = true)

theorem identity6265 : scanCanonicalize (H12AffineFastState.compose env6265 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4611) := by decide +kernel

theorem selectedBound6265 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6266 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,2088,4129,2081,4611,4357,2081,1024,2081,4096,5424,3620,35,2057,3620,2080,4128,4388,2048,7680,6657,256,33,1297,3377]

theorem envBound6266 : H12AffineFastState.Bounded env6266 := by
  intro p hp
  have h : env6266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6265_6266 : H12AffineEnvironment.transform 15 4611 env6265 = env6266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4611 env6265 == env6266) = true)

theorem identity6266 : scanCanonicalize (H12AffineFastState.compose env6266 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6266 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6267 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,2088,4129,2081,4611,4097,2081,1024,2081,4096,5172,3620,35,2057,3620,2080,4128,4128,2048,7680,6657,4,33,1045,3125]

theorem envBound6267 : H12AffineFastState.Bounded env6267 := by
  intro p hp
  have h : env6267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6266_6267 : H12AffineEnvironment.transform 7 4 env6266 = env6267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6266 == env6267) = true)

theorem identity6267 : scanCanonicalize (H12AffineFastState.compose env6267 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6268 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1038,2088,1071,2081,1549,1039,2081,1024,2081,1038,58,3620,35,2057,3620,2080,1070,1070,2048,2574,3599,4,33,1045,3125]

theorem envBound6268 : H12AffineFastState.Bounded env6268 := by
  intro p hp
  have h : env6268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6267_6268 : H12AffineEnvironment.transform 11 1038 env6267 = env6268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env6267 == env6268) = true)

theorem identity6268 : scanCanonicalize (H12AffineFastState.compose env6268 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound6268 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6269 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1582,1038,1542,1071,1551,1549,1039,1551,1024,1551,1038,58,10,35,1575,10,1550,1070,1070,1582,1056,33,4,33,1045,539]

theorem envBound6269 : H12AffineFastState.Bounded env6269 := by
  intro p hp
  have h : env6269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6268_6269 : H12AffineEnvironment.transform 10 1582 env6268 = env6269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env6268 == env6269) = true)

def env6270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,91271,41002,8329,91270,323712,16385,16812,22560,74795,4298170,256,20481,4239488,91963]

theorem envBound6270 : H12AffineFastState.Bounded env6270 := by
  intro p hp
  have h : env6270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6245_6270 : H12AffineEnvironment.transform 5 17 env6245 = env6270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6245 == env6270) = true)

theorem identity6270 : scanCanonicalize (H12AffineFastState.compose env6270 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound6270 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6271 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1024,32768,4096,4194304,444,41002,8329,445,323712,16385,16812,22560,16656,4255873,256,20481,4239488,512]

theorem envBound6271 : H12AffineFastState.Bounded env6271 := by
  intro p hp
  have h : env6271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6270_6271 : H12AffineEnvironment.transform 15 25915 env6270 = env6271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env6270 == env6271) = true)

theorem identity6271 : scanCanonicalize (H12AffineFastState.compose env6271 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6271 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6272 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1024,32768,4096,41349,444,41002,8329,445,323712,16385,16812,22560,16656,20740,256,20481,4357,512]

theorem envBound6272 : H12AffineFastState.Bounded env6272 := by
  intro p hp
  have h : env6272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6271_6272 : H12AffineEnvironment.transform 21 41349 env6271 = env6272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6271 == env6272) = true)

theorem identity6272 : scanCanonicalize (H12AffineFastState.compose env6272 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6272 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6273 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25915,4524,262144,1024,26261,4096,18192,444,18111,8329,445,267797,16385,16812,22560,16656,20740,256,20481,4357,512]

theorem envBound6273 : H12AffineFastState.Bounded env6273 := by
  intro p hp
  have h : env6273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6272_6273 : H12AffineEnvironment.transform 14 26261 env6272 = env6273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6272 == env6273) = true)

theorem identity6273 : scanCanonicalize (H12AffineFastState.compose env6273 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound6273 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25915,1045,262144,1024,26261,1465,18192,444,18111,8329,445,263084,16385,16812,19865,16656,17597,256,17848,1212,512]

theorem envBound6274 : H12AffineFastState.Bounded env6274 := by
  intro p hp
  have h : env6274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6273_6274 : H12AffineEnvironment.transform 11 1465 env6273 = env6274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env6273 == env6274) = true)

theorem identity6274 : scanCanonicalize (H12AffineFastState.compose env6274 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound6274 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25915,1045,2340,1024,26261,1465,18192,444,18111,8329,445,2696,16385,16812,19865,16656,17597,256,17848,1212,512]

theorem envBound6275 : H12AffineFastState.Bounded env6275 := by
  intro p hp
  have h : env6275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6274_6275 : H12AffineEnvironment.transform 17 2340 env6274 = env6275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env6274 == env6275) = true)

theorem identity6275 : scanCanonicalize (H12AffineFastState.compose env6275 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1944) := by decide +kernel

theorem selectedBound6275 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1944,8461,8867,1045,2340,1024,8461,1465,136,444,295,8329,445,2696,1945,1588,2561,1672,805,256,544,1212,512]

theorem envBound6276 : H12AffineFastState.Bounded env6276 := by
  intro p hp
  have h : env6276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6275_6276 : H12AffineEnvironment.transform 13 1944 env6275 = env6276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1944 env6275 == env6276) = true)

theorem identity6276 : scanCanonicalize (H12AffineFastState.compose env6276 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6276 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env6277 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,1841,8461,8714,1045,2340,1024,8461,1296,33,277,295,8224,276,2593,1840,1588,2561,1569,805,256,544,1045,512]

theorem envBound6277 : H12AffineFastState.Bounded env6277 := by
  intro p hp
  have h : env6277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6276_6277 : H12AffineEnvironment.transform 6 41 env6276 = env6277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6276 == env6277) = true)

theorem identity6277 : scanCanonicalize (H12AffineFastState.compose env6277 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6277 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6278 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1045,8192,1588,8200,8714,1045,2081,1024,8200,1045,33,16,34,8224,17,2593,1589,1588,2561,1569,544,5,544,1045,512]

theorem envBound6278 : H12AffineFastState.Bounded env6278 := by
  intro p hp
  have h : env6278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6277_6278 : H12AffineEnvironment.transform 7 5 env6277 = env6278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6277 == env6278) = true)

theorem identity6278 : scanCanonicalize (H12AffineFastState.compose env6278 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6278 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6279 : List Nat := [2,4,8,16,32,17,41,5,32,1024,2048,1045,8192,1044,8200,8234,1045,2081,1024,8200,1045,33,16,34,8224,17,2049,1045,1044,2081,1025,0,5,0,1045,32]

theorem envBound6279 : H12AffineFastState.Bounded env6279 := by
  intro p hp
  have h : env6279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6278_6279 : H12AffineEnvironment.transform 8 32 env6278 = env6279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6278 == env6279) = true)

theorem identity6279 : scanCanonicalize (H12AffineFastState.compose env6279 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound6279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6280 : List Nat := [2,4,8,16,32,17,41,5,32,1024,2048,1045,2098,1044,2106,2072,1045,2081,1024,2106,1045,33,16,34,2066,17,2049,1045,1044,2081,1025,0,5,0,1045,32]

theorem envBound6280 : H12AffineFastState.Bounded env6280 := by
  intro p hp
  have h : env6280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6279_6280 : H12AffineEnvironment.transform 12 2098 env6279 = env6280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env6279 == env6280) = true)

theorem identity6280 : scanCanonicalize (H12AffineFastState.compose env6280 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6281 : List Nat := [2,4,8,16,26,17,19,5,26,1024,2048,1045,2056,1044,2048,2072,1045,2075,1024,2048,1045,27,16,24,2066,17,2049,1045,1044,2075,1025,0,5,0,1045,26]

theorem envBound6281 : H12AffineFastState.Bounded env6281 := by
  intro p hp
  have h : env6281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6280_6281 : H12AffineEnvironment.transform 4 26 env6280 = env6281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6280 == env6281) = true)

theorem identity6281 : scanCanonicalize (H12AffineFastState.compose env6281 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound6281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6282 : List Nat := [2,4,8,16,26,17,19,5,26,21,2048,0,2056,1,2048,2072,0,2075,21,2048,0,27,16,24,2066,17,2049,0,1,2075,20,0,5,0,0,26]

theorem envBound6282 : H12AffineFastState.Bounded env6282 := by
  intro p hp
  have h : env6282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6281_6282 : H12AffineEnvironment.transform 9 21 env6281 = env6282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env6281 == env6282) = true)

theorem identity6282 : scanCanonicalize (H12AffineFastState.compose env6282 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound6282 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6283 : List Nat := [2,4,8,16,26,17,19,5,26,21,26,0,18,1,26,2,0,1,21,26,0,27,16,24,8,17,27,0,1,1,20,0,5,0,0,26]

theorem envBound6283 : H12AffineFastState.Bounded env6283 := by
  intro p hp
  have h : env6283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6282_6283 : H12AffineEnvironment.transform 10 26 env6282 = env6283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env6282 == env6283) = true)

theorem identity6283 : scanCanonicalize (H12AffineFastState.compose env6283 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6283 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6284 : List Nat := [2,4,8,11,1,10,8,5,1,14,1,0,9,1,1,2,0,1,14,1,0,0,11,3,8,10,0,0,1,1,15,0,5,0,0,1]

theorem envBound6284 : H12AffineFastState.Bounded env6284 := by
  intro p hp
  have h : env6284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6283_6284 : H12AffineEnvironment.transform 3 11 env6283 = env6284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6283 == env6284) = true)

def env6285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,12644669,257,20561,4239488,8389612]

theorem envBound6285 : H12AffineFastState.Bounded env6285 := by
  intro p hp
  have h : env6285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6243_6285 : H12AffineEnvironment.transform 18 1025 env6243 = env6285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6243 == env6285) = true)

theorem identity6285 : scanCanonicalize (H12AffineFastState.compose env6285 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound6285 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8663,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323792,16385,16893,22640,1533,12644669,257,20561,4239488,8389612]

theorem envBound6286 : H12AffineFastState.Bounded env6286 := by
  intro p hp
  have h : env6286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6285_6286 : H12AffineEnvironment.transform 15 8663 env6285 = env6286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env6285 == env6286) = true)

def env6287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,4194304,8388608,41002,8329,8388609,323712,16385,16813,22560,1453,12644669,257,20481,4239488,8389564]

theorem envBound6287 : H12AffineFastState.Bounded env6287 := by
  intro p hp
  have h : env6287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6286_6287 : H12AffineEnvironment.transform 5 16 env6286 = env6287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6286 == env6287) = true)

theorem identity6287 : scanCanonicalize (H12AffineFastState.compose env6287 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6287 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6288 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,4194304,444,41002,8329,445,323712,16385,16813,22560,1453,4255873,257,20481,4239488,512]

theorem envBound6288 : H12AffineFastState.Bounded env6288 := by
  intro p hp
  have h : env6288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6287_6288 : H12AffineEnvironment.transform 22 444 env6287 = env6288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6287 == env6288) = true)

theorem identity6288 : scanCanonicalize (H12AffineFastState.compose env6288 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6288 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6289 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,41348,444,41002,8329,445,323712,16385,16813,22560,1453,20741,257,20481,4356,512]

theorem envBound6289 : H12AffineFastState.Bounded env6289 := by
  intro p hp
  have h : env6289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6288_6289 : H12AffineEnvironment.transform 21 41348 env6288 = env6289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6288 == env6289) = true)

theorem identity6289 : scanCanonicalize (H12AffineFastState.compose env6289 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6289 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8583,4525,262144,1025,26260,4096,18192,444,18110,8329,445,267796,16385,16813,22560,1453,20741,257,20481,4356,512]

theorem envBound6290 : H12AffineFastState.Bounded env6290 := by
  intro p hp
  have h : env6290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6289_6290 : H12AffineEnvironment.transform 14 26260 env6289 = env6290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6289 == env6290) = true)

theorem identity6290 : scanCanonicalize (H12AffineFastState.compose env6290 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound6290 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,14225,8583,4525,262144,1025,14225,4096,5653,444,6075,8329,445,267796,4356,4264,2341,1453,0,257,260,4356,512]

theorem envBound6291 : H12AffineFastState.Bounded env6291 := by
  intro p hp
  have h : env6291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6290_6291 : H12AffineEnvironment.transform 13 4357 env6290 = env6291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env6290 == env6291) = true)

theorem identity6291 : scanCanonicalize (H12AffineFastState.compose env6291 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6291 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env6292 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4096,13972,8322,4264,262144,1025,13972,4096,5653,185,5822,8329,184,267796,4097,4264,2080,1192,0,4,1,4097,512]

theorem envBound6292 : H12AffineFastState.Bounded env6292 := by
  intro p hp
  have h : env6292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6291_6292 : H12AffineEnvironment.transform 7 5 env6291 = env6292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6291 == env6292) = true)

theorem identity6292 : scanCanonicalize (H12AffineFastState.compose env6292 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound6292 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6293 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4096,13972,8322,4264,7868,1025,13972,4096,5653,185,5822,8329,184,2216,4097,4264,2080,1192,0,4,1,4097,512]

theorem envBound6293 : H12AffineFastState.Bounded env6293 := by
  intro p hp
  have h : env6293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6292_6293 : H12AffineEnvironment.transform 17 7868 env6292 = env6293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env6292 == env6293) = true)

theorem identity6293 : scanCanonicalize (H12AffineFastState.compose env6293 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound6293 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6294 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1589,8192,1589,8353,8322,1693,2185,1025,8353,1589,32,185,139,8329,184,2216,1588,1693,2080,1192,0,4,1,1588,512]

theorem envBound6294 : H12AffineFastState.Bounded env6294 := by
  intro p hp
  have h : env6294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6293_6294 : H12AffineEnvironment.transform 11 1589 env6293 = env6294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env6293 == env6294) = true)

theorem identity6294 : scanCanonicalize (H12AffineFastState.compose env6294 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound6294 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6295 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1589,154,1589,59,24,1693,2185,1025,59,1589,32,185,139,19,184,2216,1588,1693,2080,1192,0,4,1,1588,512]

theorem envBound6295 : H12AffineFastState.Bounded env6295 := by
  intro p hp
  have h : env6295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6294_6295 : H12AffineEnvironment.transform 12 154 env6294 = env6295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env6294 == env6295) = true)

theorem identity6295 : scanCanonicalize (H12AffineFastState.compose env6295 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound6295 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env6296 : List Nat := [2,4,8,16,32,16,128,5,512,1024,691,1589,154,1589,59,24,1693,570,1025,59,1589,32,185,139,19,184,539,1588,1693,659,1192,0,4,1,1588,512]

theorem envBound6296 : H12AffineFastState.Bounded env6296 := by
  intro p hp
  have h : env6296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6295_6296 : H12AffineEnvironment.transform 10 691 env6295 = env6296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env6295 == env6296) = true)

theorem identity6296 : scanCanonicalize (H12AffineFastState.compose env6296 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6296 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env6297 : List Nat := [2,4,8,10,32,10,128,5,512,1024,681,1583,128,1583,33,2,1671,544,1025,33,1583,32,163,139,9,162,513,1582,1671,649,1192,0,4,1,1582,512]

theorem envBound6297 : H12AffineFastState.Bounded env6297 := by
  intro p hp
  have h : env6297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6296_6297 : H12AffineEnvironment.transform 3 10 env6296 = env6297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6296 == env6297) = true)

theorem identity6297 : scanCanonicalize (H12AffineFastState.compose env6297 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6297 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env6298 : List Nat := [2,4,8,10,32,10,8,5,512,1024,545,1583,8,1583,33,2,1551,544,1025,33,1583,32,43,3,9,42,513,1582,1551,513,1056,0,4,1,1582,512]

theorem envBound6298 : H12AffineFastState.Bounded env6298 := by
  intro p hp
  have h : env6298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6297_6298 : H12AffineEnvironment.transform 6 8 env6297 = env6298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6297 == env6298) = true)

theorem identity6298 : scanCanonicalize (H12AffineFastState.compose env6298 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6298 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6299 : List Nat := [2,4,8,10,1,10,8,5,512,1024,512,1550,8,1550,0,2,1551,513,1025,0,1550,1,10,3,9,11,513,1551,1551,513,1025,0,4,1,1551,512]

theorem envBound6299 : H12AffineFastState.Bounded env6299 := by
  intro p hp
  have h : env6299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6298_6299 : H12AffineEnvironment.transform 4 1 env6298 = env6299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6298 == env6299) = true)

theorem identity6299 : scanCanonicalize (H12AffineFastState.compose env6299 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound6299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6300 : List Nat := [2,4,8,10,1,10,8,5,10,1024,10,1028,8,1028,0,2,1029,11,1025,0,1028,1,10,3,9,11,11,1029,1029,11,1025,0,4,1,1029,10]

theorem envBound6300 : H12AffineFastState.Bounded env6300 := by
  intro p hp
  have h : env6300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6299_6300 : H12AffineEnvironment.transform 8 10 env6299 = env6300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env6299 == env6300) = true)

theorem identity6300 : scanCanonicalize (H12AffineFastState.compose env6300 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6301 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,3,1028,0,2,1029,0,1025,0,1028,1,1,3,2,0,0,1029,1029,0,1025,0,4,1,1029,1]

theorem envBound6301 : H12AffineFastState.Bounded env6301 := by
  intro p hp
  have h : env6301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6300_6301 : H12AffineEnvironment.transform 2 3 env6300 = env6301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6300 == env6301) = true)

def leafEnv6301 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,3,1028,0,2,1029,0,1025,0,1028,1,1,3,1024,2,1,0,0,1029,1029,0,1025,0,4,1,5,2,1029,1,1,1028,0]

def active6301 : List Nat := [0,1,9]

def tree6301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6301 : H12WitnessSearch.Good tree6301 := H12GlobalWitnessIndex.good

theorem leafIdentity6301 : H12AffineFastState.composeSystem env6301 rootObs = leafEnv6301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6301 rootObs == leafEnv6301) = true)

theorem terminalChecked6301 : H12PackedTerminal.terminalCheckFast leafEnv6301 active6301 tree6301 = true := by decide +kernel

def env6302 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4096,4194304,8388608,41002,8329,8388608,323713,16385,16812,22561,1452,12644669,257,20480,4239488,8389565]

theorem envBound6302 : H12AffineFastState.Bounded env6302 := by
  intro p hp
  have h : env6302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6286_6302 : H12AffineEnvironment.transform 5 17 env6286 = env6302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6286 == env6302) = true)

def env6303 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43136,1025,32768,4096,4194304,8388608,41002,8329,8388608,22529,16385,16812,22561,1452,12644669,257,20480,4239488,8389565]

theorem envBound6303 : H12AffineFastState.Bounded env6303 := by
  intro p hp
  have h : env6303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6302_6303 : H12AffineEnvironment.transform 17 43136 env6302 = env6303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env6302 == env6303) = true)

theorem identity6303 : scanCanonicalize (H12AffineFastState.compose env6303 (packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 4214833) := by decide +kernel

theorem selectedBound6303 : packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env6304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43136,1025,32768,4096,4194304,4214833,41002,8329,4214833,22529,16385,16812,22561,1452,41228,257,20480,4239488,4215692]

theorem envBound6304 : H12AffineFastState.Bounded env6304 := by
  intro p hp
  have h : env6304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6303_6304 : H12AffineEnvironment.transform 22 4214833 env6303 = env6304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4214833 env6303 == env6304) = true)

theorem identity6304 : scanCanonicalize (H12AffineFastState.compose env6304 (packedSelected [0,2,5,6,15,21,22,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6304 : packedSelected [0,2,5,6,15,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env6305 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,8235,4097,43136,1025,32768,4096,4194304,4214833,41002,8329,4214833,22529,16385,16385,22561,1025,41121,172,20480,4239488,4215329]

theorem envBound6305 : H12AffineFastState.Bounded env6305 := by
  intro p hp
  have h : env6305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6304_6305 : H12AffineEnvironment.transform 7 173 env6304 = env6305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6304 == env6305) = true)

theorem identity6305 : scanCanonicalize (H12AffineFastState.compose env6305 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound6305 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env6306 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,32768,8235,4097,43136,1025,32768,4096,4194304,4194352,41002,8329,4194352,2048,4096,4096,2080,1025,41121,172,1,4239488,4194848]

theorem envBound6306 : H12AffineFastState.Bounded env6306 := by
  intro p hp
  have h : env6306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6305_6306 : H12AffineEnvironment.transform 13 4097 env6305 = env6306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env6305 == env6306) = true)

theorem identity6306 : scanCanonicalize (H12AffineFastState.compose env6306 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6306 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env6307 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,8201,8235,4097,2185,1025,8201,4096,4194304,4194352,35,8329,4194352,2048,4096,4096,2080,1025,168,172,1,4198537,4194848]

theorem envBound6307 : H12AffineFastState.Bounded env6307 := by
  intro p hp
  have h : env6307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6306_6307 : H12AffineEnvironment.transform 14 8201 env6306 = env6307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6306 == env6307) = true)

theorem identity6307 : scanCanonicalize (H12AffineFastState.compose env6307 (packedSelected [0,1,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7317) := by decide +kernel

theorem selectedBound6307 : packedSelected [0,1,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6308 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7317,4097,7324,7358,4097,2185,1025,7324,4096,4194304,4194352,35,7196,4194352,2048,4096,4096,2080,1025,168,172,1,4198537,4194848]

theorem envBound6308 : H12AffineFastState.Bounded env6308 := by
  intro p hp
  have h : env6308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6307_6308 : H12AffineEnvironment.transform 12 7317 env6307 = env6308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7317 env6307 == env6308) = true)

theorem identity6308 : scanCanonicalize (H12AffineFastState.compose env6308 (packedSelected [0,7,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6308 : packedSelected [0,7,10,17] rootPS < 2^1333 := by decide +kernel

def env6309 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1693,2568,1692,2561,2595,1692,2185,1025,2561,1693,4194304,4194352,35,2689,4194352,2048,1693,1693,2080,1025,168,172,1,4195860,4194848]

theorem envBound6309 : H12AffineFastState.Bounded env6309 := by
  intro p hp
  have h : env6309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6308_6309 : H12AffineEnvironment.transform 11 1693 env6308 = env6309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6308 == env6309) = true)

def env6310 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,2568,1588,2561,2595,1588,2081,1025,2561,1589,4194304,4194352,35,2601,4194352,2048,1589,1589,2080,1025,0,4,1,4195860,4194848]

theorem envBound6310 : H12AffineFastState.Bounded env6310 := by
  intro p hp
  have h : env6310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6309_6310 : H12AffineEnvironment.transform 6 40 env6309 = env6310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6309 == env6310) = true)

theorem identity6310 : scanCanonicalize (H12AffineFastState.compose env6310 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6310 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6311 : List Nat := [2,4,8,16,16,17,24,5,512,1024,2048,1541,2568,1540,2561,2579,1540,2065,1025,2561,1541,4194304,4194304,19,2585,4194304,2048,1541,1541,2064,1025,0,4,1,4195860,4194832]

theorem envBound6311 : H12AffineFastState.Bounded env6311 := by
  intro p hp
  have h : env6311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6310_6311 : H12AffineEnvironment.transform 4 16 env6310 = env6311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6310 == env6311) = true)

theorem identity6311 : scanCanonicalize (H12AffineFastState.compose env6311 (packedSelected [0,2,4] rootPS)) = affineNative (2^(21+1) ^^^ 2570) := by decide +kernel

theorem selectedBound6311 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env6312 : List Nat := [2,4,8,16,16,17,24,5,512,1024,2048,1541,2568,1540,2561,2579,1540,2065,1025,2561,1541,2570,2570,19,2585,2570,2048,1541,1541,2064,1025,0,4,1,3102,2074]

theorem envBound6312 : H12AffineFastState.Bounded env6312 := by
  intro p hp
  have h : env6312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6311_6312 : H12AffineEnvironment.transform 21 2570 env6311 = env6312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2570 env6311 == env6312) = true)

theorem identity6312 : scanCanonicalize (H12AffineFastState.compose env6312 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound6312 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env6313 : List Nat := [2,4,8,16,16,17,24,5,512,1024,528,1541,24,1540,17,3,1540,513,1025,17,1541,26,26,19,9,26,528,1541,1541,512,1025,0,4,1,1550,522]

theorem envBound6313 : H12AffineFastState.Bounded env6313 := by
  intro p hp
  have h : env6313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6312_6313 : H12AffineEnvironment.transform 10 528 env6312 = env6313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env6312 == env6313) = true)

theorem identity6313 : scanCanonicalize (H12AffineFastState.compose env6313 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6313 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6314 : List Nat := [2,4,8,1,1,0,9,5,512,1024,513,1541,9,1540,0,3,1540,513,1025,0,1541,11,11,2,9,11,513,1541,1541,512,1025,0,4,1,1550,522]

theorem envBound6314 : H12AffineFastState.Bounded env6314 := by
  intro p hp
  have h : env6314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6313_6314 : H12AffineEnvironment.transform 3 1 env6313 = env6314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6313 == env6314) = true)

theorem identity6314 : scanCanonicalize (H12AffineFastState.compose env6314 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6315 : List Nat := [2,4,8,1,1,0,9,5,11,1024,10,1038,9,1039,0,3,1039,10,1025,0,1038,11,11,2,9,11,10,1038,1038,11,1025,0,4,1,1029,1]

theorem envBound6315 : H12AffineFastState.Bounded env6315 := by
  intro p hp
  have h : env6315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6314_6315 : H12AffineEnvironment.transform 8 11 env6314 = env6315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6314 == env6315) = true)

theorem identity6315 : scanCanonicalize (H12AffineFastState.compose env6315 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6316 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,3,1029,0,3,1029,0,1025,0,1028,1,1,2,3,1,0,1028,1028,1,1025,0,4,1,1029,1]

theorem envBound6316 : H12AffineFastState.Bounded env6316 := by
  intro p hp
  have h : env6316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6315_6316 : H12AffineEnvironment.transform 2 2 env6315 = env6316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6315 == env6316) = true)

def leafEnv6316 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,3,1029,0,3,1029,0,1025,0,1028,1,1,2,1024,3,1,1,0,1028,1028,1,1025,0,4,1,5,2,1029,1,1,1029,0]

def active6316 : List Nat := [0,1,9]

def tree6316 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6316 : H12WitnessSearch.Good tree6316 := H12GlobalWitnessIndex.good

theorem leafIdentity6316 : H12AffineFastState.composeSystem env6316 rootObs = leafEnv6316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6316 rootObs == leafEnv6316) = true)

theorem terminalChecked6316 : H12PackedTerminal.terminalCheckFast leafEnv6316 active6316 tree6316 = true := by decide +kernel

def env6317 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1588,2568,1589,2561,2595,1589,2080,1025,2561,1588,4194304,4194352,35,2600,4194352,2048,1588,1588,2080,1025,1,5,1,4195860,4194848]

theorem envBound6317 : H12AffineFastState.Bounded env6317 := by
  intro p hp
  have h : env6317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6309_6317 : H12AffineEnvironment.transform 6 41 env6309 = env6317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6309 == env6317) = true)

theorem identity6317 : scanCanonicalize (H12AffineFastState.compose env6317 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6317 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env6318 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1588,1030,1589,1039,1069,1589,1582,1025,1039,1588,4194304,4194352,35,1062,4194352,1550,1588,1588,1582,1025,1,5,1,4195860,4194848]

theorem envBound6318 : H12AffineFastState.Bounded env6318 := by
  intro p hp
  have h : env6318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6317_6318 : H12AffineEnvironment.transform 10 1550 env6317 = env6318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6317 == env6318) = true)

theorem identity6318 : scanCanonicalize (H12AffineFastState.compose env6318 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 545) := by decide +kernel

theorem selectedBound6318 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6319 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1588,1030,1589,1039,1069,1589,1582,1025,1039,1588,545,529,35,1062,529,1550,1588,1588,1582,1025,1,5,1,1077,1]

theorem envBound6319 : H12AffineFastState.Bounded env6319 := by
  intro p hp
  have h : env6319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6318_6319 : H12AffineEnvironment.transform 21 545 env6318 = env6319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 545 env6318 == env6319) = true)

theorem identity6319 : scanCanonicalize (H12AffineFastState.compose env6319 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound6319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6320 : List Nat := [2,4,8,16,32,17,41,4,512,53,571,513,51,512,58,24,512,539,52,58,513,545,529,35,19,529,571,513,513,539,52,1,5,1,0,1]

theorem envBound6320 : H12AffineFastState.Bounded env6320 := by
  intro p hp
  have h : env6320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6319_6320 : H12AffineEnvironment.transform 9 53 env6319 = env6320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env6319 == env6320) = true)

def env6321 : List Nat := [2,4,8,16,32,17,41,4,0,53,59,1,51,0,58,24,0,27,52,58,1,33,17,35,19,17,59,1,1,27,52,1,5,1,0,1]

theorem envBound6321 : H12AffineFastState.Bounded env6321 := by
  intro p hp
  have h : env6321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6320_6321 : H12AffineEnvironment.transform 8 0 env6320 = env6321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6320 == env6321) = true)

theorem identity6321 : scanCanonicalize (H12AffineFastState.compose env6321 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound6321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6322 : List Nat := [2,4,8,4,32,5,41,4,0,33,47,1,39,0,46,12,0,15,32,46,1,33,5,35,7,5,47,1,1,15,32,1,5,1,0,1]

theorem envBound6322 : H12AffineFastState.Bounded env6322 := by
  intro p hp
  have h : env6322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6321_6322 : H12AffineEnvironment.transform 3 4 env6321 = env6322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6321 == env6322) = true)

theorem identity6322 : scanCanonicalize (H12AffineFastState.compose env6322 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6323 : List Nat := [2,4,6,4,32,5,39,4,0,33,33,1,39,0,32,2,0,1,32,32,1,33,5,35,7,5,33,1,1,1,32,1,5,1,0,1]

theorem envBound6323 : H12AffineFastState.Bounded env6323 := by
  intro p hp
  have h : env6323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6322_6323 : H12AffineEnvironment.transform 2 6 env6322 = env6323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6322 == env6323) = true)

theorem identity6323 : scanCanonicalize (H12AffineFastState.compose env6323 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6323 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6324 : List Nat := [2,1,3,1,32,0,34,1,0,33,33,1,34,0,32,2,0,1,32,32,1,33,0,35,2,0,33,1,1,1,32,1,0,1,0,1]

theorem envBound6324 : H12AffineFastState.Bounded env6324 := by
  intro p hp
  have h : env6324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6323_6324 : H12AffineEnvironment.transform 1 1 env6323 = env6324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6323 == env6324) = true)

def leafEnv6324 : List Nat := [2,1,3,1,32,0,34,1,0,33,33,1,34,0,32,2,0,1,32,32,1,33,0,35,33,2,1,0,33,1,1,1,32,1,0,1,0,34,0,1,1,1,0]

def active6324 : List Nat := [0,4]

def tree6324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6324 : H12WitnessSearch.Good tree6324 := H12GlobalWitnessIndex.good

theorem leafIdentity6324 : H12AffineFastState.composeSystem env6324 rootObs = leafEnv6324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6324 rootObs == leafEnv6324) = true)

theorem terminalChecked6324 : H12PackedTerminal.terminalCheckFast leafEnv6324 active6324 tree6324 = true := by decide +kernel

def env6325 : List Nat := [2,4,8,16,32,17,41,4,1,53,58,0,51,1,58,24,1,26,52,58,0,32,16,35,19,16,58,0,0,26,52,1,5,1,0,1]

theorem envBound6325 : H12AffineFastState.Bounded env6325 := by
  intro p hp
  have h : env6325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6320_6325 : H12AffineEnvironment.transform 8 1 env6320 = env6325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6320 == env6325) = true)

def env6326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43137,1025,32768,4096,4194304,8388608,41002,8329,8388608,22528,16385,16812,22561,1452,12644669,257,20480,4239488,8389565]

theorem envBound6326 : H12AffineFastState.Bounded env6326 := by
  intro p hp
  have h : env6326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6302_6326 : H12AffineEnvironment.transform 17 43137 env6302 = env6326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env6302 == env6326) = true)

theorem identity6326 : scanCanonicalize (H12AffineFastState.compose env6326 (packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 4235668) := by decide +kernel

theorem selectedBound6326 : packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env6327 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43137,1025,32768,4096,4194304,4235668,41002,8329,4235668,22528,16385,16812,22561,1452,20649,257,20480,4239488,4235817]

theorem envBound6327 : H12AffineFastState.Bounded env6327 := by
  intro p hp
  have h : env6327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6326_6327 : H12AffineEnvironment.transform 22 4235668 env6326 = env6327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235668 env6326 == env6327) = true)

theorem identity6327 : scanCanonicalize (H12AffineFastState.compose env6327 (packedSelected [0,1,3,9,13,18,21,22,23,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound6327 : packedSelected [0,1,3,9,13,18,21,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6328 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43137,1025,32768,4096,41261,185,41002,8329,185,22528,16385,16812,22561,1452,20649,257,20480,4525,772]

theorem envBound6328 : H12AffineFastState.Bounded env6328 := by
  intro p hp
  have h : env6328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6327_6328 : H12AffineEnvironment.transform 21 41261 env6327 = env6328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env6327 == env6328) = true)

theorem identity6328 : scanCanonicalize (H12AffineFastState.compose env6328 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6328 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6329 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,43049,1025,32768,4096,41261,17,41002,8225,17,22528,16385,16644,22561,1284,20481,257,20480,4357,772]

theorem envBound6329 : H12AffineFastState.Bounded env6329 := by
  intro p hp
  have h : env6329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6328_6329 : H12AffineEnvironment.transform 6 40 env6328 = env6329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6328 == env6329) = true)

theorem identity6329 : scanCanonicalize (H12AffineFastState.compose env6329 (packedSelected [0,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2309) := by decide +kernel

theorem selectedBound6329 : packedSelected [0,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env6330 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,8192,16384,32768,8494,2049,43049,1025,32768,2309,41261,17,41002,8225,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound6330 : H12AffineFastState.Bounded env6330 := by
  intro p hp
  have h : env6330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6329_6330 : H12AffineEnvironment.transform 11 2309 env6329 = env6330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2309 env6329 == env6330) = true)

theorem identity6330 : scanCanonicalize (H12AffineFastState.compose env6330 (packedSelected [0,1,3,5,7,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11836) := by decide +kernel

theorem selectedBound6330 : packedSelected [0,1,3,5,7,8,13,17] rootPS < 2^1333 := by decide +kernel

def env6331 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,8192,16384,11836,8494,2049,1557,1025,11836,2309,3857,17,3606,8225,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound6331 : H12AffineFastState.Bounded env6331 := by
  intro p hp
  have h : env6331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6330_6331 : H12AffineEnvironment.transform 14 11836 env6330 = env6331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11836 env6330 == env6331) = true)

theorem identity6331 : scanCanonicalize (H12AffineFastState.compose env6331 (packedSelected [0,1,2,3,6,7,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound6331 : packedSelected [0,1,2,3,6,7,12,13,18] rootPS < 2^1333 := by decide +kernel

def env6332 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,1063,16384,2587,1289,2049,1557,1025,2587,2309,3857,17,3606,1030,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound6332 : H12AffineFastState.Bounded env6332 := by
  intro p hp
  have h : env6332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6331_6332 : H12AffineEnvironment.transform 12 1063 env6331 = env6332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env6331 == env6332) = true)

def env6333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849104,16385,16893,547952,598059,12644668,525568,545873,4239489,8914925]

theorem envBound6333 : H12AffineFastState.Bounded env6333 := by
  intro p hp
  have h : env6333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6242_6333 : H12AffineEnvironment.transform 20 4097 env6242 = env6333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env6242 == env6333) = true)

def env6334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,12644668,256,20561,4239489,8389613]

theorem envBound6334 : H12AffineFastState.Bounded env6334 := by
  intro p hp
  have h : env6334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6333_6334 : H12AffineEnvironment.transform 18 1024 env6333 = env6334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6333 == env6334) = true)

theorem identity6334 : scanCanonicalize (H12AffineFastState.compose env6334 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115782) := by decide +kernel

theorem selectedBound6334 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,115782,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,8467834,256,20561,95431,8389613]

theorem envBound6335 : H12AffineFastState.Bounded env6335 := by
  intro p hp
  have h : env6335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6334_6335 : H12AffineEnvironment.transform 21 115782 env6334 = env6335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115782 env6334 == env6335) = true)

def env6336 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8467754,256,20481,95383,8389565]

theorem envBound6336 : H12AffineFastState.Bounded env6336 := by
  intro p hp
  have h : env6336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6335_6336 : H12AffineEnvironment.transform 5 16 env6335 = env6336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6335 == env6336) = true)

theorem identity6336 : scanCanonicalize (H12AffineFastState.compose env6336 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6336 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6337 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,445,41002,8329,445,323712,16385,16813,22560,74795,78999,256,20481,95383,512]

theorem envBound6337 : H12AffineFastState.Bounded env6337 := by
  intro p hp
  have h : env6337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6336_6337 : H12AffineEnvironment.transform 22 445 env6336 = env6337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6336 == env6337) = true)

theorem identity6337 : scanCanonicalize (H12AffineFastState.compose env6337 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound6337 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4097,41348,445,41002,8329,445,323712,16385,16813,22560,16825,20741,256,20481,4357,512]

theorem envBound6338 : H12AffineFastState.Bounded env6338 := by
  intro p hp
  have h : env6338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6337_6338 : H12AffineEnvironment.transform 15 26002 env6337 = env6338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env6337 == env6338) = true)

theorem identity6338 : scanCanonicalize (H12AffineFastState.compose env6338 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6338 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6339 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26002,4525,262144,1024,26260,4097,18192,445,18110,8329,445,267796,16385,16813,22560,16825,20741,256,20481,4357,512]

theorem envBound6339 : H12AffineFastState.Bounded env6339 := by
  intro p hp
  have h : env6339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6338_6339 : H12AffineEnvironment.transform 14 26260 env6338 = env6339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6338 == env6339) = true)

theorem identity6339 : scanCanonicalize (H12AffineFastState.compose env6339 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6339 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6340 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26002,1213,262144,1024,26260,1297,18192,445,18110,8329,445,262916,16385,16813,19760,16825,17429,256,17681,1045,512]

theorem envBound6340 : H12AffineFastState.Bounded env6340 := by
  intro p hp
  have h : env6340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6339_6340 : H12AffineEnvironment.transform 11 1296 env6339 = env6340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6339 == env6340) = true)

theorem identity6340 : scanCanonicalize (H12AffineFastState.compose env6340 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6340 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6341 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1840,8612,8866,1213,262144,1024,8612,1297,32,445,398,8329,445,262916,1841,1693,2560,1673,805,256,545,1045,512]

theorem envBound6341 : H12AffineFastState.Bounded env6341 := by
  intro p hp
  have h : env6341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6340_6341 : H12AffineEnvironment.transform 13 1840 env6340 = env6341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env6340 == env6341) = true)

theorem identity6341 : scanCanonicalize (H12AffineFastState.compose env6341 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6341 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6342 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8201,8866,1213,262144,1024,8201,1212,32,16,35,8329,16,262825,1692,1693,2560,1673,648,173,545,1045,512]

theorem envBound6342 : H12AffineFastState.Bounded env6342 := by
  intro p hp
  have h : env6342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6341_6342 : H12AffineEnvironment.transform 7 173 env6341 = env6342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6341 == env6342) = true)

theorem identity6342 : scanCanonicalize (H12AffineFastState.compose env6342 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound6342 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6343 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8201,8866,1213,1582,1024,8201,1212,32,16,35,8329,16,1159,1692,1693,2560,1673,648,173,545,1045,512]

theorem envBound6343 : H12AffineFastState.Bounded env6343 := by
  intro p hp
  have h : env6343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6342_6343 : H12AffineEnvironment.transform 17 1582 env6342 = env6343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env6342 == env6343) = true)

def env6344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,8388608,41002,8329,8388609,323713,16385,16812,22561,74795,8467755,256,20480,95382,8389564]

theorem envBound6344 : H12AffineFastState.Bounded env6344 := by
  intro p hp
  have h : env6344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6335_6344 : H12AffineEnvironment.transform 5 17 env6335 = env6344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6335 == env6344) = true)

def env6345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,5376,41002,8329,5377,323713,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound6345 : H12AffineFastState.Bounded env6345 := by
  intro p hp
  have h : env6345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6344_6345 : H12AffineEnvironment.transform 22 5376 env6344 = env6345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5376 env6344 == env6345) = true)

theorem identity6345 : scanCanonicalize (H12AffineFastState.compose env6345 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 25780) := by decide +kernel

theorem selectedBound6345 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6346 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25780,65536,4524,262144,1024,25780,4097,73891,5376,17566,8329,5377,267317,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound6346 : H12AffineFastState.Bounded env6346 := by
  intro p hp
  have h : env6346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6345_6346 : H12AffineEnvironment.transform 14 25780 env6345 = env6346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25780 env6345 == env6346) = true)

theorem identity6346 : scanCanonicalize (H12AffineFastState.compose env6346 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 7308) := by decide +kernel

theorem selectedBound6346 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25780,65536,4524,7308,1024,25780,4097,73891,5376,17566,8329,5377,2233,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound6347 : H12AffineFastState.Bounded env6347 := by
  intro p hp
  have h : env6347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6346_6347 : H12AffineEnvironment.transform 17 7308 env6346 = env6347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7308 env6346 == env6347) = true)

theorem identity6347 : scanCanonicalize (H12AffineFastState.compose env6347 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound6347 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25780,26002,4524,7308,1024,25780,4097,17713,5376,17566,8329,5377,2233,16385,16812,22561,16825,17849,256,20480,4356,5820]

theorem envBound6348 : H12AffineFastState.Bounded env6348 := by
  intro p hp
  have h : env6348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6347_6348 : H12AffineEnvironment.transform 15 26002 env6347 = env6348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env6347 == env6348) = true)

theorem identity6348 : scanCanonicalize (H12AffineFastState.compose env6348 (packedSelected [1,5,6,10,12,15,17,21] rootPS)) = affineNative (2^(13+1) ^^^ 6926) := by decide +kernel

theorem selectedBound6348 : packedSelected [1,5,6,10,12,15,17,21] rootPS < 2^1333 := by decide +kernel

def env6349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,6926,16314,16028,4524,7308,1024,16314,4097,7743,5376,8080,8329,5377,2233,6927,6818,815,6839,7863,256,2830,4356,5820]

theorem envBound6349 : H12AffineFastState.Bounded env6349 := by
  intro p hp
  have h : env6349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6348_6349 : H12AffineEnvironment.transform 13 6926 env6348 = env6349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6926 env6348 == env6349) = true)

theorem identity6349 : scanCanonicalize (H12AffineFastState.compose env6349 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6349 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env6350 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,6818,15894,16028,4096,7308,1024,15894,4097,7743,5292,7740,8329,5293,2233,6819,6818,643,6839,7863,172,2722,4264,5820]

theorem envBound6350 : H12AffineFastState.Bounded env6350 := by
  intro p hp
  have h : env6350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6349_6350 : H12AffineEnvironment.transform 7 172 env6349 = env6350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6349 == env6350) = true)

theorem identity6350 : scanCanonicalize (H12AffineFastState.compose env6350 (packedSelected [0,1,5,6,7,10,12,13,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6350 : packedSelected [0,1,5,6,7,10,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env6351 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1692,8192,3134,10378,10240,1692,2576,1024,10378,1693,2211,560,2208,8329,561,2233,3135,3134,643,3115,2091,172,2722,1588,32]

theorem envBound6351 : H12AffineFastState.Bounded env6351 := by
  intro p hp
  have h : env6351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6350_6351 : H12AffineEnvironment.transform 11 1692 env6350 = env6351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env6350 == env6351) = true)

theorem identity6351 : scanCanonicalize (H12AffineFastState.compose env6351 (packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,17,23] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound6351 : packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,17,23] rootPS < 2^1333 := by decide +kernel

def env6352 : List Nat := [2,4,8,16,32,17,57,21,512,1024,2048,1573,8192,3134,10291,10240,1573,2576,1024,10291,1572,2074,560,2073,8240,561,2048,3135,3134,570,3115,2091,21,2587,1588,32]

theorem envBound6352 : H12AffineFastState.Bounded env6352 := by
  intro p hp
  have h : env6352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6351_6352 : H12AffineEnvironment.transform 6 57 env6351 = env6352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env6351 == env6352) = true)

theorem identity6352 : scanCanonicalize (H12AffineFastState.compose env6352 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound6352 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env6353 : List Nat := [2,4,8,16,32,17,57,21,512,1024,2048,1573,2562,3134,561,514,1573,2576,1024,561,1572,2074,560,2073,2610,561,2048,3135,3134,570,3115,2091,21,2587,1588,32]

theorem envBound6353 : H12AffineFastState.Bounded env6353 := by
  intro p hp
  have h : env6353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6352_6353 : H12AffineEnvironment.transform 12 2562 env6352 = env6353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env6352 == env6353) = true)

theorem identity6353 : scanCanonicalize (H12AffineFastState.compose env6353 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound6353 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6354 : List Nat := [2,4,8,16,32,17,57,21,512,1024,1060,1573,1574,26,561,514,1573,1588,1024,561,1572,1086,560,1085,1558,561,1060,27,26,570,15,1039,21,1599,1588,32]

theorem envBound6354 : H12AffineFastState.Bounded env6354 := by
  intro p hp
  have h : env6354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6353_6354 : H12AffineEnvironment.transform 10 1060 env6353 = env6354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env6353 == env6354) = true)

theorem identity6354 : scanCanonicalize (H12AffineFastState.compose env6354 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound6354 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env6355 : List Nat := [2,4,8,16,32,17,57,21,512,36,0,513,514,26,561,514,513,528,36,561,512,26,560,25,562,561,0,27,26,570,15,43,21,539,528,32]

theorem envBound6355 : H12AffineFastState.Bounded env6355 := by
  intro p hp
  have h : env6355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6354_6355 : H12AffineEnvironment.transform 9 36 env6354 = env6355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env6354 == env6355) = true)

theorem identity6355 : scanCanonicalize (H12AffineFastState.compose env6355 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6355 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env6356 : List Nat := [2,4,8,16,16,17,9,21,512,20,0,513,514,26,513,514,513,528,20,513,512,26,512,25,514,513,0,27,26,522,15,27,21,539,528,16]

theorem envBound6356 : H12AffineFastState.Bounded env6356 := by
  intro p hp
  have h : env6356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6355_6356 : H12AffineEnvironment.transform 4 16 env6355 = env6356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6355 == env6356) = true)

theorem identity6356 : scanCanonicalize (H12AffineFastState.compose env6356 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound6356 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6357 : List Nat := [2,4,8,16,16,17,9,21,16,20,0,17,18,26,17,18,17,0,20,17,16,26,16,25,18,17,0,27,26,26,15,27,21,11,0,16]

theorem envBound6357 : H12AffineFastState.Bounded env6357 := by
  intro p hp
  have h : env6357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6356_6357 : H12AffineEnvironment.transform 8 16 env6356 = env6357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env6356 == env6357) = true)

def env6358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,5377,41002,8329,5376,323713,16385,16812,22561,74795,73770,256,20480,95382,5821]

theorem envBound6358 : H12AffineFastState.Bounded env6358 := by
  intro p hp
  have h : env6358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6344_6358 : H12AffineEnvironment.transform 22 5377 env6344 = env6358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5377 env6344 == env6358) = true)

theorem identity6358 : scanCanonicalize (H12AffineFastState.compose env6358 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6358 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6359 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,115735,5377,41002,8224,5376,323624,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound6359 : H12AffineFastState.Bounded env6359 := by
  intro p hp
  have h : env6359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6358_6359 : H12AffineEnvironment.transform 6 41 env6358 = env6359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6358 == env6359) = true)

theorem identity6359 : scanCanonicalize (H12AffineFastState.compose env6359 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6359 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6360 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,8200,65536,4357,262144,1024,8200,4097,91167,5377,34,8224,5376,282656,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound6360 : H12AffineFastState.Bounded env6360 := by
  intro p hp
  have h : env6360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6359_6360 : H12AffineEnvironment.transform 14 8200 env6359 = env6360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6359 == env6360) = true)

theorem identity6360 : scanCanonicalize (H12AffineFastState.compose env6360 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6360 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6361 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,8200,65536,4357,2080,1024,8200,4097,91167,5377,34,8224,5376,22528,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound6361 : H12AffineFastState.Bounded env6361 := by
  intro p hp
  have h : env6361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6360_6361 : H12AffineEnvironment.transform 17 2080 env6360 = env6361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6360 == env6361) = true)

theorem identity6361 : scanCanonicalize (H12AffineFastState.compose env6361 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6361 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6362 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4129,8200,65536,4357,2080,1024,8200,4097,78910,5377,34,8224,5376,2081,4128,4388,2048,74795,73770,256,33,74782,5652]

theorem envBound6362 : H12AffineFastState.Bounded env6362 := by
  intro p hp
  have h : env6362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6361_6362 : H12AffineEnvironment.transform 13 4129 env6361 = env6362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6361 == env6362) = true)

theorem identity6362 : scanCanonicalize (H12AffineFastState.compose env6362 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound6362 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6363 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4129,8200,2343,4357,2080,1024,8200,4097,15641,5377,34,8224,5376,2081,4128,4388,2048,11532,10509,256,33,11577,5652]

theorem envBound6363 : H12AffineFastState.Bounded env6363 := by
  intro p hp
  have h : env6363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6362_6363 : H12AffineEnvironment.transform 15 2343 env6362 = env6363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env6362 == env6363) = true)

theorem identity6363 : scanCanonicalize (H12AffineFastState.compose env6363 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2853) := by decide +kernel

theorem selectedBound6363 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env6364 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,2853,8192,2820,8200,2343,2592,2080,1024,8200,2852,9788,3620,34,8224,3621,2081,2821,2561,2048,11532,10509,256,33,11577,3377]

theorem envBound6364 : H12AffineFastState.Bounded env6364 := by
  intro p hp
  have h : env6364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6363_6364 : H12AffineEnvironment.transform 11 2853 env6363 = env6364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2853 env6363 == env6364) = true)

theorem identity6364 : scanCanonicalize (H12AffineFastState.compose env6364 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6364 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6365 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,2593,8192,2560,8200,2083,2592,2080,1024,8200,2592,9788,3620,34,8224,3621,2081,2561,2561,2048,11272,10249,4,33,11325,3125]

theorem envBound6365 : H12AffineFastState.Bounded env6365 := by
  intro p hp
  have h : env6365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6364_6365 : H12AffineEnvironment.transform 7 4 env6364 = env6365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6364 == env6365) = true)

theorem identity6365 : scanCanonicalize (H12AffineFastState.compose env6365 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound6365 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6366 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,2593,1543,2560,1551,2083,2592,2080,1024,1551,2592,59,3620,34,1575,3621,2081,2561,2561,2048,2575,3598,4,33,2618,3125]

theorem envBound6366 : H12AffineFastState.Bounded env6366 := by
  intro p hp
  have h : env6366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6365_6366 : H12AffineEnvironment.transform 12 1543 env6365 = env6366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env6365 == env6366) = true)

theorem identity6366 : scanCanonicalize (H12AffineFastState.compose env6366 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound6366 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6367 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1583,1038,1543,1071,1551,1548,1039,1551,1024,1551,1039,59,11,34,1575,10,1550,1070,1070,1583,1056,33,4,33,1045,538]

theorem envBound6367 : H12AffineFastState.Bounded env6367 := by
  intro p hp
  have h : env6367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6366_6367 : H12AffineEnvironment.transform 10 1583 env6366 = env6367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env6366 == env6367) = true)

def env6368 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1551,1038,1543,1039,1551,1548,1039,1551,1024,1551,1039,27,11,2,1543,10,1550,1038,1038,1551,1024,1,4,1,1045,538]

theorem envBound6368 : H12AffineFastState.Bounded env6368 := by
  intro p hp
  have h : env6368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6367_6368 : H12AffineEnvironment.transform 4 0 env6367 = env6368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6367 == env6368) = true)

theorem identity6368 : scanCanonicalize (H12AffineFastState.compose env6368 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound6368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6369 : List Nat := [2,4,8,16,0,17,9,4,512,21,538,27,530,26,538,537,26,538,21,538,26,27,11,2,530,10,539,27,27,538,21,1,4,1,0,538]

theorem envBound6369 : H12AffineFastState.Bounded env6369 := by
  intro p hp
  have h : env6369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6368_6369 : H12AffineEnvironment.transform 9 21 env6368 = env6369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env6368 == env6369) = true)

theorem identity6369 : scanCanonicalize (H12AffineFastState.compose env6369 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound6369 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6370 : List Nat := [2,4,8,16,0,17,9,4,27,21,1,27,9,26,1,2,26,1,21,1,26,27,11,2,9,10,0,27,27,1,21,1,4,1,0,1]

theorem envBound6370 : H12AffineFastState.Bounded env6370 := by
  intro p hp
  have h : env6370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6369_6370 : H12AffineEnvironment.transform 8 27 env6369 = env6370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env6369 == env6370) = true)

def env6371 : List Nat := [2,4,8,4,0,5,9,4,15,1,1,15,9,14,1,2,14,1,1,1,14,15,11,2,9,10,0,15,15,1,1,1,4,1,0,1]

theorem envBound6371 : H12AffineFastState.Bounded env6371 := by
  intro p hp
  have h : env6371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6370_6371 : H12AffineEnvironment.transform 3 4 env6370 = env6371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6370 == env6371) = true)

def env6372 : List Nat := [2,4,8,5,0,4,9,4,14,0,1,14,9,15,1,2,15,1,0,1,15,14,11,2,9,10,0,14,14,1,0,1,4,1,0,1]

theorem envBound6372 : H12AffineFastState.Bounded env6372 := by
  intro p hp
  have h : env6372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6370_6372 : H12AffineEnvironment.transform 3 5 env6370 = env6372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6370 == env6372) = true)

theorem identity6372 : scanCanonicalize (H12AffineFastState.compose env6372 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6373 : List Nat := [2,4,6,5,0,4,7,4,0,0,1,0,7,1,1,2,1,1,0,1,1,0,5,2,7,4,0,0,0,1,0,1,4,1,0,1]

theorem envBound6373 : H12AffineFastState.Bounded env6373 := by
  intro p hp
  have h : env6373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6372_6373 : H12AffineEnvironment.transform 2 6 env6372 = env6373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6372 == env6373) = true)

theorem identity6373 : scanCanonicalize (H12AffineFastState.compose env6373 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6373 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6374 : List Nat := [2,1,3,0,0,1,2,1,0,0,1,0,2,1,1,2,1,1,0,1,1,0,0,2,2,1,0,0,0,1,0,1,1,1,0,1]

theorem envBound6374 : H12AffineFastState.Bounded env6374 := by
  intro p hp
  have h : env6374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6373_6374 : H12AffineEnvironment.transform 1 1 env6373 = env6374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6373 == env6374) = true)

def leafEnv6374 : List Nat := [2,1,3,0,0,1,2,1,0,0,1,0,2,1,1,2,1,1,0,1,1,0,0,2,1,2,1,1,0,0,0,1,0,1,1,1,0,3,0,1,1,1,0]

def active6374 : List Nat := [0]

def tree6374 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6374 : H12WitnessSearch.Good tree6374 := H12GlobalWitnessIndex.good

theorem leafIdentity6374 : H12AffineFastState.composeSystem env6374 rootObs = leafEnv6374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6374 rootObs == leafEnv6374) = true)

theorem terminalChecked6374 : H12PackedTerminal.terminalCheckFast leafEnv6374 active6374 tree6374 = true := by decide +kernel

def env6375 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1550,1038,1543,1038,1551,1548,1039,1551,1024,1551,1039,26,11,3,1542,10,1550,1039,1039,1550,1025,0,4,0,1045,538]

theorem envBound6375 : H12AffineFastState.Bounded env6375 := by
  intro p hp
  have h : env6375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6367_6375 : H12AffineEnvironment.transform 4 1 env6367 = env6375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6367 == env6375) = true)

theorem identity6375 : scanCanonicalize (H12AffineFastState.compose env6375 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound6375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6376 : List Nat := [2,4,8,16,1,17,8,4,512,526,0,512,9,512,1,2,513,1,526,1,513,26,11,3,8,10,0,513,513,0,527,0,4,0,539,538]

theorem envBound6376 : H12AffineFastState.Bounded env6376 := by
  intro p hp
  have h : env6376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6375_6376 : H12AffineEnvironment.transform 9 526 env6375 = env6376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env6375 == env6376) = true)

theorem identity6376 : scanCanonicalize (H12AffineFastState.compose env6376 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6376 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6377 : List Nat := [2,4,8,16,1,17,8,4,1,15,0,1,9,1,1,2,0,1,15,1,0,26,11,3,8,10,0,0,0,0,14,0,4,0,26,27]

theorem envBound6377 : H12AffineFastState.Bounded env6377 := by
  intro p hp
  have h : env6377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6376_6377 : H12AffineEnvironment.transform 8 1 env6376 = env6377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6376 == env6377) = true)

def env6378 : List Nat := [2,4,8,4,1,5,8,4,1,15,0,1,9,1,1,2,0,1,15,1,0,14,11,3,8,10,0,0,0,0,14,0,4,0,14,15]

theorem envBound6378 : H12AffineFastState.Bounded env6378 := by
  intro p hp
  have h : env6378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6377_6378 : H12AffineEnvironment.transform 3 4 env6377 = env6378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6377 == env6378) = true)

def env6379 : List Nat := [2,0,8,0,1,1,8,0,1,11,0,1,9,1,1,2,0,1,11,1,0,10,11,3,8,10,0,0,0,0,10,0,0,0,10,11]

theorem envBound6379 : H12AffineFastState.Bounded env6379 := by
  intro p hp
  have h : env6379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6378_6379 : H12AffineEnvironment.transform 1 0 env6378 = env6379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6378 == env6379) = true)

theorem identity6379 : scanCanonicalize (H12AffineFastState.compose env6379 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6379 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6380 : List Nat := [2,0,3,0,1,1,3,0,1,0,0,1,2,1,1,2,0,1,0,1,0,1,0,3,3,1,0,0,0,0,1,0,0,0,1,0]

theorem envBound6380 : H12AffineFastState.Bounded env6380 := by
  intro p hp
  have h : env6380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6379_6380 : H12AffineEnvironment.transform 2 3 env6379 = env6380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6379 == env6380) = true)

def leafEnv6380 : List Nat := [2,0,3,0,1,1,3,0,1,0,0,1,2,1,1,2,0,1,0,1,0,1,0,3,0,3,1,1,0,0,0,0,1,0,0,0,1,2,1,0,1,1,0]

def active6380 : List Nat := [0]

def tree6380 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6380 : H12WitnessSearch.Good tree6380 := H12GlobalWitnessIndex.good

theorem leafIdentity6380 : H12AffineFastState.composeSystem env6380 rootObs = leafEnv6380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6380 rootObs == leafEnv6380) = true)

theorem terminalChecked6380 : H12PackedTerminal.terminalCheckFast leafEnv6380 active6380 tree6380 = true := by decide +kernel

def env6381 : List Nat := [2,1,8,1,1,0,8,1,1,10,0,1,9,1,1,2,0,1,10,1,0,11,11,3,8,10,0,0,0,0,11,0,1,0,11,10]

theorem envBound6381 : H12AffineFastState.Bounded env6381 := by
  intro p hp
  have h : env6381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6378_6381 : H12AffineEnvironment.transform 1 1 env6378 = env6381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6378 == env6381) = true)

def env6382 : List Nat := [2,4,8,5,1,4,8,4,1,15,0,1,9,1,1,2,0,1,15,1,0,15,11,3,8,10,0,0,0,0,14,0,4,0,15,14]

theorem envBound6382 : H12AffineFastState.Bounded env6382 := by
  intro p hp
  have h : env6382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6377_6382 : H12AffineEnvironment.transform 3 5 env6377 = env6382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6377 == env6382) = true)

theorem identity6382 : scanCanonicalize (H12AffineFastState.compose env6382 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6383 : List Nat := [2,4,7,5,1,4,7,4,1,0,0,1,6,1,1,2,0,1,0,1,0,0,4,3,7,5,0,0,0,0,1,0,4,0,0,1]

theorem envBound6383 : H12AffineFastState.Bounded env6383 := by
  intro p hp
  have h : env6383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6382_6383 : H12AffineEnvironment.transform 2 7 env6382 = env6383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6382 == env6383) = true)

def env6384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323793,16385,16893,22641,74794,12644668,257,20560,4239489,8389612]

theorem envBound6384 : H12AffineFastState.Bounded env6384 := by
  intro p hp
  have h : env6384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6333_6384 : H12AffineEnvironment.transform 18 1025 env6333 = env6384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6333 == env6384) = true)

theorem identity6384 : scanCanonicalize (H12AffineFastState.compose env6384 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4292934) := by decide +kernel

theorem selectedBound6384 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4292934,41002,8329,4292887,323793,16385,16893,22641,74794,94330,257,20560,4239489,4293290]

theorem envBound6385 : H12AffineFastState.Bounded env6385 := by
  intro p hp
  have h : env6385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6384_6385 : H12AffineEnvironment.transform 22 4292934 env6384 = env6385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292934 env6384 == env6385) = true)

def env6386 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,323713,16385,16813,22561,74794,94250,257,20480,4239489,4293290]

theorem envBound6386 : H12AffineFastState.Bounded env6386 := by
  intro p hp
  have h : env6386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6385_6386 : H12AffineEnvironment.transform 5 16 env6385 = env6386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6385 == env6386) = true)

def env6387 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,303233,4097,4525,2081,74794,73770,257,0,4239489,4293290]

theorem envBound6387 : H12AffineFastState.Bounded env6387 := by
  intro p hp
  have h : env6387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6386_6387 : H12AffineEnvironment.transform 13 4096 env6386 = env6387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env6386 == env6387) = true)

theorem identity6387 : scanCanonicalize (H12AffineFastState.compose env6387 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33062) := by decide +kernel

theorem selectedBound6387 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env6388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33062,4525,262144,1025,32768,4097,4194304,4194352,41002,8329,4194353,303233,4097,4525,2081,42252,41228,257,0,4239489,4195212]

theorem envBound6388 : H12AffineFastState.Bounded env6388 := by
  intro p hp
  have h : env6388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6387_6388 : H12AffineEnvironment.transform 15 33062 env6387 = env6388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33062 env6387 == env6388) = true)

def env6389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8494,4525,262144,1025,8200,4097,4194304,4194352,34,8329,4194353,262281,4097,4525,2081,1284,260,257,0,4198537,4195212]

theorem envBound6389 : H12AffineFastState.Bounded env6389 := by
  intro p hp
  have h : env6389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6388_6389 : H12AffineEnvironment.transform 14 8200 env6388 = env6389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6388 == env6389) = true)

theorem identity6389 : scanCanonicalize (H12AffineFastState.compose env6389 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound6389 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8494,4525,4383,1025,8200,4097,4194304,4194352,34,8329,4194353,4502,4097,4525,2081,1284,260,257,0,4198537,4195212]

theorem envBound6390 : H12AffineFastState.Bounded env6390 := by
  intro p hp
  have h : env6390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6389_6390 : H12AffineEnvironment.transform 17 4383 env6389 = env6390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env6389 == env6390) = true)

theorem identity6390 : scanCanonicalize (H12AffineFastState.compose env6390 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6390 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1840,8200,8494,1693,1583,1025,8200,1841,4194304,4194352,34,8329,4194353,1702,1841,1693,2081,1284,260,257,0,4196281,4195212]

theorem envBound6391 : H12AffineFastState.Bounded env6391 := by
  intro p hp
  have h : env6391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6390_6391 : H12AffineEnvironment.transform 11 1840 env6390 = env6391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env6390 == env6391) = true)

theorem identity6391 : scanCanonicalize (H12AffineFastState.compose env6391 (packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6391 : packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS < 2^1333 := by decide +kernel

def env6392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1550,1840,8192,1840,8200,8494,1693,1583,1025,8200,1841,4194304,4194352,34,8329,4194353,1702,1841,1693,1583,1284,260,257,0,4196281,4195212]

theorem envBound6392 : H12AffineFastState.Bounded env6392 := by
  intro p hp
  have h : env6392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6391_6392 : H12AffineEnvironment.transform 10 1550 env6391 = env6392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6391 == env6392) = true)

theorem identity6392 : scanCanonicalize (H12AffineFastState.compose env6392 (packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound6392 : packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1550,1840,1031,1840,1039,1321,1693,1583,1025,1039,1841,4194304,4194352,34,1166,4194353,1702,1841,1693,1583,1284,260,257,0,4196281,4195212]

theorem envBound6393 : H12AffineFastState.Bounded env6393 := by
  intro p hp
  have h : env6393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6392_6393 : H12AffineEnvironment.transform 12 1031 env6392 = env6393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env6392 == env6393) = true)

theorem identity6393 : scanCanonicalize (H12AffineFastState.compose env6393 (packedSelected [1,4,7,8,10,11,13] rootPS)) = affineNative (2^(21+1) ^^^ 649) := by decide +kernel

theorem selectedBound6393 : packedSelected [1,4,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env6394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1550,1840,1031,1840,1039,1321,1693,1583,1025,1039,1841,649,697,34,1166,696,1702,1841,1693,1583,1284,260,257,0,1328,261]

theorem envBound6394 : H12AffineFastState.Bounded env6394 := by
  intro p hp
  have h : env6394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6393_6394 : H12AffineEnvironment.transform 21 649 env6393 = env6394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 649 env6393 == env6394) = true)

theorem identity6394 : scanCanonicalize (H12AffineFastState.compose env6394 (packedSelected [0,1,2,3,11] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound6394 : packedSelected [0,1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env6395 : List Nat := [2,4,8,16,32,16,128,256,512,393,903,697,398,697,390,160,788,934,392,390,696,649,697,34,263,696,815,696,788,934,141,260,257,0,185,261]

theorem envBound6395 : H12AffineFastState.Bounded env6395 := by
  intro p hp
  have h : env6395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6394_6395 : H12AffineEnvironment.transform 9 393 env6394 = env6395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env6394 == env6395) = true)

theorem identity6395 : scanCanonicalize (H12AffineFastState.compose env6395 (packedSelected [0,1,3,7,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6395 : packedSelected [0,1,3,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env6396 : List Nat := [2,4,8,16,32,16,128,172,512,37,555,697,34,697,42,160,696,522,36,42,696,649,697,34,171,696,643,696,696,522,141,168,173,0,185,169]

theorem envBound6396 : H12AffineFastState.Bounded env6396 := by
  intro p hp
  have h : env6396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6395_6396 : H12AffineEnvironment.transform 7 172 env6395 = env6396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6395 == env6396) = true)

theorem identity6396 : scanCanonicalize (H12AffineFastState.compose env6396 (packedSelected [0,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6396 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env6397 : List Nat := [2,4,8,16,32,16,40,4,512,37,555,529,34,529,42,8,528,522,36,42,528,545,529,34,3,528,555,528,528,522,37,0,5,0,17,1]

theorem envBound6397 : H12AffineFastState.Bounded env6397 := by
  intro p hp
  have h : env6397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6396_6397 : H12AffineEnvironment.transform 6 40 env6396 = env6397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6396 == env6397) = true)

def env6398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8495,4525,262144,1025,8201,4097,4194304,4194352,35,8329,4194353,262280,4097,4525,2081,1285,261,257,0,4198536,4195212]

theorem envBound6398 : H12AffineFastState.Bounded env6398 := by
  intro p hp
  have h : env6398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6388_6398 : H12AffineEnvironment.transform 14 8201 env6388 = env6398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6388 == env6398) = true)

theorem identity6398 : scanCanonicalize (H12AffineFastState.compose env6398 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266387) := by decide +kernel

theorem selectedBound6398 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8495,4525,262144,1025,8201,4097,266387,266403,35,8329,266402,262280,4097,4525,2081,1285,261,257,0,262171,267039]

theorem envBound6399 : H12AffineFastState.Bounded env6399 := by
  intro p hp
  have h : env6399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6398_6399 : H12AffineEnvironment.transform 21 266387 env6398 = env6399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266387 env6398 == env6399) = true)

theorem identity6399 : scanCanonicalize (H12AffineFastState.compose env6399 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1922) := by decide +kernel

theorem selectedBound6399 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6400 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8495,4525,1922,1025,8201,4097,5905,5921,35,8329,5920,1802,4097,4525,2081,1285,261,257,0,1945,5277]

theorem envBound6400 : H12AffineFastState.Bounded env6400 := by
  intro p hp
  have h : env6400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6399_6400 : H12AffineEnvironment.transform 17 1922 env6399 = env6400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1922 env6399 == env6400) = true)

theorem identity6400 : scanCanonicalize (H12AffineFastState.compose env6400 (packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound6400 : packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env6401 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1802,4096,8192,4096,8201,8495,4525,1922,1025,8201,4097,5905,5921,35,8329,5920,1802,4097,4525,1835,1285,261,257,0,1945,5277]

theorem envBound6401 : H12AffineFastState.Bounded env6401 := by
  intro p hp
  have h : env6401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6400_6401 : H12AffineEnvironment.transform 10 1802 env6400 = env6401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env6400 == env6401) = true)

theorem identity6401 : scanCanonicalize (H12AffineFastState.compose env6401 (packedSelected [3,4,5,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 4887) := by decide +kernel

theorem selectedBound6401 : packedSelected [3,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6402 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1802,4096,4887,4096,4894,4664,4525,1922,1025,4894,4097,5905,5921,35,5022,5920,1802,4097,4525,1835,1285,261,257,0,1945,5277]

theorem envBound6402 : H12AffineFastState.Bounded env6402 := by
  intro p hp
  have h : env6402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6401_6402 : H12AffineEnvironment.transform 12 4887 env6401 = env6402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4887 env6401 == env6402) = true)

theorem identity6402 : scanCanonicalize (H12AffineFastState.compose env6402 (packedSelected [4,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6402 : packedSelected [4,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env6403 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,4096,4795,4096,4786,4664,4097,1582,1025,4786,4097,5821,5773,35,4658,5772,1702,4097,4097,1671,1193,169,173,0,1589,5277]

theorem envBound6403 : H12AffineFastState.Bounded env6403 := by
  intro p hp
  have h : env6403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6402_6403 : H12AffineEnvironment.transform 7 172 env6402 = env6403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6402 == env6403) = true)

theorem identity6403 : scanCanonicalize (H12AffineFastState.compose env6403 (packedSelected [4,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6403 : packedSelected [4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env6404 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1191,4096,4282,4096,4275,4153,4097,1071,1025,4275,4097,5308,5260,35,4147,5261,1191,4097,4097,1158,1193,169,173,0,1076,5277]

theorem envBound6404 : H12AffineFastState.Bounded env6404 := by
  intro p hp
  have h : env6404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6403_6404 : H12AffineEnvironment.transform 8 1 env6403 = env6404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6403 == env6404) = true)

theorem identity6404 : scanCanonicalize (H12AffineFastState.compose env6404 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound6404 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env6405 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1191,0,186,0,179,57,1,1071,1025,179,1,1212,1164,35,51,1165,1191,1,1,1158,1193,169,173,0,1076,1181]

theorem envBound6405 : H12AffineFastState.Bounded env6405 := by
  intro p hp
  have h : env6405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6404_6405 : H12AffineEnvironment.transform 11 0 env6404 = env6405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env6404 == env6405) = true)

theorem identity6405 : scanCanonicalize (H12AffineFastState.compose env6405 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6405 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env6406 : List Nat := [2,4,8,16,32,16,41,5,1,1024,1038,0,19,0,26,57,1,1071,1025,26,1,1045,1061,35,51,1060,1038,1,1,1071,1024,0,4,0,1076,1076]

theorem envBound6406 : H12AffineFastState.Bounded env6406 := by
  intro p hp
  have h : env6406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6405_6406 : H12AffineEnvironment.transform 6 41 env6405 = env6406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6405 == env6406) = true)

def env6407 : List Nat := [2,4,8,16,32,16,41,5,1,0,14,0,19,0,26,57,1,47,1,26,1,21,37,35,51,36,14,1,1,47,0,0,4,0,52,52]

theorem envBound6407 : H12AffineFastState.Bounded env6407 := by
  intro p hp
  have h : env6407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6406_6407 : H12AffineEnvironment.transform 9 0 env6406 = env6407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env6406 == env6407) = true)

theorem identity6407 : scanCanonicalize (H12AffineFastState.compose env6407 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6408 : List Nat := [2,4,8,10,32,10,41,5,1,0,14,0,9,0,0,35,1,47,1,0,1,15,37,35,41,36,14,1,1,47,0,0,4,0,46,46]

theorem envBound6408 : H12AffineFastState.Bounded env6408 := by
  intro p hp
  have h : env6408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6407_6408 : H12AffineEnvironment.transform 3 10 env6407 = env6408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6407 == env6408) = true)

def env6409 : List Nat := [2,4,8,10,0,10,9,5,1,0,14,0,9,0,0,3,1,15,1,0,1,15,5,3,9,4,14,1,1,15,0,0,4,0,14,14]

theorem envBound6409 : H12AffineFastState.Bounded env6409 := by
  intro p hp
  have h : env6409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6408_6409 : H12AffineEnvironment.transform 4 0 env6408 = env6409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6408 == env6409) = true)

def env6410 : List Nat := [2,0,8,10,0,10,9,1,1,0,10,0,9,0,0,3,1,11,1,0,1,11,1,3,9,0,10,1,1,11,0,0,0,0,10,10]

theorem envBound6410 : H12AffineFastState.Bounded env6410 := by
  intro p hp
  have h : env6410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6409_6410 : H12AffineEnvironment.transform 1 0 env6409 = env6410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6409 == env6410) = true)

def env6411 : List Nat := [2,1,8,10,0,10,9,0,1,0,11,0,9,0,0,3,1,10,1,0,1,10,0,3,9,1,11,1,1,10,0,0,1,0,11,11]

theorem envBound6411 : H12AffineFastState.Bounded env6411 := by
  intro p hp
  have h : env6411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6409_6411 : H12AffineEnvironment.transform 1 1 env6409 = env6411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6409 == env6411) = true)

theorem identity6411 : scanCanonicalize (H12AffineFastState.compose env6411 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6411 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6412 : List Nat := [2,1,3,1,0,1,2,0,1,0,0,0,2,0,0,3,1,1,1,0,1,1,0,3,2,1,0,1,1,1,0,0,1,0,0,0]

theorem envBound6412 : H12AffineFastState.Bounded env6412 := by
  intro p hp
  have h : env6412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6411_6412 : H12AffineEnvironment.transform 2 3 env6411 = env6412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6411 == env6412) = true)

def leafEnv6412 : List Nat := [2,1,3,1,0,1,2,0,1,0,0,0,2,0,0,3,1,1,1,0,1,1,0,3,1,2,1,1,0,1,1,1,0,0,1,0,0,3,0,0,1,1,0]

def active6412 : List Nat := [0]

def tree6412 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6412 : H12WitnessSearch.Good tree6412 := H12GlobalWitnessIndex.good

theorem leafIdentity6412 : H12AffineFastState.composeSystem env6412 rootObs = leafEnv6412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6412 rootObs == leafEnv6412) = true)

theorem terminalChecked6412 : H12PackedTerminal.terminalCheckFast leafEnv6412 active6412 tree6412 = true := by decide +kernel

def env6413 : List Nat := [2,4,8,10,1,10,8,5,1,0,14,0,9,0,0,2,1,14,1,0,1,15,4,2,8,5,14,1,1,14,0,0,4,0,15,15]

theorem envBound6413 : H12AffineFastState.Bounded env6413 := by
  intro p hp
  have h : env6413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6408_6413 : H12AffineEnvironment.transform 4 1 env6408 = env6413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6408 == env6413) = true)

theorem identity6413 : scanCanonicalize (H12AffineFastState.compose env6413 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6414 : List Nat := [2,4,6,4,1,4,6,5,1,0,0,0,7,0,0,2,1,0,1,0,1,1,4,2,6,5,0,1,1,0,0,0,4,0,1,1]

theorem envBound6414 : H12AffineFastState.Bounded env6414 := by
  intro p hp
  have h : env6414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6413_6414 : H12AffineEnvironment.transform 2 6 env6413 = env6414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6413 == env6414) = true)

def env6415 : List Nat := [2,4,8,16,32,16,41,5,1,1,15,0,19,0,26,57,1,46,0,26,1,20,36,35,51,37,15,1,1,46,1,0,4,0,53,53]

theorem envBound6415 : H12AffineFastState.Bounded env6415 := by
  intro p hp
  have h : env6415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6406_6415 : H12AffineEnvironment.transform 9 1 env6406 = env6415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env6406 == env6415) = true)

theorem identity6415 : scanCanonicalize (H12AffineFastState.compose env6415 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound6415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6416 : List Nat := [2,4,8,16,14,16,7,5,1,1,15,0,19,0,26,23,1,0,0,26,1,20,10,13,29,11,15,1,1,0,1,0,4,0,27,27]

theorem envBound6416 : H12AffineFastState.Bounded env6416 := by
  intro p hp
  have h : env6416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6415_6416 : H12AffineEnvironment.transform 4 14 env6415 = env6416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env6415 == env6416) = true)

def env6417 : List Nat := [2,4,8,4,14,4,7,5,1,1,15,0,7,0,14,3,1,0,0,14,1,0,10,13,9,11,15,1,1,0,1,0,4,0,15,15]

theorem envBound6417 : H12AffineFastState.Bounded env6417 := by
  intro p hp
  have h : env6417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6416_6417 : H12AffineEnvironment.transform 3 4 env6416 = env6417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6416 == env6417) = true)

def env6418 : List Nat := [2,0,8,0,10,0,3,1,1,1,11,0,3,0,10,3,1,0,0,10,1,0,10,9,9,11,11,1,1,0,1,0,0,0,11,11]

theorem envBound6418 : H12AffineFastState.Bounded env6418 := by
  intro p hp
  have h : env6418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6417_6418 : H12AffineEnvironment.transform 1 0 env6417 = env6418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6417 == env6418) = true)

def env6419 : List Nat := [2,1,8,1,11,1,2,0,1,1,10,0,2,0,11,3,1,0,0,11,1,0,10,8,9,11,10,1,1,0,1,0,1,0,10,10]

theorem envBound6419 : H12AffineFastState.Bounded env6419 := by
  intro p hp
  have h : env6419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6417_6419 : H12AffineEnvironment.transform 1 1 env6417 = env6419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6417 == env6419) = true)

theorem identity6419 : scanCanonicalize (H12AffineFastState.compose env6419 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6419 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6420 : List Nat := [2,1,2,1,1,1,2,0,1,1,0,0,2,0,1,3,1,0,0,1,1,0,0,2,3,1,0,1,1,0,1,0,1,0,0,0]

theorem envBound6420 : H12AffineFastState.Bounded env6420 := by
  intro p hp
  have h : env6420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6419_6420 : H12AffineEnvironment.transform 2 2 env6419 = env6420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6419 == env6420) = true)

def leafEnv6420 : List Nat := [2,1,2,1,1,1,2,0,1,1,0,0,2,0,1,3,1,0,0,1,1,0,0,2,0,3,1,1,0,1,1,0,1,0,1,0,0,2,0,0,1,1,0]

def active6420 : List Nat := [0]

def tree6420 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6420 : H12WitnessSearch.Good tree6420 := H12GlobalWitnessIndex.good

theorem leafIdentity6420 : H12AffineFastState.composeSystem env6420 rootObs = leafEnv6420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6420 rootObs == leafEnv6420) = true)

theorem terminalChecked6420 : H12PackedTerminal.terminalCheckFast leafEnv6420 active6420 tree6420 = true := by decide +kernel

def env6421 : List Nat := [2,4,8,5,14,5,7,5,1,1,15,0,6,0,15,2,1,0,0,15,1,1,10,13,8,11,15,1,1,0,1,0,4,0,14,14]

theorem envBound6421 : H12AffineFastState.Bounded env6421 := by
  intro p hp
  have h : env6421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6416_6421 : H12AffineEnvironment.transform 3 5 env6416 = env6421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6416 == env6421) = true)

theorem identity6421 : scanCanonicalize (H12AffineFastState.compose env6421 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6422 : List Nat := [2,4,7,5,1,5,7,5,1,1,0,0,6,0,0,2,1,0,0,0,1,1,5,2,7,4,0,1,1,0,1,0,4,0,1,1]

theorem envBound6422 : H12AffineFastState.Bounded env6422 := by
  intro p hp
  have h : env6422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6421_6422 : H12AffineEnvironment.transform 2 7 env6421 = env6422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6421 == env6422) = true)

def env6423 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,303232,4096,4524,2080,74794,73771,257,1,4239489,4293290]

theorem envBound6423 : H12AffineFastState.Bounded env6423 := by
  intro p hp
  have h : env6423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6386_6423 : H12AffineEnvironment.transform 13 4097 env6386 = env6423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env6386 == env6423) = true)

theorem identity6423 : scanCanonicalize (H12AffineFastState.compose env6423 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound6423 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6424 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4097,73891,41397,41002,8329,41396,303232,4096,4524,2080,74794,73771,257,1,102434,41481]

theorem envBound6424 : H12AffineFastState.Bounded env6424 := by
  intro p hp
  have h : env6424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6423_6424 : H12AffineEnvironment.transform 21 73891 env6423 = env6424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env6423 == env6424) = true)

theorem identity6424 : scanCanonicalize (H12AffineFastState.compose env6424 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 75954) := by decide +kernel

theorem selectedBound6424 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6425 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,75954,1025,32768,4097,73891,41397,41002,8329,41396,100402,4096,4524,2080,74794,73771,257,1,102434,41481]

theorem envBound6425 : H12AffineFastState.Bounded env6425 := by
  intro p hp
  have h : env6425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6424_6425 : H12AffineEnvironment.transform 17 75954 env6424 = env6425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75954 env6424 == env6425) = true)

theorem identity6425 : scanCanonicalize (H12AffineFastState.compose env6425 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound6425 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6426 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,33167,4525,43325,1025,32768,4097,41260,41397,41002,8329,41396,2493,4096,4524,2080,42405,41380,257,1,4525,41481]

theorem envBound6426 : H12AffineFastState.Bounded env6426 := by
  intro p hp
  have h : env6426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6425_6426 : H12AffineEnvironment.transform 15 33167 env6425 = env6426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env6425 == env6426) = true)

theorem identity6426 : scanCanonicalize (H12AffineFastState.compose env6426 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound6426 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env6427 : List Nat := [2,4,8,16,32,16,128,256,512,1024,950,4096,8192,4097,32768,33167,4525,41611,1025,32768,4097,41260,41397,41002,8329,41396,523,4096,4524,918,42405,41380,257,1,4525,41481]

theorem envBound6427 : H12AffineFastState.Bounded env6427 := by
  intro p hp
  have h : env6427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6426_6427 : H12AffineEnvironment.transform 10 950 env6426 = env6427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env6426 == env6427) = true)

theorem identity6427 : scanCanonicalize (H12AffineFastState.compose env6427 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound6427 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env6428 : List Nat := [2,4,8,16,32,16,128,256,512,1024,950,4096,8192,4097,13972,14107,4525,5151,1025,13972,4097,6072,5921,5822,8329,5920,523,4096,4524,918,4913,5936,257,1,4525,5277]

theorem envBound6428 : H12AffineFastState.Bounded env6428 := by
  intro p hp
  have h : env6428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6427_6428 : H12AffineEnvironment.transform 14 13972 env6427 = env6428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env6427 == env6428) = true)

theorem identity6428 : scanCanonicalize (H12AffineFastState.compose env6428 (packedSelected [0,1,4,5,7,8,9,12,15,21,24] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound6428 : packedSelected [0,1,4,5,7,8,9,12,15,21,24] rootPS < 2^1333 := by decide +kernel

def env6429 : List Nat := [2,4,8,16,32,16,128,256,512,1024,950,4096,8,4097,5788,5907,4525,5151,1025,5788,4097,6072,5921,5822,129,5920,523,4096,4524,918,4913,5936,257,1,4525,5277]

theorem envBound6429 : H12AffineFastState.Bounded env6429 := by
  intro p hp
  have h : env6429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6428_6429 : H12AffineEnvironment.transform 12 8 env6428 = env6429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env6428 == env6429) = true)

theorem identity6429 : scanCanonicalize (H12AffineFastState.compose env6429 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1687) := by decide +kernel

theorem selectedBound6429 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6430 : List Nat := [2,4,8,16,32,16,128,256,512,1024,950,1687,8,1686,11,388,1850,648,1025,11,1686,303,438,41,129,439,523,1687,1851,918,1446,423,257,1,1850,522]

theorem envBound6430 : H12AffineFastState.Bounded env6430 := by
  intro p hp
  have h : env6430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6429_6430 : H12AffineEnvironment.transform 11 1687 env6429 = env6430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1687 env6429 == env6430) = true)

theorem identity6430 : scanCanonicalize (H12AffineFastState.compose env6430 (packedSelected [0,3,4,5,6,7,8,9,12,13,15,28] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound6430 : packedSelected [0,3,4,5,6,7,8,9,12,13,15,28] rootPS < 2^1333 := by decide +kernel

def env6431 : List Nat := [2,4,8,16,32,16,57,256,512,1024,783,1582,8,1583,11,317,1850,561,1025,11,1583,303,271,41,56,270,523,1582,1851,815,1311,286,257,1,1850,522]

theorem envBound6431 : H12AffineFastState.Bounded env6431 := by
  intro p hp
  have h : env6431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6430_6431 : H12AffineEnvironment.transform 6 57 env6430 = env6431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env6430 == env6431) = true)

theorem identity6431 : scanCanonicalize (H12AffineFastState.compose env6431 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound6431 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6432 : List Nat := [2,4,8,16,32,16,57,30,512,1024,529,1582,8,1583,11,35,1572,561,1025,11,1583,49,17,41,56,16,523,1582,1573,561,1025,0,31,1,1572,522]

theorem envBound6432 : H12AffineFastState.Bounded env6432 := by
  intro p hp
  have h : env6432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6431_6432 : H12AffineEnvironment.transform 7 30 env6431 = env6432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env6431 == env6432) = true)

def env6433 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4292887,41002,8329,4292887,323712,16385,16812,22560,74794,94251,257,20481,4239489,4293290]

theorem envBound6433 : H12AffineFastState.Bounded env6433 := by
  intro p hp
  have h : env6433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6385_6433 : H12AffineEnvironment.transform 5 17 env6385 = env6433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6385 == env6433) = true)

theorem identity6433 : scanCanonicalize (H12AffineFastState.compose env6433 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98474) := by decide +kernel

theorem selectedBound6433 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6434 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98474,445,41002,8329,445,323712,16385,16812,22560,74794,94251,257,20481,77867,512]

theorem envBound6434 : H12AffineFastState.Bounded env6434 := by
  intro p hp
  have h : env6434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6433_6434 : H12AffineEnvironment.transform 21 98474 env6433 = env6434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98474 env6433 == env6434) = true)

theorem identity6434 : scanCanonicalize (H12AffineFastState.compose env6434 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6434 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6435 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1025,32768,4097,41349,445,41002,8329,445,323712,16385,16812,22560,1285,20740,257,20481,4356,512]

theorem envBound6435 : H12AffineFastState.Bounded env6435 := by
  intro p hp
  have h : env6435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6434_6435 : H12AffineEnvironment.transform 15 8495 env6434 = env6435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6434 == env6435) = true)

theorem identity6435 : scanCanonicalize (H12AffineFastState.compose env6435 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6435 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6436 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1025,26261,4097,18192,445,18111,8329,445,267797,16385,16812,22560,1285,20740,257,20481,4356,512]

theorem envBound6436 : H12AffineFastState.Bounded env6436 := by
  intro p hp
  have h : env6436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6435_6436 : H12AffineEnvironment.transform 14 26261 env6435 = env6436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6435 == env6436) = true)

theorem identity6436 : scanCanonicalize (H12AffineFastState.compose env6436 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound6436 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6437 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,262144,1025,14136,4097,5821,445,5906,8329,445,267797,4524,4097,2445,1285,169,257,428,4356,512]

theorem envBound6437 : H12AffineFastState.Bounded env6437 := by
  intro p hp
  have h : env6437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6436_6437 : H12AffineEnvironment.transform 13 4525 env6436 = env6437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env6436 == env6437) = true)

theorem identity6437 : scanCanonicalize (H12AffineFastState.compose env6437 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6437 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6438 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,2184,1025,14136,4097,5821,445,5906,8329,445,7837,4524,4097,2445,1285,169,257,428,4356,512]

theorem envBound6438 : H12AffineFastState.Bounded env6438 := by
  intro p hp
  have h : env6438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6437_6438 : H12AffineEnvironment.transform 17 2184 env6437 = env6438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6437 == env6438) = true)

theorem identity6438 : scanCanonicalize (H12AffineFastState.compose env6438 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6438 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6439 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4357,14136,8495,4356,2080,1025,14136,4097,5653,277,5906,8225,277,7733,4356,4097,2341,1285,1,257,260,4356,512]

theorem envBound6439 : H12AffineFastState.Bounded env6439 := by
  intro p hp
  have h : env6439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6438_6439 : H12AffineEnvironment.transform 6 40 env6438 = env6439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6438 == env6439) = true)

theorem identity6439 : scanCanonicalize (H12AffineFastState.compose env6439 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6439 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6440 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13884,8235,4096,2080,1025,13884,4097,5653,17,5654,8225,17,7733,4096,4097,2081,1025,1,5,0,4096,512]

theorem envBound6440 : H12AffineFastState.Bounded env6440 := by
  intro p hp
  have h : env6440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6439_6440 : H12AffineEnvironment.transform 7 4 env6439 = env6440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6439 == env6440) = true)

theorem identity6440 : scanCanonicalize (H12AffineFastState.compose env6440 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 7740) := by decide +kernel

theorem selectedBound6440 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6441 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,7740,4097,2048,7703,4096,2080,1025,2048,4097,5653,17,5654,7709,17,7733,4096,4097,2081,1025,1,5,0,4096,512]

theorem envBound6441 : H12AffineFastState.Bounded env6441 := by
  intro p hp
  have h : env6441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6440_6441 : H12AffineEnvironment.transform 12 7740 env6440 = env6441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7740 env6440 == env6441) = true)

theorem identity6441 : scanCanonicalize (H12AffineFastState.compose env6441 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6441 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6442 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1551,4096,4147,4097,1551,4120,4096,1583,1025,1551,4097,5653,17,5654,4114,17,4154,4096,4097,1582,1025,1,5,0,4096,512]

theorem envBound6442 : H12AffineFastState.Bounded env6442 := by
  intro p hp
  have h : env6442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6441_6442 : H12AffineEnvironment.transform 10 1551 env6441 = env6442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6441 == env6442) = true)

theorem identity6442 : scanCanonicalize (H12AffineFastState.compose env6442 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6442 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6443 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1070,4096,4147,4097,1070,4120,4096,1038,1025,1070,4097,5172,17,5175,4114,17,4154,4096,4097,1039,1025,1,5,0,4096,33]

theorem envBound6443 : H12AffineFastState.Bounded env6443 := by
  intro p hp
  have h : env6443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6442_6443 : H12AffineEnvironment.transform 8 33 env6442 = env6443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6442 == env6443) = true)

theorem identity6443 : scanCanonicalize (H12AffineFastState.compose env6443 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound6443 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6444 : List Nat := [2,4,8,16,32,17,40,4,33,15,33,4096,4147,4097,33,4120,4096,1,14,33,4097,4155,17,4152,4114,17,4154,4096,4097,0,14,1,5,0,4096,33]

theorem envBound6444 : H12AffineFastState.Bounded env6444 := by
  intro p hp
  have h : env6444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6443_6444 : H12AffineEnvironment.transform 9 15 env6443 = env6444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env6443 == env6444) = true)

theorem identity6444 : scanCanonicalize (H12AffineFastState.compose env6444 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6445 : List Nat := [2,4,8,16,27,17,19,4,26,15,26,4096,4104,4097,26,4120,4096,1,14,26,4097,4096,17,4099,4114,17,4097,4096,4097,0,14,1,5,0,4096,26]

theorem envBound6445 : H12AffineFastState.Bounded env6445 := by
  intro p hp
  have h : env6445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6444_6445 : H12AffineEnvironment.transform 4 27 env6444 = env6445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6444 == env6445) = true)

end H12CloudChart0