import H12CloudChart0Data177

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity45085 : scanCanonicalize (H12AffineFastState.compose env45085 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound45085 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,396324,272513,452769,41430,8328,65,292136,458144,45524,10400,399800,144493,256,21793,46213,453296]

theorem envBound45086 : H12AffineFastState.Bounded env45086 := by
  intro p hp
  have h : env45086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45085_45086 : H12AffineEnvironment.transform 15 54495 env45085 = env45086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env45085 == env45086) = true)

def env45087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,396324,272393,452649,41310,8192,65,292136,458024,45404,10280,399664,144493,256,21793,46093,453176]

theorem envBound45087 : H12AffineFastState.Bounded env45087 := by
  intro p hp
  have h : env45087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45086_45087 : H12AffineEnvironment.transform 6 8 env45086 = env45087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45086 == env45087) = true)

theorem identity45087 : scanCanonicalize (H12AffineFastState.compose env45087 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound45087 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54359,131072,262144,1024,32769,396324,264304,444496,33063,121,65,283985,449873,37157,2129,399664,136212,256,21793,38004,444993]

theorem envBound45088 : H12AffineFastState.Bounded env45088 := by
  intro p hp
  have h : env45088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45087_45088 : H12AffineEnvironment.transform 12 121 env45087 = env45088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env45087 == env45088) = true)

theorem identity45088 : scanCanonicalize (H12AffineFastState.compose env45088 (packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182289) := by decide +kernel

theorem selectedBound45088 : packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54359,131072,182289,1024,32769,50229,180321,65,33063,121,65,171328,5440,37157,2129,53537,136212,256,21793,38004,592]

theorem envBound45089 : H12AffineFastState.Bounded env45089 := by
  intro p hp
  have h : env45089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45088_45089 : H12AffineEnvironment.transform 17 182289 env45088 = env45089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182289 env45088 == env45089) = true)

theorem identity45089 : scanCanonicalize (H12AffineFastState.compose env45089 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound45089 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env45090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54359,5393,56576,1024,32769,50229,54640,65,33063,121,65,34897,5440,37157,2129,53537,261,256,21793,38004,592]

theorem envBound45090 : H12AffineFastState.Bounded env45090 := by
  intro p hp
  have h : env45090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45089_45090 : H12AffineEnvironment.transform 16 5393 env45089 = env45090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env45089 == env45090) = true)

theorem identity45090 : scanCanonicalize (H12AffineFastState.compose env45090 (packedSelected [2,6,9,11,14,17,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound45090 : packedSelected [2,6,9,11,14,17,18,22] rootPS < 2^1333 := by decide +kernel

def env45091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21841,262,5393,2129,1024,21840,4452,33,65,21622,121,65,23808,5440,17524,2129,1136,261,256,21793,16677,592]

theorem envBound45091 : H12AffineFastState.Bounded env45091 := by
  intro p hp
  have h : env45091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45090_45091 : H12AffineEnvironment.transform 14 21841 env45090 = env45091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env45090 == env45091) = true)

theorem identity45091 : scanCanonicalize (H12AffineFastState.compose env45091 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound45091 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5157,372,262,5393,2129,1024,373,4452,33,65,83,121,65,2341,5440,4177,2129,1136,261,256,260,5376,592]

theorem envBound45092 : H12AffineFastState.Bounded env45092 := by
  intro p hp
  have h : env45092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45091_45092 : H12AffineEnvironment.transform 13 5157 env45091 = env45092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env45091 == env45092) = true)

theorem identity45092 : scanCanonicalize (H12AffineFastState.compose env45092 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45092 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env45093 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,81,35,5172,2129,1024,80,4161,33,65,83,121,65,2048,5221,4177,2129,1136,32,37,33,5157,592]

theorem envBound45093 : H12AffineFastState.Bounded env45093 := by
  intro p hp
  have h : env45093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45092_45093 : H12AffineEnvironment.transform 7 37 env45092 = env45093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45092 == env45093) = true)

def env45094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,396324,272392,452648,41311,8193,65,292136,458025,45405,10281,399665,144493,256,21793,46092,453177]

theorem envBound45094 : H12AffineFastState.Bounded env45094 := by
  intro p hp
  have h : env45094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45086_45094 : H12AffineEnvironment.transform 6 9 env45086 = env45094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45086 == env45094) = true)

theorem identity45094 : scanCanonicalize (H12AffineFastState.compose env45094 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound45094 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157801,1024,32769,25677,147553,32833,41311,8193,65,138561,38208,45405,10281,29016,144493,256,21793,46092,33360]

theorem envBound45095 : H12AffineFastState.Bounded env45095 := by
  intro p hp
  have h : env45095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45094_45095 : H12AffineEnvironment.transform 17 157801 env45094 = env45095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env45094 == env45095) = true)

theorem identity45095 : scanCanonicalize (H12AffineFastState.compose env45095 (packedSelected [3,7,8,12,14,15,17,20,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound45095 : packedSelected [3,7,8,12,14,15,17,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env45096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21511,131072,157801,1024,80,25677,147553,16,8462,8193,65,138561,5393,12556,10281,29016,144493,256,21793,13405,513]

theorem envBound45096 : H12AffineFastState.Bounded env45096 := by
  intro p hp
  have h : env45096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45095_45096 : H12AffineEnvironment.transform 14 81 env45095 = env45096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env45095 == env45096) = true)

theorem identity45096 : scanCanonicalize (H12AffineFastState.compose env45096 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound45096 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21511,16449,10280,1024,80,25677,32,16,8462,8193,65,23808,5393,12556,10281,29016,29740,256,21793,13405,513]

theorem envBound45097 : H12AffineFastState.Bounded env45097 := by
  intro p hp
  have h : env45097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45096_45097 : H12AffineEnvironment.transform 16 16449 env45096 = env45097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env45096 == env45097) = true)

theorem identity45097 : scanCanonicalize (H12AffineFastState.compose env45097 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45097 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,262,5440,10280,1024,80,12620,32,16,8462,8193,65,2049,5393,12556,10281,9305,8493,256,32,13405,513]

theorem envBound45098 : H12AffineFastState.Bounded env45098 := by
  intro p hp
  have h : env45098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45097_45098 : H12AffineEnvironment.transform 13 5377 env45097 = env45098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45097 == env45098) = true)

theorem identity45098 : scanCanonicalize (H12AffineFastState.compose env45098 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45098 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,81,262,5440,2421,1024,80,4113,32,16,83,348,65,2049,5393,4177,2420,1284,112,256,32,5376,513]

theorem envBound45099 : H12AffineFastState.Bounded env45099 := by
  intro p hp
  have h : env45099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45098_45099 : H12AffineEnvironment.transform 12 349 env45098 = env45099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45098 == env45099) = true)

theorem identity45099 : scanCanonicalize (H12AffineFastState.compose env45099 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound45099 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env45100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,349,2048,81,262,2113,2421,1024,80,3344,32,16,83,348,65,2049,2064,3408,2420,1284,112,256,32,2049,513]

theorem envBound45100 : H12AffineFastState.Bounded env45100 := by
  intro p hp
  have h : env45100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45099_45100 : H12AffineEnvironment.transform 11 3329 env45099 = env45100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env45099 == env45100) = true)

theorem identity45100 : scanCanonicalize (H12AffineFastState.compose env45100 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45100 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env45101 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,269,2048,1,262,2065,2341,1024,0,3344,32,16,3,268,17,2049,2064,3328,2340,1284,32,256,32,2049,513]

theorem envBound45101 : H12AffineFastState.Bounded env45101 := by
  intro p hp
  have h : env45101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45100_45101 : H12AffineEnvironment.transform 5 16 env45100 = env45101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45100 == env45101) = true)

theorem identity45101 : scanCanonicalize (H12AffineFastState.compose env45101 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45102 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,1281,269,0,1,262,17,293,1024,0,1296,32,16,3,268,17,1,16,1280,292,1284,32,256,32,1,513]

theorem envBound45102 : H12AffineFastState.Bounded env45102 := by
  intro p hp
  have h : env45102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45101_45102 : H12AffineEnvironment.transform 10 0 env45101 = env45102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45101 == env45102) = true)

theorem identity45102 : scanCanonicalize (H12AffineFastState.compose env45102 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45102 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45103 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,309,269,0,1,262,17,293,52,0,292,32,16,3,268,17,1,16,308,292,304,32,256,32,1,513]

theorem envBound45103 : H12AffineFastState.Bounded env45103 := by
  intro p hp
  have h : env45103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45102_45103 : H12AffineEnvironment.transform 9 52 env45102 = env45103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45102 == env45103) = true)

theorem identity45103 : scanCanonicalize (H12AffineFastState.compose env45103 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45103 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env45104 : List Nat := [2,4,8,16,32,16,9,37,512,52,0,16,40,0,1,35,17,0,52,0,1,32,16,3,41,17,1,16,17,1,21,32,37,32,1,513]

theorem envBound45104 : H12AffineFastState.Bounded env45104 := by
  intro p hp
  have h : env45104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45103_45104 : H12AffineEnvironment.transform 7 37 env45103 = env45104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45103 == env45104) = true)

def env45105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,8887721,8328,65,4218280,8393984,8804725,8830977,399801,12645452,256,21792,46212,474734]

theorem envBound45105 : H12AffineFastState.Bounded env45105 := by
  intro p hp
  have h : env45105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45011_45105 : H12AffineEnvironment.transform 23 8887721 env45011 = env45105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887721 env45011 == env45105) = true)

def env45106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452768,95497,8328,65,4218280,458144,45525,10401,399801,4594924,256,21792,46212,474734]

theorem envBound45106 : H12AffineFastState.Bounded env45106 := by
  intro p hp
  have h : env45106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45105_45106 : H12AffineEnvironment.transform 22 452768 env45105 = env45106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env45105 == env45106) = true)

def env45107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452768,95497,8328,65,292136,458144,45525,10401,399801,144492,256,21792,46212,474734]

theorem envBound45107 : H12AffineFastState.Bounded env45107 := by
  intro p hp
  have h : env45107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45106_45107 : H12AffineEnvironment.transform 21 272512 env45106 = env45107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45106 == env45107) = true)

theorem identity45107 : scanCanonicalize (H12AffineFastState.compose env45107 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound45107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396324,272512,400500,95497,8328,65,292136,395636,17665,10401,399801,144492,256,21792,16464,474734]

theorem envBound45108 : H12AffineFastState.Bounded env45108 := by
  intro p hp
  have h : env45108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45107_45108 : H12AffineEnvironment.transform 14 29908 env45107 = env45108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env45107 == env45108) = true)

def env45109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140420,32,144596,95497,8328,65,23944,139732,17665,10401,143641,144492,256,21792,16464,202446]

theorem envBound45109 : H12AffineFastState.Bounded env45109 := by
  intro p hp
  have h : env45109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45108_45109 : H12AffineEnvironment.transform 17 10400 env45108 = env45109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45108 == env45109) = true)

theorem identity45109 : scanCanonicalize (H12AffineFastState.compose env45109 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound45109 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env45110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21590,131072,10400,1024,29909,140420,32,144596,8543,8328,65,23944,139732,17665,10401,143641,144492,256,21792,16464,148120]

theorem envBound45110 : H12AffineFastState.Bounded env45110 := by
  intro p hp
  have h : env45110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45109_45110 : H12AffineEnvironment.transform 15 21590 env45109 = env45110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env45109 == env45110) = true)

theorem identity45110 : scanCanonicalize (H12AffineFastState.compose env45110 (packedSelected [3,5,8,10,16,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound45110 : packedSelected [3,5,8,10,16,20,28,31] rootPS < 2^1333 := by decide +kernel

def env45111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8202,131072,10400,1024,137,140420,32,144596,8543,8328,65,10708,139732,12637,10401,143641,144492,256,8572,13324,145092]

theorem envBound45111 : H12AffineFastState.Bounded env45111 := by
  intro p hp
  have h : env45111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45110_45111 : H12AffineEnvironment.transform 13 13404 env45110 = env45111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env45110 == env45111) = true)

theorem identity45111 : scanCanonicalize (H12AffineFastState.compose env45111 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound45111 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8202,13388,10400,1024,137,4296,32,152,8543,8328,65,10708,5528,12637,10401,1365,32,256,8572,13324,648]

theorem envBound45112 : H12AffineFastState.Bounded env45112 := by
  intro p hp
  have h : env45112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45111_45112 : H12AffineEnvironment.transform 16 13388 env45111 = env45112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env45111 == env45112) = true)

theorem identity45112 : scanCanonicalize (H12AffineFastState.compose env45112 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound45112 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env45113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5157,136,115,5173,2265,1024,137,4296,32,152,294,241,65,2477,5528,4388,2264,1365,32,256,261,5237,648]

theorem envBound45113 : H12AffineFastState.Bounded env45113 := by
  intro p hp
  have h : env45113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45112_45113 : H12AffineEnvironment.transform 12 121 env45112 = env45113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env45112 == env45113) = true)

theorem identity45113 : scanCanonicalize (H12AffineFastState.compose env45113 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound45113 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45114 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,121,5157,136,115,5173,2265,1024,137,4296,32,152,139,241,65,2048,5173,4233,2264,1272,32,173,168,5237,648]

theorem envBound45114 : H12AffineFastState.Bounded env45114 := by
  intro p hp
  have h : env45114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45113_45114 : H12AffineEnvironment.transform 7 173 env45113 = env45114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env45113 == env45114) = true)

theorem identity45114 : scanCanonicalize (H12AffineFastState.compose env45114 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45114 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45115 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,1,115,5173,2128,1024,0,4161,32,17,2,120,65,2048,5173,4096,2129,1137,32,36,33,5237,513]

theorem envBound45115 : H12AffineFastState.Bounded env45115 := by
  intro p hp
  have h : env45115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45114_45115 : H12AffineEnvironment.transform 6 9 env45114 = env45115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45114 == env45115) = true)

theorem identity45115 : scanCanonicalize (H12AffineFastState.compose env45115 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound45115 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45116 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1061,121,0,1,115,16,2128,1024,0,1124,32,17,2,120,65,2048,16,1061,2129,1137,32,36,33,80,513]

theorem envBound45116 : H12AffineFastState.Bounded env45116 := by
  intro p hp
  have h : env45116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45115_45116 : H12AffineEnvironment.transform 11 1061 env45115 = env45116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env45115 == env45116) = true)

theorem identity45116 : scanCanonicalize (H12AffineFastState.compose env45116 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound45116 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45117 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1077,1061,121,0,1,115,16,1125,1024,0,1124,32,17,2,120,65,1077,16,1061,1124,1137,32,36,33,80,513]

theorem envBound45117 : H12AffineFastState.Bounded env45117 := by
  intro p hp
  have h : env45117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45116_45117 : H12AffineEnvironment.transform 10 1077 env45116 = env45117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env45116 == env45117) = true)

def env45118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140421,33,144597,95497,8328,65,23945,139733,17665,10401,143640,144492,256,21792,16464,202447]

theorem envBound45118 : H12AffineFastState.Bounded env45118 := by
  intro p hp
  have h : env45118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45108_45118 : H12AffineEnvironment.transform 17 10401 env45108 = env45118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45108 == env45118) = true)

theorem identity45118 : scanCanonicalize (H12AffineFastState.compose env45118 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound45118 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env45119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,131072,10401,1024,29909,140421,33,144597,29911,8328,65,23945,139733,17665,10401,143640,144492,256,21792,16464,136977]

theorem envBound45119 : H12AffineFastState.Bounded env45119 := by
  intro p hp
  have h : env45119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45118_45119 : H12AffineEnvironment.transform 15 478 env45118 = env45119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env45118 == env45119) = true)

theorem identity45119 : scanCanonicalize (H12AffineFastState.compose env45119 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound45119 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env45120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,13389,10401,1024,29909,4296,33,152,29911,8328,65,23945,5528,17665,10401,1365,33,256,21792,16464,9052]

theorem envBound45120 : H12AffineFastState.Bounded env45120 := by
  intro p hp
  have h : env45120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45119_45120 : H12AffineEnvironment.transform 16 13389 env45119 = env45120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env45119 == env45120) = true)

theorem identity45120 : scanCanonicalize (H12AffineFastState.compose env45120 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound45120 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,478,13389,10401,1024,8540,4296,33,152,8542,8328,65,2048,5528,4232,10401,1365,33,256,169,5593,9052]

theorem envBound45121 : H12AffineFastState.Bounded env45121 := by
  intro p hp
  have h : env45121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45120_45121 : H12AffineEnvironment.transform 13 5513 env45120 = env45121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env45120 == env45121) = true)

theorem identity45121 : scanCanonicalize (H12AffineFastState.compose env45121 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45121 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,478,5392,2556,1024,1,4296,33,152,3,469,65,2048,5528,4232,2556,1365,33,256,169,5593,513]

theorem envBound45122 : H12AffineFastState.Bounded env45122 := by
  intro p hp
  have h : env45122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45121_45122 : H12AffineEnvironment.transform 12 349 env45121 = env45122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45121 == env45122) = true)

theorem identity45122 : scanCanonicalize (H12AffineFastState.compose env45122 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45122 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45123 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5373,0,170,5220,2184,1024,1,4296,33,152,3,161,65,2048,5356,4232,2184,1057,33,116,169,5293,513]

theorem envBound45123 : H12AffineFastState.Bounded env45123 := by
  intro p hp
  have h : env45123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45122_45123 : H12AffineEnvironment.transform 7 116 env45122 = env45123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45122 == env45123) = true)

theorem identity45123 : scanCanonicalize (H12AffineFastState.compose env45123 (packedSelected [0,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45123 : packedSelected [0,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env45124 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5293,0,170,5172,2184,1024,1,4248,33,152,3,161,17,2048,5308,4232,2184,1057,33,36,169,5293,513]

theorem envBound45124 : H12AffineFastState.Bounded env45124 := by
  intro p hp
  have h : env45124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45123_45124 : H12AffineEnvironment.transform 5 16 env45123 = env45124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45123 == env45124) = true)

theorem identity45124 : scanCanonicalize (H12AffineFastState.compose env45124 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45124 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env45125 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,35,5172,2049,1024,1,4113,33,17,3,40,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound45125 : H12AffineFastState.Bounded env45125 := by
  intro p hp
  have h : env45125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45124_45125 : H12AffineEnvironment.transform 6 9 env45124 = env45125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45124 == env45125) = true)

def env45126 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1044,0,35,1028,2049,1024,1,33,33,17,3,40,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound45126 : H12AffineFastState.Bounded env45126 := by
  intro p hp
  have h : env45126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45125_45126 : H12AffineEnvironment.transform 11 48 env45125 = env45126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45125 == env45126) = true)

theorem identity45126 : scanCanonicalize (H12AffineFastState.compose env45126 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45127 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,16,9,1044,0,3,1028,2049,1024,1,1,1,17,3,8,17,2048,1029,17,2049,1025,1,4,0,1044,513]

theorem envBound45127 : H12AffineFastState.Bounded env45127 := by
  intro p hp
  have h : env45127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45126_45127 : H12AffineEnvironment.transform 4 0 env45126 = env45127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45126 == env45127) = true)

def env45128 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,9,0,0,3,16,2049,20,1,1,1,17,3,8,17,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound45128 : H12AffineFastState.Bounded env45128 := by
  intro p hp
  have h : env45128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45127_45128 : H12AffineEnvironment.transform 9 20 env45127 = env45128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45127 == env45128) = true)

theorem identity45128 : scanCanonicalize (H12AffineFastState.compose env45128 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45129 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,16,9,0,0,3,16,523,20,1,1,1,17,3,8,17,522,17,17,523,21,1,4,0,0,513]

theorem envBound45129 : H12AffineFastState.Bounded env45129 := by
  intro p hp
  have h : env45129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45128_45129 : H12AffineEnvironment.transform 10 522 env45128 = env45129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45128 == env45129) = true)

def leafEnv45129 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,16,9,0,0,3,16,523,20,1,1,1,17,3,21,8,1,17,522,17,17,523,21,1,4,0,4,2,0,513,1,1,0]

def active45129 : List Nat := [0,1,2,3,8]

def tree45129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45129 : H12WitnessSearch.Good tree45129 := H12GlobalWitnessIndex.good

theorem leafIdentity45129 : H12AffineFastState.composeSystem env45129 rootObs = leafEnv45129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45129 rootObs == leafEnv45129) = true)

theorem terminalChecked45129 : H12PackedTerminal.terminalCheckFast leafEnv45129 active45129 tree45129 = true := by decide +kernel

def env45130 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,9,1,0,3,17,2049,21,1,1,1,17,3,8,17,2048,16,17,2049,20,1,4,0,1,513]

theorem envBound45130 : H12AffineFastState.Bounded env45130 := by
  intro p hp
  have h : env45130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45127_45130 : H12AffineEnvironment.transform 9 21 env45127 = env45130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45127 == env45130) = true)

theorem identity45130 : scanCanonicalize (H12AffineFastState.compose env45130 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45131 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,9,1,0,3,17,1,21,1,1,1,17,3,8,17,0,16,17,1,20,1,4,0,1,513]

theorem envBound45131 : H12AffineFastState.Bounded env45131 := by
  intro p hp
  have h : env45131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45130_45131 : H12AffineEnvironment.transform 10 0 env45130 = env45131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45130 == env45131) = true)

def leafEnv45131 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,9,1,0,3,17,1,21,1,1,1,17,3,20,8,1,17,0,16,17,1,20,1,4,0,4,2,1,513,1,1,0]

def active45131 : List Nat := [0,1,2,3,8]

def tree45131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45131 : H12WitnessSearch.Good tree45131 := H12GlobalWitnessIndex.good

theorem leafIdentity45131 : H12AffineFastState.composeSystem env45131 rootObs = leafEnv45131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45131 rootObs == leafEnv45131) = true)

theorem terminalChecked45131 : H12PackedTerminal.terminalCheckFast leafEnv45131 active45131 tree45131 = true := by decide +kernel

def env45132 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1045,0,35,1029,2049,1024,1,32,33,17,3,40,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound45132 : H12AffineFastState.Bounded env45132 := by
  intro p hp
  have h : env45132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45125_45132 : H12AffineEnvironment.transform 11 49 env45125 = env45132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45125 == env45132) = true)

theorem identity45132 : scanCanonicalize (H12AffineFastState.compose env45132 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45133 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,49,41,0,0,35,16,2049,21,1,32,33,17,3,40,17,2048,17,48,2049,52,33,36,32,0,513]

theorem envBound45133 : H12AffineFastState.Bounded env45133 := by
  intro p hp
  have h : env45133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45132_45133 : H12AffineEnvironment.transform 9 21 env45132 = env45133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45132 == env45133) = true)

def env45134 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,9,0,0,3,16,2049,21,1,0,1,17,3,8,17,2048,17,16,2049,20,1,4,0,0,513]

theorem envBound45134 : H12AffineFastState.Bounded env45134 := by
  intro p hp
  have h : env45134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45133_45134 : H12AffineEnvironment.transform 4 0 env45133 = env45134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45133 == env45134) = true)

theorem identity45134 : scanCanonicalize (H12AffineFastState.compose env45134 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45135 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,0,0,3,16,0,21,1,0,1,17,3,8,17,1,17,16,0,20,1,4,0,0,513]

theorem envBound45135 : H12AffineFastState.Bounded env45135 := by
  intro p hp
  have h : env45135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45134_45135 : H12AffineEnvironment.transform 10 1 env45134 = env45135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45134 == env45135) = true)

def leafEnv45135 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,0,0,3,16,0,21,1,0,1,17,3,20,8,1,17,1,17,16,0,20,1,4,0,4,2,0,513,1,0,0]

def active45135 : List Nat := [0,1,2,3,8]

def tree45135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45135 : H12WitnessSearch.Good tree45135 := H12GlobalWitnessIndex.good

theorem leafIdentity45135 : H12AffineFastState.composeSystem env45135 rootObs = leafEnv45135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45135 rootObs == leafEnv45135) = true)

theorem terminalChecked45135 : H12PackedTerminal.terminalCheckFast leafEnv45135 active45135 tree45135 = true := by decide +kernel

def env45136 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,8,0,0,2,16,2049,21,1,1,0,17,3,9,17,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound45136 : H12AffineFastState.Bounded env45136 := by
  intro p hp
  have h : env45136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45133_45136 : H12AffineEnvironment.transform 4 1 env45133 = env45136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45133 == env45136) = true)

theorem identity45136 : scanCanonicalize (H12AffineFastState.compose env45136 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45137 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,16,8,0,0,2,16,523,21,1,1,0,17,3,9,17,522,17,17,523,21,0,5,1,0,513]

theorem envBound45137 : H12AffineFastState.Bounded env45137 := by
  intro p hp
  have h : env45137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45136_45137 : H12AffineEnvironment.transform 10 522 env45136 = env45137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45136 == env45137) = true)

def leafEnv45137 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,16,8,0,0,2,16,523,21,1,1,0,17,3,21,9,1,17,522,17,17,523,21,0,5,1,4,3,0,513,1,1,0]

def active45137 : List Nat := [0,1,2,3,8]

def tree45137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45137 : H12WitnessSearch.Good tree45137 := H12GlobalWitnessIndex.good

theorem leafIdentity45137 : H12AffineFastState.composeSystem env45137 rootObs = leafEnv45137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45137 rootObs == leafEnv45137) = true)

theorem terminalChecked45137 : H12PackedTerminal.terminalCheckFast leafEnv45137 active45137 tree45137 = true := by decide +kernel

def env45138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452768,95497,8328,65,292137,458144,45525,10401,399801,144493,256,21792,46212,474734]

theorem envBound45138 : H12AffineFastState.Bounded env45138 := by
  intro p hp
  have h : env45138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45106_45138 : H12AffineEnvironment.transform 21 272513 env45106 = env45138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45106 == env45138) = true)

theorem identity45138 : scanCanonicalize (H12AffineFastState.compose env45138 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound45138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,144613,62660,95497,8328,65,158029,57796,45525,10401,1501,144493,256,21792,46212,74250]

theorem envBound45139 : H12AffineFastState.Bounded env45139 := by
  intro p hp
  have h : env45139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45138_45139 : H12AffineEnvironment.transform 17 138340 env45138 = env45139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env45138 == env45139) = true)

theorem identity45139 : scanCanonicalize (H12AffineFastState.compose env45139 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45139 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1024,32769,4160,144613,62660,21762,8328,65,158029,57796,45525,10401,1501,144493,256,21792,46212,513]

theorem envBound45140 : H12AffineFastState.Bounded env45140 := by
  intro p hp
  have h : env45140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45139_45140 : H12AffineEnvironment.transform 15 8203 env45139 = env45140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45139 == env45140) = true)

theorem identity45140 : scanCanonicalize (H12AffineFastState.compose env45140 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45140 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,138340,1024,32769,4160,136632,54681,21762,469,65,149520,49305,37000,2556,1501,136496,256,21792,38361,513]

theorem envBound45141 : H12AffineFastState.Bounded env45141 := by
  intro p hp
  have h : env45141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45140_45141 : H12AffineEnvironment.transform 12 349 env45140 = env45141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45140 == env45141) = true)

theorem identity45141 : scanCanonicalize (H12AffineFastState.compose env45141 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound45141 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env45142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,5528,2556,1024,32769,4160,32,54681,21762,469,65,23944,49305,37000,2556,1501,168,256,21792,38361,513]

theorem envBound45142 : H12AffineFastState.Bounded env45142 := by
  intro p hp
  have h : env45142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45141_45142 : H12AffineEnvironment.transform 16 5528 env45141 = env45142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env45141 == env45142) = true)

theorem identity45142 : scanCanonicalize (H12AffineFastState.compose env45142 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound45142 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env45143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,5528,2556,1024,21897,4160,32,17,21762,469,65,23944,5393,17664,2556,1501,168,256,21792,16465,513]

theorem envBound45143 : H12AffineFastState.Bounded env45143 := by
  intro p hp
  have h : env45143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45142_45143 : H12AffineEnvironment.transform 14 21896 env45142 = env45143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env45142 == env45143) = true)

theorem identity45143 : scanCanonicalize (H12AffineFastState.compose env45143 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound45143 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45144 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21840,342,5440,2340,1024,21841,4160,32,17,21762,269,65,23888,5393,17664,2340,1285,112,256,21792,16465,513]

theorem envBound45144 : H12AffineFastState.Bounded env45144 := by
  intro p hp
  have h : env45144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45143_45144 : H12AffineEnvironment.transform 6 88 env45143 = env45144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45143 == env45144) = true)

theorem identity45144 : scanCanonicalize (H12AffineFastState.compose env45144 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45144 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45145 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,1,342,5440,2340,1024,0,4160,32,17,83,269,65,2049,5393,4177,2340,1285,112,256,113,5376,513]

theorem envBound45145 : H12AffineFastState.Bounded env45145 := by
  intro p hp
  have h : env45145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45144_45145 : H12AffineEnvironment.transform 13 5457 env45144 = env45145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45144 == env45145) = true)

theorem identity45145 : scanCanonicalize (H12AffineFastState.compose env45145 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound45145 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45146 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1637,349,820,1,342,805,2340,1024,0,1573,32,17,83,269,65,2049,884,1588,2340,1285,112,256,113,869,513]

theorem envBound45146 : H12AffineFastState.Bounded env45146 := by
  intro p hp
  have h : env45146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45145_45146 : H12AffineEnvironment.transform 11 1637 env45145 = env45146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env45145 == env45146) = true)

theorem identity45146 : scanCanonicalize (H12AffineFastState.compose env45146 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound45146 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45147 : List Nat := [2,4,8,16,32,64,88,256,512,1024,804,1637,349,820,1,342,805,512,1024,0,1573,32,17,83,269,65,805,884,1588,512,1285,112,256,113,869,513]

theorem envBound45147 : H12AffineFastState.Bounded env45147 := by
  intro p hp
  have h : env45147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45146_45147 : H12AffineEnvironment.transform 10 804 env45146 = env45147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env45146 == env45147) = true)

theorem identity45147 : scanCanonicalize (H12AffineFastState.compose env45147 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45147 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45148 : List Nat := [2,4,8,0,32,64,72,256,512,1024,804,1637,333,804,1,326,805,512,1024,0,1573,32,1,67,269,65,805,868,1572,512,1285,96,256,97,869,513]

theorem envBound45148 : H12AffineFastState.Bounded env45148 := by
  intro p hp
  have h : env45148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45147_45148 : H12AffineEnvironment.transform 3 0 env45147 = env45148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45147 == env45148) = true)

theorem identity45148 : scanCanonicalize (H12AffineFastState.compose env45148 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound45148 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45149 : List Nat := [2,4,8,0,32,64,72,256,512,257,804,868,333,804,1,326,805,512,257,0,804,32,1,67,269,65,805,868,805,512,4,96,256,97,869,513]

theorem envBound45149 : H12AffineFastState.Bounded env45149 := by
  intro p hp
  have h : env45149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45148_45149 : H12AffineEnvironment.transform 9 257 env45148 = env45149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env45148 == env45149) = true)

theorem identity45149 : scanCanonicalize (H12AffineFastState.compose env45149 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45149 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45150 : List Nat := [2,4,8,0,32,64,72,37,512,36,513,577,104,513,1,99,512,512,36,0,513,32,1,67,40,65,512,577,512,512,4,96,37,97,576,513]

theorem envBound45150 : H12AffineFastState.Bounded env45150 := by
  intro p hp
  have h : env45150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45149_45150 : H12AffineEnvironment.transform 7 37 env45149 = env45150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45149 == env45150) = true)

def env45151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452769,95496,8328,65,4218280,458145,45524,10400,399801,4594925,256,21792,46212,474734]

theorem envBound45151 : H12AffineFastState.Bounded env45151 := by
  intro p hp
  have h : env45151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45105_45151 : H12AffineEnvironment.transform 22 452769 env45105 = env45151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env45105 == env45151) = true)

def env45152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452769,95496,8328,65,292136,458145,45524,10400,399801,144493,256,21792,46212,474734]

theorem envBound45152 : H12AffineFastState.Bounded env45152 := by
  intro p hp
  have h : env45152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45151_45152 : H12AffineEnvironment.transform 21 272512 env45151 = env45152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45151 == env45152) = true)

def env45153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272392,452649,95496,8192,65,292136,458025,45404,10280,399665,144493,256,21792,46092,474734]

theorem envBound45153 : H12AffineFastState.Bounded env45153 := by
  intro p hp
  have h : env45153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45152_45153 : H12AffineEnvironment.transform 6 8 env45152 = env45153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45152 == env45153) = true)

def env45154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272392,272441,95496,8192,65,292136,277817,45404,10280,317729,62589,256,21792,46092,392830]

theorem envBound45154 : H12AffineFastState.Bounded env45154 := by
  intro p hp
  have h : env45154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45153_45154 : H12AffineEnvironment.transform 16 49168 env45153 = env45154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45153 == env45154) = true)

theorem identity45154 : scanCanonicalize (H12AffineFastState.compose env45154 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45154 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,262144,1024,8540,290153,272392,272441,95496,8192,65,292136,277817,4097,10280,292988,21792,256,21792,5457,352035]

theorem envBound45155 : H12AffineFastState.Bounded env45155 := by
  intro p hp
  have h : env45155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45154_45155 : H12AffineEnvironment.transform 14 8541 env45154 = env45155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45154 == env45155) = true)

theorem identity45155 : scanCanonicalize (H12AffineFastState.compose env45155 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound45155 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8574,24909,262144,1024,8540,290153,272392,272441,21622,8192,65,292136,277817,4097,10280,292988,21792,256,21792,5457,294493]

theorem envBound45156 : H12AffineFastState.Bounded env45156 := by
  intro p hp
  have h : env45156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45155_45156 : H12AffineEnvironment.transform 15 8574 env45155 = env45156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env45155 == env45156) = true)

theorem identity45156 : scanCanonicalize (H12AffineFastState.compose env45156 (packedSelected [0,3,4,5,7,10,12,15,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound45156 : packedSelected [0,3,4,5,7,10,12,15,18,22,23] rootPS < 2^1333 := by decide +kernel

def env45157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8574,24909,10588,1024,8540,17461,340,357,21622,8192,65,23668,5221,4097,10280,20768,21792,256,21792,5457,22273]

theorem envBound45157 : H12AffineFastState.Bounded env45157 := by
  intro p hp
  have h : env45157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45156_45157 : H12AffineEnvironment.transform 17 10588 env45156 = env45157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env45156 == env45157) = true)

theorem identity45157 : scanCanonicalize (H12AffineFastState.compose env45157 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45157 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env45158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,372,343,16740,2421,1024,373,17461,340,357,21622,41,65,23668,5221,4097,2049,20768,21792,256,21792,5457,22273]

theorem envBound45158 : H12AffineFastState.Bounded env45158 := by
  intro p hp
  have h : env45158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45157_45158 : H12AffineEnvironment.transform 12 41 env45157 = env45158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45157 == env45158) = true)

theorem identity45158 : scanCanonicalize (H12AffineFastState.compose env45158 (packedSelected [1,2,6,8,10,12,14,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound45158 : packedSelected [1,2,6,8,10,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,41,16384,372,343,16740,2421,1024,373,17461,340,357,17462,41,65,19508,1061,65,2049,16736,17760,256,17760,1297,18241]

theorem envBound45159 : H12AffineFastState.Bounded env45159 := by
  intro p hp
  have h : env45159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45158_45159 : H12AffineEnvironment.transform 11 64 env45158 = env45159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env45158 == env45159) = true)

theorem identity45159 : scanCanonicalize (H12AffineFastState.compose env45159 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound45159 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env45160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,41,1344,372,343,1060,2421,1024,373,373,340,357,374,41,65,2420,1061,65,2049,1056,32,256,32,1297,513]

theorem envBound45160 : H12AffineFastState.Bounded env45160 := by
  intro p hp
  have h : env45160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45159_45160 : H12AffineEnvironment.transform 13 1344 env45159 = env45160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env45159 == env45160) = true)

theorem identity45160 : scanCanonicalize (H12AffineFastState.compose env45160 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45160 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45161 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,64,41,1076,0,35,1060,2049,1024,1,1,32,17,2,41,65,2048,1061,65,2049,1056,32,116,32,1125,513]

theorem envBound45161 : H12AffineFastState.Bounded env45161 := by
  intro p hp
  have h : env45161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45160_45161 : H12AffineEnvironment.transform 7 116 env45160 = env45161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45160 == env45161) = true)

theorem identity45161 : scanCanonicalize (H12AffineFastState.compose env45161 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45161 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45162 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,64,41,80,0,35,64,2049,100,1,1,32,17,2,41,65,2048,65,65,2049,68,32,116,32,1,513]

theorem envBound45162 : H12AffineFastState.Bounded env45162 := by
  intro p hp
  have h : env45162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45161_45162 : H12AffineEnvironment.transform 9 100 env45161 = env45162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45161 == env45162) = true)

theorem identity45162 : scanCanonicalize (H12AffineFastState.compose env45162 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45163 : List Nat := [2,4,8,16,32,64,8,116,1,100,2048,64,41,80,0,35,64,2049,100,1,1,32,17,2,41,65,2048,65,65,2049,68,32,116,32,1,0]

theorem envBound45163 : H12AffineFastState.Bounded env45163 := by
  intro p hp
  have h : env45163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45162_45163 : H12AffineEnvironment.transform 8 1 env45162 = env45163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45162 == env45163) = true)

theorem identity45163 : scanCanonicalize (H12AffineFastState.compose env45163 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45164 : List Nat := [2,4,8,16,32,17,8,37,1,53,2048,17,41,1,0,35,17,2049,53,1,1,32,17,2,41,16,2048,16,16,2049,21,32,37,32,1,0]

theorem envBound45164 : H12AffineFastState.Bounded env45164 := by
  intro p hp
  have h : env45164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45163_45164 : H12AffineEnvironment.transform 5 17 env45163 = env45164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45163 == env45164) = true)

theorem identity45164 : scanCanonicalize (H12AffineFastState.compose env45164 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45165 : List Nat := [2,4,8,16,10,17,8,15,1,31,2048,17,3,1,0,9,17,2049,31,1,1,10,17,2,3,16,2048,16,16,2049,21,10,15,10,1,0]

theorem envBound45165 : H12AffineFastState.Bounded env45165 := by
  intro p hp
  have h : env45165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45164_45165 : H12AffineEnvironment.transform 4 10 env45164 = env45165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45164 == env45165) = true)

def env45166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272392,272440,95496,8192,65,292136,277816,45404,10280,317728,62588,256,21792,46092,392831]

theorem envBound45166 : H12AffineFastState.Bounded env45166 := by
  intro p hp
  have h : env45166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45153_45166 : H12AffineEnvironment.transform 16 49169 env45153 = env45166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45153 == env45166) = true)

theorem identity45166 : scanCanonicalize (H12AffineFastState.compose env45166 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound45166 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,17729,41340,41292,95496,8192,65,64604,46156,45404,10280,20564,62588,256,21792,46092,96011]

theorem envBound45167 : H12AffineFastState.Bounded env45167 := by
  intro p hp
  have h : env45167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45166_45167 : H12AffineEnvironment.transform 17 35188 env45166 = env45167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env45166 == env45167) = true)

theorem identity45167 : scanCanonicalize (H12AffineFastState.compose env45167 (packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 41262) := by decide +kernel

theorem selectedBound45167 : packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env45168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41262,49169,35188,1024,32769,17729,41340,41292,54310,8192,65,64604,46156,45404,10280,20564,62588,256,21792,46092,54821]

theorem envBound45168 : H12AffineFastState.Bounded env45168 := by
  intro p hp
  have h : env45168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45167_45168 : H12AffineEnvironment.transform 15 41262 env45167 = env45168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41262 env45167 == env45168) = true)

theorem identity45168 : scanCanonicalize (H12AffineFastState.compose env45168 (packedSelected [8,10,12,15,16,20,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound45168 : packedSelected [8,10,12,15,16,20,28] rootPS < 2^1333 := by decide +kernel

def env45169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,35,24860,10361,1024,8460,17729,113,65,29995,8192,65,23889,5441,4177,10280,20564,21873,256,21792,5377,30504]

theorem envBound45169 : H12AffineFastState.Bounded env45169 := by
  intro p hp
  have h : env45169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45168_45169 : H12AffineEnvironment.transform 14 8461 env45168 = env45169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env45168 == env45169) = true)

theorem identity45169 : scanCanonicalize (H12AffineFastState.compose env45169 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45169 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env45170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,292,35,16693,2128,1024,293,17729,113,65,21762,41,65,23889,5441,4177,2049,20564,21873,256,21792,5377,22273]

theorem envBound45170 : H12AffineFastState.Bounded env45170 := by
  intro p hp
  have h : env45170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45169_45170 : H12AffineEnvironment.transform 12 41 env45169 = env45170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45169 == env45170) = true)

theorem identity45170 : scanCanonicalize (H12AffineFastState.compose env45170 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45170 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45171 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,292,35,16693,2048,1024,293,17681,33,17,21762,41,17,23809,5393,4097,2049,20484,21793,256,21792,5377,22273]

theorem envBound45171 : H12AffineFastState.Bounded env45171 := by
  intro p hp
  have h : env45171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45170_45171 : H12AffineEnvironment.transform 5 16 env45170 = env45171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45170 == env45171) = true)

theorem identity45171 : scanCanonicalize (H12AffineFastState.compose env45171 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45171 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env45172 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,16384,292,35,16693,2048,272,293,16385,33,17,20498,41,17,22545,4097,4097,2049,20484,20529,256,20528,4113,21009]

theorem envBound45172 : H12AffineFastState.Bounded env45172 := by
  intro p hp
  have h : env45172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45171_45172 : H12AffineEnvironment.transform 9 272 env45171 = env45172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45171 == env45172) = true)

theorem identity45172 : scanCanonicalize (H12AffineFastState.compose env45172 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound45172 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45173 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,2048,292,35,2357,2048,272,293,2049,33,17,6162,41,17,4113,4097,4097,2049,6148,6193,256,6192,4113,6673]

theorem envBound45173 : H12AffineFastState.Bounded env45173 := by
  intro p hp
  have h : env45173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45172_45173 : H12AffineEnvironment.transform 13 2048 env45172 = env45173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env45172 == env45173) = true)

def env45174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272393,452648,95496,8193,65,292136,458024,45405,10281,399664,144493,256,21792,46093,474734]

theorem envBound45174 : H12AffineFastState.Bounded env45174 := by
  intro p hp
  have h : env45174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45152_45174 : H12AffineEnvironment.transform 6 9 env45152 = env45174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45152 == env45174) = true)

def env45175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272393,272440,95496,8193,65,292136,277816,45405,10281,317728,62589,256,21792,46093,392830]

theorem envBound45175 : H12AffineFastState.Bounded env45175 := by
  intro p hp
  have h : env45175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45174_45175 : H12AffineEnvironment.transform 16 49168 env45174 = env45175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45174 == env45175) = true)

theorem identity45175 : scanCanonicalize (H12AffineFastState.compose env45175 (packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound45175 : packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env45176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10360,1024,32769,58444,113,64,95496,8193,65,23888,5440,45405,10281,61784,62589,256,21792,46093,120326]

theorem envBound45176 : H12AffineFastState.Bounded env45176 := by
  intro p hp
  have h : env45176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45175_45176 : H12AffineEnvironment.transform 17 10360 env45175 = env45176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env45175 == env45176) = true)

theorem identity45176 : scanCanonicalize (H12AffineFastState.compose env45176 (packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound45176 : packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env45177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,49168,10360,1024,32769,58444,113,64,8542,8193,65,23888,5440,45405,10281,61784,62589,256,21792,46093,33360]

theorem envBound45177 : H12AffineFastState.Bounded env45177 := by
  intro p hp
  have h : env45177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45176_45177 : H12AffineEnvironment.transform 15 21590 env45176 = env45177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env45176 == env45177) = true)

theorem identity45177 : scanCanonicalize (H12AffineFastState.compose env45177 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound45177 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env45178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,16401,10360,1024,0,25677,113,64,8542,8193,65,23888,5440,12636,10281,29017,29820,256,21792,13324,593]

theorem envBound45178 : H12AffineFastState.Bounded env45178 := by
  intro p hp
  have h : env45178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45177_45178 : H12AffineEnvironment.transform 14 1 env45177 = env45178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env45177 == env45178) = true)

theorem identity45178 : scanCanonicalize (H12AffineFastState.compose env45178 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45178 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env45179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,21590,16401,2341,1024,0,17680,113,64,3,348,65,23888,5440,4097,2420,20484,21793,256,21792,5457,593]

theorem envBound45179 : H12AffineFastState.Bounded env45179 := by
  intro p hp
  have h : env45179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45178_45179 : H12AffineEnvironment.transform 12 349 env45178 = env45179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45178 == env45179) = true)

theorem identity45179 : scanCanonicalize (H12AffineFastState.compose env45179 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45179 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45180 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,1,21590,16401,2049,1024,0,17460,113,64,3,120,65,23668,5220,4097,2128,20484,21509,36,21508,5237,593]

theorem envBound45180 : H12AffineFastState.Bounded env45180 := by
  intro p hp
  have h : env45180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45179_45180 : H12AffineEnvironment.transform 7 36 env45179 = env45180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45179 == env45180) = true)

theorem identity45180 : scanCanonicalize (H12AffineFastState.compose env45180 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound45180 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env45181 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,1,115,5172,2049,1024,0,4113,113,64,3,120,65,2129,5220,4097,2128,1057,32,36,33,5237,593]

theorem envBound45181 : H12AffineFastState.Bounded env45181 := by
  intro p hp
  have h : env45181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45180_45181 : H12AffineEnvironment.transform 13 5157 env45180 = env45181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env45180 == env45181) = true)

theorem identity45181 : scanCanonicalize (H12AffineFastState.compose env45181 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound45181 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45182 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3077,121,2080,1,115,2097,2049,1024,0,3092,113,64,3,120,65,2129,2145,3076,2128,1057,32,36,33,2160,593]

theorem envBound45182 : H12AffineFastState.Bounded env45182 := by
  intro p hp
  have h : env45182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45181_45182 : H12AffineEnvironment.transform 11 3077 env45181 = env45182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env45181 == env45182) = true)

theorem identity45182 : scanCanonicalize (H12AffineFastState.compose env45182 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45182 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env45183 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3077,40,2080,1,34,2097,2049,1024,0,3092,32,17,3,41,16,2048,2096,3076,2049,1057,32,36,33,2081,512]

theorem envBound45183 : H12AffineFastState.Bounded env45183 := by
  intro p hp
  have h : env45183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45182_45183 : H12AffineEnvironment.transform 5 17 env45182 = env45183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45182 == env45183) = true)

theorem identity45183 : scanCanonicalize (H12AffineFastState.compose env45183 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45184 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3077,9,2049,1,3,2064,2049,1024,0,3092,1,17,3,8,16,2048,2065,3076,2049,1024,1,5,0,2048,512]

theorem envBound45184 : H12AffineFastState.Bounded env45184 := by
  intro p hp
  have h : env45184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45183_45184 : H12AffineEnvironment.transform 4 1 env45183 = env45184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45183 == env45184) = true)

theorem identity45184 : scanCanonicalize (H12AffineFastState.compose env45184 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45185 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2065,9,2049,1,3,2064,2049,20,0,2048,1,17,3,8,16,2048,2065,2064,2049,20,1,5,0,2048,512]

theorem envBound45185 : H12AffineFastState.Bounded env45185 := by
  intro p hp
  have h : env45185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45184_45185 : H12AffineEnvironment.transform 9 20 env45184 = env45185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45184 == env45185) = true)

theorem identity45185 : scanCanonicalize (H12AffineFastState.compose env45185 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound45185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45186 : List Nat := [2,4,8,16,1,17,9,5,512,20,5,20,9,4,1,3,21,4,20,0,5,1,17,3,8,16,5,20,21,4,20,1,5,0,5,512]

theorem envBound45186 : H12AffineFastState.Bounded env45186 := by
  intro p hp
  have h : env45186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45185_45186 : H12AffineEnvironment.transform 10 5 env45185 = env45186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env45185 == env45186) = true)

def env45187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272393,272441,95496,8193,65,292136,277817,45405,10281,317729,62588,256,21792,46093,392831]

theorem envBound45187 : H12AffineFastState.Bounded env45187 := by
  intro p hp
  have h : env45187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45174_45187 : H12AffineEnvironment.transform 16 49169 env45174 = env45187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45174 == env45187) = true)

theorem identity45187 : scanCanonicalize (H12AffineFastState.compose env45187 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58397,33,17,95496,8193,65,23808,5393,45405,10281,61705,62588,256,21792,46093,120407]

theorem envBound45188 : H12AffineFastState.Bounded env45188 := by
  intro p hp
  have h : env45188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45187_45188 : H12AffineEnvironment.transform 17 10280 env45187 = env45188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45187 == env45188) = true)

theorem identity45188 : scanCanonicalize (H12AffineFastState.compose env45188 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45188 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env45189 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58397,33,17,95496,8193,16,23808,5393,45324,10281,61705,62509,256,21792,46093,120326]

theorem envBound45189 : H12AffineFastState.Bounded env45189 := by
  intro p hp
  have h : env45189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45188_45189 : H12AffineEnvironment.transform 5 17 env45188 = env45189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45188 == env45189) = true)

theorem identity45189 : scanCanonicalize (H12AffineFastState.compose env45189 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound45189 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env45190 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,62730,49169,10280,1024,32769,58397,33,17,32770,8193,16,23808,5393,45324,10281,61705,62509,256,21792,46093,8972]

theorem envBound45190 : H12AffineFastState.Bounded env45190 := by
  intro p hp
  have h : env45190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45189_45190 : H12AffineEnvironment.transform 15 62730 env45189 = env45190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env45189 == env45190) = true)

theorem identity45190 : scanCanonicalize (H12AffineFastState.compose env45190 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45190 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45191 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,8203,5392,10280,1024,21760,12572,33,17,21763,8193,16,23808,5393,25613,10281,9224,8492,256,21792,24844,8972]

theorem envBound45191 : H12AffineFastState.Bounded env45191 := by
  intro p hp
  have h : env45191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45190_45191 : H12AffineEnvironment.transform 14 21761 env45190 = env45191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45190 == env45191) = true)

theorem identity45191 : scanCanonicalize (H12AffineFastState.compose env45191 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound45191 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45192 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,8203,5392,10280,1024,8461,12572,33,17,8462,8193,16,10509,5393,4096,10281,9224,8492,256,8493,5377,8972]

theorem envBound45192 : H12AffineFastState.Bounded env45192 := by
  intro p hp
  have h : env45192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45191_45192 : H12AffineEnvironment.transform 13 13325 env45191 = env45192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env45191 == env45192) = true)

theorem identity45192 : scanCanonicalize (H12AffineFastState.compose env45192 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3387) := by decide +kernel

theorem selectedBound45192 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env45193 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3387,8192,10550,8460,8203,2091,10280,1024,8461,11303,33,17,8462,8193,16,10509,2090,3387,10281,9224,8492,256,8493,2106,8972]

theorem envBound45193 : H12AffineFastState.Bounded env45193 := by
  intro p hp
  have h : env45193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45192_45193 : H12AffineEnvironment.transform 11 3387 env45192 = env45193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3387 env45192 == env45193) = true)

theorem identity45193 : scanCanonicalize (H12AffineFastState.compose env45193 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1843) := by decide +kernel

theorem selectedBound45193 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env45194 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3387,1843,3589,1599,1848,2091,3867,1024,1598,2836,33,17,1597,1842,16,3646,2090,3387,3866,827,1567,256,1566,2106,1087]

theorem envBound45194 : H12AffineFastState.Bounded env45194 := by
  intro p hp
  have h : env45194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45193_45194 : H12AffineEnvironment.transform 12 1843 env45193 = env45194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1843 env45193 == env45194) = true)

theorem identity45194 : scanCanonicalize (H12AffineFastState.compose env45194 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45194 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env45195 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,3354,1810,3589,1566,1817,2058,3867,1024,1567,2836,0,17,1564,1811,16,3615,2059,3354,3866,794,1567,256,1566,2075,1054]

theorem envBound45195 : H12AffineFastState.Bounded env45195 := by
  intro p hp
  have h : env45195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45194_45195 : H12AffineEnvironment.transform 4 1 env45194 = env45195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45194 == env45195) = true)

theorem identity45195 : scanCanonicalize (H12AffineFastState.compose env45195 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound45195 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45196 : List Nat := [2,4,8,16,1,17,9,256,512,543,2048,2821,269,2074,1,262,2058,2308,543,0,2836,0,17,3,268,16,2048,2059,2821,2309,794,0,256,1,2075,513]

theorem envBound45196 : H12AffineFastState.Bounded env45196 := by
  intro p hp
  have h : env45196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45195_45196 : H12AffineEnvironment.transform 9 543 env45195 = env45196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env45195 == env45196) = true)

theorem identity45196 : scanCanonicalize (H12AffineFastState.compose env45196 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound45196 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45197 : List Nat := [2,4,8,16,1,17,9,256,512,543,529,276,269,523,1,262,539,789,543,0,261,0,17,3,268,16,529,538,276,788,794,0,256,1,522,513]

theorem envBound45197 : H12AffineFastState.Bounded env45197 := by
  intro p hp
  have h : env45197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45196_45197 : H12AffineEnvironment.transform 10 529 env45196 = env45197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env45196 == env45197) = true)

theorem identity45197 : scanCanonicalize (H12AffineFastState.compose env45197 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound45197 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45198 : List Nat := [2,4,8,16,1,17,9,30,512,543,529,10,19,523,1,24,539,523,543,0,27,0,17,3,18,16,529,538,10,522,516,0,30,1,522,513]

theorem envBound45198 : H12AffineFastState.Bounded env45198 := by
  intro p hp
  have h : env45198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45197_45198 : H12AffineEnvironment.transform 7 30 env45197 = env45198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env45197 == env45198) = true)

theorem identity45198 : scanCanonicalize (H12AffineFastState.compose env45198 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound45198 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45199 : List Nat := [2,4,8,16,1,17,9,30,26,5,11,10,19,17,1,24,1,17,5,0,27,0,17,3,18,16,11,0,10,16,30,0,30,1,16,27]

theorem envBound45199 : H12AffineFastState.Bounded env45199 := by
  intro p hp
  have h : env45199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45198_45199 : H12AffineEnvironment.transform 8 26 env45198 = env45199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env45198 == env45199) = true)

theorem identity45199 : scanCanonicalize (H12AffineFastState.compose env45199 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound45199 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45200 : List Nat := [2,4,8,2,1,3,9,12,8,5,11,10,1,3,1,10,1,3,5,0,9,0,3,3,0,2,11,0,10,2,12,0,12,1,2,9]

theorem envBound45200 : H12AffineFastState.Bounded env45200 := by
  intro p hp
  have h : env45200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45199_45200 : H12AffineEnvironment.transform 3 2 env45199 = env45200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env45199 == env45200) = true)

theorem identity45200 : scanCanonicalize (H12AffineFastState.compose env45200 (packedSelected [0,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45200 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45201 : List Nat := [1,4,8,1,1,0,9,12,8,5,8,9,1,0,1,9,1,0,5,0,9,0,0,0,0,1,8,0,9,1,12,0,12,1,1,9]

theorem envBound45201 : H12AffineFastState.Bounded env45201 := by
  intro p hp
  have h : env45201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45200_45201 : H12AffineEnvironment.transform 0 1 env45200 = env45201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45200 == env45201) = true)

theorem identity45201 : scanCanonicalize (H12AffineFastState.compose env45201 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45201 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45202 : List Nat := [1,4,4,1,1,0,5,0,4,5,4,5,1,0,1,5,1,0,5,0,5,0,0,0,0,1,4,0,5,1,0,0,0,1,1,5]

theorem envBound45202 : H12AffineFastState.Bounded env45202 := by
  intro p hp
  have h : env45202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45201_45202 : H12AffineEnvironment.transform 2 4 env45201 = env45202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45201 == env45202) = true)

def env45203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452769,95496,8328,65,292137,458145,45524,10400,399801,144492,256,21792,46212,474734]

theorem envBound45203 : H12AffineFastState.Bounded env45203 := by
  intro p hp
  have h : env45203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45151_45203 : H12AffineEnvironment.transform 21 272513 env45151 = env45203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45151 == env45203) = true)

theorem identity45203 : scanCanonicalize (H12AffineFastState.compose env45203 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound45203 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,58517,180272,16,95496,8328,65,171416,5392,45524,10400,61704,144492,256,21792,46212,120543]

theorem envBound45204 : H12AffineFastState.Bounded env45204 := by
  intro p hp
  have h : env45204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45203_45204 : H12AffineEnvironment.transform 17 190641 env45203 = env45204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env45203 == env45204) = true)

def env45205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58397,180272,16,95496,8192,65,171280,5392,45404,10280,61704,144492,256,21792,46092,120407]

theorem envBound45205 : H12AffineFastState.Bounded env45205 := by
  intro p hp
  have h : env45205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45204_45205 : H12AffineEnvironment.transform 6 8 env45204 = env45205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45204 == env45205) = true)

theorem identity45205 : scanCanonicalize (H12AffineFastState.compose env45205 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound45205 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,35188,1024,32769,58397,41341,16,95496,8192,65,64605,5392,45404,10280,61704,21793,256,21792,46092,120407]

theorem envBound45206 : H12AffineFastState.Bounded env45206 := by
  intro p hp
  have h : env45206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45205_45206 : H12AffineEnvironment.transform 16 24909 env45205 = env45206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env45205 == env45206) = true)

theorem identity45206 : scanCanonicalize (H12AffineFastState.compose env45206 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound45206 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,35188,1024,32769,58397,41341,16,32771,8192,65,64605,5392,45404,10280,61704,21793,256,21792,46092,9052]

theorem envBound45207 : H12AffineFastState.Bounded env45207 := by
  intro p hp
  have h : env45207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45206_45207 : H12AffineEnvironment.transform 15 62731 env45206 = env45207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env45206 == env45207) = true)

theorem identity45207 : scanCanonicalize (H12AffineFastState.compose env45207 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound45207 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env45208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,343,24909,32040,1024,29789,4161,21793,16,29791,8192,65,2049,5392,17664,10280,1364,21793,256,21792,16464,9052]

theorem envBound45208 : H12AffineFastState.Bounded env45208 := by
  intro p hp
  have h : env45208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45207_45208 : H12AffineEnvironment.transform 14 29788 env45207 = env45208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env45207 == env45208) = true)

theorem identity45208 : scanCanonicalize (H12AffineFastState.compose env45208 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45208 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16400,23669,1024,21760,4161,21793,16,21762,349,65,2049,5392,17664,2421,1364,21793,256,21792,16464,513]

theorem envBound45209 : H12AffineFastState.Bounded env45209 := by
  intro p hp
  have h : env45209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45208_45209 : H12AffineEnvironment.transform 12 349 env45208 = env45209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45208 == env45209) = true)

theorem identity45209 : scanCanonicalize (H12AffineFastState.compose env45209 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45209 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,80,343,5441,2340,1024,81,4161,112,16,83,349,65,2049,5392,4177,2421,1364,112,256,113,5377,513]

theorem envBound45210 : H12AffineFastState.Bounded env45210 := by
  intro p hp
  have h : env45210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45209_45210 : H12AffineEnvironment.transform 13 5457 env45209 = env45210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45209 == env45210) = true)

theorem identity45210 : scanCanonicalize (H12AffineFastState.compose env45210 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound45210 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,309,4096,349,5457,80,343,5441,17,1024,81,4161,112,16,83,349,65,308,5392,4177,64,1364,112,256,113,5377,513]

theorem envBound45211 : H12AffineFastState.Bounded env45211 := by
  intro p hp
  have h : env45211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45210_45211 : H12AffineEnvironment.transform 10 309 env45210 = env45211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env45210 == env45211) = true)

theorem identity45211 : scanCanonicalize (H12AffineFastState.compose env45211 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45211 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45212 : List Nat := [2,4,8,16,32,64,8,256,512,4,309,4096,349,4437,80,343,4421,17,4,81,4161,112,16,83,349,65,308,4372,4177,64,336,112,256,113,4357,513]

theorem envBound45212 : H12AffineFastState.Bounded env45212 := by
  intro p hp
  have h : env45212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45211_45212 : H12AffineEnvironment.transform 9 4 env45211 = env45212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45211 == env45212) = true)

theorem identity45212 : scanCanonicalize (H12AffineFastState.compose env45212 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound45212 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env45213 : List Nat := [2,4,8,16,32,64,8,256,512,4,309,293,349,112,80,343,96,17,4,81,356,112,16,83,349,65,308,49,372,64,336,112,256,113,32,513]

theorem envBound45213 : H12AffineFastState.Bounded env45213 := by
  intro p hp
  have h : env45213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45212_45213 : H12AffineEnvironment.transform 11 293 env45212 = env45213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env45212 == env45213) = true)

theorem identity45213 : scanCanonicalize (H12AffineFastState.compose env45213 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound45213 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45214 : List Nat := [2,4,8,16,32,64,8,256,309,4,309,293,349,112,80,343,96,17,4,81,356,112,16,83,349,65,308,49,372,64,336,112,256,113,32,308]

theorem envBound45214 : H12AffineFastState.Bounded env45214 := by
  intro p hp
  have h : env45214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45213_45214 : H12AffineEnvironment.transform 8 309 env45213 = env45214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env45213 == env45214) = true)

theorem identity45214 : scanCanonicalize (H12AffineFastState.compose env45214 (packedSelected [3,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound45214 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env45215 : List Nat := [2,4,8,16,32,48,8,256,309,4,309,293,301,0,32,295,16,17,4,33,276,0,16,35,301,49,308,49,260,48,288,0,256,1,32,308]

theorem envBound45215 : H12AffineFastState.Bounded env45215 := by
  intro p hp
  have h : env45215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45214_45215 : H12AffineEnvironment.transform 5 48 env45214 = env45215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env45214 == env45215) = true)

theorem identity45215 : scanCanonicalize (H12AffineFastState.compose env45215 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45215 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45216 : List Nat := [2,4,8,1,32,33,8,256,292,4,292,293,301,0,32,295,1,0,4,33,261,0,1,35,301,32,293,32,260,33,288,0,256,1,32,293]

theorem envBound45216 : H12AffineFastState.Bounded env45216 := by
  intro p hp
  have h : env45216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45215_45216 : H12AffineEnvironment.transform 3 1 env45215 = env45216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45215 == env45216) = true)

theorem identity45216 : scanCanonicalize (H12AffineFastState.compose env45216 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45216 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45217 : List Nat := [2,4,8,1,32,33,8,37,1,4,1,0,8,0,32,2,1,0,4,33,32,0,1,35,8,32,0,32,33,33,5,0,37,1,32,0]

theorem envBound45217 : H12AffineFastState.Bounded env45217 := by
  intro p hp
  have h : env45217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45216_45217 : H12AffineEnvironment.transform 7 37 env45216 = env45217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45216 == env45217) = true)

def env45218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58396,180272,16,95496,8193,65,171281,5392,45405,10281,61704,144492,256,21792,46093,120406]

theorem envBound45218 : H12AffineFastState.Bounded env45218 := by
  intro p hp
  have h : env45218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45204_45218 : H12AffineEnvironment.transform 6 9 env45204 = env45218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45204 == env45218) = true)

theorem identity45218 : scanCanonicalize (H12AffineFastState.compose env45218 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound45218 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58396,32,16,95496,8193,65,23809,5392,45405,10281,61704,62588,256,21792,46093,120406]

theorem envBound45219 : H12AffineFastState.Bounded env45219 := by
  intro p hp
  have h : env45219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45218_45219 : H12AffineEnvironment.transform 16 49168 env45218 = env45219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45218 == env45219) = true)

theorem identity45219 : scanCanonicalize (H12AffineFastState.compose env45219 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound45219 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env45220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,16449,10280,1024,80,25677,32,16,95496,8193,65,23809,5392,12556,10281,29017,29741,256,21792,13404,87559]

theorem envBound45220 : H12AffineFastState.Bounded env45220 := by
  intro p hp
  have h : env45220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45219_45220 : H12AffineEnvironment.transform 14 81 env45219 = env45220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env45219 == env45220) = true)

theorem identity45220 : scanCanonicalize (H12AffineFastState.compose env45220 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound45220 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,30042,16449,10280,1024,80,25677,32,16,82,8193,65,23809,5392,12556,10281,29017,29741,256,21792,13404,9053]

theorem envBound45221 : H12AffineFastState.Bounded env45221 := by
  intro p hp
  have h : env45221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45220_45221 : H12AffineEnvironment.transform 15 30042 env45220 = env45221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env45220 == env45221) = true)

theorem identity45221 : scanCanonicalize (H12AffineFastState.compose env45221 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45221 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45222 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,29963,16400,10280,1024,1,25628,32,16,3,8193,16,23809,5392,12556,10281,28936,29741,256,21792,13325,8972]

theorem envBound45222 : H12AffineFastState.Bounded env45222 := by
  intro p hp
  have h : env45222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45221_45222 : H12AffineEnvironment.transform 5 17 env45221 = env45222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45221 == env45222) = true)

theorem identity45222 : scanCanonicalize (H12AffineFastState.compose env45222 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45222 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45223 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,10281,0,7458,10297,10280,1024,1,3125,32,16,3,8193,16,13608,5392,12556,10281,6433,7172,256,15625,13325,8972]

theorem envBound45223 : H12AffineFastState.Bounded env45223 := by
  intro p hp
  have h : env45223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45222_45223 : H12AffineEnvironment.transform 13 10281 env45222 = env45223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10281 env45222 == env45223) = true)

theorem identity45223 : scanCanonicalize (H12AffineFastState.compose env45223 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound45223 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45224 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,8192,10281,0,263,10297,10280,1024,1,3125,32,16,3,8193,16,10509,2357,11561,10281,1284,33,256,8492,10280,8972]

theorem envBound45224 : H12AffineFastState.Bounded env45224 := by
  intro p hp
  have h : env45224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45223_45224 : H12AffineEnvironment.transform 11 3109 env45223 = env45224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env45223 == env45224) = true)

theorem identity45224 : scanCanonicalize (H12AffineFastState.compose env45224 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3132) := by decide +kernel

theorem selectedBound45224 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45225 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,3132,1045,0,263,1029,1044,1024,1,3125,32,16,3,3133,16,1329,2357,277,1045,1284,33,256,3344,1044,3888]

theorem envBound45225 : H12AffineFastState.Bounded env45225 := by
  intro p hp
  have h : env45225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45224_45225 : H12AffineEnvironment.transform 12 3132 env45224 = env45225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3132 env45224 == env45225) = true)

theorem identity45225 : scanCanonicalize (H12AffineFastState.compose env45225 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound45225 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45226 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,1312,1337,1045,0,263,1029,1044,1024,1,1328,32,16,3,1336,16,1329,48,277,1045,1284,33,256,1045,1044,1589]

theorem envBound45226 : H12AffineFastState.Bounded env45226 := by
  intro p hp
  have h : env45226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45225_45226 : H12AffineEnvironment.transform 10 261 env45225 = env45226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env45225 == env45226) = true)

theorem identity45226 : scanCanonicalize (H12AffineFastState.compose env45226 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45226 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env45227 : List Nat := [2,4,8,16,32,17,9,256,512,52,261,276,269,33,0,263,49,32,52,1,260,32,16,3,268,16,261,48,277,33,304,33,256,33,32,513]

theorem envBound45227 : H12AffineFastState.Bounded env45227 := by
  intro p hp
  have h : env45227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45226_45227 : H12AffineEnvironment.transform 9 52 env45226 = env45227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45226 == env45227) = true)

theorem identity45227 : scanCanonicalize (H12AffineFastState.compose env45227 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound45227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45228 : List Nat := [2,4,8,16,32,17,9,52,512,52,49,32,57,33,0,51,49,32,52,1,48,32,16,3,56,16,49,48,33,33,4,33,52,33,32,513]

theorem envBound45228 : H12AffineFastState.Bounded env45228 := by
  intro p hp
  have h : env45228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45227_45228 : H12AffineEnvironment.transform 7 52 env45227 = env45228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env45227 == env45228) = true)

theorem identity45228 : scanCanonicalize (H12AffineFastState.compose env45228 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound45228 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45229 : List Nat := [2,4,8,16,32,17,9,52,33,52,49,32,57,33,0,51,49,32,52,1,48,32,16,3,56,16,49,48,33,33,4,33,52,33,32,32]

theorem envBound45229 : H12AffineFastState.Bounded env45229 := by
  intro p hp
  have h : env45229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45228_45229 : H12AffineEnvironment.transform 8 33 env45228 = env45229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env45228 == env45229) = true)

def env45230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound45230 : H12AffineFastState.Bounded env45230 := by
  intro p hp
  have h : env45230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45009_45230 : H12AffineEnvironment.transform 18 1025 env45009 = env45230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45009 == env45230) = true)

theorem identity45230 : scanCanonicalize (H12AffineFastState.compose env45230 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10874020) := by decide +kernel

theorem selectedBound45230 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10874020,8328,65,6433956,8677416,10507601,8830976,2386100,12880229,257,272392,313773,2445154]

theorem envBound45231 : H12AffineFastState.Bounded env45231 := by
  intro p hp
  have h : env45231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45230_45231 : H12AffineEnvironment.transform 23 10874020 env45230 = env45231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10874020 env45230 == env45231) = true)

def env45232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433956,8393984,10507601,8568104,2102684,12645453,257,21792,46213,2175562]

theorem envBound45232 : H12AffineFastState.Bounded env45232 := by
  intro p hp
  have h : env45232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45231_45232 : H12AffineEnvironment.transform 17 32040 env45231 = env45232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env45231 == env45232) = true)

def env45233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101328,98780,8328,65,6433956,2098512,17665,2272632,2102684,6349853,257,21792,46213,2175562]

theorem envBound45233 : H12AffineFastState.Bounded env45233 := by
  intro p hp
  have h : env45233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45232_45233 : H12AffineEnvironment.transform 22 2101328 env45232 = env45233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env45232 == env45233) = true)

def env45234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,16,98780,8328,65,4340964,5392,17665,179512,1500,4256861,257,21792,46213,74250]

theorem envBound45234 : H12AffineFastState.Bounded env45234 := by
  intro p hp
  have h : env45234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45233_45234 : H12AffineEnvironment.transform 20 4160 env45233 = env45234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45233 == env45234) = true)

theorem identity45234 : scanCanonicalize (H12AffineFastState.compose env45234 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound45234 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98679,16,98780,8328,65,245139,5392,17665,179512,1500,95530,257,21792,46213,74250]

theorem envBound45235 : H12AffineFastState.Bounded env45235 := by
  intro p hp
  have h : env45235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45234_45235 : H12AffineEnvironment.transform 21 98679 env45234 = env45235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env45234 == env45235) = true)

def env45236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98679,16,98644,8192,65,245019,5392,17665,179512,1364,95530,257,21792,46093,74250]

theorem envBound45236 : H12AffineFastState.Bounded env45236 := by
  intro p hp
  have h : env45236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45235_45236 : H12AffineEnvironment.transform 6 8 env45235 = env45236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45235 == env45236) = true)

theorem identity45236 : scanCanonicalize (H12AffineFastState.compose env45236 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,98679,16,98644,8192,65,245019,5392,4097,179512,1364,73770,257,32,46093,74250]

theorem envBound45237 : H12AffineFastState.Bounded env45237 := by
  intro p hp
  have h : env45237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45236_45237 : H12AffineEnvironment.transform 13 5376 env45236 = env45237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45236 == env45237) = true)

theorem identity45237 : scanCanonicalize (H12AffineFastState.compose env45237 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound45237 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5441,10280,1025,32769,4160,98679,16,98644,8192,65,108634,5392,4097,43129,1364,73770,257,32,46093,74250]

theorem envBound45238 : H12AffineFastState.Bounded env45238 := by
  intro p hp
  have h : env45238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45237_45238 : H12AffineEnvironment.transform 16 5441 env45237 = env45238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env45237 == env45238) = true)

theorem identity45238 : scanCanonicalize (H12AffineFastState.compose env45238 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound45238 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env45239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33030,5441,10280,1025,32769,4160,113,16,82,8192,65,10588,5392,4097,43129,1364,41260,257,32,46093,41740]

theorem envBound45239 : H12AffineFastState.Bounded env45239 := by
  intro p hp
  have h : env45239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45238_45239 : H12AffineEnvironment.transform 15 33030 env45238 = env45239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env45238 == env45239) = true)

theorem identity45239 : scanCanonicalize (H12AffineFastState.compose env45239 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45239 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,33030,5441,2340,1025,32769,4160,113,16,82,268,65,2128,5392,4097,35189,1364,32800,257,32,38145,33280]

theorem envBound45240 : H12AffineFastState.Bounded env45240 := by
  intro p hp
  have h : env45240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45239_45240 : H12AffineEnvironment.transform 12 268 env45239 = env45240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45239 == env45240) = true)

theorem identity45240 : scanCanonicalize (H12AffineFastState.compose env45240 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45240 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45241 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,32768,33030,5392,2340,1025,32769,4113,32,16,3,268,16,2049,5392,4097,35108,1285,32800,257,32,38145,33280]

theorem envBound45241 : H12AffineFastState.Bounded env45241 := by
  intro p hp
  have h : env45241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45240_45241 : H12AffineEnvironment.transform 5 17 env45240 = env45241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45240 == env45241) = true)

theorem identity45241 : scanCanonicalize (H12AffineFastState.compose env45241 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1322) := by decide +kernel

theorem selectedBound45241 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env45242 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1322,268,42,32768,33030,58,2340,1025,32769,1339,32,16,3,268,16,2049,58,1323,35108,1285,32800,257,32,32811,33280]

theorem envBound45242 : H12AffineFastState.Bounded env45242 := by
  intro p hp
  have h : env45242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45241_45242 : H12AffineEnvironment.transform 11 1322 env45241 = env45242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1322 env45241 == env45242) = true)

theorem identity45242 : scanCanonicalize (H12AffineFastState.compose env45242 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45242 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45243 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,287,268,42,32768,33030,58,2340,52,32769,270,32,16,3,268,16,2049,58,286,35108,304,32800,257,32,32811,33280]

theorem envBound45243 : H12AffineFastState.Bounded env45243 := by
  intro p hp
  have h : env45243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45242_45243 : H12AffineEnvironment.transform 9 53 env45242 = env45243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45242 == env45243) = true)

theorem identity45243 : scanCanonicalize (H12AffineFastState.compose env45243 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 2097) := by decide +kernel

theorem selectedBound45243 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env45244 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,287,268,42,2097,2359,58,2340,52,2096,270,32,16,3,268,16,2049,58,286,277,304,2065,257,32,2074,2609]

theorem envBound45244 : H12AffineFastState.Bounded env45244 := by
  intro p hp
  have h : env45244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45243_45244 : H12AffineEnvironment.transform 14 2097 env45243 = env45244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2097 env45243 == env45244) = true)

theorem identity45244 : scanCanonicalize (H12AffineFastState.compose env45244 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound45244 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env45245 : List Nat := [2,4,8,16,32,17,8,256,512,53,276,287,268,42,293,35,58,48,52,292,270,32,16,3,268,16,277,58,286,277,304,261,257,32,270,805]

theorem envBound45245 : H12AffineFastState.Bounded env45245 := by
  intro p hp
  have h : env45245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45244_45245 : H12AffineEnvironment.transform 10 276 env45244 = env45245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env45244 == env45245) = true)

theorem identity45245 : scanCanonicalize (H12AffineFastState.compose env45245 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 58) := by decide +kernel

theorem selectedBound45245 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env45246 : List Nat := [2,4,8,16,32,17,8,58,512,53,46,37,54,42,31,35,58,48,52,30,52,32,16,3,54,16,47,58,36,47,10,63,59,32,52,543]

theorem envBound45246 : H12AffineFastState.Bounded env45246 := by
  intro p hp
  have h : env45246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45245_45246 : H12AffineEnvironment.transform 7 58 env45245 = env45246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 58 env45245 == env45246) = true)

theorem identity45246 : scanCanonicalize (H12AffineFastState.compose env45246 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound45246 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env45247 : List Nat := [2,4,8,16,30,17,8,4,512,11,16,27,8,20,31,29,4,14,10,30,10,30,16,3,8,16,17,4,26,17,10,1,5,30,10,543]

theorem envBound45247 : H12AffineFastState.Bounded env45247 := by
  intro p hp
  have h : env45247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45246_45247 : H12AffineEnvironment.transform 4 30 env45246 = env45247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env45246 == env45247) = true)

theorem identity45247 : scanCanonicalize (H12AffineFastState.compose env45247 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound45247 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45248 : List Nat := [2,4,8,14,0,15,8,4,512,11,14,5,8,10,1,3,4,14,10,0,10,0,14,3,8,14,15,4,4,15,10,1,5,0,10,513]

theorem envBound45248 : H12AffineFastState.Bounded env45248 := by
  intro p hp
  have h : env45248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45247_45248 : H12AffineEnvironment.transform 3 14 env45247 = env45248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env45247 == env45248) = true)

theorem identity45248 : scanCanonicalize (H12AffineFastState.compose env45248 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound45248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45249 : List Nat := [2,4,8,14,0,15,8,4,5,11,14,5,8,10,1,3,4,14,10,0,10,0,14,3,8,14,15,4,4,15,10,1,5,0,10,4]

theorem envBound45249 : H12AffineFastState.Bounded env45249 := by
  intro p hp
  have h : env45249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45248_45249 : H12AffineEnvironment.transform 8 5 env45248 = env45249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env45248 == env45249) = true)

theorem identity45249 : scanCanonicalize (H12AffineFastState.compose env45249 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45250 : List Nat := [2,3,8,9,0,8,8,3,2,11,9,2,8,10,1,3,3,9,10,0,10,0,9,3,8,9,8,3,3,8,10,1,2,0,10,3]

theorem envBound45250 : H12AffineFastState.Bounded env45250 := by
  intro p hp
  have h : env45250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45249_45250 : H12AffineEnvironment.transform 1 3 env45249 = env45250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45249 == env45250) = true)

def env45251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98679,16,98645,8193,65,245018,5392,17665,179512,1365,95530,257,21792,46092,74250]

theorem envBound45251 : H12AffineFastState.Bounded env45251 := by
  intro p hp
  have h : env45251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45235_45251 : H12AffineEnvironment.transform 6 9 env45235 = env45251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45235 == env45251) = true)

theorem identity45251 : scanCanonicalize (H12AffineFastState.compose env45251 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45251 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4160,95530,16,95496,8193,65,215367,5392,17665,149861,1365,95530,257,21792,16465,74250]

theorem envBound45252 : H12AffineFastState.Bounded env45252 := by
  intro p hp
  have h : env45252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45251_45252 : H12AffineEnvironment.transform 14 29789 env45251 = env45252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45251 == env45252) = true)

theorem identity45252 : scanCanonicalize (H12AffineFastState.compose env45252 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound45252 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env45253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8235,131072,32040,1025,29788,4160,21761,16,21795,8193,65,158060,5392,17665,149861,1365,21761,257,21792,16465,545]

theorem envBound45253 : H12AffineFastState.Bounded env45253 := by
  intro p hp
  have h : env45253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45252_45253 : H12AffineEnvironment.transform 15 8235 env45252 = env45253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env45252 == env45253) = true)

theorem identity45253 : scanCanonicalize (H12AffineFastState.compose env45253 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16433) := by decide +kernel

theorem selectedBound45253 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env45254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8235,16433,32040,1025,29788,4160,21761,16,21795,8193,65,10589,5392,17665,2388,1365,21761,257,21792,16465,545]

theorem envBound45254 : H12AffineFastState.Bounded env45254 := by
  intro p hp
  have h : env45254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45253_45254 : H12AffineEnvironment.transform 16 16433 env45253 = env45254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16433 env45253 == env45254) = true)

theorem identity45254 : scanCanonicalize (H12AffineFastState.compose env45254 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45254 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45255 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16401,32008,1025,29788,4160,21761,16,21763,8193,65,10589,5392,17665,2388,1365,21761,257,21760,16465,513]

theorem envBound45255 : H12AffineFastState.Bounded env45255 := by
  intro p hp
  have h : env45255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45254_45255 : H12AffineEnvironment.transform 4 0 env45254 = env45255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45254 == env45255) = true)

theorem identity45255 : scanCanonicalize (H12AffineFastState.compose env45255 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45255 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45256 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,8192,16384,29004,8203,16401,30745,272,29005,4160,20496,16,20498,8193,65,10589,4097,16400,2388,68,20496,257,20497,16465,513]

theorem envBound45256 : H12AffineFastState.Bounded env45256 := by
  intro p hp
  have h : env45256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45255_45256 : H12AffineEnvironment.transform 9 273 env45255 = env45256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45255 == env45256) = true)

theorem identity45256 : scanCanonicalize (H12AffineFastState.compose env45256 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound45256 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45257 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,8192,4113,8541,8203,4096,10248,272,8540,4160,1,16,3,8193,65,10589,4097,4097,2388,68,1,257,0,4160,513]

theorem envBound45257 : H12AffineFastState.Bounded env45257 := by
  intro p hp
  have h : env45257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45256_45257 : H12AffineEnvironment.transform 13 4113 env45256 = env45257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env45256 == env45257) = true)

theorem identity45257 : scanCanonicalize (H12AffineFastState.compose env45257 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4185) := by decide +kernel

theorem selectedBound45257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45258 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,4185,4113,4356,4178,4096,6225,272,4357,4160,1,16,3,4184,65,6404,4097,4097,2388,68,1,257,0,4160,513]

theorem envBound45258 : H12AffineFastState.Bounded env45258 := by
  intro p hp
  have h : env45258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45257_45258 : H12AffineEnvironment.transform 12 4185 env45257 = env45258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4185 env45257 == env45258) = true)

theorem identity45258 : scanCanonicalize (H12AffineFastState.compose env45258 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 340) := by decide +kernel

theorem selectedBound45258 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45259 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,340,269,325,80,262,340,2309,272,81,276,1,16,3,268,65,2128,341,341,2388,68,1,257,0,276,513]

theorem envBound45259 : H12AffineFastState.Bounded env45259 := by
  intro p hp
  have h : env45259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45258_45259 : H12AffineEnvironment.transform 11 340 env45258 = env45259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 340 env45258 == env45259) = true)

theorem identity45259 : scanCanonicalize (H12AffineFastState.compose env45259 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound45259 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45260 : List Nat := [2,4,8,16,0,64,9,256,325,273,2048,340,269,325,80,262,340,2309,272,81,276,1,16,3,268,65,2128,341,341,2388,68,1,257,0,276,324]

theorem envBound45260 : H12AffineFastState.Bounded env45260 := by
  intro p hp
  have h : env45260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45259_45260 : H12AffineEnvironment.transform 8 325 env45259 = env45260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env45259 == env45260) = true)

theorem identity45260 : scanCanonicalize (H12AffineFastState.compose env45260 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound45260 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45261 : List Nat := [2,4,8,16,0,64,9,256,325,273,64,340,269,325,80,262,340,325,272,81,276,1,16,3,268,65,16,341,341,276,68,1,257,0,276,324]

theorem envBound45261 : H12AffineFastState.Bounded env45261 := by
  intro p hp
  have h : env45261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45260_45261 : H12AffineEnvironment.transform 10 64 env45260 = env45261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env45260 == env45261) = true)

theorem identity45261 : scanCanonicalize (H12AffineFastState.compose env45261 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45261 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env45262 : List Nat := [2,4,8,16,0,17,9,256,276,273,17,261,269,276,1,262,261,276,272,0,276,1,16,3,268,16,16,260,260,276,21,1,257,0,276,277]

theorem envBound45262 : H12AffineFastState.Bounded env45262 := by
  intro p hp
  have h : env45262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45261_45262 : H12AffineEnvironment.transform 5 17 env45261 = env45262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45261 == env45262) = true)

def env45263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98780,8328,65,4340965,5393,17665,179513,1501,4256860,257,21792,46213,74251]

theorem envBound45263 : H12AffineFastState.Bounded env45263 := by
  intro p hp
  have h : env45263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45233_45263 : H12AffineEnvironment.transform 20 4161 env45233 = env45263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45233 == env45263) = true)

theorem identity45263 : scanCanonicalize (H12AffineFastState.compose env45263 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound45263 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32040,1025,32769,4161,4194304,17,21762,8328,65,4340965,5393,17665,179513,1501,4256860,257,21792,46213,63189]

theorem envBound45264 : H12AffineFastState.Bounded env45264 := by
  intro p hp
  have h : env45264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45263_45264 : H12AffineEnvironment.transform 15 54494 env45263 = env45264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env45263 == env45264) = true)

def env45265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,4161,4194304,17,21762,8192,65,4340845,5393,17665,179513,1365,4256860,257,21792,46093,63069]

theorem envBound45265 : H12AffineFastState.Bounded env45265 := by
  intro p hp
  have h : env45265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45264_45265 : H12AffineEnvironment.transform 6 8 env45264 = env45265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45264 == env45265) = true)

theorem identity45265 : scanCanonicalize (H12AffineFastState.compose env45265 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound45265 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env45266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4161,4194304,17,21762,8192,65,4340845,5393,17665,149861,1365,4194304,257,21792,16465,513]

theorem envBound45266 : H12AffineFastState.Bounded env45266 := by
  intro p hp
  have h : env45266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45265_45266 : H12AffineEnvironment.transform 14 29788 env45265 = env45266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env45265 == env45266) = true)

theorem identity45266 : scanCanonicalize (H12AffineFastState.compose env45266 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound45266 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env45267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4161,147504,17,21762,8192,65,31837,5393,17665,149861,1365,147504,257,21792,16465,513]

theorem envBound45267 : H12AffineFastState.Bounded env45267 := by
  intro p hp
  have h : env45267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45266_45267 : H12AffineEnvironment.transform 21 147504 env45266 = env45267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env45266 == env45267) = true)

theorem identity45267 : scanCanonicalize (H12AffineFastState.compose env45267 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45267 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10281,1025,8540,4161,136497,17,3,8192,65,10588,5393,4096,138340,1365,136497,257,33,5456,513]

theorem envBound45268 : H12AffineFastState.Bounded env45268 := by
  intro p hp
  have h : env45268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45267_45268 : H12AffineEnvironment.transform 13 5377 env45267 = env45268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45267 == env45268) = true)

theorem identity45268 : scanCanonicalize (H12AffineFastState.compose env45268 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound45268 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,13388,10281,1025,8540,4161,8573,17,3,8192,65,10588,5393,4096,10280,1365,8573,257,33,5456,513]

theorem envBound45269 : H12AffineFastState.Bounded env45269 := by
  intro p hp
  have h : env45269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45268_45269 : H12AffineEnvironment.transform 16 13388 env45268 = env45269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env45268 == env45269) = true)

theorem identity45269 : scanCanonicalize (H12AffineFastState.compose env45269 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45269 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45270 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8541,8202,12637,10281,272,8540,4161,8573,17,3,8192,65,10588,4096,4096,10280,68,8573,257,33,4161,513]

theorem envBound45270 : H12AffineFastState.Bounded env45270 := by
  intro p hp
  have h : env45270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45269_45270 : H12AffineEnvironment.transform 9 273 env45269 = env45270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45269 == env45270) = true)

theorem identity45270 : scanCanonicalize (H12AffineFastState.compose env45270 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound45270 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45271 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,8192,4112,8541,8202,12637,8313,272,8540,4161,8573,17,3,8192,65,8460,4096,4096,8312,68,8573,257,33,4161,513]

theorem envBound45271 : H12AffineFastState.Bounded env45271 := by
  intro p hp
  have h : env45271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45270_45271 : H12AffineEnvironment.transform 10 80 env45270 = env45271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env45270 == env45271) = true)

theorem identity45271 : scanCanonicalize (H12AffineFastState.compose env45271 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45271 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45272 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,348,4112,1,342,4097,293,272,0,4161,33,17,3,348,65,80,4096,4096,292,68,33,257,33,4161,513]

theorem envBound45272 : H12AffineFastState.Bounded env45272 := by
  intro p hp
  have h : env45272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45271_45272 : H12AffineEnvironment.transform 12 348 env45271 = env45272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45271 == env45272) = true)

theorem identity45272 : scanCanonicalize (H12AffineFastState.compose env45272 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound45272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45273 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,308,348,292,1,342,309,293,272,0,373,33,17,3,348,65,80,308,308,292,68,33,257,33,373,513]

theorem envBound45273 : H12AffineFastState.Bounded env45273 := by
  intro p hp
  have h : env45273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45272_45273 : H12AffineEnvironment.transform 11 308 env45272 = env45273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env45272 == env45273) = true)

theorem identity45273 : scanCanonicalize (H12AffineFastState.compose env45273 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 382) := by decide +kernel

theorem selectedBound45273 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45274 : List Nat := [2,4,8,16,32,64,8,256,382,273,80,308,348,292,1,342,309,293,272,0,373,33,17,3,348,65,80,308,308,292,68,33,257,33,373,383]

theorem envBound45274 : H12AffineFastState.Bounded env45274 := by
  intro p hp
  have h : env45274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45273_45274 : H12AffineEnvironment.transform 8 382 env45273 = env45274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 382 env45273 == env45274) = true)

theorem identity45274 : scanCanonicalize (H12AffineFastState.compose env45274 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound45274 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45275 : List Nat := [2,4,8,16,32,48,8,256,270,273,32,308,300,292,1,294,309,293,272,0,261,33,17,3,300,49,32,308,308,292,52,33,257,33,261,271]

theorem envBound45275 : H12AffineFastState.Bounded env45275 := by
  intro p hp
  have h : env45275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45274_45275 : H12AffineEnvironment.transform 5 48 env45274 = env45275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env45274 == env45275) = true)

theorem identity45275 : scanCanonicalize (H12AffineFastState.compose env45275 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45275 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45276 : List Nat := [2,4,8,16,32,48,8,36,42,53,32,16,8,0,1,2,17,1,52,0,33,33,17,3,8,49,32,16,16,0,52,33,37,33,33,43]

theorem envBound45276 : H12AffineFastState.Bounded env45276 := by
  intro p hp
  have h : env45276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45275_45276 : H12AffineEnvironment.transform 7 36 env45275 = env45276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45275 == env45276) = true)

theorem identity45276 : scanCanonicalize (H12AffineFastState.compose env45276 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45276 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45277 : List Nat := [2,4,8,16,0,16,8,4,10,21,0,16,8,0,1,2,17,1,20,0,1,1,17,3,8,17,0,16,16,0,20,1,5,1,1,11]

theorem envBound45277 : H12AffineFastState.Bounded env45277 := by
  intro p hp
  have h : env45277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45276_45277 : H12AffineEnvironment.transform 4 0 env45276 = env45277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45276 == env45277) = true)

theorem identity45277 : scanCanonicalize (H12AffineFastState.compose env45277 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound45277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45278 : List Nat := [2,4,6,16,0,16,6,4,4,21,0,16,6,0,1,2,17,1,20,0,1,1,17,3,6,17,0,16,16,0,20,1,5,1,1,5]

theorem envBound45278 : H12AffineFastState.Bounded env45278 := by
  intro p hp
  have h : env45278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45277_45278 : H12AffineEnvironment.transform 2 6 env45277 = env45278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env45277 == env45278) = true)

theorem identity45278 : scanCanonicalize (H12AffineFastState.compose env45278 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound45278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45279 : List Nat := [2,4,6,3,0,3,6,4,4,6,0,3,6,0,1,2,2,1,7,0,1,1,2,3,6,2,0,3,3,0,7,1,5,1,1,5]

theorem envBound45279 : H12AffineFastState.Bounded env45279 := by
  intro p hp
  have h : env45279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45278_45279 : H12AffineEnvironment.transform 3 3 env45278 = env45279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env45278 == env45279) = true)

def env45280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,4161,4194304,17,21762,8193,65,4340844,5393,17665,179513,1364,4256860,257,21792,46092,63068]

theorem envBound45280 : H12AffineFastState.Bounded env45280 := by
  intro p hp
  have h : env45280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45264_45280 : H12AffineEnvironment.transform 6 9 env45264 = env45280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45264 == env45280) = true)

theorem identity45280 : scanCanonicalize (H12AffineFastState.compose env45280 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,131072,32040,1025,8541,4161,4194304,17,21762,8193,65,4340844,5393,17665,138341,1364,4216064,257,21792,5456,22272]

theorem envBound45281 : H12AffineFastState.Bounded env45281 := by
  intro p hp
  have h : env45281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45280_45281 : H12AffineEnvironment.transform 14 8540 env45280 = env45281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45280 == env45281) = true)

theorem identity45281 : scanCanonicalize (H12AffineFastState.compose env45281 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound45281 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,16400,32040,1025,8541,4161,4194304,17,21762,8193,65,4226172,5393,17665,23669,1364,4216064,257,21792,5456,22272]

theorem envBound45282 : H12AffineFastState.Bounded env45282 := by
  intro p hp
  have h : env45282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45281_45282 : H12AffineEnvironment.transform 16 16400 env45281 = env45282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45281 == env45282) = true)

theorem identity45282 : scanCanonicalize (H12AffineFastState.compose env45282 (packedSelected [1,2,6,8,10,14,15,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound45282 : packedSelected [1,2,6,8,10,14,15,18,20] rootPS < 2^1333 := by decide +kernel

def env45283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,16400,32040,1025,8541,4161,21588,17,21762,8193,65,10280,5393,17665,23669,1364,340,257,21792,5456,22272]

theorem envBound45283 : H12AffineFastState.Bounded env45283 := by
  intro p hp
  have h : env45283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45282_45283 : H12AffineEnvironment.transform 21 21588 env45282 = env45283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env45282 == env45283) = true)

theorem identity45283 : scanCanonicalize (H12AffineFastState.compose env45283 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound45283 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,343,13388,2420,1025,8541,4161,8200,17,8542,8193,65,10280,5393,12637,10281,1364,340,257,8572,5456,9052]

theorem envBound45284 : H12AffineFastState.Bounded env45284 := by
  intro p hp
  have h : env45284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45283_45284 : H12AffineEnvironment.transform 13 13404 env45283 = env45284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env45283 == env45284) = true)

theorem identity45284 : scanCanonicalize (H12AffineFastState.compose env45284 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45284 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env45285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5392,2420,1025,1,4161,340,17,2,349,65,2420,5393,4097,2421,1364,340,257,32,5456,512]

theorem envBound45285 : H12AffineFastState.Bounded env45285 := by
  intro p hp
  have h : env45285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45284_45285 : H12AffineEnvironment.transform 12 348 env45284 = env45285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45284 == env45285) = true)

theorem identity45285 : scanCanonicalize (H12AffineFastState.compose env45285 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound45285 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45286 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,301,5376,0,294,5392,2309,1025,1,4144,293,17,2,300,48,2309,5393,4097,2308,1317,293,257,32,5409,512]

theorem envBound45286 : H12AffineFastState.Bounded env45286 := by
  intro p hp
  have h : env45286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45285_45286 : H12AffineEnvironment.transform 5 49 env45285 = env45286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env45285 == env45286) = true)

theorem identity45286 : scanCanonicalize (H12AffineFastState.compose env45286 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound45286 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env45287 : List Nat := [2,4,8,16,32,49,9,256,512,305,2048,4096,301,4145,0,294,4129,2309,304,1,4144,293,17,2,300,48,2309,4128,4097,2308,20,293,257,32,4112,512]

theorem envBound45287 : H12AffineFastState.Bounded env45287 := by
  intro p hp
  have h : env45287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45286_45287 : H12AffineEnvironment.transform 9 305 env45286 = env45287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env45286 == env45287) = true)

theorem identity45287 : scanCanonicalize (H12AffineFastState.compose env45287 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound45287 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env45288 : List Nat := [2,4,8,16,32,49,9,256,512,305,512,4096,301,4145,0,294,4129,773,304,1,4144,293,17,2,300,48,773,4128,4097,772,20,293,257,32,4112,512]

theorem envBound45288 : H12AffineFastState.Bounded env45288 := by
  intro p hp
  have h : env45288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45287_45288 : H12AffineEnvironment.transform 10 512 env45287 = env45288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env45287 == env45288) = true)

theorem identity45288 : scanCanonicalize (H12AffineFastState.compose env45288 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45288 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env45289 : List Nat := [2,4,8,16,32,49,9,37,512,20,512,4096,8,4145,0,3,4129,544,21,1,4144,0,17,2,9,48,544,4128,4097,545,20,0,36,32,4112,512]

theorem envBound45289 : H12AffineFastState.Bounded env45289 := by
  intro p hp
  have h : env45289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45288_45289 : H12AffineEnvironment.transform 7 37 env45288 = env45289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45288 == env45289) = true)

theorem identity45289 : scanCanonicalize (H12AffineFastState.compose env45289 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound45289 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env45290 : List Nat := [2,4,8,16,32,49,9,37,33,20,33,4096,8,4145,0,3,4129,1,21,1,4144,0,17,2,9,48,1,4128,4097,0,20,0,36,32,4112,33]

theorem envBound45290 : H12AffineFastState.Bounded env45290 := by
  intro p hp
  have h : env45290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45289_45290 : H12AffineEnvironment.transform 8 33 env45289 = env45290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env45289 == env45290) = true)

def env45291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101329,98781,8328,65,6433956,2098513,17664,2272633,2102684,6349852,257,21792,46213,2175562]

theorem envBound45291 : H12AffineFastState.Bounded env45291 := by
  intro p hp
  have h : env45291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45232_45291 : H12AffineEnvironment.transform 22 2101329 env45232 = env45291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env45232 == env45291) = true)

def env45292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98781,8328,65,4340964,5393,17664,179513,1500,4256860,257,21792,46213,74250]

theorem envBound45292 : H12AffineFastState.Bounded env45292 := by
  intro p hp
  have h : env45292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45291_45292 : H12AffineEnvironment.transform 20 4160 env45291 = env45292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45291 == env45292) = true)

theorem identity45292 : scanCanonicalize (H12AffineFastState.compose env45292 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45292 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41430,8328,65,4340964,5393,17664,179513,1500,4256860,257,21792,46213,513]

theorem envBound45293 : H12AffineFastState.Bounded env45293 := by
  intro p hp
  have h : env45293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45292_45293 : H12AffineEnvironment.transform 15 8203 env45292 = env45293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45292 == env45293) = true)

theorem identity45293 : scanCanonicalize (H12AffineFastState.compose env45293 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41380) := by decide +kernel

theorem selectedBound45293 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41380,17,41430,8328,65,171328,5393,17664,179513,1500,22008,257,21792,46213,513]

theorem envBound45294 : H12AffineFastState.Bounded env45294 := by
  intro p hp
  have h : env45294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45293_45294 : H12AffineEnvironment.transform 21 41380 env45293 = env45294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41380 env45293 == env45294) = true)

def env45295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41260,17,41310,8192,65,171328,5393,17664,179513,1364,21872,257,21792,46093,513]

theorem envBound45295 : H12AffineFastState.Bounded env45295 := by
  intro p hp
  have h : env45295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45294_45295 : H12AffineEnvironment.transform 6 8 env45294 = env45295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45294 == env45295) = true)

theorem identity45295 : scanCanonicalize (H12AffineFastState.compose env45295 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound45295 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env45296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21872,17,21762,8192,65,157980,5393,17664,149861,1364,21872,257,21792,16465,513]

theorem envBound45296 : H12AffineFastState.Bounded env45296 := by
  intro p hp
  have h : env45296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45295_45296 : H12AffineEnvironment.transform 14 29788 env45295 = env45296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env45295 == env45296) = true)

theorem identity45296 : scanCanonicalize (H12AffineFastState.compose env45296 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45296 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env45297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8203,131072,10361,1025,8460,4160,33,17,83,8192,65,146509,5393,4177,138292,1364,33,257,113,5376,513]

theorem envBound45297 : H12AffineFastState.Bounded env45297 := by
  intro p hp
  have h : env45297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45296_45297 : H12AffineEnvironment.transform 13 5457 env45296 = env45297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45296 == env45297) = true)

theorem identity45297 : scanCanonicalize (H12AffineFastState.compose env45297 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound45297 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env45298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8203,13389,10361,1025,8460,4160,33,17,83,8192,65,2048,5393,4177,10361,1364,33,257,113,5376,513]

theorem envBound45298 : H12AffineFastState.Bounded env45298 := by
  intro p hp
  have h : env45298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45297_45298 : H12AffineEnvironment.transform 16 13389 env45297 = env45298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env45297 == env45298) = true)

theorem identity45298 : scanCanonicalize (H12AffineFastState.compose env45298 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45298 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45299 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,13340,10280,1025,8460,4113,33,17,2,8192,16,2048,5393,4096,10280,1285,33,257,32,5376,513]

theorem envBound45299 : H12AffineFastState.Bounded env45299 := by
  intro p hp
  have h : env45299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45298_45299 : H12AffineEnvironment.transform 5 17 env45298 = env45299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45298 == env45299) = true)

theorem identity45299 : scanCanonicalize (H12AffineFastState.compose env45299 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45299 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45300 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5393,2341,1025,1,4113,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound45300 : H12AffineFastState.Bounded env45300 := by
  intro p hp
  have h : env45300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45299_45300 : H12AffineEnvironment.transform 12 269 env45299 = env45300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45299 == env45300) = true)

theorem identity45300 : scanCanonicalize (H12AffineFastState.compose env45300 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45301 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5172,2048,1025,1,4113,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound45301 : H12AffineFastState.Bounded env45301 := by
  intro p hp
  have h : env45301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45300_45301 : H12AffineEnvironment.transform 7 37 env45300 = env45301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45300 == env45301) = true)

def env45302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41261,17,41311,8193,65,171328,5393,17664,179513,1365,21873,257,21792,46092,513]

theorem envBound45302 : H12AffineFastState.Bounded env45302 := by
  intro p hp
  have h : env45302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45294_45302 : H12AffineEnvironment.transform 6 9 env45294 = env45302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45294 == env45302) = true)

theorem identity45302 : scanCanonicalize (H12AffineFastState.compose env45302 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45302 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32040,1025,8541,4160,113,17,3,8193,65,146460,5393,17664,138341,1365,21873,257,21792,5456,513]

theorem envBound45303 : H12AffineFastState.Bounded env45303 := by
  intro p hp
  have h : env45303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45302_45303 : H12AffineEnvironment.transform 14 8540 env45302 = env45303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45302 == env45303) = true)

theorem identity45303 : scanCanonicalize (H12AffineFastState.compose env45303 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound45303 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,32040,1025,8541,4160,113,17,3,8193,65,31757,5393,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound45304 : H12AffineFastState.Bounded env45304 := by
  intro p hp
  have h : env45304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45303_45304 : H12AffineEnvironment.transform 16 16401 env45303 = env45304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45303 == env45304) = true)

theorem identity45304 : scanCanonicalize (H12AffineFastState.compose env45304 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound45304 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,115,16401,23888,1025,293,4160,113,17,3,121,65,23669,5393,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound45305 : H12AffineFastState.Bounded env45305 := by
  intro p hp
  have h : env45305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45304_45305 : H12AffineEnvironment.transform 12 120 env45304 = env45305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env45304 == env45305) = true)

theorem identity45305 : scanCanonicalize (H12AffineFastState.compose env45305 (packedSelected [2,5,6,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45305 : packedSelected [2,5,6,8,11,18] rootPS < 2^1333 := by decide +kernel

def env45306 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,1,115,16401,23669,1025,0,4160,113,17,3,121,65,23669,5172,17445,23668,1136,21588,36,21509,5237,513]

theorem envBound45306 : H12AffineFastState.Bounded env45306 := by
  intro p hp
  have h : env45306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45305_45306 : H12AffineEnvironment.transform 7 37 env45305 = env45306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45305 == env45306) = true)

theorem identity45306 : scanCanonicalize (H12AffineFastState.compose env45306 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45306 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45307 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,16384,1,115,16401,22592,52,0,4160,113,17,3,121,65,22592,4097,16400,22593,69,20577,36,20528,4160,513]

theorem envBound45307 : H12AffineFastState.Bounded env45307 := by
  intro p hp
  have h : env45307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45306_45307 : H12AffineEnvironment.transform 9 53 env45306 = env45307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45306 == env45307) = true)

theorem identity45307 : scanCanonicalize (H12AffineFastState.compose env45307 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound45307 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45308 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4160,1,115,4177,2048,52,0,4160,113,17,3,121,65,2048,4097,4176,2049,69,33,36,112,4160,513]

theorem envBound45308 : H12AffineFastState.Bounded env45308 := by
  intro p hp
  have h : env45308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45307_45308 : H12AffineEnvironment.transform 13 4160 env45307 = env45308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env45307 == env45308) = true)

theorem identity45308 : scanCanonicalize (H12AffineFastState.compose env45308 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound45308 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45309 : List Nat := [2,4,8,16,32,49,9,37,512,53,2048,4096,9,4145,1,2,4128,2048,52,0,4145,0,17,3,8,48,2048,4097,4129,2049,52,33,36,1,4145,513]

theorem envBound45309 : H12AffineFastState.Bounded env45309 := by
  intro p hp
  have h : env45309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45308_45309 : H12AffineEnvironment.transform 5 49 env45308 = env45309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env45308 == env45309) = true)

theorem identity45309 : scanCanonicalize (H12AffineFastState.compose env45309 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound45309 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45310 : List Nat := [2,4,8,16,32,49,9,37,512,53,2048,48,9,1,1,2,16,2048,52,0,1,0,17,3,8,48,2048,49,17,2049,52,33,36,1,1,513]

theorem envBound45310 : H12AffineFastState.Bounded env45310 := by
  intro p hp
  have h : env45310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45309_45310 : H12AffineEnvironment.transform 11 48 env45309 = env45310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45309 == env45310) = true)

theorem identity45310 : scanCanonicalize (H12AffineFastState.compose env45310 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound45310 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45311 : List Nat := [2,4,8,16,32,49,9,37,512,53,545,48,9,1,1,2,16,545,52,0,1,0,17,3,8,48,545,49,17,544,52,33,36,1,1,513]

theorem envBound45311 : H12AffineFastState.Bounded env45311 := by
  intro p hp
  have h : env45311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45310_45311 : H12AffineEnvironment.transform 10 545 env45310 = env45311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env45310 == env45311) = true)

theorem identity45311 : scanCanonicalize (H12AffineFastState.compose env45311 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45311 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45312 : List Nat := [2,4,8,16,16,1,9,21,512,5,529,0,9,1,1,2,16,529,4,0,1,0,17,3,8,0,529,1,17,528,4,17,20,1,1,513]

theorem envBound45312 : H12AffineFastState.Bounded env45312 := by
  intro p hp
  have h : env45312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45311_45312 : H12AffineEnvironment.transform 4 16 env45311 = env45312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45311 == env45312) = true)

theorem identity45312 : scanCanonicalize (H12AffineFastState.compose env45312 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45313 : List Nat := [2,4,8,16,16,1,9,21,1,5,16,0,9,1,1,2,16,16,4,0,1,0,17,3,8,0,16,1,17,17,4,17,20,1,1,0]

theorem envBound45313 : H12AffineFastState.Bounded env45313 := by
  intro p hp
  have h : env45313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45312_45313 : H12AffineEnvironment.transform 8 1 env45312 = env45313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45312 == env45313) = true)

theorem identity45313 : scanCanonicalize (H12AffineFastState.compose env45313 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45313 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45314 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,0,9,1,1,2,0,0,4,0,1,0,1,3,8,0,0,1,1,1,4,1,4,1,1,0]

theorem envBound45314 : H12AffineFastState.Bounded env45314 := by
  intro p hp
  have h : env45314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45313_45314 : H12AffineEnvironment.transform 3 0 env45313 = env45314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45313 == env45314) = true)

def env45315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,16,98781,8328,65,4340965,5392,17664,179512,1501,4256861,257,21792,46213,74251]

theorem envBound45315 : H12AffineFastState.Bounded env45315 := by
  intro p hp
  have h : env45315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45291_45315 : H12AffineEnvironment.transform 20 4161 env45291 = env45315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45291 == env45315) = true)

theorem identity45315 : scanCanonicalize (H12AffineFastState.compose env45315 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound45315 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95650,16,98781,8328,65,215367,5392,17664,179512,1501,98815,257,21792,46213,74251]

theorem envBound45316 : H12AffineFastState.Bounded env45316 := by
  intro p hp
  have h : env45316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45315_45316 : H12AffineEnvironment.transform 21 95650 env45315 = env45316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env45315 == env45316) = true)

def env45317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95530,16,98645,8192,65,215367,5392,17664,179512,1365,98679,257,21792,46093,74251]

theorem envBound45317 : H12AffineFastState.Bounded env45317 := by
  intro p hp
  have h : env45317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45316_45317 : H12AffineEnvironment.transform 6 8 env45316 = env45317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45316 == env45317) = true)

theorem identity45317 : scanCanonicalize (H12AffineFastState.compose env45317 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45317 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4161,73770,16,98645,8192,65,203847,5392,4096,179512,1365,98679,257,32,46093,74251]

theorem envBound45318 : H12AffineFastState.Bounded env45318 := by
  intro p hp
  have h : env45318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45317_45318 : H12AffineEnvironment.transform 13 5376 env45317 = env45318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45317 == env45318) = true)

theorem identity45318 : scanCanonicalize (H12AffineFastState.compose env45318 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45318 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env45319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1025,32769,4161,33,16,41310,8192,65,146508,5392,4096,179512,1365,41340,257,32,46093,512]

theorem envBound45319 : H12AffineFastState.Bounded env45319 := by
  intro p hp
  have h : env45319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45318_45319 : H12AffineEnvironment.transform 15 8203 env45318 = env45319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45318 == env45319) = true)

theorem identity45319 : scanCanonicalize (H12AffineFastState.compose env45319 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound45319 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1124,8203,131072,10280,1025,1125,4161,33,16,9530,8192,65,146508,5392,4096,145756,1365,9496,257,32,12393,512]

theorem envBound45320 : H12AffineFastState.Bounded env45320 := by
  intro p hp
  have h : env45320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45319_45320 : H12AffineEnvironment.transform 14 1124 env45319 = env45320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env45319 == env45320) = true)

theorem identity45320 : scanCanonicalize (H12AffineFastState.compose env45320 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound45320 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env45321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,8192,373,1124,8203,131072,10280,1025,1125,1076,33,16,9530,8192,65,141369,357,1141,142633,1365,9496,257,32,9244,512]

theorem envBound45321 : H12AffineFastState.Bounded env45321 := by
  intro p hp
  have h : env45321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45320_45321 : H12AffineEnvironment.transform 11 1141 env45320 = env45321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env45320 == env45321) = true)

theorem identity45321 : scanCanonicalize (H12AffineFastState.compose env45321 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45321 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env45322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1100,373,1124,1095,131072,3172,1025,1125,1076,33,16,374,1100,65,134261,357,1141,133477,1365,340,257,32,80,512]

theorem envBound45322 : H12AffineFastState.Bounded env45322 := by
  intro p hp
  have h : env45322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45321_45322 : H12AffineEnvironment.transform 12 1100 env45321 = env45322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45321 == env45322) = true)

theorem identity45322 : scanCanonicalize (H12AffineFastState.compose env45322 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound45322 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1141,1100,373,1124,1095,131072,1077,1025,1125,1076,33,16,374,1100,65,132132,357,1141,131380,1365,340,257,32,80,512]

theorem envBound45323 : H12AffineFastState.Bounded env45323 := by
  intro p hp
  have h : env45323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45322_45323 : H12AffineEnvironment.transform 10 81 env45322 = env45323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env45322 == env45323) = true)

theorem identity45323 : scanCanonicalize (H12AffineFastState.compose env45323 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45323 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45324 : List Nat := [2,4,8,16,32,64,8,4,512,1024,81,1141,1100,113,1124,1095,131072,1077,1025,1125,1076,33,16,114,1100,65,132132,97,1141,131120,1105,80,5,32,80,512]

theorem envBound45324 : H12AffineFastState.Bounded env45324 := by
  intro p hp
  have h : env45324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45323_45324 : H12AffineEnvironment.transform 7 4 env45323 = env45324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45323 == env45324) = true)

theorem identity45324 : scanCanonicalize (H12AffineFastState.compose env45324 (packedSelected [1,2,3,4,5,7,8,11] rootPS)) = affineNative (2^(16+1) ^^^ 96) := by decide +kernel

theorem selectedBound45324 : packedSelected [1,2,3,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45325 : List Nat := [2,4,8,16,32,64,8,4,512,1024,81,1141,1100,113,1124,1095,96,1077,1025,1125,1076,33,16,114,1100,65,1092,97,1141,80,1105,80,5,32,80,512]

theorem envBound45325 : H12AffineFastState.Bounded env45325 := by
  intro p hp
  have h : env45325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45324_45325 : H12AffineEnvironment.transform 16 96 env45324 = env45325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 96 env45324 == env45325) = true)

theorem identity45325 : scanCanonicalize (H12AffineFastState.compose env45325 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound45325 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45326 : List Nat := [2,4,8,16,32,64,8,4,512,623,81,538,547,113,523,552,96,602,622,522,603,33,16,114,547,65,555,97,538,80,574,80,5,32,80,512]

theorem envBound45326 : H12AffineFastState.Bounded env45326 := by
  intro p hp
  have h : env45326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45325_45326 : H12AffineEnvironment.transform 9 623 env45325 = env45326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env45325 == env45326) = true)

theorem identity45326 : scanCanonicalize (H12AffineFastState.compose env45326 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound45326 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45327 : List Nat := [2,4,8,16,9,64,8,4,512,582,81,538,522,88,523,513,73,602,583,522,603,8,16,91,522,65,514,72,538,80,535,80,5,9,80,512]

theorem envBound45327 : H12AffineFastState.Bounded env45327 := by
  intro p hp
  have h : env45327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45326_45327 : H12AffineEnvironment.transform 4 9 env45326 = env45327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env45326 == env45327) = true)

theorem identity45327 : scanCanonicalize (H12AffineFastState.compose env45327 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound45327 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env45328 : List Nat := [2,4,8,16,9,64,8,4,3,69,81,25,9,88,8,2,73,89,68,9,88,8,16,91,9,65,1,72,25,80,20,80,5,9,80,3]

theorem envBound45328 : H12AffineFastState.Bounded env45328 := by
  intro p hp
  have h : env45328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45327_45328 : H12AffineEnvironment.transform 8 3 env45327 = env45328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env45327 == env45328) = true)

theorem identity45328 : scanCanonicalize (H12AffineFastState.compose env45328 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound45328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45329 : List Nat := [2,4,1,16,0,64,1,4,3,69,81,16,0,81,1,2,64,80,68,0,81,1,16,82,0,65,1,65,16,80,20,80,5,0,80,3]

theorem envBound45329 : H12AffineFastState.Bounded env45329 := by
  intro p hp
  have h : env45329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45328_45329 : H12AffineEnvironment.transform 2 1 env45328 = env45329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env45328 == env45329) = true)

theorem identity45329 : scanCanonicalize (H12AffineFastState.compose env45329 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45329 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45330 : List Nat := [2,4,1,16,0,16,1,4,3,21,1,16,0,1,1,2,16,0,20,0,1,1,16,2,0,17,1,17,16,0,20,0,5,0,0,3]

theorem envBound45330 : H12AffineFastState.Bounded env45330 := by
  intro p hp
  have h : env45330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45329_45330 : H12AffineEnvironment.transform 5 16 env45329 = env45330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45329 == env45330) = true)

theorem identity45330 : scanCanonicalize (H12AffineFastState.compose env45330 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45331 : List Nat := [2,4,1,7,0,7,1,4,3,2,1,7,0,1,1,2,7,0,3,0,1,1,7,2,0,6,1,6,7,0,3,0,5,0,0,3]

theorem envBound45331 : H12AffineFastState.Bounded env45331 := by
  intro p hp
  have h : env45331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45330_45331 : H12AffineEnvironment.transform 3 7 env45330 = env45331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45330 == env45331) = true)

def env45332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95531,16,98644,8193,65,215367,5392,17664,179512,1364,98678,257,21792,46092,74251]

theorem envBound45332 : H12AffineFastState.Bounded env45332 := by
  intro p hp
  have h : env45332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45316_45332 : H12AffineEnvironment.transform 6 9 env45316 = env45332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45316 == env45332) = true)

theorem identity45332 : scanCanonicalize (H12AffineFastState.compose env45332 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45332 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4161,95531,16,95497,8193,65,215367,5392,17664,149861,1364,95531,257,21792,16465,74251]

theorem envBound45333 : H12AffineFastState.Bounded env45333 := by
  intro p hp
  have h : env45333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45332_45333 : H12AffineEnvironment.transform 14 29789 env45332 = env45333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45332 == env45333) = true)

theorem identity45333 : scanCanonicalize (H12AffineFastState.compose env45333 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound45333 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env45334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,79130,32040,1025,29788,4161,95531,16,95497,8193,65,31837,5392,17664,97407,1364,95531,257,21792,16465,74251]

theorem envBound45334 : H12AffineFastState.Bounded env45334 := by
  intro p hp
  have h : env45334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45333_45334 : H12AffineEnvironment.transform 16 79130 env45333 = env45334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env45333 == env45334) = true)

theorem identity45334 : scanCanonicalize (H12AffineFastState.compose env45334 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound45334 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,16400,32040,1025,29788,4161,33,16,3,8193,65,31837,5392,17664,2421,1364,33,257,21792,16465,22273]

theorem envBound45335 : H12AffineFastState.Bounded env45335 := by
  intro p hp
  have h : env45335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45334_45335 : H12AffineEnvironment.transform 15 29962 env45334 = env45335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env45334 == env45335) = true)

theorem identity45335 : scanCanonicalize (H12AffineFastState.compose env45335 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound45335 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env45336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,16384,19557,19762,16400,17680,1025,19556,4161,33,16,3,6201,65,17509,5392,17664,2421,1364,33,257,21792,16465,22273]

theorem envBound45336 : H12AffineFastState.Bounded env45336 := by
  intro p hp
  have h : env45336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45335_45336 : H12AffineEnvironment.transform 12 6200 env45335 = env45336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env45335 == env45336) = true)

theorem identity45336 : scanCanonicalize (H12AffineFastState.compose env45336 (packedSelected [0,2,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound45336 : packedSelected [0,2,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env45337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,3101,16384,19557,19762,16400,17680,1025,19556,1124,33,16,3,3100,65,17509,309,17664,2421,1364,33,257,16645,16465,17188]

end H12CloudChart0