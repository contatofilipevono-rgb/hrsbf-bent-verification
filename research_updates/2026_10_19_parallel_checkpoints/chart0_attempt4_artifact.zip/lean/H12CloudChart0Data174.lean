import H12CloudChart0Data173

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound44076 : packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env44077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,2557,1025,21540,4589,397,445,87545,120,64,23725,5309,17664,2265,1136,169,257,21793,16464,66391]

theorem envBound44077 : H12AffineFastState.Bounded env44077 := by
  intro p hp
  have h : env44077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44076_44077 : H12AffineEnvironment.transform 20 4589 env44076 = env44077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4589 env44076 == env44077) = true)

theorem identity44077 : scanCanonicalize (H12AffineFastState.compose env44077 (packedSelected [2,3,4,6,7,10,11,14,16,18,19,20,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound44077 : packedSelected [2,3,4,6,7,10,11,14,16,18,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env44078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5592,509,65536,5309,2557,1025,508,4589,397,445,65569,120,64,2421,5309,4312,2265,1136,169,257,249,5512,66391]

theorem envBound44078 : H12AffineFastState.Bounded env44078 := by
  intro p hp
  have h : env44078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44077_44078 : H12AffineEnvironment.transform 13 5592 env44077 = env44078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env44077 == env44078) = true)

theorem identity44078 : scanCanonicalize (H12AffineFastState.compose env44078 (packedSelected [1,4,8,9,12,14,15,16,17,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44078 : packedSelected [1,4,8,9,12,14,15,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env44079 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5513,428,65536,5309,2476,1025,429,4540,397,445,65569,41,17,2340,5309,4233,2184,1057,169,257,168,5512,66310]

theorem envBound44079 : H12AffineFastState.Bounded env44079 := by
  intro p hp
  have h : env44079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44078_44079 : H12AffineEnvironment.transform 5 17 env44078 = env44079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44078 == env44079) = true)

theorem identity44079 : scanCanonicalize (H12AffineFastState.compose env44079 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound44079 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44080 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4112,428,65536,4388,2476,408,429,4540,397,445,65569,41,17,2340,4388,4233,2184,440,169,257,168,4113,66310]

theorem envBound44080 : H12AffineFastState.Bounded env44080 := by
  intro p hp
  have h : env44080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44079_44080 : H12AffineEnvironment.transform 9 409 env44079 = env44080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env44079 == env44080) = true)

theorem identity44080 : scanCanonicalize (H12AffineFastState.compose env44080 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound44080 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44081 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4112,428,171,4388,2476,408,429,4540,397,445,138,41,17,2340,4388,4233,2184,440,169,257,168,4113,941]

theorem envBound44081 : H12AffineFastState.Bounded env44081 := by
  intro p hp
  have h : env44081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44080_44081 : H12AffineEnvironment.transform 15 171 env44080 = env44081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env44080 == env44081) = true)

theorem identity44081 : scanCanonicalize (H12AffineFastState.compose env44081 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44081 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44082 : List Nat := [2,4,8,16,32,17,128,36,512,189,2048,4096,161,4112,136,171,4096,2184,188,137,4248,169,153,138,41,17,2048,4096,4233,2184,156,169,37,168,4113,649]

theorem envBound44082 : H12AffineFastState.Bounded env44082 := by
  intro p hp
  have h : env44082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44081_44082 : H12AffineEnvironment.transform 7 36 env44081 = env44082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44081 == env44082) = true)

theorem identity44082 : scanCanonicalize (H12AffineFastState.compose env44082 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44082 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44083 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4112,1,34,4096,2049,53,0,4113,32,16,3,41,17,2048,4096,4096,2049,21,32,37,33,4113,512]

theorem envBound44083 : H12AffineFastState.Bounded env44083 := by
  intro p hp
  have h : env44083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44082_44083 : H12AffineEnvironment.transform 6 9 env44082 = env44083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44082 == env44083) = true)

theorem identity44083 : scanCanonicalize (H12AffineFastState.compose env44083 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2622) := by decide +kernel

theorem selectedBound44083 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44084 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2622,40,2606,1,34,2622,2049,53,0,2607,32,16,3,41,17,2048,2622,2622,2049,21,32,37,33,2607,512]

theorem envBound44084 : H12AffineFastState.Bounded env44084 := by
  intro p hp
  have h : env44084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44083_44084 : H12AffineEnvironment.transform 11 2622 env44083 = env44084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2622 env44083 == env44084) = true)

theorem identity44084 : scanCanonicalize (H12AffineFastState.compose env44084 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44085 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2591,9,2575,1,3,2591,2049,20,0,2574,1,16,3,8,17,2048,2591,2591,2049,21,1,4,0,2574,512]

theorem envBound44085 : H12AffineFastState.Bounded env44085 := by
  intro p hp
  have h : env44085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44084_44085 : H12AffineEnvironment.transform 4 1 env44084 = env44085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44084 == env44085) = true)

theorem identity44085 : scanCanonicalize (H12AffineFastState.compose env44085 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound44085 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44086 : List Nat := [2,4,8,16,1,17,9,5,15,21,2048,2064,9,2048,1,3,2064,2049,20,0,2049,1,16,3,8,17,2048,2064,2064,2049,21,1,4,0,2049,15]

theorem envBound44086 : H12AffineFastState.Bounded env44086 := by
  intro p hp
  have h : env44086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44085_44086 : H12AffineEnvironment.transform 8 15 env44085 = env44086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env44085 == env44086) = true)

def env44087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,65536,5308,262144,1025,21541,2097152,264305,2101328,87544,121,64,2116928,2098512,17664,2363593,2102685,2365624,257,21793,16464,2167483]

theorem envBound44087 : H12AffineFastState.Bounded env44087 := by
  intro p hp
  have h : env44087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44074_44087 : H12AffineEnvironment.transform 12 241 env44074 = env44087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env44074 == env44087) = true)

theorem identity44087 : scanCanonicalize (H12AffineFastState.compose env44087 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound44087 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env44088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,65536,5308,2420,1025,21541,2097152,261,2101328,87544,121,64,2116928,2098512,17664,2103741,2102685,2101708,257,21793,16464,2167483]

theorem envBound44088 : H12AffineFastState.Bounded env44088 := by
  intro p hp
  have h : env44088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44087_44088 : H12AffineEnvironment.transform 17 2420 env44087 = env44088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env44087 == env44088) = true)

theorem identity44088 : scanCanonicalize (H12AffineFastState.compose env44088 (packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound44088 : packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS < 2^1333 := by decide +kernel

def env44089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,251,5308,2420,1025,21541,2097152,261,2101328,21763,121,64,2116928,2098512,17664,2103741,2102685,2101708,257,21793,16464,2101824]

theorem envBound44089 : H12AffineFastState.Bounded env44089 := by
  intro p hp
  have h : env44089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44088_44089 : H12AffineEnvironment.transform 15 251 env44088 = env44089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env44088 == env44089) = true)

theorem identity44089 : scanCanonicalize (H12AffineFastState.compose env44089 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 4588) := by decide +kernel

theorem selectedBound44089 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,251,5308,2420,1025,21541,4588,261,444,21763,121,64,23724,5308,17664,2129,1137,32,257,21793,16464,940]

theorem envBound44090 : H12AffineFastState.Bounded env44090 := by
  intro p hp
  have h : env44090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44089_44090 : H12AffineEnvironment.transform 20 4588 env44089 = env44090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4588 env44089 == env44090) = true)

theorem identity44090 : scanCanonicalize (H12AffineFastState.compose env44090 (packedSelected [0,3,5,6,7,10,12,14,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound44090 : packedSelected [0,3,5,6,7,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env44091 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,16384,21540,34,5221,2420,1025,21541,4405,261,357,21763,121,64,23669,5221,17664,2129,1137,32,257,21793,16464,885]

theorem envBound44091 : H12AffineFastState.Bounded env44091 := by
  intro p hp
  have h : env44091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44090_44091 : H12AffineEnvironment.transform 6 89 env44090 = env44091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env44090 == env44091) = true)

theorem identity44091 : scanCanonicalize (H12AffineFastState.compose env44091 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound44091 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env44092 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,5156,0,34,5221,2420,1025,1,4405,261,357,295,121,64,2129,5221,4388,2129,1137,32,257,261,5236,885]

theorem envBound44092 : H12AffineFastState.Bounded env44092 := by
  intro p hp
  have h : env44092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44091_44092 : H12AffineEnvironment.transform 13 5156 env44091 = env44092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env44091 == env44092) = true)

theorem identity44092 : scanCanonicalize (H12AffineFastState.compose env44092 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound44092 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env44093 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2064,40,3124,0,34,3189,2420,1025,1,2341,261,357,295,121,64,2129,3189,2356,2129,1137,32,257,261,3172,885]

theorem envBound44093 : H12AffineFastState.Bounded env44093 := by
  intro p hp
  have h : env44093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44092_44093 : H12AffineEnvironment.transform 11 2064 env44092 = env44093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env44092 == env44093) = true)

theorem identity44093 : scanCanonicalize (H12AffineFastState.compose env44093 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44093 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env44094 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,2064,40,3124,0,34,3189,2128,1025,1,2049,33,65,3,121,64,2129,3189,2064,2129,1137,32,37,33,3172,593]

theorem envBound44094 : H12AffineFastState.Bounded env44094 := by
  intro p hp
  have h : env44094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44093_44094 : H12AffineEnvironment.transform 7 36 env44093 = env44094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44093 == env44094) = true)

theorem identity44094 : scanCanonicalize (H12AffineFastState.compose env44094 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44094 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env44095 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2064,40,3124,0,34,3109,2048,1025,1,2049,33,17,3,41,16,2049,3109,2064,2049,1057,32,37,33,3124,513]

theorem envBound44095 : H12AffineFastState.Bounded env44095 := by
  intro p hp
  have h : env44095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44094_44095 : H12AffineEnvironment.transform 5 16 env44094 = env44095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44094 == env44095) = true)

theorem identity44095 : scanCanonicalize (H12AffineFastState.compose env44095 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound44095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44096 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1061,1077,40,17,0,34,0,1061,1025,1,1060,33,17,3,41,16,1060,0,1077,1060,1057,32,37,33,17,513]

theorem envBound44096 : H12AffineFastState.Bounded env44096 := by
  intro p hp
  have h : env44096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44095_44096 : H12AffineEnvironment.transform 10 1061 env44095 = env44096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env44095 == env44096) = true)

theorem identity44096 : scanCanonicalize (H12AffineFastState.compose env44096 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound44096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44097 : List Nat := [2,4,8,16,32,16,9,36,512,565,528,512,40,17,0,34,0,528,564,1,529,33,17,3,41,16,529,0,512,529,532,32,37,33,17,513]

theorem envBound44097 : H12AffineFastState.Bounded env44097 := by
  intro p hp
  have h : env44097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44096_44097 : H12AffineEnvironment.transform 9 565 env44096 = env44097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env44096 == env44097) = true)

theorem identity44097 : scanCanonicalize (H12AffineFastState.compose env44097 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44097 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44098 : List Nat := [2,4,8,16,32,16,9,36,16,37,0,16,40,17,0,34,0,0,36,1,1,33,17,3,41,16,1,0,16,1,4,32,37,33,17,17]

theorem envBound44098 : H12AffineFastState.Bounded env44098 := by
  intro p hp
  have h : env44098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44097_44098 : H12AffineEnvironment.transform 8 16 env44097 = env44098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44097 == env44098) = true)

theorem identity44098 : scanCanonicalize (H12AffineFastState.compose env44098 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44098 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44099 : List Nat := [2,4,8,0,32,0,9,36,0,37,0,0,40,1,0,34,0,0,36,1,1,33,1,3,41,0,1,0,0,1,4,32,37,33,1,1]

theorem envBound44099 : H12AffineFastState.Bounded env44099 := by
  intro p hp
  have h : env44099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44098_44099 : H12AffineEnvironment.transform 3 0 env44098 = env44099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44098 == env44099) = true)

theorem identity44099 : scanCanonicalize (H12AffineFastState.compose env44099 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44100 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,0,9,1,0,3,0,0,5,1,1,0,1,3,8,0,1,0,0,1,4,1,4,0,1,1]

theorem envBound44100 : H12AffineFastState.Bounded env44100 := by
  intro p hp
  have h : env44100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44099_44100 : H12AffineEnvironment.transform 4 1 env44099 = env44100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44099 == env44100) = true)

def env44101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144660,2098512,17664,2363593,2102685,2411677,257,21793,46213,2175562]

theorem envBound44101 : H12AffineFastState.Bounded env44101 := by
  intro p hp
  have h : env44101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44072_44101 : H12AffineEnvironment.transform 21 272513 env44072 = env44101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44072 == env44101) = true)

theorem identity44101 : scanCanonicalize (H12AffineFastState.compose env44101 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound44101 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58516,272513,62660,98780,8328,64,23808,57796,17664,324701,61705,272393,257,21793,46213,120542]

theorem envBound44102 : H12AffineFastState.Bounded env44102 := by
  intro p hp
  have h : env44102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44101_44102 : H12AffineEnvironment.transform 20 58516 env44101 = env44102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env44101 == env44102) = true)

def env44103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10280,1025,32769,58516,169,62660,98780,8328,64,23808,57796,17664,56437,61705,33,257,21793,46213,120542]

theorem envBound44103 : H12AffineFastState.Bounded env44103 := by
  intro p hp
  have h : env44103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44102_44103 : H12AffineEnvironment.transform 17 10280 env44102 = env44103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44102 == env44103) = true)

theorem identity44103 : scanCanonicalize (H12AffineFastState.compose env44103 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound44103 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env44104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,49304,10280,1025,32769,58516,169,62660,29910,8328,64,23808,57796,17664,56437,61705,33,257,21793,46213,9172]

theorem envBound44104 : H12AffineFastState.Bounded env44104 := by
  intro p hp
  have h : env44104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44103_44104 : H12AffineEnvironment.transform 15 62730 env44103 = env44104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env44103 == env44104) = true)

theorem identity44104 : scanCanonicalize (H12AffineFastState.compose env44104 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44104 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env44105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,33111,46277,10280,1025,32769,37065,169,32921,139,8328,64,10589,38297,12637,43048,34132,33,257,8572,46213,9172]

theorem envBound44105 : H12AffineFastState.Bounded env44105 := by
  intro p hp
  have h : env44105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44104_44105 : H12AffineEnvironment.transform 13 13405 env44104 = env44105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44104 == env44105) = true)

theorem identity44105 : scanCanonicalize (H12AffineFastState.compose env44105 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44105 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env44106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,0,343,13509,10280,1025,1,4297,169,153,139,8328,64,10589,5529,12637,10280,1364,33,257,8572,13445,9172]

theorem envBound44106 : H12AffineFastState.Bounded env44106 := by
  intro p hp
  have h : env44106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44105_44106 : H12AffineEnvironment.transform 14 0 env44105 = env44106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44105 == env44106) = true)

theorem identity44106 : scanCanonicalize (H12AffineFastState.compose env44106 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound44106 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env44107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,0,343,5392,2557,1025,1,4297,169,153,139,349,64,2184,5529,4232,2557,1364,33,257,169,5456,513]

theorem envBound44107 : H12AffineFastState.Bounded env44107 := by
  intro p hp
  have h : env44107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44106_44107 : H12AffineEnvironment.transform 12 469 env44106 = env44107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env44106 == env44107) = true)

theorem identity44107 : scanCanonicalize (H12AffineFastState.compose env44107 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44108 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,0,263,5392,2477,1025,1,4249,169,153,139,269,16,2184,5529,4232,2477,1284,33,257,169,5376,513]

theorem envBound44108 : H12AffineFastState.Bounded env44108 := by
  intro p hp
  have h : env44108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44107_44108 : H12AffineEnvironment.transform 5 16 env44107 = env44108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44107 == env44108) = true)

theorem identity44108 : scanCanonicalize (H12AffineFastState.compose env44108 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound44108 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44109 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1819,4096,389,5512,0,263,5392,1718,1025,1,4249,169,153,139,269,16,1939,5529,4232,1718,1284,33,257,169,5376,513]

theorem envBound44109 : H12AffineFastState.Bounded env44109 := by
  intro p hp
  have h : env44109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44108_44109 : H12AffineEnvironment.transform 10 1819 env44108 = env44109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env44108 == env44109) = true)

theorem identity44109 : scanCanonicalize (H12AffineFastState.compose env44109 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44109 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44110 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1819,4096,268,5377,0,263,5392,1599,1025,1,4112,32,16,2,269,16,1818,5392,4097,1599,1284,33,257,32,5376,513]

theorem envBound44110 : H12AffineFastState.Bounded env44110 := by
  intro p hp
  have h : env44110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44109_44110 : H12AffineEnvironment.transform 6 9 env44109 = env44110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44109 == env44110) = true)

theorem identity44110 : scanCanonicalize (H12AffineFastState.compose env44110 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound44110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44111 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1819,1060,268,293,0,263,308,1599,1025,1,1076,32,16,2,269,16,1818,308,1061,1599,1284,33,257,32,292,513]

theorem envBound44111 : H12AffineFastState.Bounded env44111 := by
  intro p hp
  have h : env44111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44110_44111 : H12AffineEnvironment.transform 11 1060 env44110 = env44111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env44110 == env44111) = true)

theorem identity44111 : scanCanonicalize (H12AffineFastState.compose env44111 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44111 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44112 : List Nat := [2,4,8,16,32,16,9,256,512,273,522,309,268,293,0,263,308,814,272,1,293,32,16,2,269,16,523,308,308,814,21,33,257,32,292,513]

theorem envBound44112 : H12AffineFastState.Bounded env44112 := by
  intro p hp
  have h : env44112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44111_44112 : H12AffineEnvironment.transform 9 273 env44111 = env44112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44111 == env44112) = true)

theorem identity44112 : scanCanonicalize (H12AffineFastState.compose env44112 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44112 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44113 : List Nat := [2,4,8,16,32,16,9,4,512,21,522,49,8,33,0,3,48,554,20,1,33,32,16,2,9,16,523,48,48,554,21,33,5,32,32,513]

theorem envBound44113 : H12AffineFastState.Bounded env44113 := by
  intro p hp
  have h : env44113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44112_44113 : H12AffineEnvironment.transform 7 4 env44112 = env44113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44112 == env44113) = true)

theorem identity44113 : scanCanonicalize (H12AffineFastState.compose env44113 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound44113 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44114 : List Nat := [2,4,8,16,32,16,9,4,43,21,33,49,8,33,0,3,48,1,20,1,33,32,16,2,9,16,32,48,48,1,21,33,5,32,32,42]

theorem envBound44114 : H12AffineFastState.Bounded env44114 := by
  intro p hp
  have h : env44114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44113_44114 : H12AffineEnvironment.transform 8 43 env44113 = env44114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env44113 == env44114) = true)

theorem identity44114 : scanCanonicalize (H12AffineFastState.compose env44114 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44114 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44115 : List Nat := [2,4,8,16,0,16,9,4,11,21,1,17,8,1,0,3,16,1,20,1,1,0,16,2,9,16,0,16,16,1,21,1,5,0,0,10]

theorem envBound44115 : H12AffineFastState.Bounded env44115 := by
  intro p hp
  have h : env44115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44114_44115 : H12AffineEnvironment.transform 4 0 env44114 = env44115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44114 == env44115) = true)

theorem identity44115 : scanCanonicalize (H12AffineFastState.compose env44115 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44115 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44116 : List Nat := [2,1,8,16,0,16,9,1,11,16,1,17,8,1,0,3,16,1,17,1,1,0,16,2,9,16,0,16,16,1,16,1,0,0,0,10]

theorem envBound44116 : H12AffineFastState.Bounded env44116 := by
  intro p hp
  have h : env44116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44115_44116 : H12AffineEnvironment.transform 1 1 env44115 = env44116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44115 == env44116) = true)

theorem identity44116 : scanCanonicalize (H12AffineFastState.compose env44116 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44117 : List Nat := [1,1,8,16,0,16,9,1,8,16,1,17,8,1,0,0,16,1,17,1,1,0,16,1,9,16,0,16,16,1,16,1,0,0,0,9]

theorem envBound44117 : H12AffineFastState.Bounded env44117 := by
  intro p hp
  have h : env44117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44116_44117 : H12AffineEnvironment.transform 0 1 env44116 = env44117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44116 == env44117) = true)

def env44118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10281,1025,32769,58516,168,62660,98780,8328,64,23808,57796,17664,56436,61705,32,257,21793,46213,120542]

theorem envBound44118 : H12AffineFastState.Bounded env44118 := by
  intro p hp
  have h : env44118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44102_44118 : H12AffineEnvironment.transform 17 10281 env44102 = env44118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44102 == env44118) = true)

theorem identity44118 : scanCanonicalize (H12AffineFastState.compose env44118 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29742) := by decide +kernel

theorem selectedBound44118 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env44119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29742,49304,10281,1025,32769,58516,168,62660,62962,8328,64,23808,57796,17664,56436,61705,32,257,21793,46213,41712]

theorem envBound44119 : H12AffineFastState.Bounded env44119 := by
  intro p hp
  have h : env44119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44118_44119 : H12AffineEnvironment.transform 15 29742 env44118 = env44119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29742 env44118 == env44119) = true)

theorem identity44119 : scanCanonicalize (H12AffineFastState.compose env44119 (packedSelected [0,1,3,9,12,15,16,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound44119 : packedSelected [0,1,3,9,12,15,16,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,32768,9446,36944,10281,1025,32769,46172,168,41996,42298,8328,64,3528,45324,5576,36028,41409,32,257,1513,46213,41712]

theorem envBound44120 : H12AffineFastState.Bounded env44120 := by
  intro p hp
  have h : env44120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44119_44120 : H12AffineEnvironment.transform 13 4296 env44119 = env44120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env44119 == env44120) = true)

theorem identity44120 : scanCanonicalize (H12AffineFastState.compose env44120 (packedSelected [0,1,2,3,5,6,8,10,14,17,18,19,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound44120 : packedSelected [0,1,2,3,5,6,8,10,14,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env44121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8353,9446,12529,10281,1025,8352,5373,168,1197,1435,8328,64,3528,4525,5576,11293,352,32,257,1513,5156,593]

theorem envBound44121 : H12AffineFastState.Bounded env44121 := by
  intro p hp
  have h : env44121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44120_44121 : H12AffineEnvironment.transform 14 8353 env44120 = env44121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env44120 == env44121) = true)

theorem identity44121 : scanCanonicalize (H12AffineFastState.compose env44121 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44121 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env44122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4248,8353,9398,12449,10281,1025,8352,5293,168,1197,1435,8328,16,3480,4525,5528,11293,304,32,257,1465,5156,513]

theorem envBound44122 : H12AffineFastState.Bounded env44122 := by
  intro p hp
  have h : env44122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44121_44122 : H12AffineEnvironment.transform 5 16 env44121 = env44122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44121 == env44122) = true)

theorem identity44122 : scanCanonicalize (H12AffineFastState.compose env44122 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound44122 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env44123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,40,4248,137,1182,4233,2049,1025,136,5293,168,1197,1435,160,16,3480,4525,5528,3125,304,32,257,1465,5156,513]

theorem envBound44123 : H12AffineFastState.Bounded env44123 := by
  intro p hp
  have h : env44123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44122_44123 : H12AffineEnvironment.transform 12 40 env44122 = env44123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env44122 == env44123) = true)

theorem identity44123 : scanCanonicalize (H12AffineFastState.compose env44123 (packedSelected [0,1,3,5,6,7,8,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound44123 : packedSelected [0,1,3,5,6,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env44124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3076,40,3228,137,1182,3213,2049,1025,136,2217,168,1197,1435,160,16,3480,3497,2460,3125,304,32,257,1465,2080,513]

theorem envBound44124 : H12AffineFastState.Bounded env44124 := by
  intro p hp
  have h : env44124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44123_44124 : H12AffineEnvironment.transform 11 3076 env44123 = env44124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env44123 == env44124) = true)

theorem identity44124 : scanCanonicalize (H12AffineFastState.compose env44124 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44124 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44125 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,40,3093,0,1047,3076,2049,1025,1,2080,33,1060,1298,41,16,3345,3360,2325,3125,304,32,257,1328,2080,513]

theorem envBound44125 : H12AffineFastState.Bounded env44125 := by
  intro p hp
  have h : env44125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44124_44125 : H12AffineEnvironment.transform 6 9 env44124 = env44125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44124 == env44125) = true)

theorem identity44125 : scanCanonicalize (H12AffineFastState.compose env44125 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound44125 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44126 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,1313,40,1328,0,1047,1313,292,1025,1,261,33,1060,1298,41,16,1076,1029,48,1296,304,32,257,1328,261,513]

theorem envBound44126 : H12AffineFastState.Bounded env44126 := by
  intro p hp
  have h : env44126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44125_44126 : H12AffineEnvironment.transform 10 293 env44125 = env44126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env44125 == env44126) = true)

theorem identity44126 : scanCanonicalize (H12AffineFastState.compose env44126 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44126 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44127 : List Nat := [2,4,8,16,32,16,9,5,512,1024,32,1060,40,1077,0,1047,1060,33,1025,1,0,33,1060,1047,41,16,1076,1029,48,1045,53,32,4,1077,0,513]

theorem envBound44127 : H12AffineFastState.Bounded env44127 := by
  intro p hp
  have h : env44127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44126_44127 : H12AffineEnvironment.transform 7 5 env44126 = env44127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44126 == env44127) = true)

theorem identity44127 : scanCanonicalize (H12AffineFastState.compose env44127 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44127 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44128 : List Nat := [2,4,8,16,0,16,9,5,512,1024,0,1028,8,1045,0,1047,1028,1,1025,1,0,1,1028,1047,9,16,1044,1029,16,1045,21,0,4,1045,0,513]

theorem envBound44128 : H12AffineFastState.Bounded env44128 := by
  intro p hp
  have h : env44128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44127_44128 : H12AffineEnvironment.transform 4 0 env44127 = env44128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44127 == env44128) = true)

theorem identity44128 : scanCanonicalize (H12AffineFastState.compose env44128 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound44128 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env44129 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,17,8,0,0,2,17,1,20,1,0,1,17,2,9,16,1,16,16,0,21,0,4,0,0,513]

theorem envBound44129 : H12AffineFastState.Bounded env44129 := by
  intro p hp
  have h : env44129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44128_44129 : H12AffineEnvironment.transform 9 21 env44128 = env44129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44128 == env44129) = true)

theorem identity44129 : scanCanonicalize (H12AffineFastState.compose env44129 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44130 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,17,8,0,0,2,17,1,20,1,0,1,17,2,9,16,1,16,16,0,21,0,4,0,0,0]

theorem envBound44130 : H12AffineFastState.Bounded env44130 := by
  intro p hp
  have h : env44130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44129_44130 : H12AffineEnvironment.transform 8 1 env44129 = env44130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44129 == env44130) = true)

theorem identity44130 : scanCanonicalize (H12AffineFastState.compose env44130 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44131 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,1,8,0,0,2,1,1,4,1,0,1,1,2,9,0,1,0,0,0,5,0,4,0,0,0]

theorem envBound44131 : H12AffineFastState.Bounded env44131 := by
  intro p hp
  have h : env44131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44130_44131 : H12AffineEnvironment.transform 3 0 env44130 = env44131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44130 == env44131) = true)

def env44132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590740,2098513,17665,2363593,2102685,6349853,257,21793,46213,2175562]

theorem envBound44132 : H12AffineFastState.Bounded env44132 := by
  intro p hp
  have h : env44132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44071_44132 : H12AffineEnvironment.transform 16 49305 env44071 = env44132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env44071 == env44132) = true)

def env44133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144660,2098513,17665,2363593,2102685,2411677,257,21793,46213,2175562]

theorem envBound44133 : H12AffineFastState.Bounded env44133 := by
  intro p hp
  have h : env44133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44132_44133 : H12AffineEnvironment.transform 21 272512 env44132 = env44133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44132 == env44133) = true)

def env44134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101329,98645,8192,64,2144540,2098513,17665,2363457,2102549,2411541,257,21793,46093,2175562]

theorem envBound44134 : H12AffineFastState.Bounded env44134 := by
  intro p hp
  have h : env44134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44133_44134 : H12AffineEnvironment.transform 6 8 env44133 = env44134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44133 == env44134) = true)

theorem identity44134 : scanCanonicalize (H12AffineFastState.compose env44134 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 110667) := by decide +kernel

theorem selectedBound44134 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,110667,272392,106522,98645,8192,64,67927,111898,17665,368650,107870,359518,257,21793,46093,33281]

theorem envBound44135 : H12AffineFastState.Bounded env44135 := by
  intro p hp
  have h : env44135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44134_44135 : H12AffineEnvironment.transform 20 110667 env44134 = env44135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110667 env44134 == env44135) = true)

theorem identity44135 : scanCanonicalize (H12AffineFastState.compose env44135 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44135 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,49169,262144,1025,32769,102678,264533,98631,98645,349,64,67927,103495,17665,360791,99331,351491,257,21793,38224,33281]

theorem envBound44136 : H12AffineFastState.Bounded env44136 := by
  intro p hp
  have h : env44136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44135_44136 : H12AffineEnvironment.transform 12 349 env44135 = env44136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44135 == env44136) = true)

theorem identity44136 : scanCanonicalize (H12AffineFastState.compose env44136 (packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound44136 : packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,49169,56356,1025,32769,102678,54641,98631,98645,349,64,67927,103495,17665,89459,99331,98599,257,21793,38224,33281]

theorem envBound44137 : H12AffineFastState.Bounded env44137 := by
  intro p hp
  have h : env44137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44136_44137 : H12AffineEnvironment.transform 17 56356 env44136 = env44137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env44136 == env44137) = true)

theorem identity44137 : scanCanonicalize (H12AffineFastState.compose env44137 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound44137 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33111,49169,56356,1025,32769,4161,54641,16,2,349,64,34816,5392,17665,56356,1364,112,257,21793,38224,33281]

theorem envBound44138 : H12AffineFastState.Bounded env44138 := by
  intro p hp
  have h : env44138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44137_44138 : H12AffineEnvironment.transform 15 33111 env44137 = env44138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env44137 == env44138) = true)

theorem identity44138 : scanCanonicalize (H12AffineFastState.compose env44138 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44138 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,343,16401,23588,1025,1,4161,21873,16,2,349,64,2048,5392,17665,23588,1364,112,257,21793,5456,513]

theorem envBound44139 : H12AffineFastState.Bounded env44139 := by
  intro p hp
  have h : env44139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44138_44139 : H12AffineEnvironment.transform 14 0 env44138 = env44139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44138 == env44139) = true)

theorem identity44139 : scanCanonicalize (H12AffineFastState.compose env44139 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound44139 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,0,343,5173,2048,1025,1,4161,341,16,2,349,64,2048,5392,4389,2048,1364,112,257,261,5456,513]

theorem envBound44140 : H12AffineFastState.Bounded env44140 := by
  intro p hp
  have h : env44140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44139_44140 : H12AffineEnvironment.transform 13 5156 env44139 = env44140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env44139 == env44140) = true)

theorem identity44140 : scanCanonicalize (H12AffineFastState.compose env44140 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44140 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44141 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4113,0,343,4096,2048,52,1,4161,341,16,2,349,64,2048,4389,4389,2048,353,112,257,261,4453,513]

theorem envBound44141 : H12AffineFastState.Bounded env44141 := by
  intro p hp
  have h : env44141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44140_44141 : H12AffineEnvironment.transform 9 53 env44140 = env44141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44140 == env44141) = true)

theorem identity44141 : scanCanonicalize (H12AffineFastState.compose env44141 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44142 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,120,4113,0,114,4096,2048,52,1,4161,112,16,2,120,64,2048,4096,4096,2048,68,112,36,32,4160,513]

theorem envBound44142 : H12AffineFastState.Bounded env44142 := by
  intro p hp
  have h : env44142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44141_44142 : H12AffineEnvironment.transform 7 37 env44141 = env44142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44141 == env44142) = true)

theorem identity44142 : scanCanonicalize (H12AffineFastState.compose env44142 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44142 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44143 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,4096,120,4113,0,114,4096,0,52,1,4161,112,16,2,120,64,0,4096,4096,0,68,112,36,32,4160,513]

theorem envBound44143 : H12AffineFastState.Bounded env44143 := by
  intro p hp
  have h : env44143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44142_44143 : H12AffineEnvironment.transform 10 0 env44142 = env44143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44142 == env44143) = true)

theorem identity44143 : scanCanonicalize (H12AffineFastState.compose env44143 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 91) := by decide +kernel

theorem selectedBound44143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44144 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,91,120,74,0,114,91,0,52,1,26,112,16,2,120,64,0,91,91,0,68,112,36,32,27,513]

theorem envBound44144 : H12AffineFastState.Bounded env44144 := by
  intro p hp
  have h : env44144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44143_44144 : H12AffineEnvironment.transform 11 91 env44143 = env44144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 91 env44143 == env44144) = true)

def env44145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101329,98644,8193,64,2144541,2098513,17665,2363456,2102548,2411540,257,21793,46092,2175562]

theorem envBound44145 : H12AffineFastState.Bounded env44145 := by
  intro p hp
  have h : env44145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44133_44145 : H12AffineEnvironment.transform 6 9 env44133 = env44145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44133 == env44145) = true)

def env44146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,98644,8193,64,43357,5393,17665,262144,1364,318548,257,21793,46092,74250]

theorem envBound44146 : H12AffineFastState.Bounded env44146 := by
  intro p hp
  have h : env44146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44145_44146 : H12AffineEnvironment.transform 20 4160 env44145 = env44146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44145 == env44146) = true)

theorem identity44146 : scanCanonicalize (H12AffineFastState.compose env44146 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44146 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,33,17,98644,8193,64,43357,5393,17665,10280,1364,62588,257,21793,46092,74250]

theorem envBound44147 : H12AffineFastState.Bounded env44147 := by
  intro p hp
  have h : env44147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44146_44147 : H12AffineEnvironment.transform 17 10280 env44146 = env44147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44146 == env44147) = true)

theorem identity44147 : scanCanonicalize (H12AffineFastState.compose env44147 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44147 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env44148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1025,8541,4160,33,17,73736,8193,64,2049,5393,17665,10280,1364,21792,257,21793,5456,74250]

theorem envBound44148 : H12AffineFastState.Bounded env44148 := by
  intro p hp
  have h : env44148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44147_44148 : H12AffineEnvironment.transform 14 8540 env44147 = env44148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44147 == env44148) = true)

theorem identity44148 : scanCanonicalize (H12AffineFastState.compose env44148 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44148 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env44149 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,24861,10280,1025,8460,4113,33,17,73736,8193,17,2049,5393,17665,10280,1285,21792,257,21793,5377,74250]

theorem envBound44149 : H12AffineFastState.Bounded env44149 := by
  intro p hp
  have h : env44149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44148_44149 : H12AffineEnvironment.transform 5 17 env44148 = env44149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44148 == env44149) = true)

theorem identity44149 : scanCanonicalize (H12AffineFastState.compose env44149 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound44149 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env44150 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,263,24861,10280,1025,8460,4113,33,17,8463,8193,17,2049,5393,17665,10280,1285,21792,257,21793,5377,8973]

theorem envBound44150 : H12AffineFastState.Bounded env44150 := by
  intro p hp
  have h : env44150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44149_44150 : H12AffineEnvironment.transform 15 263 env44149 = env44150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env44149 == env44150) = true)

theorem identity44150 : scanCanonicalize (H12AffineFastState.compose env44150 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound44150 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44151 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5409,8461,263,13372,10280,1025,8460,4113,33,17,8463,8193,17,2049,5393,4128,10280,1285,1,257,0,5377,8973]

theorem envBound44151 : H12AffineFastState.Bounded env44151 := by
  intro p hp
  have h : env44151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44150_44151 : H12AffineEnvironment.transform 13 5409 env44150 = env44151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env44150 == env44151) = true)

theorem identity44151 : scanCanonicalize (H12AffineFastState.compose env44151 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound44151 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env44152 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2081,8192,3328,8461,263,11293,10280,1025,8460,2096,33,17,8463,8193,17,2049,3376,2049,10280,1285,1,257,0,3360,8973]

theorem envBound44152 : H12AffineFastState.Bounded env44152 := by
  intro p hp
  have h : env44152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44151_44152 : H12AffineEnvironment.transform 11 2081 env44151 = env44152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env44151 == env44152) = true)

theorem identity44152 : scanCanonicalize (H12AffineFastState.compose env44152 (packedSelected [0,2,7,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44152 : packedSelected [0,2,7,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44153 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2048,8192,3328,8461,263,11293,10249,1025,8460,2065,0,17,8463,8193,17,2049,3345,2049,10249,1285,1,257,0,3329,8973]

theorem envBound44153 : H12AffineFastState.Bounded env44153 := by
  intro p hp
  have h : env44153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44152_44153 : H12AffineEnvironment.transform 4 1 env44152 = env44153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44152 == env44153) = true)

theorem identity44153 : scanCanonicalize (H12AffineFastState.compose env44153 (packedSelected [11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound44153 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env44154 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2048,1053,3328,1296,263,2048,3092,1025,1297,2065,0,17,1298,1052,17,2049,3345,2049,3092,1285,1,257,0,3329,1808]

theorem envBound44154 : H12AffineFastState.Bounded env44154 := by
  intro p hp
  have h : env44154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44153_44154 : H12AffineEnvironment.transform 12 1053 env44153 = env44154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env44153 == env44154) = true)

theorem identity44154 : scanCanonicalize (H12AffineFastState.compose env44154 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound44154 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44155 : List Nat := [2,4,8,16,1,17,9,256,512,1024,1280,1280,1053,0,1296,263,1280,276,1025,1297,1297,0,17,1298,1052,17,1281,17,1281,276,1285,1,257,0,1,1808]

theorem envBound44155 : H12AffineFastState.Bounded env44155 := by
  intro p hp
  have h : env44155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44154_44155 : H12AffineEnvironment.transform 10 1280 env44154 = env44155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env44154 == env44155) = true)

theorem identity44155 : scanCanonicalize (H12AffineFastState.compose env44155 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44155 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env44156 : List Nat := [2,4,8,16,1,17,9,256,512,272,16,16,269,0,0,263,16,276,273,1,1,0,17,2,268,17,17,17,17,276,21,1,257,0,1,512]

theorem envBound44156 : H12AffineFastState.Bounded env44156 := by
  intro p hp
  have h : env44156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44155_44156 : H12AffineEnvironment.transform 9 272 env44155 = env44156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44155 == env44156) = true)

theorem identity44156 : scanCanonicalize (H12AffineFastState.compose env44156 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44157 : List Nat := [2,4,8,1,1,0,9,256,512,257,1,1,269,0,0,263,1,261,256,1,1,0,0,2,268,0,0,0,0,261,4,1,257,0,1,512]

theorem envBound44157 : H12AffineFastState.Bounded env44157 := by
  intro p hp
  have h : env44157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44156_44157 : H12AffineEnvironment.transform 3 1 env44156 = env44157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44156 == env44157) = true)

theorem identity44157 : scanCanonicalize (H12AffineFastState.compose env44157 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 257) := by decide +kernel

theorem selectedBound44157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44158 : List Nat := [2,4,8,1,1,0,9,256,257,257,1,1,269,0,0,263,1,261,256,1,1,0,0,2,268,0,0,0,0,261,4,1,257,0,1,257]

theorem envBound44158 : H12AffineFastState.Bounded env44158 := by
  intro p hp
  have h : env44158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44157_44158 : H12AffineEnvironment.transform 8 257 env44157 = env44158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 257 env44157 == env44158) = true)

theorem identity44158 : scanCanonicalize (H12AffineFastState.compose env44158 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44158 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44159 : List Nat := [2,1,8,1,1,0,9,256,257,257,1,1,264,0,0,258,1,256,256,1,1,0,0,2,265,0,0,0,0,256,1,1,257,0,1,257]

theorem envBound44159 : H12AffineFastState.Bounded env44159 := by
  intro p hp
  have h : env44159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44158_44159 : H12AffineEnvironment.transform 1 1 env44158 = env44159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44158 == env44159) = true)

theorem identity44159 : scanCanonicalize (H12AffineFastState.compose env44159 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound44159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44160 : List Nat := [2,1,8,1,1,0,9,0,1,1,1,1,8,0,0,2,1,0,0,1,1,0,0,2,9,0,0,0,0,0,1,1,1,0,1,1]

theorem envBound44160 : H12AffineFastState.Bounded env44160 := by
  intro p hp
  have h : env44160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44159_44160 : H12AffineEnvironment.transform 7 0 env44159 = env44160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env44159 == env44160) = true)

def env44161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,16,98644,8193,64,43356,5392,17665,262145,1365,318549,257,21793,46092,74251]

theorem envBound44161 : H12AffineFastState.Bounded env44161 := by
  intro p hp
  have h : env44161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44145_44161 : H12AffineEnvironment.transform 20 4161 env44145 = env44161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44145 == env44161) = true)

theorem identity44161 : scanCanonicalize (H12AffineFastState.compose env44161 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound44161 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130095,1025,32769,4161,119846,16,98644,8193,64,43356,5392,17665,130094,1365,73850,257,21793,46092,74251]

theorem envBound44162 : H12AffineFastState.Bounded env44162 := by
  intro p hp
  have h : env44162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44161_44162 : H12AffineEnvironment.transform 17 130095 env44161 = env44162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env44161 == env44162) = true)

theorem identity44162 : scanCanonicalize (H12AffineFastState.compose env44162 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound44162 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,46109,100386,1025,32769,4161,106539,16,98644,8193,64,43356,5392,12556,100387,1365,73850,257,8492,46092,74251]

theorem envBound44163 : H12AffineFastState.Bounded env44163 := by
  intro p hp
  have h : env44163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44162_44163 : H12AffineEnvironment.transform 13 13325 env44162 = env44163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env44162 == env44163) = true)

theorem identity44163 : scanCanonicalize (H12AffineFastState.compose env44163 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44163 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env44164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,8202,46109,43048,1025,32769,4161,32801,16,41310,8193,64,43356,5392,12556,43049,1365,112,257,8492,46092,513]

theorem envBound44164 : H12AffineFastState.Bounded env44164 := by
  intro p hp
  have h : env44164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44163_44164 : H12AffineEnvironment.transform 15 8202 env44163 = env44164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44163 == env44164) = true)

theorem identity44164 : scanCanonicalize (H12AffineFastState.compose env44164 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44164 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1025,1,4161,33,16,8542,8193,64,10588,5392,12556,10281,1365,112,257,8492,13324,513]

theorem envBound44165 : H12AffineFastState.Bounded env44165 := by
  intro p hp
  have h : env44165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44164_44165 : H12AffineEnvironment.transform 14 0 env44164 = env44165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44164 == env44165) = true)

theorem identity44165 : scanCanonicalize (H12AffineFastState.compose env44165 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7449) := by decide +kernel

theorem selectedBound44165 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7449,2324,0,7443,2308,5425,1025,1,4161,33,16,7239,7448,64,5189,5392,3093,5424,1365,112,257,7221,2325,513]

theorem envBound44166 : H12AffineFastState.Bounded env44166 := by
  intro p hp
  have h : env44166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44165_44166 : H12AffineEnvironment.transform 12 7449 env44165 = env44166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7449 env44165 == env44166) = true)

theorem identity44166 : scanCanonicalize (H12AffineFastState.compose env44166 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound44166 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1323,4096,4146,1087,0,4152,1071,5425,1025,1,4161,33,16,4460,4147,64,5189,5392,318,5424,1365,112,257,4382,1086,513]

theorem envBound44167 : H12AffineFastState.Bounded env44167 := by
  intro p hp
  have h : env44167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44166_44167 : H12AffineEnvironment.transform 10 1323 env44166 = env44167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env44166 == env44167) = true)

theorem identity44167 : scanCanonicalize (H12AffineFastState.compose env44167 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 318) := by decide +kernel

theorem selectedBound44167 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env44168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1323,318,268,1087,0,262,1071,1039,1025,1,383,33,16,82,269,64,1403,1070,318,1038,1365,112,257,32,1086,513]

theorem envBound44168 : H12AffineFastState.Bounded env44168 := by
  intro p hp
  have h : env44168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44167_44168 : H12AffineEnvironment.transform 11 318 env44167 = env44168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 318 env44167 == env44168) = true)

theorem identity44168 : scanCanonicalize (H12AffineFastState.compose env44168 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44168 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44169 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,318,268,1087,0,262,1071,1039,1025,1,303,33,16,2,269,16,1323,1070,318,1038,1285,32,257,32,1086,513]

theorem envBound44169 : H12AffineFastState.Bounded env44169 := by
  intro p hp
  have h : env44169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44168_44169 : H12AffineEnvironment.transform 5 16 env44168 = env44169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44168 == env44169) = true)

theorem identity44169 : scanCanonicalize (H12AffineFastState.compose env44169 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound44169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44170 : List Nat := [2,4,8,16,32,16,9,63,512,1024,1044,1,51,1087,0,57,1071,1039,1025,1,16,33,16,2,50,16,1044,1070,1,1038,1082,32,62,32,1086,513]

theorem envBound44170 : H12AffineFastState.Bounded env44170 := by
  intro p hp
  have h : env44170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44169_44170 : H12AffineEnvironment.transform 7 63 env44169 = env44170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env44169 == env44170) = true)

theorem identity44170 : scanCanonicalize (H12AffineFastState.compose env44170 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44170 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44171 : List Nat := [2,4,8,16,1,16,9,30,512,1024,1044,1,18,1054,0,24,1038,1039,1025,1,16,0,16,2,19,16,1044,1039,1,1038,1051,1,31,1,1055,513]

theorem envBound44171 : H12AffineFastState.Bounded env44171 := by
  intro p hp
  have h : env44171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44170_44171 : H12AffineEnvironment.transform 4 1 env44170 = env44171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44170 == env44171) = true)

theorem identity44171 : scanCanonicalize (H12AffineFastState.compose env44171 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44171 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44172 : List Nat := [2,4,8,10,1,10,9,4,512,1024,1038,1,8,1028,0,2,1038,1039,1025,1,10,0,10,2,9,10,1038,1039,1,1038,1025,1,5,1,1029,513]

theorem envBound44172 : H12AffineFastState.Bounded env44172 := by
  intro p hp
  have h : env44172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44171_44172 : H12AffineEnvironment.transform 3 10 env44171 = env44172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44171 == env44172) = true)

theorem identity44172 : scanCanonicalize (H12AffineFastState.compose env44172 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44172 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env44173 : List Nat := [2,4,3,1,1,1,2,4,512,1024,1029,1,3,1028,0,2,1029,1028,1025,1,1,0,1,2,2,1,1029,1028,1,1029,1025,1,5,1,1029,513]

theorem envBound44173 : H12AffineFastState.Bounded env44173 := by
  intro p hp
  have h : env44173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44172_44173 : H12AffineEnvironment.transform 2 3 env44172 = env44173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44172 == env44173) = true)

theorem identity44173 : scanCanonicalize (H12AffineFastState.compose env44173 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound44173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44174 : List Nat := [2,4,3,1,1,1,2,4,512,1,4,1,3,5,0,2,4,5,0,1,1,0,1,2,2,1,4,5,1,4,0,1,5,1,4,513]

theorem envBound44174 : H12AffineFastState.Bounded env44174 := by
  intro p hp
  have h : env44174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44173_44174 : H12AffineEnvironment.transform 9 1 env44173 = env44174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env44173 == env44174) = true)

def env44175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144661,2098513,17665,2363593,2102685,2411676,257,21793,46213,2175562]

theorem envBound44175 : H12AffineFastState.Bounded env44175 := by
  intro p hp
  have h : env44175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44132_44175 : H12AffineEnvironment.transform 21 272513 env44132 = env44175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44132 == env44175) = true)

theorem identity44175 : scanCanonicalize (H12AffineFastState.compose env44175 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound44175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272513,17,98781,8328,64,43477,5393,17665,262281,1501,318684,257,21793,46213,74250]

theorem envBound44176 : H12AffineFastState.Bounded env44176 := by
  intro p hp
  have h : env44176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44175_44176 : H12AffineEnvironment.transform 20 4160 env44175 = env44176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44175 == env44176) = true)

theorem identity44176 : scanCanonicalize (H12AffineFastState.compose env44176 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44176 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4160,272513,17,41430,8328,64,43477,5393,17665,262281,1501,318684,257,21793,46213,513]

theorem envBound44177 : H12AffineFastState.Bounded env44177 := by
  intro p hp
  have h : env44177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44176_44177 : H12AffineEnvironment.transform 15 8203 env44176 = env44177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44176 == env44177) = true)

theorem identity44177 : scanCanonicalize (H12AffineFastState.compose env44177 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44177 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,262144,1025,8541,4160,272513,17,138,8328,64,2185,5393,17665,262281,1501,294272,257,21793,5593,513]

theorem envBound44178 : H12AffineFastState.Bounded env44178 := by
  intro p hp
  have h : env44178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44177_44178 : H12AffineEnvironment.transform 14 8540 env44177 = env44178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44177 == env44178) = true)

theorem identity44178 : scanCanonicalize (H12AffineFastState.compose env44178 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44178 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,10280,1025,8541,4160,169,17,138,8328,64,2185,5393,17665,10401,1501,21928,257,21793,5593,513]

theorem envBound44179 : H12AffineFastState.Bounded env44179 := by
  intro p hp
  have h : env44179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44178_44179 : H12AffineEnvironment.transform 17 10280 env44178 = env44179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44178 == env44179) = true)

theorem identity44179 : scanCanonicalize (H12AffineFastState.compose env44179 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound44179 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8203,13388,10280,1025,8541,4160,169,17,138,8328,64,2185,5393,4232,10401,1501,33,257,168,5593,513]

theorem envBound44180 : H12AffineFastState.Bounded env44180 := by
  intro p hp
  have h : env44180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44179_44180 : H12AffineEnvironment.transform 13 5513 env44179 = env44180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env44179 == env44180) = true)

theorem identity44180 : scanCanonicalize (H12AffineFastState.compose env44180 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44180 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env44181 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8233,8203,13388,10280,1025,8232,4160,169,17,138,8328,64,2185,5220,4232,10401,1192,33,116,168,5292,513]

theorem envBound44181 : H12AffineFastState.Bounded env44181 := by
  intro p hp
  have h : env44181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44180_44181 : H12AffineEnvironment.transform 7 117 env44180 = env44181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44180 == env44181) = true)

theorem identity44181 : scanCanonicalize (H12AffineFastState.compose env44181 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44181 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44182 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,41,5372,0,34,5221,2049,1025,1,4160,169,17,138,161,64,2185,5220,4232,2184,1192,33,116,168,5292,513]

theorem envBound44182 : H12AffineFastState.Bounded env44182 := by
  intro p hp
  have h : env44182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44181_44182 : H12AffineEnvironment.transform 12 41 env44181 = env44182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44181 == env44182) = true)

theorem identity44182 : scanCanonicalize (H12AffineFastState.compose env44182 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 216) := by decide +kernel

theorem selectedBound44182 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env44183 : List Nat := [2,4,8,16,32,64,128,117,512,1024,216,4096,41,5372,0,34,5221,217,1025,1,4160,169,17,138,161,64,81,5220,4232,80,1192,33,116,168,5292,513]

theorem envBound44183 : H12AffineFastState.Bounded env44183 := by
  intro p hp
  have h : env44183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44182_44183 : H12AffineEnvironment.transform 10 216 env44182 = env44183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env44182 == env44183) = true)

theorem identity44183 : scanCanonicalize (H12AffineFastState.compose env44183 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44183 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env44184 : List Nat := [2,4,8,16,32,64,9,117,512,1024,81,4096,41,5237,0,34,5221,80,1025,1,4160,32,17,3,40,64,81,5220,4097,80,1057,33,116,33,5157,513]

theorem envBound44184 : H12AffineFastState.Bounded env44184 := by
  intro p hp
  have h : env44184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44183_44184 : H12AffineEnvironment.transform 6 9 env44183 = env44184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44183 == env44184) = true)

theorem identity44184 : scanCanonicalize (H12AffineFastState.compose env44184 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound44184 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44185 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,4096,41,4112,0,34,4096,80,100,1,4160,32,17,3,40,64,81,4097,4097,80,68,33,116,33,4160,513]

theorem envBound44185 : H12AffineFastState.Bounded env44185 := by
  intro p hp
  have h : env44185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44184_44185 : H12AffineEnvironment.transform 9 101 env44184 = env44185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env44184 == env44185) = true)

theorem identity44185 : scanCanonicalize (H12AffineFastState.compose env44185 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44186 : List Nat := [2,4,8,16,32,1,9,52,512,36,16,4096,41,4112,0,34,4096,17,37,1,4097,32,17,3,40,1,16,4097,4097,17,5,33,53,33,4097,513]

theorem envBound44186 : H12AffineFastState.Bounded env44186 := by
  intro p hp
  have h : env44186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44185_44186 : H12AffineEnvironment.transform 5 1 env44185 = env44186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44185 == env44186) = true)

theorem identity44186 : scanCanonicalize (H12AffineFastState.compose env44186 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound44186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44187 : List Nat := [2,4,8,16,32,1,9,52,512,36,16,0,41,16,0,34,0,17,37,1,1,32,17,3,40,1,16,1,1,17,5,33,53,33,1,513]

theorem envBound44187 : H12AffineFastState.Bounded env44187 := by
  intro p hp
  have h : env44187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44186_44187 : H12AffineEnvironment.transform 11 0 env44186 = env44187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44186 == env44187) = true)

theorem identity44187 : scanCanonicalize (H12AffineFastState.compose env44187 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44188 : List Nat := [2,4,8,16,16,1,9,4,512,20,16,0,25,16,0,18,0,17,21,1,1,16,17,3,24,1,16,1,1,17,5,17,5,17,1,513]

theorem envBound44188 : H12AffineFastState.Bounded env44188 := by
  intro p hp
  have h : env44188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44187_44188 : H12AffineEnvironment.transform 4 16 env44187 = env44188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44187 == env44188) = true)

theorem identity44188 : scanCanonicalize (H12AffineFastState.compose env44188 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44188 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44189 : List Nat := [2,4,8,0,0,1,9,4,512,4,0,0,9,0,0,2,0,1,5,1,1,0,1,3,8,1,0,1,1,1,5,1,5,1,1,513]

theorem envBound44189 : H12AffineFastState.Bounded env44189 := by
  intro p hp
  have h : env44189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44188_44189 : H12AffineEnvironment.transform 3 0 env44188 = env44189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44188 == env44189) = true)

def env44190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281673,213316,8328,64,6705548,2278856,165273,2363592,2102684,6431876,257,21792,46212,2175563]

theorem envBound44190 : H12AffineFastState.Bounded env44190 := by
  intro p hp
  have h : env44190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44070_44190 : H12AffineEnvironment.transform 22 2281673 env44070 = env44190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281673 env44070 == env44190) = true)

def env44191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590740,2098512,17665,2363592,2102684,6349852,257,21792,46212,2175563]

theorem envBound44191 : H12AffineFastState.Bounded env44191 := by
  intro p hp
  have h : env44191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44190_44191 : H12AffineEnvironment.transform 16 49304 env44190 = env44191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env44190 == env44191) = true)

def env44192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144660,2098512,17665,2363592,2102684,2411676,257,21792,46212,2175563]

theorem envBound44192 : H12AffineFastState.Bounded env44192 := by
  intro p hp
  have h : env44192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44191_44192 : H12AffineEnvironment.transform 21 272512 env44191 = env44192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44191 == env44192) = true)

theorem identity44192 : scanCanonicalize (H12AffineFastState.compose env44192 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound44192 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,115870,272512,120015,98780,8328,64,97546,115150,17665,382038,119042,329730,257,21792,46212,63189]

theorem envBound44193 : H12AffineFastState.Bounded env44193 := by
  intro p hp
  have h : env44193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44192_44193 : H12AffineEnvironment.transform 20 115870 env44192 = env44193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env44192 == env44193) = true)

def env44194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1025,32769,115870,32,120015,98780,8328,64,97546,115150,17665,130294,119042,73890,257,21792,46212,63189]

theorem envBound44194 : H12AffineFastState.Bounded env44194 := by
  intro p hp
  have h : env44194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44193_44194 : H12AffineEnvironment.transform 17 10400 env44193 = env44194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44193 == env44194) = true)

theorem identity44194 : scanCanonicalize (H12AffineFastState.compose env44194 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound44194 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8432,65536,24680,10400,1025,8433,91246,32,95295,74028,8328,64,97546,90430,17665,89094,94706,73890,257,21792,5236,22053]

theorem envBound44195 : H12AffineFastState.Bounded env44195 := by
  intro p hp
  have h : env44195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44194_44195 : H12AffineEnvironment.transform 14 8432 env44194 = env44195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env44194 == env44195) = true)

theorem identity44195 : scanCanonicalize (H12AffineFastState.compose env44195 (packedSelected [0,1,8,9,10,12,14,15,18,19,22,23,27,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound44195 : packedSelected [0,1,8,9,10,12,14,15,18,19,22,23,27,31,35] rootPS < 2^1333 := by decide +kernel

def env44196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13609,8432,65536,5441,10400,1025,8433,69959,32,65814,74028,8328,64,67619,70679,12328,76079,66779,73890,257,8201,5236,8972]

theorem envBound44196 : H12AffineFastState.Bounded env44196 := by
  intro p hp
  have h : env44196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44195_44196 : H12AffineEnvironment.transform 13 13609 env44195 = env44196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env44195 == env44196) = true)

theorem identity44196 : scanCanonicalize (H12AffineFastState.compose env44196 (packedSelected [1,7,8,12,14,15,16,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound44196 : packedSelected [1,7,8,12,14,15,16,26,27] rootPS < 2^1333 := by decide +kernel

def env44197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13609,8432,398,5441,10400,1025,8433,4297,32,152,8354,8328,64,2477,5529,12328,10401,1365,8492,257,8201,5236,8972]

theorem envBound44197 : H12AffineFastState.Bounded env44197 := by
  intro p hp
  have h : env44197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44196_44197 : H12AffineEnvironment.transform 15 398 env44196 = env44197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env44196 == env44197) = true)

theorem identity44197 : scanCanonicalize (H12AffineFastState.compose env44197 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound44197 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44198 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13525,8432,114,5309,10400,1025,8433,4297,32,152,8354,8328,64,2129,5221,12328,10401,1193,8400,253,8201,5236,8944]

theorem envBound44198 : H12AffineFastState.Bounded env44198 := by
  intro p hp
  have h : env44198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44197_44198 : H12AffineEnvironment.transform 7 252 env44197 = env44198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env44197 == env44198) = true)

theorem identity44198 : scanCanonicalize (H12AffineFastState.compose env44198 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound44198 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44199 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5293,136,114,5309,2264,1025,137,4297,32,152,218,240,64,2129,5221,4176,2265,1193,168,253,113,5236,648]

theorem envBound44199 : H12AffineFastState.Bounded env44199 := by
  intro p hp
  have h : env44199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44198_44199 : H12AffineEnvironment.transform 12 120 env44198 = env44199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env44198 == env44199) = true)

theorem identity44199 : scanCanonicalize (H12AffineFastState.compose env44199 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44199 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44200 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5293,136,34,5309,2184,1025,137,4249,32,152,138,160,16,2049,5173,4096,2185,1193,168,173,33,5156,648]

theorem envBound44200 : H12AffineFastState.Bounded env44200 := by
  intro p hp
  have h : env44200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44199_44200 : H12AffineEnvironment.transform 5 16 env44199 = env44200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44199 == env44200) = true)

theorem identity44200 : scanCanonicalize (H12AffineFastState.compose env44200 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound44200 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env44201 : List Nat := [2,4,8,16,32,16,128,172,512,188,2048,4096,40,4113,136,34,4097,2184,189,137,4249,32,152,138,160,16,2049,4233,4096,2185,21,168,173,33,4248,648]

theorem envBound44201 : H12AffineFastState.Bounded env44201 := by
  intro p hp
  have h : env44201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44200_44201 : H12AffineEnvironment.transform 9 188 env44200 = env44201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env44200 == env44201) = true)

def env44202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1025,32769,115870,33,120015,98780,8328,64,97546,115150,17665,130295,119042,73891,257,21792,46212,63189]

theorem envBound44202 : H12AffineFastState.Bounded env44202 := by
  intro p hp
  have h : env44202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44193_44202 : H12AffineEnvironment.transform 17 10401 env44193 = env44202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44193 == env44202) = true)

theorem identity44202 : scanCanonicalize (H12AffineFastState.compose env44202 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound44202 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,5529,10401,1025,21760,70047,33,65998,87261,8328,64,97546,70863,17665,76278,66563,73891,257,21792,24965,9172]

theorem envBound44203 : H12AffineFastState.Bounded env44203 := by
  intro p hp
  have h : env44203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44202_44203 : H12AffineEnvironment.transform 14 21761 env44202 = env44203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env44202 == env44203) = true)

theorem identity44203 : scanCanonicalize (H12AffineFastState.compose env44203 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound44203 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,479,5529,10401,1025,21760,4160,33,17,21762,8328,64,31957,5392,17665,10281,1500,8572,257,21792,24965,9172]

theorem envBound44204 : H12AffineFastState.Bounded env44204 := by
  intro p hp
  have h : env44204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44203_44204 : H12AffineEnvironment.transform 15 479 env44203 = env44204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env44203 == env44204) = true)

theorem identity44204 : scanCanonicalize (H12AffineFastState.compose env44204 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44204 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env44205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,5392,10280,1025,21760,4160,33,17,21762,8193,64,31836,5392,17665,10281,1365,8572,257,21792,24844,9053]

theorem envBound44205 : H12AffineFastState.Bounded env44205 := by
  intro p hp
  have h : env44205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44204_44205 : H12AffineEnvironment.transform 6 9 env44204 = env44205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44204 == env44205) = true)

theorem identity44205 : scanCanonicalize (H12AffineFastState.compose env44205 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44205 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env44206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,342,5392,10280,1025,1,4160,33,17,3,8193,64,10589,5392,4096,10281,1365,8572,257,33,13325,9053]

theorem envBound44206 : H12AffineFastState.Bounded env44206 := by
  intro p hp
  have h : env44206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44205_44206 : H12AffineEnvironment.transform 13 5377 env44205 = env44206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44205 == env44206) = true)

theorem identity44206 : scanCanonicalize (H12AffineFastState.compose env44206 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44206 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env44207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,342,5392,2341,1025,1,4160,33,17,3,268,64,2128,5392,4096,2340,1365,113,257,33,5376,592]

theorem envBound44207 : H12AffineFastState.Bounded env44207 := by
  intro p hp
  have h : env44207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44206_44207 : H12AffineEnvironment.transform 12 269 env44206 = env44207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44206 == env44207) = true)

theorem identity44207 : scanCanonicalize (H12AffineFastState.compose env44207 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 356) := by decide +kernel

theorem selectedBound44207 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,356,4096,269,5377,0,342,5392,65,1025,1,4160,33,17,3,268,64,308,5392,4096,64,1365,113,257,33,5376,592]

theorem envBound44208 : H12AffineFastState.Bounded env44208 := by
  intro p hp
  have h : env44208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44207_44208 : H12AffineEnvironment.transform 10 356 env44207 = env44208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 356 env44207 == env44208) = true)

theorem identity44208 : scanCanonicalize (H12AffineFastState.compose env44208 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44208 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env44209 : List Nat := [2,4,8,16,32,64,9,256,512,273,356,4096,269,4112,0,342,4097,65,272,1,4160,33,17,3,268,64,308,4097,4096,64,68,113,257,33,4113,592]

theorem envBound44209 : H12AffineFastState.Bounded env44209 := by
  intro p hp
  have h : env44209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44208_44209 : H12AffineEnvironment.transform 9 273 env44208 = env44209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44208 == env44209) = true)

theorem identity44209 : scanCanonicalize (H12AffineFastState.compose env44209 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound44209 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44210 : List Nat := [2,4,8,16,32,64,9,256,512,273,356,592,269,576,0,342,593,65,272,1,528,33,17,3,268,64,308,593,592,64,68,113,257,33,577,592]

theorem envBound44210 : H12AffineFastState.Bounded env44210 := by
  intro p hp
  have h : env44210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44209_44210 : H12AffineEnvironment.transform 11 592 env44209 = env44210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env44209 == env44210) = true)

def env44211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144661,2098512,17665,2363592,2102684,2411677,257,21792,46212,2175563]

theorem envBound44211 : H12AffineFastState.Bounded env44211 := by
  intro p hp
  have h : env44211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44191_44211 : H12AffineEnvironment.transform 21 272513 env44191 = env44211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44191 == env44211) = true)

theorem identity44211 : scanCanonicalize (H12AffineFastState.compose env44211 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound44211 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49304,262144,1025,32769,2097152,272513,2101329,21762,8328,64,2144661,2098512,17665,2363592,2102684,2411677,257,21792,46212,2156181]

theorem envBound44212 : H12AffineFastState.Bounded env44212 := by
  intro p hp
  have h : env44212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44211_44212 : H12AffineEnvironment.transform 15 54494 env44211 = env44212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env44211 == env44212) = true)

def env44213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272393,2101329,21762,8192,64,2144541,2098512,17665,2363456,2102548,2411541,257,21792,46092,2156061]

theorem envBound44213 : H12AffineFastState.Bounded env44213 := by
  intro p hp
  have h : env44213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44212_44213 : H12AffineEnvironment.transform 6 8 env44212 = env44213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44212 == env44213) = true)

theorem identity44213 : scanCanonicalize (H12AffineFastState.compose env44213 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 45113) := by decide +kernel

theorem selectedBound44213 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env44214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,45113,272393,41064,21762,8192,64,2340,46441,17665,303225,42285,293932,257,21792,46092,22052]

theorem envBound44214 : H12AffineFastState.Bounded env44214 := by
  intro p hp
  have h : env44214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44213_44214 : H12AffineEnvironment.transform 20 45113 env44213 = env44214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45113 env44213 == env44214) = true)

theorem identity44214 : scanCanonicalize (H12AffineFastState.compose env44214 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS)) = affineNative (2^(17+1) ^^^ 43277) := by decide +kernel

theorem selectedBound44214 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS < 2^1333 := by decide +kernel

def env44215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43277,1025,32769,45113,33028,41064,21762,8192,64,2340,46441,17665,2420,42285,54561,257,21792,46092,22052]

theorem envBound44215 : H12AffineFastState.Bounded env44215 := by
  intro p hp
  have h : env44215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44214_44215 : H12AffineEnvironment.transform 17 43277 env44214 = env44215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43277 env44214 == env44215) = true)

theorem identity44215 : scanCanonicalize (H12AffineFastState.compose env44215 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound44215 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,342,5392,31757,1025,21761,25913,21508,30056,21762,8192,64,2340,24681,17665,2420,28717,33,257,21792,24844,22052]

theorem envBound44216 : H12AffineFastState.Bounded env44216 := by
  intro p hp
  have h : env44216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44215_44216 : H12AffineEnvironment.transform 14 21760 env44215 = env44216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env44215 == env44216) = true)

theorem identity44216 : scanCanonicalize (H12AffineFastState.compose env44216 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound44216 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,16384,21760,342,5392,16464,1025,21761,22884,21508,18741,21762,7261,64,2340,23604,17665,2420,19568,33,257,21792,23889,22052]

theorem envBound44217 : H12AffineFastState.Bounded env44217 := by
  intro p hp
  have h : env44217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44216_44217 : H12AffineEnvironment.transform 12 7261 env44216 = env44217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env44216 == env44217) = true)

theorem identity44217 : scanCanonicalize (H12AffineFastState.compose env44217 (packedSelected [0,1,2,3,5,6,7,8,12,20] rootPS)) = affineNative (2^(13+1) ^^^ 6500) := by decide +kernel

theorem selectedBound44217 : packedSelected [0,1,2,3,5,6,7,8,12,20] rootPS < 2^1333 := by decide +kernel

def env44218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,6500,3172,342,5392,6452,1025,3173,0,3424,4177,3174,7261,64,2340,1360,7269,2420,5396,33,257,3140,1077,3904]

theorem envBound44218 : H12AffineFastState.Bounded env44218 := by
  intro p hp
  have h : env44218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44217_44218 : H12AffineEnvironment.transform 13 6500 env44217 = env44218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6500 env44217 == env44218) = true)

theorem identity44218 : scanCanonicalize (H12AffineFastState.compose env44218 (packedSelected [1,2,3,4,5,6,8,12,16,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound44218 : packedSelected [1,2,3,4,5,6,8,12,16,17,22] rootPS < 2^1333 := by decide +kernel

def env44219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3328,349,1124,3172,342,2064,1076,1025,3173,0,3424,3409,3174,349,64,2340,1360,357,2420,2068,33,257,3140,1077,3904]

theorem envBound44219 : H12AffineFastState.Bounded env44219 := by
  intro p hp
  have h : env44219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44218_44219 : H12AffineEnvironment.transform 11 3328 env44218 = env44219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env44218 == env44219) = true)

theorem identity44219 : scanCanonicalize (H12AffineFastState.compose env44219 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound44219 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44220 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,349,293,2341,342,2064,373,320,2340,0,2081,2064,2343,349,64,2340,17,357,2420,2068,33,257,2309,372,2561]

theorem envBound44220 : H12AffineFastState.Bounded env44220 := by
  intro p hp
  have h : env44220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44219_44220 : H12AffineEnvironment.transform 9 321 env44219 = env44220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44219 == env44220) = true)

theorem identity44220 : scanCanonicalize (H12AffineFastState.compose env44220 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound44220 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env44221 : List Nat := [2,4,8,16,32,64,8,256,512,321,372,309,349,293,81,342,356,373,320,80,0,341,356,83,349,64,80,17,357,0,352,33,257,113,372,885]

theorem envBound44221 : H12AffineFastState.Bounded env44221 := by
  intro p hp
  have h : env44221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44220_44221 : H12AffineEnvironment.transform 10 372 env44220 = env44221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env44220 == env44221) = true)

theorem identity44221 : scanCanonicalize (H12AffineFastState.compose env44221 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44221 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44222 : List Nat := [2,4,8,16,32,64,8,116,512,53,0,65,41,81,81,34,16,1,52,80,0,33,16,83,41,64,80,17,17,0,20,33,117,113,0,513]

theorem envBound44222 : H12AffineFastState.Bounded env44222 := by
  intro p hp
  have h : env44222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44221_44222 : H12AffineEnvironment.transform 7 116 env44221 = env44222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44221 == env44222) = true)

def env44223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272392,2101329,21762,8193,64,2144540,2098512,17665,2363457,2102549,2411540,257,21792,46093,2156060]

theorem envBound44223 : H12AffineFastState.Bounded env44223 := by
  intro p hp
  have h : env44223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44212_44223 : H12AffineEnvironment.transform 6 9 env44212 = env44223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44212 == env44223) = true)

theorem identity44223 : scanCanonicalize (H12AffineFastState.compose env44223 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound44223 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env44224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,25629,272392,29772,21762,8193,64,56577,24909,17665,291932,28936,305161,257,21792,46093,33281]

theorem envBound44224 : H12AffineFastState.Bounded env44224 := by
  intro p hp
  have h : env44224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44223_44224 : H12AffineEnvironment.transform 20 25629 env44223 = env44224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env44223 == env44224) = true)

theorem identity44224 : scanCanonicalize (H12AffineFastState.compose env44224 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound44224 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43048,1025,32769,25629,32800,29772,21762,8193,64,56577,24909,17665,56436,28936,33,257,21792,46093,33281]

theorem envBound44225 : H12AffineFastState.Bounded env44225 := by
  intro p hp
  have h : env44225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44224_44225 : H12AffineEnvironment.transform 17 43048 env44224 = env44225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env44224 == env44225) = true)

theorem identity44225 : scanCanonicalize (H12AffineFastState.compose env44225 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44225 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env44226 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,49169,43048,1025,32769,25629,32800,29724,21762,8193,16,56577,24861,17665,56356,28936,33,257,21792,46093,33281]

theorem envBound44226 : H12AffineFastState.Bounded env44226 := by
  intro p hp
  have h : env44226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44225_44226 : H12AffineEnvironment.transform 5 16 env44225 = env44226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44225 == env44226) = true)

theorem identity44226 : scanCanonicalize (H12AffineFastState.compose env44226 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound44226 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env44227 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,40970,46108,43048,1025,32769,4112,32800,17,8463,8193,16,43276,5392,12556,43049,1285,33,257,8493,46093,33281]

theorem envBound44227 : H12AffineFastState.Bounded env44227 := by
  intro p hp
  have h : env44227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44226_44227 : H12AffineEnvironment.transform 13 13325 env44226 = env44227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env44226 == env44227) = true)

theorem identity44227 : scanCanonicalize (H12AffineFastState.compose env44227 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44227 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44228 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,8202,13340,10280,1025,1,4112,32,17,8463,8193,16,10508,5392,12556,10281,1285,33,257,8493,13325,513]

theorem envBound44228 : H12AffineFastState.Bounded env44228 := by
  intro p hp
  have h : env44228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44227_44228 : H12AffineEnvironment.transform 14 0 env44227 = env44228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44227 == env44228) = true)

theorem identity44228 : scanCanonicalize (H12AffineFastState.compose env44228 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound44228 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44229 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,8192,11068,0,8202,11053,10280,1025,1,3873,32,17,8463,8193,16,10508,2593,11837,10281,1285,33,257,8493,11068,513]

theorem envBound44229 : H12AffineFastState.Bounded env44229 := by
  intro p hp
  have h : env44229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44228_44229 : H12AffineEnvironment.transform 11 3889 env44228 = env44229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env44228 == env44229) = true)

theorem identity44229 : scanCanonicalize (H12AffineFastState.compose env44229 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44229 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44230 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,269,2609,0,263,2592,2341,1025,1,3873,32,17,2,268,16,2049,2593,3888,2340,1285,33,257,32,2609,513]

theorem envBound44230 : H12AffineFastState.Bounded env44230 := by
  intro p hp
  have h : env44230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44229_44230 : H12AffineEnvironment.transform 12 269 env44229 = env44230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44229 == env44230) = true)

theorem identity44230 : scanCanonicalize (H12AffineFastState.compose env44230 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound44230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44231 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1589,260,269,1028,0,263,1045,1808,1025,1,276,32,17,2,268,16,1588,1044,261,1809,1285,33,257,32,1028,513]

theorem envBound44231 : H12AffineFastState.Bounded env44231 := by
  intro p hp
  have h : env44231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44230_44231 : H12AffineEnvironment.transform 10 1589 env44230 = env44231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env44230 == env44231) = true)

theorem identity44231 : scanCanonicalize (H12AffineFastState.compose env44231 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound44231 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44232 : List Nat := [2,4,8,16,32,16,9,256,512,784,293,260,269,788,0,263,773,0,785,1,276,32,17,2,268,16,292,772,261,1,533,33,257,32,788,513]

theorem envBound44232 : H12AffineFastState.Bounded env44232 := by
  intro p hp
  have h : env44232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44231_44232 : H12AffineEnvironment.transform 9 784 env44231 = env44232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env44231 == env44232) = true)

theorem identity44232 : scanCanonicalize (H12AffineFastState.compose env44232 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44232 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44233 : List Nat := [2,4,8,1,32,1,9,256,512,769,293,260,269,773,0,263,773,0,768,1,261,32,0,2,268,1,292,772,261,1,516,33,257,32,773,513]

theorem envBound44233 : H12AffineFastState.Bounded env44233 := by
  intro p hp
  have h : env44233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44232_44233 : H12AffineEnvironment.transform 3 1 env44232 = env44233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44232 == env44233) = true)

theorem identity44233 : scanCanonicalize (H12AffineFastState.compose env44233 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound44233 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44234 : List Nat := [2,4,8,1,32,1,9,256,260,5,293,260,269,1,0,263,1,0,4,1,261,32,0,2,268,1,292,0,261,1,256,33,257,32,1,261]

theorem envBound44234 : H12AffineFastState.Bounded env44234 := by
  intro p hp
  have h : env44234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44233_44234 : H12AffineEnvironment.transform 8 260 env44233 = env44234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env44233 == env44234) = true)

theorem identity44234 : scanCanonicalize (H12AffineFastState.compose env44234 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44234 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env44235 : List Nat := [2,4,8,1,1,1,9,256,260,5,260,260,269,1,0,263,1,0,4,1,261,1,0,2,268,1,261,0,261,1,256,0,257,1,1,261]

theorem envBound44235 : H12AffineFastState.Bounded env44235 := by
  intro p hp
  have h : env44235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44234_44235 : H12AffineEnvironment.transform 4 1 env44234 = env44235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44234 == env44235) = true)

theorem identity44235 : scanCanonicalize (H12AffineFastState.compose env44235 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44236 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,0,9,1,0,3,1,0,4,1,1,1,0,2,8,1,1,0,1,1,4,0,5,1,1,1]

theorem envBound44236 : H12AffineFastState.Bounded env44236 := by
  intro p hp
  have h : env44236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44235_44236 : H12AffineEnvironment.transform 7 4 env44235 = env44236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44235 == env44236) = true)

theorem identity44236 : scanCanonicalize (H12AffineFastState.compose env44236 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44236 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44237 : List Nat := [2,4,3,1,1,1,2,4,0,5,0,0,2,1,0,3,1,0,4,1,1,1,0,2,3,1,1,0,1,1,4,0,5,1,1,1]

theorem envBound44237 : H12AffineFastState.Bounded env44237 := by
  intro p hp
  have h : env44237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44236_44237 : H12AffineEnvironment.transform 2 3 env44236 = env44237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44236 == env44237) = true)

def env44238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590741,2098513,17664,2363592,2102684,6349853,257,21792,46212,2175563]

theorem envBound44238 : H12AffineFastState.Bounded env44238 := by
  intro p hp
  have h : env44238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44190_44238 : H12AffineEnvironment.transform 16 49305 env44190 = env44238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env44190 == env44238) = true)

def env44239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144661,2098513,17664,2363592,2102684,2411677,257,21792,46212,2175563]

theorem envBound44239 : H12AffineFastState.Bounded env44239 := by
  intro p hp
  have h : env44239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44238_44239 : H12AffineEnvironment.transform 21 272512 env44238 = env44239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44238 == env44239) = true)

theorem identity44239 : scanCanonicalize (H12AffineFastState.compose env44239 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound44239 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77898,272512,73754,98781,8328,64,100831,79131,17664,336002,75222,392407,257,21792,46212,513]

theorem envBound44240 : H12AffineFastState.Bounded env44240 := by
  intro p hp
  have h : env44240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44239_44240 : H12AffineEnvironment.transform 20 77898 env44239 = env44240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env44239 == env44240) = true)

def env44241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272392,73754,98645,8192,64,100695,79131,17664,335882,75102,392287,257,21792,46092,513]

theorem envBound44241 : H12AffineFastState.Bounded env44241 := by
  intro p hp
  have h : env44241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44240_44241 : H12AffineEnvironment.transform 6 8 env44240 = env44241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44240 == env44241) = true)

theorem identity44241 : scanCanonicalize (H12AffineFastState.compose env44241 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound44241 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,262144,1025,32769,36928,272392,32784,8543,8192,64,10589,38161,17664,294912,34132,285781,257,21792,46092,513]

theorem envBound44242 : H12AffineFastState.Bounded env44242 := by
  intro p hp
  have h : env44242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44241_44242 : H12AffineEnvironment.transform 15 40970 env44241 = env44242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env44241 == env44242) = true)

theorem identity44242 : scanCanonicalize (H12AffineFastState.compose env44242 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 63545) := by decide +kernel

theorem selectedBound44242 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,63545,1025,32769,36928,53297,32784,8543,8192,64,10589,38161,17664,30777,34132,42092,257,21792,46092,513]

theorem envBound44243 : H12AffineFastState.Bounded env44243 := by
  intro p hp
  have h : env44243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44242_44243 : H12AffineEnvironment.transform 17 63545 env44242 = env44243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63545 env44242 == env44243) = true)

theorem identity44243 : scanCanonicalize (H12AffineFastState.compose env44243 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound44243 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env44244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,9547,17744,32120,1025,1344,5377,21872,1361,8543,8192,64,10589,4176,17664,30777,21,8493,257,21792,12621,513]

theorem envBound44244 : H12AffineFastState.Bounded env44244 := by
  intro p hp
  have h : env44244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44243_44244 : H12AffineEnvironment.transform 14 1345 env44243 = env44244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env44243 == env44244) = true)

theorem identity44244 : scanCanonicalize (H12AffineFastState.compose env44244 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound44244 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env44245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,1345,9547,13624,3344,1025,1344,5377,9496,1361,8543,8192,64,10589,4176,13672,2129,21,8493,257,9544,12621,513]

theorem envBound44245 : H12AffineFastState.Bounded env44245 := by
  intro p hp
  have h : env44245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44244_44245 : H12AffineEnvironment.transform 13 12392 env44244 = env44245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env44244 == env44245) = true)

theorem identity44245 : scanCanonicalize (H12AffineFastState.compose env44245 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound44245 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,5236,1345,343,4388,3344,1025,1344,5377,260,1361,1347,1052,64,3393,4176,4468,2129,21,1329,257,340,5457,513]

theorem envBound44246 : H12AffineFastState.Bounded env44246 := by
  intro p hp
  have h : env44246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44245_44246 : H12AffineEnvironment.transform 12 1052 env44245 = env44246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env44245 == env44246) = true)

theorem identity44246 : scanCanonicalize (H12AffineFastState.compose env44246 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44246 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44247 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,5236,1076,34,4177,3173,1025,1077,5236,113,1060,1078,1052,64,3124,4176,4097,2129,21,1092,116,33,5156,513]

theorem envBound44247 : H12AffineFastState.Bounded env44247 := by
  intro p hp
  have h : env44247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44246_44247 : H12AffineEnvironment.transform 7 117 env44246 = env44247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44246 == env44247) = true)

theorem identity44247 : scanCanonicalize (H12AffineFastState.compose env44247 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound44247 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env44248 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,121,4113,81,34,4177,2048,100,80,4113,113,65,83,121,64,2129,4176,4097,2129,21,33,116,33,4161,513]

theorem envBound44248 : H12AffineFastState.Bounded env44248 := by
  intro p hp
  have h : env44248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44247_44248 : H12AffineEnvironment.transform 9 101 env44247 = env44248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env44247 == env44248) = true)

theorem identity44248 : scanCanonicalize (H12AffineFastState.compose env44248 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44248 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44249 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,1,34,4097,2048,52,0,4113,33,17,3,41,16,2049,4096,4097,2049,21,33,36,33,4113,513]

theorem envBound44249 : H12AffineFastState.Bounded env44249 := by
  intro p hp
  have h : env44249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44248_44249 : H12AffineEnvironment.transform 5 16 env44248 = env44249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44248 == env44249) = true)

theorem identity44249 : scanCanonicalize (H12AffineFastState.compose env44249 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44250 : List Nat := [2,4,8,16,32,16,8,37,17,53,2048,4096,41,4113,1,34,4097,2048,52,0,4113,33,17,3,41,16,2049,4096,4097,2049,21,33,36,33,4113,16]

theorem envBound44250 : H12AffineFastState.Bounded env44250 := by
  intro p hp
  have h : env44250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44249_44250 : H12AffineEnvironment.transform 8 17 env44249 = env44250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44249 == env44250) = true)

theorem identity44250 : scanCanonicalize (H12AffineFastState.compose env44250 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound44250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44251 : List Nat := [2,4,8,16,32,16,8,37,17,53,2048,2059,41,2074,1,34,2058,2048,52,0,2074,33,17,3,41,16,2049,2059,2058,2049,21,33,36,33,2074,16]

theorem envBound44251 : H12AffineFastState.Bounded env44251 := by
  intro p hp
  have h : env44251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44250_44251 : H12AffineEnvironment.transform 11 2059 env44250 = env44251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env44250 == env44251) = true)

theorem identity44251 : scanCanonicalize (H12AffineFastState.compose env44251 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound44251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44252 : List Nat := [2,4,8,16,32,16,8,37,17,53,58,49,41,32,1,34,48,58,52,0,32,33,17,3,41,16,59,49,48,59,21,33,36,33,32,16]

theorem envBound44252 : H12AffineFastState.Bounded env44252 := by
  intro p hp
  have h : env44252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44251_44252 : H12AffineEnvironment.transform 10 58 env44251 = env44252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env44251 == env44252) = true)

theorem identity44252 : scanCanonicalize (H12AffineFastState.compose env44252 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44252 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44253 : List Nat := [2,4,8,16,10,16,8,15,17,31,16,27,3,10,1,8,26,16,30,0,10,11,17,3,3,16,17,27,26,17,21,11,14,11,10,16]

theorem envBound44253 : H12AffineFastState.Bounded env44253 := by
  intro p hp
  have h : env44253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44252_44253 : H12AffineEnvironment.transform 4 10 env44252 = env44253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44252 == env44253) = true)

theorem identity44253 : scanCanonicalize (H12AffineFastState.compose env44253 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44253 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env44254 : List Nat := [2,4,8,1,10,1,8,15,0,14,1,10,3,10,1,8,11,1,15,0,10,11,0,3,3,1,0,10,11,0,4,11,14,11,10,1]

theorem envBound44254 : H12AffineFastState.Bounded env44254 := by
  intro p hp
  have h : env44254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44253_44254 : H12AffineEnvironment.transform 3 1 env44253 = env44254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44253 == env44254) = true)

theorem identity44254 : scanCanonicalize (H12AffineFastState.compose env44254 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44254 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env44255 : List Nat := [2,4,2,1,0,1,2,5,0,4,1,0,3,0,1,2,1,1,5,0,0,1,0,3,3,1,0,0,1,0,4,1,4,1,0,1]

theorem envBound44255 : H12AffineFastState.Bounded env44255 := by
  intro p hp
  have h : env44255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44254_44255 : H12AffineEnvironment.transform 2 2 env44254 = env44255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44254 == env44255) = true)

def env44256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272393,73754,98644,8193,64,100694,79131,17664,335883,75103,392286,257,21792,46093,513]

theorem envBound44256 : H12AffineFastState.Bounded env44256 := by
  intro p hp
  have h : env44256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44240_44256 : H12AffineEnvironment.transform 6 9 env44240 = env44256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44240 == env44256) = true)

theorem identity44256 : scanCanonicalize (H12AffineFastState.compose env44256 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound44256 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,77898,41340,73754,98644,8193,64,100694,79131,17664,108926,75103,95531,257,21792,46093,513]

theorem envBound44257 : H12AffineFastState.Bounded env44257 := by
  intro p hp
  have h : env44257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44256_44257 : H12AffineEnvironment.transform 17 35189 env44256 = env44257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env44256 == env44257) = true)

theorem identity44257 : scanCanonicalize (H12AffineFastState.compose env44257 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound44257 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env44258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,49168,35189,1025,32769,45340,41340,41292,2,8193,64,2048,46157,17664,10280,41993,62589,257,21792,46093,513]

theorem envBound44258 : H12AffineFastState.Bounded env44258 := by
  intro p hp
  have h : env44258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44257_44258 : H12AffineEnvironment.transform 15 33110 env44257 = env44258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env44257 == env44258) = true)

theorem identity44258 : scanCanonicalize (H12AffineFastState.compose env44258 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44258 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33110,49168,35189,1025,32769,36929,32801,32785,2,348,64,2048,38160,17664,2421,34132,54560,257,21792,38224,513]

theorem envBound44259 : H12AffineFastState.Bounded env44259 := by
  intro p hp
  have h : env44259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44258_44259 : H12AffineEnvironment.transform 12 349 env44258 = env44259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44258 == env44259) = true)

theorem identity44259 : scanCanonicalize (H12AffineFastState.compose env44259 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44259 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env44260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,343,16401,2420,1025,0,4160,32,16,2,348,64,2048,5393,17664,2421,1365,21793,257,21792,5457,513]

theorem envBound44260 : H12AffineFastState.Bounded env44260 := by
  intro p hp
  have h : env44260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44259_44260 : H12AffineEnvironment.transform 14 1 env44259 = env44260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44259 == env44260) = true)

theorem identity44260 : scanCanonicalize (H12AffineFastState.compose env44260 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 6453) := by decide +kernel

theorem selectedBound44260 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,6453,1,343,6436,2420,1025,0,4160,32,16,2,348,64,2048,5393,7221,2421,1365,3092,257,3093,5457,513]

theorem envBound44261 : H12AffineFastState.Bounded env44261 := by
  intro p hp
  have h : env44261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44260_44261 : H12AffineEnvironment.transform 13 6453 env44260 = env44261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6453 env44260 == env44261) = true)

theorem identity44261 : scanCanonicalize (H12AffineFastState.compose env44261 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound44261 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env44262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,5156,1,343,5173,1125,1025,0,4160,32,16,2,348,64,1297,5393,4388,1124,1365,261,257,260,5457,513]

theorem envBound44262 : H12AffineFastState.Bounded env44262 := by
  intro p hp
  have h : env44262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44261_44262 : H12AffineEnvironment.transform 10 1297 env44261 = env44262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env44261 == env44262) = true)

theorem identity44262 : scanCanonicalize (H12AffineFastState.compose env44262 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound44262 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,356,349,1344,1,343,1361,1125,1025,0,292,32,16,2,348,64,1297,1141,64,1124,1365,261,257,260,1077,513]

theorem envBound44263 : H12AffineFastState.Bounded env44263 := by
  intro p hp
  have h : env44263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44262_44263 : H12AffineEnvironment.transform 11 356 env44262 = env44263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env44262 == env44263) = true)

theorem identity44263 : scanCanonicalize (H12AffineFastState.compose env44263 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound44263 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44264 : List Nat := [2,4,8,16,32,64,9,256,512,321,80,356,349,1,1,343,16,292,320,0,292,32,16,2,348,64,80,308,64,293,20,261,257,260,372,513]

theorem envBound44264 : H12AffineFastState.Bounded env44264 := by
  intro p hp
  have h : env44264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44263_44264 : H12AffineEnvironment.transform 9 321 env44263 = env44264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44263 == env44264) = true)

theorem identity44264 : scanCanonicalize (H12AffineFastState.compose env44264 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44264 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44265 : List Nat := [2,4,8,16,32,64,9,37,512,100,80,65,120,1,1,114,16,1,101,0,1,32,16,2,121,64,80,17,64,0,20,32,36,33,81,513]

theorem envBound44265 : H12AffineFastState.Bounded env44265 := by
  intro p hp
  have h : env44265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44264_44265 : H12AffineEnvironment.transform 7 37 env44264 = env44265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44264 == env44265) = true)

theorem identity44265 : scanCanonicalize (H12AffineFastState.compose env44265 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44265 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44266 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,1,1,35,16,1,52,0,1,32,16,2,40,17,1,17,17,0,20,32,36,33,0,513]

theorem envBound44266 : H12AffineFastState.Bounded env44266 := by
  intro p hp
  have h : env44266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44265_44266 : H12AffineEnvironment.transform 5 17 env44265 = env44266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44265 == env44266) = true)

theorem identity44266 : scanCanonicalize (H12AffineFastState.compose env44266 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44266 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44267 : List Nat := [2,4,8,16,32,17,9,37,0,53,1,16,41,1,1,35,16,1,52,0,1,32,16,2,40,17,1,17,17,0,20,32,36,33,0,1]

theorem envBound44267 : H12AffineFastState.Bounded env44267 := by
  intro p hp
  have h : env44267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44266_44267 : H12AffineEnvironment.transform 8 0 env44266 = env44267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44266 == env44267) = true)

theorem identity44267 : scanCanonicalize (H12AffineFastState.compose env44267 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44267 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44268 : List Nat := [2,4,3,16,32,17,2,37,0,53,1,16,34,1,1,35,16,1,52,0,1,32,16,2,35,17,1,17,17,0,20,32,36,33,0,1]

theorem envBound44268 : H12AffineFastState.Bounded env44268 := by
  intro p hp
  have h : env44268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44267_44268 : H12AffineEnvironment.transform 2 3 env44267 = env44268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44267 == env44268) = true)

def env44269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144660,2098513,17664,2363592,2102684,2411676,257,21792,46212,2175563]

theorem envBound44269 : H12AffineFastState.Bounded env44269 := by
  intro p hp
  have h : env44269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44238_44269 : H12AffineEnvironment.transform 21 272513 env44238 = env44269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44238 == env44269) = true)

theorem identity44269 : scanCanonicalize (H12AffineFastState.compose env44269 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44269 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272513,2101328,41430,8328,64,2144660,2098513,17664,2363592,2102684,2411676,257,21792,46212,2101824]

theorem envBound44270 : H12AffineFastState.Bounded env44270 := by
  intro p hp
  have h : env44270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44269_44270 : H12AffineEnvironment.transform 15 8203 env44269 = env44270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44269 == env44270) = true)

theorem identity44270 : scanCanonicalize (H12AffineFastState.compose env44270 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44270 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25029,262144,1025,8541,2097152,272513,2101328,138,8328,64,2103496,2098513,17664,2363592,2102684,2387392,257,21792,5592,2101824]

theorem envBound44271 : H12AffineFastState.Bounded env44271 := by
  intro p hp
  have h : env44271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44270_44271 : H12AffineEnvironment.transform 14 8540 env44270 = env44271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44270 == env44271) = true)

theorem identity44271 : scanCanonicalize (H12AffineFastState.compose env44271 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44271 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env44272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,262144,1025,8541,2097152,272392,2101328,3,8193,64,2103361,2098513,17664,2363457,2102549,2387273,257,21792,5457,2101824]

theorem envBound44272 : H12AffineFastState.Bounded env44272 := by
  intro p hp
  have h : env44272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44271_44272 : H12AffineEnvironment.transform 6 9 env44271 = env44272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44271 == env44272) = true)

theorem identity44272 : scanCanonicalize (H12AffineFastState.compose env44272 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound44272 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env44273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,23808,1025,8541,2097152,29960,2101328,3,8193,64,2103361,2098513,17664,2116929,2102549,2109513,257,21792,5457,2101824]

theorem envBound44273 : H12AffineFastState.Bounded env44273 := by
  intro p hp
  have h : env44273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44272_44273 : H12AffineEnvironment.transform 17 23808 env44272 = env44273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env44272 == env44273) = true)

theorem identity44273 : scanCanonicalize (H12AffineFastState.compose env44273 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound44273 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env44274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,23808,1025,8541,4404,29960,356,3,8193,64,2421,5221,17664,23669,1057,8573,257,21792,5457,884]

theorem envBound44274 : H12AffineFastState.Bounded env44274 := by
  intro p hp
  have h : env44274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44273_44274 : H12AffineEnvironment.transform 20 4404 env44273 = env44274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env44273 == env44274) = true)

theorem identity44274 : scanCanonicalize (H12AffineFastState.compose env44274 (packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound44274 : packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env44275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,8203,13624,2420,1025,8541,4404,8572,356,3,8193,64,2421,5221,4468,2049,1057,8573,257,340,5457,884]

theorem envBound44275 : H12AffineFastState.Bounded env44275 := by
  intro p hp
  have h : env44275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44274_44275 : H12AffineEnvironment.transform 13 5236 env44274 = env44275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env44274 == env44275) = true)

theorem identity44275 : scanCanonicalize (H12AffineFastState.compose env44275 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound44275 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2317,5236,2129,2310,7221,2420,1025,2128,4404,2161,356,3,2316,64,2421,5221,4468,2049,1057,2160,257,340,5457,884]

theorem envBound44276 : H12AffineFastState.Bounded env44276 := by
  intro p hp
  have h : env44276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44275_44276 : H12AffineEnvironment.transform 12 2317 env44275 = env44276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env44275 == env44276) = true)

theorem identity44276 : scanCanonicalize (H12AffineFastState.compose env44276 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound44276 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env44277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,4096,348,5236,0,343,5220,293,1025,1,4404,32,356,3,349,64,292,5221,4468,80,1057,33,257,340,5457,884]

theorem envBound44277 : H12AffineFastState.Bounded env44277 := by
  intro p hp
  have h : env44277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44276_44277 : H12AffineEnvironment.transform 10 81 env44276 = env44277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env44276 == env44277) = true)

theorem identity44277 : scanCanonicalize (H12AffineFastState.compose env44277 (packedSelected [0,2,3,5,6,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44277 : packedSelected [0,2,3,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env44278 : List Nat := [2,4,8,16,32,64,9,256,512,100,81,4096,348,4112,0,343,4096,293,101,1,4404,32,356,3,349,64,292,4097,4468,80,69,33,257,340,4405,884]

theorem envBound44278 : H12AffineFastState.Bounded env44278 := by
  intro p hp
  have h : env44278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44277_44278 : H12AffineEnvironment.transform 9 100 env44277 = env44278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44277 == env44278) = true)

theorem identity44278 : scanCanonicalize (H12AffineFastState.compose env44278 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44278 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env44279 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,4096,41,4112,0,34,4096,80,101,1,4161,32,17,3,40,64,81,4097,4097,80,69,33,116,33,4160,513]

theorem envBound44279 : H12AffineFastState.Bounded env44279 := by
  intro p hp
  have h : env44279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44278_44279 : H12AffineEnvironment.transform 7 117 env44278 = env44279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44278 == env44279) = true)

theorem identity44279 : scanCanonicalize (H12AffineFastState.compose env44279 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44280 : List Nat := [2,4,8,16,32,64,9,117,17,100,81,4096,41,4112,0,34,4096,80,101,1,4161,32,17,3,40,64,81,4097,4097,80,69,33,116,33,4160,16]

theorem envBound44280 : H12AffineFastState.Bounded env44280 := by
  intro p hp
  have h : env44280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44279_44280 : H12AffineEnvironment.transform 8 17 env44279 = env44280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44279 == env44280) = true)

theorem identity44280 : scanCanonicalize (H12AffineFastState.compose env44280 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound44280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44281 : List Nat := [2,4,8,16,32,64,9,117,17,100,81,17,41,1,0,34,17,80,101,1,80,32,17,3,40,64,81,16,16,80,69,33,116,33,81,16]

theorem envBound44281 : H12AffineFastState.Bounded env44281 := by
  intro p hp
  have h : env44281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44280_44281 : H12AffineEnvironment.transform 11 17 env44280 = env44281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env44280 == env44281) = true)

theorem identity44281 : scanCanonicalize (H12AffineFastState.compose env44281 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound44281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44282 : List Nat := [2,4,8,16,32,33,9,20,17,5,48,17,41,1,0,34,17,49,4,1,49,32,17,3,40,33,48,16,16,49,36,33,21,33,48,16]

theorem envBound44282 : H12AffineFastState.Bounded env44282 := by
  intro p hp
  have h : env44282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44281_44282 : H12AffineEnvironment.transform 5 33 env44281 = env44282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env44281 == env44282) = true)

def env44283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound44283 : H12AffineFastState.Bounded env44283 := by
  intro p hp
  have h : env44283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43997_44283 : H12AffineEnvironment.transform 26 30393345 env43997 = env44283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env43997 == env44283) = true)

def env44284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound44284 : H12AffineFastState.Bounded env44284 := by
  intro p hp
  have h : env44284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44283_44284 : H12AffineEnvironment.transform 18 1024 env44283 = env44284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env44283 == env44284) = true)

theorem identity44284 : scanCanonicalize (H12AffineFastState.compose env44284 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601477) := by decide +kernel

theorem selectedBound44284 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601477,8328,64,6685700,8405128,10507600,8830977,2113556,12624324,256,168,57612,2189250]

theorem envBound44285 : H12AffineFastState.Bounded env44285 := by
  intro p hp
  have h : env44285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44284_44285 : H12AffineEnvironment.transform 23 10601477 env44284 = env44285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601477 env44284 == env44285) = true)

def env44286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685700,8393984,10485976,8820105,2102684,12624324,256,168,46212,2175562]

theorem envBound44286 : H12AffineFastState.Bounded env44286 := by
  intro p hp
  have h : env44286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44285_44286 : H12AffineEnvironment.transform 13 5512 env44285 = env44286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env44285 == env44286) = true)

def env44287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685700,2098648,4096,2524497,2102684,6336796,256,168,46212,2175562]

theorem envBound44287 : H12AffineFastState.Bounded env44287 := by
  intro p hp
  have h : env44287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44286_44287 : H12AffineEnvironment.transform 22 2101464 env44286 = env44287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env44286 == env44287) = true)

def env44288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491428,2098648,4096,2524497,2102684,2142524,256,168,46212,2175562]

theorem envBound44288 : H12AffineFastState.Bounded env44288 := by
  intro p hp
  have h : env44288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44287_44288 : H12AffineEnvironment.transform 21 32 env44287 = env44288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44287 == env44288) = true)

def env44289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98645,8192,64,2491428,2098512,4096,2524497,2102548,2142524,256,32,46092,2175562]

theorem envBound44289 : H12AffineFastState.Bounded env44289 := by
  intro p hp
  have h : env44289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44288_44289 : H12AffineEnvironment.transform 6 8 env44288 = env44289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44288 == env44289) = true)

def env44290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398436,5392,4096,431377,1364,41340,256,32,46092,74250]

theorem envBound44290 : H12AffineFastState.Bounded env44290 := by
  intro p hp
  have h : env44290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44289_44290 : H12AffineEnvironment.transform 20 4160 env44289 = env44290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44289 == env44290) = true)

theorem identity44290 : scanCanonicalize (H12AffineFastState.compose env44290 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44290 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,32,16,73737,8192,64,398436,5392,4096,406605,1364,32,256,32,5456,74250]

theorem envBound44291 : H12AffineFastState.Bounded env44291 := by
  intro p hp
  have h : env44291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44290_44291 : H12AffineEnvironment.transform 14 8540 env44290 = env44291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44290 == env44291) = true)

theorem identity44291 : scanCanonicalize (H12AffineFastState.compose env44291 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67698) := by decide +kernel

theorem selectedBound44291 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67698,1024,8541,4160,32,16,73737,8192,64,203798,5392,4096,212031,1364,32,256,32,5456,74250]

theorem envBound44292 : H12AffineFastState.Bounded env44292 := by
  intro p hp
  have h : env44292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44291_44292 : H12AffineEnvironment.transform 17 67698 env44291 = env44292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67698 env44291 == env44292) = true)

theorem identity44292 : scanCanonicalize (H12AffineFastState.compose env44292 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound44292 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env44293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,5221,67698,1024,8541,4160,32,16,73737,8192,64,67699,5392,4096,75866,1364,32,256,32,5456,74250]

theorem envBound44293 : H12AffineFastState.Bounded env44293 := by
  intro p hp
  have h : env44293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44292_44293 : H12AffineEnvironment.transform 16 5221 env44292 = env44293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env44292 == env44293) = true)

theorem identity44293 : scanCanonicalize (H12AffineFastState.compose env44293 (packedSelected [4,11,12,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 10622) := by decide +kernel

theorem selectedBound44293 : packedSelected [4,11,12,15,20,22] rootPS < 2^1333 := by decide +kernel

def env44294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,10622,5221,8460,1024,8541,4160,32,16,2423,8192,64,8461,5392,4096,292,1364,32,256,32,5456,2932]

theorem envBound44294 : H12AffineFastState.Bounded env44294 := by
  intro p hp
  have h : env44294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44293_44294 : H12AffineEnvironment.transform 15 10622 env44293 = env44294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10622 env44293 == env44294) = true)

theorem identity44294 : scanCanonicalize (H12AffineFastState.compose env44294 (packedSelected [0,4,9,11,12,15,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44294 : packedSelected [0,4,9,11,12,15,20,27] rootPS < 2^1333 := by decide +kernel

def env44295 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,10542,5173,8460,1024,8461,4112,32,16,2343,8192,16,8461,5392,4096,292,1284,32,256,32,5376,2852]

theorem envBound44295 : H12AffineFastState.Bounded env44295 := by
  intro p hp
  have h : env44295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44294_44295 : H12AffineEnvironment.transform 5 16 env44294 = env44295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44294 == env44295) = true)

theorem identity44295 : scanCanonicalize (H12AffineFastState.compose env44295 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound44295 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env44296 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,2088,5376,2340,262,5173,2340,1024,2341,4112,32,16,2343,2088,16,2341,5392,4096,292,1284,32,256,32,5376,2852]

theorem envBound44296 : H12AffineFastState.Bounded env44296 := by
  intro p hp
  have h : env44296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44295_44296 : H12AffineEnvironment.transform 12 2088 env44295 = env44296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env44295 == env44296) = true)

theorem identity44296 : scanCanonicalize (H12AffineFastState.compose env44296 (packedSelected [0,2,6,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound44296 : packedSelected [0,2,6,9,10] rootPS < 2^1333 := by decide +kernel

def env44297 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,2088,0,2340,262,309,2340,1024,2341,1296,32,16,2343,2088,16,2341,16,1280,292,1284,32,256,32,0,2852]

theorem envBound44297 : H12AffineFastState.Bounded env44297 := by
  intro p hp
  have h : env44297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44296_44297 : H12AffineEnvironment.transform 11 1280 env44296 = env44297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env44296 == env44297) = true)

theorem identity44297 : scanCanonicalize (H12AffineFastState.compose env44297 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44297 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env44298 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1061,2088,0,2049,35,16,2049,1024,2048,1077,32,16,2050,2088,16,2048,16,1061,1,1057,32,37,32,0,2561]

theorem envBound44298 : H12AffineFastState.Bounded env44298 := by
  intro p hp
  have h : env44298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44297_44298 : H12AffineEnvironment.transform 7 37 env44297 = env44298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44297 == env44298) = true)

theorem identity44298 : scanCanonicalize (H12AffineFastState.compose env44298 (packedSelected [2,3,5,14] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44298 : packedSelected [2,3,5,14] rootPS < 2^1333 := by decide +kernel

def env44299 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,1061,40,0,1,35,16,1,1024,0,1077,32,16,2,40,16,0,16,1061,1,1057,32,37,32,0,513]

theorem envBound44299 : H12AffineFastState.Bounded env44299 := by
  intro p hp
  have h : env44299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44298_44299 : H12AffineEnvironment.transform 10 0 env44298 = env44299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44298 == env44299) = true)

theorem identity44299 : scanCanonicalize (H12AffineFastState.compose env44299 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound44299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44300 : List Nat := [2,4,8,16,32,16,8,37,512,36,0,1,40,0,1,35,16,1,36,0,17,32,16,2,40,16,0,16,1,1,5,32,37,32,0,513]

theorem envBound44300 : H12AffineFastState.Bounded env44300 := by
  intro p hp
  have h : env44300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44299_44300 : H12AffineEnvironment.transform 9 36 env44299 = env44300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env44299 == env44300) = true)

theorem identity44300 : scanCanonicalize (H12AffineFastState.compose env44300 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44301 : List Nat := [2,4,8,16,32,16,8,37,1,36,0,1,40,0,1,35,16,1,36,0,17,32,16,2,40,16,0,16,1,1,5,32,37,32,0,0]

theorem envBound44301 : H12AffineFastState.Bounded env44301 := by
  intro p hp
  have h : env44301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44300_44301 : H12AffineEnvironment.transform 8 1 env44300 = env44301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44300 == env44301) = true)

def env44302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398437,5393,4096,431376,1365,41341,256,32,46092,74251]

theorem envBound44302 : H12AffineFastState.Bounded env44302 := by
  intro p hp
  have h : env44302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44289_44302 : H12AffineEnvironment.transform 20 4161 env44289 = env44302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44289 == env44302) = true)

theorem identity44302 : scanCanonicalize (H12AffineFastState.compose env44302 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound44302 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1024,32769,4161,32,17,98645,8192,64,171280,5393,4096,138341,1365,41341,256,32,46092,74251]

theorem envBound44303 : H12AffineFastState.Bounded env44303 := by
  intro p hp
  have h : env44303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44302_44303 : H12AffineEnvironment.transform 17 35189 env44302 = env44303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env44302 == env44303) = true)

theorem identity44303 : scanCanonicalize (H12AffineFastState.compose env44303 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44303 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,65536,131072,2420,1024,0,4161,32,17,65876,8192,64,138513,5393,4096,138341,1365,8572,256,32,13325,74251]

theorem envBound44304 : H12AffineFastState.Bounded env44304 := by
  intro p hp
  have h : env44304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44303_44304 : H12AffineEnvironment.transform 14 1 env44303 = env44304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44303 == env44304) = true)

theorem identity44304 : scanCanonicalize (H12AffineFastState.compose env44304 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound44304 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env44305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,65536,5393,2420,1024,0,4161,32,17,65876,8192,64,2048,5393,4096,2420,1365,8572,256,32,13325,74251]

theorem envBound44305 : H12AffineFastState.Bounded env44305 := by
  intro p hp
  have h : env44305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44304_44305 : H12AffineEnvironment.transform 16 5393 env44304 = env44305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env44304 == env44305) = true)

theorem identity44305 : scanCanonicalize (H12AffineFastState.compose env44305 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44305 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,8202,5393,2420,1024,0,4161,32,17,8542,8192,64,2048,5393,4096,2420,1365,8572,256,32,13325,513]

theorem envBound44306 : H12AffineFastState.Bounded env44306 := by
  intro p hp
  have h : env44306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44305_44306 : H12AffineEnvironment.transform 15 8202 env44305 = env44306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44305 == env44306) = true)

theorem identity44306 : scanCanonicalize (H12AffineFastState.compose env44306 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound44306 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44307 : List Nat := [2,4,8,16,32,64,8,256,512,613,2048,4096,8192,4965,1,8202,4980,2420,613,0,4161,32,17,8542,8192,64,2048,4980,4096,2420,816,8572,256,32,12904,513]

theorem envBound44307 : H12AffineFastState.Bounded env44307 := by
  intro p hp
  have h : env44307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44306_44307 : H12AffineEnvironment.transform 9 613 env44306 = env44307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env44306 == env44307) = true)

def env44308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101329,98645,8193,64,2491428,2098513,4096,2524497,2102549,2142524,256,33,46093,2175562]

theorem envBound44308 : H12AffineFastState.Bounded env44308 := by
  intro p hp
  have h : env44308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44288_44308 : H12AffineEnvironment.transform 6 9 env44288 = env44308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44288 == env44308) = true)

def env44309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398436,5393,4096,431377,1365,41340,256,33,46093,74250]

theorem envBound44309 : H12AffineFastState.Bounded env44309 := by
  intro p hp
  have h : env44309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44308_44309 : H12AffineEnvironment.transform 20 4160 env44308 = env44309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44308 == env44309) = true)

theorem identity44309 : scanCanonicalize (H12AffineFastState.compose env44309 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,4160,32,17,98645,8193,64,146508,5393,4096,179513,1365,41340,256,33,46093,74250]

theorem envBound44310 : H12AffineFastState.Bounded env44310 := by
  intro p hp
  have h : env44310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44309_44310 : H12AffineEnvironment.transform 17 10280 env44309 = env44310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44309 == env44310) = true)

def env44311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98645,8193,64,398437,5392,4096,431376,1364,41341,256,33,46093,74251]

theorem envBound44311 : H12AffineFastState.Bounded env44311 := by
  intro p hp
  have h : env44311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44308_44311 : H12AffineEnvironment.transform 20 4161 env44308 = env44311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44308 == env44311) = true)

theorem identity44311 : scanCanonicalize (H12AffineFastState.compose env44311 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44311 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env44312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398437,5392,4096,431376,1364,41341,256,33,46093,513]

theorem envBound44312 : H12AffineFastState.Bounded env44312 := by
  intro p hp
  have h : env44312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44311_44312 : H12AffineEnvironment.transform 15 8202 env44311 = env44312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44311 == env44312) = true)

theorem identity44312 : scanCanonicalize (H12AffineFastState.compose env44312 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44312 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398437,5392,4096,406604,1364,33,256,33,5457,513]

theorem envBound44313 : H12AffineFastState.Bounded env44313 := by
  intro p hp
  have h : env44313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44312_44313 : H12AffineEnvironment.transform 14 8540 env44312 = env44313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44312 == env44313) = true)

theorem identity44313 : scanCanonicalize (H12AffineFastState.compose env44313 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44313 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44314 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,32,16,3,8193,16,398389,5392,4096,406556,1284,33,256,33,5377,513]

theorem envBound44314 : H12AffineFastState.Bounded env44314 := by
  intro p hp
  have h : env44314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44313_44314 : H12AffineEnvironment.transform 5 16 env44313 = env44314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44313 == env44314) = true)

theorem identity44314 : scanCanonicalize (H12AffineFastState.compose env44314 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44314 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1024,8461,4113,32,16,3,8193,16,146460,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound44315 : H12AffineFastState.Bounded env44315 := by
  intro p hp
  have h : env44315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44314_44315 : H12AffineEnvironment.transform 17 10281 env44314 = env44315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44314 == env44315) = true)

theorem identity44315 : scanCanonicalize (H12AffineFastState.compose env44315 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44315 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44316 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,131072,2341,1024,1,4113,32,16,3,269,16,138512,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound44316 : H12AffineFastState.Bounded env44316 := by
  intro p hp
  have h : env44316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44315_44316 : H12AffineEnvironment.transform 12 268 env44315 = env44316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44315 == env44316) = true)

theorem identity44316 : scanCanonicalize (H12AffineFastState.compose env44316 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound44316 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44317 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,4097,2341,1024,1,4113,32,16,3,269,16,3345,5392,4096,3124,1284,33,256,33,5377,513]

theorem envBound44317 : H12AffineFastState.Bounded env44317 := by
  intro p hp
  have h : env44317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44316_44317 : H12AffineEnvironment.transform 16 4097 env44316 = env44317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env44316 == env44317) = true)

theorem identity44317 : scanCanonicalize (H12AffineFastState.compose env44317 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44317 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env44318 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,268,4112,0,262,4097,2341,273,1,4113,32,16,3,269,16,2048,4097,4096,2341,21,33,256,33,4112,513]

theorem envBound44318 : H12AffineFastState.Bounded env44318 := by
  intro p hp
  have h : env44318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44317_44318 : H12AffineEnvironment.transform 9 273 env44317 = env44318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44317 == env44318) = true)

theorem identity44318 : scanCanonicalize (H12AffineFastState.compose env44318 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44318 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44319 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,41,4112,0,35,4097,2048,52,1,4113,32,16,3,40,16,2048,4097,4096,2048,21,33,37,33,4112,513]

theorem envBound44319 : H12AffineFastState.Bounded env44319 := by
  intro p hp
  have h : env44319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44318_44319 : H12AffineEnvironment.transform 7 37 env44318 = env44319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44318 == env44319) = true)

theorem identity44319 : scanCanonicalize (H12AffineFastState.compose env44319 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound44319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44320 : List Nat := [2,4,8,16,32,16,9,37,512,52,512,4096,41,4112,0,35,4097,512,52,1,4113,32,16,3,40,16,512,4097,4096,512,21,33,37,33,4112,513]

theorem envBound44320 : H12AffineFastState.Bounded env44320 := by
  intro p hp
  have h : env44320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44319_44320 : H12AffineEnvironment.transform 10 512 env44319 = env44320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env44319 == env44320) = true)

theorem identity44320 : scanCanonicalize (H12AffineFastState.compose env44320 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound44320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44321 : List Nat := [2,4,8,16,32,16,9,37,512,52,512,555,41,571,0,35,554,512,52,1,570,32,16,3,40,16,512,554,555,512,21,33,37,33,571,513]

theorem envBound44321 : H12AffineFastState.Bounded env44321 := by
  intro p hp
  have h : env44321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44320_44321 : H12AffineEnvironment.transform 11 555 env44320 = env44321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env44320 == env44321) = true)

def env44322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491429,2098648,4096,2524497,2102684,2142525,256,168,46212,2175562]

theorem envBound44322 : H12AffineFastState.Bounded env44322 := by
  intro p hp
  have h : env44322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44287_44322 : H12AffineEnvironment.transform 21 33 env44287 = env44322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44287 == env44322) = true)

theorem identity44322 : scanCanonicalize (H12AffineFastState.compose env44322 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound44322 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,33,16,98645,8328,64,398573,5392,4096,431513,1364,41461,256,168,46212,74370]

theorem envBound44323 : H12AffineFastState.Bounded env44323 := by
  intro p hp
  have h : env44323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44322_44323 : H12AffineEnvironment.transform 20 4296 env44322 = env44323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env44322 == env44323) = true)

def env44324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398437,5392,4096,431377,1364,41341,256,32,46092,74250]

theorem envBound44324 : H12AffineFastState.Bounded env44324 := by
  intro p hp
  have h : env44324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44323_44324 : H12AffineEnvironment.transform 6 8 env44323 = env44324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44323 == env44324) = true)

theorem identity44324 : scanCanonicalize (H12AffineFastState.compose env44324 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44324 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,33,16,73737,8192,64,398437,5392,4096,406605,1364,33,256,32,5456,74250]

theorem envBound44325 : H12AffineFastState.Bounded env44325 := by
  intro p hp
  have h : env44325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44324_44325 : H12AffineEnvironment.transform 14 8540 env44324 = env44325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44324 == env44325) = true)

theorem identity44325 : scanCanonicalize (H12AffineFastState.compose env44325 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212030) := by decide +kernel

theorem selectedBound44325 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,212030,1024,8541,4160,33,16,73737,8192,64,75867,5392,4096,67699,1364,33,256,32,5456,74250]

theorem envBound44326 : H12AffineFastState.Bounded env44326 := by
  intro p hp
  have h : env44326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44325_44326 : H12AffineEnvironment.transform 17 212030 env44325 = env44326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212030 env44325 == env44326) = true)

theorem identity44326 : scanCanonicalize (H12AffineFastState.compose env44326 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound44326 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env44327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,70963,10509,1024,8541,4160,33,16,73737,8192,64,75867,5392,4096,67699,1364,33,256,32,5456,74250]

theorem envBound44327 : H12AffineFastState.Bounded env44327 := by
  intro p hp
  have h : env44327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44326_44327 : H12AffineEnvironment.transform 16 70963 env44326 = env44327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env44326 == env44327) = true)

theorem identity44327 : scanCanonicalize (H12AffineFastState.compose env44327 (packedSelected [1,2,3,4,5,6,8,9,10,14,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 9547) := by decide +kernel

theorem selectedBound44327 : packedSelected [1,2,3,4,5,6,8,9,10,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env44328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9547,12408,10509,1024,8541,4160,33,16,1346,8192,64,3344,5392,4096,11576,1364,33,256,32,5456,1857]

theorem envBound44328 : H12AffineFastState.Bounded env44328 := by
  intro p hp
  have h : env44328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44327_44328 : H12AffineEnvironment.transform 15 9547 env44327 = env44328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9547 env44327 == env44328) = true)

def env44329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98645,8193,64,398436,5392,4096,431376,1364,41340,256,33,46093,74251]

theorem envBound44329 : H12AffineFastState.Bounded env44329 := by
  intro p hp
  have h : env44329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44323_44329 : H12AffineEnvironment.transform 6 9 env44323 = env44329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44323 == env44329) = true)

theorem identity44329 : scanCanonicalize (H12AffineFastState.compose env44329 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44329 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env44330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398436,5392,4096,431376,1364,41340,256,33,46093,513]

theorem envBound44330 : H12AffineFastState.Bounded env44330 := by
  intro p hp
  have h : env44330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44329_44330 : H12AffineEnvironment.transform 15 8202 env44329 = env44330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44329 == env44330) = true)

theorem identity44330 : scanCanonicalize (H12AffineFastState.compose env44330 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44330 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398436,5392,4096,406604,1364,32,256,33,5457,513]

theorem envBound44331 : H12AffineFastState.Bounded env44331 := by
  intro p hp
  have h : env44331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44330_44331 : H12AffineEnvironment.transform 14 8540 env44330 = env44331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44330 == env44331) = true)

theorem identity44331 : scanCanonicalize (H12AffineFastState.compose env44331 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0