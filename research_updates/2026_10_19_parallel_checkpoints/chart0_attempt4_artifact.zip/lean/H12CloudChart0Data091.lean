import H12CloudChart0Data090

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound23007 : H12AffineFastState.Bounded env23007 := by
  intro p hp
  have h : env23007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23006_23007 : H12AffineEnvironment.transform 14 8540 env23006 = env23007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23006 == env23007) = true)

theorem identity23007 : scanCanonicalize (H12AffineFastState.compose env23007 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound23007 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,8203,13673,10508,1024,8541,4160,260,17,3,8192,65,10588,5393,12408,2129,1365,8572,256,8281,5457,513]

theorem envBound23008 : H12AffineFastState.Bounded env23008 := by
  intro p hp
  have h : env23008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23007_23008 : H12AffineEnvironment.transform 13 13688 env23007 = env23008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env23007 == env23008) = true)

theorem identity23008 : scanCanonicalize (H12AffineFastState.compose env23008 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound23008 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23009 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12344,8540,8203,12329,10508,320,8541,4160,260,17,3,8192,65,10588,4177,12408,2129,21,8572,256,8281,4113,513]

theorem envBound23009 : H12AffineFastState.Bounded env23009 := by
  intro p hp
  have h : env23009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23008_23009 : H12AffineEnvironment.transform 9 320 env23008 = env23009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23008 == env23009) = true)

theorem identity23009 : scanCanonicalize (H12AffineFastState.compose env23009 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound23009 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23010 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,65,8192,8313,8540,8203,8296,10508,320,8541,1,260,17,3,8192,65,10588,16,8249,2129,21,8572,256,8281,80,513]

theorem envBound23010 : H12AffineFastState.Bounded env23010 := by
  intro p hp
  have h : env23010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23009_23010 : H12AffineEnvironment.transform 11 65 env23009 = env23010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env23009 == env23010) = true)

theorem identity23010 : scanCanonicalize (H12AffineFastState.compose env23010 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound23010 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env23011 : List Nat := [2,4,8,16,32,64,8,256,512,320,372,65,8192,8313,8540,8203,8296,8312,320,8541,1,260,17,3,8192,65,8232,16,8249,293,21,8572,256,8281,80,513]

theorem envBound23011 : H12AffineFastState.Bounded env23011 := by
  intro p hp
  have h : env23011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23010_23011 : H12AffineEnvironment.transform 10 372 env23010 = env23011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env23010 == env23011) = true)

theorem identity23011 : scanCanonicalize (H12AffineFastState.compose env23011 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23011 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23012 : List Nat := [2,4,8,16,32,64,8,116,512,52,0,65,8192,8313,8232,8203,8296,8312,52,8233,1,112,17,3,8192,65,8232,16,8249,81,21,8200,116,8281,80,513]

theorem envBound23012 : H12AffineFastState.Bounded env23012 := by
  intro p hp
  have h : env23012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23011_23012 : H12AffineEnvironment.transform 7 116 env23011 = env23012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23011 == env23012) = true)

theorem identity23012 : scanCanonicalize (H12AffineFastState.compose env23012 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23013 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,8192,8232,8232,8203,8249,8233,52,8233,1,33,17,3,8192,16,8232,16,8249,0,21,8200,37,8200,1,513]

theorem envBound23013 : H12AffineFastState.Bounded env23013 := by
  intro p hp
  have h : env23013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23012_23013 : H12AffineEnvironment.transform 5 17 env23012 = env23013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23012 == env23013) = true)

theorem identity23013 : scanCanonicalize (H12AffineFastState.compose env23013 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23013 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23014 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,1,34,16,0,52,0,1,33,17,3,41,16,1,16,16,0,21,33,37,33,1,513]

theorem envBound23014 : H12AffineFastState.Bounded env23014 := by
  intro p hp
  have h : env23014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23013_23014 : H12AffineEnvironment.transform 12 41 env23013 = env23014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23013 == env23014) = true)

theorem identity23014 : scanCanonicalize (H12AffineFastState.compose env23014 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound23014 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23015 : List Nat := [2,4,8,16,32,17,8,37,17,52,0,16,41,1,1,34,16,0,52,0,1,33,17,3,41,16,1,16,16,0,21,33,37,33,1,16]

theorem envBound23015 : H12AffineFastState.Bounded env23015 := by
  intro p hp
  have h : env23015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23014_23015 : H12AffineEnvironment.transform 8 17 env23014 = env23015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23014 == env23015) = true)

theorem identity23015 : scanCanonicalize (H12AffineFastState.compose env23015 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound23015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23016 : List Nat := [2,4,8,16,11,17,8,14,17,31,0,16,2,1,1,9,16,0,31,0,1,10,17,3,2,16,1,16,16,0,21,10,14,10,1,16]

theorem envBound23016 : H12AffineFastState.Bounded env23016 := by
  intro p hp
  have h : env23016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23015_23016 : H12AffineEnvironment.transform 4 11 env23015 = env23016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env23015 == env23016) = true)

def env23017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272393,441641,98645,8193,65,316533,436265,17664,32040,440428,156013,256,21793,46092,499506]

theorem envBound23017 : H12AffineFastState.Bounded env23017 := by
  intro p hp
  have h : env23017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23002_23017 : H12AffineEnvironment.transform 6 9 env23002 = env23017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23002 == env23017) = true)

theorem identity23017 : scanCanonicalize (H12AffineFastState.compose env23017 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23017 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env23018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322921,272393,326968,98645,8193,65,316533,321592,17664,32040,325757,8572,256,21793,46092,384803]

theorem envBound23018 : H12AffineFastState.Bounded env23018 := by
  intro p hp
  have h : env23018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23017_23018 : H12AffineEnvironment.transform 16 16401 env23017 = env23018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23017 == env23018) = true)

def env23019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1024,21761,276585,272393,272440,87125,8193,65,262517,277816,17664,32040,273789,8572,256,21793,24844,330275]

theorem envBound23019 : H12AffineFastState.Bounded env23019 := by
  intro p hp
  have h : env23019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23018_23019 : H12AffineEnvironment.transform 14 21760 env23018 = env23019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env23018 == env23019) = true)

theorem identity23019 : scanCanonicalize (H12AffineFastState.compose env23019 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound23019 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,97407,1024,21761,82966,87158,87111,87125,8193,65,97546,82247,17664,32040,86274,8572,256,21793,24844,30300]

theorem envBound23020 : H12AffineFastState.Bounded env23020 := by
  intro p hp
  have h : env23020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23019_23020 : H12AffineEnvironment.transform 17 97407 env23019 = env23020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env23019 == env23020) = true)

theorem identity23020 : scanCanonicalize (H12AffineFastState.compose env23020 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23020 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env23021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16401,23668,1024,21761,25629,29821,29772,29790,8193,65,23809,24908,17664,32040,28937,8572,256,21793,24844,30300]

theorem envBound23021 : H12AffineFastState.Bounded env23021 := by
  intro p hp
  have h : env23021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23020_23021 : H12AffineEnvironment.transform 15 8203 env23020 = env23021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23020 == env23021) = true)

theorem identity23021 : scanCanonicalize (H12AffineFastState.compose env23021 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound23021 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,8203,13341,10360,1024,8461,4113,113,64,82,8193,65,10509,5440,12556,2340,1285,8572,256,8493,5376,592]

theorem envBound23022 : H12AffineFastState.Bounded env23022 := by
  intro p hp
  have h : env23022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23021_23022 : H12AffineEnvironment.transform 13 13324 env23021 = env23022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env23021 == env23022) = true)

theorem identity23022 : scanCanonicalize (H12AffineFastState.compose env23022 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound23022 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env23023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,8192,10360,8460,8203,10345,10360,1024,8461,3173,113,64,82,8193,65,10509,2356,11640,2340,1285,8572,256,8493,2420,592]

theorem envBound23023 : H12AffineFastState.Bounded env23023 := by
  intro p hp
  have h : env23023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23022_23023 : H12AffineEnvironment.transform 11 3188 env23022 = env23023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env23022 == env23023) = true)

theorem identity23023 : scanCanonicalize (H12AffineFastState.compose env23023 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound23023 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env23024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,8192,9577,8460,8203,9592,9577,1024,8461,372,113,64,82,8193,65,9244,1061,8297,1077,1285,8572,256,8493,1125,592]

theorem envBound23024 : H12AffineFastState.Bounded env23024 := by
  intro p hp
  have h : env23024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23023_23024 : H12AffineEnvironment.transform 10 1297 env23023 = env23024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env23023 == env23024) = true)

theorem identity23024 : scanCanonicalize (H12AffineFastState.compose env23024 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound23024 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env23025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,1385,0,1125,1378,17,0,1024,1124,372,113,64,82,1384,65,373,1061,1280,1077,1285,1045,256,1092,1125,592]

theorem envBound23025 : H12AffineFastState.Bounded env23025 := by
  intro p hp
  have h : env23025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23024_23025 : H12AffineEnvironment.transform 12 1385 env23024 = env23025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env23024 == env23025) = true)

theorem identity23025 : scanCanonicalize (H12AffineFastState.compose env23025 (packedSelected [7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23025 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env23026 : List Nat := [2,4,8,16,32,64,9,256,512,52,293,357,349,0,81,342,17,0,52,80,372,113,64,82,348,65,373,17,308,1,305,33,256,112,81,592]

theorem envBound23026 : H12AffineFastState.Bounded env23026 := by
  intro p hp
  have h : env23026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23025_23026 : H12AffineEnvironment.transform 9 52 env23025 = env23026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23025 == env23026) = true)

theorem identity23026 : scanCanonicalize (H12AffineFastState.compose env23026 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23026 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23027 : List Nat := [2,4,8,16,32,64,9,116,512,52,81,17,41,0,81,34,17,0,52,80,0,113,64,82,40,65,1,17,64,1,69,33,116,112,81,592]

theorem envBound23027 : H12AffineFastState.Bounded env23027 := by
  intro p hp
  have h : env23027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23026_23027 : H12AffineEnvironment.transform 7 116 env23026 = env23027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23026 == env23027) = true)

theorem identity23027 : scanCanonicalize (H12AffineFastState.compose env23027 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23027 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23028 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,41,0,1,34,17,0,52,0,0,33,16,2,40,17,1,17,16,1,21,33,36,32,1,512]

theorem envBound23028 : H12AffineFastState.Bounded env23028 := by
  intro p hp
  have h : env23028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23027_23028 : H12AffineEnvironment.transform 5 16 env23027 = env23028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23027 == env23028) = true)

theorem identity23028 : scanCanonicalize (H12AffineFastState.compose env23028 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound23028 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23029 : List Nat := [2,4,8,16,5,16,9,1,512,17,1,17,12,0,1,7,17,0,17,0,0,4,16,2,13,17,1,17,16,1,21,4,1,5,1,512]

theorem envBound23029 : H12AffineFastState.Bounded env23029 := by
  intro p hp
  have h : env23029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23028_23029 : H12AffineEnvironment.transform 4 5 env23028 = env23029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env23028 == env23029) = true)

theorem identity23029 : scanCanonicalize (H12AffineFastState.compose env23029 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound23029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23030 : List Nat := [2,4,8,16,5,16,9,1,13,17,1,17,12,0,1,7,17,0,17,0,0,4,16,2,13,17,1,17,16,1,21,4,1,5,1,13]

theorem envBound23030 : H12AffineFastState.Bounded env23030 := by
  intro p hp
  have h : env23030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23029_23030 : H12AffineEnvironment.transform 8 13 env23029 = env23030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env23029 == env23030) = true)

theorem identity23030 : scanCanonicalize (H12AffineFastState.compose env23030 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23030 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23031 : List Nat := [2,0,8,16,1,16,9,1,9,17,1,17,8,0,1,3,17,0,17,0,0,0,16,2,9,17,1,17,16,1,17,0,1,1,1,9]

theorem envBound23031 : H12AffineFastState.Bounded env23031 := by
  intro p hp
  have h : env23031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23030_23031 : H12AffineEnvironment.transform 1 0 env23030 = env23031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23030 == env23031) = true)

theorem identity23031 : scanCanonicalize (H12AffineFastState.compose env23031 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23031 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23032 : List Nat := [1,0,8,16,1,16,9,1,9,17,1,17,8,0,1,0,17,0,17,0,0,0,16,1,9,17,1,17,16,1,17,0,1,1,1,9]

theorem envBound23032 : H12AffineFastState.Bounded env23032 := by
  intro p hp
  have h : env23032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23031_23032 : H12AffineEnvironment.transform 0 1 env23031 = env23032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23031 == env23032) = true)

def env23033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1024,21760,276584,272393,272441,87124,8193,65,262516,277817,17664,32040,273788,8572,256,21793,24845,330274]

theorem envBound23033 : H12AffineFastState.Bounded env23033 := by
  intro p hp
  have h : env23033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23018_23033 : H12AffineEnvironment.transform 14 21761 env23018 = env23033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env23018 == env23033) = true)

theorem identity23033 : scanCanonicalize (H12AffineFastState.compose env23033 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound23033 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,16401,262144,1024,21760,276584,272393,272441,3,8193,65,262516,277817,17664,32040,273788,8572,256,21793,24845,286325]

theorem envBound23034 : H12AffineFastState.Bounded env23034 := by
  intro p hp
  have h : env23034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23033_23034 : H12AffineEnvironment.transform 15 21591 env23033 = env23034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env23033 == env23034) = true)

theorem identity23034 : scanCanonicalize (H12AffineFastState.compose env23034 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound23034 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,16401,32041,1024,21760,17729,21792,21776,3,8193,65,31837,16400,17664,32040,20565,8572,256,21793,24845,9052]

theorem envBound23035 : H12AffineFastState.Bounded env23035 := by
  intro p hp
  have h : env23035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23034_23035 : H12AffineEnvironment.transform 17 32041 env23034 = env23035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env23034 == env23035) = true)

theorem identity23035 : scanCanonicalize (H12AffineFastState.compose env23035 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23035 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env23036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,13389,2421,1024,8540,12573,8572,8524,3,8193,65,2049,13388,12636,2420,9225,8572,256,8573,5457,9052]

theorem envBound23036 : H12AffineFastState.Bounded env23036 := by
  intro p hp
  have h : env23036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23035_23036 : H12AffineEnvironment.transform 13 13404 env23035 = env23036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23035 == env23036) = true)

theorem identity23036 : scanCanonicalize (H12AffineFastState.compose env23036 (packedSelected [1,2,3,5,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23036 : packedSelected [1,2,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env23037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,81,263,5441,2421,1024,80,4113,112,64,3,269,65,2049,5440,4176,2420,1285,112,256,113,5457,592]

theorem envBound23037 : H12AffineFastState.Bounded env23037 := by
  intro p hp
  have h : env23037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23036_23037 : H12AffineEnvironment.transform 12 268 env23036 = env23037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23036 == env23037) = true)

theorem identity23037 : scanCanonicalize (H12AffineFastState.compose env23037 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23037 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23038 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4113,32,16,3,269,17,2049,5392,4096,2340,1285,32,256,33,5377,512]

theorem envBound23038 : H12AffineFastState.Bounded env23038 := by
  intro p hp
  have h : env23038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23037_23038 : H12AffineEnvironment.transform 5 16 env23037 = env23038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23037 == env23038) = true)

theorem identity23038 : scanCanonicalize (H12AffineFastState.compose env23038 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23038 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23039 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5376,1,263,5393,2308,1024,0,4113,1,16,3,269,17,2049,5392,4096,2309,1285,1,256,0,5377,512]

theorem envBound23039 : H12AffineFastState.Bounded env23039 := by
  intro p hp
  have h : env23039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23038_23039 : H12AffineEnvironment.transform 4 1 env23038 = env23039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23038 == env23039) = true)

theorem identity23039 : scanCanonicalize (H12AffineFastState.compose env23039 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound23039 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23040 : List Nat := [2,4,8,16,1,16,9,256,512,1024,523,4096,268,5376,1,263,5393,783,1024,0,4113,1,16,3,269,17,522,5392,4096,782,1285,1,256,0,5377,512]

theorem envBound23040 : H12AffineFastState.Bounded env23040 := by
  intro p hp
  have h : env23040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23039_23040 : H12AffineEnvironment.transform 10 523 env23039 = env23040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env23039 == env23040) = true)

theorem identity23040 : scanCanonicalize (H12AffineFastState.compose env23040 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23040 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23041 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,4096,8,5124,1,3,5141,523,1024,0,4113,1,16,3,9,17,522,5140,4096,522,1025,1,4,0,5125,512]

theorem envBound23041 : H12AffineFastState.Bounded env23041 := by
  intro p hp
  have h : env23041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23040_23041 : H12AffineEnvironment.transform 7 4 env23040 = env23041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23040 == env23041) = true)

def env23042 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,16,8,1044,1,3,1029,523,1024,0,1,1,16,3,9,17,522,1028,16,522,1025,1,4,0,1045,512]

theorem envBound23042 : H12AffineFastState.Bounded env23042 := by
  intro p hp
  have h : env23042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23041_23042 : H12AffineEnvironment.transform 11 16 env23041 = env23042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23041 == env23042) = true)

theorem identity23042 : scanCanonicalize (H12AffineFastState.compose env23042 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound23042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23043 : List Nat := [2,4,8,5,1,5,9,4,512,1024,523,5,8,1025,1,3,1029,523,1024,0,1,1,5,3,9,4,522,1028,5,522,1025,1,4,0,1024,512]

theorem envBound23043 : H12AffineFastState.Bounded env23043 := by
  intro p hp
  have h : env23043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23042_23043 : H12AffineEnvironment.transform 3 5 env23042 = env23043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env23042 == env23043) = true)

def env23044 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,5,8,1,1,3,5,523,0,0,1,1,5,3,9,4,522,4,5,522,1,1,4,0,0,512]

theorem envBound23044 : H12AffineFastState.Bounded env23044 := by
  intro p hp
  have h : env23044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23043_23044 : H12AffineEnvironment.transform 9 0 env23043 = env23044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env23043 == env23044) = true)

theorem identity23044 : scanCanonicalize (H12AffineFastState.compose env23044 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound23044 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23045 : List Nat := [2,4,8,5,1,5,9,4,9,0,2,5,8,1,1,3,5,2,0,0,1,1,5,3,9,4,3,4,5,3,1,1,4,0,0,9]

theorem envBound23045 : H12AffineFastState.Bounded env23045 := by
  intro p hp
  have h : env23045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23044_23045 : H12AffineEnvironment.transform 8 9 env23044 = env23045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env23044 == env23045) = true)

def leafEnv23045 : List Nat := [2,4,8,5,1,5,9,4,9,0,2,5,8,1,1,3,5,2,0,0,1,1,5,3,0,9,1,4,3,4,5,3,1,1,4,0,5,2,0,9,1,0,0]

def active23045 : List Nat := [0,1,2]

def tree23045 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23045 : H12WitnessSearch.Good tree23045 := H12GlobalWitnessIndex.good

theorem leafIdentity23045 : H12AffineFastState.composeSystem env23045 rootObs = leafEnv23045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23045 rootObs == leafEnv23045) = true)

theorem terminalChecked23045 : H12PackedTerminal.terminalCheckFast leafEnv23045 active23045 tree23045 = true := by decide +kernel

def env23046 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,5,8,0,1,3,4,523,1,0,1,1,5,3,9,4,522,5,5,522,0,1,4,0,1,512]

theorem envBound23046 : H12AffineFastState.Bounded env23046 := by
  intro p hp
  have h : env23046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23043_23046 : H12AffineEnvironment.transform 9 1 env23043 = env23046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env23043 == env23046) = true)

theorem identity23046 : scanCanonicalize (H12AffineFastState.compose env23046 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23047 : List Nat := [0,4,8,5,1,5,9,4,512,1,521,5,8,0,1,1,4,521,1,0,1,1,5,1,9,4,520,5,5,520,0,1,4,0,1,512]

theorem envBound23047 : H12AffineFastState.Bounded env23047 := by
  intro p hp
  have h : env23047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23046_23047 : H12AffineEnvironment.transform 0 0 env23046 = env23047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23046 == env23047) = true)

def leafEnv23047 : List Nat := [0,4,8,5,1,5,9,4,512,1,521,5,8,0,1,1,4,521,1,0,1,1,5,1,1,9,1,4,520,5,5,520,0,1,4,0,5,0,1,512,1,0,0]

def active23047 : List Nat := [1,2,8]

def tree23047 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23047 : H12WitnessSearch.Good tree23047 := H12GlobalWitnessIndex.good

theorem leafIdentity23047 : H12AffineFastState.composeSystem env23047 rootObs = leafEnv23047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23047 rootObs == leafEnv23047) = true)

theorem terminalChecked23047 : H12PackedTerminal.terminalCheckFast leafEnv23047 active23047 tree23047 = true := by decide +kernel

def env23048 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,17,8,1045,1,3,1028,523,1024,0,0,1,16,3,9,17,522,1029,17,522,1025,1,4,0,1044,512]

theorem envBound23048 : H12AffineFastState.Bounded env23048 := by
  intro p hp
  have h : env23048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23041_23048 : H12AffineEnvironment.transform 11 17 env23041 = env23048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23041 == env23048) = true)

theorem identity23048 : scanCanonicalize (H12AffineFastState.compose env23048 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound23048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23049 : List Nat := [2,4,8,16,1,16,9,4,512,0,523,17,8,21,1,3,4,523,0,0,0,1,16,3,9,17,522,5,17,522,1,1,4,0,20,512]

theorem envBound23049 : H12AffineFastState.Bounded env23049 := by
  intro p hp
  have h : env23049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23048_23049 : H12AffineEnvironment.transform 9 0 env23048 = env23049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env23048 == env23049) = true)

def env23050 : List Nat := [2,4,8,4,1,4,9,4,512,0,523,5,8,1,1,3,4,523,0,0,0,1,4,3,9,5,522,5,5,522,1,1,4,0,0,512]

theorem envBound23050 : H12AffineFastState.Bounded env23050 := by
  intro p hp
  have h : env23050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23049_23050 : H12AffineEnvironment.transform 3 4 env23049 = env23050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23049 == env23050) = true)

theorem identity23050 : scanCanonicalize (H12AffineFastState.compose env23050 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23051 : List Nat := [0,4,8,4,1,4,9,4,512,0,521,5,8,1,1,1,4,521,0,0,0,1,4,1,9,5,520,5,5,520,1,1,4,0,0,512]

theorem envBound23051 : H12AffineFastState.Bounded env23051 := by
  intro p hp
  have h : env23051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23050_23051 : H12AffineEnvironment.transform 0 0 env23050 = env23051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23050 == env23051) = true)

def leafEnv23051 : List Nat := [0,4,8,4,1,4,9,4,512,0,521,5,8,1,1,1,4,521,0,0,0,1,4,1,0,9,1,5,520,5,5,520,1,1,4,0,5,0,0,512,1,1,0]

def active23051 : List Nat := [1,2,8]

def tree23051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23051 : H12WitnessSearch.Good tree23051 := H12GlobalWitnessIndex.good

theorem leafIdentity23051 : H12AffineFastState.composeSystem env23051 rootObs = leafEnv23051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23051 rootObs == leafEnv23051) = true)

theorem terminalChecked23051 : H12PackedTerminal.terminalCheckFast leafEnv23051 active23051 tree23051 = true := by decide +kernel

def env23052 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,4,8,0,1,3,4,523,0,0,0,1,5,3,9,4,522,5,4,522,1,1,4,0,1,512]

theorem envBound23052 : H12AffineFastState.Bounded env23052 := by
  intro p hp
  have h : env23052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23049_23052 : H12AffineEnvironment.transform 3 5 env23049 = env23052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env23049 == env23052) = true)

theorem identity23052 : scanCanonicalize (H12AffineFastState.compose env23052 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound23052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23053 : List Nat := [2,4,8,5,1,5,9,4,8,0,3,4,8,0,1,3,4,3,0,0,0,1,5,3,9,4,2,5,4,2,1,1,4,0,1,8]

theorem envBound23053 : H12AffineFastState.Bounded env23053 := by
  intro p hp
  have h : env23053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23052_23053 : H12AffineEnvironment.transform 8 8 env23052 = env23053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env23052 == env23053) = true)

def leafEnv23053 : List Nat := [2,4,8,5,1,5,9,4,8,0,3,4,8,0,1,3,4,3,0,0,0,1,5,3,0,9,1,4,2,5,4,2,1,1,4,0,5,2,1,8,1,1,0]

def active23053 : List Nat := [0,1,2]

def tree23053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23053 : H12WitnessSearch.Good tree23053 := H12GlobalWitnessIndex.good

theorem leafIdentity23053 : H12AffineFastState.composeSystem env23053 rootObs = leafEnv23053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23053 rootObs == leafEnv23053) = true)

theorem terminalChecked23053 : H12PackedTerminal.terminalCheckFast leafEnv23053 active23053 tree23053 = true := by decide +kernel

def env23054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441760,98780,8328,65,316669,436384,17664,32161,440428,156012,256,21793,46213,499643]

theorem envBound23054 : H12AffineFastState.Bounded env23054 := by
  intro p hp
  have h : env23054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23001_23054 : H12AffineEnvironment.transform 21 272513 env23001 = env23054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23001 == env23054) = true)

theorem identity23054 : scanCanonicalize (H12AffineFastState.compose env23054 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound23054 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,169265,16,98780,8328,65,158029,5392,17664,32161,1500,156012,256,21793,46213,74251]

theorem envBound23055 : H12AffineFastState.Bounded env23055 := by
  intro p hp
  have h : env23055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23054_23055 : H12AffineEnvironment.transform 17 179632 env23054 = env23055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env23054 == env23055) = true)

theorem identity23055 : scanCanonicalize (H12AffineFastState.compose env23055 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23055 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4161,169265,16,41430,8328,65,158029,5392,17664,32161,1500,156012,256,21793,46213,513]

theorem envBound23056 : H12AffineFastState.Bounded env23056 := by
  intro p hp
  have h : env23056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23055_23056 : H12AffineEnvironment.transform 15 8202 env23055 = env23056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23055 == env23056) = true)

def env23057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441761,98781,8328,65,4258940,436385,17665,32160,440428,4606444,256,21793,46213,499643]

theorem envBound23057 : H12AffineFastState.Bounded env23057 := by
  intro p hp
  have h : env23057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23000_23057 : H12AffineEnvironment.transform 22 441761 env23000 = env23057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env23000 == env23057) = true)

def env23058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441761,98781,8328,65,316668,436385,17665,32160,440428,156012,256,21793,46213,499643]

theorem envBound23058 : H12AffineFastState.Bounded env23058 := by
  intro p hp
  have h : env23058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23057_23058 : H12AffineEnvironment.transform 21 272512 env23057 = env23058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23057 == env23058) = true)

theorem identity23058 : scanCanonicalize (H12AffineFastState.compose env23058 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23058 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416036,272512,412020,95496,8328,65,270377,416884,17665,32160,412857,156012,256,21793,16464,486254]

theorem envBound23059 : H12AffineFastState.Bounded env23059 := by
  intro p hp
  have h : env23059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23058_23059 : H12AffineEnvironment.transform 14 29909 env23058 = env23059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23058 == env23059) = true)

def env23060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,160132,32,156116,95496,8328,65,2185,160980,17665,32160,156697,156012,256,21793,16464,213966]

theorem envBound23060 : H12AffineFastState.Bounded env23060 := by
  intro p hp
  have h : env23060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23059_23060 : H12AffineEnvironment.transform 17 10400 env23059 = env23060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env23059 == env23060) = true)

theorem identity23060 : scanCanonicalize (H12AffineFastState.compose env23060 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound23060 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env23061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8233,65536,131072,10400,1024,8232,140664,32,144680,74228,8328,65,2185,139304,4605,10588,143589,144784,256,477,5292,202546]

theorem envBound23061 : H12AffineFastState.Bounded env23061 := by
  intro p hp
  have h : env23061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23060_23061 : H12AffineEnvironment.transform 13 5372 env23060 = env23061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env23060 == env23061) = true)

theorem identity23061 : scanCanonicalize (H12AffineFastState.compose env23061 (packedSelected [3,7,10,11,16,18,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 70962) := by decide +kernel

theorem selectedBound23061 : packedSelected [3,7,10,11,16,18,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env23062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8233,65536,70962,10400,1024,8232,77898,32,73754,74228,8328,65,2185,79130,4605,10588,75223,73890,256,477,5292,512]

theorem envBound23062 : H12AffineFastState.Bounded env23062 := by
  intro p hp
  have h : env23062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23061_23062 : H12AffineEnvironment.transform 16 70962 env23061 = env23062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70962 env23061 == env23062) = true)

theorem identity23062 : scanCanonicalize (H12AffineFastState.compose env23062 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23062 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env23063 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,5341,8200,65536,70931,10369,1024,8201,77898,1,73754,74197,8328,65,2185,79130,4572,10588,75223,73859,256,477,5261,512]

theorem envBound23063 : H12AffineFastState.Bounded env23063 := by
  intro p hp
  have h : env23063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23062_23063 : H12AffineEnvironment.transform 4 1 env23062 = env23063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23062 == env23063) = true)

theorem identity23063 : scanCanonicalize (H12AffineFastState.compose env23063 (packedSelected [4,6,9,10,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound23063 : packedSelected [4,6,9,10,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env23064 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,5341,8200,342,5189,10369,1024,8201,12572,1,8524,8323,8328,65,2185,13388,4572,10588,9345,8661,256,477,5261,512]

theorem envBound23064 : H12AffineFastState.Bounded env23064 := by
  intro p hp
  have h : env23064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23063_23064 : H12AffineEnvironment.transform 15 342 env23063 = env23064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env23063 == env23064) = true)

theorem identity23064 : scanCanonicalize (H12AffineFastState.compose env23064 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound23064 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env23065 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8,5341,0,342,5189,2185,1024,1,4372,1,324,139,128,65,2185,5188,4572,2388,1161,477,256,477,5261,512]

theorem envBound23065 : H12AffineFastState.Bounded env23065 := by
  intro p hp
  have h : env23065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23064_23065 : H12AffineEnvironment.transform 12 8 env23064 = env23065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env23064 == env23065) = true)

theorem identity23065 : scanCanonicalize (H12AffineFastState.compose env23065 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23065 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23066 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8,5341,0,2,5189,2185,1024,1,4160,1,16,139,128,65,2185,5188,4232,2048,1161,137,84,137,5261,512]

theorem envBound23066 : H12AffineFastState.Bounded env23066 := by
  intro p hp
  have h : env23066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23065_23066 : H12AffineEnvironment.transform 7 84 env23065 = env23066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23065 == env23066) = true)

theorem identity23066 : scanCanonicalize (H12AffineFastState.compose env23066 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound23066 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env23067 : List Nat := [2,4,8,16,1,64,128,84,512,1024,81,4096,8,5341,0,2,5189,216,1024,1,4160,1,16,139,128,65,216,5188,4232,81,1161,137,84,137,5261,512]

theorem envBound23067 : H12AffineFastState.Bounded env23067 := by
  intro p hp
  have h : env23067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23066_23067 : H12AffineEnvironment.transform 10 81 env23066 = env23067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env23066 == env23067) = true)

theorem identity23067 : scanCanonicalize (H12AffineFastState.compose env23067 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound23067 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env23068 : List Nat := [2,4,8,16,1,64,128,84,512,4,81,4096,8,4313,0,2,4161,216,4,1,4160,1,16,139,128,65,216,4160,4232,81,141,137,84,137,4233,512]

theorem envBound23068 : H12AffineFastState.Bounded env23068 := by
  intro p hp
  have h : env23068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23067_23068 : H12AffineEnvironment.transform 9 4 env23067 = env23068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env23067 == env23068) = true)

theorem identity23068 : scanCanonicalize (H12AffineFastState.compose env23068 (packedSelected [0,1,3,5,7,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23068 : packedSelected [0,1,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env23069 : List Nat := [2,4,8,0,1,64,128,68,512,4,65,4096,8,4297,0,2,4161,200,4,1,4160,1,0,139,128,65,200,4160,4232,65,141,137,68,137,4233,512]

theorem envBound23069 : H12AffineFastState.Bounded env23069 := by
  intro p hp
  have h : env23069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23068_23069 : H12AffineEnvironment.transform 3 0 env23068 = env23069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23068 == env23069) = true)

theorem identity23069 : scanCanonicalize (H12AffineFastState.compose env23069 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound23069 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23070 : List Nat := [2,4,8,0,1,64,128,68,512,4,65,136,8,65,0,2,201,200,4,1,200,1,0,139,128,65,200,200,0,65,141,137,68,137,1,512]

theorem envBound23070 : H12AffineFastState.Bounded env23070 := by
  intro p hp
  have h : env23070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23069_23070 : H12AffineEnvironment.transform 11 136 env23069 = env23070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env23069 == env23070) = true)

theorem identity23070 : scanCanonicalize (H12AffineFastState.compose env23070 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound23070 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23071 : List Nat := [2,4,8,0,1,64,128,68,201,4,65,136,8,65,0,2,201,200,4,1,200,1,0,139,128,65,200,200,0,65,141,137,68,137,1,201]

theorem envBound23071 : H12AffineFastState.Bounded env23071 := by
  intro p hp
  have h : env23071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23070_23071 : H12AffineEnvironment.transform 8 201 env23070 = env23071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env23070 == env23071) = true)

theorem identity23071 : scanCanonicalize (H12AffineFastState.compose env23071 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound23071 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23072 : List Nat := [2,4,8,0,1,64,72,68,1,4,65,64,8,65,0,2,1,0,4,1,0,1,0,67,72,65,0,0,0,65,69,65,68,65,1,1]

theorem envBound23072 : H12AffineFastState.Bounded env23072 := by
  intro p hp
  have h : env23072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23071_23072 : H12AffineEnvironment.transform 6 72 env23071 = env23072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env23071 == env23072) = true)

theorem identity23072 : scanCanonicalize (H12AffineFastState.compose env23072 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound23072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23073 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,0,8,1,0,2,1,0,4,1,0,1,0,3,8,1,0,0,0,1,5,1,4,1,1,1]

theorem envBound23073 : H12AffineFastState.Bounded env23073 := by
  intro p hp
  have h : env23073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23072_23073 : H12AffineEnvironment.transform 5 0 env23072 = env23073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env23072 == env23073) = true)

theorem identity23073 : scanCanonicalize (H12AffineFastState.compose env23073 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23074 : List Nat := [2,1,8,0,1,0,8,1,1,1,1,0,8,1,0,2,1,0,1,1,0,1,0,3,8,1,0,0,0,1,0,1,1,1,1,1]

theorem envBound23074 : H12AffineFastState.Bounded env23074 := by
  intro p hp
  have h : env23074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23073_23074 : H12AffineEnvironment.transform 1 1 env23073 = env23074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23073 == env23074) = true)

theorem identity23074 : scanCanonicalize (H12AffineFastState.compose env23074 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23075 : List Nat := [0,1,8,0,1,0,8,1,1,1,1,0,8,1,0,0,1,0,1,1,0,1,0,1,8,1,0,0,0,1,0,1,1,1,1,1]

theorem envBound23075 : H12AffineFastState.Bounded env23075 := by
  intro p hp
  have h : env23075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23074_23075 : H12AffineEnvironment.transform 0 0 env23074 = env23075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23074 == env23075) = true)

theorem identity23075 : scanCanonicalize (H12AffineFastState.compose env23075 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound23075 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23076 : List Nat := [0,1,1,0,1,0,1,1,1,1,1,0,1,1,0,0,1,0,1,1,0,1,0,1,1,1,0,0,0,1,0,1,1,1,1,1]

theorem envBound23076 : H12AffineFastState.Bounded env23076 := by
  intro p hp
  have h : env23076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23075_23076 : H12AffineEnvironment.transform 2 1 env23075 = env23076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env23075 == env23076) = true)

def env23077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,160133,33,156117,95496,8328,65,2184,160981,17665,32160,156696,156012,256,21793,16464,213967]

theorem envBound23077 : H12AffineFastState.Bounded env23077 := by
  intro p hp
  have h : env23077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23059_23077 : H12AffineEnvironment.transform 17 10401 env23059 = env23077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env23059 == env23077) = true)

theorem identity23077 : scanCanonicalize (H12AffineFastState.compose env23077 (packedSelected [0,2,4,5,6,7,9,15,16,17,20,23,24,26,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound23077 : packedSelected [0,2,4,5,6,7,9,15,16,17,20,23,24,26,32,35,41] rootPS < 2^1333 := by decide +kernel

def env23078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82383,10401,1024,29908,77898,33,73754,95496,8328,65,2184,79130,17665,32160,75223,73891,256,21793,16464,512]

theorem envBound23078 : H12AffineFastState.Bounded env23078 := by
  intro p hp
  have h : env23078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23077_23078 : H12AffineEnvironment.transform 16 82383 env23077 = env23078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env23077 == env23078) = true)

theorem identity23078 : scanCanonicalize (H12AffineFastState.compose env23078 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 14790) := by decide +kernel

theorem selectedBound23078 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env23079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,14790,30729,10401,1024,29908,2444,33,6620,19662,8328,65,2184,3292,17665,32160,7185,6501,256,21793,16464,512]

theorem envBound23079 : H12AffineFastState.Bounded env23079 := by
  intro p hp
  have h : env23079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23078_23079 : H12AffineEnvironment.transform 15 14790 env23078 = env23079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14790 env23078 == env23079) = true)

theorem identity23079 : scanCanonicalize (H12AffineFastState.compose env23079 (packedSelected [2,3,5,6,9,11,15,16,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23079 : packedSelected [2,3,5,6,9,11,15,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env23080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,16384,21756,6639,22560,2184,1024,21757,2444,33,6620,19662,161,65,2184,3292,17665,23945,7185,6501,256,21793,16464,512]

theorem envBound23080 : H12AffineFastState.Bounded env23080 := by
  intro p hp
  have h : env23080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23079_23080 : H12AffineEnvironment.transform 12 41 env23079 = env23080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23079 == env23080) = true)

theorem identity23080 : scanCanonicalize (H12AffineFastState.compose env23080 (packedSelected [2,5,6,12,15,17,19,24] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound23080 : packedSelected [2,5,6,12,15,17,19,24] rootPS < 2^1333 := by decide +kernel

def env23081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,41,16384,19776,83,16796,2184,1024,19777,2444,33,96,19662,161,65,2184,3292,17665,17461,1453,217,256,19613,16464,512]

theorem envBound23081 : H12AffineFastState.Bounded env23081 := by
  intro p hp
  have h : env23081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23080_23081 : H12AffineEnvironment.transform 11 2492 env23080 = env23081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env23080 == env23081) = true)

theorem identity23081 : scanCanonicalize (H12AffineFastState.compose env23081 (packedSelected [1,2,8,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound23081 : packedSelected [1,2,8,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env23082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,41,3345,81,83,3213,2184,1024,80,2444,33,96,479,161,65,2184,3292,2064,2340,1453,217,256,396,3393,512]

theorem envBound23082 : H12AffineFastState.Bounded env23082 := by
  intro p hp
  have h : env23082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23081_23082 : H12AffineEnvironment.transform 13 3345 env23081 = env23082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env23081 == env23082) = true)

theorem identity23082 : scanCanonicalize (H12AffineFastState.compose env23082 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound23082 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env23083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1376,1244,41,113,81,83,493,1512,1024,80,1260,33,96,479,161,65,1512,444,1392,1092,1453,217,256,396,33,512]

theorem envBound23083 : H12AffineFastState.Bounded env23083 := by
  intro p hp
  have h : env23083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23082_23083 : H12AffineEnvironment.transform 10 1376 env23082 = env23083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env23082 == env23083) = true)

theorem identity23083 : scanCanonicalize (H12AffineFastState.compose env23083 (packedSelected [1,4,8,9,10,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound23083 : packedSelected [1,4,8,9,10,15,18] rootPS < 2^1333 := by decide +kernel

def env23084 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1229,1244,41,113,81,83,64,1093,1024,80,1260,33,96,114,161,65,1093,17,1245,1092,1024,217,173,33,33,512]

theorem envBound23084 : H12AffineFastState.Bounded env23084 := by
  intro p hp
  have h : env23084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23083_23084 : H12AffineEnvironment.transform 7 173 env23083 = env23084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env23083 == env23084) = true)

theorem identity23084 : scanCanonicalize (H12AffineFastState.compose env23084 (packedSelected [2,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound23084 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env23085 : List Nat := [2,4,8,16,32,64,128,173,512,68,137,152,41,113,81,83,64,1,68,80,168,33,96,114,161,65,1,17,153,0,68,217,173,33,33,512]

theorem envBound23085 : H12AffineFastState.Bounded env23085 := by
  intro p hp
  have h : env23085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23084_23085 : H12AffineEnvironment.transform 9 68 env23084 = env23085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env23084 == env23085) = true)

theorem identity23085 : scanCanonicalize (H12AffineFastState.compose env23085 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound23085 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23086 : List Nat := [2,4,8,16,32,64,41,4,512,68,32,49,41,113,81,83,64,1,68,80,1,33,96,114,8,65,1,17,48,0,68,112,4,33,33,512]

theorem envBound23086 : H12AffineFastState.Bounded env23086 := by
  intro p hp
  have h : env23086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23085_23086 : H12AffineEnvironment.transform 6 41 env23085 = env23086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env23085 == env23086) = true)

theorem identity23086 : scanCanonicalize (H12AffineFastState.compose env23086 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23086 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env23087 : List Nat := [2,4,8,16,32,17,41,4,512,21,32,49,41,32,0,2,17,1,21,1,1,33,49,35,8,16,1,17,48,0,21,33,4,33,33,512]

theorem envBound23087 : H12AffineFastState.Bounded env23087 := by
  intro p hp
  have h : env23087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23086_23087 : H12AffineEnvironment.transform 5 17 env23086 = env23087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23086 == env23087) = true)

theorem identity23087 : scanCanonicalize (H12AffineFastState.compose env23087 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound23087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23088 : List Nat := [2,4,8,16,6,17,15,4,512,21,6,23,15,6,0,2,17,1,21,1,1,7,23,5,8,16,1,17,22,0,21,7,4,7,7,512]

theorem envBound23088 : H12AffineFastState.Bounded env23088 := by
  intro p hp
  have h : env23088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23087_23088 : H12AffineEnvironment.transform 4 6 env23087 = env23088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env23087 == env23088) = true)

theorem identity23088 : scanCanonicalize (H12AffineFastState.compose env23088 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound23088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23089 : List Nat := [2,4,8,6,6,7,15,4,512,3,6,1,15,6,0,2,7,1,3,1,1,7,1,5,8,6,1,7,0,0,3,7,4,7,7,512]

theorem envBound23089 : H12AffineFastState.Bounded env23089 := by
  intro p hp
  have h : env23089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23088_23089 : H12AffineEnvironment.transform 3 6 env23088 = env23089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env23088 == env23089) = true)

theorem identity23089 : scanCanonicalize (H12AffineFastState.compose env23089 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound23089 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23090 : List Nat := [2,4,5,6,6,7,2,4,512,3,6,1,2,6,0,2,7,1,3,1,1,7,1,5,5,6,1,7,0,0,3,7,4,7,7,512]

theorem envBound23090 : H12AffineFastState.Bounded env23090 := by
  intro p hp
  have h : env23090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23089_23090 : H12AffineEnvironment.transform 2 5 env23089 = env23090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env23089 == env23090) = true)

theorem identity23090 : scanCanonicalize (H12AffineFastState.compose env23090 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound23090 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23091 : List Nat := [2,4,5,6,6,7,2,4,5,3,6,1,2,6,0,2,7,1,3,1,1,7,1,5,5,6,1,7,0,0,3,7,4,7,7,5]

theorem envBound23091 : H12AffineFastState.Bounded env23091 := by
  intro p hp
  have h : env23091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23090_23091 : H12AffineEnvironment.transform 8 5 env23090 = env23091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env23090 == env23091) = true)

def env23092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441761,98781,8328,65,316669,436385,17665,32160,440428,156013,256,21793,46213,499643]

theorem envBound23092 : H12AffineFastState.Bounded env23092 := by
  intro p hp
  have h : env23092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23057_23092 : H12AffineEnvironment.transform 21 272513 env23057 = env23092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23057 == env23092) = true)

theorem identity23092 : scanCanonicalize (H12AffineFastState.compose env23092 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound23092 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,58517,156133,62661,98781,8328,65,171417,57797,17665,32160,61704,156013,256,21793,46213,120543]

theorem envBound23093 : H12AffineFastState.Bounded env23093 := by
  intro p hp
  have h : env23093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23092_23093 : H12AffineEnvironment.transform 17 149860 env23092 = env23093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env23092 == env23093) = true)

def env23094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,56572,1024,32769,58517,62589,62661,98781,8328,65,2049,57797,17665,32160,61704,62709,256,21793,46213,120543]

theorem envBound23094 : H12AffineFastState.Bounded env23094 := by
  intro p hp
  have h : env23094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23093_23094 : H12AffineEnvironment.transform 16 38296 env23093 = env23094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env23093 == env23094) = true)

def env23095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38296,35324,1024,32769,45461,41341,41413,98781,8328,65,2049,46277,4097,10400,41992,41461,256,33,46213,99295]

theorem envBound23095 : H12AffineFastState.Bounded env23095 := by
  intro p hp
  have h : env23095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23094_23095 : H12AffineEnvironment.transform 13 5376 env23094 = env23095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23094 == env23095) = true)

theorem identity23095 : scanCanonicalize (H12AffineFastState.compose env23095 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound23095 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,38296,35324,1024,32769,45461,41341,41413,3,8328,65,2049,46277,4097,10400,41992,41461,256,33,46213,513]

theorem envBound23096 : H12AffineFastState.Bounded env23096 := by
  intro p hp
  have h : env23096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23095_23096 : H12AffineEnvironment.transform 15 33246 env23095 = env23096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env23095 == env23096) = true)

theorem identity23096 : scanCanonicalize (H12AffineFastState.compose env23096 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound23096 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,217,263,5441,2341,1024,216,12620,8612,8476,3,8328,65,2049,13340,4097,10400,9425,8492,256,33,13404,513]

theorem envBound23097 : H12AffineFastState.Bounded env23097 := by
  intro p hp
  have h : env23097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23096_23097 : H12AffineEnvironment.transform 14 217 env23096 = env23097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env23096 == env23097) = true)

theorem identity23097 : scanCanonicalize (H12AffineFastState.compose env23097 (packedSelected [0,2,6,7,9,14,16,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23097 : packedSelected [0,2,6,7,9,14,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env23098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,217,263,5441,2341,1024,216,4161,169,17,3,389,65,2049,5393,4097,2477,1500,33,256,33,5457,513]

theorem envBound23098 : H12AffineFastState.Bounded env23098 := by
  intro p hp
  have h : env23098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23097_23098 : H12AffineEnvironment.transform 12 269 env23097 = env23098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23097 == env23098) = true)

def env23099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38296,35325,1024,32769,45460,41340,41412,98781,8328,65,2049,46276,4096,10401,41993,41460,256,32,46213,99294]

theorem envBound23099 : H12AffineFastState.Bounded env23099 := by
  intro p hp
  have h : env23099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23094_23099 : H12AffineEnvironment.transform 13 5377 env23094 = env23099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23094 == env23099) = true)

theorem identity23099 : scanCanonicalize (H12AffineFastState.compose env23099 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23099 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,38296,35325,1024,32769,45460,41340,41412,138,8328,65,2049,46276,4096,10401,41993,41460,256,32,46213,649]

theorem envBound23100 : H12AffineFastState.Bounded env23100 := by
  intro p hp
  have h : env23100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23099_23100 : H12AffineEnvironment.transform 15 33111 env23099 = env23100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23099 == env23100) = true)

theorem identity23100 : scanCanonicalize (H12AffineFastState.compose env23100 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound23100 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env23101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,32768,33111,38296,35325,1024,32769,36929,32937,32785,138,349,65,2049,38161,4096,2420,34268,32801,256,32,38224,649]

theorem envBound23101 : H12AffineFastState.Bounded env23101 := by
  intro p hp
  have h : env23101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23100_23101 : H12AffineEnvironment.transform 12 469 env23100 = env23101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env23100 == env23101) = true)

theorem identity23101 : scanCanonicalize (H12AffineFastState.compose env23101 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23101 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,342,5529,2556,1024,0,4160,168,16,138,349,65,2049,5392,4096,2420,1501,32,256,32,5457,649]

theorem envBound23102 : H12AffineFastState.Bounded env23102 := by
  intro p hp
  have h : env23102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23101_23102 : H12AffineEnvironment.transform 14 1 env23101 = env23102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23101 == env23102) = true)

theorem identity23102 : scanCanonicalize (H12AffineFastState.compose env23102 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound23102 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23103 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,9,5341,1,138,5189,2080,1024,0,4160,168,16,138,129,65,2049,5324,4096,2216,1025,32,220,32,5261,649]

theorem envBound23103 : H12AffineFastState.Bounded env23103 := by
  intro p hp
  have h : env23103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23102_23103 : H12AffineEnvironment.transform 7 220 env23102 = env23103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env23102 == env23103) = true)

theorem identity23103 : scanCanonicalize (H12AffineFastState.compose env23103 (packedSelected [0,1,3,5,6,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23103 : packedSelected [0,1,3,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env23104 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5205,1,2,5189,2080,1024,0,4160,32,16,2,9,65,2049,5188,4096,2080,1025,32,84,32,5125,513]

theorem envBound23104 : H12AffineFastState.Bounded env23104 := by
  intro p hp
  have h : env23104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23103_23104 : H12AffineEnvironment.transform 6 8 env23103 = env23104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23103 == env23104) = true)

theorem identity23104 : scanCanonicalize (H12AffineFastState.compose env23104 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2666) := by decide +kernel

theorem selectedBound23104 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23105 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,2666,9,3647,1,2,3631,2080,1024,0,2602,32,16,2,9,65,2049,3630,2666,2080,1025,32,84,32,3695,513]

theorem envBound23105 : H12AffineFastState.Bounded env23105 := by
  intro p hp
  have h : env23105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23104_23105 : H12AffineEnvironment.transform 11 2666 env23104 = env23105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2666 env23104 == env23105) = true)

theorem identity23105 : scanCanonicalize (H12AffineFastState.compose env23105 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23105 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23106 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,2618,9,3647,1,2,3631,2080,1024,0,2602,32,16,2,9,17,2049,3630,2618,2080,1025,32,4,32,3647,513]

theorem envBound23106 : H12AffineFastState.Bounded env23106 := by
  intro p hp
  have h : env23106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23105_23106 : H12AffineEnvironment.transform 5 16 env23105 = env23106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23105 == env23106) = true)

theorem identity23106 : scanCanonicalize (H12AffineFastState.compose env23106 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23107 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2586,9,3615,1,2,3599,2048,1024,0,2570,0,16,2,9,17,2049,3598,2586,2048,1025,0,4,0,3615,513]

theorem envBound23107 : H12AffineFastState.Bounded env23107 := by
  intro p hp
  have h : env23107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23106_23107 : H12AffineEnvironment.transform 4 0 env23106 = env23107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23106 == env23107) = true)

theorem identity23107 : scanCanonicalize (H12AffineFastState.compose env23107 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound23107 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23108 : List Nat := [2,4,8,16,0,16,8,4,512,1024,10,528,9,1557,1,2,1541,10,1024,0,512,0,16,2,9,17,11,1540,528,10,1025,0,4,0,1557,513]

theorem envBound23108 : H12AffineFastState.Bounded env23108 := by
  intro p hp
  have h : env23108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23107_23108 : H12AffineEnvironment.transform 10 10 env23107 = env23108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env23107 == env23108) = true)

theorem identity23108 : scanCanonicalize (H12AffineFastState.compose env23108 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23108 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23109 : List Nat := [2,4,8,10,0,10,8,4,512,1024,10,522,9,1551,1,2,1541,10,1024,0,512,0,10,2,9,11,11,1540,522,10,1025,0,4,0,1551,513]

theorem envBound23109 : H12AffineFastState.Bounded env23109 := by
  intro p hp
  have h : env23109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23108_23109 : H12AffineEnvironment.transform 3 10 env23108 = env23109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23108 == env23109) = true)

theorem identity23109 : scanCanonicalize (H12AffineFastState.compose env23109 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound23109 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23110 : List Nat := [2,4,8,10,0,10,8,4,512,4,10,522,9,523,1,2,513,10,4,0,512,0,10,2,9,11,11,512,522,10,5,0,4,0,523,513]

theorem envBound23110 : H12AffineFastState.Bounded env23110 := by
  intro p hp
  have h : env23110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23109_23110 : H12AffineEnvironment.transform 9 4 env23109 = env23110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env23109 == env23110) = true)

theorem identity23110 : scanCanonicalize (H12AffineFastState.compose env23110 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound23110 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23111 : List Nat := [2,4,8,10,0,10,8,4,13,4,10,7,9,6,1,2,12,10,4,0,13,0,10,2,9,11,11,13,7,10,5,0,4,0,6,12]

theorem envBound23111 : H12AffineFastState.Bounded env23111 := by
  intro p hp
  have h : env23111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23110_23111 : H12AffineEnvironment.transform 8 13 env23110 = env23111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env23110 == env23111) = true)

theorem identity23111 : scanCanonicalize (H12AffineFastState.compose env23111 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound23111 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env23112 : List Nat := [2,4,5,7,0,7,5,4,0,4,7,7,4,6,1,2,1,7,4,0,0,0,7,2,4,6,6,0,7,7,5,0,4,0,6,1]

theorem envBound23112 : H12AffineFastState.Bounded env23112 := by
  intro p hp
  have h : env23112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23111_23112 : H12AffineEnvironment.transform 2 5 env23111 = env23112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env23111 == env23112) = true)

theorem identity23112 : scanCanonicalize (H12AffineFastState.compose env23112 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23113 : List Nat := [2,1,0,2,0,2,0,1,0,1,2,2,1,3,1,2,1,2,1,0,0,0,2,2,1,3,3,0,2,2,0,0,1,0,3,1]

theorem envBound23113 : H12AffineFastState.Bounded env23113 := by
  intro p hp
  have h : env23113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23112_23113 : H12AffineEnvironment.transform 1 1 env23112 = env23113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23112 == env23113) = true)

def env23114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,56573,1024,32769,58517,62588,62661,98781,8328,65,2048,57797,17665,32160,61704,62708,256,21793,46213,120543]

theorem envBound23114 : H12AffineFastState.Bounded env23114 := by
  intro p hp
  have h : env23114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23093_23114 : H12AffineEnvironment.transform 16 38297 env23093 = env23114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env23093 == env23114) = true)

def env23115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38297,35325,1024,32769,45461,41340,41413,98781,8328,65,2048,46277,4097,10400,41992,41460,256,33,46213,99295]

theorem envBound23115 : H12AffineFastState.Bounded env23115 := by
  intro p hp
  have h : env23115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23114_23115 : H12AffineEnvironment.transform 13 5376 env23114 = env23115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23114 == env23115) = true)

theorem identity23115 : scanCanonicalize (H12AffineFastState.compose env23115 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23115 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,38297,35325,1024,32769,45461,41340,41413,41431,8328,65,2048,46277,4097,10400,41992,41460,256,33,46213,41941]

theorem envBound23116 : H12AffineFastState.Bounded env23116 := by
  intro p hp
  have h : env23116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23115_23116 : H12AffineEnvironment.transform 15 8202 env23115 = env23116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23115 == env23116) = true)

theorem identity23116 : scanCanonicalize (H12AffineFastState.compose env23116 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound23116 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,13389,10281,1024,8661,4161,168,17,3,8328,65,2048,5393,4097,10400,1500,32,256,33,5457,513]

theorem envBound23117 : H12AffineFastState.Bounded env23117 := by
  intro p hp
  have h : env23117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23116_23117 : H12AffineEnvironment.transform 14 8660 env23116 = env23117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env23116 == env23117) = true)

theorem identity23117 : scanCanonicalize (H12AffineFastState.compose env23117 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23117 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,217,263,5440,2340,1024,216,4161,168,17,3,389,65,2048,5393,4097,2477,1500,32,256,33,5457,513]

theorem envBound23118 : H12AffineFastState.Bounded env23118 := by
  intro p hp
  have h : env23118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23117_23118 : H12AffineEnvironment.transform 12 269 env23117 = env23118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23117 == env23118) = true)

theorem identity23118 : scanCanonicalize (H12AffineFastState.compose env23118 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound23118 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23119 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5376,1,263,5440,2340,1024,0,4161,112,17,3,349,65,2048,5393,4097,2421,1284,32,256,33,5457,513]

theorem envBound23119 : H12AffineFastState.Bounded env23119 := by
  intro p hp
  have h : env23119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23118_23119 : H12AffineEnvironment.transform 6 88 env23118 = env23119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env23118 == env23119) = true)

theorem identity23119 : scanCanonicalize (H12AffineFastState.compose env23119 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23119 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env23120 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,269,4113,1,263,4177,2340,273,0,4161,112,17,3,349,65,2048,4096,4097,2421,21,32,256,33,4160,513]

theorem envBound23120 : H12AffineFastState.Bounded env23120 := by
  intro p hp
  have h : env23120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23119_23120 : H12AffineEnvironment.transform 9 273 env23119 = env23120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23119 == env23120) = true)

def env23121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38297,35324,1024,32769,45460,41341,41412,98781,8328,65,2048,46276,4096,10401,41993,41461,256,32,46213,99294]

theorem envBound23121 : H12AffineFastState.Bounded env23121 := by
  intro p hp
  have h : env23121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23114_23121 : H12AffineEnvironment.transform 13 5377 env23114 = env23121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23114 == env23121) = true)

theorem identity23121 : scanCanonicalize (H12AffineFastState.compose env23121 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound23121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,38297,35324,1024,32769,45460,41341,41412,41311,8328,65,2048,46276,4096,10401,41993,41461,256,32,46213,41820]

theorem envBound23122 : H12AffineFastState.Bounded env23122 := by
  intro p hp
  have h : env23122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23121_23122 : H12AffineEnvironment.transform 15 8322 env23121 = env23122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env23121 == env23122) = true)

theorem identity23122 : scanCanonicalize (H12AffineFastState.compose env23122 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23122 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env23123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,0,8322,5529,2556,1024,1,12692,8573,8644,8543,8328,65,2048,13508,4096,10401,9225,8693,256,32,13445,9052]

theorem envBound23123 : H12AffineFastState.Bounded env23123 := by
  intro p hp
  have h : env23123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23122_23123 : H12AffineEnvironment.transform 14 0 env23122 = env23123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23122 == env23123) = true)

def env23124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,8862845,8328,65,4258941,8393985,8845472,8830977,440429,12645452,256,21792,46212,499642]

theorem envBound23124 : H12AffineFastState.Bounded env23124 := by
  intro p hp
  have h : env23124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22999_23124 : H12AffineEnvironment.transform 23 8862845 env22999 = env23124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862845 env22999 == env23124) = true)

def env23125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441760,98781,8328,65,4258941,436385,17664,32161,440429,4606444,256,21792,46212,499642]

theorem envBound23125 : H12AffineFastState.Bounded env23125 := by
  intro p hp
  have h : env23125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23124_23125 : H12AffineEnvironment.transform 22 441760 env23124 = env23125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env23124 == env23125) = true)

def env23126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441760,98781,8328,65,316669,436385,17664,32161,440429,156012,256,21792,46212,499642]

theorem envBound23126 : H12AffineFastState.Bounded env23126 := by
  intro p hp
  have h : env23126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23125_23126 : H12AffineEnvironment.transform 21 272512 env23125 = env23126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23125 == env23126) = true)

theorem identity23126 : scanCanonicalize (H12AffineFastState.compose env23126 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound23126 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115870,213487,120015,98781,8328,65,245138,115150,17664,32161,119042,156012,256,21792,46212,63189]

theorem envBound23127 : H12AffineFastState.Bounded env23127 := by
  intro p hp
  have h : env23127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23126_23127 : H12AffineEnvironment.transform 17 223599 env23126 = env23127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env23126 == env23127) = true)

def env23128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1024,32769,115870,120063,120015,98781,8328,65,75906,115150,17664,32161,119042,62588,256,21792,46212,63189]

theorem envBound23128 : H12AffineFastState.Bounded env23128 := by
  intro p hp
  have h : env23128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23127_23128 : H12AffineEnvironment.transform 16 38160 env23127 = env23128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23127 == env23128) = true)

def env23129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1024,32769,115870,120062,120015,98781,8328,65,75907,115150,17664,32161,119042,62589,256,21792,46212,63189]

theorem envBound23129 : H12AffineFastState.Bounded env23129 := by
  intro p hp
  have h : env23129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23127_23129 : H12AffineEnvironment.transform 16 38161 env23127 = env23129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23127 == env23129) = true)

theorem identity23129 : scanCanonicalize (H12AffineFastState.compose env23129 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23129 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env23130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25028,67755,1024,29908,77899,73771,73754,95496,8328,65,75907,79131,17664,32161,75223,168,256,21792,16465,512]

theorem envBound23130 : H12AffineFastState.Bounded env23130 := by
  intro p hp
  have h : env23130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23129_23130 : H12AffineEnvironment.transform 14 29909 env23129 = env23130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23129 == env23130) = true)

theorem identity23130 : scanCanonicalize (H12AffineFastState.compose env23130 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23130 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,65536,16537,67755,1024,21897,69910,65910,65863,87125,469,65,68062,70726,17664,23804,66698,168,256,21792,16465,512]

theorem envBound23131 : H12AffineFastState.Bounded env23131 := by
  intro p hp
  have h : env23131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23130_23131 : H12AffineEnvironment.transform 12 349 env23130 = env23131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23130 == env23131) = true)

theorem identity23131 : scanCanonicalize (H12AffineFastState.compose env23131 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound23131 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5237,509,65536,5356,67755,1024,508,69910,65910,65863,65568,469,65,68062,70726,4469,2185,66698,168,256,341,5156,512]

theorem envBound23132 : H12AffineFastState.Bounded env23132 := by
  intro p hp
  have h : env23132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23131_23132 : H12AffineEnvironment.transform 13 5237 env23131 = env23132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env23131 == env23132) = true)

theorem identity23132 : scanCanonicalize (H12AffineFastState.compose env23132 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound23132 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5237,509,138,5356,2081,1024,508,4508,508,461,170,469,65,2388,5324,4469,2185,1024,168,256,341,5156,512]

theorem envBound23133 : H12AffineFastState.Bounded env23133 := by
  intro p hp
  have h : env23133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23132_23133 : H12AffineEnvironment.transform 15 138 env23132 = env23133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env23132 == env23133) = true)

theorem identity23133 : scanCanonicalize (H12AffineFastState.compose env23133 (packedSelected [6,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23133 : packedSelected [6,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,372,3,5221,2081,1024,373,4373,373,324,35,348,65,2388,5189,4469,2048,1024,33,256,341,5156,512]

theorem envBound23134 : H12AffineFastState.Bounded env23134 := by
  intro p hp
  have h : env23134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23133_23134 : H12AffineEnvironment.transform 6 9 env23133 = env23134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23133 == env23134) = true)

theorem identity23134 : scanCanonicalize (H12AffineFastState.compose env23134 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23134 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env23135 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,1,3,5221,2081,1024,0,4192,0,49,35,41,65,2081,5189,4096,2048,1024,33,117,32,5156,512]

theorem envBound23135 : H12AffineFastState.Bounded env23135 := by
  intro p hp
  have h : env23135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23134_23135 : H12AffineEnvironment.transform 7 117 env23134 = env23135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23134 == env23135) = true)

theorem identity23135 : scanCanonicalize (H12AffineFastState.compose env23135 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23135 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env23136 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,1,3,5189,2049,1024,0,4160,0,17,3,9,65,2049,5189,4096,2048,1024,1,85,0,5124,512]

theorem envBound23136 : H12AffineFastState.Bounded env23136 := by
  intro p hp
  have h : env23136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23135_23136 : H12AffineEnvironment.transform 4 0 env23135 = env23136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23135 == env23136) = true)

theorem identity23136 : scanCanonicalize (H12AffineFastState.compose env23136 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23136 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23137 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,1,3,5140,2049,1024,0,4113,0,17,3,9,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound23137 : H12AffineFastState.Bounded env23137 := by
  intro p hp
  have h : env23137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23136_23137 : H12AffineEnvironment.transform 5 17 env23136 = env23137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23136 == env23137) = true)

def env23138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441760,98781,8328,65,316668,436385,17664,32161,440429,156013,256,21792,46212,499642]

theorem envBound23138 : H12AffineFastState.Bounded env23138 := by
  intro p hp
  have h : env23138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23125_23138 : H12AffineEnvironment.transform 21 272513 env23125 = env23138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23125 == env23138) = true)

theorem identity23138 : scanCanonicalize (H12AffineFastState.compose env23138 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,437745,272513,441760,21762,8328,65,316668,436385,17664,32161,440429,156013,256,21792,46212,412517]

theorem envBound23139 : H12AffineFastState.Bounded env23139 := by
  intro p hp
  have h : env23139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23138_23139 : H12AffineEnvironment.transform 15 54495 env23138 = env23139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23138 == env23139) = true)

def env23140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437625,272393,441640,21762,8192,65,316532,436265,17664,32041,440429,156013,256,21792,46092,412517]

theorem envBound23140 : H12AffineFastState.Bounded env23140 := by
  intro p hp
  have h : env23140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23139_23140 : H12AffineEnvironment.transform 6 8 env23139 = env23140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23139 == env23140) = true)

theorem identity23140 : scanCanonicalize (H12AffineFastState.compose env23140 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound23140 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env23141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,262144,1024,32769,314420,272393,318565,21762,8192,65,316532,313700,17664,32041,317728,32,256,21792,46092,272936]

theorem envBound23141 : H12AffineFastState.Bounded env23141 := by
  intro p hp
  have h : env23141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23140_23141 : H12AffineEnvironment.transform 16 24909 env23140 = env23141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env23140 == env23141) = true)

theorem identity23141 : scanCanonicalize (H12AffineFastState.compose env23141 (packedSelected [2,3,4,6,9,12,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound23141 : packedSelected [2,3,4,6,9,12,23,24] rootPS < 2^1333 := by decide +kernel

def env23142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,56357,1024,32769,4113,62508,64,21762,8192,65,2129,5441,17664,32041,1285,32,256,21792,46092,62989]

theorem envBound23142 : H12AffineFastState.Bounded env23142 := by
  intro p hp
  have h : env23142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23141_23142 : H12AffineEnvironment.transform 17 56357 env23141 = env23142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env23141 == env23142) = true)

theorem identity23142 : scanCanonicalize (H12AffineFastState.compose env23142 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23142 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env23143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,16401,56357,1024,32769,4113,54640,64,21762,348,65,2129,5441,17664,23669,1285,32,256,21792,38224,55121]

theorem envBound23143 : H12AffineFastState.Bounded env23143 := by
  intro p hp
  have h : env23143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23142_23143 : H12AffineEnvironment.transform 12 348 env23142 = env23143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23142 == env23143) = true)

theorem identity23143 : scanCanonicalize (H12AffineFastState.compose env23143 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23143 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env23144 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,54279,16401,56357,1024,32769,4113,54560,16,21762,268,17,2049,5393,17664,23589,1285,32,256,21792,38144,55041]

theorem envBound23144 : H12AffineFastState.Bounded env23144 := by
  intro p hp
  have h : env23144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23143_23144 : H12AffineEnvironment.transform 5 16 env23143 = env23144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23143 == env23144) = true)

theorem identity23144 : scanCanonicalize (H12AffineFastState.compose env23144 (packedSelected [0,3,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound23144 : packedSelected [0,3,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env23145 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,2048,23559,16401,21541,1024,2049,4113,23840,16,21762,268,17,2049,5393,17664,23589,1285,32,256,21792,7424,24321]

theorem envBound23145 : H12AffineFastState.Bounded env23145 := by
  intro p hp
  have h : env23145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23144_23145 : H12AffineEnvironment.transform 14 2048 env23144 = env23145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env23144 == env23145) = true)

theorem identity23145 : scanCanonicalize (H12AffineFastState.compose env23145 (packedSelected [0,2,3,6,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23145 : packedSelected [0,2,3,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23146 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,16384,2048,22578,16401,20496,53,2049,4113,22805,16,20791,268,17,2049,4388,16693,22544,304,32,256,20757,6453,23348]

theorem envBound23146 : H12AffineFastState.Bounded env23146 := by
  intro p hp
  have h : env23146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23145_23146 : H12AffineEnvironment.transform 9 53 env23145 = env23146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23145 == env23146) = true)

theorem identity23146 : scanCanonicalize (H12AffineFastState.compose env23146 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23146 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23147 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,268,16384,2048,18467,16401,16385,53,2049,0,18692,16,16678,268,17,2049,309,16693,18433,304,32,256,16644,2340,19237]

theorem envBound23147 : H12AffineFastState.Bounded env23147 := by
  intro p hp
  have h : env23147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23146_23147 : H12AffineEnvironment.transform 11 17 env23146 = env23147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23146 == env23147) = true)

theorem identity23147 : scanCanonicalize (H12AffineFastState.compose env23147 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound23147 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env23148 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,268,292,2048,2311,309,293,53,2049,0,2080,16,2,268,17,2049,309,17,2341,304,32,256,32,2340,2561]

theorem envBound23148 : H12AffineFastState.Bounded env23148 := by
  intro p hp
  have h : env23148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23147_23148 : H12AffineEnvironment.transform 13 292 env23147 = env23148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env23147 == env23148) = true)

theorem identity23148 : scanCanonicalize (H12AffineFastState.compose env23148 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23148 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23149 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,17,8,32,2048,2051,49,33,53,2049,0,2080,16,2,8,17,2049,49,17,2081,52,32,4,32,2080,2561]

theorem envBound23149 : H12AffineFastState.Bounded env23149 := by
  intro p hp
  have h : env23149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23148_23149 : H12AffineEnvironment.transform 7 4 env23148 = env23149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23148 == env23149) = true)

theorem identity23149 : scanCanonicalize (H12AffineFastState.compose env23149 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23149 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env23150 : List Nat := [2,4,8,16,32,16,8,4,512,53,1,17,8,32,1,2,49,33,53,0,0,33,16,2,8,17,0,49,17,32,52,32,4,32,33,512]

theorem envBound23150 : H12AffineFastState.Bounded env23150 := by
  intro p hp
  have h : env23150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23149_23150 : H12AffineEnvironment.transform 10 1 env23149 = env23150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23149 == env23150) = true)

theorem identity23150 : scanCanonicalize (H12AffineFastState.compose env23150 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23150 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23151 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,8,0,1,2,17,1,21,0,0,1,16,2,8,17,0,17,17,0,20,0,4,0,1,512]

theorem envBound23151 : H12AffineFastState.Bounded env23151 := by
  intro p hp
  have h : env23151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23150_23151 : H12AffineEnvironment.transform 4 0 env23150 = env23151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23150 == env23151) = true)

theorem identity23151 : scanCanonicalize (H12AffineFastState.compose env23151 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound23151 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23152 : List Nat := [2,4,8,16,0,16,8,4,17,21,1,17,8,0,1,2,17,1,21,0,0,1,16,2,8,17,0,17,17,0,20,0,4,0,1,17]

theorem envBound23152 : H12AffineFastState.Bounded env23152 := by
  intro p hp
  have h : env23152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23151_23152 : H12AffineEnvironment.transform 8 17 env23151 = env23152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23151 == env23152) = true)

theorem identity23152 : scanCanonicalize (H12AffineFastState.compose env23152 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23152 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23153 : List Nat := [2,1,8,16,0,16,8,1,17,16,1,17,8,0,1,2,17,1,16,0,0,1,16,2,8,17,0,17,17,0,17,0,1,0,1,17]

theorem envBound23153 : H12AffineFastState.Bounded env23153 := by
  intro p hp
  have h : env23153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23152_23153 : H12AffineEnvironment.transform 1 1 env23152 = env23153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23152 == env23153) = true)

def env23154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272392,441641,21762,8193,65,316533,436264,17664,32040,440429,156013,256,21792,46093,412517]

theorem envBound23154 : H12AffineFastState.Bounded env23154 := by
  intro p hp
  have h : env23154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23139_23154 : H12AffineEnvironment.transform 6 9 env23139 = env23154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23139 == env23154) = true)

theorem identity23154 : scanCanonicalize (H12AffineFastState.compose env23154 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound23154 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env23155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157753,1024,32769,50497,147505,54544,21762,8193,65,179276,49169,17664,32040,53332,156013,256,21792,46093,9052]

theorem envBound23155 : H12AffineFastState.Bounded env23155 := by
  intro p hp
  have h : env23155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23154_23155 : H12AffineEnvironment.transform 17 157753 env23154 = env23155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env23154 == env23155) = true)

theorem identity23155 : scanCanonicalize (H12AffineFastState.compose env23155 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23155 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,131072,157753,1024,1,17729,147505,21776,21762,8193,65,146508,16401,17664,32040,20564,156013,256,21792,13325,9052]

theorem envBound23156 : H12AffineFastState.Bounded env23156 := by
  intro p hp
  have h : env23156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23155_23156 : H12AffineEnvironment.transform 14 0 env23155 = env23156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23155 == env23156) = true)

theorem identity23156 : scanCanonicalize (H12AffineFastState.compose env23156 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound23156 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env23157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,13388,23669,1024,1,17729,29821,21776,21762,8193,65,2048,16401,17664,32040,20564,21793,256,21792,13325,9052]

theorem envBound23157 : H12AffineFastState.Bounded env23157 := by
  intro p hp
  have h : env23157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23156_23157 : H12AffineEnvironment.transform 16 13388 env23156 = env23157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env23156 == env23157) = true)

theorem identity23157 : scanCanonicalize (H12AffineFastState.compose env23157 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23157 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env23158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,342,13388,2421,1024,1,4161,8573,16,2,8193,65,2048,5393,4096,10280,1364,33,256,32,13325,9052]

theorem envBound23158 : H12AffineFastState.Bounded env23158 := by
  intro p hp
  have h : env23158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23157_23158 : H12AffineEnvironment.transform 13 5376 env23157 = env23158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23157 == env23158) = true)

theorem identity23158 : scanCanonicalize (H12AffineFastState.compose env23158 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound23158 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5376,0,342,5425,2421,1024,1,4161,0,16,2,380,65,2048,5393,4096,2389,1364,33,256,32,5488,545]

theorem envBound23159 : H12AffineFastState.Bounded env23159 := by
  intro p hp
  have h : env23159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23158_23159 : H12AffineEnvironment.transform 12 381 env23158 = env23159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env23158 == env23159) = true)

theorem identity23159 : scanCanonicalize (H12AffineFastState.compose env23159 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound23159 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env23160 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5205,0,3,5220,2080,1024,1,4161,0,16,2,41,65,2048,5188,4096,2048,1025,33,85,32,5157,545]

theorem envBound23160 : H12AffineFastState.Bounded env23160 := by
  intro p hp
  have h : env23160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23159_23160 : H12AffineEnvironment.transform 7 85 env23159 = env23160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env23159 == env23160) = true)

theorem identity23160 : scanCanonicalize (H12AffineFastState.compose env23160 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23160 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23161 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,0,3,5188,2048,1024,1,4161,0,16,2,9,65,2048,5188,4096,2048,1025,1,85,0,5125,513]

theorem envBound23161 : H12AffineFastState.Bounded env23161 := by
  intro p hp
  have h : env23161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23160_23161 : H12AffineEnvironment.transform 4 0 env23160 = env23161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23160 == env23161) = true)

theorem identity23161 : scanCanonicalize (H12AffineFastState.compose env23161 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound23161 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23162 : List Nat := [2,4,8,16,0,64,9,85,512,581,2048,4096,8,4624,0,3,4609,2048,581,1,4161,0,16,2,9,65,2048,4609,4096,2048,580,1,85,0,4672,513]

theorem envBound23162 : H12AffineFastState.Bounded env23162 := by
  intro p hp
  have h : env23162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23161_23162 : H12AffineEnvironment.transform 9 581 env23161 = env23162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env23161 == env23162) = true)

theorem identity23162 : scanCanonicalize (H12AffineFastState.compose env23162 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23162 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23163 : List Nat := [2,4,8,16,0,17,9,4,512,532,2048,4096,8,4624,0,3,4609,2048,532,1,4112,0,16,2,9,16,2048,4609,4096,2048,533,1,4,0,4625,513]

theorem envBound23163 : H12AffineFastState.Bounded env23163 := by
  intro p hp
  have h : env23163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23162_23163 : H12AffineEnvironment.transform 5 17 env23162 = env23163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23162 == env23163) = true)

theorem identity23163 : scanCanonicalize (H12AffineFastState.compose env23163 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound23163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23164 : List Nat := [2,4,8,16,0,17,9,4,512,532,2048,1,8,529,0,3,512,2048,532,1,17,0,16,2,9,16,2048,512,1,2048,533,1,4,0,528,513]

theorem envBound23164 : H12AffineFastState.Bounded env23164 := by
  intro p hp
  have h : env23164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23163_23164 : H12AffineEnvironment.transform 11 1 env23163 = env23164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env23163 == env23164) = true)

theorem identity23164 : scanCanonicalize (H12AffineFastState.compose env23164 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound23164 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23165 : List Nat := [2,4,8,16,0,17,9,4,16,4,2048,1,8,1,0,3,16,2048,4,1,17,0,16,2,9,16,2048,16,1,2048,5,1,4,0,0,17]

theorem envBound23165 : H12AffineFastState.Bounded env23165 := by
  intro p hp
  have h : env23165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23164_23165 : H12AffineEnvironment.transform 8 16 env23164 = env23165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env23164 == env23165) = true)

theorem identity23165 : scanCanonicalize (H12AffineFastState.compose env23165 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23166 : List Nat := [2,4,8,16,0,17,9,4,16,4,1,1,8,1,0,3,16,1,4,1,17,0,16,2,9,16,1,16,1,1,5,1,4,0,0,17]

theorem envBound23166 : H12AffineFastState.Bounded env23166 := by
  intro p hp
  have h : env23166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23165_23166 : H12AffineEnvironment.transform 10 1 env23165 = env23166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23165 == env23166) = true)

theorem identity23166 : scanCanonicalize (H12AffineFastState.compose env23166 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23166 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23167 : List Nat := [2,4,8,0,0,1,9,4,0,4,1,1,8,1,0,3,0,1,4,1,1,0,0,2,9,0,1,0,1,1,5,1,4,0,0,1]

theorem envBound23167 : H12AffineFastState.Bounded env23167 := by
  intro p hp
  have h : env23167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23166_23167 : H12AffineEnvironment.transform 3 0 env23166 = env23167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23166 == env23167) = true)

theorem identity23167 : scanCanonicalize (H12AffineFastState.compose env23167 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23167 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23168 : List Nat := [2,4,2,0,0,1,3,4,0,4,1,1,2,1,0,3,0,1,4,1,1,0,0,2,3,0,1,0,1,1,5,1,4,0,0,1]

theorem envBound23168 : H12AffineFastState.Bounded env23168 := by
  intro p hp
  have h : env23168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23167_23168 : H12AffineEnvironment.transform 2 2 env23167 = env23168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23167 == env23168) = true)

def env23169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441761,98780,8328,65,4258941,436384,17665,32160,440429,4606445,256,21792,46212,499642]

theorem envBound23169 : H12AffineFastState.Bounded env23169 := by
  intro p hp
  have h : env23169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23124_23169 : H12AffineEnvironment.transform 22 441761 env23124 = env23169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env23124 == env23169) = true)

def env23170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441761,98780,8328,65,316669,436384,17665,32160,440429,156013,256,21792,46212,499642]

theorem envBound23170 : H12AffineFastState.Bounded env23170 := by
  intro p hp
  have h : env23170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23169_23170 : H12AffineEnvironment.transform 21 272512 env23169 = env23170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23169 == env23170) = true)

theorem identity23170 : scanCanonicalize (H12AffineFastState.compose env23170 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound23170 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,77898,243003,73754,98780,8328,65,215366,79131,17665,32160,75222,156013,256,21792,46212,513]

theorem envBound23171 : H12AffineFastState.Bounded env23171 := by
  intro p hp
  have h : env23171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23170_23171 : H12AffineEnvironment.transform 17 236987 env23170 = env23171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env23170 == env23171) = true)

def env23172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77898,243003,73754,98644,8192,65,215366,79131,17665,32040,75102,156013,256,21792,46092,513]

theorem envBound23172 : H12AffineFastState.Bounded env23172 := by
  intro p hp
  have h : env23172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23171_23172 : H12AffineEnvironment.transform 6 8 env23171 = env23172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23171 == env23172) = true)

theorem identity23172 : scanCanonicalize (H12AffineFastState.compose env23172 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23172 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169264,17,41311,8192,65,158029,5392,17665,32040,1365,156013,256,21792,46092,513]

theorem envBound23173 : H12AffineFastState.Bounded env23173 := by
  intro p hp
  have h : env23173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23172_23173 : H12AffineEnvironment.transform 15 8203 env23172 = env23173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23172 == env23173) = true)

theorem identity23173 : scanCanonicalize (H12AffineFastState.compose env23173 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23173 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64809,1024,32769,4161,54561,17,41311,8192,65,10588,5392,17665,32040,1365,8572,256,21792,46092,513]

theorem envBound23174 : H12AffineFastState.Bounded env23174 := by
  intro p hp
  have h : env23174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23173_23174 : H12AffineEnvironment.transform 16 16401 env23173 = env23174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23173 == env23174) = true)

theorem identity23174 : scanCanonicalize (H12AffineFastState.compose env23174 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23174 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,23669,1024,8541,4161,29821,17,3,8192,65,10588,5392,17665,32040,1365,8572,256,21792,5456,513]

theorem envBound23175 : H12AffineFastState.Bounded env23175 := by
  intro p hp
  have h : env23175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23174_23175 : H12AffineEnvironment.transform 14 8540 env23174 = env23175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23174 == env23175) = true)

theorem identity23175 : scanCanonicalize (H12AffineFastState.compose env23175 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound23175 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8203,13672,10508,1024,8541,4161,260,17,3,8192,65,10588,5392,12408,2129,1365,8572,256,8281,5456,513]

theorem envBound23176 : H12AffineFastState.Bounded env23176 := by
  intro p hp
  have h : env23176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23175_23176 : H12AffineEnvironment.transform 13 13689 env23175 = env23176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env23175 == env23176) = true)

theorem identity23176 : scanCanonicalize (H12AffineFastState.compose env23176 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound23176 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23177 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12345,8540,8203,12328,10508,320,8541,4161,260,17,3,8192,65,10588,4176,12408,2129,21,8572,256,8281,4112,513]

theorem envBound23177 : H12AffineFastState.Bounded env23177 := by
  intro p hp
  have h : env23177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23176_23177 : H12AffineEnvironment.transform 9 320 env23176 = env23177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23176 == env23177) = true)

theorem identity23177 : scanCanonicalize (H12AffineFastState.compose env23177 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound23177 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23178 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,4153,0,4453,4146,17,6453,320,4452,4161,260,17,3,4153,65,6501,4176,65,2129,21,4421,256,4192,4112,513]

theorem envBound23178 : H12AffineFastState.Bounded env23178 := by
  intro p hp
  have h : env23178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23177_23178 : H12AffineEnvironment.transform 12 4153 env23177 = env23178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env23177 == env23178) = true)

theorem identity23178 : scanCanonicalize (H12AffineFastState.compose env23178 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound23178 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env23179 : List Nat := [2,4,8,16,32,64,8,256,512,320,81,4096,4153,0,4453,4146,17,4452,320,4452,4161,260,17,3,4153,65,4404,4176,65,0,21,4421,256,4192,4112,513]

theorem envBound23179 : H12AffineFastState.Bounded env23179 := by
  intro p hp
  have h : env23179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23178_23179 : H12AffineEnvironment.transform 10 81 env23178 = env23179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env23178 == env23179) = true)

theorem identity23179 : scanCanonicalize (H12AffineFastState.compose env23179 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23179 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23180 : List Nat := [2,4,8,16,32,64,8,116,512,52,81,4096,4153,0,4113,4146,17,4112,52,4112,4161,112,17,3,4153,65,4160,4176,65,0,21,4145,116,4192,4112,513]

theorem envBound23180 : H12AffineFastState.Bounded env23180 := by
  intro p hp
  have h : env23180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23179_23180 : H12AffineEnvironment.transform 7 116 env23179 = env23180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23179 == env23180) = true)

theorem identity23180 : scanCanonicalize (H12AffineFastState.compose env23180 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound23180 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23181 : List Nat := [2,4,8,16,32,64,8,116,512,52,81,16,41,0,1,34,17,0,52,0,81,112,17,3,41,65,80,64,65,0,21,33,116,112,0,513]

theorem envBound23181 : H12AffineFastState.Bounded env23181 := by
  intro p hp
  have h : env23181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23180_23181 : H12AffineEnvironment.transform 11 16 env23180 = env23181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23180 == env23181) = true)

theorem identity23181 : scanCanonicalize (H12AffineFastState.compose env23181 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23181 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23182 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,0,1,34,17,0,52,0,0,33,17,3,41,16,1,17,16,0,21,33,37,33,0,513]

theorem envBound23182 : H12AffineFastState.Bounded env23182 := by
  intro p hp
  have h : env23182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23181_23182 : H12AffineEnvironment.transform 5 17 env23181 = env23182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23181 == env23182) = true)

theorem identity23182 : scanCanonicalize (H12AffineFastState.compose env23182 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23183 : List Nat := [2,4,8,16,32,17,8,37,32,52,0,16,41,0,1,34,17,0,52,0,0,33,17,3,41,16,1,17,16,0,21,33,37,33,0,33]

theorem envBound23183 : H12AffineFastState.Bounded env23183 := by
  intro p hp
  have h : env23183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23182_23183 : H12AffineEnvironment.transform 8 32 env23182 = env23183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23182 == env23183) = true)

def env23184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77898,243003,73754,98645,8193,65,215366,79131,17665,32041,75103,156013,256,21792,46093,513]

theorem envBound23184 : H12AffineFastState.Bounded env23184 := by
  intro p hp
  have h : env23184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23171_23184 : H12AffineEnvironment.transform 6 9 env23171 = env23184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23171 == env23184) = true)

theorem identity23184 : scanCanonicalize (H12AffineFastState.compose env23184 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23184 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,64808,1024,32769,77898,54561,73754,98645,8193,65,10588,79131,17665,32041,75103,65911,256,21792,46093,513]

theorem envBound23185 : H12AffineFastState.Bounded env23185 := by
  intro p hp
  have h : env23185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23184_23185 : H12AffineEnvironment.transform 16 90138 env23184 = env23185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23184 == env23185) = true)

theorem identity23185 : scanCanonicalize (H12AffineFastState.compose env23185 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound23185 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env23186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,16384,32768,65536,82950,55604,1024,32769,70742,54561,66566,98645,1053,65,3392,69895,17665,22837,65859,65911,256,21792,36881,513]

theorem envBound23186 : H12AffineFastState.Bounded env23186 := by
  intro p hp
  have h : env23186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23185_23186 : H12AffineEnvironment.transform 12 1052 env23185 = env23186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env23185 == env23186) = true)

theorem identity23186 : scanCanonicalize (H12AffineFastState.compose env23186 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 54562) := by decide +kernel

theorem selectedBound23186 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env23187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,16384,32768,54562,37156,55604,1024,32769,49524,54561,53540,21623,1053,65,3392,50213,17665,22837,54369,54357,256,21792,36881,513]

theorem envBound23187 : H12AffineFastState.Bounded env23187 := by
  intro p hp
  have h : env23187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23186_23187 : H12AffineEnvironment.transform 15 54562 env23186 = env23187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54562 env23186 == env23187) = true)

theorem identity23187 : scanCanonicalize (H12AffineFastState.compose env23187 (packedSelected [0,1,3,7,12,15,18,20,24,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound23187 : packedSelected [0,1,3,7,12,15,18,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env23188 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,16384,32768,53575,37156,55604,101,32769,49524,53572,53540,20498,120,65,2341,49216,16740,22837,53252,53296,256,20805,36881,513]

theorem envBound23188 : H12AffineFastState.Bounded env23188 := by
  intro p hp
  have h : env23188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23187_23188 : H12AffineEnvironment.transform 9 101 env23187 = env23188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env23187 == env23188) = true)

theorem identity23188 : scanCanonicalize (H12AffineFastState.compose env23188 (packedSelected [2,4,6,9,11,14,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23188 : packedSelected [2,4,6,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env23189 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,4112,32768,33111,37156,35108,101,32769,37220,33108,33076,2,120,65,2341,36944,4468,2341,32788,32800,256,341,36881,513]

theorem envBound23189 : H12AffineFastState.Bounded env23189 := by
  intro p hp
  have h : env23189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23188_23189 : H12AffineEnvironment.transform 13 4112 env23188 = env23189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env23188 == env23189) = true)

theorem identity23189 : scanCanonicalize (H12AffineFastState.compose env23189 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound23189 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23190 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,356,121,372,32768,33111,32832,35108,101,32769,32768,33108,33076,2,120,65,2341,33076,16,2341,32788,32800,256,341,33141,513]

theorem envBound23190 : H12AffineFastState.Bounded env23190 := by
  intro p hp
  have h : env23190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23189_23190 : H12AffineEnvironment.transform 11 356 env23189 = env23190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env23189 == env23190) = true)

theorem identity23190 : scanCanonicalize (H12AffineFastState.compose env23190 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23191 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,356,121,372,0,343,64,2340,101,1,0,340,308,2,120,65,2341,308,16,2341,20,32,256,341,373,513]

theorem envBound23191 : H12AffineFastState.Bounded env23191 := by
  intro p hp
  have h : env23191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23190_23191 : H12AffineEnvironment.transform 14 0 env23190 = env23191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23190 == env23191) = true)

theorem identity23191 : scanCanonicalize (H12AffineFastState.compose env23191 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound23191 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env23192 : List Nat := [2,4,8,16,32,64,9,256,512,101,293,356,121,372,0,343,64,1,101,1,0,340,308,2,120,65,0,308,16,0,20,32,256,341,373,513]

theorem envBound23192 : H12AffineFastState.Bounded env23192 := by
  intro p hp
  have h : env23192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23191_23192 : H12AffineEnvironment.transform 10 293 env23191 = env23192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env23191 == env23192) = true)

theorem identity23192 : scanCanonicalize (H12AffineFastState.compose env23192 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23192 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23193 : List Nat := [2,4,8,16,32,64,9,117,512,101,80,17,121,1,0,34,64,1,101,1,0,33,65,2,120,65,0,65,16,0,20,32,117,32,0,513]

theorem envBound23193 : H12AffineFastState.Bounded env23193 := by
  intro p hp
  have h : env23193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23192_23193 : H12AffineEnvironment.transform 7 117 env23192 = env23193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23192 == env23193) = true)

def env23194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441761,98780,8328,65,316668,436384,17665,32160,440429,156012,256,21792,46212,499642]

theorem envBound23194 : H12AffineFastState.Bounded env23194 := by
  intro p hp
  have h : env23194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23169_23194 : H12AffineEnvironment.transform 21 272513 env23169 = env23194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23169 == env23194) = true)

theorem identity23194 : scanCanonicalize (H12AffineFastState.compose env23194 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437745,272513,441761,41430,8328,65,316668,436384,17665,32160,440429,156012,256,21792,46212,442288]

theorem envBound23195 : H12AffineFastState.Bounded env23195 := by
  intro p hp
  have h : env23195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23194_23195 : H12AffineEnvironment.transform 15 8202 env23194 = env23195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23194 == env23195) = true)

def env23196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437625,272393,441641,41310,8192,65,316532,436264,17665,32040,440429,156012,256,21792,46092,442168]

theorem envBound23196 : H12AffineFastState.Bounded env23196 := by
  intro p hp
  have h : env23196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23195_23196 : H12AffineEnvironment.transform 6 8 env23195 = env23196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23195 == env23196) = true)

theorem identity23196 : scanCanonicalize (H12AffineFastState.compose env23196 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound23196 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env23197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1024,32769,276584,272393,272440,41310,8192,65,316532,277817,17665,32040,273788,62589,256,21792,46092,272937]

theorem envBound23197 : H12AffineFastState.Bounded env23197 := by
  intro p hp
  have h : env23197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23196_23197 : H12AffineEnvironment.transform 16 38161 env23196 = env23197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23196 == env23197) = true)

def env23198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437624,272392,441640,41311,8193,65,316533,436265,17665,32041,440429,156012,256,21792,46093,442169]

theorem envBound23198 : H12AffineFastState.Bounded env23198 := by
  intro p hp
  have h : env23198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23195_23198 : H12AffineEnvironment.transform 6 9 env23195 = env23198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23195 == env23198) = true)

theorem identity23198 : scanCanonicalize (H12AffineFastState.compose env23198 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound23198 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env23199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,262144,1024,32769,301364,272392,297316,41311,8193,65,316533,302181,17665,32041,298017,21792,256,21792,46093,297845]

theorem envBound23199 : H12AffineFastState.Bounded env23199 := by
  intro p hp
  have h : env23199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23198_23199 : H12AffineEnvironment.transform 16 13388 env23198 = env23199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env23198 == env23199) = true)

theorem identity23199 : scanCanonicalize (H12AffineFastState.compose env23199 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound23199 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env23200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8202,13388,262144,1024,32769,301364,272392,297316,41311,8193,65,294913,302181,4469,10589,298017,340,256,340,46093,297845]

theorem envBound23200 : H12AffineFastState.Bounded env23200 := by
  intro p hp
  have h : env23200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23199_23200 : H12AffineEnvironment.transform 13 5236 env23199 = env23200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env23199 == env23200) = true)

theorem identity23200 : scanCanonicalize (H12AffineFastState.compose env23200 (packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound23200 : packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env23201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8202,13388,35188,1024,32769,4160,41340,16,41311,8193,65,2421,5393,4469,10589,1365,340,256,340,46093,513]

theorem envBound23201 : H12AffineFastState.Bounded env23201 := by
  intro p hp
  have h : env23201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23200_23201 : H12AffineEnvironment.transform 17 35188 env23200 = env23201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env23200 == env23201) = true)

theorem identity23201 : scanCanonicalize (H12AffineFastState.compose env23201 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound23201 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5236,32768,1095,4097,35188,1024,32769,4160,34097,16,34066,1100,65,2421,5393,4469,3344,1365,340,256,340,36928,513]

theorem envBound23202 : H12AffineFastState.Bounded env23202 := by
  intro p hp
  have h : env23202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23201_23202 : H12AffineEnvironment.transform 12 1101 env23201 = env23202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env23201 == env23202) = true)

theorem identity23202 : scanCanonicalize (H12AffineFastState.compose env23202 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6453) := by decide +kernel

theorem selectedBound23202 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env23203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5236,6453,1095,4097,4161,1024,6452,4160,7172,16,7207,1100,65,2421,5393,4469,3344,1365,340,256,340,2421,513]

theorem envBound23203 : H12AffineFastState.Bounded env23203 := by
  intro p hp
  have h : env23203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23202_23203 : H12AffineEnvironment.transform 14 6453 env23202 = env23203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6453 env23202 == env23203) = true)

theorem identity23203 : scanCanonicalize (H12AffineFastState.compose env23203 (packedSelected [0,3,4,5,6,7,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound23203 : packedSelected [0,3,4,5,6,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env23204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,1101,3173,292,1095,2064,2128,1024,293,2129,1045,16,1078,1100,65,2421,3328,2404,3344,1365,340,256,340,2421,513]

theorem envBound23204 : H12AffineFastState.Bounded env23204 := by
  intro p hp
  have h : env23204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23203_23204 : H12AffineEnvironment.transform 11 2065 env23203 = env23204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env23203 == env23204) = true)

theorem identity23204 : scanCanonicalize (H12AffineFastState.compose env23204 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23204 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env23205 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,2420,292,342,2064,2128,273,293,2129,260,16,295,349,65,2421,2065,2404,2049,68,340,256,340,2421,513]

theorem envBound23205 : H12AffineFastState.Bounded env23205 := by
  intro p hp
  have h : env23205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23204_23205 : H12AffineEnvironment.transform 9 273 env23204 = env23205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23204 == env23205) = true)

theorem identity23205 : scanCanonicalize (H12AffineFastState.compose env23205 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23205 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env23206 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2341,292,263,2064,2049,273,293,2048,260,16,295,268,16,2340,2065,2357,2049,21,261,256,261,2340,513]

theorem envBound23206 : H12AffineFastState.Bounded env23206 := by
  intro p hp
  have h : env23206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23205_23206 : H12AffineEnvironment.transform 5 17 env23205 = env23206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23205 == env23206) = true)

def env23207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound23207 : H12AffineFastState.Bounded env23207 := by
  intro p hp
  have h : env23207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22997_23207 : H12AffineEnvironment.transform 18 1025 env22997 = env23207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22997 == env23207) = true)

theorem identity23207 : scanCanonicalize (H12AffineFastState.compose env23207 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833264) := by decide +kernel

theorem selectedBound23207 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833264,8328,65,6458737,8702460,10507601,8830976,2410848,12855472,257,297437,288888,2485942]

theorem envBound23208 : H12AffineFastState.Bounded env23208 := by
  intro p hp
  have h : env23208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23207_23208 : H12AffineEnvironment.transform 23 10833264 env23207 = env23208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833264 env23207 == env23208) = true)

def env23209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458737,8393984,10507601,8527100,2102684,12645452,257,21793,46212,2175562]

theorem envBound23209 : H12AffineFastState.Bounded env23209 := by
  intro p hp
  have h : env23209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23208_23209 : H12AffineEnvironment.transform 17 56572 env23208 = env23209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env23208 == env23209) = true)

def env23210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,8388608,8487372,8328,65,4365617,8393984,8406289,8527100,1500,12645452,257,21793,46212,74250]

theorem envBound23210 : H12AffineFastState.Bounded env23210 := by
  intro p hp
  have h : env23210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23209_23210 : H12AffineEnvironment.transform 20 4160 env23209 = env23210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23209 == env23210) = true)

def env23211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,16,98780,8328,65,4365617,5392,17665,138476,1500,4256860,257,21793,46212,74250]

theorem envBound23211 : H12AffineFastState.Bounded env23211 := by
  intro p hp
  have h : env23211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23210_23211 : H12AffineEnvironment.transform 22 16 env23210 = env23211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23210 == env23211) = true)

theorem identity23211 : scanCanonicalize (H12AffineFastState.compose env23211 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound23211 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,119927,16,98780,8328,65,215366,5392,17665,138476,1500,73771,257,21793,46212,74250]

theorem envBound23212 : H12AffineFastState.Bounded env23212 := by
  intro p hp
  have h : env23212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23211_23212 : H12AffineEnvironment.transform 21 119927 env23211 = env23212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env23211 == env23212) = true)

theorem identity23212 : scanCanonicalize (H12AffineFastState.compose env23212 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23212 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env23213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56572,1025,32769,4160,119927,16,98780,8328,65,10588,5392,17665,97526,1500,73771,257,21793,46212,74250]

theorem envBound23213 : H12AffineFastState.Bounded env23213 := by
  intro p hp
  have h : env23213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23212_23213 : H12AffineEnvironment.transform 16 90138 env23212 = env23213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23212 == env23213) = true)

def env23214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56436,1025,32769,4160,119927,16,98644,8192,65,10588,5392,17665,97406,1364,73771,257,21793,46092,74250]

theorem envBound23214 : H12AffineFastState.Bounded env23214 := by
  intro p hp
  have h : env23214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23213_23214 : H12AffineEnvironment.transform 6 8 env23213 = env23214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23213 == env23214) = true)

theorem identity23214 : scanCanonicalize (H12AffineFastState.compose env23214 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound23214 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,5393,56436,1025,32769,4160,41340,16,62559,8192,65,10588,5392,17665,2421,1364,21792,257,21793,46092,22273]

theorem envBound23215 : H12AffineFastState.Bounded env23215 := by
  intro p hp
  have h : env23215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23214_23215 : H12AffineEnvironment.transform 15 29963 env23214 = env23215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env23214 == env23215) = true)

theorem identity23215 : scanCanonicalize (H12AffineFastState.compose env23215 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23215 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23216 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29823,5221,56436,1025,32769,4160,40968,16,62559,8192,65,10280,5220,17525,2049,1056,21588,117,21589,46092,22133]

theorem envBound23216 : H12AffineFastState.Bounded env23216 := by
  intro p hp
  have h : env23216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23215_23216 : H12AffineEnvironment.transform 7 116 env23215 = env23216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23215 == env23216) = true)

theorem identity23216 : scanCanonicalize (H12AffineFastState.compose env23216 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound23216 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23217 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21540,29823,5221,2128,1025,21541,4160,29740,16,8315,8192,65,10280,5220,17525,2049,1056,21588,117,21589,24616,22133]

theorem envBound23217 : H12AffineFastState.Bounded env23217 := by
  intro p hp
  have h : env23217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23216_23217 : H12AffineEnvironment.transform 14 21540 env23216 = env23217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env23216 == env23217) = true)

def env23218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56437,1025,32769,4160,119927,16,98645,8193,65,10588,5392,17665,97407,1365,73771,257,21793,46093,74250]

theorem envBound23218 : H12AffineFastState.Bounded env23218 := by
  intro p hp
  have h : env23218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23213_23218 : H12AffineEnvironment.transform 6 9 env23213 = env23218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23213 == env23218) = true)

theorem identity23218 : scanCanonicalize (H12AffineFastState.compose env23218 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound23218 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46157,56437,1025,32769,4160,32,16,21762,8193,65,10588,5392,17665,43048,1365,62588,257,21793,46093,63069]

theorem envBound23219 : H12AffineFastState.Bounded env23219 := by
  intro p hp
  have h : env23219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23218_23219 : H12AffineEnvironment.transform 15 54359 env23218 = env23219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env23218 == env23219) = true)

theorem identity23219 : scanCanonicalize (H12AffineFastState.compose env23219 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound23219 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env23220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21511,13341,23589,1025,81,4160,32,16,21762,8193,65,10588,5392,17665,10360,1365,29740,257,21793,13405,30221]

theorem envBound23220 : H12AffineFastState.Bounded env23220 := by
  intro p hp
  have h : env23220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23219_23220 : H12AffineEnvironment.transform 14 80 env23219 = env23220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env23219 == env23220) = true)

theorem identity23220 : scanCanonicalize (H12AffineFastState.compose env23220 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23220 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env23221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,262,13341,2340,1025,81,4160,32,16,3,8193,65,10588,5392,4096,10360,1365,8493,257,32,13405,8972]

theorem envBound23221 : H12AffineFastState.Bounded env23221 := by
  intro p hp
  have h : env23221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23220_23221 : H12AffineEnvironment.transform 13 5377 env23220 = env23221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23220 == env23221) = true)

theorem identity23221 : scanCanonicalize (H12AffineFastState.compose env23221 (packedSelected [4,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound23221 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env23222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,5377,80,262,3328,2340,1025,81,4160,32,16,3,6428,65,4161,5392,4096,4453,1365,6192,257,32,3392,6673]

theorem envBound23222 : H12AffineFastState.Bounded env23222 := by
  intro p hp
  have h : env23222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23221_23222 : H12AffineEnvironment.transform 12 6429 env23221 = env23222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env23221 == env23222) = true)

theorem identity23222 : scanCanonicalize (H12AffineFastState.compose env23222 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound23222 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3392,80,262,3328,2340,1025,81,2049,32,16,3,349,65,2048,3409,2113,2340,1365,113,257,32,3392,592]

theorem envBound23223 : H12AffineFastState.Bounded env23223 := by
  intro p hp
  have h : env23223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23222_23223 : H12AffineEnvironment.transform 11 2113 env23222 = env23223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env23222 == env23223) = true)

theorem identity23223 : scanCanonicalize (H12AffineFastState.compose env23223 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23223 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23224 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2113,41,3125,80,115,3189,2129,1025,81,2049,32,16,3,40,65,2048,3108,2113,2129,1056,113,116,32,3125,592]

theorem envBound23224 : H12AffineFastState.Bounded env23224 := by
  intro p hp
  have h : env23224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23223_23224 : H12AffineEnvironment.transform 7 117 env23223 = env23224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23223 == env23224) = true)

theorem identity23224 : scanCanonicalize (H12AffineFastState.compose env23224 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23224 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env23225 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2065,41,3125,0,35,3109,2049,1025,1,2049,32,16,3,40,17,2048,3108,2065,2049,1056,33,36,32,3125,512]

theorem envBound23225 : H12AffineFastState.Bounded env23225 := by
  intro p hp
  have h : env23225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23224_23225 : H12AffineEnvironment.transform 5 16 env23224 = env23225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23224 == env23225) = true)

theorem identity23225 : scanCanonicalize (H12AffineFastState.compose env23225 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound23225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23226 : List Nat := [2,4,8,16,32,16,9,37,512,21,2048,2065,41,2080,0,35,2096,2049,20,1,2049,32,16,3,40,17,2048,2097,2065,2049,53,33,36,32,2080,512]

theorem envBound23226 : H12AffineFastState.Bounded env23226 := by
  intro p hp
  have h : env23226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23225_23226 : H12AffineEnvironment.transform 9 21 env23225 = env23226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23225 == env23226) = true)

theorem identity23226 : scanCanonicalize (H12AffineFastState.compose env23226 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound23226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23227 : List Nat := [2,4,8,16,32,16,9,37,512,21,554,571,41,522,0,35,538,555,20,1,555,32,16,3,40,17,554,539,571,555,53,33,36,32,522,512]

theorem envBound23227 : H12AffineFastState.Bounded env23227 := by
  intro p hp
  have h : env23227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23226_23227 : H12AffineEnvironment.transform 10 554 env23226 = env23227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env23226 == env23227) = true)

theorem identity23227 : scanCanonicalize (H12AffineFastState.compose env23227 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound23227 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23228 : List Nat := [2,4,8,16,24,16,9,29,512,21,530,515,17,522,0,27,538,531,20,1,531,24,16,3,16,17,530,539,515,531,13,25,28,24,522,512]

theorem envBound23228 : H12AffineFastState.Bounded env23228 := by
  intro p hp
  have h : env23228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23227_23228 : H12AffineEnvironment.transform 4 24 env23227 = env23228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env23227 == env23228) = true)

theorem identity23228 : scanCanonicalize (H12AffineFastState.compose env23228 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound23228 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23229 : List Nat := [2,4,8,8,0,8,9,5,512,13,522,515,9,522,0,3,514,523,12,1,523,0,8,3,8,9,522,515,515,523,13,1,4,0,522,512]

theorem envBound23229 : H12AffineFastState.Bounded env23229 := by
  intro p hp
  have h : env23229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23228_23229 : H12AffineEnvironment.transform 3 8 env23228 = env23229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env23228 == env23229) = true)

theorem identity23229 : scanCanonicalize (H12AffineFastState.compose env23229 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound23229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23230 : List Nat := [2,4,8,8,0,8,9,5,6,13,12,5,9,12,0,3,4,13,12,1,13,0,8,3,8,9,12,5,5,13,13,1,4,0,12,6]

theorem envBound23230 : H12AffineFastState.Bounded env23230 := by
  intro p hp
  have h : env23230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23229_23230 : H12AffineEnvironment.transform 8 6 env23229 = env23230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env23229 == env23230) = true)

def env23231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,17,98781,8328,65,4365617,5393,17664,138477,1500,4256861,257,21793,46212,74250]

theorem envBound23231 : H12AffineFastState.Bounded env23231 := by
  intro p hp
  have h : env23231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23210_23231 : H12AffineEnvironment.transform 22 17 env23210 = env23231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23210 == env23231) = true)

theorem identity23231 : scanCanonicalize (H12AffineFastState.compose env23231 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound23231 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,56572,1025,32769,4160,4194304,17,21763,8328,65,4365617,5393,17664,138477,1500,4256861,257,21793,46212,63188]

theorem envBound23232 : H12AffineFastState.Bounded env23232 := by
  intro p hp
  have h : env23232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23231_23232 : H12AffineEnvironment.transform 15 54494 env23231 = env23232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env23231 == env23232) = true)

theorem identity23232 : scanCanonicalize (H12AffineFastState.compose env23232 (packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23232 : packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env23233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8322,131072,10400,1025,29789,4160,4194304,17,21763,8328,65,4352365,5393,17664,138477,1500,4194305,257,21793,16600,648]

theorem envBound23233 : H12AffineFastState.Bounded env23233 := by
  intro p hp
  have h : env23233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23232_23233 : H12AffineEnvironment.transform 14 29788 env23232 = env23233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23232 == env23233) = true)

theorem identity23233 : scanCanonicalize (H12AffineFastState.compose env23233 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23233 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env23234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,4194304,17,21763,8193,65,4352365,5393,17664,138340,1365,4194305,257,21793,16465,513]

theorem envBound23234 : H12AffineFastState.Bounded env23234 := by
  intro p hp
  have h : env23234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23233_23234 : H12AffineEnvironment.transform 6 9 env23233 = env23234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23233 == env23234) = true)

theorem identity23234 : scanCanonicalize (H12AffineFastState.compose env23234 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound23234 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env23235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,136496,17,21763,8193,65,31837,5393,17664,138340,1365,136497,257,21793,16465,513]

theorem envBound23235 : H12AffineFastState.Bounded env23235 := by
  intro p hp
  have h : env23235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23234_23235 : H12AffineEnvironment.transform 21 136496 env23234 = env23235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env23234 == env23235) = true)

theorem identity23235 : scanCanonicalize (H12AffineFastState.compose env23235 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23235 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16401,10281,1025,29789,4160,21793,17,21763,8193,65,31837,5393,17664,23669,1365,21792,257,21793,16465,513]

theorem envBound23236 : H12AffineFastState.Bounded env23236 := by
  intro p hp
  have h : env23236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23235_23236 : H12AffineEnvironment.transform 16 16401 env23235 = env23236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23235 == env23236) = true)

theorem identity23236 : scanCanonicalize (H12AffineFastState.compose env23236 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23236 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env23237 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8203,16401,10281,1025,29709,4112,21793,17,21763,8193,17,31757,5393,17664,23589,1285,21792,257,21793,16385,513]

theorem envBound23237 : H12AffineFastState.Bounded env23237 := by
  intro p hp
  have h : env23237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23236_23237 : H12AffineEnvironment.transform 5 16 env23236 = env23237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23236 == env23237) = true)

theorem identity23237 : scanCanonicalize (H12AffineFastState.compose env23237 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23237 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23238 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,262,16401,2340,1025,21760,4112,21793,17,21763,268,17,23808,5393,17664,23589,1285,21792,257,21793,16385,513]

theorem envBound23238 : H12AffineFastState.Bounded env23238 := by
  intro p hp
  have h : env23238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23237_23238 : H12AffineEnvironment.transform 12 269 env23237 = env23238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23237 == env23238) = true)

theorem identity23238 : scanCanonicalize (H12AffineFastState.compose env23238 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23238 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23239 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4112,32,17,2,268,17,2049,5393,4097,2340,1285,33,257,32,5376,513]

theorem envBound23239 : H12AffineFastState.Bounded env23239 := by
  intro p hp
  have h : env23239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23238_23239 : H12AffineEnvironment.transform 13 5377 env23238 = env23239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23238 == env23239) = true)

theorem identity23239 : scanCanonicalize (H12AffineFastState.compose env23239 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound23239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23240 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,56,5172,0,51,5157,2065,1025,1,4112,32,17,2,57,17,2049,5156,4097,2065,1072,33,52,32,5173,513]

theorem envBound23240 : H12AffineFastState.Bounded env23240 := by
  intro p hp
  have h : env23240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23239_23240 : H12AffineEnvironment.transform 7 53 env23239 = env23240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env23239 == env23240) = true)

theorem identity23240 : scanCanonicalize (H12AffineFastState.compose env23240 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound23240 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23241 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,1572,56,528,0,51,513,2065,1025,1,1588,32,17,2,57,17,2049,512,1573,2065,1072,33,52,32,529,513]

theorem envBound23241 : H12AffineFastState.Bounded env23241 := by
  intro p hp
  have h : env23241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23240_23241 : H12AffineEnvironment.transform 11 1572 env23240 = env23241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env23240 == env23241) = true)

theorem identity23241 : scanCanonicalize (H12AffineFastState.compose env23241 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound23241 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23242 : List Nat := [2,4,8,16,32,16,9,53,512,565,2048,17,56,528,0,51,513,2065,564,1,1,32,17,2,57,17,2049,512,16,2065,517,33,52,32,529,513]

theorem envBound23242 : H12AffineFastState.Bounded env23242 := by
  intro p hp
  have h : env23242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23241_23242 : H12AffineEnvironment.transform 9 565 env23241 = env23242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env23241 == env23242) = true)

def env23243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,8388608,8487373,8328,65,4365616,8393984,8406288,8527100,1501,12645452,257,21793,46212,74251]

theorem envBound23243 : H12AffineFastState.Bounded env23243 := by
  intro p hp
  have h : env23243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23209_23243 : H12AffineEnvironment.transform 20 4161 env23209 = env23243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23209 == env23243) = true)

def env23244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,16,98781,8328,65,4365616,5392,17664,138476,1501,4256860,257,21793,46212,74251]

theorem envBound23244 : H12AffineFastState.Bounded env23244 := by
  intro p hp
  have h : env23244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23243_23244 : H12AffineEnvironment.transform 22 16 env23243 = env23244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23243 == env23244) = true)

theorem identity23244 : scanCanonicalize (H12AffineFastState.compose env23244 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound23244 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,73891,16,98781,8328,65,245139,5392,17664,138476,1501,120063,257,21793,46212,74251]

theorem envBound23245 : H12AffineFastState.Bounded env23245 := by
  intro p hp
  have h : env23245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23244_23245 : H12AffineEnvironment.transform 21 73891 env23244 = env23245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env23244 == env23245) = true)

def env23246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,73771,16,98645,8192,65,245019,5392,17664,138340,1365,119927,257,21793,46092,74251]

theorem envBound23246 : H12AffineFastState.Bounded env23246 := by
  intro p hp
  have h : env23246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23245_23246 : H12AffineEnvironment.transform 6 8 env23245 = env23246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23245 == env23246) = true)

theorem identity23246 : scanCanonicalize (H12AffineFastState.compose env23246 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound23246 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,56436,1025,32769,4161,21793,16,62559,8192,65,182289,5392,17664,138340,1365,41341,257,21793,46092,22273]

theorem envBound23247 : H12AffineFastState.Bounded env23247 := by
  intro p hp
  have h : env23247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23246_23247 : H12AffineEnvironment.transform 15 29962 env23246 = env23247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env23246 == env23247) = true)

theorem identity23247 : scanCanonicalize (H12AffineFastState.compose env23247 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound23247 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env23248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16400,56436,1025,32769,4161,21793,16,62559,8192,65,34817,5392,17664,23668,1365,41341,257,21793,46092,22273]

theorem envBound23248 : H12AffineFastState.Bounded env23248 := by
  intro p hp
  have h : env23248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23247_23248 : H12AffineEnvironment.transform 16 16400 env23247 = env23248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23247 == env23248) = true)

theorem identity23248 : scanCanonicalize (H12AffineFastState.compose env23248 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23248 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,5392,35188,1025,32769,4161,33,16,41311,8192,65,34817,5392,4096,2420,1365,41341,257,33,46092,513]

theorem envBound23249 : H12AffineFastState.Bounded env23249 := by
  intro p hp
  have h : env23249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23248_23249 : H12AffineEnvironment.transform 13 5376 env23248 = env23249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23248 == env23249) = true)

theorem identity23249 : scanCanonicalize (H12AffineFastState.compose env23249 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound23249 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,9293,8202,5392,11577,1025,9292,4161,33,16,1298,8192,65,11340,5392,4096,2420,1365,1328,257,33,4161,513]

theorem envBound23250 : H12AffineFastState.Bounded env23250 := by
  intro p hp
  have h : env23250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23249_23250 : H12AffineEnvironment.transform 14 9293 env23249 = env23250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env23249 == env23250) = true)

theorem identity23250 : scanCanonicalize (H12AffineFastState.compose env23250 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound23250 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1124,8192,356,9293,8202,372,11577,1025,9292,1061,33,16,1298,8192,65,11340,372,1124,2420,1365,1328,257,33,1061,513]

theorem envBound23251 : H12AffineFastState.Bounded env23251 := by
  intro p hp
  have h : env23251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23250_23251 : H12AffineEnvironment.transform 11 1124 env23250 = env23251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env23250 == env23251) = true)

def env23252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,73770,16,98644,8193,65,245018,5392,17664,138341,1364,119926,257,21793,46093,74251]

theorem envBound23252 : H12AffineFastState.Bounded env23252 := by
  intro p hp
  have h : env23252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23245_23252 : H12AffineEnvironment.transform 6 9 env23245 = env23252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23245 == env23252) = true)

theorem identity23252 : scanCanonicalize (H12AffineFastState.compose env23252 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56437,1025,32769,4161,62588,16,21762,8193,65,158028,5392,17664,138341,1364,32,257,21793,46093,63069]

theorem envBound23253 : H12AffineFastState.Bounded env23253 := by
  intro p hp
  have h : env23253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23252_23253 : H12AffineEnvironment.transform 15 54358 env23252 = env23253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23252 == env23253) = true)

theorem identity23253 : scanCanonicalize (H12AffineFastState.compose env23253 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound23253 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16400,56437,1025,32769,4161,62588,16,21762,8193,65,10588,5392,17664,23669,1364,32,257,21793,46093,63069]

theorem envBound23254 : H12AffineFastState.Bounded env23254 := by
  intro p hp
  have h : env23254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23253_23254 : H12AffineEnvironment.transform 16 16400 env23253 = env23254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23253 == env23254) = true)

theorem identity23254 : scanCanonicalize (H12AffineFastState.compose env23254 (packedSelected [2,3,5,6,14,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23254 : packedSelected [2,3,5,6,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env23255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,33030,5440,35109,1025,32769,4161,41260,16,82,8193,65,10588,5392,4176,2341,1364,32,257,113,46093,41741]

theorem envBound23255 : H12AffineFastState.Bounded env23255 := by
  intro p hp
  have h : env23255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23254_23255 : H12AffineEnvironment.transform 13 5456 env23254 = env23255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23254 == env23255) = true)

theorem identity23255 : scanCanonicalize (H12AffineFastState.compose env23255 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23255 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,33030,5440,35109,1025,32769,4161,32801,16,82,268,65,2129,5392,4176,2341,1364,32,257,113,38144,33280]

theorem envBound23256 : H12AffineFastState.Bounded env23256 := by
  intro p hp
  have h : env23256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23255_23256 : H12AffineEnvironment.transform 12 269 env23255 = env23256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23255 == env23256) = true)

theorem identity23256 : scanCanonicalize (H12AffineFastState.compose env23256 (packedSelected [0,2,3,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6209) := by decide +kernel

theorem selectedBound23256 : packedSelected [0,2,3,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,6209,6471,5440,4452,1025,6208,4161,6240,16,82,268,65,2129,5392,4176,2341,1364,32,257,113,3393,6721]

theorem envBound23257 : H12AffineFastState.Bounded env23257 := by
  intro p hp
  have h : env23257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23256_23257 : H12AffineEnvironment.transform 14 6209 env23256 = env23257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6209 env23256 == env23257) = true)

theorem identity23257 : scanCanonicalize (H12AffineFastState.compose env23257 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound23257 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,269,3344,1,263,3328,2340,1025,0,2049,32,16,82,268,65,2129,3408,2064,2341,1364,32,257,113,3393,513]

theorem envBound23258 : H12AffineFastState.Bounded env23258 := by
  intro p hp
  have h : env23258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23257_23258 : H12AffineEnvironment.transform 11 2112 env23257 = env23258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env23257 == env23258) = true)

theorem identity23258 : scanCanonicalize (H12AffineFastState.compose env23258 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23258 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env23259 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,269,3344,1,263,3328,2340,1025,0,2049,32,16,2,268,17,2049,3328,2064,2341,1284,32,257,33,3345,513]

theorem envBound23259 : H12AffineFastState.Bounded env23259 := by
  intro p hp
  have h : env23259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23258_23259 : H12AffineEnvironment.transform 5 16 env23258 = env23259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23258 == env23259) = true)

theorem identity23259 : scanCanonicalize (H12AffineFastState.compose env23259 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound23259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23260 : List Nat := [2,4,8,16,32,16,9,256,512,1024,277,261,269,1029,1,263,1045,49,1025,0,276,32,16,2,268,17,276,1045,261,48,1284,32,257,33,1028,513]

theorem envBound23260 : H12AffineFastState.Bounded env23260 := by
  intro p hp
  have h : env23260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23259_23260 : H12AffineEnvironment.transform 10 277 env23259 = env23260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env23259 == env23260) = true)

theorem identity23260 : scanCanonicalize (H12AffineFastState.compose env23260 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound23260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23261 : List Nat := [2,4,8,16,32,16,9,256,512,564,277,261,269,561,1,263,545,49,565,0,276,32,16,2,268,17,276,545,261,48,816,32,257,33,560,513]

end H12CloudChart0