import H12CloudChart0Data110

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound28134 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,41461,17,98644,8328,64,439728,5393,4233,431376,1364,169,256,33,46212,74370]

theorem envBound28135 : H12AffineFastState.Bounded env28135 := by
  intro p hp
  have h : env28135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28134_28135 : H12AffineEnvironment.transform 21 41461 env28134 = env28135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41461 env28134 == env28135) = true)

def env28136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,41341,17,98644,8192,64,439608,5393,4097,431376,1364,33,256,33,46092,74250]

theorem envBound28136 : H12AffineFastState.Bounded env28136 := by
  intro p hp
  have h : env28136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28135_28136 : H12AffineEnvironment.transform 6 8 env28135 = env28136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28135 == env28136) = true)

theorem identity28136 : scanCanonicalize (H12AffineFastState.compose env28136 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound28136 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67618,1024,32769,4160,41341,17,98644,8192,64,245018,5393,4097,236850,1364,33,256,33,46092,74250]

theorem envBound28137 : H12AffineFastState.Bounded env28137 := by
  intro p hp
  have h : env28137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28136_28137 : H12AffineEnvironment.transform 17 67618 env28136 = env28137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env28136 == env28137) = true)

theorem identity28137 : scanCanonicalize (H12AffineFastState.compose env28137 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound28137 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46108,67618,1024,32769,4160,41341,17,98644,8192,64,67846,5393,4097,76078,1364,33,256,33,46092,74250]

theorem envBound28138 : H12AffineFastState.Bounded env28138 := by
  intro p hp
  have h : env28138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28137_28138 : H12AffineEnvironment.transform 16 46108 env28137 = env28138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env28137 == env28138) = true)

theorem identity28138 : scanCanonicalize (H12AffineFastState.compose env28138 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28138 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env28139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,65536,38161,67618,1024,32769,4160,32880,17,98644,269,64,67846,5393,4097,67619,1364,33,256,33,38145,66311]

theorem envBound28139 : H12AffineFastState.Bounded env28139 := by
  intro p hp
  have h : env28139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28138_28139 : H12AffineEnvironment.transform 12 269 env28138 = env28139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28138 == env28139) = true)

theorem identity28139 : scanCanonicalize (H12AffineFastState.compose env28139 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound28139 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env28140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,65536,5441,67618,1024,81,4160,32,17,65796,269,64,67846,5393,4097,67619,1364,33,256,33,5457,66311]

theorem envBound28140 : H12AffineFastState.Bounded env28140 := by
  intro p hp
  have h : env28140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28139_28140 : H12AffineEnvironment.transform 14 80 env28139 = env28140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env28139 == env28140) = true)

theorem identity28140 : scanCanonicalize (H12AffineFastState.compose env28140 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound28140 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,1874,5441,3952,1024,81,4160,32,17,1622,269,64,3668,5393,4097,3953,1364,33,256,33,5457,1109]

theorem envBound28141 : H12AffineFastState.Bounded env28141 := by
  intro p hp
  have h : env28141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28140_28141 : H12AffineEnvironment.transform 15 1874 env28140 = env28141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env28140 == env28141) = true)

theorem identity28141 : scanCanonicalize (H12AffineFastState.compose env28141 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 848) := by decide +kernel

theorem selectedBound28141 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28142 : List Nat := [2,4,8,16,32,64,8,256,512,848,2048,4096,269,4689,80,2,4625,2080,848,81,4160,32,17,262,269,64,2308,4673,4097,2081,516,33,256,33,4609,773]

theorem envBound28142 : H12AffineFastState.Bounded env28142 := by
  intro p hp
  have h : env28142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28141_28142 : H12AffineEnvironment.transform 9 848 env28141 = env28142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 848 env28141 == env28142) = true)

theorem identity28142 : scanCanonicalize (H12AffineFastState.compose env28142 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28142 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28143 : List Nat := [2,4,8,16,32,17,8,256,512,769,2048,4096,269,4608,1,2,4625,2080,769,0,4113,32,17,262,269,17,2308,4624,4097,2081,516,33,256,33,4609,773]

theorem envBound28143 : H12AffineFastState.Bounded env28143 := by
  intro p hp
  have h : env28143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28142_28143 : H12AffineEnvironment.transform 5 17 env28142 = env28143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28142 == env28143) = true)

theorem identity28143 : scanCanonicalize (H12AffineFastState.compose env28143 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound28143 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env28144 : List Nat := [2,4,8,16,32,17,8,256,512,769,2048,292,269,804,1,2,821,2080,769,0,309,32,17,262,269,17,2308,820,293,2081,516,33,256,33,805,773]

theorem envBound28144 : H12AffineFastState.Bounded env28144 := by
  intro p hp
  have h : env28144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28143_28144 : H12AffineEnvironment.transform 11 292 env28143 = env28144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env28143 == env28144) = true)

theorem identity28144 : scanCanonicalize (H12AffineFastState.compose env28144 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28144 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env28145 : List Nat := [2,4,8,16,1,17,8,256,512,769,2048,261,269,773,1,2,788,2049,769,0,276,1,17,262,269,17,2308,789,260,2048,516,0,256,0,772,773]

theorem envBound28145 : H12AffineFastState.Bounded env28145 := by
  intro p hp
  have h : env28145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28144_28145 : H12AffineEnvironment.transform 4 1 env28144 = env28145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28144 == env28145) = true)

theorem identity28145 : scanCanonicalize (H12AffineFastState.compose env28145 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound28145 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env28146 : List Nat := [2,4,8,16,1,17,8,256,512,769,512,261,269,773,1,2,788,513,769,0,276,1,17,262,269,17,772,789,260,512,516,0,256,0,772,773]

theorem envBound28146 : H12AffineFastState.Bounded env28146 := by
  intro p hp
  have h : env28146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28145_28146 : H12AffineEnvironment.transform 10 512 env28145 = env28146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env28145 == env28146) = true)

theorem identity28146 : scanCanonicalize (H12AffineFastState.compose env28146 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound28146 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28147 : List Nat := [2,4,8,16,1,17,8,256,260,5,260,261,269,1,1,2,16,261,5,0,276,1,17,262,269,17,0,17,260,260,256,0,256,0,0,1]

theorem envBound28147 : H12AffineFastState.Bounded env28147 := by
  intro p hp
  have h : env28147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28146_28147 : H12AffineEnvironment.transform 8 260 env28146 = env28147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env28146 == env28147) = true)

theorem identity28147 : scanCanonicalize (H12AffineFastState.compose env28147 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28147 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28148 : List Nat := [2,4,8,0,1,1,8,256,260,5,260,261,269,1,1,2,0,261,5,0,260,1,1,262,269,1,0,1,260,260,256,0,256,0,0,1]

theorem envBound28148 : H12AffineFastState.Bounded env28148 := by
  intro p hp
  have h : env28148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28147_28148 : H12AffineEnvironment.transform 3 0 env28147 = env28148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28147 == env28148) = true)

theorem identity28148 : scanCanonicalize (H12AffineFastState.compose env28148 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28149 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,0,8,1,1,2,0,0,5,0,1,1,1,3,8,1,0,1,1,1,5,0,5,0,0,1]

theorem envBound28149 : H12AffineFastState.Bounded env28149 := by
  intro p hp
  have h : env28149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28148_28149 : H12AffineEnvironment.transform 7 5 env28148 = env28149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28148 == env28149) = true)

theorem identity28149 : scanCanonicalize (H12AffineFastState.compose env28149 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound28149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28150 : List Nat := [2,4,7,0,1,1,7,5,1,5,1,0,7,1,1,2,0,0,5,0,1,1,1,3,7,1,0,1,1,1,5,0,5,0,0,1]

theorem envBound28150 : H12AffineFastState.Bounded env28150 := by
  intro p hp
  have h : env28150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28149_28150 : H12AffineEnvironment.transform 2 7 env28149 = env28150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env28149 == env28150) = true)

def env28151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,41340,17,98644,8193,64,439609,5393,4096,431376,1364,32,256,33,46093,74251]

theorem envBound28151 : H12AffineFastState.Bounded env28151 := by
  intro p hp
  have h : env28151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28135_28151 : H12AffineEnvironment.transform 6 9 env28135 = env28151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28135 == env28151) = true)

theorem identity28151 : scanCanonicalize (H12AffineFastState.compose env28151 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound28151 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,4161,41340,17,98644,8193,64,203847,5393,4096,212078,1364,32,256,33,46093,74251]

theorem envBound28152 : H12AffineFastState.Bounded env28152 := by
  intro p hp
  have h : env28152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28151_28152 : H12AffineEnvironment.transform 17 108926 env28151 = env28152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env28151 == env28152) = true)

theorem identity28152 : scanCanonicalize (H12AffineFastState.compose env28152 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound28152 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28153 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,108926,1024,32769,4161,41340,17,98644,8193,64,10589,5393,4096,2420,1364,32,256,33,46093,74251]

theorem envBound28153 : H12AffineFastState.Bounded env28153 := by
  intro p hp
  have h : env28153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28152_28153 : H12AffineEnvironment.transform 16 79130 env28152 = env28153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env28152 == env28153) = true)

theorem identity28153 : scanCanonicalize (H12AffineFastState.compose env28153 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound28153 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,35,13625,43357,1024,32769,4161,41340,17,33143,8193,64,10589,5393,4096,2420,1364,32,256,33,46093,8744]

theorem envBound28154 : H12AffineFastState.Bounded env28154 := by
  intro p hp
  have h : env28154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28153_28154 : H12AffineEnvironment.transform 15 35 env28153 = env28154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env28153 == env28154) = true)

theorem identity28154 : scanCanonicalize (H12AffineFastState.compose env28154 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound28154 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env28155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,35,5393,35189,1024,32769,4161,33108,17,33143,41,64,2421,5393,4096,2420,1364,32,256,33,37925,512]

theorem envBound28155 : H12AffineFastState.Bounded env28155 := by
  intro p hp
  have h : env28155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28154_28155 : H12AffineEnvironment.transform 12 40 env28154 = env28155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env28154 == env28155) = true)

theorem identity28155 : scanCanonicalize (H12AffineFastState.compose env28155 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28155 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28156 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5157,32768,35,5173,34897,1024,32769,4161,32880,17,32851,41,64,2129,5173,4096,2128,1136,32,36,33,37925,512]

theorem envBound28156 : H12AffineFastState.Bounded env28156 := by
  intro p hp
  have h : env28156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28155_28156 : H12AffineEnvironment.transform 7 36 env28155 = env28156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28155 == env28156) = true)

theorem identity28156 : scanCanonicalize (H12AffineFastState.compose env28156 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 5733) := by decide +kernel

theorem selectedBound28156 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env28157 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5157,5733,35,5173,7732,1024,5732,4161,5653,17,5686,41,64,2129,5173,4096,2128,1136,32,36,33,576,512]

theorem envBound28157 : H12AffineFastState.Bounded env28157 := by
  intro p hp
  have h : env28157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28156_28157 : H12AffineEnvironment.transform 14 5733 env28156 = env28157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5733 env28156 == env28157) = true)

theorem identity28157 : scanCanonicalize (H12AffineFastState.compose env28157 (packedSelected [0,1,2,3,4,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound28157 : packedSelected [0,1,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env28158 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1124,40,65,513,35,81,2640,1024,512,1061,625,17,594,41,64,2129,81,1124,2128,1136,32,36,33,576,512]

theorem envBound28158 : H12AffineFastState.Bounded env28158 := by
  intro p hp
  have h : env28158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28157_28158 : H12AffineEnvironment.transform 11 1124 env28157 = env28158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env28157 == env28158) = true)

theorem identity28158 : scanCanonicalize (H12AffineFastState.compose env28158 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound28158 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env28159 : List Nat := [2,4,8,16,32,64,9,36,512,565,2048,593,40,65,513,35,81,2640,565,512,528,625,17,594,41,64,2129,81,593,2128,581,32,36,33,576,512]

theorem envBound28159 : H12AffineFastState.Bounded env28159 := by
  intro p hp
  have h : env28159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28158_28159 : H12AffineEnvironment.transform 9 565 env28158 = env28159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env28158 == env28159) = true)

theorem identity28159 : scanCanonicalize (H12AffineFastState.compose env28159 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28159 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28160 : List Nat := [2,4,8,16,32,48,9,36,512,565,2048,545,40,49,513,35,33,2592,565,512,528,513,17,546,41,48,2081,33,545,2080,565,32,36,33,560,512]

theorem envBound28160 : H12AffineFastState.Bounded env28160 := by
  intro p hp
  have h : env28160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28159_28160 : H12AffineEnvironment.transform 5 48 env28159 = env28160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28159 == env28160) = true)

theorem identity28160 : scanCanonicalize (H12AffineFastState.compose env28160 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28160 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28161 : List Nat := [2,4,8,16,1,17,9,5,512,532,2048,512,9,16,513,2,0,2561,532,512,528,513,17,515,8,17,2048,0,512,2049,532,1,5,0,529,512]

theorem envBound28161 : H12AffineFastState.Bounded env28161 := by
  intro p hp
  have h : env28161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28160_28161 : H12AffineEnvironment.transform 4 1 env28160 = env28161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28160 == env28161) = true)

theorem identity28161 : scanCanonicalize (H12AffineFastState.compose env28161 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28161 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env28162 : List Nat := [2,4,8,16,1,17,9,5,0,20,2048,0,9,16,1,2,0,2049,20,0,16,1,17,3,8,17,2048,0,0,2049,20,1,5,0,17,0]

theorem envBound28162 : H12AffineFastState.Bounded env28162 := by
  intro p hp
  have h : env28162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28161_28162 : H12AffineEnvironment.transform 8 0 env28161 = env28162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28161 == env28162) = true)

theorem identity28162 : scanCanonicalize (H12AffineFastState.compose env28162 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound28162 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28163 : List Nat := [2,4,8,14,1,15,9,5,0,10,2048,0,9,14,1,2,0,2049,10,0,14,1,15,3,8,15,2048,0,0,2049,10,1,5,0,15,0]

theorem envBound28163 : H12AffineFastState.Bounded env28163 := by
  intro p hp
  have h : env28163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28162_28163 : H12AffineEnvironment.transform 3 14 env28162 = env28163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env28162 == env28163) = true)

theorem identity28163 : scanCanonicalize (H12AffineFastState.compose env28163 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound28163 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28164 : List Nat := [2,4,8,14,1,15,9,5,0,10,15,0,9,14,1,2,0,14,10,0,14,1,15,3,8,15,15,0,0,14,10,1,5,0,15,0]

theorem envBound28164 : H12AffineFastState.Bounded env28164 := by
  intro p hp
  have h : env28164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28163_28164 : H12AffineEnvironment.transform 10 15 env28163 = env28164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env28163 == env28164) = true)

def env28165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21777,2213021,8328,64,6705549,16400,2097216,431377,2102685,4235612,256,21793,46213,2175563]

theorem envBound28165 : H12AffineFastState.Bounded env28165 := by
  intro p hp
  have h : env28165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28084_28165 : H12AffineEnvironment.transform 22 21777 env28084 = env28165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env28084 == env28165) = true)

def env28166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21777,98645,8328,64,4592709,16400,17800,431377,20565,4235612,256,21793,46213,96131]

theorem envBound28166 : H12AffineFastState.Bounded env28166 := by
  intro p hp
  have h : env28166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28165_28166 : H12AffineEnvironment.transform 20 17864 env28165 = env28166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env28165 == env28166) = true)

def env28167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,17,98645,8328,64,4592709,5392,4232,431377,1365,4235612,256,33,46213,74371]

theorem envBound28167 : H12AffineFastState.Bounded env28167 := by
  intro p hp
  have h : env28167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28166_28167 : H12AffineEnvironment.transform 13 5376 env28166 = env28167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28166 == env28167) = true)

theorem identity28167 : scanCanonicalize (H12AffineFastState.compose env28167 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound28167 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,73890,17,98645,8328,64,472295,5392,4232,431377,1365,98814,256,33,46213,74371]

theorem envBound28168 : H12AffineFastState.Bounded env28168 := by
  intro p hp
  have h : env28168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28167_28168 : H12AffineEnvironment.transform 21 73890 env28167 = env28168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env28167 == env28168) = true)

def env28169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,73770,17,98645,8192,64,472175,5392,4096,431377,1365,98678,256,33,46093,74251]

theorem envBound28169 : H12AffineFastState.Bounded env28169 := by
  intro p hp
  have h : env28169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28168_28169 : H12AffineEnvironment.transform 6 8 env28168 = env28169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28168 == env28169) = true)

theorem identity28169 : scanCanonicalize (H12AffineFastState.compose env28169 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound28169 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1024,32769,4160,73770,17,98645,8192,64,146508,5392,4096,236850,1365,98678,256,33,46093,74251]

theorem envBound28170 : H12AffineFastState.Bounded env28170 := by
  intro p hp
  have h : env28170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28169_28170 : H12AffineEnvironment.transform 17 67619 env28169 = env28170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env28169 == env28170) = true)

theorem identity28170 : scanCanonicalize (H12AffineFastState.compose env28170 (packedSelected [2,3,5,6,11,12,14,16,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound28170 : packedSelected [2,3,5,6,11,12,14,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38161,67619,1024,32769,4160,73770,17,98645,8192,64,43357,5392,4096,67619,1365,98678,256,33,46093,74251]

theorem envBound28171 : H12AffineFastState.Bounded env28171 := by
  intro p hp
  have h : env28171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28170_28171 : H12AffineEnvironment.transform 16 38161 env28170 = env28171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28170 == env28171) = true)

theorem identity28171 : scanCanonicalize (H12AffineFastState.compose env28171 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound28171 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env28172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,80,65536,5441,67619,1024,81,4160,73770,17,65797,8192,64,10509,5392,4096,67619,1365,65830,256,33,13405,74251]

theorem envBound28172 : H12AffineFastState.Bounded env28172 := by
  intro p hp
  have h : env28172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28171_28172 : H12AffineEnvironment.transform 14 80 env28171 = env28172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env28171 == env28172) = true)

theorem identity28172 : scanCanonicalize (H12AffineFastState.compose env28172 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound28172 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env28173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,80,343,5441,2420,1024,81,4160,8573,17,82,8192,64,10509,5392,4096,2420,1365,113,256,33,13405,9052]

theorem envBound28173 : H12AffineFastState.Bounded env28173 := by
  intro p hp
  have h : env28173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28172_28173 : H12AffineEnvironment.transform 15 343 env28172 = env28173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env28172 == env28173) = true)

theorem identity28173 : scanCanonicalize (H12AffineFastState.compose env28173 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28173 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,343,5441,2420,1024,81,4160,113,17,82,268,64,2049,5392,4096,2420,1365,113,256,33,5457,592]

theorem envBound28174 : H12AffineFastState.Bounded env28174 := by
  intro p hp
  have h : env28174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28173_28174 : H12AffineEnvironment.transform 12 268 env28173 = env28174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28173 == env28174) = true)

theorem identity28174 : scanCanonicalize (H12AffineFastState.compose env28174 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound28174 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,268,5376,80,343,5441,292,1024,81,4160,113,17,82,268,64,81,5392,4096,292,1365,113,256,33,5457,592]

theorem envBound28175 : H12AffineFastState.Bounded env28175 := by
  intro p hp
  have h : env28175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28174_28175 : H12AffineEnvironment.transform 10 80 env28174 = env28175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env28174 == env28175) = true)

theorem identity28175 : scanCanonicalize (H12AffineFastState.compose env28175 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28175 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28176 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,268,5376,1,262,5392,292,1024,0,4113,32,17,3,268,17,0,5392,4096,292,1284,32,256,33,5376,513]

theorem envBound28176 : H12AffineFastState.Bounded env28176 := by
  intro p hp
  have h : env28176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28175_28176 : H12AffineEnvironment.transform 5 17 env28175 = env28176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28175 == env28176) = true)

theorem identity28176 : scanCanonicalize (H12AffineFastState.compose env28176 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound28176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28177 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,308,268,1076,1,262,1060,292,1024,0,293,32,17,3,268,17,0,1060,308,292,1284,32,256,33,1076,513]

theorem envBound28177 : H12AffineFastState.Bounded env28177 := by
  intro p hp
  have h : env28177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28176_28177 : H12AffineEnvironment.transform 11 308 env28176 = env28177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env28176 == env28177) = true)

theorem identity28177 : scanCanonicalize (H12AffineFastState.compose env28177 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28177 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28178 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,308,268,292,1,262,308,292,272,0,293,32,17,3,268,17,0,308,308,292,20,32,256,33,292,513]

theorem envBound28178 : H12AffineFastState.Bounded env28178 := by
  intro p hp
  have h : env28178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28177_28178 : H12AffineEnvironment.transform 9 272 env28177 = env28178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28177 == env28178) = true)

def env28179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,73771,17,98645,8193,64,472174,5392,4097,431377,1365,98679,256,33,46092,74250]

theorem envBound28179 : H12AffineFastState.Bounded env28179 := by
  intro p hp
  have h : env28179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28168_28179 : H12AffineEnvironment.transform 6 9 env28168 = env28179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28168 == env28179) = true)

theorem identity28179 : scanCanonicalize (H12AffineFastState.compose env28179 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound28179 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,4161,73771,17,98645,8193,64,171281,5392,4097,212078,1365,98679,256,33,46092,74250]

theorem envBound28180 : H12AffineFastState.Bounded env28180 := by
  intro p hp
  have h : env28180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28179_28180 : H12AffineEnvironment.transform 17 108927 env28179 = env28180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env28179 == env28180) = true)

theorem identity28180 : scanCanonicalize (H12AffineFastState.compose env28180 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28180 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,131072,76158,1024,0,4161,73771,17,65876,8193,64,138512,5392,4097,212078,1365,65910,256,33,13325,74250]

theorem envBound28181 : H12AffineFastState.Bounded env28181 := by
  intro p hp
  have h : env28181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28180_28181 : H12AffineEnvironment.transform 14 1 env28180 = env28181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28180 == env28181) = true)

theorem identity28181 : scanCanonicalize (H12AffineFastState.compose env28181 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound28181 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env28182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,70727,76158,1024,0,4161,73771,17,65876,8193,64,67927,5392,4097,10281,1365,65910,256,33,13325,74250]

theorem envBound28182 : H12AffineFastState.Bounded env28182 := by
  intro p hp
  have h : env28182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28181_28182 : H12AffineEnvironment.transform 16 70727 env28181 = env28182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env28181 == env28182) = true)

theorem identity28182 : scanCanonicalize (H12AffineFastState.compose env28182 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28182 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,70727,67619,1024,0,4161,65910,17,65876,348,64,67927,5392,4097,2420,1365,65910,256,33,5456,66391]

theorem envBound28183 : H12AffineFastState.Bounded env28183 := by
  intro p hp
  have h : env28183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28182_28183 : H12AffineEnvironment.transform 12 349 env28182 = env28183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28182 == env28183) = true)

theorem identity28183 : scanCanonicalize (H12AffineFastState.compose env28183 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound28183 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,83,5140,2160,1024,0,4161,293,17,263,348,64,2308,5392,4097,2420,1365,293,256,33,5456,772]

theorem envBound28184 : H12AffineFastState.Bounded env28184 := by
  intro p hp
  have h : env28184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28183_28184 : H12AffineEnvironment.transform 15 83 env28183 = env28184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env28183 == env28184) = true)

theorem identity28184 : scanCanonicalize (H12AffineFastState.compose env28184 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound28184 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env28185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,349,1361,1,83,1093,2160,1024,0,16,293,17,263,348,64,2308,1345,80,2420,1365,293,256,33,1281,772]

theorem envBound28185 : H12AffineFastState.Bounded env28185 := by
  intro p hp
  have h : env28185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28184_28185 : H12AffineEnvironment.transform 11 81 env28184 = env28185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28184 == env28185) = true)

theorem identity28185 : scanCanonicalize (H12AffineFastState.compose env28185 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound28185 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28186 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,32,300,1312,1,34,1076,2049,1024,0,16,293,17,263,301,49,2308,1328,33,2309,1316,293,256,33,1281,772]

theorem envBound28186 : H12AffineFastState.Bounded env28186 := by
  intro p hp
  have h : env28186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28185_28186 : H12AffineEnvironment.transform 5 49 env28185 = env28186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env28185 == env28186) = true)

theorem identity28186 : scanCanonicalize (H12AffineFastState.compose env28186 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28186 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28187 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,32,40,1060,1,34,1076,2049,1024,0,16,33,17,3,41,49,2048,1076,33,2049,1056,33,4,33,1029,512]

theorem envBound28187 : H12AffineFastState.Bounded env28187 := by
  intro p hp
  have h : env28187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28186_28187 : H12AffineEnvironment.transform 7 4 env28186 = env28187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28186 == env28187) = true)

theorem identity28187 : scanCanonicalize (H12AffineFastState.compose env28187 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound28187 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28188 : List Nat := [2,4,8,16,32,49,9,4,512,1024,11,32,40,1060,1,34,1076,10,1024,0,16,33,17,3,41,49,11,1076,33,10,1056,33,4,33,1029,512]

theorem envBound28188 : H12AffineFastState.Bounded env28188 := by
  intro p hp
  have h : env28188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28187_28188 : H12AffineEnvironment.transform 10 11 env28187 = env28188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env28187 == env28188) = true)

theorem identity28188 : scanCanonicalize (H12AffineFastState.compose env28188 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound28188 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28189 : List Nat := [2,4,8,16,32,49,9,4,512,31,11,32,40,59,1,34,43,10,31,0,16,33,17,3,41,49,11,43,33,10,63,33,4,33,26,512]

theorem envBound28189 : H12AffineFastState.Bounded env28189 := by
  intro p hp
  have h : env28189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28188_28189 : H12AffineEnvironment.transform 9 31 env28188 = env28189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env28188 == env28189) = true)

theorem identity28189 : scanCanonicalize (H12AffineFastState.compose env28189 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28189 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28190 : List Nat := [2,4,8,16,0,17,9,4,512,31,11,0,8,27,1,2,11,10,31,0,16,1,17,3,9,17,11,11,1,10,31,1,4,1,26,512]

theorem envBound28190 : H12AffineFastState.Bounded env28190 := by
  intro p hp
  have h : env28190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28189_28190 : H12AffineEnvironment.transform 4 0 env28189 = env28190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28189 == env28190) = true)

theorem identity28190 : scanCanonicalize (H12AffineFastState.compose env28190 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28191 : List Nat := [2,4,8,11,0,10,9,4,512,4,11,0,8,0,1,2,11,10,4,0,11,1,10,3,9,10,11,11,1,10,4,1,4,1,1,512]

theorem envBound28191 : H12AffineFastState.Bounded env28191 := by
  intro p hp
  have h : env28191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28190_28191 : H12AffineEnvironment.transform 3 11 env28190 = env28191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28190 == env28191) = true)

theorem identity28191 : scanCanonicalize (H12AffineFastState.compose env28191 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound28191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28192 : List Nat := [2,4,6,5,0,4,7,4,512,4,5,0,6,0,1,2,5,4,4,0,5,1,4,3,7,4,5,5,1,4,4,1,4,1,1,512]

theorem envBound28192 : H12AffineFastState.Bounded env28192 := by
  intro p hp
  have h : env28192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28191_28192 : H12AffineEnvironment.transform 2 6 env28191 = env28192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env28191 == env28192) = true)

def env28193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,16,98645,8328,64,4592709,5393,4233,431377,1364,4235612,256,32,46213,74370]

theorem envBound28193 : H12AffineFastState.Bounded env28193 := by
  intro p hp
  have h : env28193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28166_28193 : H12AffineEnvironment.transform 13 5377 env28166 = env28193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28166 == env28193) = true)

theorem identity28193 : scanCanonicalize (H12AffineFastState.compose env28193 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28193 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,4194304,16,41310,8328,64,4592709,5393,4233,431377,1364,4235612,256,32,46213,649]

theorem envBound28194 : H12AffineFastState.Bounded env28194 := by
  intro p hp
  have h : env28194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28193_28194 : H12AffineEnvironment.transform 15 8203 env28193 = env28194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28193 == env28194) = true)

theorem identity28194 : scanCanonicalize (H12AffineFastState.compose env28194 (packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS)) = affineNative (2^(21+1) ^^^ 297220) := by decide +kernel

theorem selectedBound28194 : packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env28195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,297220,16,41310,8328,64,171329,5393,4233,431377,1364,272472,256,32,46213,649]

theorem envBound28195 : H12AffineFastState.Bounded env28195 := by
  intro p hp
  have h : env28195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28194_28195 : H12AffineEnvironment.transform 21 297220 env28194 = env28195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297220 env28194 == env28195) = true)

def env28196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,297220,16,41310,8192,64,171329,5393,4097,431377,1364,272472,256,32,46093,513]

theorem envBound28196 : H12AffineFastState.Bounded env28196 := by
  intro p hp
  have h : env28196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28195_28196 : H12AffineEnvironment.transform 6 8 env28195 = env28196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28195 == env28196) = true)

theorem identity28196 : scanCanonicalize (H12AffineFastState.compose env28196 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28196 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4161,272472,16,2,8192,64,146461,5393,4097,406605,1364,272472,256,32,5457,513]

theorem envBound28197 : H12AffineFastState.Bounded env28197 := by
  intro p hp
  have h : env28197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28196_28197 : H12AffineEnvironment.transform 14 8540 env28196 = env28197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28196 == env28197) = true)

theorem identity28197 : scanCanonicalize (H12AffineFastState.compose env28197 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound28197 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146792,1024,8541,4161,136496,16,2,8192,64,146461,5393,4097,2341,1364,136496,256,32,5457,513]

theorem envBound28198 : H12AffineFastState.Bounded env28198 := by
  intro p hp
  have h : env28198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28197_28198 : H12AffineEnvironment.transform 17 146792 env28197 = env28198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env28197 == env28198) = true)

theorem identity28198 : scanCanonicalize (H12AffineFastState.compose env28198 (packedSelected [1,8,12,15,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28198 : packedSelected [1,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28199 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,146744,1024,8461,4113,136496,16,2,8192,16,146461,5393,4097,2341,1284,136496,256,32,5377,513]

theorem envBound28199 : H12AffineFastState.Bounded env28199 := by
  intro p hp
  have h : env28199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28198_28199 : H12AffineEnvironment.transform 5 16 env28198 = env28199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28198 == env28199) = true)

theorem identity28199 : scanCanonicalize (H12AffineFastState.compose env28199 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound28199 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28200 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,13341,2341,1024,8461,4113,8493,16,2,8192,16,2048,5393,4097,2341,1284,8493,256,32,5377,513]

theorem envBound28200 : H12AffineFastState.Bounded env28200 := by
  intro p hp
  have h : env28200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28199_28200 : H12AffineEnvironment.transform 16 13341 env28199 = env28200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env28199 == env28200) = true)

theorem identity28200 : scanCanonicalize (H12AffineFastState.compose env28200 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28200 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5392,2341,1024,0,4113,32,16,2,269,16,2048,5393,4097,2341,1284,32,256,32,5377,513]

theorem envBound28201 : H12AffineFastState.Bounded env28201 := by
  intro p hp
  have h : env28201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28200_28201 : H12AffineEnvironment.transform 12 269 env28200 = env28201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28200 == env28201) = true)

theorem identity28201 : scanCanonicalize (H12AffineFastState.compose env28201 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28202 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4405,1,262,4388,2341,52,0,4113,32,16,2,269,16,2048,4389,4097,2341,304,32,256,32,4405,513]

theorem envBound28202 : H12AffineFastState.Bounded env28202 := by
  intro p hp
  have h : env28202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28201_28202 : H12AffineEnvironment.transform 9 52 env28201 = env28202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28201 == env28202) = true)

theorem identity28202 : scanCanonicalize (H12AffineFastState.compose env28202 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28202 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28203 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,1,34,4096,2049,52,0,4113,32,16,2,41,16,2048,4097,4097,2049,20,32,36,32,4113,513]

theorem envBound28203 : H12AffineFastState.Bounded env28203 := by
  intro p hp
  have h : env28203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28202_28203 : H12AffineEnvironment.transform 7 36 env28202 = env28203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28202 == env28203) = true)

theorem identity28203 : scanCanonicalize (H12AffineFastState.compose env28203 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound28203 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28204 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,4096,41,4113,1,34,4096,2049,52,0,4113,32,16,2,41,16,2048,4097,4097,2049,20,32,36,32,4113,48]

theorem envBound28204 : H12AffineFastState.Bounded env28204 := by
  intro p hp
  have h : env28204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28203_28204 : H12AffineEnvironment.transform 8 49 env28203 = env28204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env28203 == env28204) = true)

theorem identity28204 : scanCanonicalize (H12AffineFastState.compose env28204 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28205 : List Nat := [2,4,8,16,17,16,8,21,0,5,2048,4096,24,4113,1,19,4096,2049,5,0,4113,17,16,2,24,16,2048,4097,4097,2049,20,17,21,17,4113,1]

theorem envBound28205 : H12AffineFastState.Bounded env28205 := by
  intro p hp
  have h : env28205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28204_28205 : H12AffineEnvironment.transform 4 17 env28204 = env28205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28204 == env28205) = true)

def env28206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4160,297220,16,41310,8193,64,171329,5393,4096,431377,1364,272472,256,32,46092,512]

theorem envBound28206 : H12AffineFastState.Bounded env28206 := by
  intro p hp
  have h : env28206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28195_28206 : H12AffineEnvironment.transform 6 9 env28195 = env28206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28195 == env28206) = true)

theorem identity28206 : scanCanonicalize (H12AffineFastState.compose env28206 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 171281) := by decide +kernel

theorem selectedBound28206 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,171281,1024,32769,4160,136213,16,41310,8193,64,171329,5393,4096,2048,1364,177481,256,32,46092,512]

theorem envBound28207 : H12AffineFastState.Bounded env28207 := by
  intro p hp
  have h : env28207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28206_28207 : H12AffineEnvironment.transform 17 171281 env28206 = env28207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171281 env28206 == env28207) = true)

theorem identity28207 : scanCanonicalize (H12AffineFastState.compose env28207 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28207 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146508,1024,8540,4160,136213,16,3,8193,64,146460,5393,4096,2048,1364,136212,256,32,5457,512]

theorem envBound28208 : H12AffineFastState.Bounded env28208 := by
  intro p hp
  have h : env28208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28207_28208 : H12AffineEnvironment.transform 14 8541 env28207 = env28208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28207 == env28208) = true)

theorem identity28208 : scanCanonicalize (H12AffineFastState.compose env28208 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound28208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5141,10329,1024,8540,4160,0,16,3,8193,64,10249,5393,4096,2048,1364,1,256,32,5457,512]

theorem envBound28209 : H12AffineFastState.Bounded env28209 := by
  intro p hp
  have h : env28209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28208_28209 : H12AffineEnvironment.transform 16 5141 env28208 = env28209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env28208 == env28209) = true)

theorem identity28209 : scanCanonicalize (H12AffineFastState.compose env28209 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28209 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5141,2308,1024,1,4160,0,16,3,348,64,2388,5393,4096,2048,1364,1,256,32,5457,512]

theorem envBound28210 : H12AffineFastState.Bounded env28210 := by
  intro p hp
  have h : env28210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28209_28210 : H12AffineEnvironment.transform 12 349 env28209 = env28210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28209 == env28210) = true)

def env28211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21777,98644,8328,64,4592708,16400,17801,431377,20564,4235612,256,21793,46213,96130]

theorem envBound28211 : H12AffineFastState.Bounded env28211 := by
  intro p hp
  have h : env28211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28165_28211 : H12AffineEnvironment.transform 20 17865 env28165 = env28211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env28165 == env28211) = true)

def env28212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,17,98644,8328,64,4592708,5392,4233,431377,1364,4235612,256,33,46213,74370]

theorem envBound28212 : H12AffineFastState.Bounded env28212 := by
  intro p hp
  have h : env28212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28211_28212 : H12AffineEnvironment.transform 13 5376 env28211 = env28212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28211 == env28212) = true)

theorem identity28212 : scanCanonicalize (H12AffineFastState.compose env28212 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound28212 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,98678,17,98644,8328,64,496946,5392,4233,431377,1364,73770,256,33,46213,74370]

theorem envBound28213 : H12AffineFastState.Bounded env28213 := by
  intro p hp
  have h : env28213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28212_28213 : H12AffineEnvironment.transform 21 98678 env28212 = env28213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env28212 == env28213) = true)

def env28214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,98678,17,98644,8192,64,496946,5392,4097,431377,1364,73770,256,33,46093,74250]

theorem envBound28214 : H12AffineFastState.Bounded env28214 := by
  intro p hp
  have h : env28214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28213_28214 : H12AffineEnvironment.transform 6 8 env28213 = env28214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28213 == env28214) = true)

theorem identity28214 : scanCanonicalize (H12AffineFastState.compose env28214 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound28214 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4161,98678,17,98644,8192,64,171280,5392,4097,236851,1364,73770,256,33,46093,74250]

theorem envBound28215 : H12AffineFastState.Bounded env28215 := by
  intro p hp
  have h : env28215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28214_28215 : H12AffineEnvironment.transform 17 67618 env28214 = env28215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env28214 == env28215) = true)

theorem identity28215 : scanCanonicalize (H12AffineFastState.compose env28215 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28215 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,35188,1024,32769,4161,32,17,2,8192,64,171280,5392,4097,138341,1364,41340,256,33,46093,41820]

theorem envBound28216 : H12AffineFastState.Bounded env28216 := by
  intro p hp
  have h : env28216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28215_28216 : H12AffineEnvironment.transform 15 33110 env28215 = env28216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28215 == env28216) = true)

theorem identity28216 : scanCanonicalize (H12AffineFastState.compose env28216 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound28216 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env28217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5140,35188,1024,32769,4161,32,17,2,8192,64,35076,5392,4097,2161,1364,41340,256,33,46093,41820]

theorem envBound28217 : H12AffineFastState.Bounded env28217 := by
  intro p hp
  have h : env28217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28216_28217 : H12AffineEnvironment.transform 16 5140 env28216 = env28217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env28216 == env28217) = true)

theorem identity28217 : scanCanonicalize (H12AffineFastState.compose env28217 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28217 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5140,10281,1024,8540,4161,32,17,2,8192,64,10329,5392,4097,2161,1364,33,256,33,5456,513]

theorem envBound28218 : H12AffineFastState.Bounded env28218 := by
  intro p hp
  have h : env28218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28217_28218 : H12AffineEnvironment.transform 14 8541 env28217 = env28218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28217 == env28218) = true)

theorem identity28218 : scanCanonicalize (H12AffineFastState.compose env28218 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28218 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28219 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,8192,5125,8280,8203,5140,10281,1024,8281,4161,32,17,2,8192,64,10329,5141,4097,2161,1105,33,5,33,5205,513]

theorem envBound28219 : H12AffineFastState.Bounded env28219 := by
  intro p hp
  have h : env28219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28218_28219 : H12AffineEnvironment.transform 7 5 env28218 = env28219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28218 == env28219) = true)

theorem identity28219 : scanCanonicalize (H12AffineFastState.compose env28219 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound28219 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28220 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,88,5125,0,83,5140,2161,1024,1,4161,32,17,2,88,64,2049,5141,4097,2161,1105,33,5,33,5205,513]

theorem envBound28220 : H12AffineFastState.Bounded env28220 := by
  intro p hp
  have h : env28220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28219_28220 : H12AffineEnvironment.transform 12 88 env28219 = env28220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env28219 == env28220) = true)

theorem identity28220 : scanCanonicalize (H12AffineFastState.compose env28220 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound28220 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28221 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,577,88,1604,0,83,1621,2161,1024,1,512,32,17,2,88,64,2049,1620,576,2161,1105,33,5,33,1556,513]

theorem envBound28221 : H12AffineFastState.Bounded env28221 := by
  intro p hp
  have h : env28221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28220_28221 : H12AffineEnvironment.transform 11 577 env28220 = env28221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env28220 == env28221) = true)

theorem identity28221 : scanCanonicalize (H12AffineFastState.compose env28221 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound28221 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28222 : List Nat := [2,4,8,16,32,64,8,5,512,1024,1540,577,88,1604,0,83,1621,1653,1024,1,512,32,17,2,88,64,1541,1620,576,1653,1105,33,5,33,1556,513]

theorem envBound28222 : H12AffineFastState.Bounded env28222 := by
  intro p hp
  have h : env28222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28221_28222 : H12AffineEnvironment.transform 10 1540 env28221 = env28222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env28221 == env28222) = true)

def env28223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,98678,17,98644,8193,64,496946,5392,4096,431377,1364,73770,256,33,46092,74251]

theorem envBound28223 : H12AffineFastState.Bounded env28223 := by
  intro p hp
  have h : env28223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28213_28223 : H12AffineEnvironment.transform 6 9 env28213 = env28223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28213 == env28223) = true)

theorem identity28223 : scanCanonicalize (H12AffineFastState.compose env28223 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound28223 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,4160,98678,17,98644,8193,64,146508,5392,4096,212079,1364,73770,256,33,46092,74251]

theorem envBound28224 : H12AffineFastState.Bounded env28224 := by
  intro p hp
  have h : env28224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28223_28224 : H12AffineEnvironment.transform 17 108926 env28223 = env28224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env28223 == env28224) = true)

theorem identity28224 : scanCanonicalize (H12AffineFastState.compose env28224 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28224 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35188,1024,32769,4160,41340,17,41310,8193,64,146508,5392,4096,138341,1364,32,256,33,46092,513]

theorem envBound28225 : H12AffineFastState.Bounded env28225 := by
  intro p hp
  have h : env28225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28224_28225 : H12AffineEnvironment.transform 15 8202 env28224 = env28225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28224 == env28225) = true)

theorem identity28225 : scanCanonicalize (H12AffineFastState.compose env28225 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound28225 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1345,8202,131072,3125,1024,1344,4160,9277,17,9247,8193,64,146508,5392,4096,138341,1364,32,256,33,12621,513]

theorem envBound28226 : H12AffineFastState.Bounded env28226 := by
  intro p hp
  have h : env28226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28225_28226 : H12AffineEnvironment.transform 14 1345 env28225 = env28226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env28225 == env28226) = true)

theorem identity28226 : scanCanonicalize (H12AffineFastState.compose env28226 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28226 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env28227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1345,8202,5392,3125,1024,1344,4160,9277,17,9247,8193,64,10588,5392,4096,2421,1364,32,256,33,12621,513]

theorem envBound28227 : H12AffineFastState.Bounded env28227 := by
  intro p hp
  have h : env28227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28226_28227 : H12AffineEnvironment.transform 16 5392 env28226 = env28227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28226 == env28227) = true)

theorem identity28227 : scanCanonicalize (H12AffineFastState.compose env28227 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound28227 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3100,5376,1345,3094,5392,3125,1024,1344,4160,2081,17,2051,3101,64,1344,5392,4096,2421,1364,32,256,33,7505,513]

theorem envBound28228 : H12AffineFastState.Bounded env28228 := by
  intro p hp
  have h : env28228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28227_28228 : H12AffineEnvironment.transform 12 3100 env28227 = env28228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env28227 == env28228) = true)

theorem identity28228 : scanCanonicalize (H12AffineFastState.compose env28228 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound28228 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,3100,0,1345,3094,16,3125,1024,1344,1344,2081,17,2051,3101,64,1344,16,1280,2421,1364,32,256,33,2129,513]

theorem envBound28229 : H12AffineFastState.Bounded env28229 := by
  intro p hp
  have h : env28229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28228_28229 : H12AffineEnvironment.transform 11 1280 env28228 = env28229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env28228 == env28229) = true)

theorem identity28229 : scanCanonicalize (H12AffineFastState.compose env28229 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28229 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28230 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1140,3100,0,1077,3094,16,3125,1024,1076,1076,2081,17,2051,3101,64,1076,16,1140,2049,1056,32,116,33,2129,513]

theorem envBound28230 : H12AffineFastState.Bounded env28230 := by
  intro p hp
  have h : env28230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28229_28230 : H12AffineEnvironment.transform 7 116 env28229 = env28230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28229 == env28230) = true)

theorem identity28230 : scanCanonicalize (H12AffineFastState.compose env28230 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28230 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env28231 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1060,3100,0,1077,3094,16,3125,1024,1076,1076,2081,17,2051,3101,16,1076,16,1060,2049,1056,32,36,33,2049,513]

theorem envBound28231 : H12AffineFastState.Bounded env28231 := by
  intro p hp
  have h : env28231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28230_28231 : H12AffineEnvironment.transform 5 16 env28230 = env28231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28230 == env28231) = true)

theorem identity28231 : scanCanonicalize (H12AffineFastState.compose env28231 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound28231 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28232 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1060,40,0,1077,34,16,1,1024,1076,1076,1045,17,1079,41,16,1076,16,1060,1077,1056,32,36,33,1077,513]

theorem envBound28232 : H12AffineFastState.Bounded env28232 := by
  intro p hp
  have h : env28232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28231_28232 : H12AffineEnvironment.transform 10 1076 env28231 = env28232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env28231 == env28232) = true)

theorem identity28232 : scanCanonicalize (H12AffineFastState.compose env28232 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28233 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,16,40,0,1,34,16,1,52,0,0,33,17,3,41,16,0,16,16,1,20,32,36,33,1,513]

theorem envBound28233 : H12AffineFastState.Bounded env28233 := by
  intro p hp
  have h : env28233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28232_28233 : H12AffineEnvironment.transform 9 52 env28232 = env28233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28232 == env28233) = true)

theorem identity28233 : scanCanonicalize (H12AffineFastState.compose env28233 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28234 : List Nat := [2,4,8,0,32,0,9,36,512,36,0,0,40,0,1,34,0,1,36,0,0,33,1,3,41,0,0,0,0,1,4,32,36,33,1,513]

theorem envBound28234 : H12AffineFastState.Bounded env28234 := by
  intro p hp
  have h : env28234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28233_28234 : H12AffineEnvironment.transform 3 0 env28233 = env28234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28233 == env28234) = true)

theorem identity28234 : scanCanonicalize (H12AffineFastState.compose env28234 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28235 : List Nat := [2,4,8,0,11,0,9,15,512,15,0,0,3,0,1,9,0,1,15,0,0,10,1,3,2,0,0,0,0,1,4,11,15,10,1,513]

theorem envBound28235 : H12AffineFastState.Bounded env28235 := by
  intro p hp
  have h : env28235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28234_28235 : H12AffineEnvironment.transform 4 11 env28234 = env28235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28234 == env28235) = true)

def env28236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,16,98644,8328,64,4592708,5393,4232,431377,1365,4235612,256,32,46213,74371]

theorem envBound28236 : H12AffineFastState.Bounded env28236 := by
  intro p hp
  have h : env28236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28211_28236 : H12AffineEnvironment.transform 13 5377 env28211 = env28236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28211 == env28236) = true)

theorem identity28236 : scanCanonicalize (H12AffineFastState.compose env28236 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound28236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,4296,4194304,16,138,8328,64,4592708,5393,4232,431377,1365,4235612,256,32,46213,41821]

theorem envBound28237 : H12AffineFastState.Bounded env28237 := by
  intro p hp
  have h : env28237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28236_28237 : H12AffineEnvironment.transform 15 33246 env28236 = env28237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env28236 == env28237) = true)

def env28238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4160,4194304,16,2,8192,64,4592708,5393,4096,431377,1365,4235612,256,32,46093,41821]

theorem envBound28238 : H12AffineFastState.Bounded env28238 := by
  intro p hp
  have h : env28238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28237_28238 : H12AffineEnvironment.transform 6 8 env28237 = env28238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28237 == env28238) = true)

theorem identity28238 : scanCanonicalize (H12AffineFastState.compose env28238 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28238 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4160,4194304,16,2,8192,64,4592708,5393,4096,406605,1365,4194304,256,32,5457,513]

theorem envBound28239 : H12AffineFastState.Bounded env28239 := by
  intro p hp
  have h : env28239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28238_28239 : H12AffineEnvironment.transform 14 8540 env28238 = env28239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28238 == env28239) = true)

theorem identity28239 : scanCanonicalize (H12AffineFastState.compose env28239 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28239 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4160,32,16,2,8192,64,398436,5393,4096,406605,1365,32,256,32,5457,513]

theorem envBound28240 : H12AffineFastState.Bounded env28240 := by
  intro p hp
  have h : env28240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28239_28240 : H12AffineEnvironment.transform 21 32 env28239 = env28240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28239 == env28240) = true)

theorem identity28240 : scanCanonicalize (H12AffineFastState.compose env28240 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound28240 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,138341,1024,8541,4160,32,16,2,8192,64,2049,5393,4096,10280,1365,32,256,32,5457,513]

theorem envBound28241 : H12AffineFastState.Bounded env28241 := by
  intro p hp
  have h : env28241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28240_28241 : H12AffineEnvironment.transform 17 138341 env28240 = env28241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env28240 == env28241) = true)

theorem identity28241 : scanCanonicalize (H12AffineFastState.compose env28241 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28241 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5392,2421,1024,8541,4160,32,16,2,8192,64,2049,5393,4096,10280,1365,32,256,32,5457,513]

theorem envBound28242 : H12AffineFastState.Bounded env28242 := by
  intro p hp
  have h : env28242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28241_28242 : H12AffineEnvironment.transform 16 5392 env28241 = env28242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28241 == env28242) = true)

theorem identity28242 : scanCanonicalize (H12AffineFastState.compose env28242 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound28242 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env28243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,1297,1095,5392,2421,1024,1296,4160,32,16,2,1101,64,2049,5393,4096,3173,1365,32,256,32,5457,513]

theorem envBound28243 : H12AffineFastState.Bounded env28243 := by
  intro p hp
  have h : env28243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28242_28243 : H12AffineEnvironment.transform 12 1101 env28242 = env28243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env28242 == env28243) = true)

theorem identity28243 : scanCanonicalize (H12AffineFastState.compose env28243 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound28243 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env28244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1819,4096,1101,5377,1297,1095,5392,1646,1024,1296,4160,32,16,2,1101,64,1818,5393,4096,894,1365,32,256,32,5457,513]

theorem envBound28244 : H12AffineFastState.Bounded env28244 := by
  intro p hp
  have h : env28244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28243_28244 : H12AffineEnvironment.transform 10 1819 env28243 = env28244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env28243 == env28244) = true)

def env28245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4161,4194304,16,3,8193,64,4592708,5393,4097,431377,1365,4235612,256,32,46092,41821]

theorem envBound28245 : H12AffineFastState.Bounded env28245 := by
  intro p hp
  have h : env28245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28237_28245 : H12AffineEnvironment.transform 6 9 env28237 = env28245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28237 == env28245) = true)

theorem identity28245 : scanCanonicalize (H12AffineFastState.compose env28245 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound28245 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env28246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,46156,262144,1024,32769,4161,4194304,16,3,8193,64,4497416,5393,4097,270685,1365,4235612,256,32,46092,41821]

theorem envBound28246 : H12AffineFastState.Bounded env28246 := by
  intro p hp
  have h : env28246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28245_28246 : H12AffineEnvironment.transform 16 46156 env28245 = env28246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env28245 == env28246) = true)

theorem identity28246 : scanCanonicalize (H12AffineFastState.compose env28246 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28246 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env28247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,262144,1024,8541,4161,4194304,16,3,8193,64,4456788,5393,4097,270685,1365,4194304,256,32,5456,513]

theorem envBound28247 : H12AffineFastState.Bounded env28247 := by
  intro p hp
  have h : env28247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28246_28247 : H12AffineEnvironment.transform 14 8540 env28246 = env28247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28246 == env28247) = true)

theorem identity28247 : scanCanonicalize (H12AffineFastState.compose env28247 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound28247 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10361,1024,8541,4161,4194304,16,3,8193,64,4204845,5393,4097,2340,1365,4194304,256,32,5456,513]

theorem envBound28248 : H12AffineFastState.Bounded env28248 := by
  intro p hp
  have h : env28248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28247_28248 : H12AffineEnvironment.transform 17 10361 env28247 = env28248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env28247 == env28248) = true)

theorem identity28248 : scanCanonicalize (H12AffineFastState.compose env28248 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28248 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28249 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,4405,8540,8203,4388,10361,52,8541,4161,4194304,16,3,8193,64,4204845,4389,4097,2340,353,4194304,256,32,4452,513]

theorem envBound28249 : H12AffineFastState.Bounded env28249 := by
  intro p hp
  have h : env28249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28248_28249 : H12AffineEnvironment.transform 9 52 env28248 = env28249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28248 == env28249) = true)

theorem identity28249 : scanCanonicalize (H12AffineFastState.compose env28249 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound28249 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env28250 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,4405,8540,8203,4388,10361,52,8541,4161,341,16,3,8193,64,10360,4389,4097,2340,353,341,256,32,4452,513]

theorem envBound28250 : H12AffineFastState.Bounded env28250 := by
  intro p hp
  have h : env28250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28249_28250 : H12AffineEnvironment.transform 21 341 env28249 = env28250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env28249 == env28250) = true)

theorem identity28250 : scanCanonicalize (H12AffineFastState.compose env28250 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28250 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env28251 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4405,0,343,4388,2341,52,1,4161,341,16,3,349,64,2340,4389,4097,2340,353,341,256,32,4452,513]

theorem envBound28251 : H12AffineFastState.Bounded env28251 := by
  intro p hp
  have h : env28251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28250_28251 : H12AffineEnvironment.transform 12 348 env28250 = env28251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28250 == env28251) = true)

theorem identity28251 : scanCanonicalize (H12AffineFastState.compose env28251 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28251 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28252 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,0,262,4388,2341,52,1,4112,260,16,3,268,17,2340,4389,4097,2340,304,260,256,32,4405,513]

theorem envBound28252 : H12AffineFastState.Bounded env28252 := by
  intro p hp
  have h : env28252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28251_28252 : H12AffineEnvironment.transform 5 17 env28251 = env28252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28251 == env28252) = true)

theorem identity28252 : scanCanonicalize (H12AffineFastState.compose env28252 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound28252 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env28253 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,293,269,16,0,262,1,2341,52,1,309,260,16,3,268,17,2340,0,292,2340,304,260,256,32,16,513]

theorem envBound28253 : H12AffineFastState.Bounded env28253 := by
  intro p hp
  have h : env28253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28252_28253 : H12AffineEnvironment.transform 11 293 env28252 = env28253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env28252 == env28253) = true)

theorem identity28253 : scanCanonicalize (H12AffineFastState.compose env28253 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28253 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28254 : List Nat := [2,4,8,1,32,0,9,256,512,37,2048,293,269,1,0,262,1,2341,37,1,292,260,1,3,268,0,2340,0,292,2340,289,260,256,32,1,513]

theorem envBound28254 : H12AffineFastState.Bounded env28254 := by
  intro p hp
  have h : env28254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28253_28254 : H12AffineEnvironment.transform 3 1 env28253 = env28254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28253 == env28254) = true)

theorem identity28254 : scanCanonicalize (H12AffineFastState.compose env28254 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28254 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28255 : List Nat := [2,4,8,1,32,0,9,36,512,37,2048,1,41,1,0,34,1,2049,37,1,0,32,1,3,40,0,2048,0,0,2048,5,32,36,32,1,513]

theorem envBound28255 : H12AffineFastState.Bounded env28255 := by
  intro p hp
  have h : env28255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28254_28255 : H12AffineEnvironment.transform 7 36 env28254 = env28255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28254 == env28255) = true)

theorem identity28255 : scanCanonicalize (H12AffineFastState.compose env28255 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound28255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28256 : List Nat := [2,4,8,1,32,0,9,36,512,37,33,1,41,1,0,34,1,32,37,1,0,32,1,3,40,0,33,0,0,33,5,32,36,32,1,513]

theorem envBound28256 : H12AffineFastState.Bounded env28256 := by
  intro p hp
  have h : env28256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28255_28256 : H12AffineEnvironment.transform 10 33 env28255 = env28256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env28255 == env28256) = true)

theorem identity28256 : scanCanonicalize (H12AffineFastState.compose env28256 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound28256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28257 : List Nat := [2,4,8,1,32,0,9,36,33,37,33,1,41,1,0,34,1,32,37,1,0,32,1,3,40,0,33,0,0,33,5,32,36,32,1,32]

theorem envBound28257 : H12AffineFastState.Bounded env28257 := by
  intro p hp
  have h : env28257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28256_28257 : H12AffineEnvironment.transform 8 33 env28256 = env28257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env28256 == env28257) = true)

theorem identity28257 : scanCanonicalize (H12AffineFastState.compose env28257 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28258 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,1,8,1,0,3,1,1,4,1,0,1,1,3,9,0,0,0,0,0,5,1,5,1,1,1]

theorem envBound28258 : H12AffineFastState.Bounded env28258 := by
  intro p hp
  have h : env28258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28257_28258 : H12AffineEnvironment.transform 4 1 env28257 = env28258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28257 == env28258) = true)

def env28259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound28259 : H12AffineFastState.Bounded env28259 := by
  intro p hp
  have h : env28259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28082_28259 : H12AffineEnvironment.transform 18 1025 env28082 = env28259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28082 == env28259) = true)

theorem identity28259 : scanCanonicalize (H12AffineFastState.compose env28259 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237469) := by decide +kernel

theorem selectedBound28259 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,16777216,8328,64,23454749,18973836,160076,2417692,19111948,23160257,257,17031345,16974100,19040219]

theorem envBound28260 : H12AffineFastState.Bounded env28260 := by
  intro p hp
  have h : env28260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28259_28260 : H12AffineEnvironment.transform 22 2237469 env28259 = env28260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237469 env28259 == env28260) = true)

def env28261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,243088,8328,64,6705549,2240796,160076,2417692,2102684,6475857,257,21793,46212,2175563]

theorem envBound28261 : H12AffineFastState.Bounded env28261 := by
  intro p hp
  have h : env28261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28260_28261 : H12AffineEnvironment.transform 23 243088 env28260 = env28261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env28260 == env28261) = true)

def env28262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237469,243088,8328,64,2144661,2240796,160076,2417692,2102684,2373705,257,21793,46212,2175563]

theorem envBound28262 : H12AffineFastState.Bounded env28262 := by
  intro p hp
  have h : env28262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28261_28262 : H12AffineEnvironment.transform 21 452632 env28261 = env28262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env28261 == env28262) = true)

def env28263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144477,243088,8328,64,43477,139612,160076,324700,1500,272393,257,21793,46212,74251]

theorem envBound28263 : H12AffineFastState.Bounded env28263 := by
  intro p hp
  have h : env28263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28262_28263 : H12AffineEnvironment.transform 20 4160 env28262 = env28263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28262 == env28263) = true)

theorem identity28263 : scanCanonicalize (H12AffineFastState.compose env28263 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound28263 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4160,329867,120014,21763,8328,64,43477,115151,102879,324700,1500,272393,257,21793,46212,74251]

theorem envBound28264 : H12AffineFastState.Bounded env28264 := by
  intro p hp
  have h : env28264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28263_28264 : H12AffineEnvironment.transform 16 123027 env28263 = env28264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env28263 == env28264) = true)

def env28265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,4160,73771,120014,21763,8328,64,43477,115151,102879,56572,1500,169,257,21793,46212,74251]

theorem envBound28265 : H12AffineFastState.Bounded env28265 := by
  intro p hp
  have h : env28265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28264_28265 : H12AffineEnvironment.transform 17 10400 env28264 = env28265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env28264 == env28265) = true)

def env28266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4160,73771,119878,21763,8192,64,43357,115015,102743,56436,1364,33,257,21793,46092,74251]

theorem envBound28266 : H12AffineFastState.Bounded env28266 := by
  intro p hp
  have h : env28266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28265_28266 : H12AffineEnvironment.transform 6 8 env28265 = env28266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28265 == env28266) = true)

theorem identity28266 : scanCanonicalize (H12AffineFastState.compose env28266 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound28266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,24908,10280,1025,32769,4160,41340,21777,21763,8192,64,43357,16400,4096,56436,1364,33,257,21793,46092,41820]

theorem envBound28267 : H12AffineFastState.Bounded env28267 := by
  intro p hp
  have h : env28267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28266_28267 : H12AffineEnvironment.transform 15 33111 env28266 = env28267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env28266 == env28267) = true)

theorem identity28267 : scanCanonicalize (H12AffineFastState.compose env28267 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound28267 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,33111,4096,10280,1025,32769,4160,41340,9309,9295,8192,64,43357,12636,4096,44344,1364,33,257,9325,46092,41820]

theorem envBound28268 : H12AffineFastState.Bounded env28268 := by
  intro p hp
  have h : env28268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28267_28268 : H12AffineEnvironment.transform 13 12620 env28267 = env28268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env28267 == env28268) = true)

theorem identity28268 : scanCanonicalize (H12AffineFastState.compose env28268 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28268 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28269 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,32768,33111,4096,10280,273,32769,4160,41340,8525,8543,8192,64,43357,12636,4096,43048,68,33,257,8573,45340,41820]

theorem envBound28269 : H12AffineFastState.Bounded env28269 := by
  intro p hp
  have h : env28269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28268_28269 : H12AffineEnvironment.transform 9 272 env28268 = env28269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28268 == env28269) = true)

def env28270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4160,73771,119879,21763,8193,64,43356,115014,102742,56437,1365,32,257,21793,46093,74251]

theorem envBound28270 : H12AffineFastState.Bounded env28270 := by
  intro p hp
  have h : env28270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28265_28270 : H12AffineEnvironment.transform 6 9 env28265 = env28270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28265 == env28270) = true)

theorem identity28270 : scanCanonicalize (H12AffineFastState.compose env28270 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28270 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1025,32769,4160,33,62541,21763,8193,64,43356,57676,45404,56437,1365,32,257,21793,46093,513]

theorem envBound28271 : H12AffineFastState.Bounded env28271 := by
  intro p hp
  have h : env28271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28270_28271 : H12AffineEnvironment.transform 15 8202 env28270 = env28271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28270 == env28271) = true)

theorem identity28271 : scanCanonicalize (H12AffineFastState.compose env28271 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28271 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10281,1025,8541,4160,33,21777,21763,8193,64,2048,16400,4096,32041,1365,32,257,21793,5457,513]

theorem envBound28272 : H12AffineFastState.Bounded env28272 := by
  intro p hp
  have h : env28272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28271_28272 : H12AffineEnvironment.transform 14 8540 env28271 = env28272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28271 == env28272) = true)

theorem identity28272 : scanCanonicalize (H12AffineFastState.compose env28272 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28272 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13388,10281,1025,8541,4160,33,17,3,8193,64,2048,5392,4096,10281,1365,32,257,33,5457,513]

theorem envBound28273 : H12AffineFastState.Bounded env28273 := by
  intro p hp
  have h : env28273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28272_28273 : H12AffineEnvironment.transform 13 5376 env28272 = env28273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28272 == env28273) = true)

theorem identity28273 : scanCanonicalize (H12AffineFastState.compose env28273 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28274 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10281,1025,8461,4112,33,17,3,8193,16,2048,5392,4096,10281,1285,32,257,33,5377,513]

theorem envBound28274 : H12AffineFastState.Bounded env28274 := by
  intro p hp
  have h : env28274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28273_28274 : H12AffineEnvironment.transform 5 16 env28273 = env28274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28273 == env28274) = true)

theorem identity28274 : scanCanonicalize (H12AffineFastState.compose env28274 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound28274 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28275 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5376,292,34,5172,2049,1025,293,4112,33,17,3,41,16,2048,5392,4096,2049,1285,32,257,33,5377,513]

theorem envBound28275 : H12AffineFastState.Bounded env28275 := by
  intro p hp
  have h : env28275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28274_28275 : H12AffineEnvironment.transform 12 40 env28274 = env28275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env28274 == env28275) = true)

theorem identity28275 : scanCanonicalize (H12AffineFastState.compose env28275 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28275 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28276 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5172,2049,1025,0,4112,33,17,3,41,16,2048,5173,4096,2049,1056,32,36,33,5156,513]

theorem envBound28276 : H12AffineFastState.Bounded env28276 := by
  intro p hp
  have h : env28276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28275_28276 : H12AffineEnvironment.transform 7 37 env28275 = env28276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28275 == env28276) = true)

theorem identity28276 : scanCanonicalize (H12AffineFastState.compose env28276 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28276 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28277 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,1,34,4096,2049,53,0,4112,33,17,3,41,16,2048,4097,4096,2049,20,32,36,33,4112,513]

theorem envBound28277 : H12AffineFastState.Bounded env28277 := by
  intro p hp
  have h : env28277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28276_28277 : H12AffineEnvironment.transform 9 52 env28276 = env28277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28276 == env28277) = true)

theorem identity28277 : scanCanonicalize (H12AffineFastState.compose env28277 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound28277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28278 : List Nat := [2,4,8,16,4,16,9,1,512,16,2048,4096,12,4113,1,6,4096,2049,17,0,4112,5,17,3,13,16,2048,4097,4096,2049,20,4,0,5,4112,513]

theorem envBound28278 : H12AffineFastState.Bounded env28278 := by
  intro p hp
  have h : env28278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28277_28278 : H12AffineEnvironment.transform 4 4 env28277 = env28278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env28277 == env28278) = true)

theorem identity28278 : scanCanonicalize (H12AffineFastState.compose env28278 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2584) := by decide +kernel

theorem selectedBound28278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28279 : List Nat := [2,4,8,16,4,16,9,1,512,16,2048,2584,12,2569,1,6,2584,2049,17,0,2568,5,17,3,13,16,2048,2585,2584,2049,20,4,0,5,2568,513]

theorem envBound28279 : H12AffineFastState.Bounded env28279 := by
  intro p hp
  have h : env28279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28278_28279 : H12AffineEnvironment.transform 11 2584 env28278 = env28279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2584 env28278 == env28279) = true)

theorem identity28279 : scanCanonicalize (H12AffineFastState.compose env28279 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound28279 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28280 : List Nat := [2,4,8,16,4,16,9,1,512,16,523,19,12,2,1,6,19,522,17,0,3,5,17,3,13,16,523,18,19,522,20,4,0,5,3,513]

theorem envBound28280 : H12AffineFastState.Bounded env28280 := by
  intro p hp
  have h : env28280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28279_28280 : H12AffineEnvironment.transform 10 523 env28279 = env28280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env28279 == env28280) = true)

theorem identity28280 : scanCanonicalize (H12AffineFastState.compose env28280 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28280 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28281 : List Nat := [2,1,8,16,1,16,9,1,512,16,523,19,9,2,1,3,19,522,17,0,3,0,17,3,8,16,523,18,19,522,17,1,0,0,3,513]

theorem envBound28281 : H12AffineFastState.Bounded env28281 := by
  intro p hp
  have h : env28281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28280_28281 : H12AffineEnvironment.transform 1 1 env28280 = env28281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28280 == env28281) = true)

def env28282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,4160,73770,120014,21763,8328,64,43477,115151,102879,56573,1500,168,257,21793,46212,74251]

theorem envBound28282 : H12AffineFastState.Bounded env28282 := by
  intro p hp
  have h : env28282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28264_28282 : H12AffineEnvironment.transform 17 10401 env28264 = env28282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28264 == env28282) = true)

def env28283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4160,73770,119878,21763,8192,64,43357,115015,102743,56437,1364,32,257,21793,46092,74251]

theorem envBound28283 : H12AffineFastState.Bounded env28283 := by
  intro p hp
  have h : env28283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28282_28283 : H12AffineEnvironment.transform 6 8 env28282 = env28283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28282 == env28283) = true)

theorem identity28283 : scanCanonicalize (H12AffineFastState.compose env28283 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111898,10281,1025,32769,4160,73770,98631,2,8192,64,43357,103494,102743,35188,1364,32,257,32,46092,74251]

theorem envBound28284 : H12AffineFastState.Bounded env28284 := by
  intro p hp
  have h : env28284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28283_28284 : H12AffineEnvironment.transform 13 5377 env28283 = env28284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28283 == env28284) = true)

theorem identity28284 : scanCanonicalize (H12AffineFastState.compose env28284 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28284 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,65536,103731,2048,1025,32769,4160,65539,98631,2,41,64,35188,103494,102743,35188,1364,32,257,32,37925,66082]

theorem envBound28285 : H12AffineFastState.Bounded env28285 := by
  intro p hp
  have h : env28285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28284_28285 : H12AffineEnvironment.transform 12 41 env28284 = env28285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28284 == env28285) = true)

theorem identity28285 : scanCanonicalize (H12AffineFastState.compose env28285 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28285 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env28286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,33110,5221,2048,1025,32769,4160,33109,17,2,41,64,35188,5392,4097,35188,1364,32,257,32,37925,33652]

theorem envBound28286 : H12AffineFastState.Bounded env28286 := by
  intro p hp
  have h : env28286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28285_28286 : H12AffineEnvironment.transform 15 33110 env28285 = env28286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28285 == env28286) = true)

theorem identity28286 : scanCanonicalize (H12AffineFastState.compose env28286 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 3173) := by decide +kernel

theorem selectedBound28286 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env28287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,3173,3379,5221,2048,1025,3172,4160,3376,17,2,41,64,1297,5392,4097,1297,1364,32,257,32,6208,3857]

theorem envBound28287 : H12AffineFastState.Bounded env28287 := by
  intro p hp
  have h : env28287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28286_28287 : H12AffineEnvironment.transform 14 3173 env28286 = env28287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3173 env28286 == env28287) = true)

theorem identity28287 : scanCanonicalize (H12AffineFastState.compose env28287 (packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28287 : packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env28288 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5156,3173,3094,5221,2048,1025,3172,4160,3093,17,2,41,64,1076,5173,4097,1076,1137,32,36,32,6208,3636]

theorem envBound28288 : H12AffineFastState.Bounded env28288 := by
  intro p hp
  have h : env28288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28287_28288 : H12AffineEnvironment.transform 7 37 env28287 = env28288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28287 == env28288) = true)

theorem identity28288 : scanCanonicalize (H12AffineFastState.compose env28288 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28288 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28289 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,41,4161,2048,2163,4096,2048,100,2049,4160,2160,17,2,41,64,81,4176,4097,81,20,32,36,32,6208,2641]

theorem envBound28289 : H12AffineFastState.Bounded env28289 := by
  intro p hp
  have h : env28289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28288_28289 : H12AffineEnvironment.transform 9 101 env28288 = env28289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28288 == env28289) = true)

theorem identity28289 : scanCanonicalize (H12AffineFastState.compose env28289 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound28289 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env28290 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,2112,41,2049,2048,2163,2112,2048,100,2049,2048,2160,17,2,41,64,81,2064,2113,81,20,32,36,32,0,2641]

theorem envBound28290 : H12AffineFastState.Bounded env28290 := by
  intro p hp
  have h : env28290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28289_28290 : H12AffineEnvironment.transform 11 2112 env28289 = env28290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env28289 == env28290) = true)

theorem identity28290 : scanCanonicalize (H12AffineFastState.compose env28290 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28290 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env28291 : List Nat := [2,4,8,16,32,64,8,37,512,101,0,64,41,1,0,115,64,0,100,1,0,112,17,2,41,64,81,16,65,81,20,32,36,32,0,593]

theorem envBound28291 : H12AffineFastState.Bounded env28291 := by
  intro p hp
  have h : env28291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28290_28291 : H12AffineEnvironment.transform 10 0 env28290 = env28291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28290 == env28291) = true)

theorem identity28291 : scanCanonicalize (H12AffineFastState.compose env28291 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28291 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28292 : List Nat := [2,4,8,16,0,64,8,5,512,69,0,64,9,1,0,83,64,0,68,1,0,80,17,2,9,64,81,16,65,81,20,0,4,0,0,593]

theorem envBound28292 : H12AffineFastState.Bounded env28292 := by
  intro p hp
  have h : env28292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28291_28292 : H12AffineEnvironment.transform 4 0 env28291 = env28292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28291 == env28292) = true)

def env28293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4160,73770,119879,21763,8193,64,43356,115014,102742,56436,1365,33,257,21793,46093,74251]

theorem envBound28293 : H12AffineFastState.Bounded env28293 := by
  intro p hp
  have h : env28293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28282_28293 : H12AffineEnvironment.transform 6 9 env28282 = env28293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28282 == env28293) = true)

theorem identity28293 : scanCanonicalize (H12AffineFastState.compose env28293 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28293 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,70727,10280,1025,29788,4160,73770,73754,21763,8193,64,23809,79131,91403,10281,1365,33,257,21793,16464,74251]

theorem envBound28294 : H12AffineFastState.Bounded env28294 := by
  intro p hp
  have h : env28294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28293_28294 : H12AffineEnvironment.transform 14 29789 env28293 = env28294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28293 == env28294) = true)

theorem identity28294 : scanCanonicalize (H12AffineFastState.compose env28294 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28294 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13389,10280,1025,29788,4160,32,16,21763,8193,64,23809,5393,17665,10281,1365,33,257,21793,16464,513]

theorem envBound28295 : H12AffineFastState.Bounded env28295 := by
  intro p hp
  have h : env28295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28294_28295 : H12AffineEnvironment.transform 15 8202 env28294 = env28295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28294 == env28295) = true)

theorem identity28295 : scanCanonicalize (H12AffineFastState.compose env28295 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28295 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env28296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,9292,8202,13389,10280,1025,9293,4160,32,16,1298,8193,64,3344,5393,5392,10281,1365,33,257,1328,4161,513]

theorem envBound28296 : H12AffineFastState.Bounded env28296 := by
  intro p hp
  have h : env28296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28295_28296 : H12AffineEnvironment.transform 13 4113 env28295 = env28296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28295 == env28296) = true)

theorem identity28296 : scanCanonicalize (H12AffineFastState.compose env28296 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound28296 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,65,8192,80,9292,8202,9228,10280,1025,9293,1,32,16,1298,8193,64,3344,1360,1361,10281,1365,33,257,1328,0,513]

theorem envBound28297 : H12AffineFastState.Bounded env28297 := by
  intro p hp
  have h : env28297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28296_28297 : H12AffineEnvironment.transform 11 65 env28296 = env28297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env28296 == env28297) = true)

theorem identity28297 : scanCanonicalize (H12AffineFastState.compose env28297 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound28297 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28298 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,65,8192,80,8541,8202,8477,10280,272,8540,1,32,16,3,8193,64,2049,65,64,10281,68,33,257,33,0,513]

theorem envBound28298 : H12AffineFastState.Bounded env28298 := by
  intro p hp
  have h : env28298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28297_28298 : H12AffineEnvironment.transform 9 273 env28297 = env28298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env28297 == env28298) = true)

theorem identity28298 : scanCanonicalize (H12AffineFastState.compose env28298 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28298 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28299 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,65,348,80,1,342,65,2420,272,0,1,32,16,3,349,64,2049,65,64,2421,68,33,257,33,0,513]

theorem envBound28299 : H12AffineFastState.Bounded env28299 := by
  intro p hp
  have h : env28299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28298_28299 : H12AffineEnvironment.transform 12 348 env28298 = env28299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28298 == env28299) = true)

theorem identity28299 : scanCanonicalize (H12AffineFastState.compose env28299 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound28299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28300 : List Nat := [2,4,8,16,32,64,9,53,512,36,2048,65,105,80,1,99,65,2113,37,0,1,32,16,3,104,64,2049,65,64,2112,68,33,52,33,0,513]

theorem envBound28300 : H12AffineFastState.Bounded env28300 := by
  intro p hp
  have h : env28300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28299_28300 : H12AffineEnvironment.transform 7 53 env28299 = env28300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env28299 == env28300) = true)

theorem identity28300 : scanCanonicalize (H12AffineFastState.compose env28300 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound28300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28301 : List Nat := [2,4,8,16,32,64,9,53,512,36,26,65,105,80,1,99,65,91,37,0,1,32,16,3,104,64,27,65,64,90,68,33,52,33,0,513]

theorem envBound28301 : H12AffineFastState.Bounded env28301 := by
  intro p hp
  have h : env28301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28300_28301 : H12AffineEnvironment.transform 10 26 env28300 = env28301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env28300 == env28301) = true)

theorem identity28301 : scanCanonicalize (H12AffineFastState.compose env28301 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound28301 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28302 : List Nat := [2,4,8,16,32,59,9,53,512,36,26,58,18,43,1,24,58,32,37,0,1,32,16,3,19,59,27,58,59,33,63,33,52,33,0,513]

theorem envBound28302 : H12AffineFastState.Bounded env28302 := by
  intro p hp
  have h : env28302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28301_28302 : H12AffineEnvironment.transform 5 59 env28301 = env28302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env28301 == env28302) = true)

theorem identity28302 : scanCanonicalize (H12AffineFastState.compose env28302 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28302 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28303 : List Nat := [2,4,8,0,32,43,9,37,512,36,10,42,2,43,1,8,42,32,37,0,1,32,0,3,3,43,11,42,43,33,47,33,36,33,0,513]

theorem envBound28303 : H12AffineFastState.Bounded env28303 := by
  intro p hp
  have h : env28303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28302_28303 : H12AffineEnvironment.transform 3 0 env28302 = env28303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28302 == env28303) = true)

theorem identity28303 : scanCanonicalize (H12AffineFastState.compose env28303 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28303 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28304 : List Nat := [2,4,0,0,32,35,1,37,512,36,2,34,2,35,1,0,34,32,37,0,1,32,0,3,3,35,3,34,35,33,39,33,36,33,0,513]

theorem envBound28304 : H12AffineFastState.Bounded env28304 := by
  intro p hp
  have h : env28304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28303_28304 : H12AffineEnvironment.transform 2 0 env28303 = env28304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28303 == env28304) = true)

def env28305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144476,243088,8328,64,43476,139613,160076,324701,1501,272392,257,21793,46212,74250]

theorem envBound28305 : H12AffineFastState.Bounded env28305 := by
  intro p hp
  have h : env28305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28262_28305 : H12AffineEnvironment.transform 20 4161 env28262 = env28305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28262 == env28305) = true)

theorem identity28305 : scanCanonicalize (H12AffineFastState.compose env28305 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28305 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,452632,144476,169371,8328,64,43476,139613,160076,324701,1501,272392,257,21793,46212,513]

theorem envBound28306 : H12AffineFastState.Bounded env28306 := by
  intro p hp
  have h : env28306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28305_28306 : H12AffineEnvironment.transform 15 8203 env28305 = env28306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28305 == env28306) = true)

def env28307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,305160,29772,54667,8328,64,43476,24909,12636,324701,1501,272392,257,21793,46212,513]

theorem envBound28307 : H12AffineFastState.Bounded env28307 := by
  intro p hp
  have h : env28307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28306_28307 : H12AffineEnvironment.transform 16 16400 env28306 = env28307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28306 == env28307) = true)

theorem identity28307 : scanCanonicalize (H12AffineFastState.compose env28307 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28307 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,262144,1025,32769,4161,305160,17,41430,8328,64,43476,5392,12636,294912,1501,272392,257,8572,46212,513]

theorem envBound28308 : H12AffineFastState.Bounded env28308 := by
  intro p hp
  have h : env28308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28307_28308 : H12AffineEnvironment.transform 13 13405 env28307 = env28308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28307 == env28308) = true)

theorem identity28308 : scanCanonicalize (H12AffineFastState.compose env28308 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43169) := by decide +kernel

theorem selectedBound28308 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,43169,1025,32769,4161,169,17,41430,8328,64,43476,5392,12636,10401,1501,32937,257,8572,46212,513]

theorem envBound28309 : H12AffineFastState.Bounded env28309 := by
  intro p hp
  have h : env28309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28308_28309 : H12AffineEnvironment.transform 17 43169 env28308 = env28309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43169 env28308 == env28309) = true)

theorem identity28309 : scanCanonicalize (H12AffineFastState.compose env28309 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound28309 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env28310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8661,8203,13389,2420,1025,8660,4161,169,17,3,8328,64,2049,5392,12636,10401,1501,8572,257,8572,5457,513]

theorem envBound28310 : H12AffineFastState.Bounded env28310 := by
  intro p hp
  have h : env28310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28309_28310 : H12AffineEnvironment.transform 14 8661 env28309 = env28310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env28309 == env28310) = true)

theorem identity28310 : scanCanonicalize (H12AffineFastState.compose env28310 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound28310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,1,479,5529,2420,1025,0,4161,169,17,3,348,64,2049,5392,4232,2421,1501,168,257,168,5457,513]

theorem envBound28311 : H12AffineFastState.Bounded env28311 := by
  intro p hp
  have h : env28311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28310_28311 : H12AffineEnvironment.transform 12 468 env28310 = env28311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env28310 == env28311) = true)

theorem identity28311 : scanCanonicalize (H12AffineFastState.compose env28311 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound28311 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env28312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1432,468,17,1,479,1,2420,1025,0,1497,169,17,3,348,64,2049,136,1296,2421,1501,168,257,168,201,513]

theorem envBound28312 : H12AffineFastState.Bounded env28312 := by
  intro p hp
  have h : env28312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28311_28312 : H12AffineEnvironment.transform 11 1432 env28311 = env28312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env28311 == env28312) = true)

theorem identity28312 : scanCanonicalize (H12AffineFastState.compose env28312 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound28312 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,130,1432,468,17,1,479,1,502,1025,0,1497,169,17,3,348,64,131,136,1296,503,1501,168,257,168,201,513]

theorem envBound28313 : H12AffineFastState.Bounded env28313 := by
  intro p hp
  have h : env28313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28312_28313 : H12AffineEnvironment.transform 10 130 env28312 = env28313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env28312 == env28313) = true)

theorem identity28313 : scanCanonicalize (H12AffineFastState.compose env28313 (packedSelected [4,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28313 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env28314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,11,1297,349,17,1,342,1,383,1025,0,1360,32,17,3,348,64,10,1,1296,382,1364,33,257,33,64,513]

theorem envBound28314 : H12AffineFastState.Bounded env28314 := by
  intro p hp
  have h : env28314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28313_28314 : H12AffineEnvironment.transform 6 9 env28313 = env28314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28313 == env28314) = true)

theorem identity28314 : scanCanonicalize (H12AffineFastState.compose env28314 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,11,1297,269,17,1,262,1,303,1025,0,1280,32,17,3,268,16,10,1,1296,302,1284,33,257,33,16,513]

theorem envBound28315 : H12AffineFastState.Bounded env28315 := by
  intro p hp
  have h : env28315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28314_28315 : H12AffineEnvironment.transform 5 16 env28314 = env28315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28314 == env28315) = true)

theorem identity28315 : scanCanonicalize (H12AffineFastState.compose env28315 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28316 : List Nat := [2,4,8,0,32,0,9,256,512,1024,11,1281,269,1,1,262,1,303,1025,0,1280,32,1,3,268,0,10,1,1280,302,1284,33,257,33,0,513]

theorem envBound28316 : H12AffineFastState.Bounded env28316 := by
  intro p hp
  have h : env28316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28315_28316 : H12AffineEnvironment.transform 3 0 env28315 = env28316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28315 == env28316) = true)

theorem identity28316 : scanCanonicalize (H12AffineFastState.compose env28316 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28316 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28317 : List Nat := [2,4,8,0,11,0,9,256,512,1024,11,1281,269,1,1,262,1,260,1025,0,1280,11,1,3,268,0,10,1,1280,261,1284,10,257,10,0,513]

theorem envBound28317 : H12AffineFastState.Bounded env28317 := by
  intro p hp
  have h : env28317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28316_28317 : H12AffineEnvironment.transform 4 11 env28316 = env28317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28316 == env28317) = true)

theorem identity28317 : scanCanonicalize (H12AffineFastState.compose env28317 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound28317 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28318 : List Nat := [2,4,8,0,11,0,9,256,512,256,11,1,269,1,1,262,1,260,257,0,0,11,1,3,268,0,10,1,0,261,4,10,257,10,0,513]

theorem envBound28318 : H12AffineFastState.Bounded env28318 := by
  intro p hp
  have h : env28318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28317_28318 : H12AffineEnvironment.transform 9 256 env28317 = env28318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env28317 == env28318) = true)

theorem identity28318 : scanCanonicalize (H12AffineFastState.compose env28318 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 12) := by decide +kernel

theorem selectedBound28318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28319 : List Nat := [2,4,8,0,11,0,9,12,512,12,11,1,1,1,1,10,1,8,13,0,0,11,1,3,0,0,10,1,0,9,4,10,13,10,0,513]

theorem envBound28319 : H12AffineFastState.Bounded env28319 := by
  intro p hp
  have h : env28319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28318_28319 : H12AffineEnvironment.transform 7 12 env28318 = env28319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 12 env28318 == env28319) = true)

theorem identity28319 : scanCanonicalize (H12AffineFastState.compose env28319 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28319 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env28320 : List Nat := [2,4,1,0,2,0,0,5,512,5,2,1,1,1,1,3,1,1,4,0,0,2,1,3,0,0,3,1,0,0,4,3,4,3,0,513]

theorem envBound28320 : H12AffineFastState.Bounded env28320 := by
  intro p hp
  have h : env28320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28319_28320 : H12AffineEnvironment.transform 2 1 env28319 = env28320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28319 == env28320) = true)

theorem identity28320 : scanCanonicalize (H12AffineFastState.compose env28320 (packedSelected [0,9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28320 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env28321 : List Nat := [0,4,1,0,0,0,0,5,512,5,0,1,1,1,1,1,1,1,4,0,0,0,1,1,0,0,1,1,0,0,4,1,4,1,0,513]

theorem envBound28321 : H12AffineFastState.Bounded env28321 := by
  intro p hp
  have h : env28321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28320_28321 : H12AffineEnvironment.transform 0 0 env28320 = env28321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28320 == env28321) = true)

theorem identity28321 : scanCanonicalize (H12AffineFastState.compose env28321 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound28321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28322 : List Nat := [0,4,1,0,0,0,0,5,4,5,0,1,1,1,1,1,1,1,4,0,0,0,1,1,0,0,1,1,0,0,4,1,4,1,0,5]

theorem envBound28322 : H12AffineFastState.Bounded env28322 := by
  intro p hp
  have h : env28322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28321_28322 : H12AffineEnvironment.transform 8 4 env28321 = env28322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env28321 == env28322) = true)

def env28323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305161,29773,54666,8328,64,43476,24908,12637,324701,1501,272392,257,21793,46212,513]

theorem envBound28323 : H12AffineFastState.Bounded env28323 := by
  intro p hp
  have h : env28323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28306_28323 : H12AffineEnvironment.transform 16 16401 env28306 = env28323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28306 == env28323) = true)

def env28324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305161,29773,54530,8192,64,43356,24908,12637,324701,1365,272392,257,21793,46092,513]

theorem envBound28324 : H12AffineFastState.Bounded env28324 := by
  intro p hp
  have h : env28324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28323_28324 : H12AffineEnvironment.transform 6 8 env28323 = env28324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28323 == env28324) = true)

theorem identity28324 : scanCanonicalize (H12AffineFastState.compose env28324 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound28324 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env28325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,32768,1095,16401,262144,1025,32769,4161,298053,20481,54530,1100,64,36112,17664,5393,315409,1365,265284,257,21793,36928,513]

theorem envBound28325 : H12AffineFastState.Bounded env28325 := by
  intro p hp
  have h : env28325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28324_28325 : H12AffineEnvironment.transform 12 1100 env28324 = env28325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env28324 == env28325) = true)

theorem identity28325 : scanCanonicalize (H12AffineFastState.compose env28325 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28325 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env28326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,32768,1095,5393,262144,1025,32769,4161,298053,1281,32770,1100,64,36112,4096,5393,296209,1365,265284,257,33,36928,513]

theorem envBound28326 : H12AffineFastState.Bounded env28326 := by
  intro p hp
  have h : env28326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28325_28326 : H12AffineEnvironment.transform 13 5376 env28325 = env28326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28325 == env28326) = true)

theorem identity28326 : scanCanonicalize (H12AffineFastState.compose env28326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound28326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,32768,1095,5393,35188,1025,32769,4161,1329,1281,32770,1100,64,36112,4096,5393,3173,1365,34096,257,33,36928,513]

theorem envBound28327 : H12AffineFastState.Bounded env28327 := by
  intro p hp
  have h : env28327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28326_28327 : H12AffineEnvironment.transform 17 35188 env28326 = env28327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env28326 == env28327) = true)

theorem identity28327 : scanCanonicalize (H12AffineFastState.compose env28327 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound28327 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1296,1095,5393,3172,1025,1297,4161,1329,1281,1298,1100,64,2048,4096,5393,3173,1365,32,257,33,5456,513]

theorem envBound28328 : H12AffineFastState.Bounded env28328 := by
  intro p hp
  have h : env28328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28327_28328 : H12AffineEnvironment.transform 14 1296 env28327 = env28328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env28327 == env28328) = true)

theorem identity28328 : scanCanonicalize (H12AffineFastState.compose env28328 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound28328 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env28329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1100,3345,1296,1095,3328,3172,1025,1297,2128,1329,1281,1298,1100,64,2048,2065,3328,3173,1365,32,257,33,3393,513]

theorem envBound28329 : H12AffineFastState.Bounded env28329 := by
  intro p hp
  have h : env28329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28328_28329 : H12AffineEnvironment.transform 11 2065 env28328 = env28329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env28328 == env28329) = true)

theorem identity28329 : scanCanonicalize (H12AffineFastState.compose env28329 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1873) := by decide +kernel

theorem selectedBound28329 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env28330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1873,1856,1100,576,1296,1095,593,821,1025,1297,1793,1329,1281,1298,1100,64,1873,1856,593,820,1365,32,257,33,528,513]

theorem envBound28330 : H12AffineFastState.Bounded env28330 := by
  intro p hp
  have h : env28330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28329_28330 : H12AffineEnvironment.transform 10 1873 env28329 = env28330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1873 env28329 == env28330) = true)

theorem identity28330 : scanCanonicalize (H12AffineFastState.compose env28330 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28330 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env28331 : List Nat := [2,4,8,16,32,64,8,256,512,100,821,804,40,576,372,35,593,821,101,373,869,341,357,374,40,64,821,804,593,820,305,32,257,33,528,513]

theorem envBound28331 : H12AffineFastState.Bounded env28331 := by
  intro p hp
  have h : env28331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28330_28331 : H12AffineEnvironment.transform 9 100 env28330 = env28331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28330 == env28331) = true)

theorem identity28331 : scanCanonicalize (H12AffineFastState.compose env28331 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound28331 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28332 : List Nat := [2,4,8,16,32,64,8,30,512,100,555,570,40,576,106,35,593,555,101,107,635,75,123,104,40,64,555,570,593,554,47,32,31,33,528,513]

theorem envBound28332 : H12AffineFastState.Bounded env28332 := by
  intro p hp
  have h : env28332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28331_28332 : H12AffineEnvironment.transform 7 30 env28331 = env28332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env28331 == env28332) = true)

theorem identity28332 : scanCanonicalize (H12AffineFastState.compose env28332 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28332 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env28333 : List Nat := [2,4,8,16,32,64,8,30,0,100,43,58,40,64,106,35,81,43,101,107,123,75,123,104,40,64,43,58,81,42,47,32,31,33,16,1]

theorem envBound28333 : H12AffineFastState.Bounded env28333 := by
  intro p hp
  have h : env28333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28332_28333 : H12AffineEnvironment.transform 8 0 env28332 = env28333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28332 == env28333) = true)

theorem identity28333 : scanCanonicalize (H12AffineFastState.compose env28333 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28333 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28334 : List Nat := [2,4,8,16,11,64,8,30,0,79,0,17,3,64,65,8,81,0,78,64,80,75,80,67,3,64,0,17,81,1,4,11,31,10,16,1]

theorem envBound28334 : H12AffineFastState.Bounded env28334 := by
  intro p hp
  have h : env28334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28333_28334 : H12AffineEnvironment.transform 4 11 env28333 = env28334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28333 == env28334) = true)

theorem identity28334 : scanCanonicalize (H12AffineFastState.compose env28334 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28335 : List Nat := [2,4,8,16,11,17,8,30,0,30,0,17,3,17,16,8,0,0,31,17,1,26,1,18,3,17,0,17,0,1,4,11,31,10,16,1]

theorem envBound28335 : H12AffineFastState.Bounded env28335 := by
  intro p hp
  have h : env28335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28334_28335 : H12AffineEnvironment.transform 5 17 env28334 = env28335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28334 == env28335) = true)

theorem identity28335 : scanCanonicalize (H12AffineFastState.compose env28335 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28335 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28336 : List Nat := [2,4,8,1,11,0,8,15,0,15,0,0,3,0,1,8,0,0,14,0,1,11,1,3,3,0,0,0,0,1,4,11,14,10,1,1]

theorem envBound28336 : H12AffineFastState.Bounded env28336 := by
  intro p hp
  have h : env28336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28335_28336 : H12AffineEnvironment.transform 3 1 env28335 = env28336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28335 == env28336) = true)

def env28337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305161,29773,54531,8193,64,43357,24908,12637,324701,1364,272392,257,21793,46093,513]

theorem envBound28337 : H12AffineFastState.Bounded env28337 := by
  intro p hp
  have h : env28337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28323_28337 : H12AffineEnvironment.transform 6 9 env28323 = env28337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28323 == env28337) = true)

def env28338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237469,243088,8328,64,2144660,2240796,160076,2417692,2102684,2373704,257,21793,46212,2175563]

theorem envBound28338 : H12AffineFastState.Bounded env28338 := by
  intro p hp
  have h : env28338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28261_28338 : H12AffineEnvironment.transform 21 452633 env28261 = env28338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env28261 == env28338) = true)

def env28339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144477,243088,8328,64,43476,139612,160076,324700,1500,272392,257,21793,46212,74251]

theorem envBound28339 : H12AffineFastState.Bounded env28339 := by
  intro p hp
  have h : env28339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28338_28339 : H12AffineEnvironment.transform 20 4160 env28338 = env28339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28338 == env28339) = true)

theorem identity28339 : scanCanonicalize (H12AffineFastState.compose env28339 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound28339 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,452633,144477,155983,8328,64,43476,139612,160076,324700,1500,272392,257,21793,46212,63188]

theorem envBound28340 : H12AffineFastState.Bounded env28340 := by
  intro p hp
  have h : env28340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28339_28340 : H12AffineEnvironment.transform 15 54495 env28339 = env28340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env28339 == env28340) = true)

def env28341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1025,32769,4160,54777,144477,155983,8328,64,43476,139612,160076,182716,1500,136680,257,21793,46212,63188]

theorem envBound28341 : H12AffineFastState.Bounded env28341 := by
  intro p hp
  have h : env28341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28340_28341 : H12AffineEnvironment.transform 17 146912 env28340 = env28341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env28340 == env28341) = true)

theorem identity28341 : scanCanonicalize (H12AffineFastState.compose env28341 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound28341 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,57749,56437,1025,32769,4160,54777,54728,32986,8328,64,43476,49353,37081,10281,1500,62589,257,21793,46212,63188]

theorem envBound28342 : H12AffineFastState.Bounded env28342 := by
  intro p hp
  have h : env28342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28341_28342 : H12AffineEnvironment.transform 16 57749 env28341 = env28342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env28341 == env28342) = true)

theorem identity28342 : scanCanonicalize (H12AffineFastState.compose env28342 (packedSelected [0,9,11,12,15,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound28342 : packedSelected [0,9,11,12,15,18,22,27] rootPS < 2^1333 := by decide +kernel

def env28343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,479,13461,2421,1025,21761,4160,249,200,21978,8328,64,31956,5577,17881,10281,1500,8573,257,21793,24964,9172]

theorem envBound28343 : H12AffineFastState.Bounded env28343 := by
  intro p hp
  have h : env28343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28342_28343 : H12AffineEnvironment.transform 14 21760 env28342 = env28343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env28342 == env28343) = true)

theorem identity28343 : scanCanonicalize (H12AffineFastState.compose env28343 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28343 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env28344 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,263,13389,2421,1025,21761,4160,33,16,21762,8272,64,31756,5393,17665,10281,1284,8573,257,21793,24924,8972]

theorem envBound28344 : H12AffineFastState.Bounded env28344 := by
  intro p hp
  have h : env28344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28343_28344 : H12AffineEnvironment.transform 6 88 env28343 = env28344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28343 == env28344) = true)

theorem identity28344 : scanCanonicalize (H12AffineFastState.compose env28344 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28344 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env28345 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13405,8541,263,13389,2421,1025,8540,4160,33,16,8543,8272,64,2129,5393,12636,10281,1284,8573,257,8572,5377,8972]

theorem envBound28345 : H12AffineFastState.Bounded env28345 := by
  intro p hp
  have h : env28345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28344_28345 : H12AffineEnvironment.transform 13 13405 env28344 = env28345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28344 == env28345) = true)

theorem identity28345 : scanCanonicalize (H12AffineFastState.compose env28345 (packedSelected [0,1,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28345 : packedSelected [0,1,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28346 : List Nat := [2,4,8,16,32,64,88,256,512,100,2048,4096,8192,12345,8541,263,12329,2421,101,8540,4160,33,16,8543,8272,64,2129,4469,12636,10281,352,8573,257,8572,4453,8972]

theorem envBound28346 : H12AffineFastState.Bounded env28346 := by
  intro p hp
  have h : env28346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28345_28346 : H12AffineEnvironment.transform 9 100 env28345 = env28346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28345 == env28346) = true)

theorem identity28346 : scanCanonicalize (H12AffineFastState.compose env28346 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28346 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28347 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,12345,8461,263,12329,2341,53,8460,4112,33,16,8463,8192,16,2049,4389,12556,10281,304,8493,257,8492,4405,8972]

theorem envBound28347 : H12AffineFastState.Bounded env28347 := by
  intro p hp
  have h : env28347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28346_28347 : H12AffineEnvironment.transform 5 16 env28346 = env28347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28346 == env28347) = true)

def env28348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1025,32769,4160,54776,144477,155983,8328,64,43476,139612,160076,182717,1500,136681,257,21793,46212,63188]

theorem envBound28348 : H12AffineFastState.Bounded env28348 := by
  intro p hp
  have h : env28348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28340_28348 : H12AffineEnvironment.transform 17 146913 env28340 = env28348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env28340 == env28348) = true)

theorem identity28348 : scanCanonicalize (H12AffineFastState.compose env28348 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound28348 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,57628,56573,1025,32769,4160,54776,54593,32851,8328,64,43476,49216,36944,10401,1500,62709,257,21793,46212,63188]

theorem envBound28349 : H12AffineFastState.Bounded env28349 := by
  intro p hp
  have h : env28349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28348_28349 : H12AffineEnvironment.transform 16 57628 env28348 = env28349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env28348 == env28349) = true)

theorem identity28349 : scanCanonicalize (H12AffineFastState.compose env28349 (packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28349 : packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS < 2^1333 := by decide +kernel

def env28350 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,54495,57448,56573,1025,32769,4160,54412,54325,32851,8328,64,43168,49216,36944,10401,1192,62709,117,21589,46212,63188]

theorem envBound28350 : H12AffineFastState.Bounded env28350 := by
  intro p hp
  have h : env28350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28349_28350 : H12AffineEnvironment.transform 7 116 env28349 = env28350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28349 == env28350) = true)

theorem identity28350 : scanCanonicalize (H12AffineFastState.compose env28350 (packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28350 : packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env28351 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,16384,32768,54415,57400,56493,1025,32769,4112,54412,54325,32771,8328,16,43168,49168,36864,10401,1192,62629,37,21509,46212,63108]

theorem envBound28351 : H12AffineFastState.Bounded env28351 := by
  intro p hp
  have h : env28351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28350_28351 : H12AffineEnvironment.transform 5 16 env28350 = env28351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28350 == env28351) = true)

theorem identity28351 : scanCanonicalize (H12AffineFastState.compose env28351 (packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound28351 : packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env28352 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,16384,8353,29742,16537,31756,1025,8352,4112,29741,29844,8354,8328,16,2049,24753,12449,10401,1192,21508,37,21509,5157,22053]

theorem envBound28352 : H12AffineFastState.Bounded env28352 := by
  intro p hp
  have h : env28352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28351_28352 : H12AffineEnvironment.transform 14 8353 env28351 = env28352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env28351 == env28352) = true)

def env28353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144476,243088,8328,64,43477,139613,160076,324701,1501,272393,257,21793,46212,74250]

theorem envBound28353 : H12AffineFastState.Bounded env28353 := by
  intro p hp
  have h : env28353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28338_28353 : H12AffineEnvironment.transform 20 4161 env28338 = env28353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28338 == env28353) = true)

theorem identity28353 : scanCanonicalize (H12AffineFastState.compose env28353 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound28353 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4161,392287,73754,41430,8328,64,43477,79131,91402,324701,1501,272393,257,21793,46212,74250]

theorem envBound28354 : H12AffineFastState.Bounded env28354 := by
  intro p hp
  have h : env28354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28353_28354 : H12AffineEnvironment.transform 16 70726 env28353 = env28354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env28353 == env28354) = true)

def env28355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,4161,120063,73754,41430,8328,64,43477,79131,91402,56573,1501,169,257,21793,46212,74250]

theorem envBound28355 : H12AffineFastState.Bounded env28355 := by
  intro p hp
  have h : env28355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28354_28355 : H12AffineEnvironment.transform 17 10400 env28354 = env28355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env28354 == env28355) = true)

theorem identity28355 : scanCanonicalize (H12AffineFastState.compose env28355 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound28355 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env28356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49304,10400,1025,32769,4161,33,62660,41430,8328,64,43477,57797,45524,56573,1501,169,257,21793,46212,63188]

theorem envBound28356 : H12AffineFastState.Bounded env28356 := by
  intro p hp
  have h : env28356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28355_28356 : H12AffineEnvironment.transform 15 54494 env28355 = env28356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env28355 == env28356) = true)

theorem identity28356 : scanCanonicalize (H12AffineFastState.compose env28356 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28356 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env28357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33166,38344,10400,1025,32769,4161,33,41364,41430,8328,64,43477,46229,45524,35245,1501,169,257,113,46212,41860]

theorem envBound28357 : H12AffineFastState.Bounded env28357 := by
  intro p hp
  have h : env28357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28356_28357 : H12AffineEnvironment.transform 13 5456 env28356 = env28357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28356 == env28357) = true)

theorem identity28357 : scanCanonicalize (H12AffineFastState.compose env28357 (packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound28357 : packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env28358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,81,479,5529,10400,1025,80,4161,33,8645,8583,8328,64,10628,13508,12677,2556,1501,169,257,113,13525,9173]

theorem envBound28358 : H12AffineFastState.Bounded env28358 := by
  intro p hp
  have h : env28358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28357_28358 : H12AffineEnvironment.transform 14 81 env28357 = env28358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env28357 == env28358) = true)

theorem identity28358 : scanCanonicalize (H12AffineFastState.compose env28358 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound28358 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env28359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,81,479,5529,2341,1025,80,4161,33,64,2,269,64,2049,5441,4096,2556,1501,169,257,113,5456,592]

theorem envBound28359 : H12AffineFastState.Bounded env28359 := by
  intro p hp
  have h : env28359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28358_28359 : H12AffineEnvironment.transform 12 389 env28358 = env28359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env28358 == env28359) = true)

theorem identity28359 : scanCanonicalize (H12AffineFastState.compose env28359 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28360 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5456,81,263,5441,2341,1025,80,4161,33,64,2,269,64,2049,5441,4096,2340,1285,113,257,113,5456,592]

theorem envBound28360 : H12AffineFastState.Bounded env28360 := by
  intro p hp
  have h : env28360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28359_28360 : H12AffineEnvironment.transform 6 88 env28359 = env28360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28359 == env28360) = true)

theorem identity28360 : scanCanonicalize (H12AffineFastState.compose env28360 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28360 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env28361 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,40,5157,81,114,5172,2128,1025,80,4161,33,64,2,120,64,2049,5172,4096,2129,1136,113,116,113,5157,592]

theorem envBound28361 : H12AffineFastState.Bounded env28361 := by
  intro p hp
  have h : env28361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28360_28361 : H12AffineEnvironment.transform 7 117 env28360 = env28361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28360 == env28361) = true)

theorem identity28361 : scanCanonicalize (H12AffineFastState.compose env28361 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28361 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28362 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,35,5172,2049,1025,1,4112,33,17,2,41,17,2049,5172,4096,2048,1057,32,37,32,5157,513]

theorem envBound28362 : H12AffineFastState.Bounded env28362 := by
  intro p hp
  have h : env28362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28361_28362 : H12AffineEnvironment.transform 5 17 env28361 = env28362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28361 == env28362) = true)

theorem identity28362 : scanCanonicalize (H12AffineFastState.compose env28362 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound28362 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28363 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,0,35,1029,2049,1025,1,33,33,17,2,41,17,2049,1029,49,2048,1057,32,37,32,1044,513]

theorem envBound28363 : H12AffineFastState.Bounded env28363 := by
  intro p hp
  have h : env28363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28362_28363 : H12AffineEnvironment.transform 11 49 env28362 = env28363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env28362 == env28363) = true)

theorem identity28363 : scanCanonicalize (H12AffineFastState.compose env28363 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound28363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28364 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1541,49,40,1044,0,35,1029,1540,1025,1,33,33,17,2,41,17,1540,1029,49,1541,1057,32,37,32,1044,513]

theorem envBound28364 : H12AffineFastState.Bounded env28364 := by
  intro p hp
  have h : env28364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28363_28364 : H12AffineEnvironment.transform 10 1541 env28363 = env28364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env28363 == env28364) = true)

def env28365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,4161,120062,73754,41430,8328,64,43477,79131,91402,56572,1501,168,257,21793,46212,74250]

theorem envBound28365 : H12AffineFastState.Bounded env28365 := by
  intro p hp
  have h : env28365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28354_28365 : H12AffineEnvironment.transform 17 10401 env28354 = env28365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28354 == env28365) = true)

theorem identity28365 : scanCanonicalize (H12AffineFastState.compose env28365 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21977) := by decide +kernel

theorem selectedBound28365 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env28366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21977,65536,70726,10401,1025,21976,4161,65831,73754,29711,8328,64,31756,79131,91402,2341,1501,168,257,21793,24925,74250]

theorem envBound28366 : H12AffineFastState.Bounded env28366 := by
  intro p hp
  have h : env28366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28365_28366 : H12AffineEnvironment.transform 14 21977 env28365 = env28366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21977 env28365 == env28366) = true)

theorem identity28366 : scanCanonicalize (H12AffineFastState.compose env28366 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound28366 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env28367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,509,65536,70726,10401,1025,508,4161,65831,73754,8235,8328,64,10280,79131,78126,2341,1501,168,257,261,13689,74250]

theorem envBound28367 : H12AffineFastState.Bounded env28367 := by
  intro p hp
  have h : env28367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28366_28367 : H12AffineEnvironment.transform 13 5156 env28366 = env28367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env28366 == env28367) = true)

theorem identity28367 : scanCanonicalize (H12AffineFastState.compose env28367 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound28367 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,509,263,5441,10401,1025,508,4161,32,8477,8235,8328,64,10280,13340,12329,2341,1501,168,257,261,13689,8973]

theorem envBound28368 : H12AffineFastState.Bounded env28368 := by
  intro p hp
  have h : env28368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28367_28368 : H12AffineEnvironment.transform 15 263 env28367 = env28368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env28367 == env28368) = true)

theorem identity28368 : scanCanonicalize (H12AffineFastState.compose env28368 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28368 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env28369 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,5156,248,2,5188,10401,1025,249,4161,32,8216,8235,8328,64,10280,13340,12329,2080,1240,168,4,0,13436,8712]

theorem envBound28369 : H12AffineFastState.Bounded env28369 := by
  intro p hp
  have h : env28369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28368_28369 : H12AffineEnvironment.transform 7 5 env28368 = env28369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28368 == env28369) = true)

theorem identity28369 : scanCanonicalize (H12AffineFastState.compose env28369 (packedSelected [0,2,3,5,7,10,12,14,15,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 208) := by decide +kernel

theorem selectedBound28369 : packedSelected [0,2,3,5,7,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env28370 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,208,5156,248,2,5188,2161,1025,249,4161,32,200,251,88,64,2296,5324,4345,2080,1240,168,4,0,5292,728]

theorem envBound28370 : H12AffineFastState.Bounded env28370 := by
  intro p hp
  have h : env28370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28369_28370 : H12AffineEnvironment.transform 12 208 env28369 = env28370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env28369 == env28370) = true)

theorem identity28370 : scanCanonicalize (H12AffineFastState.compose env28370 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28370 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28371 : List Nat := [2,4,8,16,1,64,128,5,512,1024,2048,4096,208,5125,217,2,5188,2128,1025,216,4161,1,200,218,88,64,2265,5324,4312,2049,1240,137,4,0,5261,728]

theorem envBound28371 : H12AffineFastState.Bounded env28371 := by
  intro p hp
  have h : env28371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28370_28371 : H12AffineEnvironment.transform 4 1 env28370 = env28371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28370 == env28371) = true)

theorem identity28371 : scanCanonicalize (H12AffineFastState.compose env28371 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28371 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28372 : List Nat := [2,4,8,16,1,16,128,5,512,1024,2048,4096,128,5125,137,2,5140,2048,1025,136,4113,1,152,138,8,16,2185,5276,4232,2049,1160,137,4,0,5261,648]

theorem envBound28372 : H12AffineFastState.Bounded env28372 := by
  intro p hp
  have h : env28372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28371_28372 : H12AffineEnvironment.transform 5 16 env28371 = env28372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28371 == env28372) = true)

theorem identity28372 : scanCanonicalize (H12AffineFastState.compose env28372 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28372 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28373 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5125,1,2,5140,2048,1025,0,4113,1,16,2,8,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound28373 : H12AffineFastState.Bounded env28373 := by
  intro p hp
  have h : env28373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28372_28373 : H12AffineEnvironment.transform 6 8 env28372 = env28373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28372 == env28373) = true)

def env28374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,243089,8328,64,6705548,2240797,160076,2417692,2102685,6475856,257,21792,46213,2175562]

theorem envBound28374 : H12AffineFastState.Bounded env28374 := by
  intro p hp
  have h : env28374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28260_28374 : H12AffineEnvironment.transform 23 243089 env28260 = env28374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env28260 == env28374) = true)

def env28375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237469,243089,8328,64,2144660,2240797,160076,2417692,2102685,2373704,257,21792,46213,2175562]

theorem envBound28375 : H12AffineFastState.Bounded env28375 := by
  intro p hp
  have h : env28375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28374_28375 : H12AffineEnvironment.transform 21 452632 env28374 = env28375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env28374 == env28375) = true)

def env28376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144477,243089,8328,64,43476,139613,160076,324700,1501,272392,257,21792,46213,74250]

theorem envBound28376 : H12AffineFastState.Bounded env28376 := by
  intro p hp
  have h : env28376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28375_28376 : H12AffineEnvironment.transform 20 4160 env28375 = env28376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28375 == env28376) = true)

def env28377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180272,144477,243089,8328,64,43476,139613,160076,56436,1501,32,257,21792,46213,74250]

theorem envBound28377 : H12AffineFastState.Bounded env28377 := by
  intro p hp
  have h : env28377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28376_28377 : H12AffineEnvironment.transform 17 10280 env28376 = env28377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env28376 == env28377) = true)

def env28378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,21792,41293,73857,8328,64,43476,46157,58460,56436,1501,32,257,21792,46213,74250]

theorem envBound28378 : H12AffineFastState.Bounded env28378 := by
  intro p hp
  have h : env28378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28377_28378 : H12AffineEnvironment.transform 16 38160 env28377 = env28378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28377 == env28378) = true)

theorem identity28378 : scanCanonicalize (H12AffineFastState.compose env28378 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28378 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,38160,10280,1025,32769,4160,21792,41293,41431,8328,64,43476,46157,58460,56436,1501,32,257,21792,46213,41820]

theorem envBound28379 : H12AffineFastState.Bounded env28379 := by
  intro p hp
  have h : env28379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28378_28379 : H12AffineEnvironment.transform 15 33110 env28378 = env28379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28378 == env28379) = true)

theorem identity28379 : scanCanonicalize (H12AffineFastState.compose env28379 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound28379 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28380 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32938,38124,10280,1025,32769,4160,21724,41137,41003,8328,64,43048,46157,58460,56436,1057,32,253,21724,46213,41632]

theorem envBound28380 : H12AffineFastState.Bounded env28380 := by
  intro p hp
  have h : env28380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28379_28380 : H12AffineEnvironment.transform 7 252 env28379 = env28380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env28379 == env28380) = true)

theorem identity28380 : scanCanonicalize (H12AffineFastState.compose env28380 (packedSelected [0,3,5,7,9,10,12,14,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound28380 : packedSelected [0,3,5,7,9,10,12,14,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env28381 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13325,32768,32938,38124,10280,1025,32769,4160,8401,41137,41003,8328,64,43048,46157,36945,43129,1057,32,253,8401,46213,41632]

theorem envBound28381 : H12AffineFastState.Bounded env28381 := by
  intro p hp
  have h : env28381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28380_28381 : H12AffineEnvironment.transform 13 13325 env28380 = env28381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env28380 == env28381) = true)

theorem identity28381 : scanCanonicalize (H12AffineFastState.compose env28381 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound28381 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env28382 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13325,136,34,5220,10280,1025,137,4160,8401,8249,8355,8328,64,10400,13509,4313,10481,1057,32,253,8401,13325,8744]

theorem envBound28382 : H12AffineFastState.Bounded env28382 := by
  intro p hp
  have h : env28382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28381_28382 : H12AffineEnvironment.transform 14 136 env28381 = env28382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env28381 == env28382) = true)

theorem identity28382 : scanCanonicalize (H12AffineFastState.compose env28382 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28382 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28383 : List Nat := [2,4,8,16,32,64,128,252,512,52,2048,4096,8192,12345,136,34,4176,10280,53,137,4160,8401,8249,8355,8328,64,10400,12529,4313,10481,21,32,253,8401,12345,8744]

theorem envBound28383 : H12AffineFastState.Bounded env28383 := by
  intro p hp
  have h : env28383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28382_28383 : H12AffineEnvironment.transform 9 52 env28382 = env28383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28382 == env28383) = true)

def env28384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,21793,41292,73856,8328,64,43476,46156,58461,56436,1501,32,257,21792,46213,74250]

theorem envBound28384 : H12AffineFastState.Bounded env28384 := by
  intro p hp
  have h : env28384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28377_28384 : H12AffineEnvironment.transform 16 38161 env28377 = env28384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28377 == env28384) = true)

theorem identity28384 : scanCanonicalize (H12AffineFastState.compose env28384 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound28384 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,38161,10280,1025,32769,4160,21793,41292,41310,8328,64,43476,46156,58461,56436,1501,32,257,21792,46213,41940]

theorem envBound28385 : H12AffineFastState.Bounded env28385 := by
  intro p hp
  have h : env28385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28384_28385 : H12AffineEnvironment.transform 15 33246 env28384 = env28385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env28384 == env28385) = true)

theorem identity28385 : scanCanonicalize (H12AffineFastState.compose env28385 (packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound28385 : packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env28386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,8402,13341,10280,1025,8461,4160,21793,64,82,8328,64,2264,5440,17745,32120,1501,32,257,21792,5513,728]

theorem envBound28386 : H12AffineFastState.Bounded env28386 := by
  intro p hp
  have h : env28386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28385_28386 : H12AffineEnvironment.transform 14 8460 env28385 = env28386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env28385 == env28386) = true)

theorem identity28386 : scanCanonicalize (H12AffineFastState.compose env28386 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound28386 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,8460,8402,13341,10280,1025,8461,4160,8321,64,82,8328,64,2264,5440,12529,2264,1501,32,257,8320,5513,728]

theorem envBound28387 : H12AffineFastState.Bounded env28387 := by
  intro p hp
  have h : env28387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28386_28387 : H12AffineEnvironment.transform 13 13728 env28386 = env28387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env28386 == env28387) = true)

theorem identity28387 : scanCanonicalize (H12AffineFastState.compose env28387 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28387 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env28388 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13525,8313,8402,13341,10280,1025,8312,4160,8321,64,82,8328,64,2264,5173,12529,2264,1192,32,116,8320,5372,728]

theorem envBound28388 : H12AffineFastState.Bounded env28388 := by
  intro p hp
  have h : env28388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28387_28388 : H12AffineEnvironment.transform 7 117 env28387 = env28388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28387 == env28388) = true)

theorem identity28388 : scanCanonicalize (H12AffineFastState.compose env28388 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound28388 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env28389 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,1173,4160,1260,1095,4232,3261,1025,1261,4160,1044,64,82,1053,64,2264,5173,5220,2264,1192,32,116,1045,5372,728]

theorem envBound28389 : H12AffineFastState.Bounded env28389 := by
  intro p hp
  have h : env28389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28388_28389 : H12AffineEnvironment.transform 12 1173 env28388 = env28389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env28388 == env28389) = true)

theorem identity28389 : scanCanonicalize (H12AffineFastState.compose env28389 (packedSelected [1,8,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28389 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env28390 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1173,4113,1213,1046,4232,3261,1025,1212,4113,1044,17,3,1053,17,2185,5173,5173,2185,1192,32,37,1045,5293,649]

theorem envBound28390 : H12AffineFastState.Bounded env28390 := by
  intro p hp
  have h : env28390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28389_28390 : H12AffineEnvironment.transform 5 17 env28389 = env28390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28389 == env28390) = true)

theorem identity28390 : scanCanonicalize (H12AffineFastState.compose env28390 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound28390 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28391 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2064,1173,2049,1213,1046,2200,3261,1025,1212,2049,1044,17,3,1053,17,2185,3109,3109,2185,1192,32,37,1045,3261,649]

theorem envBound28391 : H12AffineFastState.Bounded env28391 := by
  intro p hp
  have h : env28391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28390_28391 : H12AffineEnvironment.transform 11 2064 env28390 = env28391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env28390 == env28391) = true)

theorem identity28391 : scanCanonicalize (H12AffineFastState.compose env28391 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28391 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28392 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,2064,161,2049,137,34,2200,2185,53,136,2049,32,17,3,41,17,2185,2065,2065,2185,156,32,37,33,2185,649]

theorem envBound28392 : H12AffineFastState.Bounded env28392 := by
  intro p hp
  have h : env28392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28391_28392 : H12AffineEnvironment.transform 9 52 env28391 = env28392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28391 == env28392) = true)

theorem identity28392 : scanCanonicalize (H12AffineFastState.compose env28392 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

end H12CloudChart0