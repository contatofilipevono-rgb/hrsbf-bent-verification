import H12CloudChart0Data069

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound17640 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env17641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8282,131072,10281,1025,8541,4161,33,65,82,8192,65,146461,5392,4176,138293,1285,33,257,112,5377,513]

theorem envBound17641 : H12AffineFastState.Bounded env17641 := by
  intro p hp
  have h : env17641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17640_17641 : H12AffineEnvironment.transform 15 8282 env17640 = env17641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env17640 == env17641) = true)

theorem identity17641 : scanCanonicalize (H12AffineFastState.compose env17641 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound17641 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8282,13341,10281,1025,8541,4161,33,65,82,8192,65,2048,5392,4176,10280,1285,33,257,112,5377,513]

theorem envBound17642 : H12AffineFastState.Bounded env17642 := by
  intro p hp
  have h : env17642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17641_17642 : H12AffineEnvironment.transform 16 13341 env17641 = env17642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env17641 == env17642) = true)

theorem identity17642 : scanCanonicalize (H12AffineFastState.compose env17642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17643 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13341,10281,1025,8461,4113,33,17,2,8192,17,2048,5392,4096,10280,1285,33,257,32,5377,513]

theorem envBound17643 : H12AffineFastState.Bounded env17643 := by
  intro p hp
  have h : env17643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17642_17643 : H12AffineEnvironment.transform 5 16 env17642 = env17643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17642 == env17643) = true)

def env17644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1025,8660,4161,168,73874,73856,8328,65,203983,5529,77954,212198,75223,169,257,73771,79194,513]

theorem envBound17644 : H12AffineFastState.Bounded env17644 := by
  intro p hp
  have h : env17644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17638_17644 : H12AffineEnvironment.transform 13 5377 env17638 = env17644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17638 == env17644) = true)

theorem identity17644 : scanCanonicalize (H12AffineFastState.compose env17644 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound17644 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79131,10401,1025,8660,4161,168,73874,73856,8328,65,10708,5529,77954,2557,75223,169,257,73771,79194,513]

theorem envBound17645 : H12AffineFastState.Bounded env17645 := by
  intro p hp
  have h : env17645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17644_17645 : H12AffineEnvironment.transform 16 79131 env17644 = env17645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env17644 == env17645) = true)

theorem identity17645 : scanCanonicalize (H12AffineFastState.compose env17645 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17645 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env17646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,65536,70727,2557,1025,136,4161,168,65998,66012,468,65,2184,5529,70110,2557,66699,169,257,65911,70662,513]

theorem envBound17646 : H12AffineFastState.Bounded env17646 := by
  intro p hp
  have h : env17646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17645_17646 : H12AffineEnvironment.transform 12 348 env17645 = env17646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17645 == env17646) = true)

theorem identity17646 : scanCanonicalize (H12AffineFastState.compose env17646 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound17646 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,342,5393,2557,1025,136,4161,168,152,138,468,65,2184,5529,4232,2557,1501,169,257,33,5456,513]

theorem envBound17647 : H12AffineFastState.Bounded env17647 := by
  intro p hp
  have h : env17647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17646_17647 : H12AffineEnvironment.transform 15 342 env17646 = env17647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env17646 == env17647) = true)

theorem identity17647 : scanCanonicalize (H12AffineFastState.compose env17647 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound17647 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17648 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,80,342,5393,2340,1025,81,4161,113,65,83,269,65,2129,5440,4177,2340,1284,112,257,33,5456,513]

theorem envBound17648 : H12AffineFastState.Bounded env17648 := by
  intro p hp
  have h : env17648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17647_17648 : H12AffineEnvironment.transform 6 89 env17647 = env17648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env17647 == env17648) = true)

theorem identity17648 : scanCanonicalize (H12AffineFastState.compose env17648 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17648 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17649 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1025,1,4113,33,17,3,269,17,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound17649 : H12AffineFastState.Bounded env17649 := by
  intro p hp
  have h : env17649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17648_17649 : H12AffineEnvironment.transform 5 16 env17648 = env17649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17648 == env17649) = true)

theorem identity17649 : scanCanonicalize (H12AffineFastState.compose env17649 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound17649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17650 : List Nat := [2,4,8,16,32,16,9,256,512,289,2048,4096,268,4128,0,262,4144,2340,288,1,4113,33,17,3,269,17,2049,4145,4097,2340,37,32,257,33,4129,513]

theorem envBound17650 : H12AffineFastState.Bounded env17650 := by
  intro p hp
  have h : env17650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17649_17650 : H12AffineEnvironment.transform 9 289 env17649 = env17650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env17649 == env17650) = true)

theorem identity17650 : scanCanonicalize (H12AffineFastState.compose env17650 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound17650 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17651 : List Nat := [2,4,8,16,32,16,9,256,512,289,2048,820,268,788,0,262,772,2340,288,1,805,33,17,3,269,17,2049,773,821,2340,37,32,257,33,789,513]

theorem envBound17651 : H12AffineFastState.Bounded env17651 := by
  intro p hp
  have h : env17651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17650_17651 : H12AffineEnvironment.transform 11 820 env17650 = env17651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env17650 == env17651) = true)

theorem identity17651 : scanCanonicalize (H12AffineFastState.compose env17651 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17651 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17652 : List Nat := [2,4,8,16,32,16,9,4,512,37,2048,560,8,528,0,2,512,2080,36,1,545,33,17,3,9,17,2049,513,561,2080,37,32,5,33,529,513]

theorem envBound17652 : H12AffineFastState.Bounded env17652 := by
  intro p hp
  have h : env17652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17651_17652 : H12AffineEnvironment.transform 7 4 env17651 = env17652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17651 == env17652) = true)

theorem identity17652 : scanCanonicalize (H12AffineFastState.compose env17652 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound17652 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17653 : List Nat := [2,4,8,16,32,16,9,4,512,37,512,560,8,528,0,2,512,544,36,1,545,33,17,3,9,17,513,513,561,544,37,32,5,33,529,513]

theorem envBound17653 : H12AffineFastState.Bounded env17653 := by
  intro p hp
  have h : env17653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17652_17653 : H12AffineEnvironment.transform 10 512 env17652 = env17653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env17652 == env17653) = true)

theorem identity17653 : scanCanonicalize (H12AffineFastState.compose env17653 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17653 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env17654 : List Nat := [2,4,8,16,16,16,9,4,512,21,512,512,8,528,0,2,512,528,20,1,529,17,17,3,9,17,513,513,513,528,21,16,5,17,529,513]

theorem envBound17654 : H12AffineFastState.Bounded env17654 := by
  intro p hp
  have h : env17654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17653_17654 : H12AffineEnvironment.transform 4 16 env17653 = env17654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17653 == env17654) = true)

theorem identity17654 : scanCanonicalize (H12AffineFastState.compose env17654 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17655 : List Nat := [2,4,8,16,16,16,9,4,1,21,1,1,8,17,0,2,1,17,20,1,16,17,17,3,9,17,0,0,0,17,21,16,5,17,16,0]

theorem envBound17655 : H12AffineFastState.Bounded env17655 := by
  intro p hp
  have h : env17655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17654_17655 : H12AffineEnvironment.transform 8 1 env17654 = env17655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17654 == env17655) = true)

def env17656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431073,8328,65,2609402,302316,333859,2329970,119042,2373704,257,2199998,2191387,63188]

theorem envBound17656 : H12AffineFastState.Bounded env17656 := by
  intro p hp
  have h : env17656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17583_17656 : H12AffineEnvironment.transform 23 2431073 env17583 = env17656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env17583 == env17656) = true)

def env17657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329761,8328,65,508090,302316,333859,236850,119042,272392,257,98814,90203,63188]

theorem envBound17657 : H12AffineFastState.Bounded env17657 := by
  intro p hp
  have h : env17657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17656_17657 : H12AffineEnvironment.transform 20 4160 env17656 = env17657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17656 == env17657) = true)

theorem identity17657 : scanCanonicalize (H12AffineFastState.compose env17657 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17657 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,21928,351539,329761,8328,65,472175,288825,333859,223719,75223,272392,257,95531,90203,513]

theorem envBound17658 : H12AffineFastState.Bounded env17658 := by
  intro p hp
  have h : env17658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17657_17658 : H12AffineEnvironment.transform 14 29909 env17657 = env17658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17657 == env17658) = true)

def env17659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,21792,351539,329761,8192,65,472175,288825,333859,223599,75103,272392,257,95531,90203,513]

theorem envBound17659 : H12AffineFastState.Bounded env17659 := by
  intro p hp
  have h : env17659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17658_17659 : H12AffineEnvironment.transform 6 8 env17658 = env17659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17658 == env17659) = true)

theorem identity17659 : scanCanonicalize (H12AffineFastState.compose env17659 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound17659 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env17660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13340,262144,1025,29788,4160,21792,351539,329761,8192,65,327795,288825,333859,89459,75103,272392,257,95531,90203,513]

theorem envBound17660 : H12AffineFastState.Bounded env17660 := by
  intro p hp
  have h : env17660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17659_17660 : H12AffineEnvironment.transform 16 13340 env17659 = env17660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env17659 == env17660) = true)

theorem identity17660 : scanCanonicalize (H12AffineFastState.compose env17660 (packedSelected [0,2,3,4,5,6,9,10,12,15,18,19,20,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17660 : packedSelected [0,2,3,4,5,6,9,10,12,15,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env17661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13340,262144,1025,8540,4160,32,329779,329761,8192,65,327795,277817,333859,67699,75103,272392,257,73771,79195,513]

theorem envBound17661 : H12AffineFastState.Bounded env17661 := by
  intro p hp
  have h : env17661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17660_17661 : H12AffineEnvironment.transform 13 5376 env17660 = env17661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17660 == env17661) = true)

theorem identity17661 : scanCanonicalize (H12AffineFastState.compose env17661 (packedSelected [0,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound17661 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env17662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8282,13340,262144,1025,8540,4160,32,272489,272507,8192,65,270377,277817,276601,10281,1285,272392,257,113,5377,513]

theorem envBound17662 : H12AffineFastState.Bounded env17662 := by
  intro p hp
  have h : env17662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17661_17662 : H12AffineEnvironment.transform 15 8282 env17661 = env17662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env17661 == env17662) = true)

theorem identity17662 : scanCanonicalize (H12AffineFastState.compose env17662 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17662 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,342,5392,262144,1025,80,4160,32,264549,264567,268,65,262437,269365,268661,2341,1285,264452,257,113,5377,513]

theorem envBound17663 : H12AffineFastState.Bounded env17663 := by
  intro p hp
  have h : env17663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17662_17663 : H12AffineEnvironment.transform 12 268 env17662 = env17663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17662 == env17663) = true)

theorem identity17663 : scanCanonicalize (H12AffineFastState.compose env17663 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17663 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17664 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,262144,1025,0,4112,32,264501,264487,268,17,262437,269365,268581,2341,1285,264452,257,33,5377,513]

theorem envBound17664 : H12AffineFastState.Bounded env17664 := by
  intro p hp
  have h : env17664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17663_17664 : H12AffineEnvironment.transform 5 16 env17663 = env17664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17663 == env17664) = true)

theorem identity17664 : scanCanonicalize (H12AffineFastState.compose env17664 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound17664 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env17665 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,4096,268,5376,1,262,5392,262144,1025,0,4112,32,262160,262146,268,17,262437,267536,266240,0,1285,262177,257,33,5377,513]

theorem envBound17665 : H12AffineFastState.Bounded env17665 := by
  intro p hp
  have h : env17665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17664_17665 : H12AffineEnvironment.transform 10 293 env17664 = env17665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17664 == env17665) = true)

theorem identity17665 : scanCanonicalize (H12AffineFastState.compose env17665 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17665 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17666 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,4096,268,5376,1,262,5392,4112,1025,0,4112,32,4096,4114,268,17,4405,1280,16,0,1285,4145,257,33,5377,513]

theorem envBound17666 : H12AffineFastState.Bounded env17666 := by
  intro p hp
  have h : env17666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17665_17666 : H12AffineEnvironment.transform 17 4112 env17665 = env17666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env17665 == env17666) = true)

theorem identity17666 : scanCanonicalize (H12AffineFastState.compose env17666 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17666 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17667 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,4096,268,4405,1,262,4389,4112,52,0,4112,32,4096,4114,268,17,4405,309,16,0,304,4145,257,33,4404,513]

theorem envBound17667 : H12AffineFastState.Bounded env17667 := by
  intro p hp
  have h : env17667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17666_17667 : H12AffineEnvironment.transform 9 53 env17666 = env17667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17666 == env17667) = true)

theorem identity17667 : scanCanonicalize (H12AffineFastState.compose env17667 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound17667 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env17668 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,308,268,1,1,262,17,292,52,0,292,32,308,294,268,17,1,309,16,0,304,261,257,33,0,513]

theorem envBound17668 : H12AffineFastState.Bounded env17668 := by
  intro p hp
  have h : env17668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17667_17668 : H12AffineEnvironment.transform 11 308 env17667 = env17668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env17667 == env17668) = true)

theorem identity17668 : scanCanonicalize (H12AffineFastState.compose env17668 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound17668 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env17669 : List Nat := [2,4,8,16,32,16,8,256,308,53,293,308,268,1,1,262,17,292,52,0,292,32,308,294,268,17,1,309,16,0,304,261,257,33,0,309]

theorem envBound17669 : H12AffineFastState.Bounded env17669 := by
  intro p hp
  have h : env17669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17668_17669 : H12AffineEnvironment.transform 8 308 env17668 = env17669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env17668 == env17669) = true)

theorem identity17669 : scanCanonicalize (H12AffineFastState.compose env17669 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17669 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17670 : List Nat := [2,4,8,16,1,16,8,256,277,20,260,277,268,1,1,262,17,261,21,0,261,1,277,263,268,17,1,276,16,0,273,261,257,0,0,276]

theorem envBound17670 : H12AffineFastState.Bounded env17670 := by
  intro p hp
  have h : env17670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17669_17670 : H12AffineEnvironment.transform 4 1 env17669 = env17670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17669 == env17670) = true)

def env17671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,21793,351539,329761,8193,65,472175,288825,333859,223598,75102,272392,257,95531,90203,513]

theorem envBound17671 : H12AffineFastState.Bounded env17671 := by
  intro p hp
  have h : env17671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17658_17671 : H12AffineEnvironment.transform 6 9 env17658 = env17671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17658 == env17671) = true)

theorem identity17671 : scanCanonicalize (H12AffineFastState.compose env17671 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17671 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,4160,21793,351539,329761,8193,65,283765,288825,333859,2420,75102,272392,257,95531,90203,513]

theorem envBound17672 : H12AffineFastState.Bounded env17672 := by
  intro p hp
  have h : env17672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17671_17672 : H12AffineEnvironment.transform 16 90138 env17671 = env17672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17671 == env17672) = true)

theorem identity17672 : scanCanonicalize (H12AffineFastState.compose env17672 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound17672 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env17673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,20530,12328,262144,1025,29789,4160,21793,265473,284691,8193,65,283765,288825,280593,2420,30060,272392,257,9497,12393,513]

theorem envBound17673 : H12AffineFastState.Bounded env17673 := by
  intro p hp
  have h : env17673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17672_17673 : H12AffineEnvironment.transform 15 20530 env17672 = env17673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env17672 == env17673) = true)

theorem identity17673 : scanCanonicalize (H12AffineFastState.compose env17673 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound17673 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env17674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,1046,12328,262144,1025,8313,4160,261,265473,265271,8193,65,262225,277533,269365,2420,8520,272392,257,9497,12393,513]

theorem envBound17674 : H12AffineFastState.Bounded env17674 := by
  intro p hp
  have h : env17674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17673_17674 : H12AffineEnvironment.transform 13 5156 env17673 = env17674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env17673 == env17674) = true)

theorem identity17674 : scanCanonicalize (H12AffineFastState.compose env17674 (packedSelected [1,3,4,9,12,14,15,17,20,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound17674 : packedSelected [1,3,4,9,12,14,15,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env17675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,1046,12328,2340,1025,8313,4160,261,1061,1299,8193,65,2421,13625,5393,2420,8520,8492,257,9497,12393,513]

theorem envBound17675 : H12AffineFastState.Bounded env17675 := by
  intro p hp
  have h : env17675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17674_17675 : H12AffineEnvironment.transform 17 2340 env17674 = env17675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env17674 == env17675) = true)

theorem identity17675 : scanCanonicalize (H12AffineFastState.compose env17675 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17675 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env17676 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,8312,1046,12328,2048,1025,8313,4160,33,1061,1079,8193,65,2129,13341,5173,2128,8300,8200,37,9277,12393,513]

theorem envBound17676 : H12AffineFastState.Bounded env17676 := by
  intro p hp
  have h : env17676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17675_17676 : H12AffineEnvironment.transform 7 36 env17675 = env17676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17675 == env17676) = true)

theorem identity17676 : scanCanonicalize (H12AffineFastState.compose env17676 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17676 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17677 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,8192,4112,8312,34,12328,2048,53,8313,4160,33,17,3,8193,65,2129,12329,4097,2128,8300,8200,37,8201,12393,513]

theorem envBound17677 : H12AffineFastState.Bounded env17677 := by
  intro p hp
  have h : env17677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17676_17677 : H12AffineEnvironment.transform 9 52 env17676 = env17677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17676 == env17677) = true)

theorem identity17677 : scanCanonicalize (H12AffineFastState.compose env17677 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound17677 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env17678 : List Nat := [2,4,8,16,32,64,9,36,512,52,561,4096,8192,4112,8312,34,12328,561,53,8313,4160,33,17,3,8193,65,608,12329,4097,609,8300,8200,37,8201,12393,513]

theorem envBound17678 : H12AffineFastState.Bounded env17678 := by
  intro p hp
  have h : env17678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17677_17678 : H12AffineEnvironment.transform 10 561 env17677 = env17678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env17677 == env17678) = true)

theorem identity17678 : scanCanonicalize (H12AffineFastState.compose env17678 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17678 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env17679 : List Nat := [2,4,8,16,0,64,9,4,512,20,529,4096,8192,4112,8280,2,12296,529,21,8281,4160,1,17,3,8193,65,576,12297,4097,577,8268,8200,5,8201,12361,513]

theorem envBound17679 : H12AffineFastState.Bounded env17679 := by
  intro p hp
  have h : env17679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17678_17679 : H12AffineEnvironment.transform 4 0 env17678 = env17679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17678 == env17679) = true)

theorem identity17679 : scanCanonicalize (H12AffineFastState.compose env17679 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17679 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env17680 : List Nat := [2,4,8,16,0,16,9,4,512,20,529,4096,8192,4112,8200,2,12296,529,21,8201,4112,1,17,3,8193,17,528,12297,4097,529,8220,8200,5,8201,12313,513]

theorem envBound17680 : H12AffineFastState.Bounded env17680 := by
  intro p hp
  have h : env17680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17679_17680 : H12AffineEnvironment.transform 5 16 env17679 = env17680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17679 == env17680) = true)

theorem identity17680 : scanCanonicalize (H12AffineFastState.compose env17680 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound17680 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17681 : List Nat := [2,4,8,16,0,16,9,4,512,20,529,4096,537,4112,529,2,4625,529,21,528,4112,1,17,3,536,17,528,4624,4097,529,517,529,5,528,4608,513]

theorem envBound17681 : H12AffineFastState.Bounded env17681 := by
  intro p hp
  have h : env17681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17680_17681 : H12AffineEnvironment.transform 12 537 env17680 = env17681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env17680 == env17681) = true)

theorem identity17681 : scanCanonicalize (H12AffineFastState.compose env17681 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound17681 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17682 : List Nat := [2,4,8,16,0,16,9,4,512,20,529,512,537,528,529,2,17,529,21,528,528,1,17,3,536,17,528,16,513,529,517,529,5,528,0,513]

theorem envBound17682 : H12AffineFastState.Bounded env17682 := by
  intro p hp
  have h : env17682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17681_17682 : H12AffineEnvironment.transform 11 512 env17681 = env17682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env17681 == env17682) = true)

theorem identity17682 : scanCanonicalize (H12AffineFastState.compose env17682 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17682 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17683 : List Nat := [2,4,8,0,0,0,9,4,512,4,513,512,521,512,513,2,1,513,5,512,512,1,1,3,520,1,512,0,513,513,517,513,5,512,0,513]

theorem envBound17683 : H12AffineFastState.Bounded env17683 := by
  intro p hp
  have h : env17683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17682_17683 : H12AffineEnvironment.transform 3 0 env17682 = env17683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17682 == env17683) = true)

theorem identity17683 : scanCanonicalize (H12AffineFastState.compose env17683 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17683 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17684 : List Nat := [2,4,8,0,0,0,9,4,1,4,0,1,8,1,0,2,1,0,5,1,1,1,1,3,9,1,1,0,0,0,4,0,5,1,0,0]

theorem envBound17684 : H12AffineFastState.Bounded env17684 := by
  intro p hp
  have h : env17684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17683_17684 : H12AffineEnvironment.transform 8 1 env17683 = env17684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17683 == env17684) = true)

def env17685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329760,8328,65,508091,302316,333859,236851,119042,272393,257,98815,90202,63188]

theorem envBound17685 : H12AffineFastState.Bounded env17685 := by
  intro p hp
  have h : env17685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17656_17685 : H12AffineEnvironment.transform 20 4161 env17656 = env17685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17656 == env17685) = true)

theorem identity17685 : scanCanonicalize (H12AffineFastState.compose env17685 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound17685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,4161,21929,120015,98781,8328,65,215366,5393,102878,236851,119042,41460,257,98815,90202,63188]

theorem envBound17686 : H12AffineFastState.Bounded env17686 := by
  intro p hp
  have h : env17686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17685_17686 : H12AffineEnvironment.transform 17 35325 env17685 = env17686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env17685 == env17686) = true)

def env17687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1025,8541,4161,21929,95635,73857,8328,65,215366,5393,77954,212079,94302,168,257,73891,90202,22408]

theorem envBound17687 : H12AffineFastState.Bounded env17687 := by
  intro p hp
  have h : env17687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17686_17687 : H12AffineEnvironment.transform 14 8540 env17686 = env17687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17686 == env17687) = true)

theorem identity17687 : scanCanonicalize (H12AffineFastState.compose env17687 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound17687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1025,8541,4161,32,73754,73857,8328,65,203983,5393,77954,212079,75223,168,257,73891,79315,513]

theorem envBound17688 : H12AffineFastState.Bounded env17688 := by
  intro p hp
  have h : env17688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17687_17688 : H12AffineEnvironment.transform 13 5513 env17687 = env17688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17687 == env17688) = true)

theorem identity17688 : scanCanonicalize (H12AffineFastState.compose env17688 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17688 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env17689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,65536,131072,2477,1025,81,4161,32,65814,65933,388,65,203983,5393,70030,204131,66779,168,257,65967,70879,513]

theorem envBound17689 : H12AffineFastState.Bounded env17689 := by
  intro p hp
  have h : env17689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17688_17689 : H12AffineEnvironment.transform 12 268 env17688 = env17689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17688 == env17689) = true)

theorem identity17689 : scanCanonicalize (H12AffineFastState.compose env17689 (packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17689 : packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env17690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,65536,5392,2477,1025,81,4161,32,65814,65933,388,65,68063,5393,70030,67699,66779,168,257,65967,70879,513]

theorem envBound17690 : H12AffineFastState.Bounded env17690 := by
  intro p hp
  have h : env17690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17689_17690 : H12AffineEnvironment.transform 16 5392 env17689 = env17690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17689 == env17690) = true)

theorem identity17690 : scanCanonicalize (H12AffineFastState.compose env17690 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17690 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,262,5392,2477,1025,81,4161,32,16,139,388,65,2265,5393,4232,2421,1501,168,257,169,5593,513]

theorem envBound17691 : H12AffineFastState.Bounded env17691 := by
  intro p hp
  have h : env17691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17690_17691 : H12AffineEnvironment.transform 15 262 env17690 = env17691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17690 == env17691) = true)

def env17692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1025,8540,4161,21929,95634,73856,8328,65,215366,5393,77955,212078,94303,169,257,73890,90202,22409]

theorem envBound17692 : H12AffineFastState.Bounded env17692 := by
  intro p hp
  have h : env17692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17686_17692 : H12AffineEnvironment.transform 14 8541 env17686 = env17692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17686 == env17692) = true)

theorem identity17692 : scanCanonicalize (H12AffineFastState.compose env17692 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound17692 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,131072,10400,1025,8540,4161,21929,21777,3,8328,65,158149,5393,4096,138477,20700,169,257,33,16601,22409]

theorem envBound17693 : H12AffineFastState.Bounded env17693 := by
  intro p hp
  have h : env17693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17692_17693 : H12AffineEnvironment.transform 15 8323 env17692 = env17693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env17692 == env17693) = true)

theorem identity17693 : scanCanonicalize (H12AffineFastState.compose env17693 (packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound17693 : packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env17694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,13340,10400,1025,8540,4161,21929,21777,3,8328,65,24025,5393,4096,10481,20700,169,257,33,16601,22409]

theorem envBound17694 : H12AffineFastState.Bounded env17694 := by
  intro p hp
  have h : env17694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17693_17694 : H12AffineEnvironment.transform 16 13340 env17693 = env17694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env17693 == env17694) = true)

theorem identity17694 : scanCanonicalize (H12AffineFastState.compose env17694 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17694 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS < 2^1333 := by decide +kernel

def env17695 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8313,8323,13340,10400,1025,8312,4161,21645,21557,3,8328,65,23805,5173,4096,10481,20700,169,37,33,16601,22189]

theorem envBound17695 : H12AffineFastState.Bounded env17695 := by
  intro p hp
  have h : env17695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17694_17695 : H12AffineEnvironment.transform 7 36 env17694 = env17695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17694 == env17695) = true)

theorem identity17695 : scanCanonicalize (H12AffineFastState.compose env17695 (packedSelected [1,2,3,4,5,6,8,10,11,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound17695 : packedSelected [1,2,3,4,5,6,8,10,11,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env17696 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,136,114,5357,2129,1025,137,4161,21645,21557,3,121,65,23805,5173,4096,2048,20700,169,37,33,16601,22189]

theorem envBound17696 : H12AffineFastState.Bounded env17696 := by
  intro p hp
  have h : env17696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17695_17696 : H12AffineEnvironment.transform 12 241 env17695 = env17696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env17695 == env17696) = true)

theorem identity17696 : scanCanonicalize (H12AffineFastState.compose env17696 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound17696 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env17697 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5373,136,114,5357,2129,1025,137,4161,112,200,3,121,65,2048,5173,4096,2048,1057,169,37,33,5156,592]

theorem envBound17697 : H12AffineFastState.Bounded env17697 := by
  intro p hp
  have h : env17697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17696_17697 : H12AffineEnvironment.transform 13 5373 env17696 = env17697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env17696 == env17697) = true)

theorem identity17697 : scanCanonicalize (H12AffineFastState.compose env17697 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17697 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17698 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5292,136,35,5308,2048,1025,137,4112,33,153,3,40,16,2048,5173,4096,2048,1057,169,37,33,5156,513]

theorem envBound17698 : H12AffineFastState.Bounded env17698 := by
  intro p hp
  have h : env17698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17697_17698 : H12AffineEnvironment.transform 5 17 env17697 = env17698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17697 == env17698) = true)

theorem identity17698 : scanCanonicalize (H12AffineFastState.compose env17698 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17698 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17699 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4112,33,17,3,40,16,2048,5173,4096,2048,1057,33,37,33,5156,513]

theorem envBound17699 : H12AffineFastState.Bounded env17699 := by
  intro p hp
  have h : env17699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17698_17699 : H12AffineEnvironment.transform 6 8 env17698 = env17699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17698 == env17699) = true)

theorem identity17699 : scanCanonicalize (H12AffineFastState.compose env17699 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound17699 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17700 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,33,40,1029,0,35,1045,2048,1025,1,49,33,17,3,40,16,2048,1044,33,2048,1057,33,37,33,1029,513]

theorem envBound17700 : H12AffineFastState.Bounded env17700 := by
  intro p hp
  have h : env17700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17699_17700 : H12AffineEnvironment.transform 11 33 env17699 = env17700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env17699 == env17700) = true)

theorem identity17700 : scanCanonicalize (H12AffineFastState.compose env17700 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound17700 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17701 : List Nat := [2,4,8,16,32,17,8,36,512,1024,11,33,40,1029,0,35,1045,11,1025,1,49,33,17,3,40,16,11,1044,33,11,1057,33,37,33,1029,513]

theorem envBound17701 : H12AffineFastState.Bounded env17701 := by
  intro p hp
  have h : env17701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17700_17701 : H12AffineEnvironment.transform 10 11 env17700 = env17701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env17700 == env17701) = true)

theorem identity17701 : scanCanonicalize (H12AffineFastState.compose env17701 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound17701 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17702 : List Nat := [2,4,8,16,32,17,8,36,512,548,11,33,40,545,0,35,561,11,549,1,49,33,17,3,40,16,11,560,33,11,517,33,37,33,545,513]

theorem envBound17702 : H12AffineFastState.Bounded env17702 := by
  intro p hp
  have h : env17702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17701_17702 : H12AffineEnvironment.transform 9 548 env17701 = env17702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env17701 == env17702) = true)

theorem identity17702 : scanCanonicalize (H12AffineFastState.compose env17702 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17702 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17703 : List Nat := [2,4,2,16,32,17,2,36,512,548,1,33,34,545,0,35,561,1,549,1,49,33,17,3,34,16,1,560,33,1,517,33,37,33,545,513]

theorem envBound17703 : H12AffineFastState.Bounded env17703 := by
  intro p hp
  have h : env17703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17702_17703 : H12AffineEnvironment.transform 2 2 env17702 = env17703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17702 == env17703) = true)

theorem identity17703 : scanCanonicalize (H12AffineFastState.compose env17703 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17703 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17704 : List Nat := [2,4,2,16,0,17,2,4,512,516,1,1,2,513,0,3,529,1,517,1,17,1,17,3,2,16,1,528,1,1,517,1,5,1,513,513]

theorem envBound17704 : H12AffineFastState.Bounded env17704 := by
  intro p hp
  have h : env17704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17703_17704 : H12AffineEnvironment.transform 4 0 env17703 = env17704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17703 == env17704) = true)

theorem identity17704 : scanCanonicalize (H12AffineFastState.compose env17704 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound17704 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17705 : List Nat := [2,3,2,16,0,17,2,3,512,515,1,1,2,513,0,3,529,1,514,1,17,1,17,3,2,16,1,528,1,1,514,1,2,1,513,513]

theorem envBound17705 : H12AffineFastState.Bounded env17705 := by
  intro p hp
  have h : env17705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17704_17705 : H12AffineEnvironment.transform 1 3 env17704 = env17705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env17704 == env17705) = true)

theorem identity17705 : scanCanonicalize (H12AffineFastState.compose env17705 (packedSelected [0,8] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound17705 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env17706 : List Nat := [2,3,2,16,0,17,2,3,16,19,1,1,2,17,0,3,1,1,18,1,17,1,17,3,2,16,1,0,1,1,18,1,2,1,17,17]

theorem envBound17706 : H12AffineFastState.Bounded env17706 := by
  intro p hp
  have h : env17706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17705_17706 : H12AffineEnvironment.transform 8 16 env17705 = env17706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env17705 == env17706) = true)

theorem identity17706 : scanCanonicalize (H12AffineFastState.compose env17706 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound17706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17707 : List Nat := [2,3,2,2,0,3,2,3,2,1,1,1,2,3,0,3,1,1,0,1,3,1,3,3,2,2,1,0,1,1,0,1,2,1,3,3]

theorem envBound17707 : H12AffineFastState.Bounded env17707 := by
  intro p hp
  have h : env17707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17706_17707 : H12AffineEnvironment.transform 3 2 env17706 = env17707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env17706 == env17707) = true)

def env17708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,16777216,8328,65,16959642,18973837,333859,2329970,19188067,16850984,257,17074655,17066106,19263157]

theorem envBound17708 : H12AffineFastState.Bounded env17708 := by
  intro p hp
  have h : env17708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17582_17708 : H12AffineEnvironment.transform 21 2115049 env17582 = env17708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env17582 == env17708) = true)

def env17709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431072,8328,65,2609402,302317,333859,2329970,119043,2373704,257,2199999,2191386,63189]

theorem envBound17709 : H12AffineFastState.Bounded env17709 := by
  intro p hp
  have h : env17709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17708_17709 : H12AffineEnvironment.transform 23 2431072 env17708 = env17709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env17708 == env17709) = true)

def env17710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329760,8328,65,508090,302317,333859,236850,119043,272392,257,98815,90202,63189]

theorem envBound17710 : H12AffineFastState.Bounded env17710 := by
  intro p hp
  have h : env17710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17709_17710 : H12AffineEnvironment.transform 20 4160 env17709 = env17710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17709 == env17710) = true)

theorem identity17710 : scanCanonicalize (H12AffineFastState.compose env17710 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17710 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21929,294200,272427,8328,65,450737,302317,276520,179513,61704,272392,257,41460,16465,63189]

theorem envBound17711 : H12AffineFastState.Bounded env17711 := by
  intro p hp
  have h : env17711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17710_17711 : H12AffineEnvironment.transform 15 8203 env17710 = env17711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17710 == env17711) = true)

def env17712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21793,294200,272427,8192,65,450617,302181,276520,179513,61704,272392,257,41340,16465,63069]

theorem envBound17712 : H12AffineFastState.Bounded env17712 := by
  intro p hp
  have h : env17712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17711_17712 : H12AffineEnvironment.transform 6 8 env17711 = env17712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17711 == env17712) = true)

theorem identity17712 : scanCanonicalize (H12AffineFastState.compose env17712 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17712 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,262144,1025,29789,4160,21793,294200,272427,8192,65,398437,288825,276520,149861,1364,272392,257,21792,16465,513]

theorem envBound17713 : H12AffineFastState.Bounded env17713 := by
  intro p hp
  have h : env17713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17712_17713 : H12AffineEnvironment.transform 14 29788 env17712 = env17713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17712 == env17713) = true)

theorem identity17713 : scanCanonicalize (H12AffineFastState.compose env17713 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound17713 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env17714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4160,21793,17,21762,8192,65,158028,5392,17665,149861,1364,21793,257,21792,16465,513]

theorem envBound17714 : H12AffineFastState.Bounded env17714 := by
  intro p hp
  have h : env17714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17713_17714 : H12AffineEnvironment.transform 17 32041 env17713 = env17714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env17713 == env17714) = true)

theorem identity17714 : scanCanonicalize (H12AffineFastState.compose env17714 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17714 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8203,131072,2340,1025,80,4160,8492,17,8463,8192,65,138561,5392,12556,146792,1364,8492,257,8493,13404,513]

theorem envBound17715 : H12AffineFastState.Bounded env17715 := by
  intro p hp
  have h : env17715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17714_17715 : H12AffineEnvironment.transform 13 13325 env17714 = env17715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env17714 == env17715) = true)

theorem identity17715 : scanCanonicalize (H12AffineFastState.compose env17715 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17715 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env17716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8203,5393,2340,1025,80,4160,8492,17,8463,8192,65,2128,5392,12556,10361,1364,8492,257,8493,13404,513]

theorem envBound17716 : H12AffineFastState.Bounded env17716 := by
  intro p hp
  have h : env17716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17715_17716 : H12AffineEnvironment.transform 16 5393 env17715 = env17716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17715 == env17716) = true)

theorem identity17716 : scanCanonicalize (H12AffineFastState.compose env17716 (packedSelected [1,2,3,5,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 7464) := by decide +kernel

theorem selectedBound17716 : packedSelected [1,2,3,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7464,2341,81,7459,5393,2340,1025,80,4160,7172,17,7207,7464,65,2128,5392,3108,5457,1364,7172,257,7173,2420,513]

theorem envBound17717 : H12AffineFastState.Bounded env17717 := by
  intro p hp
  have h : env17717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17716_17717 : H12AffineEnvironment.transform 12 7464 env17716 = env17717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7464 env17716 == env17717) = true)

theorem identity17717 : scanCanonicalize (H12AffineFastState.compose env17717 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound17717 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1337,2341,81,1330,3328,2340,1025,80,2129,1045,17,1078,1337,65,2128,3329,3108,3392,1364,1045,257,1044,2420,513]

theorem envBound17718 : H12AffineFastState.Bounded env17718 := by
  intro p hp
  have h : env17718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17717_17718 : H12AffineEnvironment.transform 11 2065 env17717 = env17718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env17717 == env17718) = true)

theorem identity17718 : scanCanonicalize (H12AffineFastState.compose env17718 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17718 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env17719 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2065,40,2341,81,35,2065,2340,272,80,2129,260,17,295,40,65,2128,2064,2357,2129,69,260,257,261,2420,513]

theorem envBound17719 : H12AffineFastState.Bounded env17719 := by
  intro p hp
  have h : env17719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17718_17719 : H12AffineEnvironment.transform 9 273 env17718 = env17719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17718 == env17719) = true)

theorem identity17719 : scanCanonicalize (H12AffineFastState.compose env17719 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17719 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env17720 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2065,40,2341,1,35,2065,2340,272,0,2049,260,17,295,40,17,2048,2064,2357,2049,21,260,257,261,2340,513]

theorem envBound17720 : H12AffineFastState.Bounded env17720 := by
  intro p hp
  have h : env17720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17719_17720 : H12AffineEnvironment.transform 5 16 env17719 = env17720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17719 == env17720) = true)

theorem identity17720 : scanCanonicalize (H12AffineFastState.compose env17720 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17721 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2065,40,2048,1,35,2065,2049,53,0,2049,33,17,2,40,17,2048,2064,2064,2049,21,33,36,32,2049,513]

theorem envBound17721 : H12AffineFastState.Bounded env17721 := by
  intro p hp
  have h : env17721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17720_17721 : H12AffineEnvironment.transform 7 37 env17720 = env17721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17720 == env17721) = true)

theorem identity17721 : scanCanonicalize (H12AffineFastState.compose env17721 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17722 : List Nat := [2,4,8,16,32,16,8,37,32,52,2048,2065,40,2048,1,35,2065,2049,53,0,2049,33,17,2,40,17,2048,2064,2064,2049,21,33,36,32,2049,33]

theorem envBound17722 : H12AffineFastState.Bounded env17722 := by
  intro p hp
  have h : env17722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17721_17722 : H12AffineEnvironment.transform 8 32 env17721 = env17722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17721 == env17722) = true)

theorem identity17722 : scanCanonicalize (H12AffineFastState.compose env17722 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound17722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17723 : List Nat := [2,4,8,16,32,16,8,37,32,52,16,1,40,16,1,35,1,17,53,0,17,33,17,2,40,17,16,0,0,17,21,33,36,32,17,33]

theorem envBound17723 : H12AffineFastState.Bounded env17723 := by
  intro p hp
  have h : env17723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17722_17723 : H12AffineEnvironment.transform 10 16 env17722 = env17723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env17722 == env17723) = true)

def env17724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21792,294200,272427,8193,65,450616,302180,276520,179513,61704,272392,257,41341,16465,63068]

theorem envBound17724 : H12AffineFastState.Bounded env17724 := by
  intro p hp
  have h : env17724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17711_17724 : H12AffineEnvironment.transform 6 9 env17711 = env17724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17711 == env17724) = true)

theorem identity17724 : scanCanonicalize (H12AffineFastState.compose env17724 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17724 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,21792,294200,272427,8193,65,303145,302180,276520,64808,61704,272392,257,41341,16465,63068]

theorem envBound17725 : H12AffineFastState.Bounded env17725 := by
  intro p hp
  have h : env17725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17724_17725 : H12AffineEnvironment.transform 16 16401 env17724 = env17725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17724 == env17725) = true)

theorem identity17725 : scanCanonicalize (H12AffineFastState.compose env17725 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17725 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16401,262144,1025,29788,4160,21792,294200,272427,8193,65,283764,288825,276520,2421,1365,272392,257,21792,16465,513]

theorem envBound17726 : H12AffineFastState.Bounded env17726 := by
  intro p hp
  have h : env17726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17725_17726 : H12AffineEnvironment.transform 14 29789 env17725 = env17726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17725 == env17726) = true)

theorem identity17726 : scanCanonicalize (H12AffineFastState.compose env17726 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 11340) := by decide +kernel

theorem selectedBound17726 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env17727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16401,11340,1025,29788,4160,21792,20852,1127,8193,65,30776,17525,5220,2421,1365,1092,257,21792,16465,513]

theorem envBound17727 : H12AffineFastState.Bounded env17727 := by
  intro p hp
  have h : env17727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17726_17727 : H12AffineEnvironment.transform 17 11340 env17726 = env17727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11340 env17726 == env17727) = true)

theorem identity17727 : scanCanonicalize (H12AffineFastState.compose env17727 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound17727 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env17728 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,29005,8203,16401,10588,273,29004,4160,20528,20852,375,8193,65,30776,16741,4468,2421,69,340,257,20528,16465,513]

theorem envBound17728 : H12AffineFastState.Bounded env17728 := by
  intro p hp
  have h : env17728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17727_17728 : H12AffineEnvironment.transform 9 272 env17727 = env17728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17727 == env17728) = true)

theorem identity17728 : scanCanonicalize (H12AffineFastState.compose env17728 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17728 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17729 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,8192,16384,28729,8203,16401,10280,101,28728,4160,20528,20480,3,8193,65,30776,16401,4096,2049,69,32,117,20528,16465,513]

theorem envBound17729 : H12AffineFastState.Bounded env17729 := by
  intro p hp
  have h : env17729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17728_17729 : H12AffineEnvironment.transform 7 116 env17728 = env17729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17728 == env17729) = true)

theorem identity17729 : scanCanonicalize (H12AffineFastState.compose env17729 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17729 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17730 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,8192,4113,8232,8203,4096,10280,101,8233,4160,33,17,3,8193,65,10281,4096,4096,2049,69,32,117,33,4160,513]

theorem envBound17730 : H12AffineFastState.Bounded env17730 := by
  intro p hp
  have h : env17730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17729_17730 : H12AffineEnvironment.transform 13 4113 env17729 = env17730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17729 == env17730) = true)

theorem identity17730 : scanCanonicalize (H12AffineFastState.compose env17730 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17731 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,8192,4113,8232,8203,4096,10280,52,8233,4113,33,17,3,8193,16,10281,4096,4096,2049,20,32,36,33,4113,513]

theorem envBound17731 : H12AffineFastState.Bounded env17731 := by
  intro p hp
  have h : env17731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17730_17731 : H12AffineEnvironment.transform 5 17 env17730 = env17731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17730 == env17731) = true)

theorem identity17731 : scanCanonicalize (H12AffineFastState.compose env17731 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound17731 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17732 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,4105,4113,4129,4098,4096,6177,52,4128,4113,33,17,3,4104,16,6176,4096,4096,2049,20,32,36,33,4113,513]

theorem envBound17732 : H12AffineFastState.Bounded env17732 := by
  intro p hp
  have h : env17732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17731_17732 : H12AffineEnvironment.transform 12 4105 env17731 = env17732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env17731 == env17732) = true)

theorem identity17732 : scanCanonicalize (H12AffineFastState.compose env17732 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound17732 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17733 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,529,536,512,560,531,529,2608,52,561,512,33,17,3,537,16,2609,529,529,2049,20,32,36,33,512,513]

theorem envBound17733 : H12AffineFastState.Bounded env17733 := by
  intro p hp
  have h : env17733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17732_17733 : H12AffineEnvironment.transform 11 529 env17732 = env17733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env17732 == env17733) = true)

def env17734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329761,8328,65,508091,302317,333859,236851,119043,272393,257,98814,90203,63189]

theorem envBound17734 : H12AffineFastState.Bounded env17734 := by
  intro p hp
  have h : env17734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17709_17734 : H12AffineEnvironment.transform 20 4161 env17709 = env17734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17709 == env17734) = true)

theorem identity17734 : scanCanonicalize (H12AffineFastState.compose env17734 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound17734 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4161,21928,17,21762,8328,65,171416,115150,17664,236851,119043,95530,257,98814,90203,63189]

theorem envBound17735 : H12AffineFastState.Bounded env17735 := by
  intro p hp
  have h : env17735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17734_17735 : H12AffineEnvironment.transform 17 89379 env17734 = env17735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env17734 == env17735) = true)

theorem identity17735 : scanCanonicalize (H12AffineFastState.compose env17735 (packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound17735 : packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env17736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21928,17,21762,8328,65,35324,115150,17664,100695,119043,95530,257,98814,90203,63189]

theorem envBound17736 : H12AffineFastState.Bounded env17736 := by
  intro p hp
  have h : env17736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17735_17736 : H12AffineEnvironment.transform 16 5220 env17735 = env17736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env17735 == env17736) = true)

def env17737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21792,17,21762,8192,65,35188,115014,17664,100695,119043,95530,257,98678,90203,63069]

theorem envBound17737 : H12AffineFastState.Bounded env17737 := by
  intro p hp
  have h : env17737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17736_17737 : H12AffineEnvironment.transform 6 8 env17736 = env17737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17736 == env17737) = true)

theorem identity17737 : scanCanonicalize (H12AffineFastState.compose env17737 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17737 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5220,89379,1025,29789,4161,21792,17,21762,8192,65,32040,79130,17664,97547,75103,95530,257,95530,90203,513]

theorem envBound17738 : H12AffineFastState.Bounded env17738 := by
  intro p hp
  have h : env17738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17737_17738 : H12AffineEnvironment.transform 14 29788 env17737 = env17738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17737 == env17738) = true)

theorem identity17738 : scanCanonicalize (H12AffineFastState.compose env17738 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17738 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env17739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,5220,32041,1025,29789,4161,21792,17,21762,8192,65,32040,5392,17664,23809,1365,21792,257,21792,16465,513]

theorem envBound17739 : H12AffineFastState.Bounded env17739 := by
  intro p hp
  have h : env17739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17738_17739 : H12AffineEnvironment.transform 15 8202 env17738 = env17739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17738 == env17739) = true)

theorem identity17739 : scanCanonicalize (H12AffineFastState.compose env17739 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound17739 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,5220,2421,1025,1,4161,8572,17,8542,8192,65,2420,5392,12636,10589,1365,8572,257,8572,13325,513]

theorem envBound17740 : H12AffineFastState.Bounded env17740 := by
  intro p hp
  have h : env17740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17739_17740 : H12AffineEnvironment.transform 13 13404 env17739 = env17740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env17739 == env17740) = true)

theorem identity17740 : scanCanonicalize (H12AffineFastState.compose env17740 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17740 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5220,2421,1025,1,4161,32,17,2,348,65,2420,5392,4096,2049,1365,32,257,32,5457,513]

theorem envBound17741 : H12AffineFastState.Bounded env17741 := by
  intro p hp
  have h : env17741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17740_17741 : H12AffineEnvironment.transform 12 348 env17740 = env17741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17740 == env17741) = true)

theorem identity17741 : scanCanonicalize (H12AffineFastState.compose env17741 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17741 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env17742 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,5237,0,35,5220,2048,1025,1,4161,32,17,2,41,65,2049,5221,4096,2049,1056,32,116,32,5156,513]

theorem envBound17742 : H12AffineFastState.Bounded env17742 := by
  intro p hp
  have h : env17742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17741_17742 : H12AffineEnvironment.transform 7 117 env17741 = env17742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17741 == env17742) = true)

theorem identity17742 : scanCanonicalize (H12AffineFastState.compose env17742 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound17742 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17743 : List Nat := [2,4,8,16,32,64,8,117,512,1024,603,4096,41,5237,0,35,5220,603,1025,1,4161,32,17,2,41,65,602,5221,4096,602,1056,32,116,32,5156,513]

theorem envBound17743 : H12AffineFastState.Bounded env17743 := by
  intro p hp
  have h : env17743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17742_17743 : H12AffineEnvironment.transform 10 603 env17742 = env17743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env17742 == env17743) = true)

theorem identity17743 : scanCanonicalize (H12AffineFastState.compose env17743 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17743 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17744 : List Nat := [2,4,8,16,32,64,8,117,512,101,603,4096,41,4112,0,35,4097,603,100,1,4161,32,17,2,41,65,602,4096,4096,602,69,32,116,32,4161,513]

theorem envBound17744 : H12AffineFastState.Bounded env17744 := by
  intro p hp
  have h : env17744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17743_17744 : H12AffineEnvironment.transform 9 101 env17743 = env17744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17743 == env17744) = true)

theorem identity17744 : scanCanonicalize (H12AffineFastState.compose env17744 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound17744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17745 : List Nat := [2,4,8,16,32,64,8,117,512,101,603,64,41,80,0,35,65,603,100,1,1,32,17,2,41,65,602,64,64,602,69,32,116,32,1,513]

theorem envBound17745 : H12AffineFastState.Bounded env17745 := by
  intro p hp
  have h : env17745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17744_17745 : H12AffineEnvironment.transform 11 64 env17744 = env17745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env17744 == env17745) = true)

theorem identity17745 : scanCanonicalize (H12AffineFastState.compose env17745 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound17745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17746 : List Nat := [2,4,8,16,32,64,8,117,4,101,95,64,41,80,0,35,65,95,100,1,1,32,17,2,41,65,94,64,64,94,69,32,116,32,1,5]

theorem envBound17746 : H12AffineFastState.Bounded env17746 := by
  intro p hp
  have h : env17746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17745_17746 : H12AffineEnvironment.transform 8 4 env17745 = env17746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env17745 == env17746) = true)

theorem identity17746 : scanCanonicalize (H12AffineFastState.compose env17746 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound17746 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17747 : List Nat := [2,4,8,16,32,62,8,11,4,27,33,62,41,46,0,35,63,33,26,1,1,32,17,2,41,63,32,62,62,32,59,32,10,32,1,5]

theorem envBound17747 : H12AffineFastState.Bounded env17747 := by
  intro p hp
  have h : env17747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17746_17747 : H12AffineEnvironment.transform 5 62 env17746 = env17747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env17746 == env17747) = true)

theorem identity17747 : scanCanonicalize (H12AffineFastState.compose env17747 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound17747 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17748 : List Nat := [0,4,8,16,32,60,8,9,4,25,33,60,41,44,0,33,61,33,24,1,1,32,17,0,41,61,32,60,60,32,57,32,8,32,1,5]

theorem envBound17748 : H12AffineFastState.Bounded env17748 := by
  intro p hp
  have h : env17748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17747_17748 : H12AffineEnvironment.transform 0 0 env17747 = env17748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env17747 == env17748) = true)

theorem identity17748 : scanCanonicalize (H12AffineFastState.compose env17748 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17748 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env17749 : List Nat := [0,4,8,16,0,28,8,9,4,25,1,28,9,12,0,1,29,1,24,1,1,0,17,0,9,29,0,28,28,0,25,0,8,0,1,5]

theorem envBound17749 : H12AffineFastState.Bounded env17749 := by
  intro p hp
  have h : env17749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17748_17749 : H12AffineEnvironment.transform 4 0 env17748 = env17749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17748 == env17749) = true)

def env17750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21793,17,21762,8193,65,35189,115015,17664,100695,119043,95530,257,98679,90203,63068]

theorem envBound17750 : H12AffineFastState.Bounded env17750 := by
  intro p hp
  have h : env17750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17736_17750 : H12AffineEnvironment.transform 6 9 env17736 = env17750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17736 == env17750) = true)

theorem identity17750 : scanCanonicalize (H12AffineFastState.compose env17750 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17750 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5220,67618,1025,32769,4161,32,17,3,8193,65,35189,103494,4097,100695,99330,73771,257,98679,79194,41821]

theorem envBound17751 : H12AffineFastState.Bounded env17751 := by
  intro p hp
  have h : env17751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17750_17751 : H12AffineEnvironment.transform 13 5377 env17750 = env17751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17750 == env17751) = true)

theorem identity17751 : scanCanonicalize (H12AffineFastState.compose env17751 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound17751 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40970,5220,43048,1025,32769,4161,32,17,3,8193,65,35189,13388,4097,10589,9224,32801,257,8573,38224,41821]

theorem envBound17752 : H12AffineFastState.Bounded env17752 := by
  intro p hp
  have h : env17752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17751_17752 : H12AffineEnvironment.transform 15 40970 env17751 = env17752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env17751 == env17752) = true)

theorem identity17752 : scanCanonicalize (H12AffineFastState.compose env17752 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound17752 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,263,5220,2341,1025,8460,4161,32,17,3,8193,65,10360,13388,4097,10589,9224,8492,257,8573,13405,592]

theorem envBound17753 : H12AffineFastState.Bounded env17753 := by
  intro p hp
  have h : env17753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17752_17753 : H12AffineEnvironment.transform 14 8461 env17752 = env17753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env17752 == env17753) = true)

theorem identity17753 : scanCanonicalize (H12AffineFastState.compose env17753 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17753 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,263,5220,2341,1025,0,4161,32,17,3,269,65,2420,5440,4097,2129,1284,32,257,113,5457,592]

theorem envBound17754 : H12AffineFastState.Bounded env17754 := by
  intro p hp
  have h : env17754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17753_17754 : H12AffineEnvironment.transform 12 268 env17753 = env17754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17753 == env17754) = true)

theorem identity17754 : scanCanonicalize (H12AffineFastState.compose env17754 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17754 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17755 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,1,114,5220,2128,1025,0,4161,32,17,3,120,65,2049,5173,4097,2129,1137,32,116,113,5156,592]

theorem envBound17755 : H12AffineFastState.Bounded env17755 := by
  intro p hp
  have h : env17755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17754_17755 : H12AffineEnvironment.transform 7 117 env17754 = env17755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17754 == env17755) = true)

theorem identity17755 : scanCanonicalize (H12AffineFastState.compose env17755 (packedSelected [3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17755 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env17756 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,8,5125,1,3,5141,2081,1025,0,4144,32,17,3,9,48,2049,5173,4097,2080,1024,32,5,0,5156,545]

theorem envBound17756 : H12AffineFastState.Bounded env17756 := by
  intro p hp
  have h : env17756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17755_17756 : H12AffineEnvironment.transform 5 49 env17755 = env17756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17755 == env17756) = true)

theorem identity17756 : scanCanonicalize (H12AffineFastState.compose env17756 (packedSelected [0,7,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17756 : packedSelected [0,7,14] rootPS < 2^1333 := by decide +kernel

def env17757 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5125,1,3,5141,2048,1025,0,4113,1,17,3,9,17,2049,5140,4097,2049,1024,1,5,0,5125,512]

theorem envBound17757 : H12AffineFastState.Bounded env17757 := by
  intro p hp
  have h : env17757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17756_17757 : H12AffineEnvironment.transform 4 1 env17756 = env17757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17756 == env17757) = true)

def env17758 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1045,1,3,1029,2048,1025,0,1,1,17,3,9,17,2049,1028,17,2049,1024,1,5,0,1045,512]

theorem envBound17758 : H12AffineFastState.Bounded env17758 := by
  intro p hp
  have h : env17758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17757_17758 : H12AffineEnvironment.transform 11 16 env17757 = env17758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17757 == env17758) = true)

def env17759 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,1,3,17,2048,21,0,1,1,17,3,9,17,2049,16,17,2049,20,1,5,0,1,512]

theorem envBound17759 : H12AffineFastState.Bounded env17759 := by
  intro p hp
  have h : env17759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17758_17759 : H12AffineEnvironment.transform 9 20 env17758 = env17759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17758 == env17759) = true)

theorem identity17759 : scanCanonicalize (H12AffineFastState.compose env17759 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound17759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17760 : List Nat := [2,4,8,16,1,16,9,4,512,20,543,16,8,1,1,3,17,543,21,0,1,1,17,3,9,17,542,16,17,542,20,1,5,0,1,512]

theorem envBound17760 : H12AffineFastState.Bounded env17760 := by
  intro p hp
  have h : env17760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17759_17760 : H12AffineEnvironment.transform 10 543 env17759 = env17760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env17759 == env17760) = true)

def leafEnv17760 : List Nat := [2,4,8,16,1,16,9,4,512,20,543,16,8,1,1,3,17,543,21,0,1,1,17,3,21,9,1,17,542,16,17,542,20,1,5,0,5,2,1,512,1,1,0]

def active17760 : List Nat := [0,1,2,3,8]

def tree17760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17760 : H12WitnessSearch.Good tree17760 := H12GlobalWitnessIndex.good

theorem leafIdentity17760 : H12AffineFastState.composeSystem env17760 rootObs = leafEnv17760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17760 rootObs == leafEnv17760) = true)

theorem terminalChecked17760 : H12PackedTerminal.terminalCheckFast leafEnv17760 active17760 tree17760 = true := by decide +kernel

def env17761 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,0,1,3,16,2048,20,0,1,1,17,3,9,17,2049,17,17,2049,21,1,5,0,0,512]

theorem envBound17761 : H12AffineFastState.Bounded env17761 := by
  intro p hp
  have h : env17761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17758_17761 : H12AffineEnvironment.transform 9 21 env17758 = env17761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17758 == env17761) = true)

theorem identity17761 : scanCanonicalize (H12AffineFastState.compose env17761 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound17761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17762 : List Nat := [2,4,8,16,1,16,9,4,512,21,20,16,8,0,1,3,16,20,20,0,1,1,17,3,9,17,21,17,17,21,21,1,5,0,0,512]

theorem envBound17762 : H12AffineFastState.Bounded env17762 := by
  intro p hp
  have h : env17762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17761_17762 : H12AffineEnvironment.transform 10 20 env17761 = env17762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env17761 == env17762) = true)

def leafEnv17762 : List Nat := [2,4,8,16,1,16,9,4,512,21,20,16,8,0,1,3,16,20,20,0,1,1,17,3,20,9,1,17,21,17,17,21,21,1,5,0,5,2,0,512,1,1,0]

def active17762 : List Nat := [0,1,2,3,8]

def tree17762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17762 : H12WitnessSearch.Good tree17762 := H12GlobalWitnessIndex.good

theorem leafIdentity17762 : H12AffineFastState.composeSystem env17762 rootObs = leafEnv17762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17762 rootObs == leafEnv17762) = true)

theorem terminalChecked17762 : H12PackedTerminal.terminalCheckFast leafEnv17762 active17762 tree17762 = true := by decide +kernel

def env17763 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,1,3,1028,2048,1025,0,0,1,17,3,9,17,2049,1029,16,2049,1024,1,5,0,1044,512]

theorem envBound17763 : H12AffineFastState.Bounded env17763 := by
  intro p hp
  have h : env17763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17757_17763 : H12AffineEnvironment.transform 11 17 env17757 = env17763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17757 == env17763) = true)

theorem identity17763 : scanCanonicalize (H12AffineFastState.compose env17763 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound17763 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17764 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,1,3,17,2048,20,0,0,1,17,3,9,17,2049,16,16,2049,21,1,5,0,1,512]

theorem envBound17764 : H12AffineFastState.Bounded env17764 := by
  intro p hp
  have h : env17764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17763_17764 : H12AffineEnvironment.transform 9 21 env17763 = env17764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17763 == env17764) = true)

theorem identity17764 : scanCanonicalize (H12AffineFastState.compose env17764 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound17764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17765 : List Nat := [2,4,8,16,1,16,9,4,512,21,21,17,8,1,1,3,17,21,20,0,0,1,17,3,9,17,20,16,16,20,21,1,5,0,1,512]

theorem envBound17765 : H12AffineFastState.Bounded env17765 := by
  intro p hp
  have h : env17765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17764_17765 : H12AffineEnvironment.transform 10 21 env17764 = env17765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env17764 == env17765) = true)

def leafEnv17765 : List Nat := [2,4,8,16,1,16,9,4,512,21,21,17,8,1,1,3,17,21,20,0,0,1,17,3,20,9,1,17,20,16,16,20,21,1,5,0,5,2,1,512,1,0,0]

def active17765 : List Nat := [0,1,2,3,8]

def tree17765 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17765 : H12WitnessSearch.Good tree17765 := H12GlobalWitnessIndex.good

theorem leafIdentity17765 : H12AffineFastState.composeSystem env17765 rootObs = leafEnv17765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17765 rootObs == leafEnv17765) = true)

theorem terminalChecked17765 : H12PackedTerminal.terminalCheckFast leafEnv17765 active17765 tree17765 = true := by decide +kernel

def env17766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431073,8328,65,2609403,302316,333859,2329970,119042,2373705,257,2199998,2191387,63188]

theorem envBound17766 : H12AffineFastState.Bounded env17766 := by
  intro p hp
  have h : env17766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17708_17766 : H12AffineEnvironment.transform 23 2431073 env17708 = env17766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env17708 == env17766) = true)

def env17767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329761,8328,65,508091,302316,333859,236850,119042,272393,257,98814,90203,63188]

theorem envBound17767 : H12AffineFastState.Bounded env17767 := by
  intro p hp
  have h : env17767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17766_17767 : H12AffineEnvironment.transform 20 4160 env17766 = env17767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17766 == env17767) = true)

theorem identity17767 : scanCanonicalize (H12AffineFastState.compose env17767 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109047) := by decide +kernel

theorem selectedBound17767 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109047,1025,32769,4160,21929,62660,41430,8328,65,158028,79131,45524,236850,119042,98814,257,98814,90203,63188]

theorem envBound17768 : H12AffineFastState.Bounded env17768 := by
  intro p hp
  have h : env17768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17767_17768 : H12AffineEnvironment.transform 17 109047 env17767 = env17768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109047 env17767 == env17768) = true)

theorem identity17768 : scanCanonicalize (H12AffineFastState.compose env17768 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17768 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89378,1025,29908,4160,21929,17,21763,8328,65,158028,79131,17665,223719,75223,95531,257,95531,90203,513]

theorem envBound17769 : H12AffineFastState.Bounded env17769 := by
  intro p hp
  have h : env17769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17768_17769 : H12AffineEnvironment.transform 14 29909 env17768 = env17769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17768 == env17769) = true)

theorem identity17769 : scanCanonicalize (H12AffineFastState.compose env17769 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17769 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env17770 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29909,65536,131072,89174,1025,29908,4160,21725,17,21623,8328,65,157752,78959,17525,223379,74915,95327,117,95327,90203,513]

theorem envBound17770 : H12AffineFastState.Bounded env17770 := by
  intro p hp
  have h : env17770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17769_17770 : H12AffineEnvironment.transform 7 116 env17769 = env17770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17769 == env17770) = true)

theorem identity17770 : scanCanonicalize (H12AffineFastState.compose env17770 (packedSelected [0,1,5,6,8,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound17770 : packedSelected [0,1,5,6,8,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17771 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29909,65536,16537,89174,1025,29908,4160,21725,17,21623,8328,65,10401,78959,17525,75786,74915,95327,117,95327,90203,513]

theorem envBound17771 : H12AffineFastState.Bounded env17771 := by
  intro p hp
  have h : env17771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17770_17771 : H12AffineEnvironment.transform 16 16537 env17770 = env17771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env17770 == env17771) = true)

theorem identity17771 : scanCanonicalize (H12AffineFastState.compose env17771 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17771 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env17772 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13405,136,65536,13508,75787,1025,137,4160,8320,17,8234,8328,65,10401,78959,12328,75786,74915,65538,117,65538,70662,513]

theorem envBound17772 : H12AffineFastState.Bounded env17772 := by
  intro p hp
  have h : env17772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17771_17772 : H12AffineEnvironment.transform 13 13405 env17771 = env17772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17771 == env17772) = true)

theorem identity17772 : scanCanonicalize (H12AffineFastState.compose env17772 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17772 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env17773 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,40,5237,136,65536,5356,67619,1025,137,4160,168,17,2,160,65,2185,70727,4096,67618,66699,65538,117,65538,70662,513]

theorem envBound17773 : H12AffineFastState.Bounded env17773 := by
  intro p hp
  have h : env17773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17772_17773 : H12AffineEnvironment.transform 12 40 env17772 = env17773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17772 == env17773) = true)

theorem identity17773 : scanCanonicalize (H12AffineFastState.compose env17773 (packedSelected [0,1,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 3095) := by decide +kernel

theorem selectedBound17773 : packedSelected [0,1,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env17774 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,40,5237,136,3095,5356,1076,1025,137,4160,168,17,2,160,65,2185,6224,4096,1077,2204,3093,117,3093,6161,513]

theorem envBound17774 : H12AffineFastState.Bounded env17774 := by
  intro p hp
  have h : env17774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17773_17774 : H12AffineEnvironment.transform 15 3095 env17773 = env17774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3095 env17773 == env17774) = true)

theorem identity17774 : scanCanonicalize (H12AffineFastState.compose env17774 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17774 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17775 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,0,3095,5220,1076,1025,1,4160,32,17,2,40,65,2049,6224,4096,1077,2068,3093,117,3093,6161,513]

theorem envBound17775 : H12AffineFastState.Bounded env17775 := by
  intro p hp
  have h : env17775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17774_17775 : H12AffineEnvironment.transform 6 8 env17774 = env17775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17774 == env17775) = true)

theorem identity17775 : scanCanonicalize (H12AffineFastState.compose env17775 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound17775 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17776 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,40,4113,0,2163,4096,80,101,1,4160,32,17,2,40,65,2049,6224,4096,81,2068,2161,117,2161,6161,513]

theorem envBound17776 : H12AffineFastState.Bounded env17776 := by
  intro p hp
  have h : env17776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17775_17776 : H12AffineEnvironment.transform 9 100 env17775 = env17776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env17775 == env17776) = true)

def env17777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329760,8328,65,508090,302316,333859,236851,119042,272392,257,98815,90202,63188]

theorem envBound17777 : H12AffineFastState.Bounded env17777 := by
  intro p hp
  have h : env17777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17766_17777 : H12AffineEnvironment.transform 20 4161 env17766 = env17777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17766 == env17777) = true)

theorem identity17777 : scanCanonicalize (H12AffineFastState.compose env17777 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound17777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,21928,297452,318718,8328,65,398436,302316,314621,149997,1500,272392,257,21793,46212,63188]

theorem envBound17778 : H12AffineFastState.Bounded env17778 := by
  intro p hp
  have h : env17778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17777_17778 : H12AffineEnvironment.transform 15 54494 env17777 = env17778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env17777 == env17778) = true)

def env17779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4161,21928,41412,62678,8328,65,146508,46276,58581,149997,1500,32,257,21793,46212,63188]

theorem envBound17779 : H12AffineFastState.Bounded env17779 := by
  intro p hp
  have h : env17779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17778_17779 : H12AffineEnvironment.transform 17 10280 env17778 = env17779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17778 == env17779) = true)

theorem identity17779 : scanCanonicalize (H12AffineFastState.compose env17779 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17779 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,131072,10280,1025,32769,4161,168,41412,41430,8328,65,146508,46276,45525,138477,1500,32,257,33,46212,41940]

theorem envBound17780 : H12AffineFastState.Bounded env17780 := by
  intro p hp
  have h : env17780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17779_17780 : H12AffineEnvironment.transform 13 5376 env17779 = env17780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17779 == env17780) = true)

theorem identity17780 : scanCanonicalize (H12AffineFastState.compose env17780 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound17780 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env17781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,131072,10280,1025,8660,4161,168,17,3,8328,65,146508,5393,4096,138477,1500,32,257,33,5457,513]

theorem envBound17781 : H12AffineFastState.Bounded env17781 := by
  intro p hp
  have h : env17781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17780_17781 : H12AffineEnvironment.transform 14 8661 env17780 = env17781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env17780 == env17781) = true)

theorem identity17781 : scanCanonicalize (H12AffineFastState.compose env17781 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13745) := by decide +kernel

theorem selectedBound17781 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13745,10280,1025,8660,4161,168,17,3,8328,65,2557,5393,4096,10588,1500,32,257,33,5457,513]

theorem envBound17782 : H12AffineFastState.Bounded env17782 := by
  intro p hp
  have h : env17782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17781_17782 : H12AffineEnvironment.transform 16 13745 env17781 = env17782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env17781 == env17782) = true)

def env17783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4161,21928,41413,62679,8328,65,146509,46277,58580,149997,1500,33,257,21793,46212,63188]

theorem envBound17783 : H12AffineFastState.Bounded env17783 := by
  intro p hp
  have h : env17783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17778_17783 : H12AffineEnvironment.transform 17 10281 env17778 = env17783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17778 == env17783) = true)

theorem identity17783 : scanCanonicalize (H12AffineFastState.compose env17783 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17783 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8323,131072,10281,1025,29788,4161,21928,21912,138,8328,65,146509,16536,4233,149997,1500,33,257,21793,16601,649]

theorem envBound17784 : H12AffineFastState.Bounded env17784 := by
  intro p hp
  have h : env17784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17783_17784 : H12AffineEnvironment.transform 14 29789 env17783 = env17784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17783 == env17784) = true)

theorem identity17784 : scanCanonicalize (H12AffineFastState.compose env17784 (packedSelected [0,1,2,6,7,8,9,10,15,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound17784 : packedSelected [0,1,2,6,7,8,9,10,15,18,22] rootPS < 2^1333 := by decide +kernel

def env17785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8323,13508,10281,1025,29788,4161,21928,21912,138,8328,65,2185,16536,4233,32041,1500,33,257,21793,16601,649]

theorem envBound17785 : H12AffineFastState.Bounded env17785 := by
  intro p hp
  have h : env17785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17784_17785 : H12AffineEnvironment.transform 16 13508 env17784 = env17785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env17784 == env17785) = true)

theorem identity17785 : scanCanonicalize (H12AffineFastState.compose env17785 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17785 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env17786 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8323,13460,10281,1025,29708,4113,21928,21912,138,8328,17,2185,16536,4233,32041,1420,33,257,21793,16521,649]

theorem envBound17786 : H12AffineFastState.Bounded env17786 := by
  intro p hp
  have h : env17786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17785_17786 : H12AffineEnvironment.transform 5 16 env17785 = env17786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17785 == env17786) = true)

theorem identity17786 : scanCanonicalize (H12AffineFastState.compose env17786 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound17786 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17787 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,136,8323,13460,10281,1025,137,4113,8493,8477,138,8328,17,2185,13341,4233,2476,1420,33,257,8612,13324,649]

theorem envBound17787 : H12AffineFastState.Bounded env17787 := by
  intro p hp
  have h : env17787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17786_17787 : H12AffineEnvironment.transform 13 13445 env17786 = env17787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env17786 == env17787) = true)

theorem identity17787 : scanCanonicalize (H12AffineFastState.compose env17787 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17787 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17788 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,136,399,5528,2341,1025,137,4113,33,17,138,388,17,2185,5393,4233,2476,1420,33,257,168,5376,649]

theorem envBound17788 : H12AffineFastState.Bounded env17788 := by
  intro p hp
  have h : env17788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17787_17788 : H12AffineEnvironment.transform 12 268 env17787 = env17788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17787 == env17788) = true)

theorem identity17788 : scanCanonicalize (H12AffineFastState.compose env17788 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17788 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env17789 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,41,5292,136,170,5309,2048,1025,137,4113,33,17,138,161,17,2185,5172,4233,2185,1193,33,36,168,5157,649]

theorem envBound17789 : H12AffineFastState.Bounded env17789 := by
  intro p hp
  have h : env17789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17788_17789 : H12AffineEnvironment.transform 7 37 env17788 = env17789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17788 == env17789) = true)

theorem identity17789 : scanCanonicalize (H12AffineFastState.compose env17789 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17789 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env17790 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1025,1,4113,33,17,2,41,17,2049,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound17790 : H12AffineFastState.Bounded env17790 := by
  intro p hp
  have h : env17790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17789_17790 : H12AffineEnvironment.transform 6 8 env17789 = env17790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17789 == env17790) = true)

theorem identity17790 : scanCanonicalize (H12AffineFastState.compose env17790 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17791 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,0,34,4096,2048,52,1,4113,33,17,2,41,17,2049,4097,4097,2049,20,33,36,32,4112,513]

theorem envBound17791 : H12AffineFastState.Bounded env17791 := by
  intro p hp
  have h : env17791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17790_17791 : H12AffineEnvironment.transform 9 53 env17790 = env17791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17790 == env17791) = true)

theorem identity17791 : scanCanonicalize (H12AffineFastState.compose env17791 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound17791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17792 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,4096,41,4113,0,34,4096,2048,52,1,4113,33,17,2,41,17,2049,4097,4097,2049,20,33,36,32,4112,48]

theorem envBound17792 : H12AffineFastState.Bounded env17792 := by
  intro p hp
  have h : env17792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17791_17792 : H12AffineEnvironment.transform 8 49 env17791 = env17792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env17791 == env17792) = true)

theorem identity17792 : scanCanonicalize (H12AffineFastState.compose env17792 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound17792 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17793 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,33,41,48,0,34,33,2048,52,1,48,33,17,2,41,17,2049,32,32,2049,20,33,36,32,49,48]

theorem envBound17793 : H12AffineFastState.Bounded env17793 := by
  intro p hp
  have h : env17793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17792_17793 : H12AffineEnvironment.transform 11 33 env17792 = env17793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env17792 == env17793) = true)

theorem identity17793 : scanCanonicalize (H12AffineFastState.compose env17793 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound17793 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17794 : List Nat := [2,4,8,16,32,16,8,37,49,53,49,33,41,48,0,34,33,49,52,1,48,33,17,2,41,17,48,32,32,48,20,33,36,32,49,48]

theorem envBound17794 : H12AffineFastState.Bounded env17794 := by
  intro p hp
  have h : env17794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17793_17794 : H12AffineEnvironment.transform 10 49 env17793 = env17794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env17793 == env17794) = true)

def env17795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound17795 : H12AffineFastState.Bounded env17795 := by
  intro p hp
  have h : env17795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14984_17795 : H12AffineEnvironment.transform 31 145662401 env14984 = env17795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env14984 == env17795) = true)

def env17796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound17796 : H12AffineFastState.Bounded env17796 := by
  intro p hp
  have h : env17796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17795_17796 : H12AffineEnvironment.transform 29 155254784 env17795 = env17796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env17795 == env17796) = true)

def env17797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound17797 : H12AffineFastState.Bounded env17797 := by
  intro p hp
  have h : env17797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17796_17797 : H12AffineEnvironment.transform 25 64 env17796 = env17797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env17796 == env17797) = true)

def env17798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound17798 : H12AffineFastState.Bounded env17798 := by
  intro p hp
  have h : env17798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17797_17798 : H12AffineEnvironment.transform 26 30393344 env17797 = env17798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env17797 == env17798) = true)

def env17799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound17799 : H12AffineFastState.Bounded env17799 := by
  intro p hp
  have h : env17799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17798_17799 : H12AffineEnvironment.transform 18 1024 env17798 = env17799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17798 == env17799) = true)

theorem identity17799 : scanCanonicalize (H12AffineFastState.compose env17799 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound17799 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,16777216,8328,64,29868032,16835015,8466458,8830976,25265169,20971658,256,25207270,25182274,25207751]

theorem envBound17800 : H12AffineFastState.Bounded env17800 := by
  intro p hp
  have h : env17800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17799_17800 : H12AffineEnvironment.transform 20 91467 env17799 = env17800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env17799 == env17800) = true)

def env17801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120028,8328,64,12981468,79131,8466458,8830976,8409293,4314198,256,8484154,8492190,8484635]

theorem envBound17801 : H12AffineFastState.Bounded env17801 := by
  intro p hp
  have h : env17801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17800_17801 : H12AffineEnvironment.transform 23 120028 env17800 = env17801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120028 env17800 == env17801) = true)

def env17802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981468,79131,8466458,8820104,8389957,4293086,256,8462514,8492190,8462995]

theorem envBound17802 : H12AffineFastState.Bounded env17802 := by
  intro p hp
  have h : env17802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17801_17802 : H12AffineEnvironment.transform 13 5512 env17801 = env17802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env17801 == env17802) = true)

def env17803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787196,79131,8466458,8820104,8389957,98814,256,8462514,8492190,8462995]

theorem envBound17803 : H12AffineFastState.Bounded env17803 := by
  intro p hp
  have h : env17803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17802_17803 : H12AffineEnvironment.transform 21 32 env17802 = env17803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17802 == env17803) = true)

theorem identity17803 : scanCanonicalize (H12AffineFastState.compose env17803 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound17803 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,98766,98644,8328,64,496946,79131,45524,463942,99467,98814,256,41340,5456,41821]

theorem envBound17804 : H12AffineFastState.Bounded env17804 := by
  intro p hp
  have h : env17804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17803_17804 : H12AffineEnvironment.transform 22 98766 env17803 = env17804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env17803 == env17804) = true)

theorem identity17804 : scanCanonicalize (H12AffineFastState.compose env17804 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17804 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,262144,1024,8541,78019,32,73874,73736,8328,64,472174,79131,4232,463942,75223,73890,256,32,5456,513]

theorem envBound17805 : H12AffineFastState.Bounded env17805 := by
  intro p hp
  have h : env17805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17804_17805 : H12AffineEnvironment.transform 14 8540 env17804 = env17805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17804 == env17805) = true)

def env17806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10400,1024,8541,78019,32,73874,73736,8328,64,203982,79131,4232,212198,75223,73890,256,32,5456,513]

theorem envBound17806 : H12AffineFastState.Bounded env17806 := by
  intro p hp
  have h : env17806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17805_17806 : H12AffineEnvironment.transform 17 10400 env17805 = env17806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17805 == env17806) = true)

theorem identity17806 : scanCanonicalize (H12AffineFastState.compose env17806 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound17806 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env17807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,79130,10400,1024,8541,78019,32,73874,73736,8328,64,10708,79131,4232,2556,75223,73890,256,32,5456,513]

theorem envBound17807 : H12AffineFastState.Bounded env17807 := by
  intro p hp
  have h : env17807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17806_17807 : H12AffineEnvironment.transform 16 79130 env17806 = env17807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env17806 == env17807) = true)

theorem identity17807 : scanCanonicalize (H12AffineFastState.compose env17807 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17807 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env17808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,5393,10400,1024,8541,4296,32,153,3,8328,64,10708,5392,4232,2556,1500,169,256,32,5456,513]

theorem envBound17808 : H12AffineFastState.Bounded env17808 := by
  intro p hp
  have h : env17808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17807_17808 : H12AffineEnvironment.transform 15 8203 env17807 = env17808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17807 == env17808) = true)

theorem identity17808 : scanCanonicalize (H12AffineFastState.compose env17808 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17808 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10281,1024,8541,4161,32,16,3,8193,64,10589,5392,4097,2421,1365,32,256,32,5456,513]

theorem envBound17809 : H12AffineFastState.Bounded env17809 := by
  intro p hp
  have h : env17809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17808_17809 : H12AffineEnvironment.transform 6 9 env17808 = env17809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17808 == env17809) = true)

theorem identity17809 : scanCanonicalize (H12AffineFastState.compose env17809 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17809 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17810 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,5393,10281,1024,8460,4112,32,16,3,8193,17,10508,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound17810 : H12AffineFastState.Bounded env17810 := by
  intro p hp
  have h : env17810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17809_17810 : H12AffineEnvironment.transform 5 17 env17809 = env17810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17809 == env17810) = true)

theorem identity17810 : scanCanonicalize (H12AffineFastState.compose env17810 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound17810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17811 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5377,1044,1298,5393,3376,1024,1045,4112,32,16,3,1304,17,3093,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound17811 : H12AffineFastState.Bounded env17811 := by
  intro p hp
  have h : env17811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17810_17811 : H12AffineEnvironment.transform 12 1305 env17810 = env17811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env17810 == env17811) = true)

theorem identity17811 : scanCanonicalize (H12AffineFastState.compose env17811 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17811 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17812 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4405,32,294,4389,2308,52,33,4112,32,16,3,300,17,2081,4388,4097,2340,304,32,256,32,4405,513]

theorem envBound17812 : H12AffineFastState.Bounded env17812 := by
  intro p hp
  have h : env17812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17811_17812 : H12AffineEnvironment.transform 9 52 env17811 = env17812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17811 == env17812) = true)

theorem identity17812 : scanCanonicalize (H12AffineFastState.compose env17812 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound17812 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17813 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2325,301,2080,32,294,2096,2308,52,33,2309,32,16,3,300,17,2081,2097,2324,2340,304,32,256,32,2080,513]

theorem envBound17813 : H12AffineFastState.Bounded env17813 := by
  intro p hp
  have h : env17813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17812_17813 : H12AffineEnvironment.transform 11 2325 env17812 = env17813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env17812 == env17813) = true)

theorem identity17813 : scanCanonicalize (H12AffineFastState.compose env17813 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound17813 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env17814 : List Nat := [2,4,8,16,32,17,9,256,308,52,2048,2325,301,2080,32,294,2096,2308,52,33,2309,32,16,3,300,17,2081,2097,2324,2340,304,32,256,32,2080,309]

theorem envBound17814 : H12AffineFastState.Bounded env17814 := by
  intro p hp
  have h : env17814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17813_17814 : H12AffineEnvironment.transform 8 308 env17813 = env17814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env17813 == env17814) = true)

theorem identity17814 : scanCanonicalize (H12AffineFastState.compose env17814 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17814 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env17815 : List Nat := [2,4,8,16,32,17,9,37,17,52,2048,2096,8,2080,32,3,2096,2081,52,33,2080,32,16,3,9,17,2081,2097,2097,2049,21,32,37,32,2080,16]

theorem envBound17815 : H12AffineFastState.Bounded env17815 := by
  intro p hp
  have h : env17815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17814_17815 : H12AffineEnvironment.transform 7 37 env17814 = env17815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17814 == env17815) = true)

theorem identity17815 : scanCanonicalize (H12AffineFastState.compose env17815 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17816 : List Nat := [2,4,8,0,32,1,9,37,1,36,2048,2080,8,2080,32,3,2080,2081,36,33,2080,32,0,3,9,1,2081,2081,2081,2049,5,32,37,32,2080,0]

theorem envBound17816 : H12AffineFastState.Bounded env17816 := by
  intro p hp
  have h : env17816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17815_17816 : H12AffineEnvironment.transform 3 0 env17815 = env17816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17815 == env17816) = true)

theorem identity17816 : scanCanonicalize (H12AffineFastState.compose env17816 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound17816 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17817 : List Nat := [2,4,8,0,32,1,9,37,1,36,33,1,8,1,32,3,1,0,36,33,1,32,0,3,9,1,0,0,0,32,5,32,37,32,1,0]

theorem envBound17817 : H12AffineFastState.Bounded env17817 := by
  intro p hp
  have h : env17817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17816_17817 : H12AffineEnvironment.transform 10 33 env17816 = env17817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17816 == env17817) = true)

theorem identity17817 : scanCanonicalize (H12AffineFastState.compose env17817 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17817 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17818 : List Nat := [2,4,8,0,0,1,9,5,1,4,1,1,8,1,0,3,1,0,4,1,1,0,0,3,9,1,0,0,0,0,5,0,5,0,1,0]

theorem envBound17818 : H12AffineFastState.Bounded env17818 := by
  intro p hp
  have h : env17818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17817_17818 : H12AffineEnvironment.transform 4 0 env17817 = env17818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17817 == env17818) = true)

def env17819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,78019,32,73874,73736,8328,64,203983,79131,4232,212199,75223,73890,256,32,5456,513]

theorem envBound17819 : H12AffineFastState.Bounded env17819 := by
  intro p hp
  have h : env17819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17805_17819 : H12AffineEnvironment.transform 17 10401 env17805 = env17819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17805 == env17819) = true)

theorem identity17819 : scanCanonicalize (H12AffineFastState.compose env17819 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound17819 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env17820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,79251,10401,1024,8541,78019,32,73874,73736,8328,64,10588,79131,4232,2420,75223,73890,256,32,5456,513]

theorem envBound17820 : H12AffineFastState.Bounded env17820 := by
  intro p hp
  have h : env17820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17819_17820 : H12AffineEnvironment.transform 16 79251 env17819 = env17820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env17819 == env17820) = true)

theorem identity17820 : scanCanonicalize (H12AffineFastState.compose env17820 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound17820 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8540,65536,75923,10401,1024,8541,77251,32,73874,73736,8328,64,10588,75803,3464,2420,75223,73890,256,32,2128,513]

theorem envBound17821 : H12AffineFastState.Bounded env17821 := by
  intro p hp
  have h : env17821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17820_17821 : H12AffineEnvironment.transform 11 3328 env17820 = env17821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env17820 == env17821) = true)

theorem identity17821 : scanCanonicalize (H12AffineFastState.compose env17821 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17821 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8540,8322,2065,10401,1024,8541,3393,32,16,138,8328,64,10588,2201,3464,2420,1365,32,256,32,2128,513]

theorem envBound17822 : H12AffineFastState.Bounded env17822 := by
  intro p hp
  have h : env17822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17821_17822 : H12AffineEnvironment.transform 15 8322 env17821 = env17822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17821 == env17822) = true)

theorem identity17822 : scanCanonicalize (H12AffineFastState.compose env17822 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17822 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,8192,137,8540,8322,16,8352,1024,8541,1344,32,16,138,8328,64,8541,152,1417,373,1365,32,256,32,81,513]

theorem envBound17823 : H12AffineFastState.Bounded env17823 := by
  intro p hp
  have h : env17823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17822_17823 : H12AffineEnvironment.transform 10 1 env17822 = env17823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17822 == env17823) = true)

theorem identity17823 : scanCanonicalize (H12AffineFastState.compose env17823 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound17823 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env17824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,1337,137,1125,1467,16,1433,1024,1124,1344,32,16,138,1457,64,1124,152,1417,373,1365,32,256,32,81,513]

theorem envBound17824 : H12AffineFastState.Bounded env17824 := by
  intro p hp
  have h : env17824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17823_17824 : H12AffineEnvironment.transform 12 1337 env17823 = env17824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env17823 == env17824) = true)

theorem identity17824 : scanCanonicalize (H12AffineFastState.compose env17824 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17824 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env17825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1281,1337,0,1125,1330,16,1296,1024,1124,1344,32,16,3,1336,64,1124,17,1280,373,1365,32,256,32,81,513]

theorem envBound17825 : H12AffineFastState.Bounded env17825 := by
  intro p hp
  have h : env17825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17824_17825 : H12AffineEnvironment.transform 6 9 env17824 = env17825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17824 == env17825) = true)

theorem identity17825 : scanCanonicalize (H12AffineFastState.compose env17825 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17825 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17826 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1,1060,1052,0,1125,1047,16,1077,1024,1124,1125,32,16,3,1053,64,1124,17,1061,80,1136,32,37,32,81,513]

theorem envBound17826 : H12AffineFastState.Bounded env17826 := by
  intro p hp
  have h : env17826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17825_17826 : H12AffineEnvironment.transform 7 37 env17825 = env17826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17825 == env17826) = true)

theorem identity17826 : scanCanonicalize (H12AffineFastState.compose env17826 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17826 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env17827 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,16,40,0,81,35,16,1,52,80,81,32,16,3,41,64,80,17,17,80,68,32,37,32,81,513]

theorem envBound17827 : H12AffineFastState.Bounded env17827 := by
  intro p hp
  have h : env17827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17826_17827 : H12AffineEnvironment.transform 9 52 env17826 = env17827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17826 == env17827) = true)

theorem identity17827 : scanCanonicalize (H12AffineFastState.compose env17827 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17828 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,16,40,0,1,35,16,1,52,0,1,32,16,3,41,16,0,17,17,0,20,32,37,32,1,513]

theorem envBound17828 : H12AffineFastState.Bounded env17828 := by
  intro p hp
  have h : env17828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17827_17828 : H12AffineEnvironment.transform 5 16 env17827 = env17828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17827 == env17828) = true)

theorem identity17828 : scanCanonicalize (H12AffineFastState.compose env17828 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17829 : List Nat := [2,4,8,16,0,16,9,5,512,20,1,16,8,0,1,3,16,1,20,0,1,0,16,3,9,16,0,17,17,0,20,0,5,0,1,513]

theorem envBound17829 : H12AffineFastState.Bounded env17829 := by
  intro p hp
  have h : env17829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17828_17829 : H12AffineEnvironment.transform 4 0 env17828 = env17829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17828 == env17829) = true)

theorem identity17829 : scanCanonicalize (H12AffineFastState.compose env17829 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17829 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17830 : List Nat := [2,4,8,1,0,1,9,5,512,5,1,1,8,0,1,3,1,1,5,0,1,0,1,3,9,1,0,0,0,0,5,0,5,0,1,513]

theorem envBound17830 : H12AffineFastState.Bounded env17830 := by
  intro p hp
  have h : env17830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17829_17830 : H12AffineEnvironment.transform 3 1 env17829 = env17830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17829 == env17830) = true)

def env17831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787197,79131,8466458,8820104,8389957,98815,256,8462514,8492190,8462995]

theorem envBound17831 : H12AffineFastState.Bounded env17831 := by
  intro p hp
  have h : env17831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17802_17831 : H12AffineEnvironment.transform 21 33 env17802 = env17831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env17802 == env17831) = true)

theorem identity17831 : scanCanonicalize (H12AffineFastState.compose env17831 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound17831 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,262144,1024,32769,45341,33,8388608,138,8328,64,8787197,46277,8434116,8820104,8389957,33,256,8429932,8394048,8430413]

theorem envBound17832 : H12AffineFastState.Bounded env17832 := by
  intro p hp
  have h : env17832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17831_17832 : H12AffineEnvironment.transform 15 33246 env17831 = env17832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env17831 == env17832) = true)

theorem identity17832 : scanCanonicalize (H12AffineFastState.compose env17832 (packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound17832 : packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,10400,1024,32769,45341,33,8388608,138,8328,64,8535133,46277,8434116,8568104,8389957,33,256,8429932,8394048,8430413]

theorem envBound17833 : H12AffineFastState.Bounded env17833 := by
  intro p hp
  have h : env17833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17832_17833 : H12AffineEnvironment.transform 17 10400 env17832 = env17833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17832 == env17833) = true)

def env17834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,10280,1024,32769,45341,33,8388608,2,8192,64,8535133,46157,8433996,8568104,8389957,33,256,8429932,8394048,8430413]

theorem envBound17834 : H12AffineFastState.Bounded env17834 := by
  intro p hp
  have h : env17834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17833_17834 : H12AffineEnvironment.transform 6 8 env17833 = env17834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17833 == env17834) = true)

theorem identity17834 : scanCanonicalize (H12AffineFastState.compose env17834 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound17834 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env17835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,13340,10280,1024,32769,45341,33,8388608,2,8192,64,8390721,46157,8433996,8423732,8389957,33,256,8429932,8394048,8430413]

theorem envBound17835 : H12AffineFastState.Bounded env17835 := by
  intro p hp
  have h : env17835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17834_17835 : H12AffineEnvironment.transform 16 13340 env17834 = env17835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env17834 == env17835) = true)

theorem identity17835 : scanCanonicalize (H12AffineFastState.compose env17835 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound17835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,13340,10280,1024,32769,45341,33,41292,2,8192,64,43277,46157,4096,10360,41993,33,256,32,46092,513]

theorem envBound17836 : H12AffineFastState.Bounded env17836 := by
  intro p hp
  have h : env17836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17835_17836 : H12AffineEnvironment.transform 22 41292 env17835 = env17836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env17835 == env17836) = true)

theorem identity17836 : scanCanonicalize (H12AffineFastState.compose env17836 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17836 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13340,10280,1024,8540,4160,33,17,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5457,513]

theorem envBound17837 : H12AffineFastState.Bounded env17837 := by
  intro p hp
  have h : env17837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17836_17837 : H12AffineEnvironment.transform 14 8541 env17836 = env17837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17836 == env17837) = true)

theorem identity17837 : scanCanonicalize (H12AffineFastState.compose env17837 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17837 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,262,5393,2341,1024,81,4160,33,17,2,269,64,2128,5392,4096,2421,1364,33,256,32,5457,513]

theorem envBound17838 : H12AffineFastState.Bounded env17838 := by
  intro p hp
  have h : env17838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17837_17838 : H12AffineEnvironment.transform 12 269 env17837 = env17838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17837 == env17838) = true)

theorem identity17838 : scanCanonicalize (H12AffineFastState.compose env17838 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1867) := by decide +kernel

theorem selectedBound17838 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1867,4096,269,5376,80,262,5393,1646,1024,81,4160,33,17,2,269,64,1819,5392,4096,1598,1364,33,256,32,5457,513]

theorem envBound17839 : H12AffineFastState.Bounded env17839 := by
  intro p hp
  have h : env17839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17838_17839 : H12AffineEnvironment.transform 10 1867 env17838 = env17839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1867 env17838 == env17839) = true)

theorem identity17839 : scanCanonicalize (H12AffineFastState.compose env17839 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound17839 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17840 : List Nat := [2,4,8,16,32,64,8,256,512,321,522,4096,269,4161,80,262,4176,815,321,81,4160,33,17,2,269,64,602,4177,4096,895,21,33,256,32,4112,513]

theorem envBound17840 : H12AffineFastState.Bounded env17840 := by
  intro p hp
  have h : env17840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17839_17840 : H12AffineEnvironment.transform 9 321 env17839 = env17840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env17839 == env17840) = true)

theorem identity17840 : scanCanonicalize (H12AffineFastState.compose env17840 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17841 : List Nat := [2,4,8,16,32,64,8,36,512,101,522,4096,41,4161,80,34,4176,523,101,81,4160,33,17,2,41,64,602,4177,4096,603,21,33,36,32,4112,513]

theorem envBound17841 : H12AffineFastState.Bounded env17841 := by
  intro p hp
  have h : env17841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17840_17841 : H12AffineEnvironment.transform 7 36 env17840 = env17841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17840 == env17841) = true)

theorem identity17841 : scanCanonicalize (H12AffineFastState.compose env17841 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17841 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17842 : List Nat := [2,4,8,16,32,17,8,36,512,52,522,4096,41,4112,1,34,4097,523,52,0,4113,33,17,2,41,17,523,4096,4096,522,21,33,36,32,4112,513]

theorem envBound17842 : H12AffineFastState.Bounded env17842 := by
  intro p hp
  have h : env17842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17841_17842 : H12AffineEnvironment.transform 5 17 env17841 = env17842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17841 == env17842) = true)

theorem identity17842 : scanCanonicalize (H12AffineFastState.compose env17842 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 575) := by decide +kernel

theorem selectedBound17842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17843 : List Nat := [2,4,8,16,32,17,8,36,512,52,522,575,41,559,1,34,574,523,52,0,558,33,17,2,41,17,523,575,575,522,21,33,36,32,559,513]

theorem envBound17843 : H12AffineFastState.Bounded env17843 := by
  intro p hp
  have h : env17843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17842_17843 : H12AffineEnvironment.transform 11 575 env17842 = env17843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 575 env17842 == env17843) = true)

theorem identity17843 : scanCanonicalize (H12AffineFastState.compose env17843 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound17843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17844 : List Nat := [2,4,8,16,6,17,8,2,512,18,522,537,15,521,1,4,536,523,18,0,520,7,17,2,15,17,523,537,537,522,21,7,2,6,521,513]

theorem envBound17844 : H12AffineFastState.Bounded env17844 := by
  intro p hp
  have h : env17844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17843_17844 : H12AffineEnvironment.transform 4 6 env17843 = env17844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env17843 == env17844) = true)

theorem identity17844 : scanCanonicalize (H12AffineFastState.compose env17844 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound17844 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17845 : List Nat := [2,1,8,16,3,17,8,2,512,18,522,537,10,521,1,1,536,523,18,0,520,2,17,2,10,17,523,537,537,522,16,2,2,3,521,513]

theorem envBound17845 : H12AffineFastState.Bounded env17845 := by
  intro p hp
  have h : env17845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17844_17845 : H12AffineEnvironment.transform 1 1 env17844 = env17845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env17844 == env17845) = true)

def env17846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1024,32769,45341,33,8388608,3,8193,64,8535133,46156,8433997,8568104,8389957,33,256,8429932,8394048,8430413]

theorem envBound17846 : H12AffineFastState.Bounded env17846 := by
  intro p hp
  have h : env17846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17833_17846 : H12AffineEnvironment.transform 6 9 env17833 = env17846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17833 == env17846) = true)

theorem identity17846 : scanCanonicalize (H12AffineFastState.compose env17846 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(22+1) ^^^ 9308) := by decide +kernel

theorem selectedBound17846 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env17847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1024,32769,45341,33,9308,3,8193,64,137217,46156,38161,170356,8473,33,256,34096,12572,34577]

theorem envBound17847 : H12AffineFastState.Bounded env17847 := by
  intro p hp
  have h : env17847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17846_17847 : H12AffineEnvironment.transform 22 9308 env17846 = env17847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9308 env17846 == env17847) = true)

theorem identity17847 : scanCanonicalize (H12AffineFastState.compose env17847 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound17847 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,33111,131072,3173,1024,32769,38225,33,16,3,1101,64,137217,36864,38161,170356,1365,33,256,34096,5456,34577]

theorem envBound17848 : H12AffineFastState.Bounded env17848 := by
  intro p hp
  have h : env17848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17847_17848 : H12AffineEnvironment.transform 12 1100 env17847 = env17848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env17847 == env17848) = true)

theorem identity17848 : scanCanonicalize (H12AffineFastState.compose env17848 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 37988) := by decide +kernel

theorem selectedBound17848 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env17849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,33111,37988,3173,1024,32769,38225,33,16,3,1101,64,35941,36864,38161,3344,1365,33,256,34096,5456,34577]

theorem envBound17849 : H12AffineFastState.Bounded env17849 := by
  intro p hp
  have h : env17849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17848_17849 : H12AffineEnvironment.transform 16 37988 env17848 = env17849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37988 env17848 == env17849) = true)

theorem identity17849 : scanCanonicalize (H12AffineFastState.compose env17849 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17849 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,0,343,5220,3173,1024,1,5457,33,16,3,1101,64,3173,4096,5393,3344,1365,33,256,1328,5456,1809]

theorem envBound17850 : H12AffineFastState.Bounded env17850 := by
  intro p hp
  have h : env17850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17849_17850 : H12AffineEnvironment.transform 14 0 env17849 = env17850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17849 == env17850) = true)

theorem identity17850 : scanCanonicalize (H12AffineFastState.compose env17850 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17850 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env17851 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,1100,5157,0,115,5220,3173,1024,1,5237,33,16,3,1101,64,3173,4096,5173,3124,1137,33,36,1044,5236,1589]

theorem envBound17851 : H12AffineFastState.Bounded env17851 := by
  intro p hp
  have h : env17851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17850_17851 : H12AffineEnvironment.transform 7 36 env17850 = env17851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17850 == env17851) = true)

theorem identity17851 : scanCanonicalize (H12AffineFastState.compose env17851 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound17851 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env17852 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,40,4161,0,115,4096,2049,100,1,4113,33,16,3,41,64,2049,4096,4177,2128,21,33,36,112,4112,593]

theorem envBound17852 : H12AffineFastState.Bounded env17852 := by
  intro p hp
  have h : env17852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17851_17852 : H12AffineEnvironment.transform 9 100 env17851 = env17852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env17851 == env17852) = true)

theorem identity17852 : scanCanonicalize (H12AffineFastState.compose env17852 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound17852 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env17853 : List Nat := [2,4,8,16,32,64,9,36,512,100,64,4096,40,4161,0,115,4096,65,100,1,4113,33,16,3,41,64,65,4096,4177,16,21,33,36,112,4112,593]

theorem envBound17853 : H12AffineFastState.Bounded env17853 := by
  intro p hp
  have h : env17853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17852_17853 : H12AffineEnvironment.transform 10 64 env17852 = env17853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env17852 == env17853) = true)

theorem identity17853 : scanCanonicalize (H12AffineFastState.compose env17853 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound17853 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env17854 : List Nat := [2,4,8,16,32,64,9,36,512,100,64,48,40,113,0,115,48,65,100,1,33,33,16,3,41,64,65,48,97,16,21,33,36,112,32,593]

theorem envBound17854 : H12AffineFastState.Bounded env17854 := by
  intro p hp
  have h : env17854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17853_17854 : H12AffineEnvironment.transform 11 48 env17853 = env17854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env17853 == env17854) = true)

theorem identity17854 : scanCanonicalize (H12AffineFastState.compose env17854 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17854 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17855 : List Nat := [2,4,8,16,16,64,9,20,512,84,64,0,24,65,0,67,0,65,84,1,17,17,16,3,25,64,65,0,81,16,21,17,20,64,16,593]

theorem envBound17855 : H12AffineFastState.Bounded env17855 := by
  intro p hp
  have h : env17855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17854_17855 : H12AffineEnvironment.transform 4 16 env17854 = env17855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17854 == env17855) = true)

def env17856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981468,79131,8466458,8820105,8389956,4293087,256,8462515,8492190,8462994]

theorem envBound17856 : H12AffineFastState.Bounded env17856 := by
  intro p hp
  have h : env17856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17801_17856 : H12AffineEnvironment.transform 13 5513 env17801 = env17856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17801 == env17856) = true)

def env17857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787196,79131,8466458,8820105,8389956,98815,256,8462515,8492190,8462994]

theorem envBound17857 : H12AffineFastState.Bounded env17857 := by
  intro p hp
  have h : env17857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17856_17857 : H12AffineEnvironment.transform 21 32 env17856 = env17857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17856 == env17857) = true)

theorem identity17857 : scanCanonicalize (H12AffineFastState.compose env17857 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound17857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,73755,98645,8328,64,472295,79131,4097,505234,75103,98815,256,168,46213,649]

theorem envBound17858 : H12AffineFastState.Bounded env17858 := by
  intro p hp
  have h : env17858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17857_17858 : H12AffineEnvironment.transform 22 73755 env17857 = env17858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env17857 == env17858) = true)

def env17859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472175,79131,4097,505114,75103,98679,256,32,46093,513]

theorem envBound17859 : H12AffineFastState.Bounded env17859 := by
  intro p hp
  have h : env17859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17858_17859 : H12AffineEnvironment.transform 6 8 env17858 = env17859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17858 == env17859) = true)

theorem identity17859 : scanCanonicalize (H12AffineFastState.compose env17859 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17859 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,45341,32,41292,2,8192,64,439608,46156,4097,406605,41992,32,256,32,46093,513]

theorem envBound17860 : H12AffineFastState.Bounded env17860 := by
  intro p hp
  have h : env17860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17859_17860 : H12AffineEnvironment.transform 15 33111 env17859 = env17860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17859 == env17860) = true)

theorem identity17860 : scanCanonicalize (H12AffineFastState.compose env17860 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound17860 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env17861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,171060,1024,32769,45341,32,41292,2,8192,64,10508,46156,4097,43129,41992,32,256,32,46093,513]

theorem envBound17861 : H12AffineFastState.Bounded env17861 := by
  intro p hp
  have h : env17861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17860_17861 : H12AffineEnvironment.transform 17 171060 env17860 = env17861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env17860 == env17861) = true)

theorem identity17861 : scanCanonicalize (H12AffineFastState.compose env17861 (packedSelected [0,3,4,7,9,10,14,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound17861 : packedSelected [0,3,4,7,9,10,14,19,24] rootPS < 2^1333 := by decide +kernel

def env17862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38160,2340,1024,32769,45341,32,41292,2,8192,64,10508,46156,4097,43129,41992,32,256,32,46093,513]

theorem envBound17862 : H12AffineFastState.Bounded env17862 := by
  intro p hp
  have h : env17862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17861_17862 : H12AffineEnvironment.transform 16 38160 env17861 = env17862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env17861 == env17862) = true)

theorem identity17862 : scanCanonicalize (H12AffineFastState.compose env17862 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17862 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env17863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33111,38160,2340,1024,32769,36929,32,32784,2,348,64,2128,38160,4097,35109,34132,32,256,32,38225,513]

theorem envBound17863 : H12AffineFastState.Bounded env17863 := by
  intro p hp
  have h : env17863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17862_17863 : H12AffineEnvironment.transform 12 348 env17862 = env17863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17862 == env17863) = true)

theorem identity17863 : scanCanonicalize (H12AffineFastState.compose env17863 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17863 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5392,2340,1024,1,4161,32,16,2,348,64,2128,5392,4097,2341,1364,32,256,32,5457,513]

theorem envBound17864 : H12AffineFastState.Bounded env17864 := by
  intro p hp
  have h : env17864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17863_17864 : H12AffineEnvironment.transform 14 0 env17863 = env17864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17863 == env17864) = true)

theorem identity17864 : scanCanonicalize (H12AffineFastState.compose env17864 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound17864 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1076,348,309,0,343,292,2340,1024,1,1141,32,16,2,348,64,2128,292,1077,2341,1364,32,256,32,357,513]

theorem envBound17865 : H12AffineFastState.Bounded env17865 := by
  intro p hp
  have h : env17865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17864_17865 : H12AffineEnvironment.transform 11 1076 env17864 = env17865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env17864 == env17865) = true)

theorem identity17865 : scanCanonicalize (H12AffineFastState.compose env17865 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound17865 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env17866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,286,1076,348,309,0,343,292,58,1024,1,1141,32,16,2,348,64,334,292,1077,59,1364,32,256,32,357,513]

theorem envBound17866 : H12AffineFastState.Bounded env17866 := by
  intro p hp
  have h : env17866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17865_17866 : H12AffineEnvironment.transform 10 286 env17865 = env17866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env17865 == env17866) = true)

theorem identity17866 : scanCanonicalize (H12AffineFastState.compose env17866 (packedSelected [1,4,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 126) := by decide +kernel

theorem selectedBound17866 : packedSelected [1,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env17867 : List Nat := [2,4,8,16,32,64,8,126,512,1024,96,1076,34,75,0,41,90,58,1024,1,1141,32,16,2,34,64,48,90,1077,59,1066,32,126,32,27,513]

theorem envBound17867 : H12AffineFastState.Bounded env17867 := by
  intro p hp
  have h : env17867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17866_17867 : H12AffineEnvironment.transform 7 126 env17866 = env17867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 126 env17866 == env17867) = true)

theorem identity17867 : scanCanonicalize (H12AffineFastState.compose env17867 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17867 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env17868 : List Nat := [2,4,8,16,32,16,8,46,512,1024,48,1076,34,27,0,41,10,58,1024,1,1061,32,16,2,34,16,48,10,1077,59,1066,32,46,32,27,513]

theorem envBound17868 : H12AffineFastState.Bounded env17868 := by
  intro p hp
  have h : env17868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17867_17868 : H12AffineEnvironment.transform 5 16 env17867 = env17868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17867 == env17868) = true)

theorem identity17868 : scanCanonicalize (H12AffineFastState.compose env17868 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound17868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17869 : List Nat := [2,4,8,16,10,16,8,4,512,1024,26,1054,8,27,0,3,10,16,1024,1,1039,10,16,2,8,16,26,10,1055,17,1024,10,4,10,27,513]

theorem envBound17869 : H12AffineFastState.Bounded env17869 := by
  intro p hp
  have h : env17869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17868_17869 : H12AffineEnvironment.transform 4 10 env17868 = env17869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env17868 == env17869) = true)

def env17870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98645,8193,64,472174,79131,4097,505115,75103,98678,256,33,46092,512]

theorem envBound17870 : H12AffineFastState.Bounded env17870 := by
  intro p hp
  have h : env17870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17858_17870 : H12AffineEnvironment.transform 6 9 env17858 = env17870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17858 == env17870) = true)

theorem identity17870 : scanCanonicalize (H12AffineFastState.compose env17870 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17870 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,45341,32,41293,3,8193,64,439608,46157,4097,406605,41993,32,256,33,46092,512]

theorem envBound17871 : H12AffineFastState.Bounded env17871 := by
  intro p hp
  have h : env17871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17870_17871 : H12AffineEnvironment.transform 15 33110 env17870 = env17871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17870 == env17871) = true)

theorem identity17871 : scanCanonicalize (H12AffineFastState.compose env17871 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 46189) := by decide +kernel

theorem selectedBound17871 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46189,262144,1024,32769,45341,32,41293,3,8193,64,262485,46157,4097,294944,41993,32,256,33,46092,512]

theorem envBound17872 : H12AffineFastState.Bounded env17872 := by
  intro p hp
  have h : env17872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17871_17872 : H12AffineEnvironment.transform 16 46189 env17871 = env17872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46189 env17871 == env17872) = true)

theorem identity17872 : scanCanonicalize (H12AffineFastState.compose env17872 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17872 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env17873 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33031,46140,262144,1024,32769,45341,32,41244,3,8193,17,262404,46108,4097,294944,41993,32,256,33,46092,512]

theorem envBound17873 : H12AffineFastState.Bounded env17873 := by
  intro p hp
  have h : env17873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17872_17873 : H12AffineEnvironment.transform 5 17 env17872 = env17873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17872 == env17873) = true)

theorem identity17873 : scanCanonicalize (H12AffineFastState.compose env17873 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound17873 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env17874 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33031,46140,10280,1024,32769,45341,32,41244,3,8193,17,10540,46108,4097,43016,41993,32,256,33,46092,512]

theorem envBound17874 : H12AffineFastState.Bounded env17874 := by
  intro p hp
  have h : env17874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17873_17874 : H12AffineEnvironment.transform 17 10280 env17873 = env17874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17873 == env17874) = true)

theorem identity17874 : scanCanonicalize (H12AffineFastState.compose env17874 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17874 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17875 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,13372,10280,1024,1,12573,32,8476,3,8193,17,10540,13340,4097,10248,9225,32,256,33,13324,512]

theorem envBound17875 : H12AffineFastState.Bounded env17875 := by
  intro p hp
  have h : env17875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17874_17875 : H12AffineEnvironment.transform 14 0 env17874 = env17875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17874 == env17875) = true)

theorem identity17875 : scanCanonicalize (H12AffineFastState.compose env17875 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound17875 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env17876 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5376,0,263,5393,2309,1024,1,4144,32,49,3,300,17,2049,5425,4097,2341,1316,32,256,33,5409,512]

theorem envBound17876 : H12AffineFastState.Bounded env17876 := by
  intro p hp
  have h : env17876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17875_17876 : H12AffineEnvironment.transform 12 301 env17875 = env17876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env17875 == env17876) = true)

theorem identity17876 : scanCanonicalize (H12AffineFastState.compose env17876 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17876 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env17877 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,9,5156,0,35,5173,2081,1024,1,4144,32,49,3,8,17,2049,5141,4097,2049,1024,32,36,33,5125,512]

theorem envBound17877 : H12AffineFastState.Bounded env17877 := by
  intro p hp
  have h : env17877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17876_17877 : H12AffineEnvironment.transform 7 36 env17876 = env17877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17876 == env17877) = true)

theorem identity17877 : scanCanonicalize (H12AffineFastState.compose env17877 (packedSelected [3,5,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17877 : packedSelected [3,5,16] rootPS < 2^1333 := by decide +kernel

def env17878 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1024,1,4113,1,16,3,8,17,2049,5141,4097,2049,1024,1,5,0,5125,512]

theorem envBound17878 : H12AffineFastState.Bounded env17878 := by
  intro p hp
  have h : env17878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17877_17878 : H12AffineEnvironment.transform 4 1 env17877 = env17878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17877 == env17878) = true)

def env17879 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,0,2,1028,2048,1024,1,1,1,16,3,8,17,2049,1029,17,2049,1024,1,5,0,1045,512]

theorem envBound17879 : H12AffineFastState.Bounded env17879 := by
  intro p hp
  have h : env17879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17878_17879 : H12AffineEnvironment.transform 11 16 env17878 = env17879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17878 == env17879) = true)

theorem identity17879 : scanCanonicalize (H12AffineFastState.compose env17879 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound17879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17880 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,0,2,16,2048,20,1,1,1,16,3,8,17,2049,17,17,2049,20,1,5,0,1,512]

theorem envBound17880 : H12AffineFastState.Bounded env17880 := by
  intro p hp
  have h : env17880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17879_17880 : H12AffineEnvironment.transform 9 20 env17879 = env17880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17879 == env17880) = true)

theorem identity17880 : scanCanonicalize (H12AffineFastState.compose env17880 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17881 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,5,9,1,0,2,5,2048,1,1,1,1,5,3,8,4,2049,4,4,2049,1,1,5,0,1,512]

theorem envBound17881 : H12AffineFastState.Bounded env17881 := by
  intro p hp
  have h : env17881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17880_17881 : H12AffineEnvironment.transform 3 5 env17880 = env17881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17880 == env17881) = true)

def leafEnv17881 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,5,9,1,0,2,5,2048,1,1,1,1,5,3,1,8,1,4,2049,4,4,2049,1,1,5,0,4,3,1,512,1,1,0]

def active17881 : List Nat := [0,1,2,8,10]

def tree17881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17881 : H12WitnessSearch.Good tree17881 := H12GlobalWitnessIndex.good

theorem leafIdentity17881 : H12AffineFastState.composeSystem env17881 rootObs = leafEnv17881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17881 rootObs == leafEnv17881) = true)

theorem terminalChecked17881 : H12PackedTerminal.terminalCheckFast leafEnv17881 active17881 tree17881 = true := by decide +kernel

def env17882 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,0,2,1029,2048,1024,1,0,1,16,3,8,17,2049,1028,16,2049,1024,1,5,0,1044,512]

theorem envBound17882 : H12AffineFastState.Bounded env17882 := by
  intro p hp
  have h : env17882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17878_17882 : H12AffineEnvironment.transform 11 17 env17878 = env17882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17878 == env17882) = true)

def env17883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787197,79131,8466458,8820105,8389956,98814,256,8462515,8492190,8462994]

theorem envBound17883 : H12AffineFastState.Bounded env17883 := by
  intro p hp
  have h : env17883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17856_17883 : H12AffineEnvironment.transform 21 33 env17856 = env17883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env17856 == env17883) = true)

theorem identity17883 : scanCanonicalize (H12AffineFastState.compose env17883 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17883 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,262144,1024,32769,4297,33,8388608,41310,8328,64,8787197,5392,8392721,8820105,8389956,41461,256,8388792,8434837,8389273]

theorem envBound17884 : H12AffineFastState.Bounded env17884 := by
  intro p hp
  have h : env17884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17883_17884 : H12AffineEnvironment.transform 15 8203 env17883 = env17884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17883 == env17884) = true)

def env17885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,8388608,41310,8192,64,8787061,5392,8392721,8819969,8389956,41341,256,8388656,8434717,8389137]

theorem envBound17885 : H12AffineFastState.Bounded env17885 := by
  intro p hp
  have h : env17885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17884_17885 : H12AffineEnvironment.transform 6 8 env17884 = env17885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17884 == env17885) = true)

theorem identity17885 : scanCanonicalize (H12AffineFastState.compose env17885 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound17885 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35108,1024,32769,4161,33,8388608,41310,8192,64,8559953,5392,8392721,8526885,8389956,41341,256,8388656,8434717,8389137]

theorem envBound17886 : H12AffineFastState.Bounded env17886 := by
  intro p hp
  have h : env17886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17885_17886 : H12AffineEnvironment.transform 17 35108 env17885 = env17886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env17885 == env17886) = true)

theorem identity17886 : scanCanonicalize (H12AffineFastState.compose env17886 (packedSelected [4,7,9,14,16,20,21,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound17886 : packedSelected [4,7,9,14,16,20,21,27,35] rootPS < 2^1333 := by decide +kernel

def env17887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35108,1024,32769,4161,33,16,41310,8192,64,171329,5392,4097,138293,1364,41341,256,32,46093,513]

theorem envBound17887 : H12AffineFastState.Bounded env17887 := by
  intro p hp
  have h : env17887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17886_17887 : H12AffineEnvironment.transform 22 16 env17886 = env17887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17886 == env17887) = true)

theorem identity17887 : scanCanonicalize (H12AffineFastState.compose env17887 (packedSelected [2,4,5,6,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound17887 : packedSelected [2,4,5,6,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env17888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,81,8203,131072,2421,1024,80,4161,33,16,8463,8192,64,138512,5392,4097,138293,1364,8492,256,32,13404,513]

theorem envBound17888 : H12AffineFastState.Bounded env17888 := by
  intro p hp
  have h : env17888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17887_17888 : H12AffineEnvironment.transform 14 81 env17887 = env17888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env17887 == env17888) = true)

theorem identity17888 : scanCanonicalize (H12AffineFastState.compose env17888 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound17888 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env17889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,81,8203,13341,2421,1024,80,4161,33,16,8463,8192,64,10509,5392,4097,10280,1364,8492,256,32,13404,513]

theorem envBound17889 : H12AffineFastState.Bounded env17889 := by
  intro p hp
  have h : env17889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17888_17889 : H12AffineEnvironment.transform 16 13341 env17888 = env17889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env17888 == env17889) = true)

theorem identity17889 : scanCanonicalize (H12AffineFastState.compose env17889 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17889 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,262,5392,2421,1024,80,4161,33,16,2,269,64,2048,5392,4097,2341,1364,33,256,32,5457,513]

theorem envBound17890 : H12AffineFastState.Bounded env17890 := by
  intro p hp
  have h : env17890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17889_17890 : H12AffineEnvironment.transform 12 269 env17889 = env17890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17889 == env17890) = true)

theorem identity17890 : scanCanonicalize (H12AffineFastState.compose env17890 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound17890 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1077,269,308,81,262,293,2421,1024,80,1140,33,16,2,269,64,2048,293,1076,2341,1364,33,256,32,356,513]

theorem envBound17891 : H12AffineFastState.Bounded env17891 := by
  intro p hp
  have h : env17891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17890_17891 : H12AffineEnvironment.transform 11 1077 env17890 = env17891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env17890 == env17891) = true)

theorem identity17891 : scanCanonicalize (H12AffineFastState.compose env17891 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound17891 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env17892 : List Nat := [2,4,8,16,32,64,8,14,512,1024,2048,1077,3,58,81,8,43,2171,1024,80,1140,33,16,2,3,64,2048,43,1076,2091,1114,33,14,32,106,513]

theorem envBound17892 : H12AffineFastState.Bounded env17892 := by
  intro p hp
  have h : env17892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17891_17892 : H12AffineEnvironment.transform 7 14 env17891 = env17892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env17891 == env17892) = true)

theorem identity17892 : scanCanonicalize (H12AffineFastState.compose env17892 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17892 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env17893 : List Nat := [2,4,8,16,32,17,8,14,512,1024,2048,1077,3,58,0,8,43,2090,1024,1,1061,33,16,2,3,17,2048,43,1076,2091,1035,33,14,32,59,513]

theorem envBound17893 : H12AffineFastState.Bounded env17893 := by
  intro p hp
  have h : env17893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17892_17893 : H12AffineEnvironment.transform 5 17 env17892 = env17893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17892 == env17893) = true)

theorem identity17893 : scanCanonicalize (H12AffineFastState.compose env17893 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound17893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17894 : List Nat := [2,4,8,16,32,17,8,14,512,21,2048,32,3,58,0,8,43,2090,21,1,48,33,16,2,3,17,2048,43,33,2091,30,33,14,32,59,513]

theorem envBound17894 : H12AffineFastState.Bounded env17894 := by
  intro p hp
  have h : env17894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0