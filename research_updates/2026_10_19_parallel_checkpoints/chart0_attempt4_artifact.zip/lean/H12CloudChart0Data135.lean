import H12CloudChart0Data134

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity34257 : scanCanonicalize (H12AffineFastState.compose env34257 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34257 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34258 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,0,3,2064,2049,20,1,2049,0,17,3,8,17,2048,2064,2065,2049,21,0,5,1,2049,512]

theorem envBound34258 : H12AffineFastState.Bounded env34258 := by
  intro p hp
  have h : env34258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34257_34258 : H12AffineEnvironment.transform 5 16 env34257 = env34258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34257 == env34258) = true)

def env34259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,8388608,98781,8328,65,12683622,5392,8406288,8456378,8390093,4256860,256,8410416,8434837,8462874]

theorem envBound34259 : H12AffineFastState.Bounded env34259 := by
  intro p hp
  have h : env34259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34207_34259 : H12AffineEnvironment.transform 20 4161 env34207 = env34259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34207 == env34259) = true)

def env34260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374560,98781,8328,65,215366,5392,4359472,4442266,4376045,4256860,256,4363536,4355253,4448826]

theorem envBound34260 : H12AffineFastState.Bounded env34260 := by
  intro p hp
  have h : env34260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34259_34260 : H12AffineEnvironment.transform 22 4374560 env34259 = env34260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env34259 == env34260) = true)

theorem identity34260 : scanCanonicalize (H12AffineFastState.compose env34260 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34260 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,4194304,4374560,41430,8328,65,158029,5392,4359472,4384913,4376045,4256860,256,4363536,4355253,4375089]

theorem envBound34261 : H12AffineFastState.Bounded env34261 := by
  intro p hp
  have h : env34261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34260_34261 : H12AffineEnvironment.transform 15 8203 env34260 = env34261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34260 == env34261) = true)

theorem identity34261 : scanCanonicalize (H12AffineFastState.compose env34261 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound34261 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,180272,16,41430,8328,65,158029,5392,17664,10401,1501,144492,256,21792,46213,513]

theorem envBound34262 : H12AffineFastState.Bounded env34262 := by
  intro p hp
  have h : env34262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34261_34262 : H12AffineEnvironment.transform 21 180272 env34261 = env34262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env34261 == env34262) = true)

theorem identity34262 : scanCanonicalize (H12AffineFastState.compose env34262 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound34262 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43169,1024,32769,4161,32801,16,41430,8328,65,10588,5392,17664,10401,1501,29821,256,21792,46213,513]

theorem envBound34263 : H12AffineFastState.Bounded env34263 := by
  intro p hp
  have h : env34263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34262_34263 : H12AffineEnvironment.transform 16 16401 env34262 = env34263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34262 == env34263) = true)

theorem identity34263 : scanCanonicalize (H12AffineFastState.compose env34263 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34263 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,43169,1024,32769,4161,32801,16,41430,8328,65,10588,5392,12636,10401,1501,33,256,8572,46213,513]

theorem envBound34264 : H12AffineFastState.Bounded env34264 := by
  intro p hp
  have h : env34264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34263_34264 : H12AffineEnvironment.transform 13 13404 env34263 = env34264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34263 == env34264) = true)

theorem identity34264 : scanCanonicalize (H12AffineFastState.compose env34264 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34264 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8541,8203,13389,2556,1024,8540,4161,8572,16,139,8328,65,10588,5392,12636,10401,1501,33,256,8572,5592,513]

theorem envBound34265 : H12AffineFastState.Bounded env34265 := by
  intro p hp
  have h : env34265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34264_34265 : H12AffineEnvironment.transform 14 8541 env34264 = env34265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34264 == env34265) = true)

theorem identity34265 : scanCanonicalize (H12AffineFastState.compose env34265 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34265 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1,343,5393,2556,1024,0,4161,32,16,139,468,65,2048,5392,4096,2557,1501,33,256,32,5592,513]

theorem envBound34266 : H12AffineFastState.Bounded env34266 := by
  intro p hp
  have h : env34266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34265_34266 : H12AffineEnvironment.transform 12 348 env34265 = env34266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34265 == env34266) = true)

theorem identity34266 : scanCanonicalize (H12AffineFastState.compose env34266 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3309) := by decide +kernel

theorem selectedBound34266 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3309,348,2541,1,343,2556,2556,1024,0,3244,32,16,139,468,65,2048,2557,3309,2557,1501,33,256,32,2357,513]

theorem envBound34267 : H12AffineFastState.Bounded env34267 := by
  intro p hp
  have h : env34267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34266_34267 : H12AffineEnvironment.transform 11 3309 env34266 = env34267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3309 env34266 == env34267) = true)

theorem identity34267 : scanCanonicalize (H12AffineFastState.compose env34267 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound34267 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env34268 : List Nat := [2,4,8,16,32,64,128,256,512,266,2048,2535,348,2541,1,343,2556,2556,266,0,2470,32,16,139,468,65,2048,2557,2535,2557,215,33,256,32,2357,513]

theorem envBound34268 : H12AffineFastState.Bounded env34268 := by
  intro p hp
  have h : env34268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34267_34268 : H12AffineEnvironment.transform 9 266 env34267 = env34268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env34267 == env34268) = true)

def env34269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374561,98781,8328,65,215367,5392,4359473,4442267,4376044,4256860,256,4363537,4355252,4448827]

theorem envBound34269 : H12AffineFastState.Bounded env34269 := by
  intro p hp
  have h : env34269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34259_34269 : H12AffineEnvironment.transform 22 4374561 env34259 = env34269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env34259 == env34269) = true)

theorem identity34269 : scanCanonicalize (H12AffineFastState.compose env34269 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound34269 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,254010,73755,98781,8328,65,215367,5392,91403,10401,75222,201830,256,95531,103566,513]

theorem envBound34270 : H12AffineFastState.Bounded env34270 := by
  intro p hp
  have h : env34270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34269_34270 : H12AffineEnvironment.transform 21 254010 env34269 = env34270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env34269 == env34270) = true)

def env34271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,254010,73755,98645,8192,65,215367,5392,91403,10281,75102,201830,256,95531,103430,513]

theorem envBound34271 : H12AffineFastState.Bounded env34271 := by
  intro p hp
  have h : env34271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34270_34271 : H12AffineEnvironment.transform 6 8 env34270 = env34271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34270 == env34271) = true)

theorem identity34271 : scanCanonicalize (H12AffineFastState.compose env34271 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34271 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,43048,1024,32769,4161,32801,73755,98645,8192,65,10588,5392,91403,10281,75102,29821,256,95531,103430,513]

theorem envBound34272 : H12AffineFastState.Bounded env34272 := by
  intro p hp
  have h : env34272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34271_34272 : H12AffineEnvironment.transform 16 90139 env34271 = env34272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34271 == env34272) = true)

theorem identity34272 : scanCanonicalize (H12AffineFastState.compose env34272 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound34272 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,90139,23589,1024,29708,4161,29740,73755,95576,8192,65,10588,5392,91403,10281,75102,29821,256,95531,90123,513]

theorem envBound34273 : H12AffineFastState.Bounded env34273 := by
  intro p hp
  have h : env34273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34272_34273 : H12AffineEnvironment.transform 14 29709 env34272 = env34273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env34272 == env34273) = true)

theorem identity34273 : scanCanonicalize (H12AffineFastState.compose env34273 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34273 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34274 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,16384,28776,65536,90139,22592,101,28777,4161,28745,73755,94525,8192,65,10588,4469,90478,10281,74043,28696,256,94542,90123,513]

theorem envBound34274 : H12AffineFastState.Bounded env34274 := by
  intro p hp
  have h : env34274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34273_34274 : H12AffineEnvironment.transform 9 101 env34273 = env34274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34273 == env34274) = true)

theorem identity34274 : scanCanonicalize (H12AffineFastState.compose env34274 (packedSelected [2,3,5,6,10,11,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound34274 : packedSelected [2,3,5,6,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env34275 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,12620,292,65536,69975,10508,101,293,4161,261,73755,65649,8192,65,10588,4469,69666,10281,74043,340,256,65538,69959,513]

theorem envBound34275 : H12AffineFastState.Bounded env34275 := by
  intro p hp
  have h : env34275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34274_34275 : H12AffineEnvironment.transform 13 12620 env34274 = env34275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env34274 == env34275) = true)

theorem identity34275 : scanCanonicalize (H12AffineFastState.compose env34275 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34275 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env34276 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,12620,292,8202,12637,10508,101,293,4161,261,17,8315,8192,65,10588,4469,12328,10281,305,340,256,8200,12621,513]

theorem envBound34276 : H12AffineFastState.Bounded env34276 := by
  intro p hp
  have h : env34276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34275_34276 : H12AffineEnvironment.transform 15 8202 env34275 = env34276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34275 == env34276) = true)

theorem identity34276 : scanCanonicalize (H12AffineFastState.compose env34276 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34276 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env34277 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,41,4453,292,35,4468,2341,101,293,4161,261,17,82,41,65,2421,4469,4097,2048,305,340,256,33,4452,513]

theorem envBound34277 : H12AffineFastState.Bounded env34277 := by
  intro p hp
  have h : env34277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34276_34277 : H12AffineEnvironment.transform 12 41 env34276 = env34277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34276 == env34277) = true)

theorem identity34277 : scanCanonicalize (H12AffineFastState.compose env34277 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34277 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34278 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4405,292,35,4388,2341,53,293,4113,261,17,2,41,17,2341,4389,4097,2048,305,260,256,33,4404,513]

theorem envBound34278 : H12AffineFastState.Bounded env34278 := by
  intro p hp
  have h : env34278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34277_34278 : H12AffineEnvironment.transform 5 16 env34277 = env34278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34277 == env34278) = true)

def env34279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,254010,73755,98644,8193,65,215367,5392,91403,10280,75103,201830,256,95531,103431,513]

theorem envBound34279 : H12AffineFastState.Bounded env34279 := by
  intro p hp
  have h : env34279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34270_34279 : H12AffineEnvironment.transform 6 9 env34270 = env34279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34270 == env34279) = true)

theorem identity34279 : scanCanonicalize (H12AffineFastState.compose env34279 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound34279 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4161,33,73755,98644,8193,65,43356,5392,91403,10280,75103,62589,256,95531,103431,513]

theorem envBound34280 : H12AffineFastState.Bounded env34280 := by
  intro p hp
  have h : env34280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34279_34280 : H12AffineEnvironment.transform 16 122907 env34279 = env34280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env34279 == env34280) = true)

theorem identity34280 : scanCanonicalize (H12AffineFastState.compose env34280 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34280 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env34281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4161,33,16,41311,8193,65,43356,5392,17664,10280,1364,62589,256,21792,46092,513]

theorem envBound34281 : H12AffineFastState.Bounded env34281 := by
  intro p hp
  have h : env34281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34280_34281 : H12AffineEnvironment.transform 15 8203 env34280 = env34281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34280 == env34281) = true)

theorem identity34281 : scanCanonicalize (H12AffineFastState.compose env34281 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34281 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49168,2340,1024,32769,4161,33,16,32850,268,65,34897,5392,17664,2341,1364,54640,256,21792,38145,513]

theorem envBound34282 : H12AffineFastState.Bounded env34282 := by
  intro p hp
  have h : env34282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34281_34282 : H12AffineEnvironment.transform 12 269 env34281 = env34282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34281 == env34282) = true)

theorem identity34282 : scanCanonicalize (H12AffineFastState.compose env34282 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34282 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1024,1,4161,33,16,82,268,65,2129,5392,17664,2341,1364,21872,256,21792,5377,513]

theorem envBound34283 : H12AffineFastState.Bounded env34283 := by
  intro p hp
  have h : env34283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34282_34283 : H12AffineEnvironment.transform 14 0 env34282 = env34283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34282 == env34283) = true)

theorem identity34283 : scanCanonicalize (H12AffineFastState.compose env34283 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34283 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34284 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1024,1,4113,33,16,2,268,17,2049,5392,17664,2341,1284,21792,256,21792,5377,513]

theorem envBound34284 : H12AffineFastState.Bounded env34284 := by
  intro p hp
  have h : env34284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34283_34284 : H12AffineEnvironment.transform 5 16 env34283 = env34284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34283 == env34284) = true)

theorem identity34284 : scanCanonicalize (H12AffineFastState.compose env34284 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34284 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34285 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,16384,0,262,16400,2340,272,1,4113,33,16,2,268,17,2049,4096,16400,2341,20,20528,256,20528,4113,513]

theorem envBound34285 : H12AffineFastState.Bounded env34285 := by
  intro p hp
  have h : env34285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34284_34285 : H12AffineEnvironment.transform 9 272 env34284 = env34285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34284 == env34285) = true)

theorem identity34285 : scanCanonicalize (H12AffineFastState.compose env34285 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound34285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34286 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,33,0,262,49,2340,272,1,4113,33,16,2,268,17,2049,4096,49,2341,20,4113,256,4113,4113,513]

theorem envBound34286 : H12AffineFastState.Bounded env34286 := by
  intro p hp
  have h : env34286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34285_34286 : H12AffineEnvironment.transform 13 33 env34285 = env34286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env34285 == env34286) = true)

theorem identity34286 : scanCanonicalize (H12AffineFastState.compose env34286 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34286 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34287 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,4096,269,33,0,262,49,293,272,1,4113,33,16,2,268,17,0,4096,49,292,20,4113,256,4113,4113,513]

theorem envBound34287 : H12AffineFastState.Bounded env34287 := by
  intro p hp
  have h : env34287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34286_34287 : H12AffineEnvironment.transform 10 1 env34286 = env34287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34286 == env34287) = true)

theorem identity34287 : scanCanonicalize (H12AffineFastState.compose env34287 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound34287 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34288 : List Nat := [2,4,8,16,32,16,9,52,512,36,1,4096,57,33,0,50,49,17,36,1,4113,33,16,2,56,17,0,4096,49,16,20,4113,52,4113,4113,513]

theorem envBound34288 : H12AffineFastState.Bounded env34288 := by
  intro p hp
  have h : env34288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34287_34288 : H12AffineEnvironment.transform 7 52 env34287 = env34288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env34287 == env34288) = true)

theorem identity34288 : scanCanonicalize (H12AffineFastState.compose env34288 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34288 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34289 : List Nat := [2,4,8,16,16,16,9,4,512,20,1,4096,9,17,0,2,1,17,20,1,4113,17,16,2,8,17,0,4096,1,16,20,4113,4,4113,4113,513]

theorem envBound34289 : H12AffineFastState.Bounded env34289 := by
  intro p hp
  have h : env34289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34288_34289 : H12AffineEnvironment.transform 4 16 env34288 = env34289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34288 == env34289) = true)

theorem identity34289 : scanCanonicalize (H12AffineFastState.compose env34289 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34289 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34290 : List Nat := [2,4,8,16,16,16,9,4,16,20,1,4096,9,17,0,2,1,17,20,1,4113,17,16,2,8,17,0,4096,1,16,20,4113,4,4113,4113,17]

theorem envBound34290 : H12AffineFastState.Bounded env34290 := by
  intro p hp
  have h : env34290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34289_34290 : H12AffineEnvironment.transform 8 16 env34289 = env34290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34289 == env34290) = true)

def env34291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784806,5393,10507601,8456378,10491277,4256861,256,8410417,8434836,10564186]

theorem envBound34291 : H12AffineFastState.Bounded env34291 := by
  intro p hp
  have h : env34291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34206_34291 : H12AffineEnvironment.transform 23 2199965 env34206 = env34291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env34206 == env34291) = true)

def env34292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,8388608,98781,8328,65,12683622,5393,8406289,8456378,8390093,4256861,256,8410417,8434836,8462874]

theorem envBound34292 : H12AffineFastState.Bounded env34292 := by
  intro p hp
  have h : env34292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34291_34292 : H12AffineEnvironment.transform 20 4160 env34291 = env34292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34291 == env34292) = true)

def env34293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374560,98781,8328,65,215366,5393,4359473,4442266,4376045,4256861,256,4363537,4355252,4448826]

theorem envBound34293 : H12AffineFastState.Bounded env34293 := by
  intro p hp
  have h : env34293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34292_34293 : H12AffineEnvironment.transform 22 4374560 env34292 = env34293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env34292 == env34293) = true)

theorem identity34293 : scanCanonicalize (H12AffineFastState.compose env34293 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound34293 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,180272,16,98781,8328,65,215366,5393,17665,67754,1501,144493,256,21793,46212,74250]

theorem envBound34294 : H12AffineFastState.Bounded env34294 := by
  intro p hp
  have h : env34294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34293_34294 : H12AffineEnvironment.transform 21 180272 env34293 = env34294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env34293 == env34294) = true)

def env34295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180272,16,98645,8192,65,215366,5393,17665,67618,1365,144493,256,21793,46092,74250]

theorem envBound34295 : H12AffineFastState.Bounded env34295 := by
  intro p hp
  have h : env34295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34294_34295 : H12AffineEnvironment.transform 6 8 env34294 = env34295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34294 == env34295) = true)

theorem identity34295 : scanCanonicalize (H12AffineFastState.compose env34295 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound34295 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35189,1024,32769,4160,98678,16,98645,8192,65,2048,5393,17665,67618,1365,95531,256,21793,46092,74250]

theorem envBound34296 : H12AffineFastState.Bounded env34296 := by
  intro p hp
  have h : env34296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34295_34296 : H12AffineEnvironment.transform 16 82246 env34295 = env34296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env34295 == env34296) = true)

theorem identity34296 : scanCanonicalize (H12AffineFastState.compose env34296 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34296 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82246,35189,1024,32769,4160,98678,16,98645,348,65,2048,5393,17665,67618,1365,87159,256,21793,38224,66390]

theorem envBound34297 : H12AffineFastState.Bounded env34297 := by
  intro p hp
  have h : env34297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34296_34297 : H12AffineEnvironment.transform 12 348 env34296 = env34297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34296 == env34297) = true)

theorem identity34297 : scanCanonicalize (H12AffineFastState.compose env34297 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound34297 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21590,5392,35189,1024,32769,4160,54560,16,54531,348,65,2048,5393,17665,23668,1365,33,256,21793,38224,22272]

theorem envBound34298 : H12AffineFastState.Bounded env34298 := by
  intro p hp
  have h : env34298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34297_34298 : H12AffineEnvironment.transform 15 21590 env34297 = env34298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env34297 == env34298) = true)

theorem identity34298 : scanCanonicalize (H12AffineFastState.compose env34298 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound34298 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env34299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,5392,23668,1024,21760,4160,33,16,2,348,65,2048,5393,17665,23668,1365,33,256,21793,16465,22272]

theorem envBound34299 : H12AffineFastState.Bounded env34299 := by
  intro p hp
  have h : env34299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34298_34299 : H12AffineEnvironment.transform 14 21761 env34298 = env34299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env34298 == env34299) = true)

theorem identity34299 : scanCanonicalize (H12AffineFastState.compose env34299 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1140) := by decide +kernel

theorem selectedBound34299 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env34300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1140,4469,4130,5392,6144,1024,4468,4160,33,16,2,348,65,2048,5393,373,6144,1365,33,256,4437,1061,4980]

theorem envBound34300 : H12AffineFastState.Bounded env34300 := by
  intro p hp
  have h : env34300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34299_34300 : H12AffineEnvironment.transform 13 1140 env34299 = env34300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1140 env34299 == env34300) = true)

theorem identity34300 : scanCanonicalize (H12AffineFastState.compose env34300 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound34300 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,64,4096,348,1140,4469,4130,5392,4160,1024,4468,4160,33,16,2,348,65,64,5393,373,4160,1365,33,256,4437,1061,4980]

theorem envBound34301 : H12AffineFastState.Bounded env34301 := by
  intro p hp
  have h : env34301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34300_34301 : H12AffineEnvironment.transform 10 64 env34300 = env34301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env34300 == env34301) = true)

theorem identity34301 : scanCanonicalize (H12AffineFastState.compose env34301 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound34301 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env34302 : List Nat := [2,4,8,16,32,64,8,53,512,1024,64,4096,105,1140,4160,4130,5157,4160,1024,4161,4160,33,16,2,105,65,64,5156,64,4160,1120,33,53,4192,1061,4673]

theorem envBound34302 : H12AffineFastState.Bounded env34302 := by
  intro p hp
  have h : env34302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34301_34302 : H12AffineEnvironment.transform 7 53 env34301 = env34302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env34301 == env34302) = true)

theorem identity34302 : scanCanonicalize (H12AffineFastState.compose env34302 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound34302 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env34303 : List Nat := [2,4,8,16,32,64,8,53,512,84,64,4096,105,32,4160,4130,4209,4160,84,4161,4160,33,16,2,105,65,64,4208,64,4160,52,33,53,4192,113,4673]

theorem envBound34303 : H12AffineFastState.Bounded env34303 := by
  intro p hp
  have h : env34303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34302_34303 : H12AffineEnvironment.transform 9 84 env34302 = env34303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env34302 == env34303) = true)

theorem identity34303 : scanCanonicalize (H12AffineFastState.compose env34303 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound34303 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env34304 : List Nat := [2,4,8,16,32,64,8,53,512,84,64,65,105,32,1,99,48,1,84,0,1,33,16,2,105,65,64,49,64,1,52,33,53,33,113,512]

theorem envBound34304 : H12AffineFastState.Bounded env34304 := by
  intro p hp
  have h : env34304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34303_34304 : H12AffineEnvironment.transform 11 65 env34303 = env34304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env34303 == env34304) = true)

theorem identity34304 : scanCanonicalize (H12AffineFastState.compose env34304 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound34304 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34305 : List Nat := [2,4,8,16,32,64,8,53,64,84,64,65,105,32,1,99,48,1,84,0,1,33,16,2,105,65,64,49,64,1,52,33,53,33,113,64]

theorem envBound34305 : H12AffineFastState.Bounded env34305 := by
  intro p hp
  have h : env34305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34304_34305 : H12AffineEnvironment.transform 8 64 env34304 = env34305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env34304 == env34305) = true)

theorem identity34305 : scanCanonicalize (H12AffineFastState.compose env34305 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34305 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34306 : List Nat := [2,4,8,16,32,49,8,53,49,37,49,48,24,32,1,18,48,1,37,0,1,33,16,2,24,48,49,49,49,1,52,33,53,33,0,49]

theorem envBound34306 : H12AffineFastState.Bounded env34306 := by
  intro p hp
  have h : env34306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34305_34306 : H12AffineEnvironment.transform 5 49 env34305 = env34306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34305 == env34306) = true)

def env34307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180272,16,98644,8193,65,215366,5393,17665,67619,1364,144493,256,21793,46093,74250]

theorem envBound34307 : H12AffineFastState.Bounded env34307 := by
  intro p hp
  have h : env34307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34294_34307 : H12AffineEnvironment.transform 6 9 env34294 = env34307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34294 == env34307) = true)

theorem identity34307 : scanCanonicalize (H12AffineFastState.compose env34307 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound34307 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4160,73771,16,98644,8193,65,43357,5393,17665,67619,1364,119926,256,21793,46093,74250]

theorem envBound34308 : H12AffineFastState.Bounded env34308 := by
  intro p hp
  have h : env34308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34307_34308 : H12AffineEnvironment.transform 16 122907 env34307 = env34308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env34307 == env34308) = true)

theorem identity34308 : scanCanonicalize (H12AffineFastState.compose env34308 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound34308 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env34309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1024,32769,4160,32801,16,8542,8193,65,43357,5393,17665,43049,1364,29820,256,21793,46093,33280]

theorem envBound34309 : H12AffineFastState.Bounded env34309 := by
  intro p hp
  have h : env34309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34308_34309 : H12AffineEnvironment.transform 15 40970 env34308 = env34309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env34308 == env34309) = true)

def env34310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374561,98781,8328,65,215367,5393,4359472,4442267,4376044,4256861,256,4363536,4355253,4448827]

theorem envBound34310 : H12AffineFastState.Bounded env34310 := by
  intro p hp
  have h : env34310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34292_34310 : H12AffineEnvironment.transform 22 4374561 env34292 = env34310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env34292 == env34310) = true)

def env34311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100523,1024,32769,4160,4194304,4227121,98781,8328,65,67927,5393,4244768,4294795,4228604,4256861,256,4248832,4207781,4301355]

theorem envBound34311 : H12AffineFastState.Bounded env34311 := by
  intro p hp
  have h : env34311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34310_34311 : H12AffineEnvironment.transform 16 16400 env34310 = env34311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34310 == env34311) = true)

theorem identity34311 : scanCanonicalize (H12AffineFastState.compose env34311 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound34311 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env34312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100523,1024,32769,4160,168,32921,98781,8328,65,67927,5393,50568,100387,34132,62709,256,54696,13325,107139]

theorem envBound34312 : H12AffineFastState.Bounded env34312 := by
  intro p hp
  have h : env34312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34311_34312 : H12AffineEnvironment.transform 21 168 env34311 = env34312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env34311 == env34312) = true)

theorem identity34312 : scanCanonicalize (H12AffineFastState.compose env34312 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound34312 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10400,1024,32769,4160,168,32921,8662,8328,65,43356,5393,50568,10280,34132,62709,256,54696,13325,648]

theorem envBound34313 : H12AffineFastState.Bounded env34313 := by
  intro p hp
  have h : env34313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34312_34313 : H12AffineEnvironment.transform 15 40971 env34312 = env34313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env34312 == env34313) = true)

theorem identity34313 : scanCanonicalize (H12AffineFastState.compose env34313 (packedSelected [3,5,8,10,17,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34313 : packedSelected [3,5,8,10,17,28,31] rootPS < 2^1333 := by decide +kernel

def env34314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10281,1024,32769,4160,33,32784,8543,8193,65,43356,5393,50433,10280,34132,62588,256,54561,13325,513]

theorem envBound34314 : H12AffineFastState.Bounded env34314 := by
  intro p hp
  have h : env34314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34313_34314 : H12AffineEnvironment.transform 6 9 env34313 = env34314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34313 == env34314) = true)

theorem identity34314 : scanCanonicalize (H12AffineFastState.compose env34314 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34314 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21591,16400,10281,1024,29789,4160,33,29772,8543,8193,65,23808,5393,12637,10280,28936,32,256,8573,13325,513]

theorem envBound34315 : H12AffineFastState.Bounded env34315 := by
  intro p hp
  have h : env34315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34314_34315 : H12AffineEnvironment.transform 14 29788 env34314 = env34315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34314 == env34315) = true)

theorem identity34315 : scanCanonicalize (H12AffineFastState.compose env34315 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,5393,10281,1024,8540,4160,33,8525,8543,8193,65,2049,5393,12637,10280,9225,32,256,8573,13325,513]

theorem envBound34316 : H12AffineFastState.Bounded env34316 := by
  intro p hp
  have h : env34316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34315_34316 : H12AffineEnvironment.transform 13 5377 env34315 = env34316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34315 == env34316) = true)

theorem identity34316 : scanCanonicalize (H12AffineFastState.compose env34316 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34316 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env34317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5393,2420,1024,1,4160,33,16,2,348,65,2049,5393,4096,2421,1364,32,256,32,5456,513]

theorem envBound34317 : H12AffineFastState.Bounded env34317 := by
  intro p hp
  have h : env34317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34316_34317 : H12AffineEnvironment.transform 12 349 env34316 = env34317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34316 == env34317) = true)

theorem identity34317 : scanCanonicalize (H12AffineFastState.compose env34317 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34317 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34318 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,0,115,5172,2129,1024,1,4160,33,16,2,121,65,2049,5172,4096,2128,1137,32,37,32,5237,513]

theorem envBound34318 : H12AffineFastState.Bounded env34318 := by
  intro p hp
  have h : env34318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34317_34318 : H12AffineEnvironment.transform 7 37 env34317 = env34318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34317 == env34318) = true)

theorem identity34318 : scanCanonicalize (H12AffineFastState.compose env34318 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34318 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34319 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,0,115,4097,2129,53,1,4160,33,16,2,121,65,2049,4097,4096,2128,68,32,37,32,4160,513]

theorem envBound34319 : H12AffineFastState.Bounded env34319 := by
  intro p hp
  have h : env34319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34318_34319 : H12AffineEnvironment.transform 9 53 env34318 = env34319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34318 == env34319) = true)

theorem identity34319 : scanCanonicalize (H12AffineFastState.compose env34319 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound34319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34320 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,96,120,113,0,115,97,2129,53,1,32,33,16,2,121,65,2049,97,96,2128,68,32,37,32,32,513]

theorem envBound34320 : H12AffineFastState.Bounded env34320 := by
  intro p hp
  have h : env34320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34319_34320 : H12AffineEnvironment.transform 11 96 env34319 = env34320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env34319 == env34320) = true)

theorem identity34320 : scanCanonicalize (H12AffineFastState.compose env34320 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound34320 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34321 : List Nat := [2,4,8,16,32,64,9,37,512,53,80,96,120,113,0,115,97,1,53,1,32,33,16,2,121,65,81,97,96,0,68,32,37,32,32,513]

theorem envBound34321 : H12AffineFastState.Bounded env34321 := by
  intro p hp
  have h : env34321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34320_34321 : H12AffineEnvironment.transform 10 80 env34320 = env34321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env34320 == env34321) = true)

theorem identity34321 : scanCanonicalize (H12AffineFastState.compose env34321 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound34321 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34322 : List Nat := [2,4,8,16,32,0,9,37,512,53,16,32,56,49,0,51,33,1,53,1,32,33,16,2,57,1,17,33,32,0,4,32,37,32,32,513]

theorem envBound34322 : H12AffineFastState.Bounded env34322 := by
  intro p hp
  have h : env34322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34321_34322 : H12AffineEnvironment.transform 5 0 env34321 = env34322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34321 == env34322) = true)

theorem identity34322 : scanCanonicalize (H12AffineFastState.compose env34322 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound34322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34323 : List Nat := [2,4,8,16,32,0,9,37,58,53,16,32,56,49,0,51,33,1,53,1,32,33,16,2,57,1,17,33,32,0,4,32,37,32,32,59]

theorem envBound34323 : H12AffineFastState.Bounded env34323 := by
  intro p hp
  have h : env34323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34322_34323 : H12AffineEnvironment.transform 8 58 env34322 = env34323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env34322 == env34323) = true)

theorem identity34323 : scanCanonicalize (H12AffineFastState.compose env34323 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34323 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34324 : List Nat := [2,4,8,16,16,0,9,21,10,5,16,16,8,1,0,3,17,1,5,1,16,17,16,2,9,1,17,17,16,0,4,16,21,16,16,11]

theorem envBound34324 : H12AffineFastState.Bounded env34324 := by
  intro p hp
  have h : env34324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34323_34324 : H12AffineEnvironment.transform 4 16 env34323 = env34324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34323 == env34324) = true)

theorem identity34324 : scanCanonicalize (H12AffineFastState.compose env34324 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34324 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34325 : List Nat := [2,4,8,10,10,0,9,15,10,5,10,10,8,1,0,3,11,1,5,1,10,11,10,2,9,1,11,11,10,0,4,10,15,10,10,11]

theorem envBound34325 : H12AffineFastState.Bounded env34325 := by
  intro p hp
  have h : env34325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34324_34325 : H12AffineEnvironment.transform 3 10 env34324 = env34325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34324 == env34325) = true)

theorem identity34325 : scanCanonicalize (H12AffineFastState.compose env34325 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34326 : List Nat := [2,4,2,0,0,0,3,5,0,5,0,0,2,1,0,3,1,1,5,1,0,1,0,2,3,1,1,1,0,0,4,0,5,0,0,1]

theorem envBound34326 : H12AffineFastState.Bounded env34326 := by
  intro p hp
  have h : env34326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34325_34326 : H12AffineEnvironment.transform 2 2 env34325 = env34326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34325 == env34326) = true)

def env34327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,100522,1024,32769,4160,4194304,4227120,98781,8328,65,67926,5393,4244769,4294794,4228605,4256861,256,4248833,4207780,4301354]

theorem envBound34327 : H12AffineFastState.Bounded env34327 := by
  intro p hp
  have h : env34327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34310_34327 : H12AffineEnvironment.transform 16 16401 env34310 = env34327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34310 == env34327) = true)

theorem identity34327 : scanCanonicalize (H12AffineFastState.compose env34327 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound34327 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env34328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,16401,43048,1024,32769,4160,4194304,4227120,41311,8328,65,10708,5393,4244769,4237320,4228605,4256861,256,4248833,4207780,4227752]

theorem envBound34328 : H12AffineFastState.Bounded env34328 := by
  intro p hp
  have h : env34328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34327_34328 : H12AffineEnvironment.transform 15 8322 env34327 = env34328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env34327 == env34328) = true)

theorem identity34328 : scanCanonicalize (H12AffineFastState.compose env34328 (packedSelected [1,3,4,7,9,10,14,16,19,20,24,26,27,28,31,35] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound34328 : packedSelected [1,3,4,7,9,10,14,16,19,20,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,16401,43048,1024,32769,4160,32937,153,41311,8328,65,10708,5393,17800,10401,1364,29940,256,21928,46093,513]

theorem envBound34329 : H12AffineFastState.Bounded env34329 := by
  intro p hp
  have h : env34329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34328_34329 : H12AffineEnvironment.transform 21 32937 env34328 = env34329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env34328 == env34329) = true)

theorem identity34329 : scanCanonicalize (H12AffineFastState.compose env34329 (packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34329 : packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env34330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32801,17,41311,8192,65,10588,5393,17664,10281,1364,29820,256,21792,46093,513]

theorem envBound34330 : H12AffineFastState.Bounded env34330 := by
  intro p hp
  have h : env34330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34329_34330 : H12AffineEnvironment.transform 6 8 env34329 = env34330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34329 == env34330) = true)

theorem identity34330 : scanCanonicalize (H12AffineFastState.compose env34330 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2421,1024,8540,4160,8572,17,2,8192,65,10588,5393,17664,10281,1364,29820,256,21792,5456,513]

theorem envBound34331 : H12AffineFastState.Bounded env34331 := by
  intro p hp
  have h : env34331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34330_34331 : H12AffineEnvironment.transform 14 8541 env34330 = env34331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34330 == env34331) = true)

theorem identity34331 : scanCanonicalize (H12AffineFastState.compose env34331 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34331 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34332 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8313,8202,16401,2129,1024,8312,4160,8280,17,2,8192,65,10360,5173,17444,10281,1136,29820,36,21508,5236,513]

theorem envBound34332 : H12AffineFastState.Bounded env34332 := by
  intro p hp
  have h : env34332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34331_34332 : H12AffineEnvironment.transform 7 36 env34331 = env34332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34331 == env34332) = true)

theorem identity34332 : scanCanonicalize (H12AffineFastState.compose env34332 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound34332 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34333 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8313,8202,12408,2129,1024,8312,4160,8280,17,2,8192,65,10360,5173,13389,10281,1136,1045,36,9325,5236,513]

theorem envBound34333 : H12AffineFastState.Bounded env34333 := by
  intro p hp
  have h : env34333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34332_34333 : H12AffineEnvironment.transform 13 12393 env34332 = env34333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env34332 == env34333) = true)

def env34334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,8388608,98780,8328,65,12683623,5393,8406288,8456378,8390092,4256861,256,8410417,8434836,8462875]

theorem envBound34334 : H12AffineFastState.Bounded env34334 := by
  intro p hp
  have h : env34334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34291_34334 : H12AffineEnvironment.transform 20 4161 env34291 = env34334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34291 == env34334) = true)

def env34335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374560,98780,8328,65,215367,5393,4359472,4442266,4376044,4256861,256,4363537,4355252,4448827]

theorem envBound34335 : H12AffineFastState.Bounded env34335 := by
  intro p hp
  have h : env34335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34334_34335 : H12AffineEnvironment.transform 22 4374560 env34334 = env34335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env34334 == env34335) = true)

theorem identity34335 : scanCanonicalize (H12AffineFastState.compose env34335 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound34335 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,144613,62661,98780,8328,65,215367,5393,45525,130175,61705,180408,256,41460,16465,120542]

theorem envBound34336 : H12AffineFastState.Bounded env34336 := by
  intro p hp
  have h : env34336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34335_34336 : H12AffineEnvironment.transform 21 144613 env34335 = env34336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env34335 == env34336) = true)

def env34337 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4113,144565,62613,98700,8328,17,215319,5393,45445,130095,61705,180408,256,41380,16385,120462]

theorem envBound34337 : H12AffineFastState.Bounded env34337 := by
  intro p hp
  have h : env34337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34336_34337 : H12AffineEnvironment.transform 5 16 env34336 = env34337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34336 == env34337) = true)

theorem identity34337 : scanCanonicalize (H12AffineFastState.compose env34337 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 46229) := by decide +kernel

theorem selectedBound34337 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env34338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46229,97326,1024,32769,4113,32800,62613,98700,8328,17,130434,5393,45445,130095,61705,29741,256,41380,16385,120462]

theorem envBound34338 : H12AffineFastState.Bounded env34338 := by
  intro p hp
  have h : env34338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34337_34338 : H12AffineEnvironment.transform 16 46229 env34337 = env34338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46229 env34337 == env34338) = true)

theorem identity34338 : scanCanonicalize (H12AffineFastState.compose env34338 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound34338 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34339 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46229,43169,1024,32769,4113,32800,62613,21763,8328,17,10509,5393,45445,10400,61705,29741,256,41380,16385,513]

theorem envBound34339 : H12AffineFastState.Bounded env34339 := by
  intro p hp
  have h : env34339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34338_34339 : H12AffineEnvironment.transform 15 54415 env34338 = env34339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env34338 == env34339) = true)

theorem identity34339 : scanCanonicalize (H12AffineFastState.compose env34339 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound34339 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34340 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8202,16400,23588,1024,29828,4113,29861,16,21763,8328,17,10509,5393,17664,10400,1420,29741,256,21793,16385,513]

theorem envBound34340 : H12AffineFastState.Bounded env34340 := by
  intro p hp
  have h : env34340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34339_34340 : H12AffineEnvironment.transform 14 29829 env34339 = env34340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env34339 == env34340) = true)

theorem identity34340 : scanCanonicalize (H12AffineFastState.compose env34340 (packedSelected [3,4,5,7,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34340 : packedSelected [3,4,5,7,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34341 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,8202,13340,10280,1024,136,4113,169,16,8463,8328,17,10509,5393,12556,10400,1420,33,256,8493,13325,513]

theorem envBound34341 : H12AffineFastState.Bounded env34341 := by
  intro p hp
  have h : env34341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34340_34341 : H12AffineEnvironment.transform 13 13324 env34340 = env34341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34340 == env34341) = true)

theorem identity34341 : scanCanonicalize (H12AffineFastState.compose env34341 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound34341 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34342 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,8192,12693,137,8202,12677,10280,409,136,4113,169,16,8463,8328,17,10509,4232,12556,10400,21,33,256,8493,12692,513]

theorem envBound34342 : H12AffineFastState.Bounded env34342 := by
  intro p hp
  have h : env34342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34341_34342 : H12AffineEnvironment.transform 9 409 env34341 = env34342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env34341 == env34342) = true)

theorem identity34342 : scanCanonicalize (H12AffineFastState.compose env34342 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2730) := by decide +kernel

theorem selectedBound34342 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env34343 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,2730,6975,137,2720,6959,642,409,136,4113,169,16,2981,2594,17,935,4232,7078,522,21,33,256,2951,6974,513]

theorem envBound34343 : H12AffineFastState.Bounded env34343 := by
  intro p hp
  have h : env34343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34342_34343 : H12AffineEnvironment.transform 12 2730 env34342 = env34343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2730 env34342 == env34343) = true)

theorem identity34343 : scanCanonicalize (H12AffineFastState.compose env34343 (packedSelected [1,3,7,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2461) := by decide +kernel

theorem selectedBound34343 : packedSelected [1,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env34344 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,2461,2730,674,137,2720,690,642,409,136,2444,169,16,2981,2594,17,935,2325,571,522,21,33,256,2951,675,513]

theorem envBound34344 : H12AffineFastState.Bounded env34344 := by
  intro p hp
  have h : env34344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34343_34344 : H12AffineEnvironment.transform 11 2461 env34343 = env34344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2461 env34343 == env34344) = true)

theorem identity34344 : scanCanonicalize (H12AffineFastState.compose env34344 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34344 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34345 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2324,2595,555,0,2601,571,523,272,1,2309,32,16,2860,2594,17,814,2325,571,522,21,33,256,2830,554,513]

theorem envBound34345 : H12AffineFastState.Bounded env34345 := by
  intro p hp
  have h : env34345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34344_34345 : H12AffineEnvironment.transform 6 9 env34344 = env34345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34344 == env34345) = true)

theorem identity34345 : scanCanonicalize (H12AffineFastState.compose env34345 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound34345 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34346 : List Nat := [2,4,8,16,32,16,9,256,270,272,2048,2324,2349,293,0,2343,309,261,272,1,2309,32,16,2082,2348,17,32,2325,309,260,21,33,256,2048,292,271]

theorem envBound34346 : H12AffineFastState.Bounded env34346 := by
  intro p hp
  have h : env34346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34345_34346 : H12AffineEnvironment.transform 8 270 env34345 = env34346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env34345 == env34346) = true)

theorem identity34346 : scanCanonicalize (H12AffineFastState.compose env34346 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34346 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34347 : List Nat := [2,4,8,16,32,16,9,5,11,21,2048,2065,2088,32,0,2082,48,0,21,1,2048,32,16,2082,2089,17,32,2064,48,1,21,33,5,2048,33,10]

theorem envBound34347 : H12AffineFastState.Bounded env34347 := by
  intro p hp
  have h : env34347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34346_34347 : H12AffineEnvironment.transform 7 5 env34346 = env34347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34346 == env34347) = true)

theorem identity34347 : scanCanonicalize (H12AffineFastState.compose env34347 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34347 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34348 : List Nat := [2,4,8,16,32,16,9,5,11,21,33,48,9,32,0,3,48,0,21,1,33,32,16,3,8,17,32,49,48,1,21,33,5,33,33,10]

theorem envBound34348 : H12AffineFastState.Bounded env34348 := by
  intro p hp
  have h : env34348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34347_34348 : H12AffineEnvironment.transform 10 33 env34347 = env34348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34347 == env34348) = true)

theorem identity34348 : scanCanonicalize (H12AffineFastState.compose env34348 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34349 : List Nat := [2,4,8,16,0,16,9,5,11,21,1,16,9,0,0,3,16,0,21,1,1,0,16,3,8,17,0,17,16,1,21,1,5,1,1,10]

theorem envBound34349 : H12AffineFastState.Bounded env34349 := by
  intro p hp
  have h : env34349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34348_34349 : H12AffineEnvironment.transform 4 0 env34348 = env34349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34348 == env34349) = true)

theorem identity34349 : scanCanonicalize (H12AffineFastState.compose env34349 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound34349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34350 : List Nat := [2,4,7,16,0,16,6,5,4,21,1,16,6,0,0,3,16,0,21,1,1,0,16,3,7,17,0,17,16,1,21,1,5,1,1,5]

theorem envBound34350 : H12AffineFastState.Bounded env34350 := by
  intro p hp
  have h : env34350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34349_34350 : H12AffineEnvironment.transform 2 7 env34349 = env34350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env34349 == env34350) = true)

theorem identity34350 : scanCanonicalize (H12AffineFastState.compose env34350 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34350 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34351 : List Nat := [2,4,7,7,0,7,6,5,4,2,1,7,6,0,0,3,7,0,2,1,1,0,7,3,7,6,0,6,7,1,2,1,5,1,1,5]

theorem envBound34351 : H12AffineFastState.Bounded env34351 := by
  intro p hp
  have h : env34351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34350_34351 : H12AffineEnvironment.transform 3 7 env34350 = env34351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34350 == env34351) = true)

def env34352 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4112,144564,62612,98701,8328,16,215318,5393,45444,130094,61705,180408,256,41381,16384,120463]

theorem envBound34352 : H12AffineFastState.Bounded env34352 := by
  intro p hp
  have h : env34352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34336_34352 : H12AffineEnvironment.transform 5 17 env34336 = env34352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34336 == env34352) = true)

theorem identity34352 : scanCanonicalize (H12AffineFastState.compose env34352 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34352 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env34353 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,65536,131072,215226,1024,0,4112,144564,29845,65932,8328,16,215318,5393,12677,97327,28936,147641,256,8612,16384,87694]

theorem envBound34353 : H12AffineFastState.Bounded env34353 := by
  intro p hp
  have h : env34353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34352_34353 : H12AffineEnvironment.transform 14 1 env34352 = env34353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34352 == env34353) = true)

theorem identity34353 : scanCanonicalize (H12AffineFastState.compose env34353 (packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound34353 : packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34354 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,263,131072,149949,1024,0,4112,144564,29845,139,8328,16,149521,5393,12677,32040,28936,147641,256,8612,16384,22409]

theorem envBound34354 : H12AffineFastState.Bounded env34354 := by
  intro p hp
  have h : env34354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34353_34354 : H12AffineEnvironment.transform 15 263 env34353 = env34354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env34353 == env34354) = true)

theorem identity34354 : scanCanonicalize (H12AffineFastState.compose env34354 (packedSelected [16,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound34354 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env34355 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,263,13340,32161,1024,0,4112,168,29845,139,8328,16,31757,5393,12677,32040,28936,29861,256,8612,16384,22409]

theorem envBound34355 : H12AffineFastState.Bounded env34355 := by
  intro p hp
  have h : env34355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34354_34355 : H12AffineEnvironment.transform 16 13340 env34354 = env34355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env34354 == env34355) = true)

theorem identity34355 : scanCanonicalize (H12AffineFastState.compose env34355 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound34355 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env34356 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,1,263,13340,10281,1024,0,4112,168,8477,139,8328,16,10629,5393,12677,10400,9344,8493,256,8612,5512,513]

theorem envBound34356 : H12AffineFastState.Bounded env34356 := by
  intro p hp
  have h : env34356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34355_34356 : H12AffineEnvironment.transform 13 5512 env34355 = env34356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34355 == env34356) = true)

theorem identity34356 : scanCanonicalize (H12AffineFastState.compose env34356 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound34356 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,1,263,5528,2477,1024,0,4112,168,153,139,268,16,2049,5393,4097,2340,1284,169,256,32,5512,513]

theorem envBound34357 : H12AffineFastState.Bounded env34357 := by
  intro p hp
  have h : env34357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34356_34357 : H12AffineEnvironment.transform 12 388 env34356 = env34357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env34356 == env34357) = true)

def env34358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374561,98780,8328,65,215366,5393,4359473,4442267,4376045,4256861,256,4363536,4355253,4448826]

theorem envBound34358 : H12AffineFastState.Bounded env34358 := by
  intro p hp
  have h : env34358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34334_34358 : H12AffineEnvironment.transform 22 4374561 env34334 = env34358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env34334 == env34358) = true)

theorem identity34358 : scanCanonicalize (H12AffineFastState.compose env34358 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34358 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4161,4194304,4338932,95497,8328,65,215366,5393,4354532,4406350,4337976,4194440,256,4350405,4355253,4396783]

theorem envBound34359 : H12AffineFastState.Bounded env34359 := by
  intro p hp
  have h : env34359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34358_34359 : H12AffineEnvironment.transform 14 29909 env34358 = env34359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34358 == env34359) = true)

def env34360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4161,144612,16,95497,8328,65,215366,5393,17664,67754,1500,144492,256,21793,16465,74251]

theorem envBound34360 : H12AffineFastState.Bounded env34360 := by
  intro p hp
  have h : env34360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34359_34360 : H12AffineEnvironment.transform 21 144612 env34359 = env34360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144612 env34359 == env34360) = true)

theorem identity34360 : scanCanonicalize (H12AffineFastState.compose env34360 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34360 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,138340,1024,29908,4161,144612,16,21763,8328,65,158028,5393,17664,10400,1500,144492,256,21793,16465,513]

theorem envBound34361 : H12AffineFastState.Bounded env34361 := by
  intro p hp
  have h : env34361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34360_34361 : H12AffineEnvironment.transform 15 8202 env34360 = env34361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34360 == env34361) = true)

theorem identity34361 : scanCanonicalize (H12AffineFastState.compose env34361 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34361 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env34362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,8202,131072,138340,1024,8581,4161,144612,16,82,8328,65,146461,5393,4177,10400,1500,144492,256,112,5376,513]

theorem envBound34362 : H12AffineFastState.Bounded env34362 := by
  intro p hp
  have h : env34362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34361_34362 : H12AffineEnvironment.transform 13 5457 env34361 = env34362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34361 == env34362) = true)

theorem identity34362 : scanCanonicalize (H12AffineFastState.compose env34362 (packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34362 : packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env34363 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,8202,131072,138292,1024,8581,4113,144564,16,2,8328,17,146461,5393,4097,10400,1420,144444,256,32,5376,513]

theorem envBound34363 : H12AffineFastState.Bounded env34363 := by
  intro p hp
  have h : env34363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34362_34363 : H12AffineEnvironment.transform 5 16 env34362 = env34363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34362 == env34363) = true)

theorem identity34363 : scanCanonicalize (H12AffineFastState.compose env34363 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34363 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34364 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,136,262,131072,138292,1024,137,4113,136632,16,2,388,17,138513,5393,4097,2476,1420,136496,256,32,5376,513]

theorem envBound34364 : H12AffineFastState.Bounded env34364 := by
  intro p hp
  have h : env34364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34363_34364 : H12AffineEnvironment.transform 12 268 env34363 = env34364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34363 == env34364) = true)

theorem identity34364 : scanCanonicalize (H12AffineFastState.compose env34364 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 1588) := by decide +kernel

theorem selectedBound34364 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env34365 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,136,262,1588,6656,1024,137,4113,5004,16,2,388,17,6949,5393,4097,2476,1420,4868,256,32,5376,513]

theorem envBound34365 : H12AffineFastState.Bounded env34365 := by
  intro p hp
  have h : env34365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34364_34365 : H12AffineEnvironment.transform 16 1588 env34364 = env34365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1588 env34364 == env34365) = true)

theorem identity34365 : scanCanonicalize (H12AffineFastState.compose env34365 (packedSelected [17] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound34365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34366 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,805,268,1572,136,262,1588,2341,1024,137,820,169,16,2,388,17,2048,1588,804,2476,1420,33,256,32,1573,513]

theorem envBound34366 : H12AffineFastState.Bounded env34366 := by
  intro p hp
  have h : env34366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34365_34366 : H12AffineEnvironment.transform 11 805 env34365 = env34366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env34365 == env34366) = true)

theorem identity34366 : scanCanonicalize (H12AffineFastState.compose env34366 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34366 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34367 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,805,268,528,136,262,512,2341,52,137,820,169,16,2,388,17,2048,512,804,2476,440,33,256,32,529,513]

theorem envBound34367 : H12AffineFastState.Bounded env34367 := by
  intro p hp
  have h : env34367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34366_34367 : H12AffineEnvironment.transform 9 52 env34366 = env34367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34366 == env34367) = true)

theorem identity34367 : scanCanonicalize (H12AffineFastState.compose env34367 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound34367 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34368 : List Nat := [2,4,8,16,32,16,128,256,261,52,2048,32,268,277,136,262,261,2341,52,137,49,169,16,2,388,17,2048,261,33,2476,440,33,256,32,276,260]

theorem envBound34368 : H12AffineFastState.Bounded env34368 := by
  intro p hp
  have h : env34368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34367_34368 : H12AffineEnvironment.transform 8 261 env34367 = env34368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env34367 == env34368) = true)

theorem identity34368 : scanCanonicalize (H12AffineFastState.compose env34368 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound34368 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34369 : List Nat := [2,4,8,16,32,16,128,256,261,52,390,32,268,277,136,262,261,163,52,137,49,169,16,2,388,17,390,261,33,42,440,33,256,32,276,260]

theorem envBound34369 : H12AffineFastState.Bounded env34369 := by
  intro p hp
  have h : env34369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34368_34369 : H12AffineEnvironment.transform 10 390 env34368 = env34369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env34368 == env34369) = true)

theorem identity34369 : scanCanonicalize (H12AffineFastState.compose env34369 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34369 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env34370 : List Nat := [2,4,8,16,1,16,128,256,261,21,390,1,268,277,136,262,261,130,21,137,16,136,16,2,388,17,390,261,0,11,409,0,256,1,276,260]

theorem envBound34370 : H12AffineFastState.Bounded env34370 := by
  intro p hp
  have h : env34370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34369_34370 : H12AffineEnvironment.transform 4 1 env34369 = env34370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34369 == env34370) = true)

theorem identity34370 : scanCanonicalize (H12AffineFastState.compose env34370 (packedSelected [3,4] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound34370 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env34371 : List Nat := [2,4,8,16,1,16,128,8,13,21,142,1,4,29,136,14,13,130,21,137,16,136,16,2,140,17,142,13,0,11,145,0,8,1,28,12]

theorem envBound34371 : H12AffineFastState.Bounded env34371 := by
  intro p hp
  have h : env34371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34370_34371 : H12AffineEnvironment.transform 7 8 env34370 = env34371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env34370 == env34371) = true)

theorem identity34371 : scanCanonicalize (H12AffineFastState.compose env34371 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34371 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env34372 : List Nat := [2,4,8,16,1,16,8,8,13,21,6,1,4,29,0,14,13,10,21,1,16,0,16,2,4,17,6,13,0,11,25,0,8,1,28,12]

theorem envBound34372 : H12AffineFastState.Bounded env34372 := by
  intro p hp
  have h : env34372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34371_34372 : H12AffineEnvironment.transform 6 8 env34371 = env34372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34371 == env34372) = true)

theorem identity34372 : scanCanonicalize (H12AffineFastState.compose env34372 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34372 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34373 : List Nat := [2,4,8,11,1,11,8,8,13,14,6,1,4,6,0,14,13,10,14,1,11,0,11,2,4,10,6,13,0,11,2,0,8,1,7,12]

theorem envBound34373 : H12AffineFastState.Bounded env34373 := by
  intro p hp
  have h : env34373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34372_34373 : H12AffineEnvironment.transform 3 11 env34372 = env34373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34372 == env34373) = true)

theorem identity34373 : scanCanonicalize (H12AffineFastState.compose env34373 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34373 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34374 : List Nat := [1,4,8,8,1,8,8,8,13,13,5,1,4,5,0,13,13,9,13,1,8,0,8,1,4,9,5,13,0,8,1,0,8,1,4,12]

theorem envBound34374 : H12AffineFastState.Bounded env34374 := by
  intro p hp
  have h : env34374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34373_34374 : H12AffineEnvironment.transform 0 1 env34373 = env34374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34373 == env34374) = true)

theorem identity34374 : scanCanonicalize (H12AffineFastState.compose env34374 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34375 : List Nat := [1,4,4,4,1,4,4,4,1,1,5,1,4,5,0,1,1,5,1,1,4,0,4,1,4,5,5,1,0,4,1,0,4,1,4,0]

theorem envBound34375 : H12AffineFastState.Bounded env34375 := by
  intro p hp
  have h : env34375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34374_34375 : H12AffineEnvironment.transform 2 4 env34374 = env34375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34374 == env34375) = true)

theorem identity34375 : scanCanonicalize (H12AffineFastState.compose env34375 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34375 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34376 : List Nat := [1,0,0,0,1,0,0,0,1,1,1,1,0,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1,0,0,1,0,0,1,0,0]

theorem envBound34376 : H12AffineFastState.Bounded env34376 := by
  intro p hp
  have h : env34376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34375_34376 : H12AffineEnvironment.transform 1 0 env34375 = env34376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34375 == env34376) = true)

def env34377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4161,144613,17,95497,8328,65,215366,5393,17665,67755,1501,144493,256,21792,16464,74250]

theorem envBound34377 : H12AffineFastState.Bounded env34377 := by
  intro p hp
  have h : env34377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34359_34377 : H12AffineEnvironment.transform 21 144613 env34359 = env34377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env34359 == env34377) = true)

def env34378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212078,1024,8660,4161,144613,17,73737,8328,65,203846,5393,4097,67755,1501,144493,256,32,5456,74250]

theorem envBound34378 : H12AffineFastState.Bounded env34378 := by
  intro p hp
  have h : env34378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34377_34378 : H12AffineEnvironment.transform 13 5376 env34377 = env34378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34377 == env34378) = true)

theorem identity34378 : scanCanonicalize (H12AffineFastState.compose env34378 (packedSelected [0,1,3,9,11,16,20,22,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound34378 : packedSelected [0,1,3,9,11,16,20,22,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env34379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5576,76198,1024,8660,4161,8493,17,73737,8328,65,67982,5393,4097,67755,1501,8613,256,32,5456,74250]

theorem envBound34379 : H12AffineFastState.Bounded env34379 := by
  intro p hp
  have h : env34379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34378_34379 : H12AffineEnvironment.transform 16 5576 env34378 = env34379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env34378 == env34379) = true)

theorem identity34379 : scanCanonicalize (H12AffineFastState.compose env34379 (packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound34379 : packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env34380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,65536,5576,67699,1024,1,4161,248,17,66012,349,65,67982,5393,4097,67755,1501,112,256,32,5456,66527]

theorem envBound34380 : H12AffineFastState.Bounded env34380 := by
  intro p hp
  have h : env34380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34379_34380 : H12AffineEnvironment.transform 12 469 env34379 = env34380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env34379 == env34380) = true)

theorem identity34380 : scanCanonicalize (H12AffineFastState.compose env34380 (packedSelected [0,1,5,6,7,8,14,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34380 : packedSelected [0,1,5,6,7,8,14,20,24] rootPS < 2^1333 := by decide +kernel

def env34381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,5441,67699,1024,1,4161,113,17,65877,349,65,67847,5393,4097,67618,1364,112,256,32,5456,66390]

theorem envBound34381 : H12AffineFastState.Bounded env34381 := by
  intro p hp
  have h : env34381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34380_34381 : H12AffineEnvironment.transform 6 9 env34380 = env34381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34380 == env34381) = true)

theorem identity34381 : scanCanonicalize (H12AffineFastState.compose env34381 (packedSelected [1,2,3,4,5,8,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound34381 : packedSelected [1,2,3,4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env34382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,1095,5441,3124,1024,1,4161,113,17,1298,349,65,3392,5393,4097,3173,1364,112,256,32,5456,1809]

theorem envBound34382 : H12AffineFastState.Bounded env34382 := by
  intro p hp
  have h : env34382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34381_34382 : H12AffineEnvironment.transform 15 1095 env34381 = env34382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env34381 == env34382) = true)

theorem identity34382 : scanCanonicalize (H12AffineFastState.compose env34382 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound34382 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34383 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,348,4160,0,263,4097,2420,320,1,4161,113,17,82,349,65,2048,4177,4097,2341,20,112,256,32,4112,593]

theorem envBound34383 : H12AffineFastState.Bounded env34383 := by
  intro p hp
  have h : env34383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34382_34383 : H12AffineEnvironment.transform 9 320 env34382 = env34383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34382 == env34383) = true)

theorem identity34383 : scanCanonicalize (H12AffineFastState.compose env34383 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound34383 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34384 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2097,348,2161,0,263,2096,2420,320,1,2160,113,17,82,349,65,2048,2144,2096,2341,20,112,256,32,2081,593]

theorem envBound34384 : H12AffineFastState.Bounded env34384 := by
  intro p hp
  have h : env34384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34383_34384 : H12AffineEnvironment.transform 11 2097 env34383 = env34384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env34383 == env34384) = true)

theorem identity34384 : scanCanonicalize (H12AffineFastState.compose env34384 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34384 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34385 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,2097,300,2049,0,263,2096,2308,304,1,2048,1,17,34,301,49,2048,2064,2096,2341,20,0,256,32,2081,545]

theorem envBound34385 : H12AffineFastState.Bounded env34385 := by
  intro p hp
  have h : env34385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34384_34385 : H12AffineEnvironment.transform 5 48 env34384 = env34385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34384 == env34385) = true)

def env34386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212078,1024,8661,4161,144613,17,73736,8328,65,203847,5393,4096,67755,1501,144493,256,33,5457,74250]

theorem envBound34386 : H12AffineFastState.Bounded env34386 := by
  intro p hp
  have h : env34386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34377_34386 : H12AffineEnvironment.transform 13 5377 env34377 = env34386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34377 == env34386) = true)

theorem identity34386 : scanCanonicalize (H12AffineFastState.compose env34386 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34386 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,212078,1024,8540,4161,144492,17,73736,8193,65,203847,5393,4096,67618,1364,144493,256,33,5457,74250]

theorem envBound34387 : H12AffineFastState.Bounded env34387 := by
  intro p hp
  have h : env34387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34386_34387 : H12AffineEnvironment.transform 6 9 env34386 = env34387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34386 == env34387) = true)

def env34388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound34388 : H12AffineFastState.Bounded env34388 := by
  intro p hp
  have h : env34388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34204_34388 : H12AffineEnvironment.transform 18 1025 env34204 = env34388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34204 == env34388) = true)

theorem identity34388 : scanCanonicalize (H12AffineFastState.compose env34388 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661050) := by decide +kernel

theorem selectedBound34388 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8328,65,4450363,10857655,10507601,8830976,371754,15027706,257,2485399,2428211,297980]

theorem envBound34389 : H12AffineFastState.Bounded env34389 := by
  intro p hp
  have h : env34389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34388_34389 : H12AffineEnvironment.transform 23 8661050 env34388 = env34389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661050 env34388 == env34389) = true)

def env34390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450363,10857535,10507601,8830976,371754,15027570,257,2485279,2428211,297844]

theorem envBound34390 : H12AffineFastState.Bounded env34390 := by
  intro p hp
  have h : env34390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34389_34390 : H12AffineEnvironment.transform 6 8 env34389 = env34390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34389 == env34390) = true)

theorem identity34390 : scanCanonicalize (H12AffineFastState.compose env34390 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound34390 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8429903,8192,65,4450363,10560842,10507601,8538485,75103,14795783,257,2188650,2196550,513]

theorem envBound34391 : H12AffineFastState.Bounded env34391 := by
  intro p hp
  have h : env34391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34390_34391 : H12AffineEnvironment.transform 17 35189 env34390 = env34391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34390 == env34391) = true)

def env34392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,16,41311,8192,65,4450363,2172250,2118977,149861,75103,6407191,257,2188650,2196550,513]

theorem envBound34392 : H12AffineFastState.Bounded env34392 := by
  intro p hp
  have h : env34392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34391_34392 : H12AffineEnvironment.transform 22 16 env34391 = env34392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env34391 == env34392) = true)

theorem identity34392 : scanCanonicalize (H12AffineFastState.compose env34392 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34392 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2172250,2118977,76158,75103,6407191,257,2188650,2196550,513]

theorem envBound34393 : H12AffineFastState.Bounded env34393 := by
  intro p hp
  have h : env34393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34392_34393 : H12AffineEnvironment.transform 16 90139 env34392 = env34393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34392 == env34393) = true)

theorem identity34393 : scanCanonicalize (H12AffineFastState.compose env34393 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound34393 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env34394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2139149,2118977,43049,41992,6309184,257,2155581,2098449,513]

theorem envBound34394 : H12AffineFastState.Bounded env34394 := by
  intro p hp
  have h : env34394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34393_34394 : H12AffineEnvironment.transform 15 33111 env34393 = env34394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env34393 == env34394) = true)

theorem identity34394 : scanCanonicalize (H12AffineFastState.compose env34394 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34394 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env34395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1025,8541,2097152,4194304,16,3,8192,65,4204924,2098513,2118977,2421,1364,6309184,257,2114913,2098449,513]

theorem envBound34395 : H12AffineFastState.Bounded env34395 := by
  intro p hp
  have h : env34395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34394_34395 : H12AffineEnvironment.transform 14 8540 env34394 = env34395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34394 == env34395) = true)

theorem identity34395 : scanCanonicalize (H12AffineFastState.compose env34395 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound34395 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1025,8541,2097152,32,16,3,8192,65,10588,2098513,2118977,2421,1364,2114912,257,2114913,2098449,513]

theorem envBound34396 : H12AffineFastState.Bounded env34396 := by
  intro p hp
  have h : env34396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34395_34396 : H12AffineEnvironment.transform 21 32 env34395 = env34396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env34395 == env34396) = true)

theorem identity34396 : scanCanonicalize (H12AffineFastState.compose env34396 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound34396 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10281,1025,8541,25628,32,16,3,8192,65,10588,24909,12637,2421,1364,8572,257,8573,24845,513]

theorem envBound34397 : H12AffineFastState.Bounded env34397 := by
  intro p hp
  have h : env34397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34396_34397 : H12AffineEnvironment.transform 20 25628 env34396 = env34397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env34396 == env34397) = true)

theorem identity34397 : scanCanonicalize (H12AffineFastState.compose env34397 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound34397 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,16384,113,294,16400,2308,1025,112,17713,32,16,3,301,65,2161,16480,4208,2421,1364,81,257,80,16416,513]

theorem envBound34398 : H12AffineFastState.Bounded env34398 := by
  intro p hp
  have h : env34398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34397_34398 : H12AffineEnvironment.transform 12 301 env34397 = env34398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env34397 == env34398) = true)

theorem identity34398 : scanCanonicalize (H12AffineFastState.compose env34398 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34398 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env34399 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,16384,32,294,16400,2308,1025,33,17713,32,16,3,301,16,2080,16433,4129,2340,1285,0,257,1,16416,513]

theorem envBound34399 : H12AffineFastState.Bounded env34399 := by
  intro p hp
  have h : env34399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34398_34399 : H12AffineEnvironment.transform 5 17 env34398 = env34399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34398 == env34399) = true)

theorem identity34399 : scanCanonicalize (H12AffineFastState.compose env34399 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34399 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34400 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,0,262,16400,2308,1025,1,17681,0,16,3,269,16,2048,16401,4097,2308,1285,0,257,1,16384,513]

theorem envBound34400 : H12AffineFastState.Bounded env34400 := by
  intro p hp
  have h : env34400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34399_34400 : H12AffineEnvironment.transform 4 0 env34399 = env34400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34399 == env34400) = true)

theorem identity34400 : scanCanonicalize (H12AffineFastState.compose env34400 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound34400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34401 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,261,269,16384,0,262,16400,2308,1025,1,17681,0,16,3,269,16,2048,16401,260,2308,1285,0,257,1,16384,513]

theorem envBound34401 : H12AffineFastState.Bounded env34401 := by
  intro p hp
  have h : env34401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34400_34401 : H12AffineEnvironment.transform 11 261 env34400 = env34401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env34400 == env34401) = true)

theorem identity34401 : scanCanonicalize (H12AffineFastState.compose env34401 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound34401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34402 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,261,269,1540,0,262,1556,2308,1025,1,789,0,16,3,269,16,2048,1557,260,2308,1285,0,257,1,1540,513]

theorem envBound34402 : H12AffineFastState.Bounded env34402 := by
  intro p hp
  have h : env34402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34401_34402 : H12AffineEnvironment.transform 13 1540 env34401 = env34402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env34401 == env34402) = true)

theorem identity34402 : scanCanonicalize (H12AffineFastState.compose env34402 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34402 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34403 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,261,269,529,0,262,513,2308,20,1,789,0,16,3,269,16,2048,512,260,2308,272,0,257,1,529,513]

theorem envBound34403 : H12AffineFastState.Bounded env34403 := by
  intro p hp
  have h : env34403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34402_34403 : H12AffineEnvironment.transform 9 21 env34402 = env34403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34402 == env34403) = true)

theorem identity34403 : scanCanonicalize (H12AffineFastState.compose env34403 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound34403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34404 : List Nat := [2,4,8,16,0,17,8,256,261,21,2048,261,269,276,0,262,260,2308,20,1,16,0,16,3,269,16,2048,261,260,2308,272,0,257,1,276,260]

theorem envBound34404 : H12AffineFastState.Bounded env34404 := by
  intro p hp
  have h : env34404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34403_34404 : H12AffineEnvironment.transform 8 261 env34403 = env34404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env34403 == env34404) = true)

theorem identity34404 : scanCanonicalize (H12AffineFastState.compose env34404 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34404 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34405 : List Nat := [2,4,8,16,0,17,8,4,1,21,2048,1,9,16,0,2,0,2048,20,1,16,0,16,3,9,16,2048,1,0,2048,20,0,5,1,16,0]

theorem envBound34405 : H12AffineFastState.Bounded env34405 := by
  intro p hp
  have h : env34405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34404_34405 : H12AffineEnvironment.transform 7 4 env34404 = env34405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34404 == env34405) = true)

theorem identity34405 : scanCanonicalize (H12AffineFastState.compose env34405 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34406 : List Nat := [2,4,8,16,0,17,8,4,1,21,0,1,9,16,0,2,0,0,20,1,16,0,16,3,9,16,0,1,0,0,20,0,5,1,16,0]

theorem envBound34406 : H12AffineFastState.Bounded env34406 := by
  intro p hp
  have h : env34406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34405_34406 : H12AffineEnvironment.transform 10 0 env34405 = env34406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34405 == env34406) = true)

def env34407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,17,41310,8192,65,4450363,2172251,2118976,149860,75103,6407190,257,2188650,2196550,513]

theorem envBound34407 : H12AffineFastState.Bounded env34407 := by
  intro p hp
  have h : env34407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34391_34407 : H12AffineEnvironment.transform 22 17 env34391 = env34407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env34391 == env34407) = true)

theorem identity34407 : scanCanonicalize (H12AffineFastState.compose env34407 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound34407 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env34408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,115734,4194304,17,41310,8192,65,4450363,57677,102742,149860,75103,4194304,257,41340,16464,513]

theorem envBound34408 : H12AffineFastState.Bounded env34408 := by
  intro p hp
  have h : env34408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34407_34408 : H12AffineEnvironment.transform 20 115734 env34407 = env34408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env34407 == env34408) = true)

def env34409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9293,1025,11577,92462,4194304,17,3174,8192,65,4408579,19573,81006,149860,75103,4194304,257,3140,16464,513]

theorem envBound34409 : H12AffineFastState.Bounded env34409 := by
  intro p hp
  have h : env34409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34408_34409 : H12AffineEnvironment.transform 14 11576 env34408 = env34409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env34408 == env34409) = true)

theorem identity34409 : scanCanonicalize (H12AffineFastState.compose env34409 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85282) := by decide +kernel

theorem selectedBound34409 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env34410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,85282,9293,1025,11577,92462,4194304,17,3174,8192,65,4196385,19573,81006,66630,75103,4194304,257,3140,16464,513]

theorem envBound34410 : H12AffineFastState.Bounded env34410 := by
  intro p hp
  have h : env34410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34409_34410 : H12AffineEnvironment.transform 16 85282 env34409 = env34410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85282 env34409 == env34410) = true)

theorem identity34410 : scanCanonicalize (H12AffineFastState.compose env34410 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound34410 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env34411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,65536,82246,9293,1025,8541,91466,4194304,17,2,8192,65,4195397,16401,77834,66630,75103,4194304,257,32,16464,513]

theorem envBound34411 : H12AffineFastState.Bounded env34411 := by
  intro p hp
  have h : env34411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34410_34411 : H12AffineEnvironment.transform 10 1124 env34410 = env34411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env34410 == env34411) = true)

def env34412 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8460,65536,82198,9245,1025,8461,91418,4194304,17,2,8192,17,4195349,16401,77834,66582,75023,4194304,257,32,16384,513]

theorem envBound34412 : H12AffineFastState.Bounded env34412 := by
  intro p hp
  have h : env34412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34411_34412 : H12AffineEnvironment.transform 5 16 env34411 = env34412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34411 == env34412) = true)

theorem identity34412 : scanCanonicalize (H12AffineFastState.compose env34412 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34412 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34413 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8460,8203,24861,9245,1025,8461,17681,4194304,17,2,8192,17,4195349,16401,4097,9245,1284,4194304,257,32,16384,513]

theorem envBound34413 : H12AffineFastState.Bounded env34413 := by
  intro p hp
  have h : env34413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34412_34413 : H12AffineEnvironment.transform 15 8203 env34412 = env34413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34412 == env34413) = true)

theorem identity34413 : scanCanonicalize (H12AffineFastState.compose env34413 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34413 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34414 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,16384,1,262,16400,1296,1025,0,17681,4194304,17,2,269,17,4195349,16401,4097,1296,1284,4194304,257,32,16384,513]

theorem envBound34414 : H12AffineFastState.Bounded env34414 := by
  intro p hp
  have h : env34414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34413_34414 : H12AffineEnvironment.transform 12 269 env34413 = env34414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34413 == env34414) = true)

theorem identity34414 : scanCanonicalize (H12AffineFastState.compose env34414 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound34414 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34415 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,16384,1,262,16400,1296,1025,0,17681,21509,17,2,269,17,20496,16401,4097,1296,1284,21509,257,32,16384,513]

theorem envBound34415 : H12AffineFastState.Bounded env34415 := by
  intro p hp
  have h : env34415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34414_34415 : H12AffineEnvironment.transform 21 21509 env34414 = env34415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env34414 == env34415) = true)

theorem identity34415 : scanCanonicalize (H12AffineFastState.compose env34415 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound34415 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34416 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,5156,1,262,5172,1296,1025,0,4405,33,17,2,269,17,1076,5173,4097,1296,1284,33,257,32,5156,513]

theorem envBound34416 : H12AffineFastState.Bounded env34416 := by
  intro p hp
  have h : env34416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34415_34416 : H12AffineEnvironment.transform 13 5156 env34415 = env34416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env34415 == env34416) = true)

def env34417 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,544,269,1540,1,262,1556,1296,1025,0,789,33,17,2,269,17,1076,1557,545,1296,1284,33,257,32,1540,513]

theorem envBound34417 : H12AffineFastState.Bounded env34417 := by
  intro p hp
  have h : env34417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34416_34417 : H12AffineEnvironment.transform 11 544 env34416 = env34417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env34416 == env34417) = true)

def env34418 : List Nat := [2,4,8,16,32,16,8,256,512,768,820,544,269,260,1,262,276,528,769,0,789,33,17,2,269,17,820,277,545,528,516,33,257,32,260,513]

theorem envBound34418 : H12AffineFastState.Bounded env34418 := by
  intro p hp
  have h : env34418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34417_34418 : H12AffineEnvironment.transform 9 768 env34417 = env34418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env34417 == env34418) = true)

theorem identity34418 : scanCanonicalize (H12AffineFastState.compose env34418 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound34418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34419 : List Nat := [2,4,8,16,32,16,8,256,48,304,260,16,269,260,1,262,276,32,305,0,293,33,17,2,269,17,260,277,17,32,52,33,257,32,260,49]

theorem envBound34419 : H12AffineFastState.Bounded env34419 := by
  intro p hp
  have h : env34419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34418_34419 : H12AffineEnvironment.transform 8 48 env34418 = env34419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34418 == env34419) = true)

def env34420 : List Nat := [2,4,8,16,32,16,8,4,48,52,0,16,9,0,1,2,16,32,53,0,33,33,17,2,9,17,0,17,17,32,52,33,5,32,0,49]

theorem envBound34420 : H12AffineFastState.Bounded env34420 := by
  intro p hp
  have h : env34420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34419_34420 : H12AffineEnvironment.transform 7 4 env34419 = env34420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34419 == env34420) = true)

def env34421 : List Nat := [2,4,8,16,32,16,8,5,48,53,1,16,8,1,1,3,17,32,52,0,32,33,17,2,8,17,1,16,17,32,52,33,4,32,1,49]

theorem envBound34421 : H12AffineFastState.Bounded env34421 := by
  intro p hp
  have h : env34421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34419_34421 : H12AffineEnvironment.transform 7 5 env34419 = env34421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34419 == env34421) = true)

theorem identity34421 : scanCanonicalize (H12AffineFastState.compose env34421 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34421 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34422 : List Nat := [2,4,8,10,32,10,8,5,42,47,1,10,8,1,1,3,11,32,46,0,32,33,11,2,8,11,1,10,11,32,46,33,4,32,1,43]

theorem envBound34422 : H12AffineFastState.Bounded env34422 := by
  intro p hp
  have h : env34422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34421_34422 : H12AffineEnvironment.transform 3 10 env34421 = env34422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34421 == env34422) = true)

def leafEnv34422 : List Nat := [2,4,8,10,32,10,8,5,42,47,1,10,8,1,1,3,11,32,46,0,32,33,11,2,47,8,1,11,1,10,11,32,46,33,4,32,5,3,1,43,1,32,0]

def active34422 : List Nat := [0,1,2,4]

def tree34422 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34422 : H12WitnessSearch.Good tree34422 := H12GlobalWitnessIndex.good

theorem leafIdentity34422 : H12AffineFastState.composeSystem env34422 rootObs = leafEnv34422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34422 rootObs == leafEnv34422) = true)

theorem terminalChecked34422 : H12PackedTerminal.terminalCheckFast leafEnv34422 active34422 tree34422 = true := by decide +kernel

def env34423 : List Nat := [2,4,8,16,32,16,8,256,512,769,821,544,269,261,1,262,277,529,768,0,789,33,17,2,269,17,821,276,545,529,517,33,257,32,261,513]

theorem envBound34423 : H12AffineFastState.Bounded env34423 := by
  intro p hp
  have h : env34423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34417_34423 : H12AffineEnvironment.transform 9 769 env34417 = env34423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env34417 == env34423) = true)

theorem identity34423 : scanCanonicalize (H12AffineFastState.compose env34423 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34424 : List Nat := [2,4,8,16,0,16,8,256,512,769,789,512,269,261,1,262,277,529,768,0,789,1,17,2,269,17,789,276,513,529,517,1,257,0,261,513]

theorem envBound34424 : H12AffineFastState.Bounded env34424 := by
  intro p hp
  have h : env34424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34423_34424 : H12AffineEnvironment.transform 4 0 env34423 = env34424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34423 == env34424) = true)

def env34425 : List Nat := [2,4,8,16,0,16,8,256,276,21,1,276,269,261,1,262,277,261,20,0,1,1,17,2,269,17,1,276,277,261,273,1,257,0,261,277]

theorem envBound34425 : H12AffineFastState.Bounded env34425 := by
  intro p hp
  have h : env34425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34424_34425 : H12AffineEnvironment.transform 8 276 env34424 = env34425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34424 == env34425) = true)

theorem identity34425 : scanCanonicalize (H12AffineFastState.compose env34425 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound34425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34426 : List Nat := [2,4,8,16,0,16,8,31,11,21,1,11,18,26,1,25,10,26,20,0,1,1,17,2,18,17,1,11,10,26,14,1,30,0,26,10]

theorem envBound34426 : H12AffineFastState.Bounded env34426 := by
  intro p hp
  have h : env34426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34425_34426 : H12AffineEnvironment.transform 7 31 env34425 = env34426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env34425 == env34426) = true)

def leafEnv34426 : List Nat := [2,4,8,16,0,16,8,31,11,21,1,11,18,26,1,25,10,26,20,0,1,1,17,2,15,18,1,17,1,11,10,26,14,1,30,0,5,25,26,10,1,1,0]

def active34426 : List Nat := [0,1,2,3]

def tree34426 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34426 : H12WitnessSearch.Good tree34426 := H12GlobalWitnessIndex.good

theorem leafIdentity34426 : H12AffineFastState.composeSystem env34426 rootObs = leafEnv34426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34426 rootObs == leafEnv34426) = true)

theorem terminalChecked34426 : H12PackedTerminal.terminalCheckFast leafEnv34426 active34426 tree34426 = true := by decide +kernel

def env34427 : List Nat := [2,4,8,16,0,16,8,256,277,20,0,277,269,261,1,262,277,260,21,0,0,1,17,2,269,17,0,276,276,260,272,1,257,0,261,276]

theorem envBound34427 : H12AffineFastState.Bounded env34427 := by
  intro p hp
  have h : env34427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34424_34427 : H12AffineEnvironment.transform 8 277 env34424 = env34427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34424 == env34427) = true)

def env34428 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,545,269,1541,1,262,1557,1296,1025,0,788,33,17,2,269,17,1076,1556,544,1296,1284,33,257,32,1541,513]

theorem envBound34428 : H12AffineFastState.Bounded env34428 := by
  intro p hp
  have h : env34428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34416_34428 : H12AffineEnvironment.transform 11 545 env34416 = env34428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env34416 == env34428) = true)

def env34429 : List Nat := [2,4,8,16,32,16,8,256,512,768,820,545,269,261,1,262,277,528,769,0,788,33,17,2,269,17,820,276,544,528,516,33,257,32,261,513]

theorem envBound34429 : H12AffineFastState.Bounded env34429 := by
  intro p hp
  have h : env34429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34428_34429 : H12AffineEnvironment.transform 9 768 env34428 = env34429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env34428 == env34429) = true)

theorem identity34429 : scanCanonicalize (H12AffineFastState.compose env34429 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34430 : List Nat := [2,4,8,16,32,16,8,4,512,516,560,545,9,1,1,2,17,528,517,0,528,33,17,2,9,17,560,16,544,528,516,33,5,32,1,513]

theorem envBound34430 : H12AffineFastState.Bounded env34430 := by
  intro p hp
  have h : env34430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34429_34430 : H12AffineEnvironment.transform 7 4 env34429 = env34430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34429 == env34430) = true)

def env34431 : List Nat := [2,4,8,16,32,16,8,4,48,52,0,17,9,1,1,2,17,32,53,0,32,33,17,2,9,17,0,16,16,32,52,33,5,32,1,49]

theorem envBound34431 : H12AffineFastState.Bounded env34431 := by
  intro p hp
  have h : env34431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34430_34431 : H12AffineEnvironment.transform 8 48 env34430 = env34431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34430 == env34431) = true)

def env34432 : List Nat := [2,4,8,16,32,16,8,4,49,53,1,16,9,1,1,2,17,33,52,0,33,33,17,2,9,17,1,16,17,33,53,33,5,32,1,48]

theorem envBound34432 : H12AffineFastState.Bounded env34432 := by
  intro p hp
  have h : env34432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34430_34432 : H12AffineEnvironment.transform 8 49 env34430 = env34432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34430 == env34432) = true)

theorem identity34432 : scanCanonicalize (H12AffineFastState.compose env34432 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34433 : List Nat := [2,4,8,10,32,10,8,4,43,47,1,10,9,1,1,2,11,33,46,0,33,33,11,2,9,11,1,10,11,33,47,33,5,32,1,42]

theorem envBound34433 : H12AffineFastState.Bounded env34433 := by
  intro p hp
  have h : env34433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34432_34433 : H12AffineEnvironment.transform 3 10 env34432 = env34433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34432 == env34433) = true)

def leafEnv34433 : List Nat := [2,4,8,10,32,10,8,4,43,47,1,10,9,1,1,2,11,33,46,0,33,33,11,2,46,9,1,11,1,10,11,33,47,33,5,32,5,2,1,42,1,33,0]

def active34433 : List Nat := [0,1,2,4]

def tree34433 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34433 : H12WitnessSearch.Good tree34433 := H12GlobalWitnessIndex.good

theorem leafIdentity34433 : H12AffineFastState.composeSystem env34433 rootObs = leafEnv34433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34433 rootObs == leafEnv34433) = true)

theorem terminalChecked34433 : H12PackedTerminal.terminalCheckFast leafEnv34433 active34433 tree34433 = true := by decide +kernel

def env34434 : List Nat := [2,4,8,16,32,16,8,256,512,769,821,545,269,260,1,262,276,529,768,0,788,33,17,2,269,17,821,277,544,529,517,33,257,32,260,513]

theorem envBound34434 : H12AffineFastState.Bounded env34434 := by
  intro p hp
  have h : env34434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34428_34434 : H12AffineEnvironment.transform 9 769 env34428 = env34434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env34428 == env34434) = true)

theorem identity34434 : scanCanonicalize (H12AffineFastState.compose env34434 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound34434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34435 : List Nat := [2,4,8,16,32,16,8,256,277,20,32,308,269,260,1,262,276,260,21,0,1,33,17,2,269,17,32,277,309,260,272,33,257,32,260,276]

theorem envBound34435 : H12AffineFastState.Bounded env34435 := by
  intro p hp
  have h : env34435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34434_34435 : H12AffineEnvironment.transform 8 277 env34434 = env34435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34434 == env34435) = true)

def env34436 : List Nat := [2,4,8,16,0,16,8,256,277,20,0,276,269,260,1,262,276,260,21,0,1,1,17,2,269,17,0,277,277,260,272,1,257,0,260,276]

theorem envBound34436 : H12AffineFastState.Bounded env34436 := by
  intro p hp
  have h : env34436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34435_34436 : H12AffineEnvironment.transform 4 0 env34435 = env34436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34435 == env34436) = true)

def env34437 : List Nat := [2,4,8,16,1,16,8,256,277,20,1,277,269,260,1,262,276,260,21,0,1,0,17,2,269,17,1,277,276,260,272,0,257,1,260,276]

theorem envBound34437 : H12AffineFastState.Bounded env34437 := by
  intro p hp
  have h : env34437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34435_34437 : H12AffineEnvironment.transform 4 1 env34435 = env34437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34435 == env34437) = true)

theorem identity34437 : scanCanonicalize (H12AffineFastState.compose env34437 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound34437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34438 : List Nat := [2,4,8,16,1,16,8,30,11,20,1,11,19,26,1,24,10,26,21,0,1,0,17,2,19,17,1,11,10,26,14,0,31,1,26,10]

theorem envBound34438 : H12AffineFastState.Bounded env34438 := by
  intro p hp
  have h : env34438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34437_34438 : H12AffineEnvironment.transform 7 30 env34437 = env34438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env34437 == env34438) = true)

def leafEnv34438 : List Nat := [2,4,8,16,1,16,8,30,11,20,1,11,19,26,1,24,10,26,21,0,1,0,17,2,15,19,1,17,1,11,10,26,14,0,31,1,5,24,26,10,1,1,0]

def active34438 : List Nat := [0,1,2,3]

def tree34438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34438 : H12WitnessSearch.Good tree34438 := H12GlobalWitnessIndex.good

theorem leafIdentity34438 : H12AffineFastState.composeSystem env34438 rootObs = leafEnv34438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34438 rootObs == leafEnv34438) = true)

theorem terminalChecked34438 : H12PackedTerminal.terminalCheckFast leafEnv34438 active34438 tree34438 = true := by decide +kernel

def env34439 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8461,65536,82199,9244,1025,8460,91419,4194304,17,2,8192,16,4195348,16401,77834,66583,75022,4194304,257,32,16385,513]

theorem envBound34439 : H12AffineFastState.Bounded env34439 := by
  intro p hp
  have h : env34439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34411_34439 : H12AffineEnvironment.transform 5 17 env34411 = env34439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34411 == env34439) = true)

def env34440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9292,1025,11576,92463,4194304,17,3175,8192,65,4408578,19572,81007,149860,75103,4194304,257,3141,16464,513]

theorem envBound34440 : H12AffineFastState.Bounded env34440 := by
  intro p hp
  have h : env34440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34408_34440 : H12AffineEnvironment.transform 14 11577 env34408 = env34440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env34408 == env34440) = true)

theorem identity34440 : scanCanonicalize (H12AffineFastState.compose env34440 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound34440 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env34441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,82246,9292,1025,11576,92463,4194304,17,3175,8192,65,4195396,19572,81007,67618,75103,4194304,257,3141,16464,513]

theorem envBound34441 : H12AffineFastState.Bounded env34441 := by
  intro p hp
  have h : env34441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34440_34441 : H12AffineEnvironment.transform 16 82246 env34440 = env34441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env34440 == env34441) = true)

def env34442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,65536,82246,9292,1025,8540,91467,4194304,17,3,8192,65,4195396,16400,77835,66630,75103,4194304,257,33,16464,513]

theorem envBound34442 : H12AffineFastState.Bounded env34442 := by
  intro p hp
  have h : env34442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34442 : H12AffineEnvironment.transform 10 1124 env34441 = env34442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env34441 == env34442) = true)

theorem identity34442 : scanCanonicalize (H12AffineFastState.compose env34442 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound34442 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,28699,12637,9292,1025,8540,5456,4194304,17,3,8192,65,4195396,16400,16400,29789,21828,4194304,257,33,16464,513]

theorem envBound34443 : H12AffineFastState.Bounded env34443 := by
  intro p hp
  have h : env34443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34442_34443 : H12AffineEnvironment.transform 15 28699 env34442 = env34443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env34442 == env34443) = true)

theorem identity34443 : scanCanonicalize (H12AffineFastState.compose env34443 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34443 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env34444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,41,16384,372,20530,4468,1125,1025,373,5456,4194304,17,3,41,65,4195396,16400,16400,21620,21828,4194304,257,33,16464,513]

theorem envBound34444 : H12AffineFastState.Bounded env34444 := by
  intro p hp
  have h : env34444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34443_34444 : H12AffineEnvironment.transform 12 41 env34443 = env34444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34443 == env34444) = true)

theorem identity34444 : scanCanonicalize (H12AffineFastState.compose env34444 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34444 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34445 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,0,20530,4096,1125,1025,1,5156,4194304,17,3,41,65,4195396,16400,16400,21620,21552,4194304,117,33,16464,513]

theorem envBound34445 : H12AffineFastState.Bounded env34445 := by
  intro p hp
  have h : env34445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34444_34445 : H12AffineEnvironment.transform 7 116 env34444 = env34445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34444 == env34445) = true)

theorem identity34445 : scanCanonicalize (H12AffineFastState.compose env34445 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1045) := by decide +kernel

theorem selectedBound34445 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34446 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,0,20530,4096,1125,1025,1,5156,1045,17,3,41,65,81,16400,16400,21620,21552,1045,117,33,16464,513]

theorem envBound34446 : H12AffineFastState.Bounded env34446 := by
  intro p hp
  have h : env34446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34445_34446 : H12AffineEnvironment.transform 21 1045 env34445 = env34446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1045 env34445 == env34446) = true)

theorem identity34446 : scanCanonicalize (H12AffineFastState.compose env34446 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound34446 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env34447 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,1076,0,5126,4096,1125,1025,1,5156,1045,17,3,41,65,81,1060,1060,4160,4100,1045,117,33,1124,513]

theorem envBound34447 : H12AffineFastState.Bounded env34447 := by
  intro p hp
  have h : env34447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34446_34447 : H12AffineEnvironment.transform 13 1076 env34446 = env34447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env34446 == env34447) = true)

theorem identity34447 : scanCanonicalize (H12AffineFastState.compose env34447 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34447 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34448 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,4096,41,0,0,4146,4096,81,53,1,4112,33,17,3,41,65,81,16,16,4160,4100,33,117,33,80,513]

theorem envBound34448 : H12AffineFastState.Bounded env34448 := by
  intro p hp
  have h : env34448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34447_34448 : H12AffineEnvironment.transform 9 52 env34447 = env34448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34447 == env34448) = true)

theorem identity34448 : scanCanonicalize (H12AffineFastState.compose env34448 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34448 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env34449 : List Nat := [2,4,8,16,32,64,8,116,0,52,80,4096,41,0,0,4146,4096,81,53,1,4112,33,17,3,41,65,81,16,16,4160,4100,33,117,33,80,1]

theorem envBound34449 : H12AffineFastState.Bounded env34449 := by
  intro p hp
  have h : env34449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34448_34449 : H12AffineEnvironment.transform 8 0 env34448 = env34449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34448 == env34449) = true)

theorem identity34449 : scanCanonicalize (H12AffineFastState.compose env34449 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound34449 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34450 : List Nat := [2,4,8,16,32,64,8,116,0,52,80,64,41,0,0,114,64,81,53,1,80,33,17,3,41,65,81,16,16,0,68,33,117,33,80,1]

theorem envBound34450 : H12AffineFastState.Bounded env34450 := by
  intro p hp
  have h : env34450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34449_34450 : H12AffineEnvironment.transform 11 64 env34449 = env34450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env34449 == env34450) = true)

theorem identity34450 : scanCanonicalize (H12AffineFastState.compose env34450 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34451 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,17,41,0,0,35,17,0,53,1,1,33,17,3,41,16,0,16,16,0,21,33,36,33,1,1]

theorem envBound34451 : H12AffineFastState.Bounded env34451 := by
  intro p hp
  have h : env34451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34450_34451 : H12AffineEnvironment.transform 5 17 env34450 = env34451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34450 == env34451) = true)

theorem identity34451 : scanCanonicalize (H12AffineFastState.compose env34451 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34452 : List Nat := [2,4,8,16,17,17,8,20,0,5,1,17,24,0,0,18,17,0,4,1,1,16,17,3,24,16,0,16,16,0,21,16,21,16,1,1]

theorem envBound34452 : H12AffineFastState.Bounded env34452 := by
  intro p hp
  have h : env34452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34451_34452 : H12AffineEnvironment.transform 4 17 env34451 = env34452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34451 == env34452) = true)

theorem identity34452 : scanCanonicalize (H12AffineFastState.compose env34452 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34453 : List Nat := [2,4,8,0,1,1,8,4,0,5,1,1,8,0,0,2,1,0,4,1,1,0,1,3,8,0,0,0,0,0,5,0,5,0,1,1]

theorem envBound34453 : H12AffineFastState.Bounded env34453 := by
  intro p hp
  have h : env34453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34452_34453 : H12AffineEnvironment.transform 3 0 env34452 = env34453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34452 == env34453) = true)

def env34454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,16384,8540,65536,82246,9292,1025,8541,91466,4194304,17,2,8192,65,4195396,16401,77834,66631,75103,4194304,257,32,16464,513]

theorem envBound34454 : H12AffineFastState.Bounded env34454 := by
  intro p hp
  have h : env34454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34454 : H12AffineEnvironment.transform 10 1125 env34441 = env34454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env34441 == env34454) = true)

def env34455 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8460,65536,82198,9244,1025,8461,91418,4194304,17,2,8192,17,4195348,16401,77834,66583,75023,4194304,257,32,16384,513]

theorem envBound34455 : H12AffineFastState.Bounded env34455 := by
  intro p hp
  have h : env34455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34454_34455 : H12AffineEnvironment.transform 5 16 env34454 = env34455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34454 == env34455) = true)

theorem identity34455 : scanCanonicalize (H12AffineFastState.compose env34455 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34455 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34456 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8460,8203,24861,9244,1025,8461,17681,4194304,17,2,8192,17,4195348,16401,4097,9244,1284,4194304,257,32,16384,513]

theorem envBound34456 : H12AffineFastState.Bounded env34456 := by
  intro p hp
  have h : env34456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34455_34456 : H12AffineEnvironment.transform 15 8203 env34455 = env34456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34455 == env34456) = true)

theorem identity34456 : scanCanonicalize (H12AffineFastState.compose env34456 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34457 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,16384,1,262,16400,1297,1025,0,17681,4194304,17,2,269,17,4195348,16401,4097,1297,1284,4194304,257,32,16384,513]

theorem envBound34457 : H12AffineFastState.Bounded env34457 := by
  intro p hp
  have h : env34457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34456_34457 : H12AffineEnvironment.transform 12 269 env34456 = env34457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34456 == env34457) = true)

theorem identity34457 : scanCanonicalize (H12AffineFastState.compose env34457 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound34457 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34458 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,16384,1,262,16400,1297,1025,0,17681,21509,17,2,269,17,20497,16401,4097,1297,1284,21509,257,32,16384,513]

theorem envBound34458 : H12AffineFastState.Bounded env34458 := by
  intro p hp
  have h : env34458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34457_34458 : H12AffineEnvironment.transform 21 21509 env34457 = env34458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env34457 == env34458) = true)

theorem identity34458 : scanCanonicalize (H12AffineFastState.compose env34458 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound34458 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34459 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,5156,1,262,5172,1297,1025,0,4405,33,17,2,269,17,1077,5173,4097,1297,1284,33,257,32,5156,513]

theorem envBound34459 : H12AffineFastState.Bounded env34459 := by
  intro p hp
  have h : env34459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34458_34459 : H12AffineEnvironment.transform 13 5156 env34458 = env34459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env34458 == env34459) = true)

def env34460 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,544,269,1540,1,262,1556,1297,1025,0,789,33,17,2,269,17,1077,1557,545,1297,1284,33,257,32,1540,513]

theorem envBound34460 : H12AffineFastState.Bounded env34460 := by
  intro p hp
  have h : env34460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34459_34460 : H12AffineEnvironment.transform 11 544 env34459 = env34460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env34459 == env34460) = true)

def env34461 : List Nat := [2,4,8,16,32,16,8,256,512,768,821,544,269,260,1,262,276,529,769,0,789,33,17,2,269,17,821,277,545,529,516,33,257,32,260,513]

theorem envBound34461 : H12AffineFastState.Bounded env34461 := by
  intro p hp
  have h : env34461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34460_34461 : H12AffineEnvironment.transform 9 768 env34460 = env34461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env34460 == env34461) = true)

theorem identity34461 : scanCanonicalize (H12AffineFastState.compose env34461 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound34461 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34462 : List Nat := [2,4,8,16,32,16,8,256,277,21,32,309,269,260,1,262,276,260,20,0,0,33,17,2,269,17,32,277,308,260,273,33,257,32,260,276]

theorem envBound34462 : H12AffineFastState.Bounded env34462 := by
  intro p hp
  have h : env34462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34461_34462 : H12AffineEnvironment.transform 8 277 env34461 = env34462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34461 == env34462) = true)

def env34463 : List Nat := [2,4,8,16,0,16,8,256,277,21,0,277,269,260,1,262,276,260,20,0,0,1,17,2,269,17,0,277,276,260,273,1,257,0,260,276]

theorem envBound34463 : H12AffineFastState.Bounded env34463 := by
  intro p hp
  have h : env34463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34462_34463 : H12AffineEnvironment.transform 4 0 env34462 = env34463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34462 == env34463) = true)

theorem identity34463 : scanCanonicalize (H12AffineFastState.compose env34463 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound34463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34464 : List Nat := [2,4,8,16,0,16,8,31,10,21,0,10,18,27,1,25,11,27,20,0,0,1,17,2,18,17,0,10,11,27,14,1,30,0,27,11]

theorem envBound34464 : H12AffineFastState.Bounded env34464 := by
  intro p hp
  have h : env34464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34463_34464 : H12AffineEnvironment.transform 7 31 env34463 = env34464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env34463 == env34464) = true)

def leafEnv34464 : List Nat := [2,4,8,16,0,16,8,31,10,21,0,10,18,27,1,25,11,27,20,0,0,1,17,2,15,18,1,17,0,10,11,27,14,1,30,0,5,25,27,11,1,0,0]

def active34464 : List Nat := [0,1,2,3]

def tree34464 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34464 : H12WitnessSearch.Good tree34464 := H12GlobalWitnessIndex.good

theorem leafIdentity34464 : H12AffineFastState.composeSystem env34464 rootObs = leafEnv34464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34464 rootObs == leafEnv34464) = true)

theorem terminalChecked34464 : H12PackedTerminal.terminalCheckFast leafEnv34464 active34464 tree34464 = true := by decide +kernel

def env34465 : List Nat := [2,4,8,16,1,16,8,256,277,21,1,276,269,260,1,262,276,260,20,0,0,0,17,2,269,17,1,277,277,260,273,0,257,1,260,276]

theorem envBound34465 : H12AffineFastState.Bounded env34465 := by
  intro p hp
  have h : env34465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34462_34465 : H12AffineEnvironment.transform 4 1 env34462 = env34465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34462 == env34465) = true)

def env34466 : List Nat := [2,4,8,16,32,16,8,256,512,769,820,544,269,261,1,262,277,528,768,0,789,33,17,2,269,17,820,276,545,528,517,33,257,32,261,513]

theorem envBound34466 : H12AffineFastState.Bounded env34466 := by
  intro p hp
  have h : env34466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34460_34466 : H12AffineEnvironment.transform 9 769 env34460 = env34466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env34460 == env34466) = true)

theorem identity34466 : scanCanonicalize (H12AffineFastState.compose env34466 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34467 : List Nat := [2,4,8,16,32,16,8,5,512,516,561,544,8,0,1,3,16,528,517,0,528,33,17,2,8,17,561,17,545,528,517,33,4,32,0,513]

theorem envBound34467 : H12AffineFastState.Bounded env34467 := by
  intro p hp
  have h : env34467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34466_34467 : H12AffineEnvironment.transform 7 5 env34466 = env34467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34466 == env34467) = true)

def env34468 : List Nat := [2,4,8,16,32,16,8,5,48,52,1,16,8,0,1,3,16,32,53,0,32,33,17,2,8,17,1,17,17,32,53,33,4,32,0,49]

theorem envBound34468 : H12AffineFastState.Bounded env34468 := by
  intro p hp
  have h : env34468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34467_34468 : H12AffineEnvironment.transform 8 48 env34467 = env34468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34467 == env34468) = true)

def env34469 : List Nat := [2,4,8,16,32,16,8,5,49,53,0,17,8,0,1,3,16,33,52,0,33,33,17,2,8,17,0,17,16,33,52,33,4,32,0,48]

theorem envBound34469 : H12AffineFastState.Bounded env34469 := by
  intro p hp
  have h : env34469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34467_34469 : H12AffineEnvironment.transform 8 49 env34467 = env34469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34467 == env34469) = true)

theorem identity34469 : scanCanonicalize (H12AffineFastState.compose env34469 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34470 : List Nat := [2,4,8,10,32,10,8,5,43,47,0,11,8,0,1,3,10,33,46,0,33,33,11,2,8,11,0,11,10,33,46,33,4,32,0,42]

theorem envBound34470 : H12AffineFastState.Bounded env34470 := by
  intro p hp
  have h : env34470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34469_34470 : H12AffineEnvironment.transform 3 10 env34469 = env34470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34469 == env34470) = true)

def leafEnv34470 : List Nat := [2,4,8,10,32,10,8,5,43,47,0,11,8,0,1,3,10,33,46,0,33,33,11,2,47,8,1,11,0,11,10,33,46,33,4,32,5,3,0,42,1,33,0]

def active34470 : List Nat := [0,1,2,4]

def tree34470 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34470 : H12WitnessSearch.Good tree34470 := H12GlobalWitnessIndex.good

theorem leafIdentity34470 : H12AffineFastState.composeSystem env34470 rootObs = leafEnv34470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34470 rootObs == leafEnv34470) = true)

theorem terminalChecked34470 : H12PackedTerminal.terminalCheckFast leafEnv34470 active34470 tree34470 = true := by decide +kernel

def env34471 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,545,269,1541,1,262,1557,1297,1025,0,788,33,17,2,269,17,1077,1556,544,1297,1284,33,257,32,1541,513]

theorem envBound34471 : H12AffineFastState.Bounded env34471 := by
  intro p hp
  have h : env34471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34459_34471 : H12AffineEnvironment.transform 11 545 env34459 = env34471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env34459 == env34471) = true)

def env34472 : List Nat := [2,4,8,16,32,16,8,256,512,768,821,545,269,261,1,262,277,529,769,0,788,33,17,2,269,17,821,276,544,529,516,33,257,32,261,513]

theorem envBound34472 : H12AffineFastState.Bounded env34472 := by
  intro p hp
  have h : env34472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34471_34472 : H12AffineEnvironment.transform 9 768 env34471 = env34472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env34471 == env34472) = true)

theorem identity34472 : scanCanonicalize (H12AffineFastState.compose env34472 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34473 : List Nat := [2,4,8,16,1,16,8,256,512,768,788,512,269,261,1,262,277,529,769,0,788,0,17,2,269,17,788,276,513,529,516,0,257,1,261,513]

theorem envBound34473 : H12AffineFastState.Bounded env34473 := by
  intro p hp
  have h : env34473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34472_34473 : H12AffineEnvironment.transform 4 1 env34472 = env34473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34472 == env34473) = true)

def env34474 : List Nat := [2,4,8,16,1,16,8,256,276,20,0,276,269,261,1,262,277,261,21,0,0,0,17,2,269,17,0,276,277,261,272,0,257,1,261,277]

theorem envBound34474 : H12AffineFastState.Bounded env34474 := by
  intro p hp
  have h : env34474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34473_34474 : H12AffineEnvironment.transform 8 276 env34473 = env34474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34473 == env34474) = true)

theorem identity34474 : scanCanonicalize (H12AffineFastState.compose env34474 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound34474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34475 : List Nat := [2,4,8,16,1,16,8,30,10,20,0,10,19,27,1,24,11,27,21,0,0,0,17,2,19,17,0,10,11,27,14,0,31,1,27,11]

theorem envBound34475 : H12AffineFastState.Bounded env34475 := by
  intro p hp
  have h : env34475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34474_34475 : H12AffineEnvironment.transform 7 30 env34474 = env34475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env34474 == env34475) = true)

def leafEnv34475 : List Nat := [2,4,8,16,1,16,8,30,10,20,0,10,19,27,1,24,11,27,21,0,0,0,17,2,15,19,1,17,0,10,11,27,14,0,31,1,5,24,27,11,1,0,0]

def active34475 : List Nat := [0,1,2,3]

def tree34475 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34475 : H12WitnessSearch.Good tree34475 := H12GlobalWitnessIndex.good

theorem leafIdentity34475 : H12AffineFastState.composeSystem env34475 rootObs = leafEnv34475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34475 rootObs == leafEnv34475) = true)

theorem terminalChecked34475 : H12PackedTerminal.terminalCheckFast leafEnv34475 active34475 tree34475 = true := by decide +kernel

def env34476 : List Nat := [2,4,8,16,1,16,8,256,277,21,1,277,269,261,1,262,277,260,20,0,1,0,17,2,269,17,1,276,276,260,273,0,257,1,261,276]

theorem envBound34476 : H12AffineFastState.Bounded env34476 := by
  intro p hp
  have h : env34476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34473_34476 : H12AffineEnvironment.transform 8 277 env34473 = env34476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34473 == env34476) = true)

def env34477 : List Nat := [2,4,8,16,32,16,8,256,512,769,820,545,269,260,1,262,276,528,768,0,788,33,17,2,269,17,820,277,544,528,517,33,257,32,260,513]

theorem envBound34477 : H12AffineFastState.Bounded env34477 := by
  intro p hp
  have h : env34477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34471_34477 : H12AffineEnvironment.transform 9 769 env34471 = env34477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env34471 == env34477) = true)

theorem identity34477 : scanCanonicalize (H12AffineFastState.compose env34477 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound34477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34478 : List Nat := [2,4,8,16,32,16,8,256,48,305,260,17,269,260,1,262,276,32,304,0,292,33,17,2,269,17,260,277,16,32,53,33,257,32,260,49]

theorem envBound34478 : H12AffineFastState.Bounded env34478 := by
  intro p hp
  have h : env34478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34477_34478 : H12AffineEnvironment.transform 8 48 env34477 = env34478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34477 == env34478) = true)

def env34479 : List Nat := [2,4,8,16,32,16,8,4,48,53,0,17,9,0,1,2,16,32,52,0,32,33,17,2,9,17,0,17,16,32,53,33,5,32,0,49]

theorem envBound34479 : H12AffineFastState.Bounded env34479 := by
  intro p hp
  have h : env34479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34478_34479 : H12AffineEnvironment.transform 7 4 env34478 = env34479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34478 == env34479) = true)

theorem identity34479 : scanCanonicalize (H12AffineFastState.compose env34479 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34480 : List Nat := [2,4,8,10,32,10,8,4,42,47,0,11,9,0,1,2,10,32,46,0,32,33,11,2,9,11,0,11,10,32,47,33,5,32,0,43]

theorem envBound34480 : H12AffineFastState.Bounded env34480 := by
  intro p hp
  have h : env34480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34479_34480 : H12AffineEnvironment.transform 3 10 env34479 = env34480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34479 == env34480) = true)

def leafEnv34480 : List Nat := [2,4,8,10,32,10,8,4,42,47,0,11,9,0,1,2,10,32,46,0,32,33,11,2,46,9,1,11,0,11,10,32,47,33,5,32,5,2,0,43,1,32,0]

def active34480 : List Nat := [0,1,2,4]

def tree34480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34480 : H12WitnessSearch.Good tree34480 := H12GlobalWitnessIndex.good

theorem leafIdentity34480 : H12AffineFastState.composeSystem env34480 rootObs = leafEnv34480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34480 rootObs == leafEnv34480) = true)

theorem terminalChecked34480 : H12PackedTerminal.terminalCheckFast leafEnv34480 active34480 tree34480 = true := by decide +kernel

def env34481 : List Nat := [2,4,8,16,32,16,8,5,48,52,1,17,8,1,1,3,17,32,53,0,33,33,17,2,8,17,1,16,16,32,53,33,4,32,1,49]

theorem envBound34481 : H12AffineFastState.Bounded env34481 := by
  intro p hp
  have h : env34481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34478_34481 : H12AffineEnvironment.transform 7 5 env34478 = env34481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34478 == env34481) = true)

def env34482 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8461,65536,82199,9245,1025,8460,91419,4194304,17,2,8192,16,4195349,16401,77834,66582,75022,4194304,257,32,16385,513]

theorem envBound34482 : H12AffineFastState.Bounded env34482 := by
  intro p hp
  have h : env34482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34454_34482 : H12AffineEnvironment.transform 5 17 env34454 = env34482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34454 == env34482) = true)

def env34483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4450363,10857534,10507601,8830976,371754,15027571,257,2485278,2428211,297845]

theorem envBound34483 : H12AffineFastState.Bounded env34483 := by
  intro p hp
  have h : env34483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34389_34483 : H12AffineEnvironment.transform 6 9 env34389 = env34483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34389 == env34483) = true)

theorem identity34483 : scanCanonicalize (H12AffineFastState.compose env34483 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34483 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4229152,10857534,10507601,8757275,371754,15027571,257,2485278,2428211,297845]

theorem envBound34484 : H12AffineFastState.Bounded env34484 := by
  intro p hp
  have h : env34484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34483_34484 : H12AffineEnvironment.transform 16 90139 env34483 = env34484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34483 == env34484) = true)

def env34485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,8388608,8429902,8193,65,4229152,10560842,10507601,8464751,75102,14795783,257,2188650,2196551,513]

theorem envBound34485 : H12AffineFastState.Bounded env34485 := by
  intro p hp
  have h : env34485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34484_34485 : H12AffineEnvironment.transform 17 35188 env34484 = env34485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34484 == env34485) = true)

def env34486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2172250,2118977,76159,75102,6407191,257,2188650,2196551,513]

theorem envBound34486 : H12AffineFastState.Bounded env34486 := by
  intro p hp
  have h : env34486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34485_34486 : H12AffineEnvironment.transform 22 16 env34485 = env34486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env34485 == env34486) = true)

theorem identity34486 : scanCanonicalize (H12AffineFastState.compose env34486 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound34486 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env34487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1025,29004,2097152,4194304,16,20499,8193,65,4225389,2172250,2118977,76159,75102,6370650,257,2188650,2192650,513]

theorem envBound34487 : H12AffineFastState.Bounded env34487 := by
  intro p hp
  have h : env34487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34486_34487 : H12AffineEnvironment.transform 14 29005 env34486 = env34487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env34486 == env34487) = true)

def env34488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1025,29004,5456,4194304,16,20499,8193,65,4225389,77834,16401,76159,75102,4268042,257,94266,90202,513]

theorem envBound34488 : H12AffineFastState.Bounded env34488 := by
  intro p hp
  have h : env34488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34487_34488 : H12AffineEnvironment.transform 20 5456 env34487 = env34488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env34487 == env34488) = true)

theorem identity34488 : scanCanonicalize (H12AffineFastState.compose env34488 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound34488 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1025,29004,5456,20529,16,20499,8193,65,10588,77834,16401,76159,75102,94267,257,94266,90202,513]

theorem envBound34489 : H12AffineFastState.Bounded env34489 := by
  intro p hp
  have h : env34489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34488_34489 : H12AffineEnvironment.transform 21 20529 env34488 = env34489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env34488 == env34489) = true)

theorem identity34489 : scanCanonicalize (H12AffineFastState.compose env34489 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34489 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8202,16401,30777,1025,29004,5456,20529,16,20499,8193,65,10588,4096,16401,2421,1364,20529,257,20528,16464,513]

theorem envBound34490 : H12AffineFastState.Bounded env34490 := by
  intro p hp
  have h : env34490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34489_34490 : H12AffineEnvironment.transform 15 8202 env34489 = env34490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34489 == env34490) = true)

theorem identity34490 : scanCanonicalize (H12AffineFastState.compose env34490 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound34490 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,80,8202,12556,2340,1025,81,5456,8492,16,8462,8193,65,10588,4096,12556,2421,1364,8492,257,8493,12621,513]

theorem envBound34491 : H12AffineFastState.Bounded env34491 := by
  intro p hp
  have h : env34491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34490_34491 : H12AffineEnvironment.transform 13 12573 env34490 = env34491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env34490 == env34491) = true)

theorem identity34491 : scanCanonicalize (H12AffineFastState.compose env34491 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34491 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4161,80,342,4176,2340,1025,81,5456,112,16,82,349,65,2048,4096,4176,2421,1364,112,257,113,4113,513]

theorem envBound34492 : H12AffineFastState.Bounded env34492 := by
  intro p hp
  have h : env34492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34491_34492 : H12AffineEnvironment.transform 12 348 env34491 = env34492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34491 == env34492) = true)

theorem identity34492 : scanCanonicalize (H12AffineFastState.compose env34492 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound34492 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env34493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,1125,80,342,1140,2340,1025,81,372,112,16,82,349,65,2048,1060,1140,2421,1364,112,257,113,1077,513]

theorem envBound34493 : H12AffineFastState.Bounded env34493 := by
  intro p hp
  have h : env34493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34492_34493 : H12AffineEnvironment.transform 11 1060 env34492 = env34493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env34492 == env34493) = true)

def env34494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1025,29004,5457,4194304,16,20499,8193,65,4225389,77835,16400,76159,75102,4268043,257,94267,90203,513]

theorem envBound34494 : H12AffineFastState.Bounded env34494 := by
  intro p hp
  have h : env34494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34487_34494 : H12AffineEnvironment.transform 20 5457 env34487 = env34494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env34487 == env34494) = true)

theorem identity34494 : scanCanonicalize (H12AffineFastState.compose env34494 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound34494 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1025,29004,5457,32,16,20499,8193,65,31053,77835,16400,76159,75102,73771,257,94267,90203,513]

theorem envBound34495 : H12AffineFastState.Bounded env34495 := by
  intro p hp
  have h : env34495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34494_34495 : H12AffineEnvironment.transform 21 32 env34494 = env34495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env34494 == env34495) = true)

theorem identity34495 : scanCanonicalize (H12AffineFastState.compose env34495 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound34495 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,65536,77834,10280,1025,8541,5457,32,16,2,8193,65,10588,77835,4097,76159,75102,73771,257,73770,77898,513]

theorem envBound34496 : H12AffineFastState.Bounded env34496 := by
  intro p hp
  have h : env34496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34495_34496 : H12AffineEnvironment.transform 13 4113 env34495 = env34496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env34495 == env34496) = true)

theorem identity34496 : scanCanonicalize (H12AffineFastState.compose env34496 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15486) := by decide +kernel

theorem selectedBound34496 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env34497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,15486,3188,10280,1025,8541,5457,32,16,2,8193,65,10588,3189,4097,5377,6432,7253,257,7252,3124,513]

theorem envBound34497 : H12AffineFastState.Bounded env34497 := by
  intro p hp
  have h : env34497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34496_34497 : H12AffineEnvironment.transform 15 15486 env34496 = env34497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15486 env34496 == env34497) = true)

theorem identity34497 : scanCanonicalize (H12AffineFastState.compose env34497 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34497 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env34498 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4113,8540,14363,2065,10280,100,8541,4404,32,16,2,8193,65,10588,2064,4097,4452,6432,6192,257,6193,2129,513]

theorem envBound34498 : H12AffineFastState.Bounded env34498 := by
  intro p hp
  have h : env34498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34497_34498 : H12AffineEnvironment.transform 9 101 env34497 = env34498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34497 == env34498) = true)

theorem identity34498 : scanCanonicalize (H12AffineFastState.compose env34498 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound34498 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env34499 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,6429,4113,6209,262,2065,4405,100,6208,4404,32,16,2,6428,65,4161,2064,4097,4452,6432,6192,257,6193,2129,513]

theorem envBound34499 : H12AffineFastState.Bounded env34499 := by
  intro p hp
  have h : env34499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34498_34499 : H12AffineEnvironment.transform 12 6429 env34498 = env34499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env34498 == env34499) = true)

theorem identity34499 : scanCanonicalize (H12AffineFastState.compose env34499 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound34499 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34500 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,4096,4200,4113,4404,262,356,4405,100,4405,4404,32,16,2,4201,65,4161,357,4097,4452,4181,4421,257,4420,292,513]

theorem envBound34500 : H12AffineFastState.Bounded env34500 := by
  intro p hp
  have h : env34500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34499_34500 : H12AffineEnvironment.transform 10 373 env34499 = env34500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env34499 == env34500) = true)

theorem identity34500 : scanCanonicalize (H12AffineFastState.compose env34500 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound34500 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34501 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,16,120,1,292,262,356,293,100,293,292,32,16,2,121,65,81,357,17,372,69,341,257,340,292,513]

theorem envBound34501 : H12AffineFastState.Bounded env34501 := by
  intro p hp
  have h : env34501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34500_34501 : H12AffineEnvironment.transform 11 16 env34500 = env34501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34500 == env34501) = true)

theorem identity34501 : scanCanonicalize (H12AffineFastState.compose env34501 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound34501 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env34502 : List Nat := [2,4,8,16,32,64,9,256,308,101,373,16,120,1,292,262,356,293,100,293,292,32,16,2,121,65,81,357,17,372,69,341,257,340,292,309]

theorem envBound34502 : H12AffineFastState.Bounded env34502 := by
  intro p hp
  have h : env34502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34501_34502 : H12AffineEnvironment.transform 8 308 env34501 = env34502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env34501 == env34502) = true)

theorem identity34502 : scanCanonicalize (H12AffineFastState.compose env34502 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34502 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env34503 : List Nat := [2,4,8,16,32,16,9,256,308,53,293,16,40,1,292,262,308,293,52,293,292,32,16,2,41,17,1,309,17,292,21,261,257,260,292,309]

theorem envBound34503 : H12AffineFastState.Bounded env34503 := by
  intro p hp
  have h : env34503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34502_34503 : H12AffineEnvironment.transform 5 16 env34502 = env34503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34502 == env34503) = true)

theorem identity34503 : scanCanonicalize (H12AffineFastState.compose env34503 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34503 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env34504 : List Nat := [2,4,8,16,32,16,9,36,16,53,1,16,40,1,0,34,16,1,52,1,0,32,16,2,41,17,1,17,17,0,21,33,37,32,0,17]

theorem envBound34504 : H12AffineFastState.Bounded env34504 := by
  intro p hp
  have h : env34504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34503_34504 : H12AffineEnvironment.transform 7 36 env34503 = env34504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34503 == env34504) = true)

def env34505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,17,41311,8193,65,4229152,2172251,2118976,76158,75102,6407190,257,2188650,2196551,513]

theorem envBound34505 : H12AffineFastState.Bounded env34505 := by
  intro p hp
  have h : env34505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34485_34505 : H12AffineEnvironment.transform 22 17 env34485 = env34505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env34485 == env34505) = true)

theorem identity34505 : scanCanonicalize (H12AffineFastState.compose env34505 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46092) := by decide +kernel

theorem selectedBound34505 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env34506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,46092,4194304,17,41311,8193,65,4229152,102743,57676,76158,75102,4288538,257,119142,77899,513]

theorem envBound34506 : H12AffineFastState.Bounded env34506 := by
  intro p hp
  have h : env34506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34505_34506 : H12AffineEnvironment.transform 20 46092 env34505 = env34506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46092 env34505 == env34506) = true)

theorem identity34506 : scanCanonicalize (H12AffineFastState.compose env34506 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound34506 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,28699,4096,35188,1025,32769,46092,4194304,17,41311,8193,65,4229152,57676,57676,22885,21829,4194305,257,41341,16464,513]

theorem envBound34507 : H12AffineFastState.Bounded env34507 := by
  intro p hp
  have h : env34507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34506_34507 : H12AffineEnvironment.transform 15 28699 env34506 = env34507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env34506 == env34507) = true)

theorem identity34507 : scanCanonicalize (H12AffineFastState.compose env34507 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34507 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10280,1025,8541,5456,4194304,17,3,8193,65,4204924,16400,16400,22885,21829,4194305,257,33,16464,513]

theorem envBound34508 : H12AffineFastState.Bounded env34508 := by
  intro p hp
  have h : env34508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34507_34508 : H12AffineEnvironment.transform 14 8540 env34507 = env34508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34507 == env34508) = true)

theorem identity34508 : scanCanonicalize (H12AffineFastState.compose env34508 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 27929) := by decide +kernel

theorem selectedBound34508 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10280,1025,8541,5456,27929,17,3,8193,65,17509,16400,16400,22885,21829,27928,257,33,16464,513]

theorem envBound34509 : H12AffineFastState.Bounded env34509 := by
  intro p hp
  have h : env34509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34508_34509 : H12AffineEnvironment.transform 21 27929 env34508 = env34509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27929 env34508 == env34509) = true)

theorem identity34509 : scanCanonicalize (H12AffineFastState.compose env34509 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound34509 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env34510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10508,8540,6423,4096,10280,1025,8541,5456,1045,17,3,8193,65,11625,10524,10524,12393,15433,1044,257,33,10588,513]

theorem envBound34510 : H12AffineFastState.Bounded env34510 := by
  intro p hp
  have h : env34510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34509_34510 : H12AffineEnvironment.transform 13 10508 env34509 = env34510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env34509 == env34510) = true)

theorem identity34510 : scanCanonicalize (H12AffineFastState.compose env34510 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound34510 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,3125,1125,6423,4096,3345,1025,1124,5456,1045,17,3,1336,65,2128,3109,3109,5456,6512,1044,257,33,3173,513]

theorem envBound34511 : H12AffineFastState.Bounded env34511 := by
  intro p hp
  have h : env34511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34510_34511 : H12AffineEnvironment.transform 12 1337 env34510 = env34511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env34510 == env34511) = true)

theorem identity34511 : scanCanonicalize (H12AffineFastState.compose env34511 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34511 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env34512 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,3125,1076,6423,4096,3345,1025,1077,5377,1045,17,3,1336,16,2049,3109,3109,5377,6433,1044,257,33,3124,513]

theorem envBound34512 : H12AffineFastState.Bounded env34512 := by
  intro p hp
  have h : env34512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34511_34512 : H12AffineEnvironment.transform 5 17 env34511 = env34512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34511 == env34512) = true)

theorem identity34512 : scanCanonicalize (H12AffineFastState.compose env34512 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound34512 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env34513 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,40,2340,293,6423,4096,2048,272,292,4112,260,17,3,41,16,2049,2356,2356,4112,6433,261,257,33,2341,513]

theorem envBound34513 : H12AffineFastState.Bounded env34513 := by
  intro p hp
  have h : env34513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34512_34513 : H12AffineEnvironment.transform 9 273 env34512 = env34513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34512 == env34513) = true)

theorem identity34513 : scanCanonicalize (H12AffineFastState.compose env34513 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound34513 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env34514 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2356,40,2340,293,35,2356,2048,272,292,2340,260,17,3,41,16,2049,2356,2356,2340,21,261,257,33,2341,513]

theorem envBound34514 : H12AffineFastState.Bounded env34514 := by
  intro p hp
  have h : env34514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34513_34514 : H12AffineEnvironment.transform 11 2356 env34513 = env34514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env34513 == env34514) = true)

theorem identity34514 : scanCanonicalize (H12AffineFastState.compose env34514 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound34514 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env34515 : List Nat := [2,4,8,16,32,17,9,256,512,273,277,33,40,49,293,35,33,277,272,292,49,260,17,3,41,16,276,33,33,49,21,261,257,33,48,513]

end H12CloudChart0