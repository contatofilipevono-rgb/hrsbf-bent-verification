import H12CloudChart0Data163

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound41573 : H12AffineFastState.Bounded env41573 := by
  intro p hp
  have h : env41573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41572_41573 : H12AffineEnvironment.transform 3 1 env41572 = env41573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41572 == env41573) = true)

theorem identity41573 : scanCanonicalize (H12AffineFastState.compose env41573 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41574 : List Nat := [2,4,8,1,1,0,9,5,1,5,1,1,9,1,0,2,1,1,4,1,1,1,0,3,8,0,1,1,1,1,4,0,4,1,1,1]

theorem envBound41574 : H12AffineFastState.Bounded env41574 := by
  intro p hp
  have h : env41574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41573_41574 : H12AffineEnvironment.transform 4 1 env41573 = env41574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41573 == env41574) = true)

theorem identity41574 : scanCanonicalize (H12AffineFastState.compose env41574 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound41574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41575 : List Nat := [2,1,8,1,1,0,9,0,1,0,1,1,9,1,0,2,1,1,1,1,1,1,0,3,8,0,1,1,1,1,1,0,1,1,1,1]

theorem envBound41575 : H12AffineFastState.Bounded env41575 := by
  intro p hp
  have h : env41575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41574_41575 : H12AffineEnvironment.transform 1 1 env41574 = env41575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env41574 == env41575) = true)

def env41576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,33,2411556,2114834,8328,17,75786,115103,301348,2125113,331047,73890,257,2444699,2468926,273057]

theorem envBound41576 : H12AffineFastState.Bounded env41576 := by
  intro p hp
  have h : env41576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41559_41576 : H12AffineEnvironment.transform 21 33 env41559 = env41576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env41559 == env41576) = true)

theorem identity41576 : scanCanonicalize (H12AffineFastState.compose env41576 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 91539) := by decide +kernel

theorem selectedBound41576 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env41577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,91539,33,371127,73857,8328,17,75786,115103,301348,67754,331047,73890,257,272392,313773,273057]

theorem envBound41577 : H12AffineFastState.Bounded env41577 := by
  intro p hp
  have h : env41577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41576_41577 : H12AffineEnvironment.transform 20 91539 env41576 = env41577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91539 env41576 == env41577) = true)

theorem identity41577 : scanCanonicalize (H12AffineFastState.compose env41577 (packedSelected [1,3,8,9,14,15,19,20,22,24,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound41577 : packedSelected [1,3,8,9,14,15,19,20,22,24,32,35] rootPS < 2^1333 := by decide +kernel

def env41578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,35109,1025,32769,91539,33,73874,73857,8328,17,75786,115103,4097,67754,99330,73890,257,41261,16520,41860]

theorem envBound41578 : H12AffineFastState.Bounded env41578 := by
  intro p hp
  have h : env41578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41577_41578 : H12AffineEnvironment.transform 17 35109 env41577 = env41578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env41577 == env41578) = true)

theorem identity41578 : scanCanonicalize (H12AffineFastState.compose env41578 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound41578 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env41579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,65536,24861,2477,1025,137,91539,33,73874,73857,8328,17,75786,82199,4097,67754,66698,73890,257,8613,16520,8972]

theorem envBound41579 : H12AffineFastState.Bounded env41579 := by
  intro p hp
  have h : env41579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41578_41579 : H12AffineEnvironment.transform 14 136 env41578 = env41579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env41578 == env41579) = true)

theorem identity41579 : scanCanonicalize (H12AffineFastState.compose env41579 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41579 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env41580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,262,24861,2477,1025,137,25749,33,8596,8583,8328,17,10508,16401,4097,2476,1420,8612,257,8613,16520,8972]

theorem envBound41580 : H12AffineFastState.Bounded env41580 := by
  intro p hp
  have h : env41580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41579_41580 : H12AffineEnvironment.transform 15 262 env41579 = env41580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41579 == env41580) = true)

theorem identity41580 : scanCanonicalize (H12AffineFastState.compose env41580 (packedSelected [1,2,4,8,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound41580 : packedSelected [1,2,4,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,136,262,16828,2477,1025,137,17460,33,309,294,41,17,2477,16401,4097,2476,1420,261,257,260,16520,941]

theorem envBound41581 : H12AffineFastState.Bounded env41581 := by
  intro p hp
  have h : env41581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41580_41581 : H12AffineEnvironment.transform 12 161 env41580 = env41581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env41580 == env41581) = true)

theorem identity41581 : scanCanonicalize (H12AffineFastState.compose env41581 (packedSelected [0,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2476) := by decide +kernel

theorem selectedBound41581 : packedSelected [0,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41582 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,2476,136,262,2064,2477,1025,137,3480,33,309,294,41,17,2477,2493,4097,2476,1420,261,257,260,2340,941]

theorem envBound41582 : H12AffineFastState.Bounded env41582 := by
  intro p hp
  have h : env41582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41581_41582 : H12AffineEnvironment.transform 13 2476 env41581 = env41582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2476 env41581 == env41582) = true)

theorem identity41582 : scanCanonicalize (H12AffineFastState.compose env41582 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound41582 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env41583 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,161,2476,136,262,2064,2477,1025,137,3480,33,309,294,41,17,2477,2493,3464,2476,1420,261,257,260,2340,941]

theorem envBound41583 : H12AffineFastState.Bounded env41583 := by
  intro p hp
  have h : env41583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41582_41583 : H12AffineEnvironment.transform 11 3465 env41582 = env41583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env41582 == env41583) = true)

theorem identity41583 : scanCanonicalize (H12AffineFastState.compose env41583 (packedSelected [1,2,3,4,5,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41583 : packedSelected [1,2,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env41584 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3329,41,2340,0,262,2064,2341,1025,1,3344,33,309,294,41,17,2341,2357,3328,2340,1284,261,257,260,2340,805]

theorem envBound41584 : H12AffineFastState.Bounded env41584 := by
  intro p hp
  have h : env41584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41583_41584 : H12AffineEnvironment.transform 6 8 env41583 = env41584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41583 == env41584) = true)

theorem identity41584 : scanCanonicalize (H12AffineFastState.compose env41584 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound41584 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41585 : List Nat := [2,4,8,16,32,17,8,256,512,1024,292,1061,41,0,0,262,308,1,1025,1,1076,33,309,294,41,17,1,17,1060,0,1284,261,257,260,0,805]

theorem envBound41585 : H12AffineFastState.Bounded env41585 := by
  intro p hp
  have h : env41585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41584_41585 : H12AffineEnvironment.transform 10 292 env41584 = env41585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env41584 == env41585) = true)

theorem identity41585 : scanCanonicalize (H12AffineFastState.compose env41585 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41585 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41586 : List Nat := [2,4,8,16,32,17,8,256,512,53,292,16,41,0,0,262,308,1,52,1,1,33,309,294,41,17,1,17,17,0,305,261,257,260,0,805]

theorem envBound41586 : H12AffineFastState.Bounded env41586 := by
  intro p hp
  have h : env41586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41585_41586 : H12AffineEnvironment.transform 9 53 env41585 = env41586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41585 == env41586) = true)

theorem identity41586 : scanCanonicalize (H12AffineFastState.compose env41586 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41586 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env41587 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,0,0,34,16,1,52,1,1,33,17,2,41,17,1,17,17,0,21,33,37,32,0,513]

theorem envBound41587 : H12AffineFastState.Bounded env41587 := by
  intro p hp
  have h : env41587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41586_41587 : H12AffineEnvironment.transform 7 36 env41586 = env41587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41586 == env41587) = true)

theorem identity41587 : scanCanonicalize (H12AffineFastState.compose env41587 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41588 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,16,8,0,0,3,16,1,21,1,1,0,17,2,8,17,1,17,17,0,21,0,4,1,0,513]

theorem envBound41588 : H12AffineFastState.Bounded env41588 := by
  intro p hp
  have h : env41588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41587_41588 : H12AffineEnvironment.transform 4 1 env41587 = env41588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41587 == env41588) = true)

theorem identity41588 : scanCanonicalize (H12AffineFastState.compose env41588 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41589 : List Nat := [2,4,8,1,1,0,8,5,512,5,0,1,8,0,0,3,1,1,4,1,1,0,0,2,8,0,1,0,0,0,4,0,4,1,0,513]

theorem envBound41589 : H12AffineFastState.Bounded env41589 := by
  intro p hp
  have h : env41589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41588_41589 : H12AffineEnvironment.transform 3 1 env41588 = env41589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41588 == env41589) = true)

theorem identity41589 : scanCanonicalize (H12AffineFastState.compose env41589 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41589 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41590 : List Nat := [2,4,8,1,1,0,8,5,1,5,0,1,8,0,0,3,1,1,4,1,1,0,0,2,8,0,1,0,0,0,4,0,4,1,0,0]

theorem envBound41590 : H12AffineFastState.Bounded env41590 := by
  intro p hp
  have h : env41590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41589_41590 : H12AffineEnvironment.transform 8 1 env41589 = env41590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41589 == env41590) = true)

def env41591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066127,115151,10507601,8692045,10600787,4268162,257,8487407,8478794,10544772]

theorem envBound41591 : H12AffineFastState.Bounded env41591 := by
  intro p hp
  have h : env41591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41523_41591 : H12AffineEnvironment.transform 16 24909 env41523 = env41591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env41523 == env41591) = true)

def env41592 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114834,8328,16,15066127,115103,10507521,8691997,10600707,4268162,257,8487359,8478746,10544772]

theorem envBound41592 : H12AffineFastState.Bounded env41592 := by
  intro p hp
  have h : env41592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41591_41592 : H12AffineEnvironment.transform 5 16 env41591 = env41592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41591 == env41592) = true)

theorem identity41592 : scanCanonicalize (H12AffineFastState.compose env41592 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41592 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env41593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8328,16,14797863,115103,10507521,8423733,10600707,4268162,257,8487359,8478746,10544772]

theorem envBound41593 : H12AffineFastState.Bounded env41593 := by
  intro p hp
  have h : env41593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41592_41593 : H12AffineEnvironment.transform 17 10280 env41592 = env41593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41592 == env41593) = true)

def env41594 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8192,16,14797863,114967,10507521,8423733,10600707,4268042,257,8487223,8478746,10544652]

theorem envBound41594 : H12AffineFastState.Bounded env41594 := by
  intro p hp
  have h : env41594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41593_41594 : H12AffineEnvironment.transform 6 8 env41593 = env41594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41593 == env41594) = true)

def env41595 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50448,4194304,8388608,32770,8192,16,12650807,114967,8425489,8423733,8455187,4268042,257,8487223,8478746,8397596]

theorem envBound41595 : H12AffineFastState.Bounded env41595 := by
  intro p hp
  have h : env41595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41594_41595 : H12AffineEnvironment.transform 20 50448 env41594 = env41595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env41594 == env41595) = true)

theorem identity41595 : scanCanonicalize (H12AffineFastState.compose env41595 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 41245) := by decide +kernel

theorem selectedBound41595 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env41596 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50448,4194304,41245,32770,8192,16,4302890,114967,12556,10280,107790,4268042,257,73770,114951,33281]

theorem envBound41596 : H12AffineFastState.Bounded env41596 := by
  intro p hp
  have h : env41596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41595_41596 : H12AffineEnvironment.transform 22 41245 env41595 = env41596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41245 env41595 == env41596) = true)

def env41597 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50449,4194304,8388608,32771,8192,16,12650806,114967,8425488,8423733,8455186,4268042,257,8487223,8478746,8397597]

theorem envBound41597 : H12AffineFastState.Bounded env41597 := by
  intro p hp
  have h : env41597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41594_41597 : H12AffineEnvironment.transform 20 50449 env41594 = env41597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env41594 == env41597) = true)

theorem identity41597 : scanCanonicalize (H12AffineFastState.compose env41597 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235580) := by decide +kernel

theorem selectedBound41597 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env41598 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50449,4194304,4235580,32771,8192,16,108554,114967,4206892,4204553,4302126,4268042,257,4268043,4309286,4227617]

theorem envBound41598 : H12AffineFastState.Bounded env41598 := by
  intro p hp
  have h : env41598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41597_41598 : H12AffineEnvironment.transform 22 4235580 env41597 = env41598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235580 env41597 == env41598) = true)

theorem identity41598 : scanCanonicalize (H12AffineFastState.compose env41598 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41598 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41599 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,65536,24861,10280,1025,0,17680,4194304,4202813,2,8192,16,75787,82198,4206892,4204553,4269359,4268042,257,4268043,4276519,4194848]

theorem envBound41599 : H12AffineFastState.Bounded env41599 := by
  intro p hp
  have h : env41599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41598_41599 : H12AffineEnvironment.transform 14 1 env41598 = env41599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41598 == env41599) = true)

theorem identity41599 : scanCanonicalize (H12AffineFastState.compose env41599 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound41599 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env41600 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,263,24861,10280,1025,0,17680,4194304,4202813,2,8192,16,10508,16401,4206892,4204553,4203560,4202765,257,4202764,4210720,4194848]

theorem envBound41600 : H12AffineFastState.Bounded env41600 := by
  intro p hp
  have h : env41600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41599_41600 : H12AffineEnvironment.transform 15 263 env41599 = env41600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env41599 == env41600) = true)

def env41601 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8193,16,14797863,114966,10507521,8423733,10600707,4268043,257,8487222,8478746,10544653]

theorem envBound41601 : H12AffineFastState.Bounded env41601 := by
  intro p hp
  have h : env41601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41593_41601 : H12AffineEnvironment.transform 6 9 env41593 = env41601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41593 == env41601) = true)

theorem identity41601 : scanCanonicalize (H12AffineFastState.compose env41601 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 41245) := by decide +kernel

theorem selectedBound41601 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41602 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,41245,2114834,8193,16,6384954,114966,2159644,10280,2187294,4268043,257,73771,114951,2115344]

theorem envBound41602 : H12AffineFastState.Bounded env41602 := by
  intro p hp
  have h : env41602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41601_41602 : H12AffineEnvironment.transform 22 41245 env41601 = env41602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41245 env41601 == env41602) = true)

theorem identity41602 : scanCanonicalize (H12AffineFastState.compose env41602 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound41602 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41603 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,293,65536,24861,10280,1025,292,2097152,4194304,8248,2114834,8193,16,6384954,81971,2127161,10280,2187294,4268043,257,73771,81954,2115344]

theorem envBound41603 : H12AffineFastState.Bounded env41603 := by
  intro p hp
  have h : env41603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41602_41603 : H12AffineEnvironment.transform 14 293 env41602 = env41603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env41602 == env41603) = true)

theorem identity41603 : scanCanonicalize (H12AffineFastState.compose env41603 (packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound41603 : packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env41604 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,293,65536,24861,10280,1025,292,2097152,8200,8248,2114834,8193,16,2182450,81971,2127161,10280,2187294,65539,257,73771,81954,2115344]

theorem envBound41604 : H12AffineFastState.Bounded env41604 := by
  intro p hp
  have h : env41604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41603_41604 : H12AffineEnvironment.transform 21 8200 env41603 = env41604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env41603 == env41604) = true)

theorem identity41604 : scanCanonicalize (H12AffineFastState.compose env41604 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound41604 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41605 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,293,21795,24861,10280,1025,292,2097152,8200,8248,2114834,8193,16,2103313,5392,2127161,10280,2110781,21792,257,29960,5377,2115344]

theorem envBound41605 : H12AffineFastState.Bounded env41605 := by
  intro p hp
  have h : env41605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41604_41605 : H12AffineEnvironment.transform 15 21795 env41604 = env41605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env41604 == env41605) = true)

theorem identity41605 : scanCanonicalize (H12AffineFastState.compose env41605 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 12345) := by decide +kernel

theorem selectedBound41605 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41606 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,293,21795,24861,10280,1025,292,12345,8200,8248,29995,8193,16,10280,5392,17664,10280,1284,21792,257,29960,5377,30505]

theorem envBound41606 : H12AffineFastState.Bounded env41606 := by
  intro p hp
  have h : env41606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41605_41606 : H12AffineEnvironment.transform 20 12345 env41605 = env41606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12345 env41605 == env41606) = true)

theorem identity41606 : scanCanonicalize (H12AffineFastState.compose env41606 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound41606 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41607 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13608,293,8203,5173,10280,1025,292,12345,8200,8248,3,8193,16,10280,5392,12328,10280,1284,8200,257,32,5377,513]

theorem envBound41607 : H12AffineFastState.Bounded env41607 := by
  intro p hp
  have h : env41607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41606_41607 : H12AffineEnvironment.transform 13 13608 env41606 = env41607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env41606 == env41607) = true)

theorem identity41607 : scanCanonicalize (H12AffineFastState.compose env41607 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound41607 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41608 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,8192,8460,293,8203,17,10280,1025,292,9245,8200,8248,3,8193,16,10280,308,9228,10280,1284,8200,257,32,293,513]

theorem envBound41608 : H12AffineFastState.Bounded env41608 := by
  intro p hp
  have h : env41608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41607_41608 : H12AffineEnvironment.transform 11 1060 env41607 = env41608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env41607 == env41608) = true)

theorem identity41608 : scanCanonicalize (H12AffineFastState.compose env41608 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41608 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41609 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1060,8192,8460,293,8203,17,8233,1025,292,9245,8200,8248,3,8193,16,8233,308,9228,8233,1284,8200,257,32,293,513]

theorem envBound41609 : H12AffineFastState.Bounded env41609 := by
  intro p hp
  have h : env41609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41608_41609 : H12AffineEnvironment.transform 10 1 env41608 = env41609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41608 == env41609) = true)

theorem identity41609 : scanCanonicalize (H12AffineFastState.compose env41609 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41609 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env41610 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,16,8192,8460,293,8203,17,8233,53,292,8233,8200,8248,3,8193,16,8233,308,8248,8233,304,8200,257,32,293,513]

theorem envBound41610 : H12AffineFastState.Bounded env41610 := by
  intro p hp
  have h : env41610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41609_41610 : H12AffineEnvironment.transform 9 52 env41609 = env41610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41609 == env41610) = true)

theorem identity41610 : scanCanonicalize (H12AffineFastState.compose env41610 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41610 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env41611 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,16,269,1,293,262,17,292,53,292,292,261,309,3,268,16,292,308,309,292,304,261,257,32,293,513]

theorem envBound41611 : H12AffineFastState.Bounded env41611 := by
  intro p hp
  have h : env41611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41610_41611 : H12AffineEnvironment.transform 12 269 env41610 = env41611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41610 == env41611) = true)

theorem identity41611 : scanCanonicalize (H12AffineFastState.compose env41611 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41611 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41612 : List Nat := [2,4,8,16,32,16,9,256,49,52,1,16,269,1,293,262,17,292,53,292,292,261,309,3,268,16,292,308,309,292,304,261,257,32,293,48]

theorem envBound41612 : H12AffineFastState.Bounded env41612 := by
  intro p hp
  have h : env41612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41611_41612 : H12AffineEnvironment.transform 8 49 env41611 = env41612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41611 == env41612) = true)

theorem identity41612 : scanCanonicalize (H12AffineFastState.compose env41612 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41612 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env41613 : List Nat := [2,4,8,16,32,16,9,37,49,52,1,16,40,1,0,35,17,1,53,1,1,32,16,3,41,16,1,17,16,1,21,32,36,32,0,48]

theorem envBound41613 : H12AffineFastState.Bounded env41613 := by
  intro p hp
  have h : env41613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41612_41613 : H12AffineEnvironment.transform 7 37 env41612 = env41613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41612 == env41613) = true)

def env41614 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114835,8328,17,15066127,115102,10507520,8691996,10600706,4268162,257,8487358,8478747,10544772]

theorem envBound41614 : H12AffineFastState.Bounded env41614 := by
  intro p hp
  have h : env41614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41591_41614 : H12AffineEnvironment.transform 5 17 env41591 = env41614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41591 == env41614) = true)

def env41615 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2101248,2114835,8328,17,4584463,115102,17664,2404636,119042,4268162,257,2199998,2191387,63108]

theorem envBound41615 : H12AffineFastState.Bounded env41615 := by
  intro p hp
  have h : env41615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41614_41615 : H12AffineEnvironment.transform 22 2101248 env41614 = env41615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101248 env41614 == env41615) = true)

def env41616 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,121999,115102,17664,2404636,119042,329730,257,2199998,2191387,63108]

theorem envBound41616 : H12AffineFastState.Bounded env41616 := by
  intro p hp
  have h : env41616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41615_41616 : H12AffineEnvironment.transform 21 272512 env41615 = env41616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41615 == env41616) = true)

theorem identity41616 : scanCanonicalize (H12AffineFastState.compose env41616 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound41616 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,24860,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,2048,5393,17664,2404636,1421,318605,257,2114865,2139284,63108]

theorem envBound41617 : H12AffineFastState.Bounded env41617 := by
  intro p hp
  have h : env41617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41616_41617 : H12AffineEnvironment.transform 15 54415 env41616 = env41617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env41616 == env41617) = true)

theorem identity41617 : scanCanonicalize (H12AffineFastState.compose env41617 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound41617 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24860,262144,1025,29828,2097152,272512,2101248,2114835,8328,17,2048,5393,17664,2377113,1421,272392,257,2114865,2117649,513]

theorem envBound41618 : H12AffineFastState.Bounded env41618 := by
  intro p hp
  have h : env41618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41617_41618 : H12AffineEnvironment.transform 14 29829 env41617 = env41618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env41617 == env41618) = true)

theorem identity41618 : scanCanonicalize (H12AffineFastState.compose env41618 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound41618 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env41619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24860,262144,1025,29828,281653,272512,285749,264486,8328,17,2048,5393,17664,2476,1421,272392,257,264452,269348,513]

theorem envBound41619 : H12AffineFastState.Bounded env41619 := by
  intro p hp
  have h : env41619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41618_41619 : H12AffineEnvironment.transform 20 281653 env41618 = env41619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env41618 == env41619) = true)

theorem identity41619 : scanCanonicalize (H12AffineFastState.compose env41619 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound41619 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env41620 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,398,16536,262144,1025,21760,281653,264452,285749,264486,268,17,2048,5393,17664,2476,1421,264588,257,264452,269348,513]

theorem envBound41620 : H12AffineFastState.Bounded env41620 := by
  intro p hp
  have h : env41620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41619_41620 : H12AffineEnvironment.transform 12 388 env41619 = env41620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env41619 == env41620) = true)

theorem identity41620 : scanCanonicalize (H12AffineFastState.compose env41620 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound41620 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41621 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,398,16536,23589,1025,21760,4112,21793,16,21763,268,17,2048,5393,17664,2476,1421,21929,257,21793,16385,513]

theorem envBound41621 : H12AffineFastState.Bounded env41621 := by
  intro p hp
  have h : env41621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41620_41621 : H12AffineEnvironment.transform 17 23589 env41620 = env41621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env41620 == env41621) = true)

theorem identity41621 : scanCanonicalize (H12AffineFastState.compose env41621 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound41621 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env41622 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,16384,21676,35,16536,23589,1025,21677,4112,21644,16,21678,161,17,2048,5308,17581,2049,1056,21508,172,21644,16385,513]

theorem envBound41622 : H12AffineFastState.Bounded env41622 := by
  intro p hp
  have h : env41622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41621_41622 : H12AffineEnvironment.transform 7 173 env41621 = env41622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41621 == env41622) = true)

theorem identity41622 : scanCanonicalize (H12AffineFastState.compose env41622 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41622 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41623 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,136,35,5308,2049,1025,137,4112,168,16,138,161,17,2048,5308,4233,2049,1056,32,172,168,5157,513]

theorem envBound41623 : H12AffineFastState.Bounded env41623 := by
  intro p hp
  have h : env41623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41622_41623 : H12AffineEnvironment.transform 13 5156 env41622 = env41623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41622 == env41623) = true)

theorem identity41623 : scanCanonicalize (H12AffineFastState.compose env41623 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41624 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4112,33,16,3,40,17,2048,5173,4096,2049,1056,32,37,33,5157,513]

theorem envBound41624 : H12AffineFastState.Bounded env41624 := by
  intro p hp
  have h : env41624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41623_41624 : H12AffineEnvironment.transform 6 9 env41623 = env41624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41623 == env41624) = true)

theorem identity41624 : scanCanonicalize (H12AffineFastState.compose env41624 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41625 : List Nat := [2,4,8,1,32,0,9,36,512,1024,2048,4096,41,5156,1,35,5156,2049,1025,0,4097,33,1,3,40,0,2048,5156,4096,2049,1056,32,37,33,5157,513]

theorem envBound41625 : H12AffineFastState.Bounded env41625 := by
  intro p hp
  have h : env41625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41624_41625 : H12AffineEnvironment.transform 3 1 env41624 = env41625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41624 == env41625) = true)

theorem identity41625 : scanCanonicalize (H12AffineFastState.compose env41625 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41625 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41626 : List Nat := [2,4,8,1,32,0,9,36,1,1024,2048,4096,41,5156,1,35,5156,2049,1025,0,4097,33,1,3,40,0,2048,5156,4096,2049,1056,32,37,33,5157,0]

theorem envBound41626 : H12AffineFastState.Bounded env41626 := by
  intro p hp
  have h : env41626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41625_41626 : H12AffineEnvironment.transform 8 1 env41625 = env41626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41625 == env41626) = true)

theorem identity41626 : scanCanonicalize (H12AffineFastState.compose env41626 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound41626 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41627 : List Nat := [2,4,8,1,32,0,9,36,1,1024,2048,1060,41,0,1,35,0,2049,1025,0,1061,33,1,3,40,0,2048,0,1060,2049,1056,32,37,33,1,0]

theorem envBound41627 : H12AffineFastState.Bounded env41627 := by
  intro p hp
  have h : env41627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41626_41627 : H12AffineEnvironment.transform 11 1060 env41626 = env41627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env41626 == env41627) = true)

theorem identity41627 : scanCanonicalize (H12AffineFastState.compose env41627 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound41627 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41628 : List Nat := [2,4,8,1,32,0,9,36,1,37,2048,1,41,0,1,35,0,2049,36,0,0,33,1,3,40,0,2048,0,1,2049,5,32,37,33,1,0]

theorem envBound41628 : H12AffineFastState.Bounded env41628 := by
  intro p hp
  have h : env41628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41627_41628 : H12AffineEnvironment.transform 9 37 env41627 = env41628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env41627 == env41628) = true)

theorem identity41628 : scanCanonicalize (H12AffineFastState.compose env41628 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41629 : List Nat := [2,4,8,1,1,0,9,5,1,4,2048,1,8,0,1,2,0,2049,5,0,0,0,1,3,9,0,2048,0,1,2049,5,1,4,0,1,0]

theorem envBound41629 : H12AffineFastState.Bounded env41629 := by
  intro p hp
  have h : env41629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41628_41629 : H12AffineEnvironment.transform 4 1 env41628 = env41629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41628 == env41629) = true)

theorem identity41629 : scanCanonicalize (H12AffineFastState.compose env41629 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41630 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,1,8,0,1,2,0,1,5,0,0,0,1,3,9,0,0,0,1,1,5,1,4,0,1,0]

theorem envBound41630 : H12AffineFastState.Bounded env41630 := by
  intro p hp
  have h : env41630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41629_41630 : H12AffineEnvironment.transform 10 0 env41629 = env41630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41629 == env41630) = true)

def env41631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272513,2101248,2114835,8328,17,121998,115102,17664,2404636,119042,329731,257,2199998,2191387,63108]

theorem envBound41631 : H12AffineFastState.Bounded env41631 := by
  intro p hp
  have h : env41631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41615_41631 : H12AffineEnvironment.transform 21 272513 env41615 = env41631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41615 == env41631) = true)

theorem identity41631 : scanCanonicalize (H12AffineFastState.compose env41631 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound41631 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115870,272513,119966,98701,8328,17,121998,115102,17664,357762,119042,329731,257,21792,46213,63108]

theorem envBound41632 : H12AffineFastState.Bounded env41632 := by
  intro p hp
  have h : env41632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41631_41632 : H12AffineEnvironment.transform 20 115870 env41631 = env41632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env41631 == env41632) = true)

def env41633 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115734,272393,119830,98565,8192,17,121862,114966,17664,357642,119042,329731,257,21792,46093,62988]

theorem envBound41633 : H12AffineFastState.Bounded env41633 := by
  intro p hp
  have h : env41633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41632_41633 : H12AffineEnvironment.transform 6 8 env41632 = env41633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41632 == env41633) = true)

theorem identity41633 : scanCanonicalize (H12AffineFastState.compose env41633 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound41633 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env41634 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24860,262144,1025,8461,91418,272393,95514,73737,8192,17,97546,90138,17664,357642,94222,329731,257,21792,5377,22272]

theorem envBound41634 : H12AffineFastState.Bounded env41634 := by
  intro p hp
  have h : env41634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41633_41634 : H12AffineEnvironment.transform 14 8460 env41633 = env41634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env41633 == env41634) = true)

theorem identity41634 : scanCanonicalize (H12AffineFastState.compose env41634 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound41634 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env41635 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24860,2340,1025,8461,91418,8493,95514,73737,8192,17,97546,90138,17664,97326,94222,65831,257,21792,5377,22272]

theorem envBound41635 : H12AffineFastState.Bounded env41635 := by
  intro p hp
  have h : env41635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41634_41635 : H12AffineEnvironment.transform 17 2340 env41634 = env41635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env41634 == env41635) = true)

theorem identity41635 : scanCanonicalize (H12AffineFastState.compose env41635 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41635 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41636 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8203,24860,2340,1025,8461,17681,8493,21777,2,8192,17,23809,16401,17664,23589,20485,8492,257,21792,5377,22272]

theorem envBound41636 : H12AffineFastState.Bounded env41636 := by
  intro p hp
  have h : env41636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41635_41636 : H12AffineEnvironment.transform 15 8203 env41635 = env41636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41635 == env41636) = true)

theorem identity41636 : scanCanonicalize (H12AffineFastState.compose env41636 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41636 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41637 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8460,8203,5393,2340,1025,8461,12572,8493,8476,2,8192,17,10508,13340,12557,10280,9224,8492,257,8493,5377,8973]

theorem envBound41637 : H12AffineFastState.Bounded env41637 := by
  intro p hp
  have h : env41637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41636_41637 : H12AffineEnvironment.transform 13 13325 env41636 = env41637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41636 == env41637) = true)

theorem identity41637 : scanCanonicalize (H12AffineFastState.compose env41637 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41637 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41638 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4112,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound41638 : H12AffineFastState.Bounded env41638 := by
  intro p hp
  have h : env41638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41637_41638 : H12AffineEnvironment.transform 12 268 env41637 = env41638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41637 == env41638) = true)

theorem identity41638 : scanCanonicalize (H12AffineFastState.compose env41638 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41639 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,35,5173,2048,1025,1,4112,33,16,2,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound41639 : H12AffineFastState.Bounded env41639 := by
  intro p hp
  have h : env41639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41638_41639 : H12AffineEnvironment.transform 7 36 env41638 = env41639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41638 == env41639) = true)

def env41640 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1045,0,35,1029,2048,1025,1,32,33,16,2,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound41640 : H12AffineFastState.Bounded env41640 := by
  intro p hp
  have h : env41640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41639_41640 : H12AffineEnvironment.transform 11 48 env41639 = env41640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env41639 == env41640) = true)

theorem identity41640 : scanCanonicalize (H12AffineFastState.compose env41640 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound41640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41641 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,40,1045,0,35,1029,1077,1025,1,32,33,16,2,40,17,1077,1028,49,1077,1056,32,37,33,1045,513]

theorem envBound41641 : H12AffineFastState.Bounded env41641 := by
  intro p hp
  have h : env41641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41640_41641 : H12AffineEnvironment.transform 10 1077 env41640 = env41641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env41640 == env41641) = true)

def env41642 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,40,33,0,35,49,1,53,1,32,33,16,2,40,17,1,48,49,1,20,32,37,33,33,513]

theorem envBound41642 : H12AffineFastState.Bounded env41642 := by
  intro p hp
  have h : env41642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41641_41642 : H12AffineEnvironment.transform 9 52 env41641 = env41642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41641 == env41642) = true)

theorem identity41642 : scanCanonicalize (H12AffineFastState.compose env41642 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41643 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,8,1,0,3,17,1,21,1,0,1,16,2,8,17,1,16,17,1,20,0,5,1,1,513]

theorem envBound41643 : H12AffineFastState.Bounded env41643 := by
  intro p hp
  have h : env41643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41642_41643 : H12AffineEnvironment.transform 4 0 env41642 = env41643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41642 == env41643) = true)

def leafEnv41643 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,8,1,0,3,17,1,21,1,0,1,16,2,21,8,1,17,1,16,17,1,20,0,5,1,5,3,1,513,1,0,0]

def active41643 : List Nat := [0,1,2,3,8]

def tree41643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41643 : H12WitnessSearch.Good tree41643 := H12GlobalWitnessIndex.good

theorem leafIdentity41643 : H12AffineFastState.composeSystem env41643 rootObs = leafEnv41643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41643 rootObs == leafEnv41643) = true)

theorem terminalChecked41643 : H12PackedTerminal.terminalCheckFast leafEnv41643 active41643 tree41643 = true := by decide +kernel

def env41644 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,32,0,35,48,0,52,1,32,33,16,2,40,17,0,49,49,0,21,32,37,33,32,513]

theorem envBound41644 : H12AffineFastState.Bounded env41644 := by
  intro p hp
  have h : env41644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41641_41644 : H12AffineEnvironment.transform 9 53 env41641 = env41644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41641 == env41644) = true)

theorem identity41644 : scanCanonicalize (H12AffineFastState.compose env41644 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound41644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41645 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,40,32,0,35,48,0,52,1,32,33,16,2,40,17,0,49,49,0,21,32,37,33,32,10]

theorem envBound41645 : H12AffineFastState.Bounded env41645 := by
  intro p hp
  have h : env41645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41644_41645 : H12AffineEnvironment.transform 8 11 env41644 = env41645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env41644 == env41645) = true)

def leafEnv41645 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,40,32,0,35,48,0,52,1,32,33,16,2,20,40,1,17,0,49,49,0,21,32,37,33,5,35,32,10,1,32,0]

def active41645 : List Nat := [0,1,2,3,4]

def tree41645 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41645 : H12WitnessSearch.Good tree41645 := H12GlobalWitnessIndex.good

theorem leafIdentity41645 : H12AffineFastState.composeSystem env41645 rootObs = leafEnv41645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41645 rootObs == leafEnv41645) = true)

theorem terminalChecked41645 : H12PackedTerminal.terminalCheckFast leafEnv41645 active41645 tree41645 = true := by decide +kernel

def env41646 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1044,0,35,1028,2048,1025,1,33,33,16,2,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound41646 : H12AffineFastState.Bounded env41646 := by
  intro p hp
  have h : env41646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41639_41646 : H12AffineEnvironment.transform 11 49 env41639 = env41646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env41639 == env41646) = true)

theorem identity41646 : scanCanonicalize (H12AffineFastState.compose env41646 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41647 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,40,1044,0,35,1028,0,1025,1,33,33,16,2,40,17,0,1029,48,0,1056,32,37,33,1044,513]

theorem envBound41647 : H12AffineFastState.Bounded env41647 := by
  intro p hp
  have h : env41647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41646_41647 : H12AffineEnvironment.transform 10 0 env41646 = env41647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41646 == env41647) = true)

def env41648 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,32,0,35,48,0,53,1,33,33,16,2,40,17,0,49,48,0,20,32,37,33,32,513]

theorem envBound41648 : H12AffineFastState.Bounded env41648 := by
  intro p hp
  have h : env41648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41647_41648 : H12AffineEnvironment.transform 9 52 env41647 = env41648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41647 == env41648) = true)

theorem identity41648 : scanCanonicalize (H12AffineFastState.compose env41648 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41649 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,8,0,0,3,16,0,21,1,1,1,16,2,8,17,0,17,16,0,20,0,5,1,0,513]

theorem envBound41649 : H12AffineFastState.Bounded env41649 := by
  intro p hp
  have h : env41649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41648_41649 : H12AffineEnvironment.transform 4 0 env41648 = env41649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41648 == env41649) = true)

def leafEnv41649 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,8,0,0,3,16,0,21,1,1,1,16,2,21,8,1,17,0,17,16,0,20,0,5,1,5,3,0,513,1,1,0]

def active41649 : List Nat := [0,1,2,3,8]

def tree41649 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41649 : H12WitnessSearch.Good tree41649 := H12GlobalWitnessIndex.good

theorem leafIdentity41649 : H12AffineFastState.composeSystem env41649 rootObs = leafEnv41649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41649 rootObs == leafEnv41649) = true)

theorem terminalChecked41649 : H12PackedTerminal.terminalCheckFast leafEnv41649 active41649 tree41649 = true := by decide +kernel

def env41650 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,40,33,0,35,49,0,52,1,33,33,16,2,40,17,0,48,48,0,21,32,37,33,33,513]

theorem envBound41650 : H12AffineFastState.Bounded env41650 := by
  intro p hp
  have h : env41650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41647_41650 : H12AffineEnvironment.transform 9 53 env41647 = env41650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41647 == env41650) = true)

theorem identity41650 : scanCanonicalize (H12AffineFastState.compose env41650 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound41650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41651 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,40,33,0,35,49,0,52,1,33,33,16,2,40,17,0,48,48,0,21,32,37,33,33,10]

theorem envBound41651 : H12AffineFastState.Bounded env41651 := by
  intro p hp
  have h : env41651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41650_41651 : H12AffineEnvironment.transform 8 11 env41650 = env41651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env41650 == env41651) = true)

def leafEnv41651 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,40,33,0,35,49,0,52,1,33,33,16,2,20,40,1,17,0,48,48,0,21,32,37,33,5,35,33,10,1,33,0]

def active41651 : List Nat := [0,1,2,3,4]

def tree41651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41651 : H12WitnessSearch.Good tree41651 := H12GlobalWitnessIndex.good

theorem leafIdentity41651 : H12AffineFastState.composeSystem env41651 rootObs = leafEnv41651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41651 rootObs == leafEnv41651) = true)

theorem terminalChecked41651 : H12PackedTerminal.terminalCheckFast leafEnv41651 active41651 tree41651 = true := by decide +kernel

def env41652 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115735,272392,119831,98564,8193,17,121863,114967,17664,357643,119042,329731,257,21792,46092,62989]

theorem envBound41652 : H12AffineFastState.Bounded env41652 := by
  intro p hp
  have h : env41652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41632_41652 : H12AffineEnvironment.transform 6 9 env41632 = env41652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41632 == env41652) = true)

theorem identity41652 : scanCanonicalize (H12AffineFastState.compose env41652 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41262) := by decide +kernel

theorem selectedBound41652 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env41653 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41262,24860,262144,1025,32769,25913,272392,30009,8234,8193,17,32041,24633,17664,316453,28716,305453,257,21792,46092,62989]

theorem envBound41653 : H12AffineFastState.Bounded env41653 := by
  intro p hp
  have h : env41653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41652_41653 : H12AffineEnvironment.transform 15 41262 env41652 = env41653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41262 env41652 == env41653) = true)

theorem identity41653 : scanCanonicalize (H12AffineFastState.compose env41653 (packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound41653 : packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env41654 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41262,24860,43048,1025,32769,25913,32800,30009,8234,8193,17,32041,24633,17664,31757,28716,261,257,21792,46092,62989]

theorem envBound41654 : H12AffineFastState.Bounded env41654 := by
  intro p hp
  have h : env41654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41653_41654 : H12AffineEnvironment.transform 17 43048 env41653 = env41654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env41653 == env41654) = true)

theorem identity41654 : scanCanonicalize (H12AffineFastState.compose env41654 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41654 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41655 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,32768,41262,5392,43048,1025,32769,4405,32800,309,8234,8193,17,2341,5173,12556,2049,1056,261,257,8492,46092,33281]

theorem envBound41655 : H12AffineFastState.Bounded env41655 := by
  intro p hp
  have h : env41655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41654_41655 : H12AffineEnvironment.transform 13 13324 env41654 = env41655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41654 == env41655) = true)

theorem identity41655 : scanCanonicalize (H12AffineFastState.compose env41655 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 15373) := by decide +kernel

theorem selectedBound41655 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41656 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,15373,7459,5392,5157,1025,15372,4405,15405,309,8234,8193,17,2341,5173,12556,2049,1056,261,257,8492,2049,15884]

theorem envBound41656 : H12AffineFastState.Bounded env41656 := by
  intro p hp
  have h : env41656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41655_41656 : H12AffineEnvironment.transform 14 15373 env41655 = env41656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15373 env41655 == env41656) = true)

theorem identity41656 : scanCanonicalize (H12AffineFastState.compose env41656 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound41656 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41657 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3385,6453,4404,7459,5392,5157,1025,4405,4405,4372,309,3347,3384,17,2341,5173,7221,2049,1056,261,257,3093,2049,4917]

theorem envBound41657 : H12AffineFastState.Bounded env41657 := by
  intro p hp
  have h : env41657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41656_41657 : H12AffineEnvironment.transform 12 3385 env41656 = env41657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env41656 == env41657) = true)

theorem identity41657 : scanCanonicalize (H12AffineFastState.compose env41657 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41657 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env41658 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,2317,6453,4404,6423,4388,4113,53,4405,4405,4372,309,2343,2316,17,2341,4097,6145,2049,20,261,257,2081,2049,4917]

theorem envBound41658 : H12AffineFastState.Bounded env41658 := by
  intro p hp
  have h : env41658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41657_41658 : H12AffineEnvironment.transform 9 52 env41657 = env41658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41657 == env41658) = true)

theorem identity41658 : scanCanonicalize (H12AffineFastState.compose env41658 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound41658 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env41659 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2065,2317,292,2341,262,2357,2048,53,2340,2340,2309,309,2343,2316,17,2341,2064,16,2049,20,261,257,2081,2049,2852]

theorem envBound41659 : H12AffineFastState.Bounded env41659 := by
  intro p hp
  have h : env41659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41658_41659 : H12AffineEnvironment.transform 11 2065 env41658 = env41659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env41658 == env41659) = true)

theorem identity41659 : scanCanonicalize (H12AffineFastState.compose env41659 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41659 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41660 : List Nat := [2,4,8,1,32,0,9,256,512,37,2048,2048,2317,292,2341,262,2340,2048,36,2340,2340,2309,292,2343,2316,0,2341,2049,1,2049,5,261,257,2081,2049,2852]

theorem envBound41660 : H12AffineFastState.Bounded env41660 := by
  intro p hp
  have h : env41660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41659_41660 : H12AffineEnvironment.transform 3 1 env41659 = env41660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41659 == env41660) = true)

theorem identity41660 : scanCanonicalize (H12AffineFastState.compose env41660 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41660 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env41661 : List Nat := [2,4,8,1,0,0,9,256,512,5,2048,2048,2317,260,2309,262,2308,2048,4,2308,2308,2309,260,2311,2316,0,2309,2049,1,2049,5,261,257,2049,2049,2820]

theorem envBound41661 : H12AffineFastState.Bounded env41661 := by
  intro p hp
  have h : env41661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41660_41661 : H12AffineEnvironment.transform 4 0 env41660 = env41661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41660 == env41661) = true)

theorem identity41661 : scanCanonicalize (H12AffineFastState.compose env41661 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41662 : List Nat := [2,4,8,1,0,0,9,5,512,5,2048,2048,2056,1,2048,3,2049,2048,4,2049,2049,2048,1,2050,2057,0,2048,2049,1,2049,5,0,4,2049,2049,2561]

theorem envBound41662 : H12AffineFastState.Bounded env41662 := by
  intro p hp
  have h : env41662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41661_41662 : H12AffineEnvironment.transform 7 5 env41661 = env41662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41661 == env41662) = true)

theorem identity41662 : scanCanonicalize (H12AffineFastState.compose env41662 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41662 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41663 : List Nat := [2,4,8,1,0,0,9,5,512,5,0,0,8,1,0,3,1,0,4,1,1,0,1,2,9,0,0,1,1,1,5,0,4,1,1,513]

theorem envBound41663 : H12AffineFastState.Bounded env41663 := by
  intro p hp
  have h : env41663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41662_41663 : H12AffineEnvironment.transform 10 0 env41662 = env41663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41662 == env41663) = true)

theorem identity41663 : scanCanonicalize (H12AffineFastState.compose env41663 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound41663 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41664 : List Nat := [2,4,8,1,0,0,9,5,4,5,0,0,8,1,0,3,1,0,4,1,1,0,1,2,9,0,0,1,1,1,5,0,4,1,1,5]

theorem envBound41664 : H12AffineFastState.Bounded env41664 := by
  intro p hp
  have h : env41664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41663_41664 : H12AffineEnvironment.transform 8 4 env41663 = env41664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env41663 == env41664) = true)

theorem identity41664 : scanCanonicalize (H12AffineFastState.compose env41664 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41664 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41665 : List Nat := [2,4,5,1,0,0,4,5,4,5,0,0,5,1,0,3,1,0,4,1,1,0,1,2,4,0,0,1,1,1,5,0,4,1,1,5]

theorem envBound41665 : H12AffineFastState.Bounded env41665 := by
  intro p hp
  have h : env41665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41664_41665 : H12AffineEnvironment.transform 2 5 env41664 = env41665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41664 == env41665) = true)

theorem identity41665 : scanCanonicalize (H12AffineFastState.compose env41665 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41665 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41666 : List Nat := [2,3,2,1,0,0,3,2,3,2,0,0,2,1,0,3,1,0,3,1,1,0,1,2,3,0,0,1,1,1,2,0,3,1,1,2]

theorem envBound41666 : H12AffineFastState.Bounded env41666 := by
  intro p hp
  have h : env41666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41665_41666 : H12AffineEnvironment.transform 1 3 env41665 = env41666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41665 == env41666) = true)

def env41667 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2101249,2114835,8328,17,4584462,115102,17665,2404637,119043,4268162,257,2199999,2191386,63109]

theorem envBound41667 : H12AffineFastState.Bounded env41667 := by
  intro p hp
  have h : env41667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41614_41667 : H12AffineEnvironment.transform 22 2101249 env41614 = env41667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101249 env41614 == env41667) = true)

def env41668 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,121998,115102,17665,2404637,119043,329730,257,2199999,2191386,63109]

theorem envBound41668 : H12AffineFastState.Bounded env41668 := by
  intro p hp
  have h : env41668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41667_41668 : H12AffineEnvironment.transform 21 272512 env41667 = env41668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41667 == env41668) = true)

theorem identity41668 : scanCanonicalize (H12AffineFastState.compose env41668 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41669 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24860,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,64644,57748,17665,2404637,61705,272392,257,2142645,2117648,63109]

theorem envBound41669 : H12AffineFastState.Bounded env41669 := by
  intro p hp
  have h : env41669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41668_41669 : H12AffineEnvironment.transform 15 8202 env41668 = env41669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41668 == env41669) = true)

def env41670 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16828,262144,1025,32769,2097152,264224,2101249,2114835,40,17,56356,49460,17665,2396605,53673,264360,257,2134293,2117648,54821]

theorem envBound41670 : H12AffineFastState.Bounded env41670 := by
  intro p hp
  have h : env41670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41669_41670 : H12AffineEnvironment.transform 12 160 env41669 = env41670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env41669 == env41670) = true)

theorem identity41670 : scanCanonicalize (H12AffineFastState.compose env41670 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound41670 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env41671 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16828,2476,1025,32769,2097152,396,2101249,2114835,40,17,56356,49460,17665,2136081,53673,260,257,2134293,2117648,54821]

theorem envBound41671 : H12AffineFastState.Bounded env41671 := by
  intro p hp
  have h : env41671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41670_41671 : H12AffineEnvironment.transform 17 2476 env41670 = env41671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env41670 == env41671) = true)

theorem identity41671 : scanCanonicalize (H12AffineFastState.compose env41671 (packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound41671 : packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env41672 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5513,32768,170,5173,2476,1025,32769,2097152,396,2101249,2101402,40,17,35245,38077,4232,2136081,33824,260,257,2134293,2098585,33708]

theorem envBound41672 : H12AffineFastState.Bounded env41672 := by
  intro p hp
  have h : env41672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41671_41672 : H12AffineEnvironment.transform 13 5513 env41671 = env41672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env41671 == env41672) = true)

theorem identity41672 : scanCanonicalize (H12AffineFastState.compose env41672 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound41672 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41673 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5513,32768,170,5173,2476,1025,32769,4404,396,309,430,40,17,35245,38077,4232,35109,33824,260,257,32801,5293,33708]

theorem envBound41673 : H12AffineFastState.Bounded env41673 := by
  intro p hp
  have h : env41673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41672_41673 : H12AffineEnvironment.transform 20 4404 env41672 = env41673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env41672 == env41673) = true)

theorem identity41673 : scanCanonicalize (H12AffineFastState.compose env41673 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound41673 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41674 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,160,5156,32768,170,5173,2049,1025,32769,4249,33,152,3,40,17,34816,38077,4232,34952,33824,169,172,32801,5293,33281]

theorem envBound41674 : H12AffineFastState.Bounded env41674 := by
  intro p hp
  have h : env41674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41673_41674 : H12AffineEnvironment.transform 7 173 env41673 = env41674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41673 == env41674) = true)

theorem identity41674 : scanCanonicalize (H12AffineFastState.compose env41674 (packedSelected [0,2,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41674 : packedSelected [0,2,6,9,11] rootPS < 2^1333 := by decide +kernel

def env41675 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,160,5156,5156,170,5173,2049,1025,5157,4249,33,152,3,40,17,7204,153,4232,7340,4100,169,172,5125,5293,5669]

theorem envBound41675 : H12AffineFastState.Bounded env41675 := by
  intro p hp
  have h : env41675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41674_41675 : H12AffineEnvironment.transform 14 5156 env41674 = env41675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5156 env41674 == env41675) = true)

theorem identity41675 : scanCanonicalize (H12AffineFastState.compose env41675 (packedSelected [0,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41675 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env41676 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,4096,160,4112,4112,170,4097,2049,53,4113,4249,33,152,3,40,17,6160,153,4232,6296,4100,169,172,4145,4249,4625]

theorem envBound41676 : H12AffineFastState.Bounded env41676 := by
  intro p hp
  have h : env41676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41675_41676 : H12AffineEnvironment.transform 9 52 env41675 = env41676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41675 == env41676) = true)

theorem identity41676 : scanCanonicalize (H12AffineFastState.compose env41676 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41676 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41677 : List Nat := [2,4,8,16,32,17,128,173,512,52,1,4096,160,4112,4112,170,4097,0,53,4113,4249,33,152,3,40,17,4113,153,4232,4249,4100,169,172,4145,4249,4625]

theorem envBound41677 : H12AffineFastState.Bounded env41677 := by
  intro p hp
  have h : env41677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41676_41677 : H12AffineEnvironment.transform 10 1 env41676 = env41677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41676 == env41677) = true)

theorem identity41677 : scanCanonicalize (H12AffineFastState.compose env41677 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41677 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env41678 : List Nat := [2,4,8,16,32,17,128,173,512,52,1,17,160,1,1,170,16,0,53,0,136,33,152,3,40,17,0,153,153,136,21,169,172,32,136,512]

theorem envBound41678 : H12AffineFastState.Bounded env41678 := by
  intro p hp
  have h : env41678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41677_41678 : H12AffineEnvironment.transform 11 17 env41677 = env41678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41677 == env41678) = true)

theorem identity41678 : scanCanonicalize (H12AffineFastState.compose env41678 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41678 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41679 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,41,1,1,35,16,0,53,0,1,33,17,3,40,17,0,16,16,1,21,32,37,32,1,512]

theorem envBound41679 : H12AffineFastState.Bounded env41679 := by
  intro p hp
  have h : env41679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41678_41679 : H12AffineEnvironment.transform 6 9 env41678 = env41679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41678 == env41679) = true)

theorem identity41679 : scanCanonicalize (H12AffineFastState.compose env41679 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound41679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41680 : List Nat := [2,4,8,16,32,17,9,36,5,52,1,17,41,1,1,35,16,0,53,0,1,33,17,3,40,17,0,16,16,1,21,32,37,32,1,5]

theorem envBound41680 : H12AffineFastState.Bounded env41680 := by
  intro p hp
  have h : env41680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41679_41680 : H12AffineEnvironment.transform 8 5 env41679 = env41680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env41679 == env41680) = true)

theorem identity41680 : scanCanonicalize (H12AffineFastState.compose env41680 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41680 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41681 : List Nat := [2,4,8,7,32,6,9,36,5,35,1,6,41,1,1,35,7,0,34,0,1,33,6,3,40,6,0,7,7,1,2,32,37,32,1,5]

theorem envBound41681 : H12AffineFastState.Bounded env41681 := by
  intro p hp
  have h : env41681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41680_41681 : H12AffineEnvironment.transform 3 7 env41680 = env41681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41680 == env41681) = true)

theorem identity41681 : scanCanonicalize (H12AffineFastState.compose env41681 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41682 : List Nat := [2,4,8,7,6,6,9,2,5,5,1,6,15,1,1,5,7,0,4,0,1,7,6,3,14,6,0,7,7,1,2,6,3,6,1,5]

theorem envBound41682 : H12AffineFastState.Bounded env41682 := by
  intro p hp
  have h : env41682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41681_41682 : H12AffineEnvironment.transform 4 6 env41681 = env41682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41681 == env41682) = true)

theorem identity41682 : scanCanonicalize (H12AffineFastState.compose env41682 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41682 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41683 : List Nat := [2,4,4,7,6,6,5,2,5,5,1,6,3,1,1,5,7,0,4,0,1,7,6,3,2,6,0,7,7,1,2,6,3,6,1,5]

theorem envBound41683 : H12AffineFastState.Bounded env41683 := by
  intro p hp
  have h : env41683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41682_41683 : H12AffineEnvironment.transform 2 4 env41682 = env41683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41682 == env41683) = true)

theorem identity41683 : scanCanonicalize (H12AffineFastState.compose env41683 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41683 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41684 : List Nat := [2,3,3,0,1,1,2,2,2,2,1,1,3,1,1,2,0,0,3,0,1,0,1,3,2,1,0,0,0,1,2,1,3,1,1,2]

theorem envBound41684 : H12AffineFastState.Bounded env41684 := by
  intro p hp
  have h : env41684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41683_41684 : H12AffineEnvironment.transform 1 3 env41683 = env41684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41683 == env41684) = true)

def env41685 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16829,262144,1025,32769,2097152,264225,2101249,2114835,41,17,56357,49461,17665,2396604,53672,264361,257,2134292,2117648,54820]

theorem envBound41685 : H12AffineFastState.Bounded env41685 := by
  intro p hp
  have h : env41685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41669_41685 : H12AffineEnvironment.transform 12 161 env41669 = env41685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env41669 == env41685) = true)

theorem identity41685 : scanCanonicalize (H12AffineFastState.compose env41685 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound41685 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env41686 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16829,2340,1025,32769,2097152,261,2101249,2114835,41,17,56357,49461,17665,2136216,53672,397,257,2134292,2117648,54820]

theorem envBound41686 : H12AffineFastState.Bounded env41686 := by
  intro p hp
  have h : env41686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41685_41686 : H12AffineEnvironment.transform 17 2340 env41685 = env41686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env41685 == env41686) = true)

theorem identity41686 : scanCanonicalize (H12AffineFastState.compose env41686 (packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound41686 : packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS < 2^1333 := by decide +kernel

def env41687 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,428,171,16829,2340,1025,429,2097152,261,2101249,2114835,41,17,23945,16537,17665,2103604,20484,397,257,2101432,2117648,22408]

theorem envBound41687 : H12AffineFastState.Bounded env41687 := by
  intro p hp
  have h : env41687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41686_41687 : H12AffineEnvironment.transform 14 428 env41686 = env41687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env41686 == env41687) = true)

theorem identity41687 : scanCanonicalize (H12AffineFastState.compose env41687 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41687 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env41688 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,16384,136,171,16537,2048,1025,137,2097152,33,2101249,2114615,41,17,23725,16537,17445,2103312,20484,169,37,2101432,2117648,22188]

theorem envBound41688 : H12AffineFastState.Bounded env41688 := by
  intro p hp
  have h : env41688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41687_41688 : H12AffineEnvironment.transform 7 36 env41687 = env41688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41687 == env41688) = true)

theorem identity41688 : scanCanonicalize (H12AffineFastState.compose env41688 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound41688 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41689 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,16384,136,171,16537,2048,1025,137,17596,33,21693,139,41,17,23725,16537,17445,23724,20484,169,37,21508,5292,22188]

theorem envBound41689 : H12AffineFastState.Bounded env41689 := by
  intro p hp
  have h : env41689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41688_41689 : H12AffineEnvironment.transform 20 17596 env41688 = env41689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env41688 == env41689) = true)

theorem identity41689 : scanCanonicalize (H12AffineFastState.compose env41689 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound41689 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41690 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2200,161,16384,136,171,16537,2048,1025,137,17596,33,19493,139,41,17,17461,16537,17445,17460,18588,169,37,19612,3124,20020]

theorem envBound41690 : H12AffineFastState.Bounded env41690 := by
  intro p hp
  have h : env41690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41689_41690 : H12AffineEnvironment.transform 11 2200 env41689 = env41690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env41689 == env41690) = true)

theorem identity41690 : scanCanonicalize (H12AffineFastState.compose env41690 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound41690 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41691 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2200,161,3125,136,171,3244,2048,1025,137,2185,33,16,139,41,17,2048,3244,2064,2049,1193,169,37,169,3124,513]

theorem envBound41691 : H12AffineFastState.Bounded env41691 := by
  intro p hp
  have h : env41691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41690_41691 : H12AffineEnvironment.transform 13 3125 env41690 = env41691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env41690 == env41691) = true)

theorem identity41691 : scanCanonicalize (H12AffineFastState.compose env41691 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41691 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41692 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,2200,161,2048,136,171,2201,2048,52,137,2185,33,16,139,41,17,2048,2201,2064,2049,156,169,37,169,2049,513]

theorem envBound41692 : H12AffineFastState.Bounded env41692 := by
  intro p hp
  have h : env41692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41691_41692 : H12AffineEnvironment.transform 9 53 env41691 = env41692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41691 == env41692) = true)

theorem identity41692 : scanCanonicalize (H12AffineFastState.compose env41692 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41692 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41693 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2065,40,2048,1,34,2064,2048,52,0,2048,33,16,2,41,17,2048,2064,2064,2049,21,32,37,32,2049,513]

theorem envBound41693 : H12AffineFastState.Bounded env41693 := by
  intro p hp
  have h : env41693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41692_41693 : H12AffineEnvironment.transform 6 9 env41692 = env41693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41692 == env41693) = true)

theorem identity41693 : scanCanonicalize (H12AffineFastState.compose env41693 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 564) := by decide +kernel

theorem selectedBound41693 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41694 : List Nat := [2,4,8,16,32,17,9,36,512,53,564,549,40,564,1,34,548,564,52,0,564,33,16,2,41,17,564,548,548,565,21,32,37,32,565,513]

theorem envBound41694 : H12AffineFastState.Bounded env41694 := by
  intro p hp
  have h : env41694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41693_41694 : H12AffineEnvironment.transform 10 564 env41693 = env41694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 564 env41693 == env41694) = true)

theorem identity41694 : scanCanonicalize (H12AffineFastState.compose env41694 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41695 : List Nat := [2,4,8,12,32,13,9,36,512,41,552,549,40,552,1,34,548,552,40,0,552,33,12,2,41,13,552,548,548,553,9,32,37,32,553,513]

theorem envBound41695 : H12AffineFastState.Bounded env41695 := by
  intro p hp
  have h : env41695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41694_41695 : H12AffineEnvironment.transform 3 12 env41694 = env41695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41694 == env41695) = true)

theorem identity41695 : scanCanonicalize (H12AffineFastState.compose env41695 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound41695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41696 : List Nat := [2,4,8,12,32,13,9,36,41,41,1,12,40,1,1,34,13,1,40,0,1,33,12,2,41,13,1,13,13,0,9,32,37,32,0,40]

theorem envBound41696 : H12AffineFastState.Bounded env41696 := by
  intro p hp
  have h : env41696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41695_41696 : H12AffineEnvironment.transform 8 41 env41695 = env41696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env41695 == env41696) = true)

theorem identity41696 : scanCanonicalize (H12AffineFastState.compose env41696 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound41696 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41697 : List Nat := [2,4,8,12,2,13,9,6,11,11,1,12,10,1,1,0,13,1,10,0,1,3,12,2,11,13,1,13,13,0,9,2,7,2,0,10]

theorem envBound41697 : H12AffineFastState.Bounded env41697 := by
  intro p hp
  have h : env41697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41696_41697 : H12AffineEnvironment.transform 4 2 env41696 = env41697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env41696 == env41697) = true)

theorem identity41697 : scanCanonicalize (H12AffineFastState.compose env41697 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41697 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41698 : List Nat := [1,4,8,12,1,13,9,5,8,8,1,12,9,1,1,0,13,1,9,0,1,0,12,1,8,13,1,13,13,0,9,1,4,1,0,9]

theorem envBound41698 : H12AffineFastState.Bounded env41698 := by
  intro p hp
  have h : env41698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41697_41698 : H12AffineEnvironment.transform 0 1 env41697 = env41698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41697 == env41698) = true)

def env41699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272513,2101249,2114835,8328,17,121999,115102,17665,2404637,119043,329731,257,2199999,2191386,63109]

theorem envBound41699 : H12AffineFastState.Bounded env41699 := by
  intro p hp
  have h : env41699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41667_41699 : H12AffineEnvironment.transform 21 272513 env41667 = env41699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41667 == env41699) = true)

theorem identity41699 : scanCanonicalize (H12AffineFastState.compose env41699 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77850) := by decide +kernel

theorem selectedBound41699 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121999,115102,17665,360711,119043,329731,257,41381,16384,63109]

theorem envBound41700 : H12AffineFastState.Bounded env41700 := by
  intro p hp
  have h : env41700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41699_41700 : H12AffineEnvironment.transform 20 77850 env41699 = env41700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77850 env41699 == env41700) = true)

def env41701 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121999,115102,17665,360711,119043,329731,257,41349,16384,63109]

theorem envBound41701 : H12AffineFastState.Bounded env41701 := by
  intro p hp
  have h : env41701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41700_41701 : H12AffineEnvironment.transform 4 0 env41700 = env41701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41700 == env41701) = true)

theorem identity41701 : scanCanonicalize (H12AffineFastState.compose env41701 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 2308) := by decide +kernel

theorem selectedBound41701 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env41702 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,2308,1025,32769,77850,8581,73755,95497,8328,17,121999,115102,17665,100355,119043,65799,257,41349,16384,63109]

theorem envBound41702 : H12AffineFastState.Bounded env41702 := by
  intro p hp
  have h : env41702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41701_41702 : H12AffineEnvironment.transform 17 2308 env41701 = env41702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2308 env41701 == env41702) = true)

theorem identity41702 : scanCanonicalize (H12AffineFastState.compose env41702 (packedSelected [1,2,3,4,6,7,9,16,19,20,24,26,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41702 : packedSelected [1,2,3,4,6,7,9,16,19,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env41703 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,2308,1025,32769,77850,8461,73755,95497,8192,17,121863,114966,17665,100355,119043,65799,257,41229,16384,62989]

theorem envBound41703 : H12AffineFastState.Bounded env41703 := by
  intro p hp
  have h : env41703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41702_41703 : H12AffineEnvironment.transform 6 8 env41702 = env41703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41702 == env41703) = true)

theorem identity41703 : scanCanonicalize (H12AffineFastState.compose env41703 (packedSelected [1,2,4,6,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound41703 : packedSelected [1,2,4,6,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env41704 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24860,2308,1025,8461,77850,8461,73755,95497,8192,17,97547,90138,17665,76047,94223,65799,257,1,16384,22273]

theorem envBound41704 : H12AffineFastState.Bounded env41704 := by
  intro p hp
  have h : env41704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41703_41704 : H12AffineEnvironment.transform 14 8460 env41703 = env41704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env41703 == env41704) = true)

theorem identity41704 : scanCanonicalize (H12AffineFastState.compose env41704 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound41704 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env41705 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8460,21511,24860,2308,1025,8461,25629,8461,29724,8462,8192,17,10508,13341,17665,32008,9224,21760,257,1,16384,22273]

theorem envBound41705 : H12AffineFastState.Bounded env41705 := by
  intro p hp
  have h : env41705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41704_41705 : H12AffineEnvironment.transform 15 21511 env41704 = env41705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env41704 == env41705) = true)

theorem identity41705 : scanCanonicalize (H12AffineFastState.compose env41705 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41706 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,16384,0,21511,16400,2308,1025,1,17681,1,21776,2,268,17,2048,5393,17665,23556,1284,21760,257,1,16384,22273]

theorem envBound41706 : H12AffineFastState.Bounded env41706 := by
  intro p hp
  have h : env41706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41705_41706 : H12AffineEnvironment.transform 12 268 env41705 = env41706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41705 == env41706) = true)

theorem identity41706 : scanCanonicalize (H12AffineFastState.compose env41706 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41706 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41707 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2308,1025,1,4113,1,16,2,268,17,2048,5393,4097,2308,1284,0,257,1,5376,513]

theorem envBound41707 : H12AffineFastState.Bounded env41707 := by
  intro p hp
  have h : env41707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41706_41707 : H12AffineEnvironment.transform 13 5376 env41706 = env41707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41706 == env41707) = true)

theorem identity41707 : scanCanonicalize (H12AffineFastState.compose env41707 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41708 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,0,2,5141,2049,1025,1,4113,1,16,2,9,17,2048,5140,4097,2049,1025,0,4,1,5125,513]

theorem envBound41708 : H12AffineFastState.Bounded env41708 := by
  intro p hp
  have h : env41708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41707_41708 : H12AffineEnvironment.transform 7 5 env41707 = env41708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41707 == env41708) = true)

def env41709 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,0,2,1029,2049,1025,1,1,1,16,2,9,17,2048,1028,17,2049,1025,0,4,1,1045,513]

theorem envBound41709 : H12AffineFastState.Bounded env41709 := by
  intro p hp
  have h : env41709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41708_41709 : H12AffineEnvironment.transform 11 16 env41708 = env41709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41708 == env41709) = true)

theorem identity41709 : scanCanonicalize (H12AffineFastState.compose env41709 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound41709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41710 : List Nat := [2,4,8,16,0,17,8,5,16,1024,2048,16,9,1045,0,2,1029,2049,1025,1,1,1,16,2,9,17,2048,1028,17,2049,1025,0,4,1,1045,17]

theorem envBound41710 : H12AffineFastState.Bounded env41710 := by
  intro p hp
  have h : env41710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41709_41710 : H12AffineEnvironment.transform 8 16 env41709 = env41710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41709 == env41710) = true)

def env41711 : List Nat := [2,4,8,16,0,17,8,5,16,20,2048,16,9,1,0,2,17,2049,21,1,1,1,16,2,9,17,2048,16,17,2049,21,0,4,1,1,17]

theorem envBound41711 : H12AffineFastState.Bounded env41711 := by
  intro p hp
  have h : env41711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41710_41711 : H12AffineEnvironment.transform 9 20 env41710 = env41711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41710 == env41711) = true)

theorem identity41711 : scanCanonicalize (H12AffineFastState.compose env41711 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41712 : List Nat := [2,4,8,16,0,17,8,5,16,20,1,16,9,1,0,2,17,0,21,1,1,1,16,2,9,17,1,16,17,0,21,0,4,1,1,17]

theorem envBound41712 : H12AffineFastState.Bounded env41712 := by
  intro p hp
  have h : env41712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41711_41712 : H12AffineEnvironment.transform 10 1 env41711 = env41712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41711 == env41712) = true)

def leafEnv41712 : List Nat := [2,4,8,16,0,17,8,5,16,20,1,16,9,1,0,2,17,0,21,1,1,1,16,2,20,9,1,17,1,16,17,0,21,0,4,1,5,2,1,17,1,1,0]

def active41712 : List Nat := [0,1,2,3]

def tree41712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41712 : H12WitnessSearch.Good tree41712 := H12GlobalWitnessIndex.good

theorem leafIdentity41712 : H12AffineFastState.composeSystem env41712 rootObs = leafEnv41712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41712 rootObs == leafEnv41712) = true)

theorem terminalChecked41712 : H12PackedTerminal.terminalCheckFast leafEnv41712 active41712 tree41712 = true := by decide +kernel

def env41713 : List Nat := [2,4,8,16,0,17,8,5,16,21,2048,16,9,0,0,2,16,2049,20,1,1,1,16,2,9,17,2048,17,17,2049,20,0,4,1,0,17]

theorem envBound41713 : H12AffineFastState.Bounded env41713 := by
  intro p hp
  have h : env41713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41710_41713 : H12AffineEnvironment.transform 9 21 env41710 = env41713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41710 == env41713) = true)

theorem identity41713 : scanCanonicalize (H12AffineFastState.compose env41713 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41714 : List Nat := [2,4,8,16,0,17,8,5,16,21,26,16,9,0,0,2,16,27,20,1,1,1,16,2,9,17,26,17,17,27,20,0,4,1,0,17]

theorem envBound41714 : H12AffineFastState.Bounded env41714 := by
  intro p hp
  have h : env41714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41713_41714 : H12AffineEnvironment.transform 10 26 env41713 = env41714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41713 == env41714) = true)

def leafEnv41714 : List Nat := [2,4,8,16,0,17,8,5,16,21,26,16,9,0,0,2,16,27,20,1,1,1,16,2,21,9,1,17,26,17,17,27,20,0,4,1,5,2,0,17,1,1,0]

def active41714 : List Nat := [0,1,2,3]

def tree41714 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41714 : H12WitnessSearch.Good tree41714 := H12GlobalWitnessIndex.good

theorem leafIdentity41714 : H12AffineFastState.composeSystem env41714 rootObs = leafEnv41714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41714 rootObs == leafEnv41714) = true)

theorem terminalChecked41714 : H12PackedTerminal.terminalCheckFast leafEnv41714 active41714 tree41714 = true := by decide +kernel

def env41715 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,0,2,1028,2049,1025,1,0,1,16,2,9,17,2048,1029,16,2049,1025,0,4,1,1044,513]

theorem envBound41715 : H12AffineFastState.Bounded env41715 := by
  intro p hp
  have h : env41715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41708_41715 : H12AffineEnvironment.transform 11 17 env41708 = env41715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41708 == env41715) = true)

theorem identity41715 : scanCanonicalize (H12AffineFastState.compose env41715 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound41715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41716 : List Nat := [2,4,8,16,0,17,8,5,512,517,2048,17,9,529,0,2,513,2049,516,1,0,1,16,2,9,17,2048,512,16,2049,516,0,4,1,529,513]

theorem envBound41716 : H12AffineFastState.Bounded env41716 := by
  intro p hp
  have h : env41716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41715_41716 : H12AffineEnvironment.transform 9 517 env41715 = env41716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env41715 == env41716) = true)

def env41717 : List Nat := [2,4,8,16,0,17,8,5,16,21,2048,17,9,1,0,2,17,2049,20,1,0,1,16,2,9,17,2048,16,16,2049,20,0,4,1,1,17]

theorem envBound41717 : H12AffineFastState.Bounded env41717 := by
  intro p hp
  have h : env41717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41716_41717 : H12AffineEnvironment.transform 8 16 env41716 = env41717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41716 == env41717) = true)

theorem identity41717 : scanCanonicalize (H12AffineFastState.compose env41717 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41717 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41718 : List Nat := [2,4,8,16,0,17,8,5,16,21,26,17,9,1,0,2,17,27,20,1,0,1,16,2,9,17,26,16,16,27,20,0,4,1,1,17]

theorem envBound41718 : H12AffineFastState.Bounded env41718 := by
  intro p hp
  have h : env41718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41717_41718 : H12AffineEnvironment.transform 10 26 env41717 = env41718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41717 == env41718) = true)

def leafEnv41718 : List Nat := [2,4,8,16,0,17,8,5,16,21,26,17,9,1,0,2,17,27,20,1,0,1,16,2,21,9,1,17,26,16,16,27,20,0,4,1,5,2,1,17,1,0,0]

def active41718 : List Nat := [0,1,2,3]

def tree41718 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41718 : H12WitnessSearch.Good tree41718 := H12GlobalWitnessIndex.good

theorem leafIdentity41718 : H12AffineFastState.composeSystem env41718 rootObs = leafEnv41718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41718 rootObs == leafEnv41718) = true)

theorem terminalChecked41718 : H12PackedTerminal.terminalCheckFast leafEnv41718 active41718 tree41718 = true := by decide +kernel

def env41719 : List Nat := [2,4,8,16,0,17,8,5,17,20,2048,17,9,0,0,2,16,2049,21,1,0,1,16,2,9,17,2048,17,16,2049,21,0,4,1,0,16]

theorem envBound41719 : H12AffineFastState.Bounded env41719 := by
  intro p hp
  have h : env41719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41716_41719 : H12AffineEnvironment.transform 8 17 env41716 = env41719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41716 == env41719) = true)

theorem identity41719 : scanCanonicalize (H12AffineFastState.compose env41719 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41720 : List Nat := [2,4,8,16,0,17,8,5,17,20,0,17,9,0,0,2,16,1,21,1,0,1,16,2,9,17,0,17,16,1,21,0,4,1,0,16]

theorem envBound41720 : H12AffineFastState.Bounded env41720 := by
  intro p hp
  have h : env41720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41719_41720 : H12AffineEnvironment.transform 10 0 env41719 = env41720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41719 == env41720) = true)

def leafEnv41720 : List Nat := [2,4,8,16,0,17,8,5,17,20,0,17,9,0,0,2,16,1,21,1,0,1,16,2,20,9,1,17,0,17,16,1,21,0,4,1,5,2,0,16,1,0,0]

def active41720 : List Nat := [0,1,2,3]

def tree41720 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41720 : H12WitnessSearch.Good tree41720 := H12GlobalWitnessIndex.good

theorem leafIdentity41720 : H12AffineFastState.composeSystem env41720 rootObs = leafEnv41720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41720 rootObs == leafEnv41720) = true)

theorem terminalChecked41720 : H12PackedTerminal.terminalCheckFast leafEnv41720 active41720 tree41720 = true := by decide +kernel

def env41721 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121999,115102,17665,360711,119043,329731,257,41348,16384,63109]

theorem envBound41721 : H12AffineFastState.Bounded env41721 := by
  intro p hp
  have h : env41721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41700_41721 : H12AffineEnvironment.transform 4 1 env41700 = env41721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41700 == env41721) = true)

theorem identity41721 : scanCanonicalize (H12AffineFastState.compose env41721 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64897) := by decide +kernel

theorem selectedBound41721 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env41722 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,64897,1025,32769,77850,54528,73755,95497,8328,17,121999,115102,17665,97414,119043,128386,257,41348,16384,63109]

theorem envBound41722 : H12AffineFastState.Bounded env41722 := by
  intro p hp
  have h : env41722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41721_41722 : H12AffineEnvironment.transform 17 64897 env41721 = env41722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64897 env41721 == env41722) = true)

theorem identity41722 : scanCanonicalize (H12AffineFastState.compose env41722 (packedSelected [2,3,5,6,8,17,19,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41722 : packedSelected [2,3,5,6,8,17,19,26,28] rootPS < 2^1333 := by decide +kernel

def env41723 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,24860,64897,1025,32769,4113,54528,16,21762,8328,17,64644,57749,17665,23693,61704,54665,257,41348,16384,63109]

theorem envBound41723 : H12AffineFastState.Bounded env41723 := by
  intro p hp
  have h : env41723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41722_41723 : H12AffineEnvironment.transform 15 8203 env41722 = env41723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41722 == env41723) = true)

theorem identity41723 : scanCanonicalize (H12AffineFastState.compose env41723 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound41723 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env41724 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8460,8203,24860,23693,1025,8461,4113,29708,16,21762,8328,17,23944,16537,17665,23693,20484,29829,257,136,16384,22409]

theorem envBound41724 : H12AffineFastState.Bounded env41724 := by
  intro p hp
  have h : env41724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41723_41724 : H12AffineEnvironment.transform 14 8460 env41723 = env41724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env41723 == env41724) = true)

theorem identity41724 : scanCanonicalize (H12AffineFastState.compose env41724 (packedSelected [3,4,5,6,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41724 : packedSelected [3,4,5,6,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env41725 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,13324,8460,8203,5392,10369,1025,8461,4113,0,16,8462,8328,17,10628,13461,12557,10369,9224,137,257,136,13324,9093]

theorem envBound41725 : H12AffineFastState.Bounded env41725 := by
  intro p hp
  have h : env41725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41724_41725 : H12AffineEnvironment.transform 13 13324 env41724 = env41725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41724 == env41725) = true)

theorem identity41725 : scanCanonicalize (H12AffineFastState.compose env41725 (packedSelected [0,1,4,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41725 : packedSelected [0,1,4,8,12] rootPS < 2^1333 := by decide +kernel

def env41726 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,8192,13324,8460,8203,5392,10249,1025,8461,4113,0,16,8462,8192,17,10508,13341,12557,10249,9224,1,257,0,13324,8973]

theorem envBound41726 : H12AffineFastState.Bounded env41726 := by
  intro p hp
  have h : env41726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41725_41726 : H12AffineEnvironment.transform 6 8 env41725 = env41726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41725 == env41726) = true)

theorem identity41726 : scanCanonicalize (H12AffineFastState.compose env41726 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41726 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41727 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2309,1025,1,4113,0,16,2,268,17,2048,5393,4097,2309,1284,1,257,0,5376,513]

theorem envBound41727 : H12AffineFastState.Bounded env41727 := by
  intro p hp
  have h : env41727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41726_41727 : H12AffineEnvironment.transform 12 268 env41726 = env41727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41726 == env41727) = true)

theorem identity41727 : scanCanonicalize (H12AffineFastState.compose env41727 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41728 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5124,0,3,5140,2049,1025,1,4113,0,16,2,8,17,2048,5141,4097,2049,1024,1,5,0,5124,513]

theorem envBound41728 : H12AffineFastState.Bounded env41728 := by
  intro p hp
  have h : env41728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41727_41728 : H12AffineEnvironment.transform 7 4 env41727 = env41728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41727 == env41728) = true)

def env41729 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,16,8,1044,0,3,1028,2049,1025,1,1,0,16,2,8,17,2048,1029,17,2049,1024,1,5,0,1044,513]

theorem envBound41729 : H12AffineFastState.Bounded env41729 := by
  intro p hp
  have h : env41729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41728_41729 : H12AffineEnvironment.transform 11 16 env41728 = env41729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41728 == env41729) = true)

theorem identity41729 : scanCanonicalize (H12AffineFastState.compose env41729 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound41729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41730 : List Nat := [2,4,8,16,1,17,8,4,512,516,2048,16,8,528,0,3,512,2049,517,1,1,0,16,2,8,17,2048,513,17,2049,516,1,5,0,528,513]

theorem envBound41730 : H12AffineFastState.Bounded env41730 := by
  intro p hp
  have h : env41730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41729_41730 : H12AffineEnvironment.transform 9 516 env41729 = env41730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env41729 == env41730) = true)

def env41731 : List Nat := [2,4,8,16,1,17,8,4,16,20,2048,16,8,0,0,3,16,2049,21,1,1,0,16,2,8,17,2048,17,17,2049,20,1,5,0,0,17]

theorem envBound41731 : H12AffineFastState.Bounded env41731 := by
  intro p hp
  have h : env41731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41730_41731 : H12AffineEnvironment.transform 8 16 env41730 = env41731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41730 == env41731) = true)

theorem identity41731 : scanCanonicalize (H12AffineFastState.compose env41731 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41732 : List Nat := [2,4,8,16,1,17,8,4,16,20,26,16,8,0,0,3,16,27,21,1,1,0,16,2,8,17,26,17,17,27,20,1,5,0,0,17]

theorem envBound41732 : H12AffineFastState.Bounded env41732 := by
  intro p hp
  have h : env41732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41731_41732 : H12AffineEnvironment.transform 10 26 env41731 = env41732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41731 == env41732) = true)

def leafEnv41732 : List Nat := [2,4,8,16,1,17,8,4,16,20,26,16,8,0,0,3,16,27,21,1,1,0,16,2,21,8,1,17,26,17,17,27,20,1,5,0,5,3,0,17,1,1,0]

def active41732 : List Nat := [0,1,2,3]

def tree41732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41732 : H12WitnessSearch.Good tree41732 := H12GlobalWitnessIndex.good

theorem leafIdentity41732 : H12AffineFastState.composeSystem env41732 rootObs = leafEnv41732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41732 rootObs == leafEnv41732) = true)

theorem terminalChecked41732 : H12PackedTerminal.terminalCheckFast leafEnv41732 active41732 tree41732 = true := by decide +kernel

def env41733 : List Nat := [2,4,8,16,1,17,8,4,17,21,2048,16,8,1,0,3,17,2049,20,1,1,0,16,2,8,17,2048,16,17,2049,21,1,5,0,1,16]

theorem envBound41733 : H12AffineFastState.Bounded env41733 := by
  intro p hp
  have h : env41733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41730_41733 : H12AffineEnvironment.transform 8 17 env41730 = env41733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41730 == env41733) = true)

theorem identity41733 : scanCanonicalize (H12AffineFastState.compose env41733 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41733 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41734 : List Nat := [2,4,8,16,1,17,8,4,17,21,1,16,8,1,0,3,17,0,20,1,1,0,16,2,8,17,1,16,17,0,21,1,5,0,1,16]

theorem envBound41734 : H12AffineFastState.Bounded env41734 := by
  intro p hp
  have h : env41734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41733_41734 : H12AffineEnvironment.transform 10 1 env41733 = env41734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41733 == env41734) = true)

def leafEnv41734 : List Nat := [2,4,8,16,1,17,8,4,17,21,1,16,8,1,0,3,17,0,20,1,1,0,16,2,20,8,1,17,1,16,17,0,21,1,5,0,5,3,1,16,1,1,0]

def active41734 : List Nat := [0,1,2,3]

def tree41734 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41734 : H12WitnessSearch.Good tree41734 := H12GlobalWitnessIndex.good

theorem leafIdentity41734 : H12AffineFastState.composeSystem env41734 rootObs = leafEnv41734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41734 rootObs == leafEnv41734) = true)

theorem terminalChecked41734 : H12PackedTerminal.terminalCheckFast leafEnv41734 active41734 tree41734 = true := by decide +kernel

def env41735 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,17,8,1045,0,3,1029,2049,1025,1,0,0,16,2,8,17,2048,1028,16,2049,1024,1,5,0,1045,513]

theorem envBound41735 : H12AffineFastState.Bounded env41735 := by
  intro p hp
  have h : env41735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41728_41735 : H12AffineEnvironment.transform 11 17 env41728 = env41735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41728 == env41735) = true)

theorem identity41735 : scanCanonicalize (H12AffineFastState.compose env41735 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound41735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41736 : List Nat := [2,4,8,16,1,17,8,4,16,1024,2048,17,8,1045,0,3,1029,2049,1025,1,0,0,16,2,8,17,2048,1028,16,2049,1024,1,5,0,1045,17]

theorem envBound41736 : H12AffineFastState.Bounded env41736 := by
  intro p hp
  have h : env41736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41735_41736 : H12AffineEnvironment.transform 8 16 env41735 = env41736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41735 == env41736) = true)

def env41737 : List Nat := [2,4,8,16,1,17,8,4,16,20,2048,17,8,1,0,3,17,2049,21,1,0,0,16,2,8,17,2048,16,16,2049,20,1,5,0,1,17]

theorem envBound41737 : H12AffineFastState.Bounded env41737 := by
  intro p hp
  have h : env41737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41736_41737 : H12AffineEnvironment.transform 9 20 env41736 = env41737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41736 == env41737) = true)

theorem identity41737 : scanCanonicalize (H12AffineFastState.compose env41737 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41738 : List Nat := [2,4,8,16,1,17,8,4,16,20,26,17,8,1,0,3,17,27,21,1,0,0,16,2,8,17,26,16,16,27,20,1,5,0,1,17]

theorem envBound41738 : H12AffineFastState.Bounded env41738 := by
  intro p hp
  have h : env41738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41737_41738 : H12AffineEnvironment.transform 10 26 env41737 = env41738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41737 == env41738) = true)

def leafEnv41738 : List Nat := [2,4,8,16,1,17,8,4,16,20,26,17,8,1,0,3,17,27,21,1,0,0,16,2,21,8,1,17,26,16,16,27,20,1,5,0,5,3,1,17,1,0,0]

def active41738 : List Nat := [0,1,2,3]

def tree41738 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41738 : H12WitnessSearch.Good tree41738 := H12GlobalWitnessIndex.good

theorem leafIdentity41738 : H12AffineFastState.composeSystem env41738 rootObs = leafEnv41738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41738 rootObs == leafEnv41738) = true)

theorem terminalChecked41738 : H12PackedTerminal.terminalCheckFast leafEnv41738 active41738 tree41738 = true := by decide +kernel

def env41739 : List Nat := [2,4,8,16,1,17,8,4,16,21,2048,17,8,0,0,3,16,2049,20,1,0,0,16,2,8,17,2048,17,16,2049,21,1,5,0,0,17]

theorem envBound41739 : H12AffineFastState.Bounded env41739 := by
  intro p hp
  have h : env41739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41736_41739 : H12AffineEnvironment.transform 9 21 env41736 = env41739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41736 == env41739) = true)

theorem identity41739 : scanCanonicalize (H12AffineFastState.compose env41739 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41739 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41740 : List Nat := [2,4,8,16,1,17,8,4,16,21,0,17,8,0,0,3,16,1,20,1,0,0,16,2,8,17,0,17,16,1,21,1,5,0,0,17]

theorem envBound41740 : H12AffineFastState.Bounded env41740 := by
  intro p hp
  have h : env41740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41739_41740 : H12AffineEnvironment.transform 10 0 env41739 = env41740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41739 == env41740) = true)

def leafEnv41740 : List Nat := [2,4,8,16,1,17,8,4,16,21,0,17,8,0,0,3,16,1,20,1,0,0,16,2,20,8,1,17,0,17,16,1,21,1,5,0,5,3,0,17,1,0,0]

def active41740 : List Nat := [0,1,2,3]

def tree41740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41740 : H12WitnessSearch.Good tree41740 := H12GlobalWitnessIndex.good

theorem leafIdentity41740 : H12AffineFastState.composeSystem env41740 rootObs = leafEnv41740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41740 rootObs == leafEnv41740) = true)

theorem terminalChecked41740 : H12PackedTerminal.terminalCheckFast leafEnv41740 active41740 tree41740 = true := by decide +kernel

def env41741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound41741 : H12AffineFastState.Bounded env41741 := by
  intro p hp
  have h : env41741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41012_41741 : H12AffineEnvironment.transform 25 65 env41012 = env41741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env41012 == env41741) = true)

def env41742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound41742 : H12AffineFastState.Bounded env41742 := by
  intro p hp
  have h : env41742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41741_41742 : H12AffineEnvironment.transform 26 30393344 env41741 = env41742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env41741 == env41742) = true)

def env41743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound41743 : H12AffineFastState.Bounded env41743 := by
  intro p hp
  have h : env41743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41742_41743 : H12AffineEnvironment.transform 18 1024 env41742 = env41743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env41742 == env41743) = true)

theorem identity41743 : scanCanonicalize (H12AffineFastState.compose env41743 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound41743 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403502,18973836,10507600,8497518,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound41744 : H12AffineFastState.Bounded env41744 := by
  intro p hp
  have h : env41744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41743_41744 : H12AffineEnvironment.transform 17 223598 env41743 = env41744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env41743 == env41744) = true)

def env41745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760178,5392,10507600,8497518,10491276,4256861,256,8410417,8434836,10564187]

theorem envBound41745 : H12AffineFastState.Bounded env41745 := by
  intro p hp
  have h : env41745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41744_41745 : H12AffineEnvironment.transform 23 2199964 env41744 = env41745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env41744 == env41745) = true)

def env41746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270242,5392,17664,2210110,1500,4256861,256,2114913,2139332,74251]

theorem envBound41746 : H12AffineFastState.Bounded env41746 := by
  intro p hp
  have h : env41746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41745_41746 : H12AffineEnvironment.transform 22 2101328 env41745 = env41746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env41745 == env41746) = true)

def env41747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98780,8328,65,4270242,5392,17664,108926,1500,4256861,256,21793,46212,74251]

theorem envBound41747 : H12AffineFastState.Bounded env41747 := by
  intro p hp
  have h : env41747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41746_41747 : H12AffineEnvironment.transform 20 4160 env41746 = env41747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41746 == env41747) = true)

def env41748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98644,8192,65,4270122,5392,17664,108926,1364,4256861,256,21793,46092,74251]

theorem envBound41748 : H12AffineFastState.Bounded env41748 := by
  intro p hp
  have h : env41748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41747_41748 : H12AffineEnvironment.transform 6 8 env41747 = env41748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41747 == env41748) = true)

theorem identity41748 : scanCanonicalize (H12AffineFastState.compose env41748 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound41748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,4194304,16,98644,8192,65,4270122,5392,17664,108926,1364,4256861,256,21793,46092,74251]

theorem envBound41749 : H12AffineFastState.Bounded env41749 := by
  intro p hp
  have h : env41749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41748_41749 : H12AffineEnvironment.transform 16 82246 env41748 = env41749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env41748 == env41749) = true)

theorem identity41749 : scanCanonicalize (H12AffineFastState.compose env41749 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound41749 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,8573,16,98644,8192,65,67927,5392,17664,108926,1364,54560,256,21793,46092,74251]

theorem envBound41750 : H12AffineFastState.Bounded env41750 := by
  intro p hp
  have h : env41750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41749_41750 : H12AffineEnvironment.transform 21 8573 env41749 = env41750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env41749 == env41750) = true)

theorem identity41750 : scanCanonicalize (H12AffineFastState.compose env41750 (packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound41750 : packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env41751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,79130,10280,1024,32769,4160,8573,16,98644,8192,65,67927,5392,12636,108926,1364,41340,256,8573,46092,74251]

theorem envBound41751 : H12AffineFastState.Bounded env41751 := by
  intro p hp
  have h : env41751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41750_41751 : H12AffineEnvironment.transform 13 13404 env41750 = env41751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env41750 == env41751) = true)

theorem identity41751 : scanCanonicalize (H12AffineFastState.compose env41751 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41751 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env41752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,79130,10280,1024,0,4160,8573,16,65877,8192,65,67927,5392,12636,76159,1364,8573,256,8573,13325,74251]

theorem envBound41752 : H12AffineFastState.Bounded env41752 := by
  intro p hp
  have h : env41752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41751_41752 : H12AffineEnvironment.transform 14 1 env41751 = env41752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41751 == env41752) = true)

theorem identity41752 : scanCanonicalize (H12AffineFastState.compose env41752 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41752 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,5392,10280,1024,0,4160,8573,16,8543,8192,65,10589,5392,12636,2421,1364,8573,256,8573,13325,513]

theorem envBound41753 : H12AffineFastState.Bounded env41753 := by
  intro p hp
  have h : env41753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41752_41753 : H12AffineEnvironment.transform 15 8202 env41752 = env41753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41752 == env41753) = true)

theorem identity41753 : scanCanonicalize (H12AffineFastState.compose env41753 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41753 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41754 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,1,8202,5392,10280,1024,0,4113,8492,16,8462,8192,16,10508,5392,12557,2340,1285,8492,256,8492,13325,513]

theorem envBound41754 : H12AffineFastState.Bounded env41754 := by
  intro p hp
  have h : env41754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41753_41754 : H12AffineEnvironment.transform 5 17 env41753 = env41754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41753 == env41754) = true)

theorem identity41754 : scanCanonicalize (H12AffineFastState.compose env41754 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41754 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41755 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,8192,13325,1,8202,5392,8233,1024,0,4113,8492,16,8462,8192,16,8461,5392,12557,293,1285,8492,256,8492,13325,513]

theorem envBound41755 : H12AffineFastState.Bounded env41755 := by
  intro p hp
  have h : env41755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41754_41755 : H12AffineEnvironment.transform 10 1 env41754 = env41755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41754 == env41755) = true)

theorem identity41755 : scanCanonicalize (H12AffineFastState.compose env41755 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41755 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41756 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,269,5376,1,263,5392,292,1024,0,4113,33,16,3,269,16,0,5392,4096,293,1285,33,256,33,5376,513]

theorem envBound41756 : H12AffineFastState.Bounded env41756 := by
  intro p hp
  have h : env41756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41755_41756 : H12AffineEnvironment.transform 12 269 env41755 = env41756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41755 == env41756) = true)

theorem identity41756 : scanCanonicalize (H12AffineFastState.compose env41756 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound41756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41757 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,1313,269,33,1,263,49,292,1024,0,1328,33,16,3,269,16,0,49,1313,293,1285,33,256,33,33,513]

theorem envBound41757 : H12AffineFastState.Bounded env41757 := by
  intro p hp
  have h : env41757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41756_41757 : H12AffineEnvironment.transform 11 1313 env41756 = env41757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env41756 == env41757) = true)

theorem identity41757 : scanCanonicalize (H12AffineFastState.compose env41757 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41757 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41758 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,1028,40,33,1,34,49,1,1024,0,1045,33,16,3,40,16,0,49,1028,0,1056,33,37,33,33,513]

theorem envBound41758 : H12AffineFastState.Bounded env41758 := by
  intro p hp
  have h : env41758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41757_41758 : H12AffineEnvironment.transform 7 37 env41757 = env41758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41757 == env41758) = true)

theorem identity41758 : scanCanonicalize (H12AffineFastState.compose env41758 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound41758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41759 : List Nat := [2,4,8,16,32,17,8,37,512,516,1,512,40,33,1,34,49,1,516,0,529,33,16,3,40,16,0,49,512,0,548,33,37,33,33,513]

theorem envBound41759 : H12AffineFastState.Bounded env41759 := by
  intro p hp
  have h : env41759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41758_41759 : H12AffineEnvironment.transform 9 516 env41758 = env41759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env41758 == env41759) = true)

theorem identity41759 : scanCanonicalize (H12AffineFastState.compose env41759 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41759 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41760 : List Nat := [2,4,8,16,32,17,8,37,0,4,1,0,40,33,1,34,49,1,4,0,17,33,16,3,40,16,0,49,0,0,36,33,37,33,33,1]

theorem envBound41760 : H12AffineFastState.Bounded env41760 := by
  intro p hp
  have h : env41760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41759_41760 : H12AffineEnvironment.transform 8 0 env41759 = env41760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41759 == env41760) = true)

theorem identity41760 : scanCanonicalize (H12AffineFastState.compose env41760 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41760 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41761 : List Nat := [2,4,8,16,0,17,8,5,0,4,1,0,8,1,1,2,17,1,4,0,17,1,16,3,8,16,0,17,0,0,4,1,5,1,1,1]

theorem envBound41761 : H12AffineFastState.Bounded env41761 := by
  intro p hp
  have h : env41761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41760_41761 : H12AffineEnvironment.transform 4 0 env41760 = env41761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41760 == env41761) = true)

theorem identity41761 : scanCanonicalize (H12AffineFastState.compose env41761 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41761 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env41762 : List Nat := [2,4,8,0,0,1,8,5,0,4,1,0,8,1,1,2,1,1,4,0,1,1,0,3,8,0,0,1,0,0,4,1,5,1,1,1]

theorem envBound41762 : H12AffineFastState.Bounded env41762 := by
  intro p hp
  have h : env41762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41761_41762 : H12AffineEnvironment.transform 3 0 env41761 = env41762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41761 == env41762) = true)

theorem identity41762 : scanCanonicalize (H12AffineFastState.compose env41762 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41763 : List Nat := [2,4,3,0,0,1,3,5,0,4,1,0,3,1,1,2,1,1,4,0,1,1,0,3,3,0,0,1,0,0,4,1,5,1,1,1]

theorem envBound41763 : H12AffineFastState.Bounded env41763 := by
  intro p hp
  have h : env41763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41762_41763 : H12AffineEnvironment.transform 2 3 env41762 = env41763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41762 == env41763) = true)

def env41764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98645,8193,65,4270123,5392,17664,108926,1365,4256861,256,21793,46093,74251]

theorem envBound41764 : H12AffineFastState.Bounded env41764 := by
  intro p hp
  have h : env41764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41747_41764 : H12AffineEnvironment.transform 6 9 env41747 = env41764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41747 == env41764) = true)

theorem identity41764 : scanCanonicalize (H12AffineFastState.compose env41764 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound41764 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35188,1024,32769,4160,4194304,16,98645,8193,65,4270123,5392,17664,108926,1365,4256861,256,21793,46093,74251]

theorem envBound41765 : H12AffineFastState.Bounded env41765 := by
  intro p hp
  have h : env41765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41764_41765 : H12AffineEnvironment.transform 16 122906 env41764 = env41765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env41764 == env41765) = true)

theorem identity41765 : scanCanonicalize (H12AffineFastState.compose env41765 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 119846) := by decide +kernel

theorem selectedBound41765 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env41766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35188,1024,32769,4160,119846,16,98645,8193,65,64525,5392,17664,108926,1365,73851,256,21793,46093,74251]

theorem envBound41766 : H12AffineFastState.Bounded env41766 := by
  intro p hp
  have h : env41766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41765_41766 : H12AffineEnvironment.transform 21 119846 env41765 = env41766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119846 env41765 == env41766) = true)

theorem identity41766 : scanCanonicalize (H12AffineFastState.compose env41766 (packedSelected [0,3,9,10,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound41766 : packedSelected [0,3,9,10,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,65536,111946,35188,1024,32769,4160,98678,16,98645,8193,65,43357,5392,4176,108926,1365,73851,256,113,46093,74251]

theorem envBound41767 : H12AffineFastState.Bounded env41767 := by
  intro p hp
  have h : env41767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41766_41767 : H12AffineEnvironment.transform 13 5456 env41766 = env41767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env41766 == env41767) = true)

theorem identity41767 : scanCanonicalize (H12AffineFastState.compose env41767 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41767 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env41768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,0,65536,79178,2420,1024,1,4160,65910,16,65877,8193,65,10589,5392,4176,76158,1365,73851,256,113,13325,74251]

theorem envBound41768 : H12AffineFastState.Bounded env41768 := by
  intro p hp
  have h : env41768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41767_41768 : H12AffineEnvironment.transform 14 0 env41767 = env41768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41767 == env41768) = true)

theorem identity41768 : scanCanonicalize (H12AffineFastState.compose env41768 (packedSelected [3,4,5,6,9,10,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 1126) := by decide +kernel

theorem selectedBound41768 : packedSelected [3,4,5,6,9,10,12,14,16] rootPS < 2^1333 := by decide +kernel

def env41769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,0,1126,12588,2420,1024,1,4160,1296,16,1331,8193,65,10589,5392,4176,11544,1365,9245,256,113,13325,9837]

theorem envBound41769 : H12AffineFastState.Bounded env41769 := by
  intro p hp
  have h : env41769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41768_41769 : H12AffineEnvironment.transform 15 1126 env41768 = env41769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1126 env41768 == env41769) = true)

theorem identity41769 : scanCanonicalize (H12AffineFastState.compose env41769 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41769 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41770 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4405,0,3,12588,2420,101,1,4160,373,16,342,8193,65,10589,4469,4176,10621,304,8312,256,113,12392,8712]

theorem envBound41770 : H12AffineFastState.Bounded env41770 := by
  intro p hp
  have h : env41770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41769_41770 : H12AffineEnvironment.transform 9 101 env41769 = env41770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41769 == env41770) = true)

theorem identity41770 : scanCanonicalize (H12AffineFastState.compose env41770 (packedSelected [1,2,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound41770 : packedSelected [1,2,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41771 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,553,4405,0,3,4869,2420,101,1,4160,373,16,342,552,65,2932,4469,4176,2900,304,593,256,113,4673,33]

theorem envBound41771 : H12AffineFastState.Bounded env41771 := by
  intro p hp
  have h : env41771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41770_41771 : H12AffineEnvironment.transform 12 553 env41770 = env41771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env41770 == env41771) = true)

theorem identity41771 : scanCanonicalize (H12AffineFastState.compose env41771 (packedSelected [1,2,6,7,8,9,10,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound41771 : packedSelected [1,2,6,7,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env41772 : List Nat := [2,4,8,16,32,64,9,256,260,101,2048,4096,301,4405,0,3,4097,2420,101,1,4160,373,16,342,300,65,2160,4469,4176,2128,304,341,256,113,4421,33]

theorem envBound41772 : H12AffineFastState.Bounded env41772 := by
  intro p hp
  have h : env41772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41771_41772 : H12AffineEnvironment.transform 8 260 env41771 = env41772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env41771 == env41772) = true)

theorem identity41772 : scanCanonicalize (H12AffineFastState.compose env41772 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound41772 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41773 : List Nat := [2,4,8,16,32,64,9,256,260,101,2048,293,301,16,0,3,292,2420,101,1,357,373,16,342,300,65,2160,80,373,2128,304,341,256,113,96,33]

theorem envBound41773 : H12AffineFastState.Bounded env41773 := by
  intro p hp
  have h : env41773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41772_41773 : H12AffineEnvironment.transform 11 293 env41772 = env41773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env41772 == env41773) = true)

theorem identity41773 : scanCanonicalize (H12AffineFastState.compose env41773 (packedSelected [1,2,4,6,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41773 : packedSelected [1,2,4,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env41774 : List Nat := [2,4,8,16,32,64,9,36,32,101,2048,1,9,16,0,3,0,2128,101,1,65,81,16,114,8,65,2160,80,81,2128,20,113,36,113,96,33]

theorem envBound41774 : H12AffineFastState.Bounded env41774 := by
  intro p hp
  have h : env41774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41773_41774 : H12AffineEnvironment.transform 7 36 env41773 = env41774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41773 == env41774) = true)

theorem identity41774 : scanCanonicalize (H12AffineFastState.compose env41774 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound41774 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41775 : List Nat := [2,4,8,16,32,64,9,36,32,101,90,1,9,16,0,3,0,10,101,1,65,81,16,114,8,65,42,80,81,10,20,113,36,113,96,33]

theorem envBound41775 : H12AffineFastState.Bounded env41775 := by
  intro p hp
  have h : env41775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41774_41775 : H12AffineEnvironment.transform 10 90 env41774 = env41775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env41774 == env41775) = true)

theorem identity41775 : scanCanonicalize (H12AffineFastState.compose env41775 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41775 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41776 : List Nat := [2,4,8,16,16,64,9,20,16,85,90,1,9,16,0,3,0,10,85,1,65,81,16,66,8,65,26,80,81,10,20,65,20,65,80,17]

theorem envBound41776 : H12AffineFastState.Bounded env41776 := by
  intro p hp
  have h : env41776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41775_41776 : H12AffineEnvironment.transform 4 16 env41775 = env41776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41775 == env41776) = true)

theorem identity41776 : scanCanonicalize (H12AffineFastState.compose env41776 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41776 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41777 : List Nat := [2,4,8,16,16,16,9,20,16,5,10,1,9,16,0,3,0,10,5,1,17,1,16,18,8,17,26,0,1,10,20,17,20,17,0,17]

theorem envBound41777 : H12AffineFastState.Bounded env41777 := by
  intro p hp
  have h : env41777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41776_41777 : H12AffineEnvironment.transform 5 16 env41776 = env41777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41776 == env41777) = true)

theorem identity41777 : scanCanonicalize (H12AffineFastState.compose env41777 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41778 : List Nat := [2,4,2,16,16,16,3,20,16,5,0,1,3,16,0,3,0,0,5,1,17,1,16,18,2,17,16,0,1,0,20,17,20,17,0,17]

theorem envBound41778 : H12AffineFastState.Bounded env41778 := by
  intro p hp
  have h : env41778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41777_41778 : H12AffineEnvironment.transform 2 2 env41777 = env41778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41777 == env41778) = true)

def env41779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,17,98781,8328,65,4270242,5392,17664,108927,1500,4256861,256,21792,46213,74251]

theorem envBound41779 : H12AffineFastState.Bounded env41779 := by
  intro p hp
  have h : env41779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41746_41779 : H12AffineEnvironment.transform 20 4161 env41746 = env41779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41746 == env41779) = true)

theorem identity41779 : scanCanonicalize (H12AffineFastState.compose env41779 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound41779 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169265,17,98781,8328,65,245139,5392,17664,108927,1500,156012,256,21792,46213,74251]

theorem envBound41780 : H12AffineFastState.Bounded env41780 := by
  intro p hp
  have h : env41780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41779_41780 : H12AffineEnvironment.transform 21 169265 env41779 = env41780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env41779 == env41780) = true)

def env41781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169265,17,98645,8192,65,245019,5392,17664,108927,1364,156012,256,21792,46093,74251]

theorem envBound41781 : H12AffineFastState.Bounded env41781 := by
  intro p hp
  have h : env41781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41780_41781 : H12AffineEnvironment.transform 6 8 env41780 = env41781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41780 == env41781) = true)

theorem identity41781 : scanCanonicalize (H12AffineFastState.compose env41781 (packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound41781 : packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env41782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103495,64809,1024,32769,4161,65910,17,98645,8192,65,10588,5392,17664,108927,1364,128299,256,21792,46093,74251]

theorem envBound41782 : H12AffineFastState.Bounded env41782 := by
  intro p hp
  have h : env41782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41781_41782 : H12AffineEnvironment.transform 16 103495 env41781 = env41782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env41781 == env41782) = true)

theorem identity41782 : scanCanonicalize (H12AffineFastState.compose env41782 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41782 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,2420,1024,29788,4161,65910,17,95496,8192,65,10588,5392,17664,89378,1364,65910,256,21792,16464,74251]

theorem envBound41783 : H12AffineFastState.Bounded env41783 := by
  intro p hp
  have h : env41783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41782_41783 : H12AffineEnvironment.transform 14 29789 env41782 = env41783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41782 == env41783) = true)

theorem identity41783 : scanCanonicalize (H12AffineFastState.compose env41783 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41783 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,2420,1024,29788,4161,8572,17,21762,8192,65,10588,5392,17664,32040,1364,8572,256,21792,16464,513]

theorem envBound41784 : H12AffineFastState.Bounded env41784 := by
  intro p hp
  have h : env41784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41783_41784 : H12AffineEnvironment.transform 15 8202 env41783 = env41784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41783 == env41784) = true)

theorem identity41784 : scanCanonicalize (H12AffineFastState.compose env41784 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41784 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8202,13341,2420,1024,81,4161,8572,17,8463,8192,65,10588,5392,12557,2341,1364,8572,256,8493,13405,513]

theorem envBound41785 : H12AffineFastState.Bounded env41785 := by
  intro p hp
  have h : env41785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41784_41785 : H12AffineEnvironment.transform 13 13325 env41784 = env41785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41784 == env41785) = true)

theorem identity41785 : scanCanonicalize (H12AffineFastState.compose env41785 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound41785 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,2049,80,7174,2065,2420,1024,81,4161,7536,17,7427,7180,65,5456,5392,3329,2341,1364,7536,256,7457,2129,513]

theorem envBound41786 : H12AffineFastState.Bounded env41786 := by
  intro p hp
  have h : env41786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41785_41786 : H12AffineEnvironment.transform 12 7180 env41785 = env41786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env41785 == env41786) = true)

theorem identity41786 : scanCanonicalize (H12AffineFastState.compose env41786 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound41786 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env41787 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,4096,7180,2049,80,7174,2065,2420,1024,81,4161,7536,17,7427,7180,65,5456,5392,3329,2341,1364,7536,256,7457,2129,373]

theorem envBound41787 : H12AffineFastState.Bounded env41787 := by
  intro p hp
  have h : env41787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41786_41787 : H12AffineEnvironment.transform 8 372 env41786 = env41787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env41786 == env41787) = true)

theorem identity41787 : scanCanonicalize (H12AffineFastState.compose env41787 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound41787 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env41788 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,2065,1053,2049,80,1047,2065,2420,1024,81,2128,1377,17,1298,1053,65,3393,3329,3329,2341,1364,1377,256,1328,2129,373]

theorem envBound41788 : H12AffineFastState.Bounded env41788 := by
  intro p hp
  have h : env41788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41787_41788 : H12AffineEnvironment.transform 11 2065 env41787 = env41788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env41787 == env41788) = true)

theorem identity41788 : scanCanonicalize (H12AffineFastState.compose env41788 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound41788 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41789 : List Nat := [2,4,8,16,32,64,8,101,17,1024,2048,2065,1053,2049,80,1047,2065,2065,1024,81,2128,1028,17,1143,1053,65,3108,3172,3172,2112,1073,1028,101,1109,2129,16]

theorem envBound41789 : H12AffineFastState.Bounded env41789 := by
  intro p hp
  have h : env41789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41788_41789 : H12AffineEnvironment.transform 7 101 env41788 = env41789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env41788 == env41789) = true)

theorem identity41789 : scanCanonicalize (H12AffineFastState.compose env41789 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound41789 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41790 : List Nat := [2,4,8,16,32,64,8,101,17,37,2048,2065,56,2049,80,50,2065,2065,37,81,2128,33,17,82,56,65,2049,2113,2113,2112,20,33,101,112,2129,16]

theorem envBound41790 : H12AffineFastState.Bounded env41790 := by
  intro p hp
  have h : env41790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41789_41790 : H12AffineEnvironment.transform 9 37 env41789 = env41790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env41789 == env41790) = true)

theorem identity41790 : scanCanonicalize (H12AffineFastState.compose env41790 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound41790 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env41791 : List Nat := [2,4,8,16,32,64,8,101,17,37,64,81,56,65,80,50,81,81,37,81,16,33,17,82,56,65,65,1,1,0,20,33,101,112,17,16]

theorem envBound41791 : H12AffineFastState.Bounded env41791 := by
  intro p hp
  have h : env41791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41790_41791 : H12AffineEnvironment.transform 10 64 env41790 = env41791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env41790 == env41791) = true)

theorem identity41791 : scanCanonicalize (H12AffineFastState.compose env41791 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41792 : List Nat := [2,4,8,1,32,64,8,101,0,37,64,64,41,65,65,35,64,64,37,64,1,33,0,67,41,65,65,1,1,0,5,33,101,97,0,1]

theorem envBound41792 : H12AffineFastState.Bounded env41792 := by
  intro p hp
  have h : env41792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41791_41792 : H12AffineEnvironment.transform 3 1 env41791 = env41792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41791 == env41792) = true)

def env41793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169265,17,98644,8193,65,245018,5392,17664,108927,1365,156012,256,21792,46092,74251]

theorem envBound41793 : H12AffineFastState.Bounded env41793 := by
  intro p hp
  have h : env41793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41780_41793 : H12AffineEnvironment.transform 6 9 env41780 = env41793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41780 == env41793) = true)

theorem identity41793 : scanCanonicalize (H12AffineFastState.compose env41793 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41793 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223598,1024,8540,4161,144492,17,73737,8193,65,203847,5392,17664,67618,1365,156012,256,21792,5457,74251]

theorem envBound41794 : H12AffineFastState.Bounded env41794 := by
  intro p hp
  have h : env41794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41793_41794 : H12AffineEnvironment.transform 14 8541 env41793 = env41794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41793 == env41794) = true)

theorem identity41794 : scanCanonicalize (H12AffineFastState.compose env41794 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41794 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env41795 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,65536,131072,223258,1024,8232,4161,144492,17,73737,8193,65,203847,5220,17524,67618,1057,155672,116,21588,5157,74251]

theorem envBound41795 : H12AffineFastState.Bounded env41795 := by
  intro p hp
  have h : env41795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41794_41795 : H12AffineEnvironment.transform 7 116 env41794 = env41795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41794 == env41795) = true)

theorem identity41795 : scanCanonicalize (H12AffineFastState.compose env41795 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41795 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41796 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,1,65536,131072,215090,1024,0,4161,136260,17,65569,41,65,203847,5220,17524,67618,1057,147504,116,21588,5157,66083]

theorem envBound41796 : H12AffineFastState.Bounded env41796 := by
  intro p hp
  have h : env41796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41795_41796 : H12AffineEnvironment.transform 12 40 env41795 = env41796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41795 == env41796) = true)

theorem identity41796 : scanCanonicalize (H12AffineFastState.compose env41796 (packedSelected [1,3,4,5,8,9,10,14,16,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41796 : packedSelected [1,3,4,5,8,9,10,14,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41797 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,1,65536,131072,215090,1024,0,4113,136212,17,65569,41,17,203799,5172,17444,67618,1057,147504,36,21508,5157,66083]

theorem envBound41797 : H12AffineFastState.Bounded env41797 := by
  intro p hp
  have h : env41797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41796_41797 : H12AffineEnvironment.transform 5 16 env41796 = env41797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41796 == env41797) = true)

theorem identity41797 : scanCanonicalize (H12AffineFastState.compose env41797 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound41797 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env41798 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,1,65536,5173,89095,1024,0,4113,33,17,65569,41,17,67618,5172,17444,67618,1057,21509,36,21508,5157,66083]

theorem envBound41798 : H12AffineFastState.Bounded env41798 := by
  intro p hp
  have h : env41798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41797_41798 : H12AffineEnvironment.transform 16 5173 env41797 = env41798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env41797 == env41798) = true)

theorem identity41798 : scanCanonicalize (H12AffineFastState.compose env41798 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound41798 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env41799 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,1,35,5173,23588,1024,0,4113,33,17,2,41,17,2049,5172,17444,2049,1057,21509,36,21508,5157,512]

theorem envBound41799 : H12AffineFastState.Bounded env41799 := by
  intro p hp
  have h : env41799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41798_41799 : H12AffineEnvironment.transform 15 35 env41798 = env41799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env41798 == env41799) = true)

theorem identity41799 : scanCanonicalize (H12AffineFastState.compose env41799 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound41799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41800 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5125,1,35,5173,2081,1024,0,4113,33,17,2,41,17,2049,5172,4129,2049,1057,0,36,1,5157,512]

theorem envBound41800 : H12AffineFastState.Bounded env41800 := by
  intro p hp
  have h : env41800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41799_41800 : H12AffineEnvironment.transform 13 5125 env41799 = env41800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env41799 == env41800) = true)

theorem identity41800 : scanCanonicalize (H12AffineFastState.compose env41800 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41800 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41801 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1024,0,4113,0,17,2,8,17,2049,5141,4096,2049,1024,0,5,1,5124,512]

theorem envBound41801 : H12AffineFastState.Bounded env41801 := by
  intro p hp
  have h : env41801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41800_41801 : H12AffineEnvironment.transform 4 1 env41800 = env41801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41800 == env41801) = true)

theorem identity41801 : scanCanonicalize (H12AffineFastState.compose env41801 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound41801 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41802 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,1045,9,16,1,2,1,2048,1024,0,1028,0,17,2,8,17,2049,0,1045,2049,1024,0,5,1,17,512]

theorem envBound41802 : H12AffineFastState.Bounded env41802 := by
  intro p hp
  have h : env41802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41801_41802 : H12AffineEnvironment.transform 11 1045 env41801 = env41802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env41801 == env41802) = true)

theorem identity41802 : scanCanonicalize (H12AffineFastState.compose env41802 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound41802 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41803 : List Nat := [2,4,8,16,1,16,9,5,512,1024,10,1045,9,16,1,2,1,10,1024,0,1028,0,17,2,8,17,11,0,1045,11,1024,0,5,1,17,512]

theorem envBound41803 : H12AffineFastState.Bounded env41803 := by
  intro p hp
  have h : env41803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41802_41803 : H12AffineEnvironment.transform 10 10 env41802 = env41803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env41802 == env41803) = true)

theorem identity41803 : scanCanonicalize (H12AffineFastState.compose env41803 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41803 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41804 : List Nat := [2,4,8,16,1,16,9,5,1,1024,10,1045,9,16,1,2,1,10,1024,0,1028,0,17,2,8,17,11,0,1045,11,1024,0,5,1,17,1]

theorem envBound41804 : H12AffineFastState.Bounded env41804 := by
  intro p hp
  have h : env41804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41803_41804 : H12AffineEnvironment.transform 8 1 env41803 = env41804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41803 == env41804) = true)

theorem identity41804 : scanCanonicalize (H12AffineFastState.compose env41804 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41804 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41805 : List Nat := [2,4,8,16,1,16,9,5,1,20,10,1,9,16,1,2,1,10,20,0,16,0,17,2,8,17,11,0,1,11,20,0,5,1,17,1]

theorem envBound41805 : H12AffineFastState.Bounded env41805 := by
  intro p hp
  have h : env41805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41804_41805 : H12AffineEnvironment.transform 9 20 env41804 = env41805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41804 == env41805) = true)

theorem identity41805 : scanCanonicalize (H12AffineFastState.compose env41805 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound41805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41806 : List Nat := [2,1,8,16,1,16,9,0,1,17,10,1,9,16,1,2,1,10,17,0,16,0,17,2,8,17,11,0,1,11,17,0,0,1,17,1]

theorem envBound41806 : H12AffineFastState.Bounded env41806 := by
  intro p hp
  have h : env41806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41805_41806 : H12AffineEnvironment.transform 1 1 env41805 = env41806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env41805 == env41806) = true)

theorem identity41806 : scanCanonicalize (H12AffineFastState.compose env41806 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41806 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41807 : List Nat := [0,1,8,16,1,16,9,0,1,17,8,1,9,16,1,0,1,8,17,0,16,0,17,0,8,17,9,0,1,9,17,0,0,1,17,1]

theorem envBound41807 : H12AffineFastState.Bounded env41807 := by
  intro p hp
  have h : env41807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41806_41807 : H12AffineEnvironment.transform 0 0 env41806 = env41807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41806 == env41807) = true)

def env41808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270243,5392,17665,2210111,1501,4256861,256,2114912,2139333,74250]

theorem envBound41808 : H12AffineFastState.Bounded env41808 := by
  intro p hp
  have h : env41808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41745_41808 : H12AffineEnvironment.transform 22 2101329 env41745 = env41808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env41745 == env41808) = true)

def env41809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,17,98780,8328,65,4270243,5392,17665,108927,1501,4256861,256,21792,46213,74250]

theorem envBound41809 : H12AffineFastState.Bounded env41809 := by
  intro p hp
  have h : env41809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41808_41809 : H12AffineEnvironment.transform 20 4160 env41808 = env41809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41808 == env41809) = true)

theorem identity41809 : scanCanonicalize (H12AffineFastState.compose env41809 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound41809 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,156132,17,98780,8328,65,215367,5392,17665,108927,1501,169401,256,21792,46213,74250]

theorem envBound41810 : H12AffineFastState.Bounded env41810 := by
  intro p hp
  have h : env41810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41809_41810 : H12AffineEnvironment.transform 21 156132 env41809 = env41810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env41809 == env41810) = true)

theorem identity41810 : scanCanonicalize (H12AffineFastState.compose env41810 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41810 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env41811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2421,1024,32769,4160,66047,17,98780,8328,65,10588,5392,17665,108927,1501,128418,256,21792,46213,74250]

theorem envBound41811 : H12AffineFastState.Bounded env41811 := by
  intro p hp
  have h : env41811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41810_41811 : H12AffineEnvironment.transform 16 90139 env41810 = env41811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41810 == env41811) = true)

theorem identity41811 : scanCanonicalize (H12AffineFastState.compose env41811 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound41811 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,2421,1024,29908,4160,66047,17,95497,8328,65,10588,5392,17665,89514,1501,65911,256,21792,16464,74250]

theorem envBound41812 : H12AffineFastState.Bounded env41812 := by
  intro p hp
  have h : env41812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41811_41812 : H12AffineEnvironment.transform 14 29909 env41811 = env41812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env41811 == env41812) = true)

theorem identity41812 : scanCanonicalize (H12AffineFastState.compose env41812 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41812 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env41813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16400,2421,1024,29908,4160,8692,17,21762,8328,65,10588,5392,17665,32161,1501,8572,256,21792,16464,513]

theorem envBound41813 : H12AffineFastState.Bounded env41813 := by
  intro p hp
  have h : env41813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41812_41813 : H12AffineEnvironment.transform 15 8203 env41812 = env41813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41812 == env41813) = true)

def env41814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98781,8328,65,4270243,5392,17665,108926,1501,4256861,256,21793,46212,74250]

theorem envBound41814 : H12AffineFastState.Bounded env41814 := by
  intro p hp
  have h : env41814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41808_41814 : H12AffineEnvironment.transform 20 4161 env41808 = env41814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41808 == env41814) = true)

theorem identity41814 : scanCanonicalize (H12AffineFastState.compose env41814 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound41814 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,223598,1024,29908,4161,4194304,16,95496,8328,65,4270243,5392,17665,89515,1501,4194440,256,21793,16465,74250]

theorem envBound41815 : H12AffineFastState.Bounded env41815 := by
  intro p hp
  have h : env41815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41814_41815 : H12AffineEnvironment.transform 14 29909 env41814 = env41815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env41814 == env41815) = true)

def env41816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212078,1024,8660,4161,4194304,16,73736,8328,65,4270243,5392,4097,67755,1501,4194440,256,33,5457,74250]

theorem envBound41816 : H12AffineFastState.Bounded env41816 := by
  intro p hp
  have h : env41816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41815_41816 : H12AffineEnvironment.transform 13 5376 env41815 = env41816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41815 == env41816) = true)

theorem identity41816 : scanCanonicalize (H12AffineFastState.compose env41816 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound41816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,10280,1024,8660,4161,4194304,16,73736,8328,65,4270243,5392,4097,67755,1501,4194440,256,33,5457,74250]

theorem envBound41817 : H12AffineFastState.Bounded env41817 := by
  intro p hp
  have h : env41817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41816_41817 : H12AffineEnvironment.transform 16 70726 env41816 = env41817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env41816 == env41817) = true)

theorem identity41817 : scanCanonicalize (H12AffineFastState.compose env41817 (packedSelected [1,2,6,7,8,9,11,16,18,19,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41817 : packedSelected [1,2,6,7,8,9,11,16,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env41818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,70726,10280,1024,8540,4161,4194304,16,73736,8192,65,4270123,5392,4097,67619,1365,4194304,256,33,5457,74250]

theorem envBound41818 : H12AffineFastState.Bounded env41818 := by
  intro p hp
  have h : env41818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41817_41818 : H12AffineEnvironment.transform 6 8 env41817 = env41818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41817 == env41818) = true)

theorem identity41818 : scanCanonicalize (H12AffineFastState.compose env41818 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41818 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env41819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10280,1024,8540,4161,4194304,16,3,8192,65,4196384,5392,4097,10280,1365,4194304,256,33,5457,513]

theorem envBound41819 : H12AffineFastState.Bounded env41819 := by
  intro p hp
  have h : env41819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41818_41819 : H12AffineEnvironment.transform 15 8203 env41818 = env41819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41818 == env41819) = true)

theorem identity41819 : scanCanonicalize (H12AffineFastState.compose env41819 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound41819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0