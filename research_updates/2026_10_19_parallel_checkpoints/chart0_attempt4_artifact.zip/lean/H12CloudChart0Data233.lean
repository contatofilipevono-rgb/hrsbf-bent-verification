import H12CloudChart0Data232

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59090_59104 : H12AffineEnvironment.transform 12 1409 env59090 = env59104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59090 == env59104) = true)

theorem identity59104 : scanCanonicalize (H12AffineFastState.compose env59104 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound59104 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59105 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4131,1392,262144,1025,2129,2264,1417,65,3159,1288,16,266668,4177,1312,5488,4133,6621,256,4264,1392,1]

theorem envBound59105 : H12AffineFastState.Bounded env59105 := by
  intro p hp
  have h : env59105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59104_59105 : H12AffineEnvironment.transform 15 4131 env59104 = env59105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env59104 == env59105) = true)

theorem identity59105 : scanCanonicalize (H12AffineFastState.compose env59105 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59105 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59106 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4131,1392,276,1025,2129,2264,1417,65,3159,1288,16,4280,4177,1312,5488,4133,6621,256,4264,1392,1]

theorem envBound59106 : H12AffineFastState.Bounded env59106 := by
  intro p hp
  have h : env59106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59105_59106 : H12AffineEnvironment.transform 17 276 env59105 = env59106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59105 == env59106) = true)

theorem identity59106 : scanCanonicalize (H12AffineFastState.compose env59106 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59106 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59107 : List Nat := [2,4,8,16,32,64,128,256,1,236,2048,4096,365,4176,2129,4131,412,276,237,2129,2264,357,65,2235,484,16,4280,4177,460,4508,4133,6621,256,4264,412,1]

theorem envBound59107 : H12AffineFastState.Bounded env59107 := by
  intro p hp
  have h : env59107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59106_59107 : H12AffineEnvironment.transform 9 236 env59106 = env59107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59106 == env59107) = true)

theorem identity59107 : scanCanonicalize (H12AffineFastState.compose env59107 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59107 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59108 : List Nat := [2,4,8,16,32,64,128,69,1,236,2048,4096,40,4176,2129,4131,217,81,237,2129,2264,32,65,2235,161,16,4280,4177,137,4313,4133,6296,69,4264,217,1]

theorem envBound59108 : H12AffineFastState.Bounded env59108 := by
  intro p hp
  have h : env59108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59107_59108 : H12AffineEnvironment.transform 7 69 env59107 = env59108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59107 == env59108) = true)

theorem identity59108 : scanCanonicalize (H12AffineFastState.compose env59108 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound59108 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59109 : List Nat := [2,4,8,16,32,64,128,69,1,236,2048,2232,40,2280,2129,2203,217,81,237,2129,2264,32,65,2235,161,16,2048,2281,137,2145,2205,32,69,2064,217,1]

theorem envBound59109 : H12AffineFastState.Bounded env59109 := by
  intro p hp
  have h : env59109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59108_59109 : H12AffineEnvironment.transform 11 2232 env59108 = env59109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env59108 == env59109) = true)

theorem identity59109 : scanCanonicalize (H12AffineFastState.compose env59109 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound59109 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59110 : List Nat := [2,4,8,16,32,64,128,69,1,236,195,123,40,43,146,88,217,81,237,146,27,32,65,120,161,16,195,42,137,162,94,32,69,211,217,1]

theorem envBound59110 : H12AffineFastState.Bounded env59110 := by
  intro p hp
  have h : env59110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59109_59110 : H12AffineEnvironment.transform 10 195 env59109 = env59110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env59109 == env59110) = true)

theorem identity59110 : scanCanonicalize (H12AffineFastState.compose env59110 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59110 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59111 : List Nat := [2,4,8,16,32,64,114,69,1,30,49,123,40,43,96,88,43,81,31,96,27,32,65,120,83,16,49,42,123,80,94,32,69,33,43,1]

theorem envBound59111 : H12AffineFastState.Bounded env59111 := by
  intro p hp
  have h : env59111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59110_59111 : H12AffineEnvironment.transform 6 114 env59110 = env59111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59110 == env59111) = true)

def env59112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3671,1289,9616,2366325,4177,77954,67410,65543,68606,256,65675,78034,10112]

theorem envBound59112 : H12AffineFastState.Bounded env59112 := by
  intro p hp
  have h : env59112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59068_59112 : H12AffineEnvironment.transform 22 9665 env59068 = env59112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59068 == env59112) = true)

def env59113 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59113 : H12AffineFastState.Bounded env59113 := by
  intro p hp
  have h : env59113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59112_59113 : H12AffineEnvironment.transform 8 0 env59112 = env59113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59112 == env59113) = true)

theorem identity59113 : scanCanonicalize (H12AffineFastState.compose env59113 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59114 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,8192,216,2128,65536,73818,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2361853,217,73738,66898,65543,68094,256,65675,73818,9600]

theorem envBound59114 : H12AffineFastState.Bounded env59114 := by
  intro p hp
  have h : env59114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59113_59114 : H12AffineEnvironment.transform 11 136 env59113 = env59114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59113 == env59114) = true)

def env59115 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2128,65536,67034,262144,1025,2128,2097152,1417,65,3159,1289,16,2361853,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59115 : H12AffineFastState.Bounded env59115 := by
  intro p hp
  have h : env59115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59114_59115 : H12AffineEnvironment.transform 12 1408 env59114 = env59115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59114 == env59115) = true)

theorem identity59115 : scanCanonicalize (H12AffineFastState.compose env59115 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound59115 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59116 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2128,65536,67034,262144,1025,2128,67699,1417,65,3159,1289,16,328078,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59116 : H12AffineFastState.Bounded env59116 := by
  intro p hp
  have h : env59116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59115_59116 : H12AffineEnvironment.transform 20 67699 env59115 = env59116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env59115 == env59116) = true)

theorem identity59116 : scanCanonicalize (H12AffineFastState.compose env59116 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound59116 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59117 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2128,65536,67034,65983,1025,2128,67699,1417,65,3159,1289,16,49,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59117 : H12AffineFastState.Bounded env59117 := by
  intro p hp
  have h : env59117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59116_59117 : H12AffineEnvironment.transform 17 65983 env59116 = env59117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env59116 == env59117) = true)

theorem identity59117 : scanCanonicalize (H12AffineFastState.compose env59117 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59117 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59118 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2128,1095,413,1528,1025,2128,3124,1417,65,3159,1289,16,49,217,461,277,1088,3513,256,1228,413,0]

theorem envBound59118 : H12AffineFastState.Bounded env59118 := by
  intro p hp
  have h : env59118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59117_59118 : H12AffineEnvironment.transform 15 1095 env59117 = env59118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59117 == env59118) = true)

theorem identity59118 : scanCanonicalize (H12AffineFastState.compose env59118 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59118 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59119 : List Nat := [2,4,8,16,32,64,128,256,0,425,2048,136,41,216,2128,494,413,81,424,2128,2461,32,65,2558,160,16,49,217,461,277,489,2064,256,357,413,0]

theorem envBound59119 : H12AffineFastState.Bounded env59119 := by
  intro p hp
  have h : env59119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59118_59119 : H12AffineEnvironment.transform 9 425 env59118 = env59119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59118 == env59119) = true)

theorem identity59119 : scanCanonicalize (H12AffineFastState.compose env59119 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59119 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59120 : List Nat := [2,4,8,16,32,64,128,256,0,425,49,136,41,216,97,494,413,81,424,97,428,32,65,463,160,16,49,217,461,277,489,33,256,357,413,0]

theorem envBound59120 : H12AffineFastState.Bounded env59120 := by
  intro p hp
  have h : env59120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59119_59120 : H12AffineEnvironment.transform 10 49 env59119 = env59120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59119 == env59120) = true)

theorem identity59120 : scanCanonicalize (H12AffineFastState.compose env59120 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59120 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59121 : List Nat := [2,4,8,16,32,64,115,256,0,346,49,123,41,43,97,285,366,81,347,97,351,32,65,316,83,16,49,42,318,277,282,33,256,357,366,0]

theorem envBound59121 : H12AffineFastState.Bounded env59121 := by
  intro p hp
  have h : env59121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59120_59121 : H12AffineEnvironment.transform 6 115 env59120 = env59121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59120 == env59121) = true)

theorem identity59121 : scanCanonicalize (H12AffineFastState.compose env59121 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59121 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59122 : List Nat := [2,4,8,16,32,64,115,69,0,31,49,123,41,43,97,88,43,81,30,97,26,32,65,121,83,16,49,42,123,80,95,33,69,32,43,0]

theorem envBound59122 : H12AffineFastState.Bounded env59122 := by
  intro p hp
  have h : env59122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59121_59122 : H12AffineEnvironment.transform 7 69 env59121 = env59122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59121 == env59122) = true)

def env59123 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2097152,1417,64,3159,1289,17,2361853,217,66955,66898,65543,68094,256,65675,67035,1]

theorem envBound59123 : H12AffineFastState.Bounded env59123 := by
  intro p hp
  have h : env59123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59114_59123 : H12AffineEnvironment.transform 12 1409 env59114 = env59123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59114 == env59123) = true)

theorem identity59123 : scanCanonicalize (H12AffineFastState.compose env59123 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2420) := by decide +kernel

theorem selectedBound59123 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59124 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2420,1417,64,3159,1289,17,262281,217,66955,66898,65543,68094,256,65675,67035,1]

theorem envBound59124 : H12AffineFastState.Bounded env59124 := by
  intro p hp
  have h : env59124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59123_59124 : H12AffineEnvironment.transform 20 2420 env59123 = env59124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2420 env59123 == env59124) = true)

theorem identity59124 : scanCanonicalize (H12AffineFastState.compose env59124 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59124 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59125 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1449,65536,67035,262144,1025,1449,1165,1417,64,430,1289,17,262281,217,66955,66898,65543,66567,256,65675,67035,1]

theorem envBound59125 : H12AffineFastState.Bounded env59125 := by
  intro p hp
  have h : env59125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59124_59125 : H12AffineEnvironment.transform 10 1529 env59124 = env59125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59124 == env59125) = true)

theorem identity59125 : scanCanonicalize (H12AffineFastState.compose env59125 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59125 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59126 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1449,65536,67035,1377,1025,1449,1165,1417,64,430,1289,17,1512,217,66955,66898,65543,66567,256,65675,67035,1]

theorem envBound59126 : H12AffineFastState.Bounded env59126 := by
  intro p hp
  have h : env59126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59125_59126 : H12AffineEnvironment.transform 17 1377 env59125 = env59126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59125 == env59126) = true)

theorem identity59126 : scanCanonicalize (H12AffineFastState.compose env59126 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59126 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59127 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1449,1062,509,1377,1025,1449,1165,1417,64,430,1289,17,1512,217,429,372,1057,33,256,1197,509,1]

theorem envBound59127 : H12AffineFastState.Bounded env59127 := by
  intro p hp
  have h : env59127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59126_59127 : H12AffineEnvironment.transform 15 1062 env59126 = env59127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59126 == env59127) = true)

theorem identity59127 : scanCanonicalize (H12AffineFastState.compose env59127 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59127 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59128 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,136,348,216,372,251,509,444,220,372,80,340,64,430,468,17,309,217,429,372,252,33,256,112,509,1]

theorem envBound59128 : H12AffineFastState.Bounded env59128 := by
  intro p hp
  have h : env59128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59127_59128 : H12AffineEnvironment.transform 9 221 env59127 = env59128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59127 == env59128) = true)

theorem identity59128 : scanCanonicalize (H12AffineFastState.compose env59128 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound59128 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59129 : List Nat := [2,4,8,16,32,64,128,5,0,221,33,136,89,216,113,251,248,185,220,113,80,81,64,171,209,17,48,217,168,113,252,33,5,112,248,1]

theorem envBound59129 : H12AffineFastState.Bounded env59129 := by
  intro p hp
  have h : env59129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59128_59129 : H12AffineEnvironment.transform 7 5 env59128 = env59129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env59128 == env59129) = true)

theorem identity59129 : scanCanonicalize (H12AffineFastState.compose env59129 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59129 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59130 : List Nat := [2,4,8,16,32,17,128,5,0,140,33,136,8,137,32,170,169,185,141,32,1,0,17,171,128,17,48,136,168,32,173,33,5,33,169,1]

theorem envBound59130 : H12AffineFastState.Bounded env59130 := by
  intro p hp
  have h : env59130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59129_59130 : H12AffineEnvironment.transform 5 17 env59129 = env59130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59129 == env59130) = true)

theorem identity59130 : scanCanonicalize (H12AffineFastState.compose env59130 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound59130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59131 : List Nat := [2,4,8,16,32,17,10,5,0,6,33,2,8,3,32,32,35,51,7,32,1,0,17,33,10,17,48,2,34,32,39,33,5,33,35,1]

theorem envBound59131 : H12AffineFastState.Bounded env59131 := by
  intro p hp
  have h : env59131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59130_59131 : H12AffineEnvironment.transform 6 10 env59130 = env59131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env59130 == env59131) = true)

theorem identity59131 : scanCanonicalize (H12AffineFastState.compose env59131 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59131 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59132 : List Nat := [2,4,1,16,32,17,3,5,0,6,33,2,1,3,32,32,35,51,7,32,1,0,17,33,3,17,48,2,34,32,39,33,5,33,35,1]

theorem envBound59132 : H12AffineFastState.Bounded env59132 := by
  intro p hp
  have h : env59132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59131_59132 : H12AffineEnvironment.transform 2 1 env59131 = env59132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59131 == env59132) = true)

theorem identity59132 : scanCanonicalize (H12AffineFastState.compose env59132 (packedSelected [3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59132 : packedSelected [3,5,9] rootPS < 2^1333 := by decide +kernel

def env59133 : List Nat := [2,4,1,16,17,17,3,5,0,6,16,2,1,3,17,17,18,2,7,17,1,0,17,16,3,17,1,2,19,17,22,16,5,16,18,1]

theorem envBound59133 : H12AffineFastState.Bounded env59133 := by
  intro p hp
  have h : env59133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59132_59133 : H12AffineEnvironment.transform 4 17 env59132 = env59133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59132 == env59133) = true)

theorem identity59133 : scanCanonicalize (H12AffineFastState.compose env59133 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59134 : List Nat := [2,4,1,1,0,0,3,5,0,6,1,2,1,3,0,0,3,2,7,0,1,0,0,1,3,0,1,2,2,0,7,1,5,1,3,1]

theorem envBound59134 : H12AffineFastState.Bounded env59134 := by
  intro p hp
  have h : env59134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59133_59134 : H12AffineEnvironment.transform 3 1 env59133 = env59134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59133 == env59134) = true)

def env59135 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound59135 : H12AffineFastState.Bounded env59135 := by
  intro p hp
  have h : env59135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59112_59135 : H12AffineEnvironment.transform 8 1 env59112 = env59135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59112 == env59135) = true)

theorem identity59135 : scanCanonicalize (H12AffineFastState.compose env59135 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound59135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59136 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,5385,4176,2129,65536,67035,262144,1025,2129,2097152,1417,4296,3158,1289,4249,2365812,4177,66955,66899,65543,68095,256,65675,67035,4232]

theorem envBound59136 : H12AffineFastState.Bounded env59136 := by
  intro p hp
  have h : env59136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59135_59136 : H12AffineEnvironment.transform 12 5385 env59135 = env59136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env59135 == env59136) = true)

def env59137 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2097152,1417,64,3158,1289,17,2361852,217,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound59137 : H12AffineFastState.Bounded env59137 := by
  intro p hp
  have h : env59137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59136_59137 : H12AffineEnvironment.transform 11 136 env59136 = env59137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59136 == env59137) = true)

theorem identity59137 : scanCanonicalize (H12AffineFastState.compose env59137 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2421) := by decide +kernel

theorem selectedBound59137 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59138 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2421,1417,64,3158,1289,17,262281,217,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound59138 : H12AffineFastState.Bounded env59138 := by
  intro p hp
  have h : env59138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59137_59138 : H12AffineEnvironment.transform 20 2421 env59137 = env59138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2421 env59137 == env59138) = true)

theorem identity59138 : scanCanonicalize (H12AffineFastState.compose env59138 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59138 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59139 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1449,65536,67035,262144,1025,1449,1165,1417,64,430,1289,17,262281,217,66955,66899,65543,66567,256,65675,67035,0]

theorem envBound59139 : H12AffineFastState.Bounded env59139 := by
  intro p hp
  have h : env59139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59138_59139 : H12AffineEnvironment.transform 10 1528 env59138 = env59139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59138 == env59139) = true)

theorem identity59139 : scanCanonicalize (H12AffineFastState.compose env59139 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59139 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59140 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1449,65536,67035,1377,1025,1449,1165,1417,64,430,1289,17,1512,217,66955,66899,65543,66567,256,65675,67035,0]

theorem envBound59140 : H12AffineFastState.Bounded env59140 := by
  intro p hp
  have h : env59140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59139_59140 : H12AffineEnvironment.transform 17 1377 env59139 = env59140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59139 == env59140) = true)

theorem identity59140 : scanCanonicalize (H12AffineFastState.compose env59140 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59140 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59141 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1449,1062,509,1377,1025,1449,1165,1417,64,430,1289,17,1512,217,429,373,1057,33,256,1197,509,0]

theorem envBound59141 : H12AffineFastState.Bounded env59141 := by
  intro p hp
  have h : env59141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59140_59141 : H12AffineEnvironment.transform 15 1062 env59140 = env59141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59140 == env59141) = true)

theorem identity59141 : scanCanonicalize (H12AffineFastState.compose env59141 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59141 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59142 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,136,349,216,373,250,509,445,221,373,81,341,64,430,469,17,308,217,429,373,253,33,256,113,509,0]

theorem envBound59142 : H12AffineFastState.Bounded env59142 := by
  intro p hp
  have h : env59142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59141_59142 : H12AffineEnvironment.transform 9 220 env59141 = env59142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59141 == env59142) = true)

theorem identity59142 : scanCanonicalize (H12AffineFastState.compose env59142 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59142 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59143 : List Nat := [2,4,8,16,32,32,128,256,1,188,292,136,317,184,277,154,413,445,189,277,49,309,32,430,437,17,308,185,429,277,157,33,256,17,413,0]

theorem envBound59143 : H12AffineFastState.Bounded env59143 := by
  intro p hp
  have h : env59143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59142_59143 : H12AffineEnvironment.transform 5 32 env59142 = env59143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59142 == env59143) = true)

theorem identity59143 : scanCanonicalize (H12AffineFastState.compose env59143 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59143 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59144 : List Nat := [2,4,8,16,32,32,9,256,1,53,292,1,317,49,277,19,276,308,52,277,49,309,32,295,316,17,308,48,292,277,20,33,256,17,276,0]

theorem envBound59144 : H12AffineFastState.Bounded env59144 := by
  intro p hp
  have h : env59144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59143_59144 : H12AffineEnvironment.transform 6 9 env59143 = env59144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59143 == env59144) = true)

theorem identity59144 : scanCanonicalize (H12AffineFastState.compose env59144 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound59144 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59145 : List Nat := [2,4,8,16,32,32,9,37,1,53,1,1,24,49,48,19,49,17,52,48,49,16,32,2,25,17,17,48,1,48,20,33,37,17,49,0]

theorem envBound59145 : H12AffineFastState.Bounded env59145 := by
  intro p hp
  have h : env59145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59144_59145 : H12AffineEnvironment.transform 7 37 env59144 = env59145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env59144 == env59145) = true)

theorem identity59145 : scanCanonicalize (H12AffineFastState.compose env59145 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59146 : List Nat := [2,4,8,2,32,32,9,37,1,39,1,1,10,35,34,1,35,3,38,34,35,2,32,2,11,3,3,34,1,34,6,33,37,3,35,0]

theorem envBound59146 : H12AffineFastState.Bounded env59146 := by
  intro p hp
  have h : env59146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59145_59146 : H12AffineEnvironment.transform 3 2 env59145 = env59146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59145 == env59146) = true)

theorem identity59146 : scanCanonicalize (H12AffineFastState.compose env59146 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59146 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59147 : List Nat := [2,4,3,2,32,32,2,37,1,39,1,1,1,35,34,1,35,3,38,34,35,2,32,2,0,3,3,34,1,34,6,33,37,3,35,0]

theorem envBound59147 : H12AffineFastState.Bounded env59147 := by
  intro p hp
  have h : env59147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59146_59147 : H12AffineEnvironment.transform 2 3 env59146 = env59147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59146 == env59147) = true)

theorem identity59147 : scanCanonicalize (H12AffineFastState.compose env59147 (packedSelected [1,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59147 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59148 : List Nat := [1,4,0,1,32,32,1,37,1,36,1,1,1,32,33,1,32,0,37,33,32,1,32,1,0,0,0,33,1,33,5,33,37,0,32,0]

theorem envBound59148 : H12AffineFastState.Bounded env59148 := by
  intro p hp
  have h : env59148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59147_59148 : H12AffineEnvironment.transform 0 1 env59147 = env59148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59147 == env59148) = true)

def env59149 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2129,65536,67035,262144,1025,2129,2097152,1417,65,3158,1289,16,2361853,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound59149 : H12AffineFastState.Bounded env59149 := by
  intro p hp
  have h : env59149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59136_59149 : H12AffineEnvironment.transform 11 137 env59136 = env59149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59136 == env59149) = true)

theorem identity59149 : scanCanonicalize (H12AffineFastState.compose env59149 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound59149 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59150 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2129,65536,67035,262144,1025,2129,67699,1417,65,3158,1289,16,328078,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound59150 : H12AffineFastState.Bounded env59150 := by
  intro p hp
  have h : env59150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59149_59150 : H12AffineEnvironment.transform 20 67699 env59149 = env59150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env59149 == env59150) = true)

theorem identity59150 : scanCanonicalize (H12AffineFastState.compose env59150 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59150 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59151 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2129,65536,67035,65982,1025,2129,67699,1417,65,3158,1289,16,48,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound59151 : H12AffineFastState.Bounded env59151 := by
  intro p hp
  have h : env59151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59150_59151 : H12AffineEnvironment.transform 17 65982 env59150 = env59151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59150 == env59151) = true)

theorem identity59151 : scanCanonicalize (H12AffineFastState.compose env59151 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59151 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59152 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2129,1095,412,1529,1025,2129,3124,1417,65,3158,1289,16,48,216,460,276,1088,3512,256,1228,412,1]

theorem envBound59152 : H12AffineFastState.Bounded env59152 := by
  intro p hp
  have h : env59152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59151_59152 : H12AffineEnvironment.transform 15 1095 env59151 = env59152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59151 == env59152) = true)

theorem identity59152 : scanCanonicalize (H12AffineFastState.compose env59152 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59152 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59153 : List Nat := [2,4,8,16,32,64,128,256,1,1024,373,137,1408,217,292,1095,412,1529,1025,292,1345,1417,65,1315,1289,16,48,216,460,276,1088,1229,256,1228,412,1]

theorem envBound59153 : H12AffineFastState.Bounded env59153 := by
  intro p hp
  have h : env59153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59152_59153 : H12AffineEnvironment.transform 10 373 env59152 = env59153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59152 == env59153) = true)

theorem identity59153 : scanCanonicalize (H12AffineFastState.compose env59153 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59153 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59154 : List Nat := [2,4,8,16,32,64,128,69,1,1024,48,137,1221,217,97,1095,217,1212,1025,97,1028,1228,65,1126,1100,16,48,216,137,81,1088,1229,69,1228,217,1]

theorem envBound59154 : H12AffineFastState.Bounded env59154 := by
  intro p hp
  have h : env59154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59153_59154 : H12AffineEnvironment.transform 7 69 env59153 = env59154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59153 == env59154) = true)

def env59155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397000,8388689,6561533,4177,77954,4260571,8463814,8465982,256,4261123,78034,8389185]

theorem envBound59155 : H12AffineFastState.Bounded env59155 := by
  intro p hp
  have h : env59155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58984_59155 : H12AffineEnvironment.transform 26 6561533 env58984 = env59155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env58984 == env59155) = true)

def env59156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399766,8397000,8388689,2366325,4177,77954,67411,8463814,8465982,256,65675,78034,8389185]

theorem envBound59156 : H12AffineFastState.Bounded env59156 := by
  intro p hp
  have h : env59156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59155_59156 : H12AffineEnvironment.transform 21 1416 env59155 = env59156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59155 == env59156) = true)

def env59157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3670,1288,9617,2366325,4177,77954,67411,65542,68606,256,65675,78034,10113]

theorem envBound59157 : H12AffineFastState.Bounded env59157 := by
  intro p hp
  have h : env59157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59156_59157 : H12AffineEnvironment.transform 22 9664 env59156 = env59157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59156 == env59157) = true)

def env59158 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1288,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59158 : H12AffineFastState.Bounded env59158 := by
  intro p hp
  have h : env59158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59157_59158 : H12AffineEnvironment.transform 8 0 env59157 = env59158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59157 == env59158) = true)

theorem identity59158 : scanCanonicalize (H12AffineFastState.compose env59158 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 67698) := by decide +kernel

theorem selectedBound59158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59159 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,67698,1416,9664,3158,1288,9617,332039,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59159 : H12AffineFastState.Bounded env59159 := by
  intro p hp
  have h : env59159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59158_59159 : H12AffineEnvironment.transform 20 67698 env59158 = env59159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67698 env59158 == env59159) = true)

def env59160 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,67698,1416,64,3158,1288,17,332039,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound59160 : H12AffineFastState.Bounded env59160 := by
  intro p hp
  have h : env59160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59159_59160 : H12AffineEnvironment.transform 12 1408 env59159 = env59160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59159 == env59160) = true)

theorem identity59160 : scanCanonicalize (H12AffineFastState.compose env59160 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59160 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59161 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4494,1244,262144,1025,2128,6652,1416,64,3158,1288,17,262281,4177,1164,5341,4488,6256,256,4357,1244,1]

theorem envBound59161 : H12AffineFastState.Bounded env59161 := by
  intro p hp
  have h : env59161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59160_59161 : H12AffineEnvironment.transform 15 4494 env59160 = env59161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59160 == env59161) = true)

theorem identity59161 : scanCanonicalize (H12AffineFastState.compose env59161 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59161 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59162 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,4494,1244,262144,1025,1448,5124,1416,64,430,1288,17,262281,4177,1164,5341,4488,5512,256,4357,1244,1]

theorem envBound59162 : H12AffineFastState.Bounded env59162 := by
  intro p hp
  have h : env59162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59161_59162 : H12AffineEnvironment.transform 10 1528 env59161 = env59162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59161 == env59162) = true)

theorem identity59162 : scanCanonicalize (H12AffineFastState.compose env59162 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59162 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59163 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,4494,1244,5609,1025,1448,5124,1416,64,430,1288,17,5472,4177,1164,5341,4488,5512,256,4357,1244,1]

theorem envBound59163 : H12AffineFastState.Bounded env59163 := by
  intro p hp
  have h : env59163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59162_59163 : H12AffineEnvironment.transform 17 5609 env59162 = env59163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59162 == env59163) = true)

theorem identity59163 : scanCanonicalize (H12AffineFastState.compose env59163 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59163 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59164 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1449,1408,1529,1448,1063,1244,64,1025,1448,429,1416,64,430,1288,17,201,1528,1164,372,1057,33,256,1196,1244,1]

theorem envBound59164 : H12AffineFastState.Bounded env59164 := by
  intro p hp
  have h : env59164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59163_59164 : H12AffineEnvironment.transform 11 1449 env59163 = env59164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59163 == env59164) = true)

theorem identity59164 : scanCanonicalize (H12AffineFastState.compose env59164 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59164 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59165 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,373,348,293,372,251,0,64,221,372,429,340,64,430,468,17,201,292,80,372,253,33,256,112,0,1]

theorem envBound59165 : H12AffineFastState.Bounded env59165 := by
  intro p hp
  have h : env59165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59164_59165 : H12AffineEnvironment.transform 9 220 env59164 = env59165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59164 == env59165) = true)

theorem identity59165 : scanCanonicalize (H12AffineFastState.compose env59165 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59165 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59166 : List Nat := [2,4,8,16,32,64,128,173,0,220,137,216,241,136,217,251,0,64,221,217,0,249,64,3,121,17,201,137,80,217,253,33,173,112,0,1]

theorem envBound59166 : H12AffineFastState.Bounded env59166 := by
  intro p hp
  have h : env59166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59165_59166 : H12AffineEnvironment.transform 7 173 env59165 = env59166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59165 == env59166) = true)

theorem identity59166 : scanCanonicalize (H12AffineFastState.compose env59166 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59166 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59167 : List Nat := [2,4,8,16,32,64,105,68,0,53,96,49,24,97,48,18,0,64,52,48,0,16,64,3,121,17,32,96,80,48,20,33,68,112,0,1]

theorem envBound59167 : H12AffineFastState.Bounded env59167 := by
  intro p hp
  have h : env59167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59166_59167 : H12AffineEnvironment.transform 6 105 env59166 = env59167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59166 == env59167) = true)

theorem identity59167 : scanCanonicalize (H12AffineFastState.compose env59167 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound59167 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env59168 : List Nat := [2,4,8,16,26,64,83,68,0,15,90,11,24,91,10,18,0,64,14,10,0,16,64,3,67,17,26,90,80,10,20,27,68,74,0,1]

theorem envBound59168 : H12AffineFastState.Bounded env59168 := by
  intro p hp
  have h : env59168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59167_59168 : H12AffineEnvironment.transform 4 26 env59167 = env59168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env59167 == env59168) = true)

theorem identity59168 : scanCanonicalize (H12AffineFastState.compose env59168 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59169 : List Nat := [2,4,8,0,10,64,67,68,0,15,74,11,8,75,10,2,0,64,14,10,0,0,64,3,67,1,10,74,64,10,4,11,68,74,0,1]

theorem envBound59169 : H12AffineFastState.Bounded env59169 := by
  intro p hp
  have h : env59169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59168_59169 : H12AffineEnvironment.transform 3 0 env59168 = env59169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59168 == env59169) = true)

theorem identity59169 : scanCanonicalize (H12AffineFastState.compose env59169 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound59169 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59170 : List Nat := [2,4,8,0,10,8,11,12,0,15,2,11,8,3,10,2,0,8,14,10,0,0,8,3,11,1,10,2,8,10,4,11,12,2,0,1]

theorem envBound59170 : H12AffineFastState.Bounded env59170 := by
  intro p hp
  have h : env59170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59169_59170 : H12AffineEnvironment.transform 5 8 env59169 = env59170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env59169 == env59170) = true)

theorem identity59170 : scanCanonicalize (H12AffineFastState.compose env59170 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59170 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59171 : List Nat := [2,4,3,0,1,3,0,7,0,4,2,0,3,3,1,2,0,3,5,1,0,0,3,3,0,1,1,2,3,1,4,0,7,2,0,1]

theorem envBound59171 : H12AffineFastState.Bounded env59171 := by
  intro p hp
  have h : env59171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59170_59171 : H12AffineEnvironment.transform 2 3 env59170 = env59171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59170 == env59171) = true)

def env59172 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,67698,1416,65,3158,1288,16,332039,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound59172 : H12AffineFastState.Bounded env59172 := by
  intro p hp
  have h : env59172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59159_59172 : H12AffineEnvironment.transform 12 1409 env59159 = env59172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59159 == env59172) = true)

theorem identity59172 : scanCanonicalize (H12AffineFastState.compose env59172 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59172 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59173 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2128,65536,67034,262144,1025,2128,67698,1416,65,3158,1288,16,328078,216,66954,66899,65542,68094,256,65675,67034,0]

theorem envBound59173 : H12AffineFastState.Bounded env59173 := by
  intro p hp
  have h : env59173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59172_59173 : H12AffineEnvironment.transform 11 137 env59172 = env59173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59172 == env59173) = true)

theorem identity59173 : scanCanonicalize (H12AffineFastState.compose env59173 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound59173 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59174 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2128,65536,67034,65983,1025,2128,67698,1416,65,3158,1288,16,49,216,66954,66899,65542,68094,256,65675,67034,0]

theorem envBound59174 : H12AffineFastState.Bounded env59174 := by
  intro p hp
  have h : env59174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59173_59174 : H12AffineEnvironment.transform 17 65983 env59173 = env59174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env59173 == env59174) = true)

theorem identity59174 : scanCanonicalize (H12AffineFastState.compose env59174 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound59174 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59175 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2128,1094,412,1529,1025,2128,3124,1416,65,3158,1288,16,49,216,460,277,1088,3512,256,1229,412,0]

theorem envBound59175 : H12AffineFastState.Bounded env59175 := by
  intro p hp
  have h : env59175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59174_59175 : H12AffineEnvironment.transform 15 1094 env59174 = env59175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env59174 == env59175) = true)

theorem identity59175 : scanCanonicalize (H12AffineFastState.compose env59175 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59175 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59176 : List Nat := [2,4,8,16,32,64,128,256,0,424,2048,137,41,217,2128,494,412,81,425,2128,2460,32,65,2558,160,16,49,216,460,277,488,2064,256,357,412,0]

theorem envBound59176 : H12AffineFastState.Bounded env59176 := by
  intro p hp
  have h : env59176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59175_59176 : H12AffineEnvironment.transform 9 424 env59175 = env59176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59175 == env59176) = true)

theorem identity59176 : scanCanonicalize (H12AffineFastState.compose env59176 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59176 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59177 : List Nat := [2,4,8,16,32,64,128,256,0,424,49,137,41,217,97,494,412,81,425,97,429,32,65,463,160,16,49,216,460,277,488,33,256,357,412,0]

theorem envBound59177 : H12AffineFastState.Bounded env59177 := by
  intro p hp
  have h : env59177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59176_59177 : H12AffineEnvironment.transform 10 49 env59176 = env59177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59176 == env59177) = true)

theorem identity59177 : scanCanonicalize (H12AffineFastState.compose env59177 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59177 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59178 : List Nat := [2,4,8,16,32,64,115,256,0,347,49,122,41,42,97,285,367,81,346,97,350,32,65,316,83,16,49,43,319,277,283,33,256,357,367,0]

theorem envBound59178 : H12AffineFastState.Bounded env59178 := by
  intro p hp
  have h : env59178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59177_59178 : H12AffineEnvironment.transform 6 115 env59177 = env59178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59177 == env59178) = true)

theorem identity59178 : scanCanonicalize (H12AffineFastState.compose env59178 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59178 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59179 : List Nat := [2,4,8,16,32,64,115,69,0,30,49,122,41,42,97,88,42,81,31,97,27,32,65,121,83,16,49,43,122,80,94,33,69,32,42,0]

theorem envBound59179 : H12AffineFastState.Bounded env59179 := by
  intro p hp
  have h : env59179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59178_59179 : H12AffineEnvironment.transform 7 69 env59178 = env59179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59178 == env59179) = true)

def env59180 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1288,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59180 : H12AffineFastState.Bounded env59180 := by
  intro p hp
  have h : env59180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59157_59180 : H12AffineEnvironment.transform 8 1 env59157 = env59180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59157 == env59180) = true)

theorem identity59180 : scanCanonicalize (H12AffineFastState.compose env59180 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 77299) := by decide +kernel

theorem selectedBound59180 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59181 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,77299,1416,9664,3159,1288,9617,341127,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59181 : H12AffineFastState.Bounded env59181 := by
  intro p hp
  have h : env59181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59180_59181 : H12AffineEnvironment.transform 20 77299 env59180 = env59181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77299 env59180 == env59181) = true)

def env59182 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,67699,1416,64,3159,1288,17,332039,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound59182 : H12AffineFastState.Bounded env59182 := by
  intro p hp
  have h : env59182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59181_59182 : H12AffineEnvironment.transform 12 1408 env59181 = env59182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59181 == env59182) = true)

theorem identity59182 : scanCanonicalize (H12AffineFastState.compose env59182 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59182 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59183 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4494,1244,262144,1025,2129,6653,1416,64,3159,1288,17,262281,4177,1164,5340,4488,6257,256,4357,1244,0]

theorem envBound59183 : H12AffineFastState.Bounded env59183 := by
  intro p hp
  have h : env59183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59182_59183 : H12AffineEnvironment.transform 15 4494 env59182 = env59183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59182 == env59183) = true)

theorem identity59183 : scanCanonicalize (H12AffineFastState.compose env59183 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59183 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59184 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,4494,1244,262144,1025,1448,5124,1416,64,430,1288,17,262281,4177,1164,5340,4488,5512,256,4357,1244,0]

theorem envBound59184 : H12AffineFastState.Bounded env59184 := by
  intro p hp
  have h : env59184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59183_59184 : H12AffineEnvironment.transform 10 1529 env59183 = env59184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59183 == env59184) = true)

theorem identity59184 : scanCanonicalize (H12AffineFastState.compose env59184 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59184 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59185 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,4494,1244,5609,1025,1448,5124,1416,64,430,1288,17,5472,4177,1164,5340,4488,5512,256,4357,1244,0]

theorem envBound59185 : H12AffineFastState.Bounded env59185 := by
  intro p hp
  have h : env59185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59184_59185 : H12AffineEnvironment.transform 17 5609 env59184 = env59185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59184 == env59185) = true)

theorem identity59185 : scanCanonicalize (H12AffineFastState.compose env59185 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59185 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59186 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1449,1408,1529,1448,1063,1244,64,1025,1448,429,1416,64,430,1288,17,201,1528,1164,373,1057,33,256,1196,1244,0]

theorem envBound59186 : H12AffineFastState.Bounded env59186 := by
  intro p hp
  have h : env59186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59185_59186 : H12AffineEnvironment.transform 11 1449 env59185 = env59186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59185 == env59186) = true)

theorem identity59186 : scanCanonicalize (H12AffineFastState.compose env59186 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59186 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59187 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,372,349,292,373,250,1,64,220,373,429,341,64,430,469,17,201,293,81,373,252,33,256,113,1,0]

theorem envBound59187 : H12AffineFastState.Bounded env59187 := by
  intro p hp
  have h : env59187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59186_59187 : H12AffineEnvironment.transform 9 221 env59186 = env59187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59186 == env59187) = true)

theorem identity59187 : scanCanonicalize (H12AffineFastState.compose env59187 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59187 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59188 : List Nat := [2,4,8,16,32,16,128,256,1,141,292,292,269,292,293,170,1,16,140,293,429,261,16,430,389,17,153,293,1,293,172,33,256,33,1,0]

theorem envBound59188 : H12AffineFastState.Bounded env59188 := by
  intro p hp
  have h : env59188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59187_59188 : H12AffineEnvironment.transform 5 16 env59187 = env59188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59187 == env59188) = true)

theorem identity59188 : scanCanonicalize (H12AffineFastState.compose env59188 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 174) := by decide +kernel

theorem selectedBound59188 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59189 : List Nat := [2,4,8,16,32,16,128,174,1,141,138,138,163,138,139,170,1,16,140,139,3,171,16,0,43,17,153,139,1,139,172,33,174,33,1,0]

theorem envBound59189 : H12AffineFastState.Bounded env59189 := by
  intro p hp
  have h : env59189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59188_59189 : H12AffineEnvironment.transform 7 174 env59188 = env59189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 174 env59188 == env59189) = true)

theorem identity59189 : scanCanonicalize (H12AffineFastState.compose env59189 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59189 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59190 : List Nat := [2,4,8,16,2,16,128,140,1,141,138,138,129,138,139,136,1,16,140,139,3,137,16,0,9,17,153,139,1,139,142,3,140,3,1,0]

theorem envBound59190 : H12AffineFastState.Bounded env59190 := by
  intro p hp
  have h : env59190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59189_59190 : H12AffineEnvironment.transform 4 2 env59189 = env59190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59189 == env59190) = true)

theorem identity59190 : scanCanonicalize (H12AffineFastState.compose env59190 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound59190 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59191 : List Nat := [2,4,8,16,2,16,18,30,1,31,24,24,19,24,25,26,1,16,30,25,3,27,16,0,9,17,11,25,1,25,28,3,30,3,1,0]

theorem envBound59191 : H12AffineFastState.Bounded env59191 := by
  intro p hp
  have h : env59191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59190_59191 : H12AffineEnvironment.transform 6 18 env59190 = env59191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env59190 == env59191) = true)

theorem identity59191 : scanCanonicalize (H12AffineFastState.compose env59191 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59191 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env59192 : List Nat := [2,4,8,0,2,0,2,14,1,15,8,8,3,8,9,10,1,0,14,9,3,11,0,0,9,1,11,9,1,9,12,3,14,3,1,0]

theorem envBound59192 : H12AffineFastState.Bounded env59192 := by
  intro p hp
  have h : env59192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59191_59192 : H12AffineEnvironment.transform 3 0 env59191 = env59192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59191 == env59192) = true)

theorem identity59192 : scanCanonicalize (H12AffineFastState.compose env59192 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59193 : List Nat := [2,4,0,0,2,0,2,6,1,7,0,0,3,0,1,2,1,0,6,1,3,3,0,0,1,1,3,1,1,1,4,3,6,3,1,0]

theorem envBound59193 : H12AffineFastState.Bounded env59193 := by
  intro p hp
  have h : env59193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59192_59193 : H12AffineEnvironment.transform 2 0 env59192 = env59193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59192 == env59193) = true)

theorem identity59193 : scanCanonicalize (H12AffineFastState.compose env59193 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59194 : List Nat := [1,4,0,0,1,0,1,5,1,4,0,0,0,0,1,1,1,0,5,1,0,0,0,0,1,1,0,1,1,1,4,0,5,0,1,0]

theorem envBound59194 : H12AffineFastState.Bounded env59194 := by
  intro p hp
  have h : env59194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59193_59194 : H12AffineEnvironment.transform 0 1 env59193 = env59194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59193 == env59194) = true)

def env59195 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,67698,1416,65,3159,1288,16,332038,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound59195 : H12AffineFastState.Bounded env59195 := by
  intro p hp
  have h : env59195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59181_59195 : H12AffineEnvironment.transform 12 1409 env59181 = env59195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59181 == env59195) = true)

theorem identity59195 : scanCanonicalize (H12AffineFastState.compose env59195 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59195 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59196 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,67698,1416,65,3159,1288,16,328078,217,66955,66898,65542,68095,256,65675,67035,1]

theorem envBound59196 : H12AffineFastState.Bounded env59196 := by
  intro p hp
  have h : env59196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59195_59196 : H12AffineEnvironment.transform 11 136 env59195 = env59196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59195 == env59196) = true)

theorem identity59196 : scanCanonicalize (H12AffineFastState.compose env59196 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59196 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59197 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,65982,1025,2129,67698,1416,65,3159,1288,16,48,217,66955,66898,65542,68095,256,65675,67035,1]

theorem envBound59197 : H12AffineFastState.Bounded env59197 := by
  intro p hp
  have h : env59197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59196_59197 : H12AffineEnvironment.transform 17 65982 env59196 = env59197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59196 == env59197) = true)

theorem identity59197 : scanCanonicalize (H12AffineFastState.compose env59197 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound59197 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59198 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,1094,413,1528,1025,2129,3124,1416,65,3159,1288,16,48,217,461,276,1088,3513,256,1229,413,1]

theorem envBound59198 : H12AffineFastState.Bounded env59198 := by
  intro p hp
  have h : env59198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59197_59198 : H12AffineEnvironment.transform 15 1094 env59197 = env59198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env59197 == env59198) = true)

theorem identity59198 : scanCanonicalize (H12AffineFastState.compose env59198 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59198 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59199 : List Nat := [2,4,8,16,32,64,128,256,1,1024,373,136,1409,216,292,1094,413,1528,1025,292,1345,1416,65,1314,1288,16,48,217,461,276,1088,1228,256,1229,413,1]

theorem envBound59199 : H12AffineFastState.Bounded env59199 := by
  intro p hp
  have h : env59199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59198_59199 : H12AffineEnvironment.transform 10 373 env59198 = env59199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59198 == env59199) = true)

theorem identity59199 : scanCanonicalize (H12AffineFastState.compose env59199 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59199 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59200 : List Nat := [2,4,8,16,32,64,128,69,1,1024,48,136,1220,216,97,1094,216,1213,1025,97,1028,1229,65,1127,1101,16,48,217,136,81,1088,1228,69,1229,216,1]

theorem envBound59200 : H12AffineFastState.Bounded env59200 := by
  intro p hp
  have h : env59200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59199_59200 : H12AffineEnvironment.transform 7 69 env59199 = env59200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59199 == env59200) = true)

theorem identity59200 : scanCanonicalize (H12AffineFastState.compose env59200 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59200 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59201 : List Nat := [2,4,8,16,32,64,128,69,1,236,48,136,40,216,97,170,216,81,237,97,232,33,65,139,161,16,48,217,136,81,172,32,69,33,216,1]

theorem envBound59201 : H12AffineFastState.Bounded env59201 := by
  intro p hp
  have h : env59201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59200_59201 : H12AffineEnvironment.transform 9 236 env59200 = env59201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59200 == env59201) = true)

theorem identity59201 : scanCanonicalize (H12AffineFastState.compose env59201 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59201 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59202 : List Nat := [2,4,8,16,32,64,9,69,1,101,48,1,40,81,97,35,81,81,100,97,97,33,65,2,40,16,48,80,1,81,37,32,69,33,81,1]

theorem envBound59202 : H12AffineFastState.Bounded env59202 := by
  intro p hp
  have h : env59202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59201_59202 : H12AffineEnvironment.transform 6 9 env59201 = env59202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59201 == env59202) = true)

theorem identity59202 : scanCanonicalize (H12AffineFastState.compose env59202 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59202 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59203 : List Nat := [2,4,8,16,32,11,9,14,1,46,48,1,40,26,42,35,26,26,47,42,42,33,10,2,40,16,48,27,1,26,37,32,14,33,26,1]

theorem envBound59203 : H12AffineFastState.Bounded env59203 := by
  intro p hp
  have h : env59203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59202_59203 : H12AffineEnvironment.transform 5 11 env59202 = env59203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59202 == env59203) = true)

theorem identity59203 : scanCanonicalize (H12AffineFastState.compose env59203 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59203 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59204 : List Nat := [2,4,8,16,17,11,9,14,1,31,1,1,25,26,27,18,26,26,30,27,27,16,10,2,25,16,1,27,1,26,20,17,14,16,26,1]

theorem envBound59204 : H12AffineFastState.Bounded env59204 := by
  intro p hp
  have h : env59204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59203_59204 : H12AffineEnvironment.transform 4 17 env59203 = env59204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59203 == env59204) = true)

def env59205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3671,1289,9616,2366325,4177,77954,67411,65543,68607,256,65675,78034,10112]

theorem envBound59205 : H12AffineFastState.Bounded env59205 := by
  intro p hp
  have h : env59205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59156_59205 : H12AffineEnvironment.transform 22 9665 env59156 = env59205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59156 == env59205) = true)

def env59206 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound59206 : H12AffineFastState.Bounded env59206 := by
  intro p hp
  have h : env59206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59205_59206 : H12AffineEnvironment.transform 8 0 env59205 = env59206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59205 == env59206) = true)

theorem identity59206 : scanCanonicalize (H12AffineFastState.compose env59206 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 13731) := by decide +kernel

theorem selectedBound59206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59207 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,13731,1393,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365813,4177,1313,12528,13732,15452,256,13608,1393,9600]

theorem envBound59207 : H12AffineFastState.Bounded env59207 := by
  intro p hp
  have h : env59207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59206_59207 : H12AffineEnvironment.transform 15 13731 env59206 = env59207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13731 env59206 == env59207) = true)

def env59208 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4131,1393,262144,1025,2128,2097152,1416,65,3159,1289,16,2365813,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound59208 : H12AffineFastState.Bounded env59208 := by
  intro p hp
  have h : env59208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59207_59208 : H12AffineEnvironment.transform 12 1408 env59207 = env59208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59207 == env59208) = true)

theorem identity59208 : scanCanonicalize (H12AffineFastState.compose env59208 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59208 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59209 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4131,1393,262144,1025,2128,2265,1416,65,3159,1289,16,266668,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound59209 : H12AffineFastState.Bounded env59209 := by
  intro p hp
  have h : env59209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59208_59209 : H12AffineEnvironment.transform 20 2265 env59208 = env59209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59208 == env59209) = true)

theorem identity59209 : scanCanonicalize (H12AffineFastState.compose env59209 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59209 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59210 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4131,1393,277,1025,2128,2265,1416,65,3159,1289,16,4281,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound59210 : H12AffineFastState.Bounded env59210 := by
  intro p hp
  have h : env59210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59209_59210 : H12AffineEnvironment.transform 17 277 env59209 = env59210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59209 == env59210) = true)

theorem identity59210 : scanCanonicalize (H12AffineFastState.compose env59210 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59210 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59211 : List Nat := [2,4,8,16,32,64,128,256,0,237,2048,4096,365,4176,2128,4131,412,277,236,2128,2265,357,65,2234,484,16,4281,4177,460,4509,4132,6620,256,4264,412,0]

theorem envBound59211 : H12AffineFastState.Bounded env59211 := by
  intro p hp
  have h : env59211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59210_59211 : H12AffineEnvironment.transform 9 237 env59210 = env59211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59210 == env59211) = true)

theorem identity59211 : scanCanonicalize (H12AffineFastState.compose env59211 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59211 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59212 : List Nat := [2,4,8,16,32,64,128,256,0,237,373,4096,365,4176,293,4131,412,277,236,293,428,357,65,463,484,16,4281,4177,460,4509,4132,4265,256,4264,412,0]

theorem envBound59212 : H12AffineFastState.Bounded env59212 := by
  intro p hp
  have h : env59212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59211_59212 : H12AffineEnvironment.transform 10 373 env59211 = env59212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59211 == env59212) = true)

theorem identity59212 : scanCanonicalize (H12AffineFastState.compose env59212 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59212 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59213 : List Nat := [2,4,8,16,32,64,128,256,0,237,373,460,365,412,293,495,412,277,236,293,428,357,65,463,484,16,373,413,460,81,488,357,256,356,412,0]

theorem envBound59213 : H12AffineFastState.Bounded env59213 := by
  intro p hp
  have h : env59213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59212_59213 : H12AffineEnvironment.transform 11 460 env59212 = env59213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59212 == env59213) = true)

theorem identity59213 : scanCanonicalize (H12AffineFastState.compose env59213 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59213 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59214 : List Nat := [2,4,8,16,32,64,128,68,0,237,49,136,41,216,97,171,216,81,236,97,232,33,65,139,160,16,49,217,136,81,172,33,68,32,216,0]

theorem envBound59214 : H12AffineFastState.Bounded env59214 := by
  intro p hp
  have h : env59214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59213_59214 : H12AffineEnvironment.transform 7 68 env59213 = env59214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59213 == env59214) = true)

theorem identity59214 : scanCanonicalize (H12AffineFastState.compose env59214 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59214 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59215 : List Nat := [2,4,8,16,32,64,9,68,0,100,49,1,41,81,97,34,81,81,101,97,97,33,65,2,41,16,49,80,1,81,37,33,68,32,81,0]

theorem envBound59215 : H12AffineFastState.Bounded env59215 := by
  intro p hp
  have h : env59215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59214_59215 : H12AffineEnvironment.transform 6 9 env59214 = env59215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59214 == env59215) = true)

theorem identity59215 : scanCanonicalize (H12AffineFastState.compose env59215 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59215 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59216 : List Nat := [2,4,8,16,32,10,9,14,0,46,49,1,41,27,43,34,27,27,47,43,43,33,11,2,41,16,49,26,1,27,37,33,14,32,27,0]

theorem envBound59216 : H12AffineFastState.Bounded env59216 := by
  intro p hp
  have h : env59216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59215_59216 : H12AffineEnvironment.transform 5 10 env59215 = env59216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59215 == env59216) = true)

theorem identity59216 : scanCanonicalize (H12AffineFastState.compose env59216 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59216 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59217 : List Nat := [2,4,8,16,16,10,9,14,0,30,1,1,25,27,27,18,27,27,31,27,27,17,11,2,25,16,1,26,1,27,21,17,14,16,27,0]

theorem envBound59217 : H12AffineFastState.Bounded env59217 := by
  intro p hp
  have h : env59217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59216_59217 : H12AffineEnvironment.transform 4 16 env59216 = env59217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59216 == env59217) = true)

def env59218 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2097152,1416,64,3159,1289,17,2365813,4177,1313,5489,4133,6621,256,4265,1393,1]

theorem envBound59218 : H12AffineFastState.Bounded env59218 := by
  intro p hp
  have h : env59218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59207_59218 : H12AffineEnvironment.transform 12 1409 env59207 = env59218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59207 == env59218) = true)

theorem identity59218 : scanCanonicalize (H12AffineFastState.compose env59218 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59218 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59219 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,6652,1416,64,3159,1289,17,262281,4177,1313,5489,4133,6621,256,4265,1393,1]

theorem envBound59219 : H12AffineFastState.Bounded env59219 := by
  intro p hp
  have h : env59219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59218_59219 : H12AffineEnvironment.transform 20 6652 env59218 = env59219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59218 == env59219) = true)

theorem identity59219 : scanCanonicalize (H12AffineFastState.compose env59219 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59219 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59220 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,4130,1393,262144,1025,1448,5124,1416,64,431,1289,17,262281,4177,1313,5489,4133,5157,256,4265,1393,1]

theorem envBound59220 : H12AffineFastState.Bounded env59220 := by
  intro p hp
  have h : env59220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59219_59220 : H12AffineEnvironment.transform 10 1528 env59219 = env59220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59219 == env59220) = true)

theorem identity59220 : scanCanonicalize (H12AffineFastState.compose env59220 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59220 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59221 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,4130,1393,5609,1025,1448,5124,1416,64,431,1289,17,5472,4177,1313,5489,4133,5157,256,4265,1393,1]

theorem envBound59221 : H12AffineFastState.Bounded env59221 := by
  intro p hp
  have h : env59221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59220_59221 : H12AffineEnvironment.transform 17 5609 env59220 = env59221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59220 == env59221) = true)

theorem identity59221 : scanCanonicalize (H12AffineFastState.compose env59221 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59221 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59222 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1029,1409,1109,1448,1063,1393,492,1025,1448,1,1416,64,431,1289,17,357,1108,1313,372,1056,32,256,1196,1393,1]

theorem envBound59222 : H12AffineFastState.Bounded env59222 := by
  intro p hp
  have h : env59222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59221_59222 : H12AffineEnvironment.transform 11 1029 env59221 = env59222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59221 == env59222) = true)

theorem identity59222 : scanCanonicalize (H12AffineFastState.compose env59222 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59222 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59223 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,217,349,137,372,251,429,492,221,372,1,340,64,431,469,17,357,136,509,372,252,32,256,112,429,1]

theorem envBound59223 : H12AffineFastState.Bounded env59223 := by
  intro p hp
  have h : env59223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59222_59223 : H12AffineEnvironment.transform 9 220 env59222 = env59223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59222 == env59223) = true)

theorem identity59223 : scanCanonicalize (H12AffineFastState.compose env59223 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59223 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59224 : List Nat := [2,4,8,16,32,16,128,256,0,140,292,137,269,137,292,171,429,444,141,292,1,260,16,431,389,17,309,136,429,292,172,32,256,32,429,1]

theorem envBound59224 : H12AffineFastState.Bounded env59224 := by
  intro p hp
  have h : env59224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59223_59224 : H12AffineEnvironment.transform 5 16 env59223 = env59224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59223 == env59224) = true)

theorem identity59224 : scanCanonicalize (H12AffineFastState.compose env59224 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 190) := by decide +kernel

theorem selectedBound59224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59225 : List Nat := [2,4,8,16,32,16,128,190,0,140,154,137,179,137,154,171,19,2,141,154,1,186,16,17,59,17,139,136,19,154,172,32,190,32,19,1]

theorem envBound59225 : H12AffineFastState.Bounded env59225 := by
  intro p hp
  have h : env59225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59224_59225 : H12AffineEnvironment.transform 7 190 env59224 = env59225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 190 env59224 == env59225) = true)

theorem identity59225 : scanCanonicalize (H12AffineFastState.compose env59225 (packedSelected [3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound59225 : packedSelected [3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59226 : List Nat := [2,4,8,16,32,16,40,22,0,36,50,33,27,33,50,3,19,2,37,50,1,18,16,17,59,17,35,32,19,50,4,32,22,32,19,1]

theorem envBound59226 : H12AffineFastState.Bounded env59226 := by
  intro p hp
  have h : env59226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59225_59226 : H12AffineEnvironment.transform 6 40 env59225 = env59226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env59225 == env59226) = true)

theorem identity59226 : scanCanonicalize (H12AffineFastState.compose env59226 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59226 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59227 : List Nat := [2,4,8,16,10,16,2,22,0,14,24,11,27,11,24,3,19,2,15,24,1,18,16,17,17,17,9,10,19,24,4,10,22,10,19,1]

theorem envBound59227 : H12AffineFastState.Bounded env59227 := by
  intro p hp
  have h : env59227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59226_59227 : H12AffineEnvironment.transform 4 10 env59226 = env59227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59226 == env59227) = true)

theorem identity59227 : scanCanonicalize (H12AffineFastState.compose env59227 (packedSelected [1,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59227 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59228 : List Nat := [2,4,3,16,1,16,2,22,0,5,19,0,16,0,19,3,19,2,4,19,1,18,16,17,17,17,2,1,19,19,4,1,22,1,19,1]

theorem envBound59228 : H12AffineFastState.Bounded env59228 := by
  intro p hp
  have h : env59228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59227_59228 : H12AffineEnvironment.transform 2 3 env59227 = env59228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59227 == env59228) = true)

theorem identity59228 : scanCanonicalize (H12AffineFastState.compose env59228 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59228 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59229 : List Nat := [2,4,3,1,1,1,2,7,0,5,2,0,1,0,2,3,2,2,4,2,1,3,1,0,0,0,2,1,2,2,4,1,7,1,2,1]

theorem envBound59229 : H12AffineFastState.Bounded env59229 := by
  intro p hp
  have h : env59229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59228_59229 : H12AffineEnvironment.transform 3 1 env59228 = env59229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59228 == env59229) = true)

theorem identity59229 : scanCanonicalize (H12AffineFastState.compose env59229 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59229 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59230 : List Nat := [1,4,0,1,1,1,1,4,0,5,1,0,1,0,1,0,1,1,4,1,1,0,1,0,0,0,1,1,1,1,4,1,4,1,1,1]

theorem envBound59230 : H12AffineFastState.Bounded env59230 := by
  intro p hp
  have h : env59230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59229_59230 : H12AffineEnvironment.transform 0 1 env59229 = env59230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59229 == env59230) = true)

def env59231 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound59231 : H12AffineFastState.Bounded env59231 := by
  intro p hp
  have h : env59231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59205_59231 : H12AffineEnvironment.transform 8 1 env59205 = env59231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59205 == env59231) = true)

theorem identity59231 : scanCanonicalize (H12AffineFastState.compose env59231 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59232 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,4130,8432,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365812,4177,8352,5488,4133,6620,256,4265,8432,9601]

theorem envBound59232 : H12AffineFastState.Bounded env59232 := by
  intro p hp
  have h : env59232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59231_59232 : H12AffineEnvironment.transform 15 4130 env59231 = env59232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59231 == env59232) = true)

def env59233 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4130,1392,262144,1025,2129,2097152,1416,65,3158,1289,16,2365812,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound59233 : H12AffineFastState.Bounded env59233 := by
  intro p hp
  have h : env59233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59232_59233 : H12AffineEnvironment.transform 12 1408 env59232 = env59233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59232 == env59233) = true)

theorem identity59233 : scanCanonicalize (H12AffineFastState.compose env59233 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59233 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59234 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4130,1392,262144,1025,2129,2265,1416,65,3158,1289,16,266669,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound59234 : H12AffineFastState.Bounded env59234 := by
  intro p hp
  have h : env59234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59233_59234 : H12AffineEnvironment.transform 20 2265 env59233 = env59234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59233 == env59234) = true)

theorem identity59234 : scanCanonicalize (H12AffineFastState.compose env59234 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59234 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59235 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4130,1392,276,1025,2129,2265,1416,65,3158,1289,16,4281,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound59235 : H12AffineFastState.Bounded env59235 := by
  intro p hp
  have h : env59235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59234_59235 : H12AffineEnvironment.transform 17 276 env59234 = env59235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59234 == env59235) = true)

theorem identity59235 : scanCanonicalize (H12AffineFastState.compose env59235 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59235 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59236 : List Nat := [2,4,8,16,32,64,128,256,1,237,2048,4096,365,4176,2129,4130,413,276,236,2129,2265,357,65,2235,484,16,4281,4177,461,4509,4133,6620,256,4265,413,1]

theorem envBound59236 : H12AffineFastState.Bounded env59236 := by
  intro p hp
  have h : env59236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59235_59236 : H12AffineEnvironment.transform 9 237 env59235 = env59236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59235 == env59236) = true)

theorem identity59236 : scanCanonicalize (H12AffineFastState.compose env59236 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59236 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59237 : List Nat := [2,4,8,16,32,64,128,69,1,237,2048,4096,40,4176,2129,4130,216,81,236,2129,2265,32,65,2235,161,16,4281,4177,136,4312,4133,6297,69,4265,216,1]

theorem envBound59237 : H12AffineFastState.Bounded env59237 := by
  intro p hp
  have h : env59237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59236_59237 : H12AffineEnvironment.transform 7 69 env59236 = env59237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59236 == env59237) = true)

theorem identity59237 : scanCanonicalize (H12AffineFastState.compose env59237 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound59237 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59238 : List Nat := [2,4,8,16,32,64,128,69,1,237,2048,2233,40,2281,2129,2203,216,81,236,2129,2265,32,65,2235,161,16,2048,2280,136,2145,2204,32,69,2064,216,1]

theorem envBound59238 : H12AffineFastState.Bounded env59238 := by
  intro p hp
  have h : env59238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59237_59238 : H12AffineEnvironment.transform 11 2233 env59237 = env59238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env59237 == env59238) = true)

theorem identity59238 : scanCanonicalize (H12AffineFastState.compose env59238 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound59238 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59239 : List Nat := [2,4,8,16,32,64,128,69,1,237,195,122,40,42,146,88,216,81,236,146,26,32,65,120,161,16,195,43,136,162,95,32,69,211,216,1]

theorem envBound59239 : H12AffineFastState.Bounded env59239 := by
  intro p hp
  have h : env59239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59238_59239 : H12AffineEnvironment.transform 10 195 env59238 = env59239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env59238 == env59239) = true)

theorem identity59239 : scanCanonicalize (H12AffineFastState.compose env59239 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59239 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59240 : List Nat := [2,4,8,16,32,64,114,69,1,31,49,122,40,42,96,88,42,81,30,96,26,32,65,120,83,16,49,43,122,80,95,32,69,33,42,1]

theorem envBound59240 : H12AffineFastState.Bounded env59240 := by
  intro p hp
  have h : env59240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59239_59240 : H12AffineEnvironment.transform 6 114 env59239 = env59240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59239 == env59240) = true)

def env59241 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2097152,1416,64,3158,1289,17,2365812,4177,1313,5488,4133,6620,256,4265,1393,0]

theorem envBound59241 : H12AffineFastState.Bounded env59241 := by
  intro p hp
  have h : env59241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59232_59241 : H12AffineEnvironment.transform 12 1409 env59232 = env59241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59232 == env59241) = true)

theorem identity59241 : scanCanonicalize (H12AffineFastState.compose env59241 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59241 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59242 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,6653,1416,64,3158,1289,17,262281,4177,1313,5488,4133,6620,256,4265,1393,0]

theorem envBound59242 : H12AffineFastState.Bounded env59242 := by
  intro p hp
  have h : env59242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59241_59242 : H12AffineEnvironment.transform 20 6653 env59241 = env59242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59241 == env59242) = true)

theorem identity59242 : scanCanonicalize (H12AffineFastState.compose env59242 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59242 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59243 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,4130,1393,262144,1025,1448,5124,1416,64,431,1289,17,262281,4177,1313,5488,4133,5157,256,4265,1393,0]

theorem envBound59243 : H12AffineFastState.Bounded env59243 := by
  intro p hp
  have h : env59243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59242_59243 : H12AffineEnvironment.transform 10 1529 env59242 = env59243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59242 == env59243) = true)

theorem identity59243 : scanCanonicalize (H12AffineFastState.compose env59243 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59243 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59244 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,4130,1393,5609,1025,1448,5124,1416,64,431,1289,17,5472,4177,1313,5488,4133,5157,256,4265,1393,0]

theorem envBound59244 : H12AffineFastState.Bounded env59244 := by
  intro p hp
  have h : env59244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59243_59244 : H12AffineEnvironment.transform 17 5609 env59243 = env59244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59243 == env59244) = true)

theorem identity59244 : scanCanonicalize (H12AffineFastState.compose env59244 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59244 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59245 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1029,1409,1109,1448,1063,1393,492,1025,1448,1,1416,64,431,1289,17,357,1108,1313,373,1056,32,256,1196,1393,0]

theorem envBound59245 : H12AffineFastState.Bounded env59245 := by
  intro p hp
  have h : env59245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59244_59245 : H12AffineEnvironment.transform 11 1029 env59244 = env59245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59244 == env59245) = true)

theorem identity59245 : scanCanonicalize (H12AffineFastState.compose env59245 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59245 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59246 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,216,348,136,373,250,428,492,220,373,1,341,64,431,468,17,357,137,508,373,253,32,256,113,428,0]

theorem envBound59246 : H12AffineFastState.Bounded env59246 := by
  intro p hp
  have h : env59246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59245_59246 : H12AffineEnvironment.transform 9 221 env59245 = env59246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59245 == env59246) = true)

theorem identity59246 : scanCanonicalize (H12AffineFastState.compose env59246 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59246 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59247 : List Nat := [2,4,8,16,32,64,128,173,1,221,137,216,241,136,216,250,1,65,220,216,1,248,64,2,121,17,200,137,81,216,253,32,173,113,1,0]

theorem envBound59247 : H12AffineFastState.Bounded env59247 := by
  intro p hp
  have h : env59247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59246_59247 : H12AffineEnvironment.transform 7 173 env59246 = env59247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59246 == env59247) = true)

theorem identity59247 : scanCanonicalize (H12AffineFastState.compose env59247 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59247 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59248 : List Nat := [2,4,8,16,0,64,128,141,1,221,137,216,209,136,216,218,1,65,220,216,1,216,64,2,89,17,200,137,81,216,221,0,141,81,1,0]

theorem envBound59248 : H12AffineFastState.Bounded env59248 := by
  intro p hp
  have h : env59248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59247_59248 : H12AffineEnvironment.transform 4 0 env59247 = env59248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59247 == env59248) = true)

theorem identity59248 : scanCanonicalize (H12AffineFastState.compose env59248 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound59248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59249 : List Nat := [2,4,8,16,0,64,19,30,1,78,26,75,66,27,75,73,1,65,79,75,1,75,64,2,89,17,91,26,81,75,78,0,30,81,1,0]

theorem envBound59249 : H12AffineFastState.Bounded env59249 := by
  intro p hp
  have h : env59249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59248_59249 : H12AffineEnvironment.transform 6 19 env59248 = env59249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env59248 == env59249) = true)

def env59250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399766,8397000,8388689,2366324,4177,77954,67410,8463814,8465982,256,65674,78034,8389185]

theorem envBound59250 : H12AffineFastState.Bounded env59250 := by
  intro p hp
  have h : env59250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59155_59250 : H12AffineEnvironment.transform 21 1417 env59155 = env59250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59155 == env59250) = true)

def env59251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3670,1288,9617,2366324,4177,77954,67410,65542,68606,256,65674,78034,10113]

theorem envBound59251 : H12AffineFastState.Bounded env59251 := by
  intro p hp
  have h : env59251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59250_59251 : H12AffineEnvironment.transform 22 9664 env59250 = env59251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59250 == env59251) = true)

def env59252 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1288,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59252 : H12AffineFastState.Bounded env59252 := by
  intro p hp
  have h : env59252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59251_59252 : H12AffineEnvironment.transform 8 0 env59251 = env59252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59251 == env59252) = true)

theorem identity59252 : scanCanonicalize (H12AffineFastState.compose env59252 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 74030) := by decide +kernel

theorem selectedBound59252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59253 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,74030,1417,9664,3158,1288,9617,342106,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59253 : H12AffineFastState.Bounded env59253 := by
  intro p hp
  have h : env59253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59252_59253 : H12AffineEnvironment.transform 20 74030 env59252 = env59253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74030 env59252 == env59253) = true)

def env59254 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,66734,1417,64,3158,1288,17,335322,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound59254 : H12AffineFastState.Bounded env59254 := by
  intro p hp
  have h : env59254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59253_59254 : H12AffineEnvironment.transform 12 1408 env59253 = env59254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59253 == env59254) = true)

theorem identity59254 : scanCanonicalize (H12AffineFastState.compose env59254 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7507) := by decide +kernel

theorem selectedBound59254 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59255 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7507,2049,262144,1025,2128,6653,1417,64,3158,1288,17,262281,4177,2129,6145,7509,5293,256,7641,2049,1]

theorem envBound59255 : H12AffineFastState.Bounded env59255 := by
  intro p hp
  have h : env59255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59254_59255 : H12AffineEnvironment.transform 15 7507 env59254 = env59255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7507 env59254 == env59255) = true)

theorem identity59255 : scanCanonicalize (H12AffineFastState.compose env59255 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59255 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59256 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,4267,1529,262144,1025,1448,5125,1417,64,430,1288,17,262281,4177,1449,5625,4269,5293,256,4129,1529,1]

theorem envBound59256 : H12AffineFastState.Bounded env59256 := by
  intro p hp
  have h : env59256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59255_59256 : H12AffineEnvironment.transform 10 1528 env59255 = env59256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59255 == env59256) = true)

theorem identity59256 : scanCanonicalize (H12AffineFastState.compose env59256 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59256 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59257 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,4267,1529,5609,1025,1448,5125,1417,64,430,1288,17,5472,4177,1449,5625,4269,5293,256,4129,1529,1]

theorem envBound59257 : H12AffineFastState.Bounded env59257 := by
  intro p hp
  have h : env59257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59256_59257 : H12AffineEnvironment.transform 17 5609 env59256 = env59257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59256 == env59257) = true)

theorem identity59257 : scanCanonicalize (H12AffineFastState.compose env59257 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59257 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59258 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1164,1408,1244,1448,1063,1529,357,1025,1448,137,1417,64,430,1288,17,492,1245,1449,373,1057,33,256,1197,1529,1]

theorem envBound59258 : H12AffineFastState.Bounded env59258 := by
  intro p hp
  have h : env59258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59257_59258 : H12AffineEnvironment.transform 11 1164 env59257 = env59258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59257 == env59258) = true)

theorem identity59258 : scanCanonicalize (H12AffineFastState.compose env59258 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59258 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59259 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,81,349,1,373,250,292,357,220,373,137,340,64,430,469,17,492,0,372,373,252,33,256,112,292,1]

theorem envBound59259 : H12AffineFastState.Bounded env59259 := by
  intro p hp
  have h : env59259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59258_59259 : H12AffineEnvironment.transform 9 221 env59258 = env59259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59258 == env59259) = true)

theorem identity59259 : scanCanonicalize (H12AffineFastState.compose env59259 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59259 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59260 : List Nat := [2,4,8,16,32,64,128,173,0,221,136,81,240,1,216,250,137,200,220,216,137,249,64,3,120,17,65,0,217,216,252,33,173,112,137,1]

theorem envBound59260 : H12AffineFastState.Bounded env59260 := by
  intro p hp
  have h : env59260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59259_59260 : H12AffineEnvironment.transform 7 173 env59259 = env59260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59259 == env59260) = true)

theorem identity59260 : scanCanonicalize (H12AffineFastState.compose env59260 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59260 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59261 : List Nat := [2,4,8,16,32,64,105,68,0,52,97,81,25,1,49,19,96,33,53,49,96,16,64,3,120,17,65,0,48,49,21,33,68,112,96,1]

theorem envBound59261 : H12AffineFastState.Bounded env59261 := by
  intro p hp
  have h : env59261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59260_59261 : H12AffineEnvironment.transform 6 105 env59260 = env59261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59260 == env59261) = true)

theorem identity59261 : scanCanonicalize (H12AffineFastState.compose env59261 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 50) := by decide +kernel

theorem selectedBound59261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59262 : List Nat := [2,4,8,16,32,50,27,54,0,52,19,35,25,1,49,19,18,33,53,49,18,16,50,3,10,17,51,0,48,49,21,33,54,2,18,1]

theorem envBound59262 : H12AffineFastState.Bounded env59262 := by
  intro p hp
  have h : env59262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59261_59262 : H12AffineEnvironment.transform 5 50 env59261 = env59262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 50 env59261 == env59262) = true)

theorem identity59262 : scanCanonicalize (H12AffineFastState.compose env59262 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59262 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env59263 : List Nat := [2,4,3,16,32,50,16,54,0,52,19,35,18,1,49,19,18,33,53,49,18,16,50,3,1,17,51,0,48,49,21,33,54,2,18,1]

theorem envBound59263 : H12AffineFastState.Bounded env59263 := by
  intro p hp
  have h : env59263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59262_59263 : H12AffineEnvironment.transform 2 3 env59262 = env59263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59262 == env59263) = true)

theorem identity59263 : scanCanonicalize (H12AffineFastState.compose env59263 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59263 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59264 : List Nat := [2,4,3,1,32,35,1,39,0,37,2,35,3,1,32,2,3,33,36,32,3,1,35,3,1,0,34,0,33,32,4,33,39,2,3,1]

theorem envBound59264 : H12AffineFastState.Bounded env59264 := by
  intro p hp
  have h : env59264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59263_59264 : H12AffineEnvironment.transform 3 1 env59263 = env59264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59263 == env59264) = true)

theorem identity59264 : scanCanonicalize (H12AffineFastState.compose env59264 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59264 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59265 : List Nat := [1,4,0,1,32,32,1,36,0,37,1,32,0,1,32,1,0,33,36,32,0,1,32,0,1,0,33,0,33,32,4,33,36,1,0,1]

theorem envBound59265 : H12AffineFastState.Bounded env59265 := by
  intro p hp
  have h : env59265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59264_59265 : H12AffineEnvironment.transform 0 1 env59264 = env59265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59264 == env59265) = true)

def env59266 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,66735,1417,65,3158,1288,16,335323,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound59266 : H12AffineFastState.Bounded env59266 := by
  intro p hp
  have h : env59266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59253_59266 : H12AffineEnvironment.transform 12 1409 env59253 = env59266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59253 == env59266) = true)

theorem identity59266 : scanCanonicalize (H12AffineFastState.compose env59266 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59266 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59267 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,66735,1417,65,3158,1288,16,328079,3077,67927,66898,65542,68094,256,65674,67847,0]

theorem envBound59267 : H12AffineFastState.Bounded env59267 := by
  intro p hp
  have h : env59267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59266_59267 : H12AffineEnvironment.transform 11 3156 env59266 = env59267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59266 == env59267) = true)

theorem identity59267 : scanCanonicalize (H12AffineFastState.compose env59267 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59267 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59268 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,68963,1025,2128,66735,1417,65,3158,1288,16,3308,3077,67927,66898,65542,68094,256,65674,67847,0]

theorem envBound59268 : H12AffineFastState.Bounded env59268 := by
  intro p hp
  have h : env59268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59267_59268 : H12AffineEnvironment.transform 17 68963 env59267 = env59268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59267 == env59268) = true)

theorem identity59268 : scanCanonicalize (H12AffineFastState.compose env59268 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59268 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59269 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,2202,413,1529,1025,2128,3125,1417,65,3158,1288,16,3308,3077,461,3528,2204,356,256,2064,413,0]

theorem envBound59269 : H12AffineFastState.Bounded env59269 := by
  intro p hp
  have h : env59269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59268_59269 : H12AffineEnvironment.transform 15 2202 env59268 = env59269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59268 == env59269) = true)

theorem identity59269 : scanCanonicalize (H12AffineFastState.compose env59269 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59269 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59270 : List Nat := [2,4,8,16,32,64,128,256,0,425,2048,2557,40,2477,2128,2202,413,80,424,2128,2460,32,65,2559,161,16,2373,2476,461,2145,2204,356,256,2064,413,0]

theorem envBound59270 : H12AffineFastState.Bounded env59270 := by
  intro p hp
  have h : env59270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59269_59270 : H12AffineEnvironment.transform 9 425 env59269 = env59270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59269 == env59270) = true)

theorem identity59270 : scanCanonicalize (H12AffineFastState.compose env59270 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59270 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59271 : List Nat := [2,4,8,16,32,64,128,69,0,236,2048,2232,40,2280,2128,2202,216,80,237,2128,2265,32,65,2234,161,16,2048,2281,136,2145,2204,33,69,2064,216,0]

theorem envBound59271 : H12AffineFastState.Bounded env59271 := by
  intro p hp
  have h : env59271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59270_59271 : H12AffineEnvironment.transform 7 69 env59270 = env59271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59270 == env59271) = true)

theorem identity59271 : scanCanonicalize (H12AffineFastState.compose env59271 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59271 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59272 : List Nat := [2,4,8,16,32,64,115,69,0,31,2048,2123,40,2075,2128,2153,43,80,30,2128,2090,32,65,2121,82,16,2048,2074,123,2145,2159,33,69,2064,43,0]

theorem envBound59272 : H12AffineFastState.Bounded env59272 := by
  intro p hp
  have h : env59272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59271_59272 : H12AffineEnvironment.transform 6 115 env59271 = env59272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59271 == env59272) = true)

def env59273 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1288,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59273 : H12AffineFastState.Bounded env59273 := by
  intro p hp
  have h : env59273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59251_59273 : H12AffineEnvironment.transform 8 1 env59251 = env59273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59251 == env59273) = true)

theorem identity59273 : scanCanonicalize (H12AffineFastState.compose env59273 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59273 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59274 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,66734,1417,9664,3159,1288,9617,335323,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59274 : H12AffineFastState.Bounded env59274 := by
  intro p hp
  have h : env59274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59273_59274 : H12AffineEnvironment.transform 20 66734 env59273 = env59274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59273 == env59274) = true)

def env59275 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,66734,1417,64,3159,1288,17,335323,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound59275 : H12AffineFastState.Bounded env59275 := by
  intro p hp
  have h : env59275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59274_59275 : H12AffineEnvironment.transform 12 1408 env59274 = env59275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59274 == env59275) = true)

theorem identity59275 : scanCanonicalize (H12AffineFastState.compose env59275 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7506) := by decide +kernel

theorem selectedBound59275 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59276 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7506,2048,262144,1025,2129,6652,1417,64,3159,1288,17,262281,4177,2128,6145,7508,5293,256,7640,2048,0]

theorem envBound59276 : H12AffineFastState.Bounded env59276 := by
  intro p hp
  have h : env59276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59275_59276 : H12AffineEnvironment.transform 15 7506 env59275 = env59276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7506 env59275 == env59276) = true)

theorem identity59276 : scanCanonicalize (H12AffineFastState.compose env59276 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59276 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59277 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,4267,1529,262144,1025,1448,5125,1417,64,430,1288,17,262281,4177,1449,5624,4269,5293,256,4129,1529,0]

theorem envBound59277 : H12AffineFastState.Bounded env59277 := by
  intro p hp
  have h : env59277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59276_59277 : H12AffineEnvironment.transform 10 1529 env59276 = env59277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59276 == env59277) = true)

theorem identity59277 : scanCanonicalize (H12AffineFastState.compose env59277 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59277 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59278 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,4267,1529,5609,1025,1448,5125,1417,64,430,1288,17,5472,4177,1449,5624,4269,5293,256,4129,1529,0]

theorem envBound59278 : H12AffineFastState.Bounded env59278 := by
  intro p hp
  have h : env59278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59277_59278 : H12AffineEnvironment.transform 17 5609 env59277 = env59278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59277 == env59278) = true)

theorem identity59278 : scanCanonicalize (H12AffineFastState.compose env59278 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59278 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59279 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1164,1408,1244,1448,1063,1529,357,1025,1448,137,1417,64,430,1288,17,492,1245,1449,372,1057,33,256,1197,1529,0]

theorem envBound59279 : H12AffineFastState.Bounded env59279 := by
  intro p hp
  have h : env59279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59278_59279 : H12AffineEnvironment.transform 11 1164 env59278 = env59279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59278 == env59279) = true)

theorem identity59279 : scanCanonicalize (H12AffineFastState.compose env59279 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59279 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59280 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,80,348,0,372,251,293,357,221,372,137,341,64,430,468,17,492,1,373,372,253,33,256,113,293,0]

theorem envBound59280 : H12AffineFastState.Bounded env59280 := by
  intro p hp
  have h : env59280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59279_59280 : H12AffineEnvironment.transform 9 220 env59279 = env59280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59279 == env59280) = true)

theorem identity59280 : scanCanonicalize (H12AffineFastState.compose env59280 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59280 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59281 : List Nat := [2,4,8,16,32,16,128,256,1,140,293,0,268,0,292,171,293,309,141,292,137,261,16,430,388,17,444,1,293,292,173,33,256,33,293,0]

theorem envBound59281 : H12AffineFastState.Bounded env59281 := by
  intro p hp
  have h : env59281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59280_59281 : H12AffineEnvironment.transform 5 16 env59280 = env59281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59280 == env59281) = true)

theorem identity59281 : scanCanonicalize (H12AffineFastState.compose env59281 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound59281 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59282 : List Nat := [2,4,8,16,32,16,41,256,1,37,293,0,268,0,292,2,293,309,36,292,32,261,16,263,301,17,277,1,293,292,4,33,256,33,293,0]

theorem envBound59282 : H12AffineFastState.Bounded env59282 := by
  intro p hp
  have h : env59282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59281_59282 : H12AffineEnvironment.transform 6 41 env59281 = env59282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env59281 == env59282) = true)

theorem identity59282 : scanCanonicalize (H12AffineFastState.compose env59282 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 13) := by decide +kernel

theorem selectedBound59282 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59283 : List Nat := [2,4,8,16,32,16,41,13,1,37,40,0,1,0,41,2,40,56,36,41,32,8,16,10,32,17,24,1,40,41,4,33,13,33,40,0]

theorem envBound59283 : H12AffineFastState.Bounded env59283 := by
  intro p hp
  have h : env59283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59282_59283 : H12AffineEnvironment.transform 7 13 env59282 = env59283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 13 env59282 == env59283) = true)

theorem identity59283 : scanCanonicalize (H12AffineFastState.compose env59283 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59283 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59284 : List Nat := [2,4,2,16,32,16,35,7,1,37,34,0,1,0,35,2,34,50,36,35,32,2,16,0,32,17,18,1,34,35,4,33,7,33,34,0]

theorem envBound59284 : H12AffineFastState.Bounded env59284 := by
  intro p hp
  have h : env59284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59283_59284 : H12AffineEnvironment.transform 2 2 env59283 = env59284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59283 == env59284) = true)

def env59285 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,66734,1417,65,3159,1288,16,335323,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound59285 : H12AffineFastState.Bounded env59285 := by
  intro p hp
  have h : env59285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59274_59285 : H12AffineEnvironment.transform 12 1409 env59274 = env59285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59274 == env59285) = true)

theorem identity59285 : scanCanonicalize (H12AffineFastState.compose env59285 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59285 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59286 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,66734,1417,65,3159,1288,16,328079,3077,67927,66899,65542,68095,256,65674,67847,1]

theorem envBound59286 : H12AffineFastState.Bounded env59286 := by
  intro p hp
  have h : env59286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59285_59286 : H12AffineEnvironment.transform 11 3156 env59285 = env59286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59285 == env59286) = true)

theorem identity59286 : scanCanonicalize (H12AffineFastState.compose env59286 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59286 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59287 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,68963,1025,2129,66734,1417,65,3159,1288,16,3308,3077,67927,66899,65542,68095,256,65674,67847,1]

theorem envBound59287 : H12AffineFastState.Bounded env59287 := by
  intro p hp
  have h : env59287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59286_59287 : H12AffineEnvironment.transform 17 68963 env59286 = env59287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59286 == env59287) = true)

theorem identity59287 : scanCanonicalize (H12AffineFastState.compose env59287 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59287 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59288 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,2203,412,1528,1025,2129,3125,1417,65,3159,1288,16,3308,3077,460,3528,2205,356,256,2065,412,1]

theorem envBound59288 : H12AffineFastState.Bounded env59288 := by
  intro p hp
  have h : env59288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59287_59288 : H12AffineEnvironment.transform 15 2203 env59287 = env59288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59287 == env59288) = true)

theorem identity59288 : scanCanonicalize (H12AffineFastState.compose env59288 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound59288 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59289 : List Nat := [2,4,8,16,32,64,128,256,1,1024,372,1312,1409,1392,293,495,412,1528,1025,293,1345,1417,65,1315,1288,16,1432,1393,460,1212,489,356,256,357,412,1]

theorem envBound59289 : H12AffineFastState.Bounded env59289 := by
  intro p hp
  have h : env59289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59288_59289 : H12AffineEnvironment.transform 10 372 env59288 = env59289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env59288 == env59289) = true)

theorem identity59289 : scanCanonicalize (H12AffineFastState.compose env59289 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59289 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59290 : List Nat := [2,4,8,16,32,64,128,256,1,236,372,460,365,412,293,495,412,276,237,293,429,357,65,463,484,16,372,413,460,80,489,356,256,357,412,1]

theorem envBound59290 : H12AffineFastState.Bounded env59290 := by
  intro p hp
  have h : env59290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59289_59290 : H12AffineEnvironment.transform 9 236 env59289 = env59290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59289 == env59290) = true)

theorem identity59290 : scanCanonicalize (H12AffineFastState.compose env59290 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59290 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59291 : List Nat := [2,4,8,16,32,64,128,68,1,236,48,136,41,216,97,171,216,80,237,97,233,33,65,139,160,16,48,217,136,80,173,32,68,33,216,1]

theorem envBound59291 : H12AffineFastState.Bounded env59291 := by
  intro p hp
  have h : env59291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59290_59291 : H12AffineEnvironment.transform 7 68 env59290 = env59291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59290 == env59291) = true)

theorem identity59291 : scanCanonicalize (H12AffineFastState.compose env59291 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59291 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59292 : List Nat := [2,4,8,16,32,64,9,68,1,101,48,1,41,81,97,34,81,80,100,97,96,33,65,2,41,16,48,80,1,80,36,32,68,33,81,1]

theorem envBound59292 : H12AffineFastState.Bounded env59292 := by
  intro p hp
  have h : env59292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59291_59292 : H12AffineEnvironment.transform 6 9 env59291 = env59292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59291 == env59292) = true)

theorem identity59292 : scanCanonicalize (H12AffineFastState.compose env59292 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59292 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59293 : List Nat := [2,4,8,16,32,10,9,14,1,47,48,1,41,27,43,34,27,26,46,43,42,33,11,2,41,16,48,26,1,26,36,32,14,33,27,1]

theorem envBound59293 : H12AffineFastState.Bounded env59293 := by
  intro p hp
  have h : env59293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59292_59293 : H12AffineEnvironment.transform 5 10 env59292 = env59293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59292 == env59293) = true)

theorem identity59293 : scanCanonicalize (H12AffineFastState.compose env59293 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59293 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59294 : List Nat := [2,4,8,16,17,10,9,14,1,30,1,1,24,27,26,19,27,26,31,26,27,16,11,2,24,16,1,26,1,26,21,17,14,16,27,1]

theorem envBound59294 : H12AffineFastState.Bounded env59294 := by
  intro p hp
  have h : env59294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59293_59294 : H12AffineEnvironment.transform 4 17 env59293 = env59294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59293 == env59294) = true)

theorem identity59294 : scanCanonicalize (H12AffineFastState.compose env59294 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59295 : List Nat := [2,4,8,10,11,10,9,14,1,4,1,1,2,1,0,9,1,0,5,0,1,10,11,2,2,10,1,0,1,0,15,11,14,10,1,1]

theorem envBound59295 : H12AffineFastState.Bounded env59295 := by
  intro p hp
  have h : env59295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59294_59295 : H12AffineEnvironment.transform 3 10 env59294 = env59295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59294 == env59295) = true)

def env59296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3671,1289,9616,2366324,4177,77954,67410,65543,68607,256,65674,78034,10112]

theorem envBound59296 : H12AffineFastState.Bounded env59296 := by
  intro p hp
  have h : env59296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59250_59296 : H12AffineEnvironment.transform 22 9665 env59250 = env59296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59250 == env59296) = true)

def env59297 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound59297 : H12AffineFastState.Bounded env59297 := by
  intro p hp
  have h : env59297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59296_59297 : H12AffineEnvironment.transform 8 0 env59296 = env59297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59296 == env59297) = true)

theorem identity59297 : scanCanonicalize (H12AffineFastState.compose env59297 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59298 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,7422,11308,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365812,4177,11388,6572,7417,5377,256,7284,11308,9600]

theorem envBound59298 : H12AffineFastState.Bounded env59298 := by
  intro p hp
  have h : env59298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59297_59298 : H12AffineEnvironment.transform 15 7422 env59297 = env59298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59297 == env59298) = true)

def env59299 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,2097152,1417,65,3159,1289,16,2365812,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound59299 : H12AffineFastState.Bounded env59299 := by
  intro p hp
  have h : env59299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59298_59299 : H12AffineEnvironment.transform 12 1408 env59298 = env59299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59298 == env59299) = true)

theorem identity59299 : scanCanonicalize (H12AffineFastState.compose env59299 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59299 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59300 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,1028,1417,65,3159,1289,16,269680,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound59300 : H12AffineFastState.Bounded env59300 := by
  intro p hp
  have h : env59300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59299_59300 : H12AffineEnvironment.transform 20 1028 env59299 = env59300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59299 == env59300) = true)

theorem identity59300 : scanCanonicalize (H12AffineFastState.compose env59300 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59300 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59301 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,3529,1025,2128,1028,1417,65,3159,1289,16,4281,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound59301 : H12AffineFastState.Bounded env59301 := by
  intro p hp
  have h : env59301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59300_59301 : H12AffineEnvironment.transform 17 3529 env59300 = env59301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59300 == env59301) = true)

theorem identity59301 : scanCanonicalize (H12AffineFastState.compose env59301 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59301 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59302 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,4096,1408,4176,97,5327,413,1528,1025,97,1028,1417,65,1126,1289,16,4281,4177,461,4509,5320,5377,256,5189,413,0]

theorem envBound59302 : H12AffineFastState.Bounded env59302 := by
  intro p hp
  have h : env59302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59301_59302 : H12AffineEnvironment.transform 10 49 env59301 = env59302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59301 == env59302) = true)

theorem identity59302 : scanCanonicalize (H12AffineFastState.compose env59302 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59302 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59303 : List Nat := [2,4,8,16,32,64,128,69,0,1024,49,4096,1221,4176,97,5327,216,1213,1025,97,1028,1228,65,1126,1100,16,4281,4177,136,4312,5320,5188,69,5189,216,0]

theorem envBound59303 : H12AffineFastState.Bounded env59303 := by
  intro p hp
  have h : env59303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59302_59303 : H12AffineEnvironment.transform 7 69 env59302 = env59303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59302 == env59303) = true)

theorem identity59303 : scanCanonicalize (H12AffineFastState.compose env59303 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59303 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59304 : List Nat := [2,4,8,16,32,64,128,69,0,1024,49,136,1221,216,97,1095,216,1213,1025,97,1028,1228,65,1126,1100,16,49,217,136,80,1088,1228,69,1229,216,0]

theorem envBound59304 : H12AffineFastState.Bounded env59304 := by
  intro p hp
  have h : env59304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59303_59304 : H12AffineEnvironment.transform 11 136 env59303 = env59304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59303 == env59304) = true)

theorem identity59304 : scanCanonicalize (H12AffineFastState.compose env59304 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59304 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59305 : List Nat := [2,4,8,16,32,64,128,69,0,237,49,136,40,216,97,170,216,80,236,97,233,33,65,139,161,16,49,217,136,80,173,33,69,32,216,0]

theorem envBound59305 : H12AffineFastState.Bounded env59305 := by
  intro p hp
  have h : env59305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59304_59305 : H12AffineEnvironment.transform 9 237 env59304 = env59305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59304 == env59305) = true)

theorem identity59305 : scanCanonicalize (H12AffineFastState.compose env59305 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59305 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59306 : List Nat := [2,4,8,16,32,64,9,69,0,100,49,1,40,81,97,35,81,80,101,97,96,33,65,2,40,16,49,80,1,80,36,33,69,32,81,0]

theorem envBound59306 : H12AffineFastState.Bounded env59306 := by
  intro p hp
  have h : env59306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59305_59306 : H12AffineEnvironment.transform 6 9 env59305 = env59306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59305 == env59306) = true)

theorem identity59306 : scanCanonicalize (H12AffineFastState.compose env59306 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59306 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59307 : List Nat := [2,4,8,16,32,11,9,14,0,47,49,1,40,26,42,35,26,27,46,42,43,33,10,2,40,16,49,27,1,27,36,33,14,32,26,0]

theorem envBound59307 : H12AffineFastState.Bounded env59307 := by
  intro p hp
  have h : env59307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59306_59307 : H12AffineEnvironment.transform 5 11 env59306 = env59307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59306 == env59307) = true)

theorem identity59307 : scanCanonicalize (H12AffineFastState.compose env59307 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59307 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59308 : List Nat := [2,4,8,16,16,11,9,14,0,31,1,1,24,26,26,19,26,27,30,26,27,17,10,2,24,16,1,27,1,27,20,17,14,16,26,0]

theorem envBound59308 : H12AffineFastState.Bounded env59308 := by
  intro p hp
  have h : env59308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59307_59308 : H12AffineEnvironment.transform 4 16 env59307 = env59308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59307 == env59308) = true)

theorem identity59308 : scanCanonicalize (H12AffineFastState.compose env59308 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59308 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59309 : List Nat := [2,4,8,11,11,11,9,14,0,4,1,1,3,1,1,8,1,0,5,1,0,10,10,2,3,11,1,0,1,0,15,10,14,11,1,0]

theorem envBound59309 : H12AffineFastState.Bounded env59309 := by
  intro p hp
  have h : env59309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59308_59309 : H12AffineEnvironment.transform 3 11 env59308 = env59309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59308 == env59309) = true)

def env59310 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,2097152,1417,64,3159,1289,17,2365812,4177,2557,6572,7417,5377,256,7284,2477,1]

theorem envBound59310 : H12AffineFastState.Bounded env59310 := by
  intro p hp
  have h : env59310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59298_59310 : H12AffineEnvironment.transform 12 1409 env59298 = env59310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59298 == env59310) = true)

theorem identity59310 : scanCanonicalize (H12AffineFastState.compose env59310 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59310 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59311 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,6653,1417,64,3159,1289,17,262281,4177,2557,6572,7417,5377,256,7284,2477,1]

theorem envBound59311 : H12AffineFastState.Bounded env59311 := by
  intro p hp
  have h : env59311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59310_59311 : H12AffineEnvironment.transform 20 6653 env59310 = env59311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59310 == env59311) = true)

theorem identity59311 : scanCanonicalize (H12AffineFastState.compose env59311 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59311 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59312 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,4358,1109,262144,1025,1448,5125,1417,64,431,1289,17,262281,4177,1029,5204,4353,5377,256,4492,1109,1]

theorem envBound59312 : H12AffineFastState.Bounded env59312 := by
  intro p hp
  have h : env59312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59311_59312 : H12AffineEnvironment.transform 10 1528 env59311 = env59312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59311 == env59312) = true)

theorem identity59312 : scanCanonicalize (H12AffineFastState.compose env59312 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59312 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59313 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,4358,1109,5609,1025,1448,5125,1417,64,431,1289,17,5472,4177,1029,5204,4353,5377,256,4492,1109,1]

theorem envBound59313 : H12AffineFastState.Bounded env59313 := by
  intro p hp
  have h : env59313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59312_59313 : H12AffineEnvironment.transform 17 5609 env59312 = env59313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59312 == env59313) = true)

theorem identity59313 : scanCanonicalize (H12AffineFastState.compose env59313 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59313 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59314 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1313,1409,1393,1448,1063,1109,200,1025,1448,292,1417,64,431,1289,17,65,1392,1029,373,1056,32,256,1197,1109,1]

theorem envBound59314 : H12AffineFastState.Bounded env59314 := by
  intro p hp
  have h : env59314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59313_59314 : H12AffineEnvironment.transform 11 1313 env59313 = env59314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59313 == env59314) = true)

theorem identity59314 : scanCanonicalize (H12AffineFastState.compose env59314 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59314 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59315 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,508,348,428,373,250,136,200,220,373,292,340,64,431,468,17,65,429,216,373,253,32,256,112,136,1]

theorem envBound59315 : H12AffineFastState.Bounded env59315 := by
  intro p hp
  have h : env59315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59314_59315 : H12AffineEnvironment.transform 9 221 env59314 = env59315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59314 == env59315) = true)

theorem identity59315 : scanCanonicalize (H12AffineFastState.compose env59315 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59315 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59316 : List Nat := [2,4,8,16,32,16,128,256,0,141,293,428,268,428,293,170,136,152,140,293,292,260,16,431,388,17,17,429,136,293,173,32,256,32,136,1]

theorem envBound59316 : H12AffineFastState.Bounded env59316 := by
  intro p hp
  have h : env59316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59315_59316 : H12AffineEnvironment.transform 5 16 env59315 = env59316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59315 == env59316) = true)

theorem identity59316 : scanCanonicalize (H12AffineFastState.compose env59316 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59317 : List Nat := [2,4,8,16,32,16,27,256,0,22,293,311,268,311,293,49,19,3,23,293,292,260,16,308,287,17,17,310,19,293,54,32,256,32,19,1]

theorem envBound59317 : H12AffineFastState.Bounded env59317 := by
  intro p hp
  have h : env59317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59316_59317 : H12AffineEnvironment.transform 6 27 env59316 = env59317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59316 == env59317) = true)

theorem identity59317 : scanCanonicalize (H12AffineFastState.compose env59317 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59317 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59318 : List Nat := [2,4,8,16,32,16,27,4,0,22,33,51,8,51,33,49,19,3,23,33,32,0,16,48,27,17,17,50,19,33,54,32,4,32,19,1]

theorem envBound59318 : H12AffineFastState.Bounded env59318 := by
  intro p hp
  have h : env59318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59317_59318 : H12AffineEnvironment.transform 7 4 env59317 = env59318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59317 == env59318) = true)

theorem identity59318 : scanCanonicalize (H12AffineFastState.compose env59318 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59318 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59319 : List Nat := [2,4,8,16,10,16,27,4,0,22,11,25,8,25,11,27,19,3,23,11,10,0,16,26,27,17,17,24,19,11,28,10,4,10,19,1]

theorem envBound59319 : H12AffineFastState.Bounded env59319 := by
  intro p hp
  have h : env59319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59318_59319 : H12AffineEnvironment.transform 4 10 env59318 = env59319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59318 == env59319) = true)

theorem identity59319 : scanCanonicalize (H12AffineFastState.compose env59319 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59320 : List Nat := [2,4,8,3,10,3,8,4,0,5,11,10,8,10,11,8,0,3,4,11,10,0,3,9,8,2,2,11,0,11,15,10,4,10,0,1]

theorem envBound59320 : H12AffineFastState.Bounded env59320 := by
  intro p hp
  have h : env59320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59319_59320 : H12AffineEnvironment.transform 3 3 env59319 = env59320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59319 == env59320) = true)

theorem identity59320 : scanCanonicalize (H12AffineFastState.compose env59320 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59320 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59321 : List Nat := [2,4,3,3,1,3,3,4,0,5,0,1,3,1,0,3,0,3,4,0,1,0,3,2,3,2,2,0,0,0,4,1,4,1,0,1]

theorem envBound59321 : H12AffineFastState.Bounded env59321 := by
  intro p hp
  have h : env59321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59320_59321 : H12AffineEnvironment.transform 2 3 env59320 = env59321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59320 == env59321) = true)

theorem identity59321 : scanCanonicalize (H12AffineFastState.compose env59321 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59321 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59322 : List Nat := [0,4,1,1,1,1,1,4,0,5,0,1,1,1,0,1,0,1,4,0,1,0,1,0,1,0,0,0,0,0,4,1,4,1,0,1]

theorem envBound59322 : H12AffineFastState.Bounded env59322 := by
  intro p hp
  have h : env59322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59321_59322 : H12AffineEnvironment.transform 0 0 env59321 = env59322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59321 == env59322) = true)

def env59323 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound59323 : H12AffineFastState.Bounded env59323 := by
  intro p hp
  have h : env59323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59296_59323 : H12AffineEnvironment.transform 8 1 env59296 = env59323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59296 == env59323) = true)

theorem identity59323 : scanCanonicalize (H12AffineFastState.compose env59323 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 14718) := by decide +kernel

theorem selectedBound59323 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59324 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,14718,2476,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365813,4177,2556,15405,14713,12416,256,14836,2476,9601]

theorem envBound59324 : H12AffineFastState.Bounded env59324 := by
  intro p hp
  have h : env59324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59323_59324 : H12AffineEnvironment.transform 15 14718 env59323 = env59324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14718 env59323 == env59324) = true)

def env59325 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,2097152,1417,65,3158,1289,16,2365813,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound59325 : H12AffineFastState.Bounded env59325 := by
  intro p hp
  have h : env59325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59324_59325 : H12AffineEnvironment.transform 12 1408 env59324 = env59325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59324 == env59325) = true)

theorem identity59325 : scanCanonicalize (H12AffineFastState.compose env59325 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59325 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59326 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,1029,1417,65,3158,1289,16,269680,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound59326 : H12AffineFastState.Bounded env59326 := by
  intro p hp
  have h : env59326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59325_59326 : H12AffineEnvironment.transform 20 1029 env59325 = env59326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env59325 == env59326) = true)

theorem identity59326 : scanCanonicalize (H12AffineFastState.compose env59326 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59326 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59327 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,3529,1025,2129,1029,1417,65,3158,1289,16,4281,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound59327 : H12AffineFastState.Bounded env59327 := by
  intro p hp
  have h : env59327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59326_59327 : H12AffineEnvironment.transform 17 3529 env59326 = env59327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59326 == env59327) = true)

theorem identity59327 : scanCanonicalize (H12AffineFastState.compose env59327 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59327 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59328 : List Nat := [2,4,8,16,32,64,128,256,1,1024,48,4096,1408,4176,97,5326,412,1529,1025,97,1029,1417,65,1126,1289,16,4281,4177,460,4509,5321,5376,256,5188,412,1]

theorem envBound59328 : H12AffineFastState.Bounded env59328 := by
  intro p hp
  have h : env59328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59327_59328 : H12AffineEnvironment.transform 10 48 env59327 = env59328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59327 == env59328) = true)

theorem identity59328 : scanCanonicalize (H12AffineFastState.compose env59328 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59328 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59329 : List Nat := [2,4,8,16,32,64,128,256,1,425,48,4096,41,4176,97,4455,412,80,424,97,428,32,65,463,160,16,4281,4177,460,4509,4448,4265,256,4589,412,1]

theorem envBound59329 : H12AffineFastState.Bounded env59329 := by
  intro p hp
  have h : env59329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59328_59329 : H12AffineEnvironment.transform 9 425 env59328 = env59329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59328 == env59329) = true)

theorem identity59329 : scanCanonicalize (H12AffineFastState.compose env59329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59330 : List Nat := [2,4,8,16,32,64,128,256,1,425,48,137,41,217,97,494,412,80,424,97,428,32,65,463,160,16,48,216,460,276,489,32,256,356,412,1]

theorem envBound59330 : H12AffineFastState.Bounded env59330 := by
  intro p hp
  have h : env59330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59329_59330 : H12AffineEnvironment.transform 11 137 env59329 = env59330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59329 == env59330) = true)

theorem identity59330 : scanCanonicalize (H12AffineFastState.compose env59330 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound59330 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59331 : List Nat := [2,4,8,16,32,64,128,183,1,30,48,137,41,217,97,89,43,80,31,97,27,32,65,120,160,16,48,216,123,163,94,32,183,211,43,1]

theorem envBound59331 : H12AffineFastState.Bounded env59331 := by
  intro p hp
  have h : env59331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59330_59331 : H12AffineEnvironment.transform 7 183 env59330 = env59331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env59330 == env59331) = true)

theorem identity59331 : scanCanonicalize (H12AffineFastState.compose env59331 (packedSelected [1,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59331 : packedSelected [1,6,9] rootPS < 2^1333 := by decide +kernel

def env59332 : List Nat := [2,4,8,16,32,64,114,69,1,30,48,123,41,43,97,89,43,80,31,97,27,32,65,120,82,16,48,42,123,81,94,32,69,33,43,1]

theorem envBound59332 : H12AffineFastState.Bounded env59332 := by
  intro p hp
  have h : env59332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59331_59332 : H12AffineEnvironment.transform 6 114 env59331 = env59332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59331 == env59332) = true)

def env59333 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7423,2476,262144,1025,2129,2097152,1417,64,3158,1289,17,2365813,4177,2556,6572,7416,5377,256,7285,2476,0]

theorem envBound59333 : H12AffineFastState.Bounded env59333 := by
  intro p hp
  have h : env59333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59324_59333 : H12AffineEnvironment.transform 12 1409 env59324 = env59333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59324 == env59333) = true)

theorem identity59333 : scanCanonicalize (H12AffineFastState.compose env59333 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59333 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59334 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7423,2476,262144,1025,2129,6652,1417,64,3158,1289,17,262281,4177,2556,6572,7416,5377,256,7285,2476,0]

theorem envBound59334 : H12AffineFastState.Bounded env59334 := by
  intro p hp
  have h : env59334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59333_59334 : H12AffineEnvironment.transform 20 6652 env59333 = env59334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59333 == env59334) = true)

theorem identity59334 : scanCanonicalize (H12AffineFastState.compose env59334 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59334 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59335 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,4358,1109,262144,1025,1448,5125,1417,64,431,1289,17,262281,4177,1029,5205,4353,5377,256,4492,1109,0]

theorem envBound59335 : H12AffineFastState.Bounded env59335 := by
  intro p hp
  have h : env59335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59334_59335 : H12AffineEnvironment.transform 10 1529 env59334 = env59335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59334 == env59335) = true)

theorem identity59335 : scanCanonicalize (H12AffineFastState.compose env59335 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59335 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59336 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,4358,1109,5609,1025,1448,5125,1417,64,431,1289,17,5472,4177,1029,5205,4353,5377,256,4492,1109,0]

theorem envBound59336 : H12AffineFastState.Bounded env59336 := by
  intro p hp
  have h : env59336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59335_59336 : H12AffineEnvironment.transform 17 5609 env59335 = env59336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59335 == env59336) = true)

theorem identity59336 : scanCanonicalize (H12AffineFastState.compose env59336 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59336 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59337 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1313,1409,1393,1448,1063,1109,200,1025,1448,292,1417,64,431,1289,17,65,1392,1029,372,1056,32,256,1197,1109,0]

theorem envBound59337 : H12AffineFastState.Bounded env59337 := by
  intro p hp
  have h : env59337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59336_59337 : H12AffineEnvironment.transform 11 1313 env59336 = env59337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59336 == env59337) = true)

theorem identity59337 : scanCanonicalize (H12AffineFastState.compose env59337 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59337 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59338 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,509,349,429,372,251,137,200,221,372,292,341,64,431,469,17,65,428,217,372,252,32,256,113,137,0]

theorem envBound59338 : H12AffineFastState.Bounded env59338 := by
  intro p hp
  have h : env59338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59337_59338 : H12AffineEnvironment.transform 9 220 env59337 = env59338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59337 == env59338) = true)

theorem identity59338 : scanCanonicalize (H12AffineFastState.compose env59338 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59338 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59339 : List Nat := [2,4,8,16,32,64,128,173,1,220,136,80,240,0,217,251,137,200,221,217,137,248,64,2,120,17,65,1,217,217,252,32,173,113,137,0]

theorem envBound59339 : H12AffineFastState.Bounded env59339 := by
  intro p hp
  have h : env59339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59338_59339 : H12AffineEnvironment.transform 7 173 env59338 = env59339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59338 == env59339) = true)

theorem identity59339 : scanCanonicalize (H12AffineFastState.compose env59339 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound59339 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59340 : List Nat := [2,4,8,16,32,64,40,5,1,116,32,80,88,0,113,83,33,96,117,113,33,80,64,2,120,17,65,1,113,113,84,32,5,113,33,0]

theorem envBound59340 : H12AffineFastState.Bounded env59340 := by
  intro p hp
  have h : env59340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59339_59340 : H12AffineEnvironment.transform 6 40 env59339 = env59340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env59339 == env59340) = true)

theorem identity59340 : scanCanonicalize (H12AffineFastState.compose env59340 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59341 : List Nat := [2,4,8,16,11,64,3,5,1,95,11,80,88,0,90,83,10,75,94,90,10,80,64,2,83,17,65,1,90,90,84,11,5,90,10,0]

theorem envBound59341 : H12AffineFastState.Bounded env59341 := by
  intro p hp
  have h : env59341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59340_59341 : H12AffineEnvironment.transform 4 11 env59340 = env59341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59340 == env59341) = true)

theorem identity59341 : scanCanonicalize (H12AffineFastState.compose env59341 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59341 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59342 : List Nat := [2,4,8,2,11,64,3,5,1,77,11,66,74,0,72,65,10,75,76,72,10,66,64,2,65,3,65,1,72,72,70,11,5,72,10,0]

theorem envBound59342 : H12AffineFastState.Bounded env59342 := by
  intro p hp
  have h : env59342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59341_59342 : H12AffineEnvironment.transform 3 2 env59341 = env59342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59341 == env59342) = true)

theorem identity59342 : scanCanonicalize (H12AffineFastState.compose env59342 (packedSelected [6,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59342 : packedSelected [6,9] rootPS < 2^1333 := by decide +kernel

def env59343 : List Nat := [2,4,8,2,11,11,3,5,1,6,11,9,1,0,3,10,10,0,7,3,10,9,11,2,10,3,10,1,3,3,13,11,5,3,10,0]

theorem envBound59343 : H12AffineFastState.Bounded env59343 := by
  intro p hp
  have h : env59343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59342_59343 : H12AffineEnvironment.transform 5 11 env59342 = env59343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59342 == env59343) = true)

theorem identity59343 : scanCanonicalize (H12AffineFastState.compose env59343 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59343 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59344 : List Nat := [2,4,2,2,1,1,3,5,1,6,1,3,1,0,3,0,0,0,7,3,0,3,1,2,0,3,0,1,3,3,7,1,5,3,0,0]

theorem envBound59344 : H12AffineFastState.Bounded env59344 := by
  intro p hp
  have h : env59344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59343_59344 : H12AffineEnvironment.transform 2 2 env59343 = env59344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59343 == env59344) = true)

def env59345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397001,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,8389184]

theorem envBound59345 : H12AffineFastState.Bounded env59345 := by
  intro p hp
  have h : env59345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58983_59345 : H12AffineEnvironment.transform 24 8397001 env58983 = env59345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397001 env58983 == env59345) = true)

def env59346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397001,8388689,6561532,4177,77954,4260571,8463814,8465983,256,4261122,78034,8389184]

theorem envBound59346 : H12AffineFastState.Bounded env59346 := by
  intro p hp
  have h : env59346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59345_59346 : H12AffineEnvironment.transform 26 6561532 env59345 = env59346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env59345 == env59346) = true)

def env59347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399766,8397001,8388689,2366324,4177,77954,67411,8463814,8465983,256,65674,78034,8389184]

theorem envBound59347 : H12AffineFastState.Bounded env59347 := by
  intro p hp
  have h : env59347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59346_59347 : H12AffineEnvironment.transform 21 1416 env59346 = env59347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59346 == env59347) = true)

def env59348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3670,1289,9617,2366324,4177,77954,67411,65542,68607,256,65674,78034,10112]

theorem envBound59348 : H12AffineFastState.Bounded env59348 := by
  intro p hp
  have h : env59348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59347_59348 : H12AffineEnvironment.transform 22 9664 env59347 = env59348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59347 == env59348) = true)

def env59349 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1289,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59349 : H12AffineFastState.Bounded env59349 := by
  intro p hp
  have h : env59349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59348_59349 : H12AffineEnvironment.transform 8 0 env59348 = env59349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59348 == env59349) = true)

theorem identity59349 : scanCanonicalize (H12AffineFastState.compose env59349 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59350 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,3076,1416,9664,3158,1289,9617,267632,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59350 : H12AffineFastState.Bounded env59350 := by
  intro p hp
  have h : env59350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59349_59350 : H12AffineEnvironment.transform 20 3076 env59349 = env59350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59349 == env59350) = true)

def env59351 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,3076,1416,64,3158,1289,17,267632,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound59351 : H12AffineFastState.Bounded env59351 := by
  intro p hp
  have h : env59351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59350_59351 : H12AffineEnvironment.transform 12 1408 env59350 = env59351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59350 == env59351) = true)

theorem identity59351 : scanCanonicalize (H12AffineFastState.compose env59351 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound59351 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59352 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,3076,1416,64,3158,1289,17,267632,4177,508,4525,5368,7425,256,5236,428,0]

theorem envBound59352 : H12AffineFastState.Bounded env59352 := by
  intro p hp
  have h : env59352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59351_59352 : H12AffineEnvironment.transform 15 5374 env59351 = env59352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env59351 == env59352) = true)

theorem identity59352 : scanCanonicalize (H12AffineFastState.compose env59352 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59352 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59353 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,6376,1025,2128,3076,1416,64,3158,1289,17,3480,4177,508,4525,5368,7425,256,5236,428,0]

theorem envBound59353 : H12AffineFastState.Bounded env59353 := by
  intro p hp
  have h : env59353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59352_59353 : H12AffineEnvironment.transform 17 6376 env59352 = env59353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59352 == env59353) = true)

theorem identity59353 : scanCanonicalize (H12AffineFastState.compose env59353 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59353 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59354 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1408,412,2128,1330,428,2340,1025,2128,3076,1416,64,3158,1289,17,3480,413,508,97,1332,3277,256,1464,428,0]

theorem envBound59354 : H12AffineFastState.Bounded env59354 := by
  intro p hp
  have h : env59354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59353_59354 : H12AffineEnvironment.transform 11 460 env59353 = env59354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59353 == env59354) = true)

theorem identity59354 : scanCanonicalize (H12AffineFastState.compose env59354 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59354 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59355 : List Nat := [2,4,8,16,17,64,128,256,0,1024,2048,460,1408,412,2128,1283,413,2325,1025,2128,3076,1416,64,3158,1289,17,3480,413,461,80,1285,3277,256,1417,413,0]

theorem envBound59355 : H12AffineFastState.Bounded env59355 := by
  intro p hp
  have h : env59355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59354_59355 : H12AffineEnvironment.transform 4 17 env59354 = env59355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59354 == env59355) = true)

theorem identity59355 : scanCanonicalize (H12AffineFastState.compose env59355 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59355 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env59356 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1244,460,1408,412,1164,1283,413,1481,1025,1164,216,1416,64,138,1289,17,324,413,461,80,1285,17,256,1417,413,0]

theorem envBound59356 : H12AffineFastState.Bounded env59356 := by
  intro p hp
  have h : env59356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59355_59356 : H12AffineEnvironment.transform 10 1244 env59355 = env59356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59355 == env59356) = true)

theorem identity59356 : scanCanonicalize (H12AffineFastState.compose env59356 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59356 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59357 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1244,147,1247,195,1164,1116,194,1174,1025,1164,216,1239,64,138,1110,17,27,194,146,80,1114,17,95,1238,194,0]

theorem envBound59357 : H12AffineFastState.Bounded env59357 := by
  intro p hp
  have h : env59357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59356_59357 : H12AffineEnvironment.transform 7 95 env59356 = env59357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59356 == env59357) = true)

theorem identity59357 : scanCanonicalize (H12AffineFastState.compose env59357 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59357 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59358 : List Nat := [2,4,8,16,17,64,128,95,0,198,26,147,25,195,74,154,194,80,199,74,216,17,64,138,144,17,27,194,146,80,156,17,95,16,194,0]

theorem envBound59358 : H12AffineFastState.Bounded env59358 := by
  intro p hp
  have h : env59358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59357_59358 : H12AffineEnvironment.transform 9 198 env59357 = env59358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59357 == env59358) = true)

def env59359 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,3076,1416,65,3158,1289,16,267632,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound59359 : H12AffineFastState.Bounded env59359 := by
  intro p hp
  have h : env59359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59350_59359 : H12AffineEnvironment.transform 12 1409 env59350 = env59359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59350 == env59359) = true)

theorem identity59359 : scanCanonicalize (H12AffineFastState.compose env59359 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59359 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59360 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1529,1409,1449,2128,65536,65706,262144,1025,2128,3076,1416,65,3158,1289,16,262281,1448,65786,66899,65542,68095,256,65674,65706,1]

theorem envBound59360 : H12AffineFastState.Bounded env59360 := by
  intro p hp
  have h : env59360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59359_59360 : H12AffineEnvironment.transform 11 1529 env59359 = env59360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env59359 == env59360) = true)

theorem identity59360 : scanCanonicalize (H12AffineFastState.compose env59360 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59360 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59361 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1449,65536,65706,262144,1025,1449,509,1416,65,431,1289,16,262281,1448,65786,66899,65542,66566,256,65674,65706,1]

theorem envBound59361 : H12AffineFastState.Bounded env59361 := by
  intro p hp
  have h : env59361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59360_59361 : H12AffineEnvironment.transform 10 1529 env59360 = env59361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59360 == env59361) = true)

theorem identity59361 : scanCanonicalize (H12AffineFastState.compose env59361 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 308) := by decide +kernel

theorem selectedBound59361 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59362 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1449,65536,65706,308,1025,1449,509,1416,65,431,1289,16,445,1448,65786,66899,65542,66566,256,65674,65706,1]

theorem envBound59362 : H12AffineFastState.Bounded env59362 := by
  intro p hp
  have h : env59362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0