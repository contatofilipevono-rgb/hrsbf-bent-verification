import H12CloudChart0Data028

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound7182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7183 : List Nat := [2,2,8,16,19,16,9,16,11,19,1,17,27,19,0,17,3,1,0,0,18,18,3,3,26,2,0,16,2,1,0,18,3,18,18,10]

theorem envBound7183 : H12AffineFastState.Bounded env7183 := by
  intro p hp
  have h : env7183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7182_7183 : H12AffineEnvironment.transform 1 2 env7182 = env7183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7182 == env7183) = true)

def env7184 : List Nat := [2,4,8,16,32,17,9,36,512,33,0,36,29,555,53,553,48,53,575,53,554,33,526,573,28,48,522,538,526,0,575,33,570,33,543,63]

theorem envBound7184 : H12AffineFastState.Bounded env7184 := by
  intro p hp
  have h : env7184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7179_7184 : H12AffineEnvironment.transform 5 17 env7179 = env7184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env7179 == env7184) = true)

theorem identity7184 : scanCanonicalize (H12AffineFastState.compose env7184 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7185 : List Nat := [2,4,8,16,32,17,9,36,10,33,0,36,29,33,53,35,48,53,53,53,32,33,4,55,28,48,0,16,4,0,53,33,48,33,21,63]

theorem envBound7185 : H12AffineFastState.Bounded env7185 := by
  intro p hp
  have h : env7185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7184_7185 : H12AffineEnvironment.transform 8 10 env7184 = env7185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7184 == env7185) = true)

theorem identity7185 : scanCanonicalize (H12AffineFastState.compose env7185 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound7185 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7186 : List Nat := [2,4,8,16,21,17,9,17,10,20,0,17,29,20,0,22,5,0,0,0,21,20,4,2,28,5,0,16,4,0,0,20,5,20,21,10]

theorem envBound7186 : H12AffineFastState.Bounded env7186 := by
  intro p hp
  have h : env7186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7185_7186 : H12AffineEnvironment.transform 4 21 env7185 = env7186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env7185 == env7186) = true)

theorem identity7186 : scanCanonicalize (H12AffineFastState.compose env7186 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound7186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7187 : List Nat := [2,4,5,16,21,17,4,17,7,20,0,17,16,20,0,22,5,0,0,0,21,20,4,2,17,5,0,16,4,0,0,20,5,20,21,7]

theorem envBound7187 : H12AffineFastState.Bounded env7187 := by
  intro p hp
  have h : env7187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7186_7187 : H12AffineEnvironment.transform 2 5 env7186 = env7187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env7186 == env7187) = true)

def leafEnv7187 : List Nat := [2,4,5,16,21,17,4,17,7,20,0,17,16,20,0,22,5,0,0,0,21,20,4,2,20,17,1,5,0,16,4,0,0,20,5,20,16,22,21,7,1,20,0]

def active7187 : List Nat := [0,1,3]

def tree7187 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7187 : H12WitnessSearch.Good tree7187 := H12GlobalWitnessIndex.good

theorem leafIdentity7187 : H12AffineFastState.composeSystem env7187 rootObs = leafEnv7187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7187 rootObs == leafEnv7187) = true)

theorem terminalChecked7187 : H12PackedTerminal.terminalCheckFast leafEnv7187 active7187 tree7187 = true := by decide +kernel

def env7188 : List Nat := [2,4,8,16,32,64,9,117,512,113,2048,37,28,2682,52,2680,48,2100,2623,52,2683,33,2654,2669,29,97,603,2586,2575,2048,2623,33,2619,33,2639,2159]

theorem envBound7188 : H12AffineFastState.Bounded env7188 := by
  intro p hp
  have h : env7188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7177_7188 : H12AffineEnvironment.transform 9 113 env7177 = env7188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 113 env7177 == env7188) = true)

theorem identity7188 : scanCanonicalize (H12AffineFastState.compose env7188 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound7188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7189 : List Nat := [2,4,8,16,32,64,9,117,63,113,2048,37,28,2117,52,2119,48,2100,2048,52,2116,33,2145,2130,29,97,100,2085,2096,2048,2048,33,2052,33,2160,2159]

theorem envBound7189 : H12AffineFastState.Bounded env7189 := by
  intro p hp
  have h : env7189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7188_7189 : H12AffineEnvironment.transform 8 63 env7188 = env7189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env7188 == env7189) = true)

def env7190 : List Nat := [2,4,8,16,32,64,9,117,63,113,0,37,28,69,52,71,48,52,0,52,68,33,97,82,29,97,100,37,48,0,0,33,4,33,112,111]

theorem envBound7190 : H12AffineFastState.Bounded env7190 := by
  intro p hp
  have h : env7190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7189_7190 : H12AffineEnvironment.transform 10 0 env7189 = env7190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env7189 == env7190) = true)

theorem identity7190 : scanCanonicalize (H12AffineFastState.compose env7190 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7190 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7191 : List Nat := [2,4,8,16,32,36,9,17,63,21,0,37,28,33,52,35,48,52,0,52,32,33,5,54,29,5,0,37,48,0,0,33,4,33,20,11]

theorem envBound7191 : H12AffineFastState.Bounded env7191 := by
  intro p hp
  have h : env7191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7190_7191 : H12AffineEnvironment.transform 5 36 env7190 = env7191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7190 == env7191) = true)

theorem identity7191 : scanCanonicalize (H12AffineFastState.compose env7191 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound7191 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7192 : List Nat := [2,4,8,16,20,16,9,17,11,21,0,17,28,21,0,23,4,0,0,0,20,21,5,2,29,5,0,17,4,0,0,21,4,21,20,11]

theorem envBound7192 : H12AffineFastState.Bounded env7192 := by
  intro p hp
  have h : env7192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7191_7192 : H12AffineEnvironment.transform 4 20 env7191 = env7192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env7191 == env7192) = true)

theorem identity7192 : scanCanonicalize (H12AffineFastState.compose env7192 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound7192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7193 : List Nat := [2,4,4,16,20,16,5,17,7,21,0,17,16,21,0,23,4,0,0,0,20,21,5,2,17,5,0,17,4,0,0,21,4,21,20,7]

theorem envBound7193 : H12AffineFastState.Bounded env7193 := by
  intro p hp
  have h : env7193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7192_7193 : H12AffineEnvironment.transform 2 4 env7192 = env7193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env7192 == env7193) = true)

def leafEnv7193 : List Nat := [2,4,4,16,20,16,5,17,7,21,0,17,16,21,0,23,4,0,0,0,20,21,5,2,21,17,1,5,0,17,4,0,0,21,4,21,17,23,20,7,1,21,0]

def active7193 : List Nat := [0,1,3]

def tree7193 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7193 : H12WitnessSearch.Good tree7193 := H12GlobalWitnessIndex.good

theorem leafIdentity7193 : H12AffineFastState.composeSystem env7193 rootObs = leafEnv7193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7193 rootObs == leafEnv7193) = true)

theorem terminalChecked7193 : H12PackedTerminal.terminalCheckFast leafEnv7193 active7193 tree7193 = true := by decide +kernel

def env7194 : List Nat := [2,4,8,16,32,64,9,117,63,113,1,37,28,68,52,70,48,53,1,52,69,33,96,83,29,97,100,36,49,1,1,33,5,33,113,110]

theorem envBound7194 : H12AffineFastState.Bounded env7194 := by
  intro p hp
  have h : env7194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7189_7194 : H12AffineEnvironment.transform 10 1 env7189 = env7194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env7189 == env7194) = true)

theorem identity7194 : scanCanonicalize (H12AffineFastState.compose env7194 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7194 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7195 : List Nat := [2,4,8,16,32,36,9,17,63,21,1,37,28,32,52,34,48,53,1,52,33,33,4,55,29,5,0,36,49,1,1,33,5,33,21,10]

theorem envBound7195 : H12AffineFastState.Bounded env7195 := by
  intro p hp
  have h : env7195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7194_7195 : H12AffineEnvironment.transform 5 36 env7194 = env7195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7194 == env7195) = true)

theorem identity7195 : scanCanonicalize (H12AffineFastState.compose env7195 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound7195 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7196 : List Nat := [2,4,8,16,20,16,9,17,11,21,1,17,28,20,0,22,4,1,1,0,21,21,4,3,29,5,0,16,5,1,1,21,5,21,21,10]

theorem envBound7196 : H12AffineFastState.Bounded env7196 := by
  intro p hp
  have h : env7196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7195_7196 : H12AffineEnvironment.transform 4 20 env7195 = env7196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env7195 == env7196) = true)

theorem identity7196 : scanCanonicalize (H12AffineFastState.compose env7196 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound7196 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7197 : List Nat := [2,3,8,16,19,16,9,17,11,18,1,17,27,19,0,17,3,1,1,0,18,18,3,3,26,2,0,16,2,1,1,18,2,18,18,10]

theorem envBound7197 : H12AffineFastState.Bounded env7197 := by
  intro p hp
  have h : env7197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7196_7197 : H12AffineEnvironment.transform 1 3 env7196 = env7197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env7196 == env7197) = true)

def env7198 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1109,1252,2802,1093,2801,184,3276,2742,1093,2682,33,3750,3612,1132,97,722,2587,3830,2185,2623,168,3658,168,3766,3223]

theorem envBound7198 : H12AffineFastState.Bounded env7198 := by
  intro p hp
  have h : env7198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7169_7198 : H12AffineEnvironment.transform 11 1109 env7169 = env7198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env7169 == env7198) = true)

def env7199 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1109,1132,2682,1093,2681,48,3140,2622,1093,2682,33,3630,3612,1132,97,602,2587,3710,2049,2623,32,3658,32,3646,3103]

theorem envBound7199 : H12AffineFastState.Bounded env7199 := by
  intro p hp
  have h : env7199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7198_7199 : H12AffineEnvironment.transform 6 8 env7198 = env7199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7198 == env7199) = true)

theorem identity7199 : scanCanonicalize (H12AffineFastState.compose env7199 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound7199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7200 : List Nat := [2,4,8,16,32,64,8,116,512,1024,603,1109,1132,33,1093,34,48,1567,101,1093,33,33,1141,1095,1132,97,602,64,1061,602,100,32,1041,32,1125,1604]

theorem envBound7200 : H12AffineFastState.Bounded env7200 := by
  intro p hp
  have h : env7200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7199_7200 : H12AffineEnvironment.transform 10 603 env7199 = env7200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env7199 == env7200) = true)

def env7201 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1109,1133,2683,1093,2680,49,3141,2623,1093,2682,33,3631,3612,1132,97,603,2587,3711,2048,2623,33,3658,33,3647,3102]

theorem envBound7201 : H12AffineFastState.Bounded env7201 := by
  intro p hp
  have h : env7201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7198_7201 : H12AffineEnvironment.transform 6 9 env7198 = env7201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7198 == env7201) = true)

theorem identity7201 : scanCanonicalize (H12AffineFastState.compose env7201 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound7201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7202 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1566,1109,1133,1125,1093,1126,49,603,1057,1093,1124,33,49,2,1132,97,603,1029,97,1566,1057,33,84,33,33,512]

theorem envBound7202 : H12AffineFastState.Bounded env7202 := by
  intro p hp
  have h : env7202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7201_7202 : H12AffineEnvironment.transform 10 1566 env7201 = env7202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env7201 == env7202) = true)

theorem identity7202 : scanCanonicalize (H12AffineFastState.compose env7202 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 635) := by decide +kernel

theorem selectedBound7202 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7203 : List Nat := [2,4,8,16,32,64,9,117,512,635,101,558,534,542,574,541,49,603,602,574,543,33,49,2,535,97,603,638,97,101,602,33,84,33,33,512]

theorem envBound7203 : H12AffineFastState.Bounded env7203 := by
  intro p hp
  have h : env7203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7202_7203 : H12AffineEnvironment.transform 9 635 env7202 = env7203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 635 env7202 == env7203) = true)

theorem identity7203 : scanCanonicalize (H12AffineFastState.compose env7203 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 62) := by decide +kernel

theorem selectedBound7203 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7204 : List Nat := [2,4,8,16,32,64,9,117,62,69,101,16,40,32,0,35,49,101,100,0,33,33,49,2,41,97,101,64,97,101,100,33,84,33,33,62]

theorem envBound7204 : H12AffineFastState.Bounded env7204 := by
  intro p hp
  have h : env7204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7203_7204 : H12AffineEnvironment.transform 8 62 env7203 = env7204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 62 env7203 == env7204) = true)

theorem identity7204 : scanCanonicalize (H12AffineFastState.compose env7204 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound7204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7205 : List Nat := [2,4,8,16,25,64,9,76,7,69,92,16,17,25,0,26,8,92,93,0,24,24,8,2,16,88,92,64,88,92,93,24,84,24,24,7]

theorem envBound7205 : H12AffineFastState.Bounded env7205 := by
  intro p hp
  have h : env7205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7204_7205 : H12AffineEnvironment.transform 4 25 env7204 = env7205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env7204 == env7205) = true)

theorem identity7205 : scanCanonicalize (H12AffineFastState.compose env7205 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound7205 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7206 : List Nat := [2,4,8,16,25,29,9,17,7,24,1,16,17,25,0,26,8,1,0,0,24,24,8,2,16,5,1,29,5,1,0,24,9,24,24,7]

theorem envBound7206 : H12AffineFastState.Bounded env7206 := by
  intro p hp
  have h : env7206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7205_7206 : H12AffineEnvironment.transform 5 29 env7205 = env7206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env7205 == env7206) = true)

def leafEnv7206 : List Nat := [2,4,8,16,25,29,9,17,7,24,1,16,17,25,0,26,8,1,0,0,24,24,8,2,24,16,1,5,1,29,5,1,0,24,9,24,28,26,24,7,1,25,0]

def active7206 : List Nat := [0,1,2,3]

def tree7206 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7206 : H12WitnessSearch.Good tree7206 := H12GlobalWitnessIndex.good

theorem leafIdentity7206 : H12AffineFastState.composeSystem env7206 rootObs = leafEnv7206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7206 rootObs == leafEnv7206) = true)

theorem terminalChecked7206 : H12PackedTerminal.terminalCheckFast leafEnv7206 active7206 tree7206 = true := by decide +kernel

def env7207 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,5357,3277,2742,8353,15050,33,3750,11000,8328,9349,9783,7759,6818,2185,11995,168,3658,168,6882,10355]

theorem envBound7207 : H12AffineFastState.Bounded env7207 := by
  intro p hp
  have h : env7207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7167_7207 : H12AffineEnvironment.transform 17 3277 env7167 = env7207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3277 env7167 == env7207) = true)

theorem identity7207 : scanCanonicalize (H12AffineFastState.compose env7207 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1686) := by decide +kernel

theorem selectedBound7207 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7208 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,4096,8192,4145,8353,1127,5357,603,1056,8353,13404,33,48,9326,8328,9349,9783,4313,5172,1567,8269,168,220,168,5236,9957]

theorem envBound7208 : H12AffineFastState.Bounded env7208 := by
  intro p hp
  have h : env7208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7207_7208 : H12AffineEnvironment.transform 10 1686 env7207 = env7208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1686 env7207 == env7208) = true)

def env7209 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,152,8192,169,8353,1127,1141,603,1056,8353,9412,33,48,9326,8328,9349,9783,65,1196,1567,8269,168,220,168,1260,9957]

theorem envBound7209 : H12AffineFastState.Bounded env7209 := by
  intro p hp
  have h : env7209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7208_7209 : H12AffineEnvironment.transform 11 152 env7208 = env7209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env7208 == env7209) = true)

def env7210 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,152,160,169,1,1127,1141,603,1056,1,1124,33,48,1230,40,1061,1687,65,1196,1567,237,168,220,168,1260,1605]

theorem envBound7210 : H12AffineFastState.Bounded env7210 := by
  intro p hp
  have h : env7210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7209_7210 : H12AffineEnvironment.transform 12 160 env7209 = env7210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7209 == env7210) = true)

def env7211 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,152,161,169,0,1127,1141,603,1056,0,1125,33,48,1231,41,1060,1686,65,1196,1567,236,168,220,168,1260,1604]

theorem envBound7211 : H12AffineFastState.Bounded env7211 := by
  intro p hp
  have h : env7211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7209_7211 : H12AffineEnvironment.transform 12 161 env7209 = env7211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7209 == env7211) = true)

theorem identity7211 : scanCanonicalize (H12AffineFastState.compose env7211 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound7211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7212 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1566,16,41,33,0,1127,1141,603,1056,0,1125,33,48,1095,41,1060,1566,65,1060,1567,100,32,84,32,1124,1604]

theorem envBound7212 : H12AffineFastState.Bounded env7212 := by
  intro p hp
  have h : env7212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7211_7212 : H12AffineEnvironment.transform 6 8 env7211 = env7212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7211 == env7212) = true)

theorem identity7212 : scanCanonicalize (H12AffineFastState.compose env7212 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound7212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7213 : List Nat := [2,4,8,16,32,64,8,116,512,543,1,16,41,33,0,632,618,603,575,0,634,33,48,600,41,571,1,65,571,0,100,32,84,32,635,91]

theorem envBound7213 : H12AffineFastState.Bounded env7213 := by
  intro p hp
  have h : env7213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7212_7213 : H12AffineEnvironment.transform 9 543 env7212 = env7213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env7212 == env7213) = true)

theorem identity7213 : scanCanonicalize (H12AffineFastState.compose env7213 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound7213 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7214 : List Nat := [2,4,8,16,32,64,8,116,91,68,1,16,41,33,0,35,49,0,100,0,33,33,48,3,41,96,1,65,96,0,100,32,84,32,32,91]

theorem envBound7214 : H12AffineFastState.Bounded env7214 := by
  intro p hp
  have h : env7214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7213_7214 : H12AffineEnvironment.transform 8 91 env7213 = env7214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env7213 == env7214) = true)

theorem identity7214 : scanCanonicalize (H12AffineFastState.compose env7214 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound7214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7215 : List Nat := [2,4,8,8,32,64,8,108,67,68,1,8,41,33,0,35,41,0,100,0,33,33,40,3,41,96,1,65,96,0,100,32,76,32,32,67]

theorem envBound7215 : H12AffineFastState.Bounded env7215 := by
  intro p hp
  have h : env7215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7214_7215 : H12AffineEnvironment.transform 3 8 env7214 = env7215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env7214 == env7215) = true)

theorem identity7215 : scanCanonicalize (H12AffineFastState.compose env7215 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7216 : List Nat := [2,4,8,8,12,64,8,64,67,68,1,8,5,13,0,15,5,0,72,0,13,13,4,3,5,76,1,65,76,0,72,12,76,12,12,67]

theorem envBound7216 : H12AffineFastState.Bounded env7216 := by
  intro p hp
  have h : env7216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7215_7216 : H12AffineEnvironment.transform 4 12 env7215 = env7216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7215 == env7216) = true)

def leafEnv7216 : List Nat := [2,4,8,8,12,64,8,64,67,68,1,8,5,13,0,15,5,0,72,0,13,13,4,3,68,5,1,76,1,65,76,0,72,12,76,12,8,14,12,67,1,12,0]

def active7216 : List Nat := [0,1,2,5]

def tree7216 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7216 : H12WitnessSearch.Good tree7216 := H12GlobalWitnessIndex.good

theorem leafIdentity7216 : H12AffineFastState.composeSystem env7216 rootObs = leafEnv7216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7216 rootObs == leafEnv7216) = true)

theorem terminalChecked7216 : H12PackedTerminal.terminalCheckFast leafEnv7216 active7216 tree7216 = true := by decide +kernel

def env7217 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,153,8192,168,8353,1127,1140,603,1056,8353,9413,33,48,9326,8328,9349,9783,64,1197,1567,8269,168,220,168,1261,9957]

theorem envBound7217 : H12AffineFastState.Bounded env7217 := by
  intro p hp
  have h : env7217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7208_7217 : H12AffineEnvironment.transform 11 153 env7208 = env7217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env7208 == env7217) = true)

def env7218 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,153,160,168,1,1127,1140,603,1056,1,1125,33,48,1230,40,1061,1687,64,1197,1567,237,168,220,168,1261,1605]

theorem envBound7218 : H12AffineFastState.Bounded env7218 := by
  intro p hp
  have h : env7218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7217_7218 : H12AffineEnvironment.transform 12 160 env7217 = env7218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7217 == env7218) = true)

theorem identity7218 : scanCanonicalize (H12AffineFastState.compose env7218 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7218 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7219 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,153,160,168,1,35,48,603,100,1,33,33,48,138,40,97,723,64,233,603,237,168,220,168,169,513]

theorem envBound7219 : H12AffineFastState.Bounded env7219 := by
  intro p hp
  have h : env7219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7218_7219 : H12AffineEnvironment.transform 9 68 env7218 = env7219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7218 == env7219) = true)

theorem identity7219 : scanCanonicalize (H12AffineFastState.compose env7219 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 193) := by decide +kernel

theorem selectedBound7219 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7220 : List Nat := [2,4,8,16,32,64,128,252,193,68,19,153,160,168,1,35,48,154,100,1,33,33,48,138,40,97,18,64,233,154,237,168,220,168,169,192]

theorem envBound7220 : H12AffineFastState.Bounded env7220 := by
  intro p hp
  have h : env7220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7219_7220 : H12AffineEnvironment.transform 8 193 env7219 = env7220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 193 env7219 == env7220) = true)

def env7221 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,153,161,168,0,1127,1140,603,1056,0,1124,33,48,1231,41,1060,1686,64,1197,1567,236,168,220,168,1261,1604]

theorem envBound7221 : H12AffineFastState.Bounded env7221 := by
  intro p hp
  have h : env7221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7217_7221 : H12AffineEnvironment.transform 12 161 env7217 = env7221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7217 == env7221) = true)

theorem identity7221 : scanCanonicalize (H12AffineFastState.compose env7221 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound7221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7222 : List Nat := [2,4,8,16,32,64,128,252,512,204,602,153,161,168,0,171,184,603,236,0,168,33,48,3,41,232,602,64,97,723,236,168,220,168,33,648]

theorem envBound7222 : H12AffineFastState.Bounded env7222 := by
  intro p hp
  have h : env7222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7221_7222 : H12AffineEnvironment.transform 9 204 env7221 = env7222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env7221 == env7222) = true)

theorem identity7222 : scanCanonicalize (H12AffineFastState.compose env7222 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound7222 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7223 : List Nat := [2,4,8,16,32,64,128,252,90,204,0,153,161,168,0,171,184,1,236,0,168,33,48,3,41,232,0,64,97,137,236,168,220,168,33,210]

theorem envBound7223 : H12AffineFastState.Bounded env7223 := by
  intro p hp
  have h : env7223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7222_7223 : H12AffineEnvironment.transform 8 90 env7222 = env7223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env7222 == env7223) = true)

theorem identity7223 : scanCanonicalize (H12AffineFastState.compose env7223 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound7223 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7224 : List Nat := [2,4,8,16,32,64,8,116,90,68,0,17,41,32,0,35,48,1,100,0,32,33,48,3,41,96,0,64,97,1,100,32,84,32,33,90]

theorem envBound7224 : H12AffineFastState.Bounded env7224 := by
  intro p hp
  have h : env7224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7223_7224 : H12AffineEnvironment.transform 6 8 env7223 = env7224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7223 == env7224) = true)

theorem identity7224 : scanCanonicalize (H12AffineFastState.compose env7224 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound7224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7225 : List Nat := [2,4,8,9,32,64,8,109,67,68,0,8,41,32,0,35,41,1,100,0,32,33,41,3,41,96,0,64,97,1,100,32,77,32,33,67]

theorem envBound7225 : H12AffineFastState.Bounded env7225 := by
  intro p hp
  have h : env7225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7224_7225 : H12AffineEnvironment.transform 3 9 env7224 = env7225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env7224 == env7225) = true)

theorem identity7225 : scanCanonicalize (H12AffineFastState.compose env7225 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7226 : List Nat := [2,4,8,9,13,64,8,64,67,68,0,8,4,13,0,14,4,1,73,0,13,12,4,3,4,77,0,64,76,1,73,13,77,13,12,67]

theorem envBound7226 : H12AffineFastState.Bounded env7226 := by
  intro p hp
  have h : env7226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7225_7226 : H12AffineEnvironment.transform 4 13 env7225 = env7226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7225 == env7226) = true)

def leafEnv7226 : List Nat := [2,4,8,9,13,64,8,64,67,68,0,8,4,13,0,14,4,1,73,0,13,12,4,3,68,4,1,77,0,64,76,1,73,13,77,13,9,15,12,67,1,12,0]

def active7226 : List Nat := [0,1,2,5]

def tree7226 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7226 : H12WitnessSearch.Good tree7226 := H12GlobalWitnessIndex.good

theorem leafIdentity7226 : H12AffineFastState.composeSystem env7226 rootObs = leafEnv7226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7226 rootObs == leafEnv7226) = true)

theorem terminalChecked7226 : H12PackedTerminal.terminalCheckFast leafEnv7226 active7226 tree7226 = true := by decide +kernel

def env7227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62641,32768,2097152,41088,8388608,8507732,8328,118899,360618,10584178,10719346,8411509,99703,40969,61873,8409428,34359738368,98851]

theorem envBound7227 : H12AffineFastState.Bounded env7227 := by
  intro p hp
  have h : env7227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7103_7227 : H12AffineEnvironment.transform 18 62641 env7103 = env7227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62641 env7103 == env7227) = true)

theorem identity7227 : scanCanonicalize (H12AffineFastState.compose env7227 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103730) := by decide +kernel

theorem selectedBound7227 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41088,8388608,8507732,8328,118899,360618,10584178,10487104,8411509,99703,40969,61873,8409428,34359738368,98851]

theorem envBound7228 : H12AffineFastState.Bounded env7228 := by
  intro p hp
  have h : env7228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7227_7228 : H12AffineEnvironment.transform 16 103730 env7227 = env7228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103730 env7227 == env7228) = true)

def env7229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41088,20480,98644,8328,118899,360618,2216050,2118976,2421,99703,40969,61873,340,34359738368,98851]

theorem envBound7229 : H12AffineFastState.Bounded env7229 := by
  intro p hp
  have h : env7229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7228_7229 : H12AffineEnvironment.transform 22 20480 env7228 = env7229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env7228 == env7229) = true)

theorem identity7229 : scanCanonicalize (H12AffineFastState.compose env7229 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7229 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7230 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62641,32768,2097152,41088,20480,98472,8328,118899,360618,2216050,2118844,2185,99467,40969,61517,168,34359738368,98851]

theorem envBound7230 : H12AffineFastState.Bounded env7230 := by
  intro p hp
  have h : env7230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7229_7230 : H12AffineEnvironment.transform 7 252 env7229 = env7230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7229 == env7230) = true)

theorem identity7230 : scanCanonicalize (H12AffineFastState.compose env7230 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 310484) := by decide +kernel

theorem selectedBound7230 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7231 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62641,32768,310484,41088,20480,98472,8328,118899,360618,355494,321640,2185,99467,40969,61517,168,34359738368,98851]

theorem envBound7231 : H12AffineFastState.Bounded env7231 := by
  intro p hp
  have h : env7231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7230_7231 : H12AffineEnvironment.transform 20 310484 env7230 = env7231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310484 env7230 == env7231) = true)

theorem identity7231 : scanCanonicalize (H12AffineFastState.compose env7231 (packedSelected [11,13,18] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7231 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env7232 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,78959,262144,21520,8353,269429,33,20480,73737,8328,94418,335883,355494,280777,2185,74794,168,20716,168,34359738368,74370]

theorem envBound7232 : H12AffineFastState.Bounded env7232 := by
  intro p hp
  have h : env7232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7231_7232 : H12AffineEnvironment.transform 14 8353 env7231 = env7232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7231 == env7232) = true)

theorem identity7232 : scanCanonicalize (H12AffineFastState.compose env7232 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7232 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env7233 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,78959,262144,21520,8353,269429,33,20480,73737,8328,94418,335883,355494,280777,2185,74794,168,20716,168,280712,74370]

theorem envBound7233 : H12AffineFastState.Bounded env7233 := by
  intro p hp
  have h : env7233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7232_7233 : H12AffineEnvironment.transform 34 280712 env7232 = env7233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7232 == env7233) = true)

theorem identity7233 : scanCanonicalize (H12AffineFastState.compose env7233 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound7233 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7234 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,65536,78959,262144,2743,8353,269429,33,3751,73737,8328,77429,335883,340481,267886,2185,74794,168,3659,168,267823,74370]

theorem envBound7234 : H12AffineFastState.Bounded env7234 := by
  intro p hp
  have h : env7234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7233_7234 : H12AffineEnvironment.transform 13 7847 env7233 = env7234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env7233 == env7234) = true)

def env7235 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,16031,262144,2743,8353,269429,33,3751,11001,8328,9349,273147,276721,267886,2185,11994,168,3659,168,267823,10354]

theorem envBound7235 : H12AffineFastState.Bounded env7235 := by
  intro p hp
  have h : env7235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7234_7235 : H12AffineEnvironment.transform 15 2800 env7234 = env7235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7234 == env7235) = true)

def env7236 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,16031,3276,2743,8353,4281,33,3751,11001,8328,9349,9783,13373,6818,2185,11994,168,3659,168,6883,10354]

theorem envBound7236 : H12AffineFastState.Bounded env7236 := by
  intro p hp
  have h : env7236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7235_7236 : H12AffineEnvironment.transform 17 3276 env7235 = env7236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3276 env7235 == env7236) = true)

theorem identity7236 : scanCanonicalize (H12AffineFastState.compose env7236 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1686) := by decide +kernel

theorem selectedBound7236 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7237 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,4096,8192,4145,8353,1126,12297,602,1057,8353,4281,33,49,9327,8328,9349,9783,13373,5172,1567,8268,168,221,168,5237,9956]

theorem envBound7237 : H12AffineFastState.Bounded env7237 := by
  intro p hp
  have h : env7237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7236_7237 : H12AffineEnvironment.transform 10 1686 env7236 = env7237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1686 env7236 == env7237) = true)

def env7238 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,4096,4152,4145,4249,1126,49,602,1057,4249,4281,33,49,5207,4272,5309,5647,1029,5172,1567,4212,168,221,168,5237,5852]

theorem envBound7238 : H12AffineFastState.Bounded env7238 := by
  intro p hp
  have h : env7238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7237_7238 : H12AffineEnvironment.transform 12 4152 env7237 = env7238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env7237 == env7238) = true)

def env7239 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,16,40,33,137,1126,49,602,1057,137,169,33,49,1095,160,1197,1567,1029,1060,1567,100,168,221,168,1125,1740]

theorem envBound7239 : H12AffineFastState.Bounded env7239 := by
  intro p hp
  have h : env7239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7238_7239 : H12AffineEnvironment.transform 11 16 env7238 = env7239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7238 == env7239) = true)

def env7240 : List Nat := [2,4,8,16,32,64,128,252,512,216,590,16,40,33,137,190,49,602,249,137,169,33,49,159,160,117,711,221,252,711,100,168,221,168,189,532]

theorem envBound7240 : H12AffineFastState.Bounded env7240 := by
  intro p hp
  have h : env7240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7239_7240 : H12AffineEnvironment.transform 9 216 env7239 = env7240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 216 env7239 == env7240) = true)

theorem identity7240 : scanCanonicalize (H12AffineFastState.compose env7240 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 76) := by decide +kernel

theorem selectedBound7240 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7241 : List Nat := [2,4,8,16,32,64,76,48,512,20,590,16,40,33,69,114,49,602,53,69,101,33,49,83,108,117,523,17,48,523,100,100,17,100,113,532]

theorem envBound7241 : H12AffineFastState.Bounded env7241 := by
  intro p hp
  have h : env7241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7240_7241 : H12AffineEnvironment.transform 6 76 env7240 = env7241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 76 env7240 == env7241) = true)

def env7242 : List Nat := [2,4,8,16,32,4,8,48,512,20,522,16,40,33,1,54,49,542,53,1,33,33,49,23,40,49,523,17,48,523,32,32,17,32,53,532]

theorem envBound7242 : H12AffineFastState.Bounded env7242 := by
  intro p hp
  have h : env7242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7241_7242 : H12AffineEnvironment.transform 5 4 env7241 = env7242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env7241 == env7242) = true)

theorem identity7242 : scanCanonicalize (H12AffineFastState.compose env7242 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound7242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7243 : List Nat := [2,4,8,5,32,4,8,37,512,1,522,5,40,33,1,35,36,523,32,1,33,33,36,2,40,36,523,4,37,523,32,32,4,32,32,513]

theorem envBound7243 : H12AffineFastState.Bounded env7243 := by
  intro p hp
  have h : env7243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7242_7243 : H12AffineEnvironment.transform 3 5 env7242 = env7243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7242 == env7243) = true)

theorem identity7243 : scanCanonicalize (H12AffineFastState.compose env7243 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound7243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7244 : List Nat := [2,3,8,2,32,3,8,34,512,1,522,2,40,33,1,35,35,523,32,1,33,33,35,2,40,35,523,3,34,523,32,32,3,32,32,513]

theorem envBound7244 : H12AffineFastState.Bounded env7244 := by
  intro p hp
  have h : env7244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7243_7244 : H12AffineEnvironment.transform 1 3 env7243 = env7244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env7243 == env7244) = true)

theorem identity7244 : scanCanonicalize (H12AffineFastState.compose env7244 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7244 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7245 : List Nat := [2,3,8,2,32,3,8,34,10,1,0,2,40,33,1,35,35,1,32,1,33,33,35,2,40,35,1,3,34,1,32,32,3,32,32,11]

theorem envBound7245 : H12AffineFastState.Bounded env7245 := by
  intro p hp
  have h : env7245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7244_7245 : H12AffineEnvironment.transform 8 10 env7244 = env7245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7244 == env7245) = true)

def env7246 : List Nat := [2,4,8,16,32,5,9,48,512,20,523,16,40,33,0,55,49,543,53,0,32,33,49,22,41,48,523,17,48,523,33,33,17,33,52,532]

theorem envBound7246 : H12AffineFastState.Bounded env7246 := by
  intro p hp
  have h : env7246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7241_7246 : H12AffineEnvironment.transform 5 5 env7241 = env7246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7241 == env7246) = true)

theorem identity7246 : scanCanonicalize (H12AffineFastState.compose env7246 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7247 : List Nat := [2,4,8,16,32,5,9,48,10,20,1,16,40,33,0,55,49,21,53,0,32,33,49,22,41,48,1,17,48,1,33,33,17,33,52,30]

theorem envBound7247 : H12AffineFastState.Bounded env7247 := by
  intro p hp
  have h : env7247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7246_7247 : H12AffineEnvironment.transform 8 10 env7246 = env7247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7246 == env7247) = true)

theorem identity7247 : scanCanonicalize (H12AffineFastState.compose env7247 (packedSelected [20] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7247 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7248 : List Nat := [2,4,8,4,32,5,9,36,10,0,1,4,40,33,0,35,37,1,33,0,32,33,37,2,41,36,1,5,36,1,33,33,5,33,32,10]

theorem envBound7248 : H12AffineFastState.Bounded env7248 := by
  intro p hp
  have h : env7248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7247_7248 : H12AffineEnvironment.transform 3 4 env7247 = env7248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7247 == env7248) = true)

theorem identity7248 : scanCanonicalize (H12AffineFastState.compose env7248 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7249 : List Nat := [2,4,8,4,13,5,9,9,10,0,1,4,5,12,0,14,8,1,12,0,13,12,8,2,4,9,1,5,9,1,12,12,5,12,13,10]

theorem envBound7249 : H12AffineFastState.Bounded env7249 := by
  intro p hp
  have h : env7249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7248_7249 : H12AffineEnvironment.transform 4 13 env7248 = env7249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7248 == env7249) = true)

def leafEnv7249 : List Nat := [2,4,8,4,13,5,9,9,10,0,1,4,5,12,0,14,8,1,12,0,13,12,8,2,0,4,1,9,1,5,9,1,12,12,5,12,8,14,13,10,1,12,0]

def active7249 : List Nat := [0,1,2]

def tree7249 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7249 : H12WitnessSearch.Good tree7249 := H12GlobalWitnessIndex.good

theorem leafIdentity7249 : H12AffineFastState.composeSystem env7249 rootObs = leafEnv7249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7249 rootObs == leafEnv7249) = true)

theorem terminalChecked7249 : H12PackedTerminal.terminalCheckFast leafEnv7249 active7249 tree7249 = true := by decide +kernel

def env7250 : List Nat := [2,4,8,16,32,64,128,252,512,217,591,16,40,33,137,191,49,602,248,137,169,33,49,158,160,116,710,220,253,710,100,168,221,168,188,533]

theorem envBound7250 : H12AffineFastState.Bounded env7250 := by
  intro p hp
  have h : env7250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7239_7250 : H12AffineEnvironment.transform 9 217 env7239 = env7250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 217 env7239 == env7250) = true)

theorem identity7250 : scanCanonicalize (H12AffineFastState.compose env7250 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7250 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7251 : List Nat := [2,4,8,16,32,64,89,37,512,0,591,16,40,33,80,102,49,602,33,80,112,33,49,71,121,116,543,5,36,543,100,113,4,113,101,533]

theorem envBound7251 : H12AffineFastState.Bounded env7251 := by
  intro p hp
  have h : env7251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7250_7251 : H12AffineEnvironment.transform 6 89 env7250 = env7251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7250 == env7251) = true)

def env7252 : List Nat := [2,4,8,16,32,16,9,37,512,0,543,16,40,33,0,54,49,522,33,0,32,33,49,23,41,36,543,5,36,543,52,33,4,33,53,533]

theorem envBound7252 : H12AffineFastState.Bounded env7252 := by
  intro p hp
  have h : env7252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7251_7252 : H12AffineEnvironment.transform 5 16 env7251 = env7252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7251 == env7252) = true)

theorem identity7252 : scanCanonicalize (H12AffineFastState.compose env7252 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound7252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7253 : List Nat := [2,4,8,16,32,16,9,37,30,0,1,16,40,33,0,54,49,20,33,0,32,33,49,23,41,36,1,5,36,1,52,33,4,33,53,11]

theorem envBound7253 : H12AffineFastState.Bounded env7253 := by
  intro p hp
  have h : env7253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7252_7253 : H12AffineEnvironment.transform 8 30 env7252 = env7253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env7252 == env7253) = true)

theorem identity7253 : scanCanonicalize (H12AffineFastState.compose env7253 (packedSelected [20] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound7253 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7254 : List Nat := [2,4,8,5,32,5,9,37,11,0,1,5,40,33,0,35,36,1,33,0,32,33,36,2,41,36,1,5,36,1,33,33,4,33,32,11]

theorem envBound7254 : H12AffineFastState.Bounded env7254 := by
  intro p hp
  have h : env7254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7253_7254 : H12AffineEnvironment.transform 3 5 env7253 = env7254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7253 == env7254) = true)

theorem identity7254 : scanCanonicalize (H12AffineFastState.compose env7254 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7255 : List Nat := [2,4,8,5,13,5,9,8,11,0,1,5,5,12,0,14,9,1,12,0,13,12,9,2,4,9,1,5,9,1,12,12,4,12,13,11]

theorem envBound7255 : H12AffineFastState.Bounded env7255 := by
  intro p hp
  have h : env7255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7254_7255 : H12AffineEnvironment.transform 4 13 env7254 = env7255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7254 == env7255) = true)

def leafEnv7255 : List Nat := [2,4,8,5,13,5,9,8,11,0,1,5,5,12,0,14,9,1,12,0,13,12,9,2,0,4,1,9,1,5,9,1,12,12,4,12,8,14,13,11,1,12,0]

def active7255 : List Nat := [0,1,2]

def tree7255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7255 : H12WitnessSearch.Good tree7255 := H12GlobalWitnessIndex.good

theorem leafIdentity7255 : H12AffineFastState.composeSystem env7255 rootObs = leafEnv7255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7255 rootObs == leafEnv7255) = true)

theorem terminalChecked7255 : H12PackedTerminal.terminalCheckFast leafEnv7255 active7255 tree7255 = true := by decide +kernel

def env7256 : List Nat := [2,4,8,16,32,17,8,37,512,0,542,16,40,33,1,55,49,523,33,1,33,33,49,22,40,37,543,5,36,543,53,32,4,32,52,533]

theorem envBound7256 : H12AffineFastState.Bounded env7256 := by
  intro p hp
  have h : env7256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7251_7256 : H12AffineEnvironment.transform 5 17 env7251 = env7256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env7251 == env7256) = true)

theorem identity7256 : scanCanonicalize (H12AffineFastState.compose env7256 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7257 : List Nat := [2,4,8,4,32,5,8,37,512,0,522,4,40,33,1,35,37,523,33,1,33,33,37,2,40,37,523,5,36,523,33,32,4,32,32,513]

theorem envBound7257 : H12AffineFastState.Bounded env7257 := by
  intro p hp
  have h : env7257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7256_7257 : H12AffineEnvironment.transform 3 4 env7256 = env7257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7256 == env7257) = true)

theorem identity7257 : scanCanonicalize (H12AffineFastState.compose env7257 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7258 : List Nat := [2,2,8,2,32,3,8,35,512,0,522,2,40,33,1,35,35,523,33,1,33,33,35,2,40,35,523,3,34,523,33,32,2,32,32,513]

theorem envBound7258 : H12AffineFastState.Bounded env7258 := by
  intro p hp
  have h : env7258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7257_7258 : H12AffineEnvironment.transform 1 2 env7257 = env7258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7257 == env7258) = true)

theorem identity7258 : scanCanonicalize (H12AffineFastState.compose env7258 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7258 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7259 : List Nat := [2,2,8,2,32,3,8,35,10,0,0,2,40,33,1,35,35,1,33,1,33,33,35,2,40,35,1,3,34,1,33,32,2,32,32,11]

theorem envBound7259 : H12AffineFastState.Bounded env7259 := by
  intro p hp
  have h : env7259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7258_7259 : H12AffineEnvironment.transform 8 10 env7258 = env7259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7258 == env7259) = true)

def env7260 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,17,41,32,136,1126,49,602,1057,136,168,33,49,1094,161,1196,1566,1029,1061,1567,101,168,221,168,1124,1741]

theorem envBound7260 : H12AffineFastState.Bounded env7260 := by
  intro p hp
  have h : env7260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7238_7260 : H12AffineEnvironment.transform 11 17 env7238 = env7260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7238 == env7260) = true)

theorem identity7260 : scanCanonicalize (H12AffineFastState.compose env7260 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound7260 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7261 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1567,17,41,32,1,1126,49,602,1057,1,33,33,49,1094,40,1061,1566,1029,1061,1567,101,33,84,33,1124,1604]

theorem envBound7261 : H12AffineFastState.Bounded env7261 := by
  intro p hp
  have h : env7261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7260_7261 : H12AffineEnvironment.transform 6 9 env7260 = env7261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7260 == env7261) = true)

theorem identity7261 : scanCanonicalize (H12AffineFastState.compose env7261 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7261 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7262 : List Nat := [2,4,8,16,32,64,9,117,512,69,602,17,41,32,1,35,49,602,100,1,33,33,49,3,40,96,603,64,96,602,101,33,84,33,33,513]

theorem envBound7262 : H12AffineFastState.Bounded env7262 := by
  intro p hp
  have h : env7262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7261_7262 : H12AffineEnvironment.transform 9 69 env7261 = env7262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7261 == env7262) = true)

theorem identity7262 : scanCanonicalize (H12AffineFastState.compose env7262 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 73) := by decide +kernel

theorem selectedBound7262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7263 : List Nat := [2,4,8,16,32,64,9,117,73,69,19,17,41,32,1,35,49,19,100,1,33,33,49,3,40,96,18,64,96,19,101,33,84,33,33,72]

theorem envBound7263 : H12AffineFastState.Bounded env7263 := by
  intro p hp
  have h : env7263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7262_7263 : H12AffineEnvironment.transform 8 73 env7262 = env7263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 73 env7262 == env7263) = true)

theorem identity7263 : scanCanonicalize (H12AffineFastState.compose env7263 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound7263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7264 : List Nat := [2,4,8,16,32,2,9,55,11,7,19,17,41,32,1,35,49,19,38,1,33,33,49,3,40,34,18,2,34,19,39,33,22,33,33,10]

theorem envBound7264 : H12AffineFastState.Bounded env7264 := by
  intro p hp
  have h : env7264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7263_7264 : H12AffineEnvironment.transform 5 2 env7263 = env7264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env7263 == env7264) = true)

theorem identity7264 : scanCanonicalize (H12AffineFastState.compose env7264 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound7264 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7265 : List Nat := [2,4,8,3,32,2,9,36,11,7,0,2,41,32,1,35,34,0,38,1,33,33,34,3,40,34,1,2,34,0,39,33,5,33,33,10]

theorem envBound7265 : H12AffineFastState.Bounded env7265 := by
  intro p hp
  have h : env7265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7264_7265 : H12AffineEnvironment.transform 3 3 env7264 = env7265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env7264 == env7265) = true)

def env7266 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,4096,4153,4145,4248,1126,48,602,1057,4248,4281,33,49,5206,4273,5308,5646,1028,5172,1567,4213,168,221,168,5237,5853]

theorem envBound7266 : H12AffineFastState.Bounded env7266 := by
  intro p hp
  have h : env7266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7237_7266 : H12AffineEnvironment.transform 12 4153 env7237 = env7266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env7237 == env7266) = true)

def env7267 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,16,41,33,136,1126,48,602,1057,136,169,33,49,1094,161,1196,1566,1028,1060,1567,101,168,221,168,1125,1741]

theorem envBound7267 : H12AffineFastState.Bounded env7267 := by
  intro p hp
  have h : env7267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7266_7267 : H12AffineEnvironment.transform 11 16 env7266 = env7267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7266 == env7267) = true)

theorem identity7267 : scanCanonicalize (H12AffineFastState.compose env7267 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7267 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7268 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,16,41,33,136,34,48,602,101,136,169,33,49,2,161,232,602,64,96,603,101,168,221,168,33,649]

theorem envBound7268 : H12AffineFastState.Bounded env7268 := by
  intro p hp
  have h : env7268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7267_7268 : H12AffineEnvironment.transform 9 68 env7267 = env7268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7267 == env7268) = true)

def env7269 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,17,40,32,137,1126,48,602,1057,137,168,33,49,1095,160,1197,1567,1028,1061,1567,100,168,221,168,1124,1740]

theorem envBound7269 : H12AffineFastState.Bounded env7269 := by
  intro p hp
  have h : env7269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7266_7269 : H12AffineEnvironment.transform 11 17 env7266 = env7269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7266 == env7269) = true)

theorem identity7269 : scanCanonicalize (H12AffineFastState.compose env7269 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound7269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7270 : List Nat := [2,4,8,16,32,64,128,252,512,204,602,17,40,32,137,170,48,602,237,137,168,33,49,139,160,97,723,200,233,723,100,168,221,168,168,512]

theorem envBound7270 : H12AffineFastState.Bounded env7270 := by
  intro p hp
  have h : env7270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7269_7270 : H12AffineEnvironment.transform 9 204 env7269 = env7270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env7269 == env7270) = true)

theorem identity7270 : scanCanonicalize (H12AffineFastState.compose env7270 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound7270 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7271 : List Nat := [2,4,8,16,32,5,128,185,512,137,543,17,40,32,137,170,48,543,168,137,168,33,49,139,160,36,662,141,172,662,33,168,152,168,168,512]

theorem envBound7271 : H12AffineFastState.Bounded env7271 := by
  intro p hp
  have h : env7271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7270_7271 : H12AffineEnvironment.transform 5 5 env7270 = env7271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7270 == env7271) = true)

theorem identity7271 : scanCanonicalize (H12AffineFastState.compose env7271 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound7271 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7272 : List Nat := [2,4,8,16,32,5,9,48,512,0,543,17,40,32,0,35,48,543,33,0,33,33,49,2,41,36,543,4,37,543,33,33,17,33,33,512]

theorem envBound7272 : H12AffineFastState.Bounded env7272 := by
  intro p hp
  have h : env7272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7271_7272 : H12AffineEnvironment.transform 6 9 env7271 = env7272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7271 == env7272) = true)

theorem identity7272 : scanCanonicalize (H12AffineFastState.compose env7272 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7273 : List Nat := [2,4,8,16,12,5,9,28,512,0,543,17,4,12,0,15,28,543,13,0,13,13,29,2,5,8,543,4,9,543,13,13,17,13,13,512]

theorem envBound7273 : H12AffineFastState.Bounded env7273 := by
  intro p hp
  have h : env7273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7272_7273 : H12AffineEnvironment.transform 4 12 env7272 = env7273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7272 == env7273) = true)

theorem identity7273 : scanCanonicalize (H12AffineFastState.compose env7273 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound7273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7274 : List Nat := [2,4,8,16,12,5,9,28,31,0,0,17,4,12,0,15,28,0,13,0,13,13,29,2,5,8,0,4,9,0,13,13,17,13,13,31]

theorem envBound7274 : H12AffineFastState.Bounded env7274 := by
  intro p hp
  have h : env7274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7273_7274 : H12AffineEnvironment.transform 8 31 env7273 = env7274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env7273 == env7274) = true)

def leafEnv7274 : List Nat := [2,4,8,16,12,5,9,28,31,0,0,17,4,12,0,15,28,0,13,0,13,13,29,2,0,5,1,8,0,4,9,0,13,13,17,13,9,15,13,31,1,12,0]

def active7274 : List Nat := [0,1,2,3]

def tree7274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7274 : H12WitnessSearch.Good tree7274 := H12GlobalWitnessIndex.good

theorem leafIdentity7274 : H12AffineFastState.composeSystem env7274 rootObs = leafEnv7274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7274 rootObs == leafEnv7274) = true)

theorem terminalChecked7274 : H12PackedTerminal.terminalCheckFast leafEnv7274 active7274 tree7274 = true := by decide +kernel

def env7275 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,16031,3277,2743,8353,4280,33,3751,11001,8328,9349,9782,13372,6819,2185,11994,168,3659,168,6882,10354]

theorem envBound7275 : H12AffineFastState.Bounded env7275 := by
  intro p hp
  have h : env7275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7235_7275 : H12AffineEnvironment.transform 17 3277 env7235 = env7275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3277 env7235 == env7275) = true)

theorem identity7275 : scanCanonicalize (H12AffineFastState.compose env7275 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1253) := by decide +kernel

theorem selectedBound7275 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7276 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1253,7847,1092,2800,6778,3277,2743,1092,4280,33,3751,3612,1133,96,723,4313,6819,2185,2623,168,3659,168,6882,3223]

theorem envBound7276 : H12AffineFastState.Bounded env7276 := by
  intro p hp
  have h : env7276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7275_7276 : H12AffineEnvironment.transform 12 1253 env7275 = env7276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1253 env7275 == env7276) = true)

def env7277 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,16,1253,3767,1092,2800,2666,3277,2743,1092,168,33,3751,3612,1133,96,723,201,2739,2185,2623,168,3659,168,2802,3223]

theorem envBound7277 : H12AffineFastState.Bounded env7277 := by
  intro p hp
  have h : env7277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7276_7277 : H12AffineEnvironment.transform 11 16 env7276 = env7277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7276 == env7277) = true)

def env7278 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,16,1133,3647,1092,2680,2666,3141,2623,1092,32,33,3631,3612,1133,96,603,65,2619,2049,2623,32,3659,32,2682,3103]

theorem envBound7278 : H12AffineFastState.Bounded env7278 := by
  intro p hp
  have h : env7278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7277_7278 : H12AffineEnvironment.transform 6 8 env7277 = env7278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7277 == env7278) = true)

theorem identity7278 : scanCanonicalize (H12AffineFastState.compose env7278 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound7278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7279 : List Nat := [2,4,8,16,32,64,8,116,512,1024,603,16,1133,1124,1092,35,49,1566,100,1092,32,33,1140,1095,1133,96,603,65,96,602,100,32,1040,32,33,1604]

theorem envBound7279 : H12AffineFastState.Bounded env7279 := by
  intro p hp
  have h : env7279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7278_7279 : H12AffineEnvironment.transform 10 603 env7278 = env7279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env7278 == env7279) = true)

theorem identity7279 : scanCanonicalize (H12AffineFastState.compose env7279 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound7279 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7280 : List Nat := [2,4,8,16,32,64,8,116,512,542,603,16,627,634,602,35,49,0,100,602,32,33,618,601,627,96,603,65,96,602,100,32,526,32,33,90]

theorem envBound7280 : H12AffineFastState.Bounded env7280 := by
  intro p hp
  have h : env7280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7279_7280 : H12AffineEnvironment.transform 9 542 env7279 = env7280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env7279 == env7280) = true)

theorem identity7280 : scanCanonicalize (H12AffineFastState.compose env7280 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound7280 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7281 : List Nat := [2,4,8,16,32,64,8,116,90,68,1,16,41,32,0,35,49,0,100,0,32,33,48,3,41,96,1,65,96,0,100,32,84,32,33,90]

theorem envBound7281 : H12AffineFastState.Bounded env7281 := by
  intro p hp
  have h : env7281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7280_7281 : H12AffineEnvironment.transform 8 90 env7280 = env7281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env7280 == env7281) = true)

theorem identity7281 : scanCanonicalize (H12AffineFastState.compose env7281 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound7281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7282 : List Nat := [2,4,8,16,32,9,8,61,19,13,1,16,41,32,0,35,49,0,45,0,32,33,48,3,41,41,1,8,41,0,45,32,29,32,33,19]

theorem envBound7282 : H12AffineFastState.Bounded env7282 := by
  intro p hp
  have h : env7282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7281_7282 : H12AffineEnvironment.transform 5 9 env7281 = env7282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env7281 == env7282) = true)

theorem identity7282 : scanCanonicalize (H12AffineFastState.compose env7282 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7283 : List Nat := [2,4,8,4,32,9,8,41,7,13,1,4,41,32,0,35,37,0,45,0,32,33,36,3,41,41,1,8,41,0,45,32,9,32,33,7]

theorem envBound7283 : H12AffineFastState.Bounded env7283 := by
  intro p hp
  have h : env7283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7282_7283 : H12AffineEnvironment.transform 3 4 env7282 = env7283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7282 == env7283) = true)

def leafEnv7283 : List Nat := [2,4,8,4,32,9,8,41,7,13,1,4,41,32,0,35,37,0,45,0,32,33,36,3,13,41,1,41,1,8,41,0,45,32,9,32,36,34,33,7,1,33,0]

def active7283 : List Nat := [0,1,2,4]

def tree7283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7283 : H12WitnessSearch.Good tree7283 := H12GlobalWitnessIndex.good

theorem leafIdentity7283 : H12AffineFastState.composeSystem env7283 rootObs = leafEnv7283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7283 rootObs == leafEnv7283) = true)

theorem terminalChecked7283 : H12PackedTerminal.terminalCheckFast leafEnv7283 active7283 tree7283 = true := by decide +kernel

def env7284 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,16,1132,3646,1092,2681,2666,3140,2622,1092,33,33,3630,3612,1133,96,602,64,2618,2048,2623,33,3659,33,2683,3102]

theorem envBound7284 : H12AffineFastState.Bounded env7284 := by
  intro p hp
  have h : env7284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7277_7284 : H12AffineEnvironment.transform 6 9 env7277 = env7284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7277 == env7284) = true)

theorem identity7284 : scanCanonicalize (H12AffineFastState.compose env7284 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound7284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7285 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1567,16,1132,33,1092,1126,1141,603,1057,1092,33,33,49,3,1133,96,602,64,1061,1567,1056,33,84,33,1124,513]

theorem envBound7285 : H12AffineFastState.Bounded env7285 := by
  intro p hp
  have h : env7285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7284_7285 : H12AffineEnvironment.transform 10 1567 env7284 = env7285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env7284 == env7285) = true)

theorem identity7285 : scanCanonicalize (H12AffineFastState.compose env7285 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound7285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7286 : List Nat := [2,4,8,16,32,64,9,117,512,20,523,16,120,33,80,114,97,603,53,80,33,33,49,3,121,96,602,64,49,523,52,33,84,33,112,513]

theorem envBound7286 : H12AffineFastState.Bounded env7286 := by
  intro p hp
  have h : env7286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7285_7286 : H12AffineEnvironment.transform 9 20 env7285 = env7286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env7285 == env7286) = true)

theorem identity7286 : scanCanonicalize (H12AffineFastState.compose env7286 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound7286 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7287 : List Nat := [2,4,8,16,32,64,9,117,90,20,81,16,120,33,80,114,97,1,53,80,33,33,49,3,121,96,0,64,49,81,52,33,84,33,112,91]

theorem envBound7287 : H12AffineFastState.Bounded env7287 := by
  intro p hp
  have h : env7287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7286_7287 : H12AffineEnvironment.transform 8 90 env7286 = env7287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env7286 == env7287) = true)

def env7288 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,1253,3766,1092,2800,2667,3277,2743,1092,169,33,3751,3612,1133,96,723,200,2738,2185,2623,168,3659,168,2803,3223]

theorem envBound7288 : H12AffineFastState.Bounded env7288 := by
  intro p hp
  have h : env7288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7276_7288 : H12AffineEnvironment.transform 11 17 env7276 = env7288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7276 == env7288) = true)

def env7289 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,17,1133,3646,1092,2680,2667,3141,2623,1092,33,33,3631,3612,1133,96,603,64,2618,2049,2623,32,3659,32,2683,3103]

theorem envBound7289 : H12AffineFastState.Bounded env7289 := by
  intro p hp
  have h : env7289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7288_7289 : H12AffineEnvironment.transform 6 8 env7288 = env7289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7288 == env7289) = true)

theorem identity7289 : scanCanonicalize (H12AffineFastState.compose env7289 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7290 : List Nat := [2,4,8,16,32,64,8,116,512,68,2048,17,41,2682,0,2680,2667,2049,2623,0,33,33,2667,2648,41,96,603,64,2618,2049,2623,32,2575,32,2683,2139]

theorem envBound7290 : H12AffineFastState.Bounded env7290 := by
  intro p hp
  have h : env7290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7289_7290 : H12AffineEnvironment.transform 9 68 env7289 = env7290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7289 == env7290) = true)

theorem identity7290 : scanCanonicalize (H12AffineFastState.compose env7290 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound7290 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env7291 : List Nat := [2,4,8,16,32,64,8,116,512,68,0,17,41,634,0,632,619,1,575,0,33,33,619,600,41,96,603,64,570,1,575,32,527,32,635,91]

theorem envBound7291 : H12AffineFastState.Bounded env7291 := by
  intro p hp
  have h : env7291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7290_7291 : H12AffineEnvironment.transform 10 0 env7290 = env7291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env7290 == env7291) = true)

theorem identity7291 : scanCanonicalize (H12AffineFastState.compose env7291 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound7291 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7292 : List Nat := [2,4,8,16,32,64,8,116,91,68,0,17,41,33,0,35,48,1,100,0,33,33,48,3,41,96,0,64,97,1,100,32,84,32,32,91]

theorem envBound7292 : H12AffineFastState.Bounded env7292 := by
  intro p hp
  have h : env7292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7291_7292 : H12AffineEnvironment.transform 8 91 env7291 = env7292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env7291 == env7292) = true)

theorem identity7292 : scanCanonicalize (H12AffineFastState.compose env7292 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound7292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7293 : List Nat := [2,4,8,16,32,8,8,60,19,12,0,17,41,33,0,35,48,1,44,0,33,33,48,3,41,40,0,8,41,1,44,32,28,32,32,19]

theorem envBound7293 : H12AffineFastState.Bounded env7293 := by
  intro p hp
  have h : env7293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7292_7293 : H12AffineEnvironment.transform 5 8 env7292 = env7293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env7292 == env7293) = true)

theorem identity7293 : scanCanonicalize (H12AffineFastState.compose env7293 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7294 : List Nat := [2,4,8,4,32,8,8,40,7,12,0,5,41,33,0,35,36,1,44,0,33,33,36,3,41,40,0,8,41,1,44,32,8,32,32,7]

theorem envBound7294 : H12AffineFastState.Bounded env7294 := by
  intro p hp
  have h : env7294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7293_7294 : H12AffineEnvironment.transform 3 4 env7293 = env7294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7293 == env7294) = true)

def leafEnv7294 : List Nat := [2,4,8,4,32,8,8,40,7,12,0,5,41,33,0,35,36,1,44,0,33,33,36,3,12,41,1,40,0,8,41,1,44,32,8,32,36,34,32,7,1,32,0]

def active7294 : List Nat := [0,1,2,4]

def tree7294 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7294 : H12WitnessSearch.Good tree7294 := H12GlobalWitnessIndex.good

theorem leafIdentity7294 : H12AffineFastState.composeSystem env7294 rootObs = leafEnv7294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7294 rootObs == leafEnv7294) = true)

theorem terminalChecked7294 : H12PackedTerminal.terminalCheckFast leafEnv7294 active7294 tree7294 = true := by decide +kernel

def env7295 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,17,1132,3647,1092,2681,2667,3140,2622,1092,32,33,3630,3612,1133,96,602,65,2619,2048,2623,33,3659,33,2682,3102]

theorem envBound7295 : H12AffineFastState.Bounded env7295 := by
  intro p hp
  have h : env7295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7288_7295 : H12AffineEnvironment.transform 6 9 env7288 = env7295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7288 == env7295) = true)

def env7296 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,16030,262144,2743,8353,269429,33,3751,11000,8328,9348,273146,276720,267886,2185,11995,168,3659,168,267823,10355]

theorem envBound7296 : H12AffineFastState.Bounded env7296 := by
  intro p hp
  have h : env7296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7234_7296 : H12AffineEnvironment.transform 15 2801 env7234 = env7296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7234 == env7296) = true)

theorem identity7296 : scanCanonicalize (H12AffineFastState.compose env7296 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 8955) := by decide +kernel

theorem selectedBound7296 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7297 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,16030,8955,2743,8353,16014,33,3751,11000,8328,9348,2049,6667,13461,2185,11995,168,3659,168,13524,10355]

theorem envBound7297 : H12AffineFastState.Bounded env7297 := by
  intro p hp
  have h : env7297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7296_7297 : H12AffineEnvironment.transform 17 8955 env7296 = env7297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8955 env7296 == env7297) = true)

theorem identity7297 : scanCanonicalize (H12AffineFastState.compose env7297 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 2675) := by decide +kernel

theorem selectedBound7297 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7298 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2675,7847,2770,2801,5357,2184,2743,2770,5373,33,3751,139,2811,3831,2049,6667,7910,2185,1192,168,3659,168,7847,512]

theorem envBound7298 : H12AffineFastState.Bounded env7298 := by
  intro p hp
  have h : env7298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7297_7298 : H12AffineEnvironment.transform 12 2675 env7297 = env7298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2675 env7297 == env7298) = true)

theorem identity7298 : scanCanonicalize (H12AffineFastState.compose env7298 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7298 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7299 : List Nat := [2,4,8,16,32,64,128,252,512,68,2048,4096,2675,6883,2770,2801,4265,2184,2743,2770,4281,33,2787,139,2811,2739,2049,6667,6818,2185,236,168,2575,168,6883,512]

theorem envBound7299 : H12AffineFastState.Bounded env7299 := by
  intro p hp
  have h : env7299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7298_7299 : H12AffineEnvironment.transform 9 68 env7298 = env7299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7298 == env7299) = true)

theorem identity7299 : scanCanonicalize (H12AffineFastState.compose env7299 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 722) := by decide +kernel

theorem selectedBound7299 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7300 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,4096,161,4145,0,35,4265,602,101,0,4281,33,49,139,41,97,723,4313,4208,603,236,168,221,168,4145,512]

theorem envBound7300 : H12AffineFastState.Bounded env7300 := by
  intro p hp
  have h : env7300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7299_7300 : H12AffineEnvironment.transform 10 722 env7299 = env7300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 722 env7299 == env7300) = true)

theorem identity7300 : scanCanonicalize (H12AffineFastState.compose env7300 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 671) := by decide +kernel

theorem selectedBound7300 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7301 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,671,161,686,0,35,566,602,101,0,550,33,49,139,41,97,723,582,751,603,236,168,221,168,686,512]

theorem envBound7301 : H12AffineFastState.Bounded env7301 := by
  intro p hp
  have h : env7301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7300_7301 : H12AffineEnvironment.transform 11 671 env7300 = env7301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 671 env7300 == env7301) = true)

def env7302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41088,20481,98645,8328,118899,360618,2216051,2118977,2420,99703,40969,61873,341,34359738368,98851]

theorem envBound7302 : H12AffineFastState.Bounded env7302 := by
  intro p hp
  have h : env7302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7228_7302 : H12AffineEnvironment.transform 22 20481 env7228 = env7302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env7228 == env7302) = true)

def env7303 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62641,32768,2097152,41088,20481,98473,8328,118899,360618,2216051,2118845,2184,99467,40969,61517,169,34359738368,98851]

theorem envBound7303 : H12AffineFastState.Bounded env7303 := by
  intro p hp
  have h : env7303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7302_7303 : H12AffineEnvironment.transform 7 252 env7302 = env7303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7302 == env7303) = true)

theorem identity7303 : scanCanonicalize (H12AffineFastState.compose env7303 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 269429) := by decide +kernel

theorem selectedBound7303 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7304 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62641,32768,269429,41088,20481,98473,8328,118899,360618,379910,280776,2184,99467,40969,61517,169,34359738368,98851]

theorem envBound7304 : H12AffineFastState.Bounded env7304 := by
  intro p hp
  have h : env7304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7303_7304 : H12AffineEnvironment.transform 20 269429 env7303 = env7304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 269429 env7303 == env7304) = true)

theorem identity7304 : scanCanonicalize (H12AffineFastState.compose env7304 (packedSelected [11,13,18] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7304 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env7305 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,78958,262144,21521,8352,269429,32,20481,73737,8328,94419,335882,355494,280776,2184,74795,169,20717,169,34359738368,74371]

theorem envBound7305 : H12AffineFastState.Bounded env7305 := by
  intro p hp
  have h : env7305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7304_7305 : H12AffineEnvironment.transform 14 8352 env7304 = env7305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7304 == env7305) = true)

theorem identity7305 : scanCanonicalize (H12AffineFastState.compose env7305 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7305 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7306 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,78958,262144,21521,8352,269429,32,20481,73737,8328,94419,335882,355494,280776,2184,74795,169,20717,169,280712,74371]

theorem envBound7306 : H12AffineFastState.Bounded env7306 := by
  intro p hp
  have h : env7306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7305_7306 : H12AffineEnvironment.transform 34 280712 env7305 = env7306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7305 == env7306) = true)

theorem identity7306 : scanCanonicalize (H12AffineFastState.compose env7306 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound7306 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7307 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,65536,78958,262144,2743,8352,269429,32,3751,73737,8328,77429,335882,340480,267886,2184,74795,169,3659,169,267822,74371]

theorem envBound7307 : H12AffineFastState.Bounded env7307 := by
  intro p hp
  have h : env7307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7306_7307 : H12AffineEnvironment.transform 13 7846 env7306 = env7307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env7306 == env7307) = true)

def env7308 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,16030,262144,2743,8352,269429,32,3751,11001,8328,9349,273146,276720,267886,2184,11995,169,3659,169,267822,10355]

theorem envBound7308 : H12AffineFastState.Bounded env7308 := by
  intro p hp
  have h : env7308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7307_7308 : H12AffineEnvironment.transform 15 2800 env7307 = env7308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7307 == env7308) = true)

theorem identity7308 : scanCanonicalize (H12AffineFastState.compose env7308 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 4113) := by decide +kernel

theorem selectedBound7308 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7309 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,16030,4113,2743,8352,3172,32,3751,11001,8328,9349,15083,10465,1663,2184,11995,169,3659,169,1599,10355]

theorem envBound7309 : H12AffineFastState.Bounded env7309 := by
  intro p hp
  have h : env7309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7308_7309 : H12AffineEnvironment.transform 17 4113 env7308 = env7309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4113 env7308 == env7309) = true)

theorem identity7309 : scanCanonicalize (H12AffineFastState.compose env7309 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 723) := by decide +kernel

theorem selectedBound7309 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7310 : List Nat := [2,4,8,16,32,64,128,252,512,1024,723,4096,8192,5237,8352,35,13389,4113,100,8352,1719,32,1140,8234,8328,9349,12344,8754,1663,603,9224,169,1176,169,1599,8864]

theorem envBound7310 : H12AffineFastState.Bounded env7310 := by
  intro p hp
  have h : env7310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7309_7310 : H12AffineEnvironment.transform 10 723 env7309 = env7310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 723 env7309 == env7310) = true)

theorem identity7310 : scanCanonicalize (H12AffineFastState.compose env7310 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1253) := by decide +kernel

theorem selectedBound7310 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7311 : List Nat := [2,4,8,16,32,64,128,252,512,1024,723,4096,1253,5237,1093,35,4264,4113,100,1093,1719,32,1140,1231,1133,96,5341,1751,1663,603,237,169,1176,169,1599,1605]

theorem envBound7311 : H12AffineFastState.Bounded env7311 := by
  intro p hp
  have h : env7311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7310_7311 : H12AffineEnvironment.transform 12 1253 env7310 = env7311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1253 env7310 == env7311) = true)

theorem identity7311 : scanCanonicalize (H12AffineFastState.compose env7311 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7311 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env7312 : List Nat := [2,4,8,16,32,64,128,252,512,69,723,4096,160,4144,0,35,4264,4113,100,0,754,32,49,138,40,96,4248,658,570,603,237,169,221,169,634,512]

theorem envBound7312 : H12AffineFastState.Bounded env7312 := by
  intro p hp
  have h : env7312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7311_7312 : H12AffineEnvironment.transform 9 69 env7311 = env7312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7311 == env7312) = true)

theorem identity7312 : scanCanonicalize (H12AffineFastState.compose env7312 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 607) := by decide +kernel

theorem selectedBound7312 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env7313 : List Nat := [2,4,8,16,32,64,128,252,512,69,723,607,160,623,0,35,759,590,100,0,754,32,49,138,40,96,711,658,570,603,237,169,221,169,634,512]

theorem envBound7313 : H12AffineFastState.Bounded env7313 := by
  intro p hp
  have h : env7313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7312_7313 : H12AffineEnvironment.transform 11 607 env7312 = env7313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 607 env7312 == env7313) = true)

def env7314 : List Nat := [2,4,8,4,32,64,128,232,512,69,711,587,160,623,0,35,739,590,100,0,742,32,37,138,40,96,711,646,558,591,237,169,201,169,622,512]

theorem envBound7314 : H12AffineFastState.Bounded env7314 := by
  intro p hp
  have h : env7314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7313_7314 : H12AffineEnvironment.transform 3 4 env7313 = env7314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7313 == env7314) = true)

theorem identity7314 : scanCanonicalize (H12AffineFastState.compose env7314 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound7314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7315 : List Nat := [2,4,8,4,32,9,128,161,512,12,654,514,160,550,0,35,682,519,45,0,687,32,37,138,40,41,654,646,558,518,164,169,128,169,551,512]

theorem envBound7315 : H12AffineFastState.Bounded env7315 := by
  intro p hp
  have h : env7315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7314_7315 : H12AffineEnvironment.transform 5 9 env7314 = env7315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env7314 == env7315) = true)

theorem identity7315 : scanCanonicalize (H12AffineFastState.compose env7315 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound7315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7316 : List Nat := [2,4,8,4,32,9,128,161,7,12,137,5,160,33,0,35,173,0,45,0,168,32,37,138,40,41,137,129,41,1,164,169,128,169,32,7]

theorem envBound7316 : H12AffineFastState.Bounded env7316 := by
  intro p hp
  have h : env7316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7315_7316 : H12AffineEnvironment.transform 8 7 env7315 = env7316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env7315 == env7316) = true)

def leafEnv7316 : List Nat := [2,4,8,4,32,9,128,161,7,12,137,5,160,33,0,35,173,0,45,0,168,32,37,138,132,40,1,41,137,129,41,1,164,169,128,169,36,171,32,7,1,168,0]

def active7316 : List Nat := [0,1,2,4,6]

def tree7316 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7316 : H12WitnessSearch.Good tree7316 := H12GlobalWitnessIndex.good

theorem leafIdentity7316 : H12AffineFastState.composeSystem env7316 rootObs = leafEnv7316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7316 rootObs == leafEnv7316) = true)

theorem terminalChecked7316 : H12PackedTerminal.terminalCheckFast leafEnv7316 active7316 tree7316 = true := by decide +kernel

def env7317 : List Nat := [2,4,8,5,32,64,128,233,512,69,710,586,160,623,0,35,738,590,100,0,743,32,36,138,40,96,711,647,559,590,237,169,200,169,623,512]

theorem envBound7317 : H12AffineFastState.Bounded env7317 := by
  intro p hp
  have h : env7317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7313_7317 : H12AffineEnvironment.transform 3 5 env7313 = env7317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7313 == env7317) = true)

theorem identity7317 : scanCanonicalize (H12AffineFastState.compose env7317 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound7317 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7318 : List Nat := [2,4,8,5,32,64,128,233,142,69,72,196,160,225,0,35,108,192,100,0,105,32,36,138,40,96,73,9,161,192,237,169,200,169,225,142]

theorem envBound7318 : H12AffineFastState.Bounded env7318 := by
  intro p hp
  have h : env7318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7317_7318 : H12AffineEnvironment.transform 8 142 env7317 = env7318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env7317 == env7318) = true)

theorem identity7318 : scanCanonicalize (H12AffineFastState.compose env7318 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound7318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7319 : List Nat := [2,4,8,5,32,9,128,160,142,12,1,141,160,168,0,35,37,137,45,0,32,32,36,138,40,41,0,9,161,137,164,169,129,169,168,142]

theorem envBound7319 : H12AffineFastState.Bounded env7319 := by
  intro p hp
  have h : env7319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7318_7319 : H12AffineEnvironment.transform 5 9 env7318 = env7319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env7318 == env7319) = true)

def leafEnv7319 : List Nat := [2,4,8,5,32,9,128,160,142,12,1,141,160,168,0,35,37,137,45,0,32,32,36,138,132,40,1,41,0,9,161,137,164,169,129,169,36,171,168,142,1,33,0]

def active7319 : List Nat := [0,1,2,4,6]

def tree7319 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7319 : H12WitnessSearch.Good tree7319 := H12GlobalWitnessIndex.good

theorem leafIdentity7319 : H12AffineFastState.composeSystem env7319 rootObs = leafEnv7319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7319 rootObs == leafEnv7319) = true)

theorem terminalChecked7319 : H12PackedTerminal.terminalCheckFast leafEnv7319 active7319 tree7319 = true := by decide +kernel

def env7320 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,16031,262144,2743,8352,269429,32,3751,11000,8328,9348,273147,276721,267886,2184,11994,169,3659,169,267822,10354]

theorem envBound7320 : H12AffineFastState.Bounded env7320 := by
  intro p hp
  have h : env7320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7307_7320 : H12AffineEnvironment.transform 15 2801 env7307 = env7320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7307 == env7320) = true)

theorem identity7320 : scanCanonicalize (H12AffineFastState.compose env7320 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 4842) := by decide +kernel

theorem selectedBound7320 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7321 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,4842,7846,4682,2801,3189,262144,2743,4682,269429,32,3751,6162,4706,5742,268305,264731,267886,2184,7216,169,3659,169,267822,6808]

theorem envBound7321 : H12AffineFastState.Bounded env7321 := by
  intro p hp
  have h : env7321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7320_7321 : H12AffineEnvironment.transform 12 4842 env7320 = env7321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4842 env7320 == env7321) = true)

theorem identity7321 : scanCanonicalize (H12AffineFastState.compose env7321 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound7321 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7322 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,586,160,3308,0,2801,3189,262144,2743,0,265791,32,3751,2648,40,1060,264795,264731,263204,2184,3706,169,3659,169,263268,2258]

theorem envBound7322 : H12AffineFastState.Bounded env7322 := by
  intro p hp
  have h : env7322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7321_7322 : H12AffineEnvironment.transform 11 586 env7321 = env7322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env7321 == env7322) = true)

theorem identity7322 : scanCanonicalize (H12AffineFastState.compose env7322 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1686) := by decide +kernel

theorem selectedBound7322 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env7323 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1686,586,160,634,0,1127,739,262144,1057,0,262313,32,49,1230,40,1060,263373,263309,263204,1566,236,169,221,169,263268,1604]

theorem envBound7323 : H12AffineFastState.Bounded env7323 := by
  intro p hp
  have h : env7323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7322_7323 : H12AffineEnvironment.transform 10 1686 env7322 = env7323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1686 env7322 == env7323) = true)

theorem identity7323 : scanCanonicalize (H12AffineFastState.compose env7323 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7323 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7324 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,586,160,634,0,35,739,262144,101,0,262313,32,49,138,40,96,262281,262345,262240,602,236,169,221,169,262176,512]

theorem envBound7324 : H12AffineFastState.Bounded env7324 := by
  intro p hp
  have h : env7324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7323_7324 : H12AffineEnvironment.transform 9 68 env7323 = env7324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7323 == env7324) = true)

theorem identity7324 : scanCanonicalize (H12AffineFastState.compose env7324 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 76) := by decide +kernel

theorem selectedBound7324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7325 : List Nat := [2,4,8,16,32,64,76,48,512,68,542,586,108,634,0,35,559,262144,101,0,262245,32,49,70,40,96,262213,262149,262240,602,32,101,17,101,262176,512]

theorem envBound7325 : H12AffineFastState.Bounded env7325 := by
  intro p hp
  have h : env7325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7324_7325 : H12AffineEnvironment.transform 6 76 env7324 = env7325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 76 env7324 == env7325) = true)

def env7326 : List Nat := [2,4,8,16,32,64,76,48,512,68,542,586,108,634,0,35,559,0,101,0,101,32,49,70,40,96,69,5,96,602,32,101,17,101,32,512]

theorem envBound7326 : H12AffineFastState.Bounded env7326 := by
  intro p hp
  have h : env7326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7325_7326 : H12AffineEnvironment.transform 17 0 env7325 = env7326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env7325 == env7326) = true)

theorem identity7326 : scanCanonicalize (H12AffineFastState.compose env7326 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 118) := by decide +kernel

theorem selectedBound7326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7327 : List Nat := [2,4,8,16,32,64,76,48,118,68,104,60,108,12,0,35,89,0,101,0,101,32,49,70,40,96,69,5,96,44,32,101,17,101,32,118]

theorem envBound7327 : H12AffineFastState.Bounded env7327 := by
  intro p hp
  have h : env7327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7326_7327 : H12AffineEnvironment.transform 8 118 env7326 = env7327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 118 env7326 == env7327) = true)

def env7328 : List Nat := [2,4,8,16,32,40,36,48,30,44,0,60,4,12,0,35,49,0,13,0,13,32,49,46,40,8,45,5,8,44,32,13,17,13,32,30]

theorem envBound7328 : H12AffineFastState.Bounded env7328 := by
  intro p hp
  have h : env7328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7327_7328 : H12AffineEnvironment.transform 5 40 env7327 = env7328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 40 env7327 == env7328) = true)

theorem identity7328 : scanCanonicalize (H12AffineFastState.compose env7328 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7329 : List Nat := [2,4,8,16,12,4,8,28,30,0,0,16,4,12,0,15,29,0,13,0,13,12,29,2,4,8,1,5,8,0,12,13,17,13,12,30]

theorem envBound7329 : H12AffineFastState.Bounded env7329 := by
  intro p hp
  have h : env7329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7328_7329 : H12AffineEnvironment.transform 4 12 env7328 = env7329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7328 == env7329) = true)

def leafEnv7329 : List Nat := [2,4,8,16,12,4,8,28,30,0,0,16,4,12,0,15,29,0,13,0,13,12,29,2,0,4,1,8,1,5,8,0,12,13,17,13,8,15,12,30,1,12,0]

def active7329 : List Nat := [0,1,2,3]

def tree7329 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7329 : H12WitnessSearch.Good tree7329 := H12GlobalWitnessIndex.good

theorem leafIdentity7329 : H12AffineFastState.composeSystem env7329 rootObs = leafEnv7329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7329 rootObs == leafEnv7329) = true)

theorem terminalChecked7329 : H12PackedTerminal.terminalCheckFast leafEnv7329 active7329 tree7329 = true := by decide +kernel

def env7330 : List Nat := [2,4,8,16,32,41,37,48,31,45,1,60,5,12,0,35,48,0,12,0,12,32,49,47,40,9,44,5,9,44,32,12,17,12,32,31]

theorem envBound7330 : H12AffineFastState.Bounded env7330 := by
  intro p hp
  have h : env7330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7327_7330 : H12AffineEnvironment.transform 5 41 env7327 = env7330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 41 env7327 == env7330) = true)

def env7331 : List Nat := [2,4,8,16,32,64,76,48,512,68,542,586,108,634,0,35,559,1,101,0,100,32,49,70,40,96,68,4,97,602,32,101,17,101,33,512]

theorem envBound7331 : H12AffineFastState.Bounded env7331 := by
  intro p hp
  have h : env7331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7325_7331 : H12AffineEnvironment.transform 17 1 env7325 = env7331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env7325 == env7331) = true)

theorem identity7331 : scanCanonicalize (H12AffineFastState.compose env7331 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7332 : List Nat := [2,4,8,16,12,64,76,28,512,68,542,586,64,598,0,15,515,1,73,0,72,12,29,70,4,76,68,4,77,602,12,73,17,73,13,512]

theorem envBound7332 : H12AffineFastState.Bounded env7332 := by
  intro p hp
  have h : env7332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7331_7332 : H12AffineEnvironment.transform 4 12 env7331 = env7332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7331 == env7332) = true)

def env7333 : List Nat := [2,4,8,16,12,4,8,28,512,0,542,526,4,530,0,15,515,1,13,0,12,12,29,2,4,8,0,4,9,542,12,13,17,13,13,512]

theorem envBound7333 : H12AffineFastState.Bounded env7333 := by
  intro p hp
  have h : env7333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7332_7333 : H12AffineEnvironment.transform 5 4 env7332 = env7333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env7332 == env7333) = true)

theorem identity7333 : scanCanonicalize (H12AffineFastState.compose env7333 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound7333 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7334 : List Nat := [2,4,8,16,12,4,8,28,30,0,0,16,4,12,0,15,29,1,13,0,12,12,29,2,4,8,0,4,9,0,12,13,17,13,13,30]

theorem envBound7334 : H12AffineFastState.Bounded env7334 := by
  intro p hp
  have h : env7334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7333_7334 : H12AffineEnvironment.transform 8 30 env7333 = env7334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env7333 == env7334) = true)

def leafEnv7334 : List Nat := [2,4,8,16,12,4,8,28,30,0,0,16,4,12,0,15,29,1,13,0,12,12,29,2,0,4,1,8,0,4,9,0,12,13,17,13,8,15,13,30,1,12,0]

def active7334 : List Nat := [0,1,2,3]

def tree7334 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7334 : H12WitnessSearch.Good tree7334 := H12GlobalWitnessIndex.good

theorem leafIdentity7334 : H12AffineFastState.composeSystem env7334 rootObs = leafEnv7334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7334 rootObs == leafEnv7334) = true)

theorem terminalChecked7334 : H12PackedTerminal.terminalCheckFast leafEnv7334 active7334 tree7334 = true := by decide +kernel

def env7335 : List Nat := [2,4,8,16,12,5,9,28,512,1,542,527,5,531,0,15,515,1,12,0,13,12,29,3,4,9,1,4,8,543,12,12,17,12,13,512]

theorem envBound7335 : H12AffineFastState.Bounded env7335 := by
  intro p hp
  have h : env7335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7332_7335 : H12AffineEnvironment.transform 5 5 env7332 = env7335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7332 == env7335) = true)

def leafEnv7335 : List Nat := [2,4,8,16,12,5,9,28,512,1,542,527,5,531,0,15,515,1,12,0,13,12,29,3,0,4,1,9,1,4,8,543,12,12,17,12,8,14,13,512,1,530,0]

def active7335 : List Nat := [0,1,2,3,8]

def tree7335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7335 : H12WitnessSearch.Good tree7335 := H12GlobalWitnessIndex.good

theorem leafIdentity7335 : H12AffineFastState.composeSystem env7335 rootObs = leafEnv7335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7335 rootObs == leafEnv7335) = true)

theorem terminalChecked7335 : H12PackedTerminal.terminalCheckFast leafEnv7335 active7335 tree7335 = true := by decide +kernel

def env7336 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62641,32768,2097152,41088,20481,98472,8328,118899,360618,2216051,2118844,2185,99466,40969,61516,168,34359738368,98851]

theorem envBound7336 : H12AffineFastState.Bounded env7336 := by
  intro p hp
  have h : env7336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7302_7336 : H12AffineEnvironment.transform 7 253 env7302 = env7336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7302 == env7336) = true)

theorem identity7336 : scanCanonicalize (H12AffineFastState.compose env7336 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 387203) := by decide +kernel

theorem selectedBound7336 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7337 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62641,32768,387203,41088,20481,98472,8328,118899,360618,276720,375871,2185,99466,40969,61516,168,34359738368,98851]

theorem envBound7337 : H12AffineFastState.Bounded env7337 := by
  intro p hp
  have h : env7337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7336_7337 : H12AffineEnvironment.transform 20 387203 env7336 = env7337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 387203 env7336 == env7337) = true)

theorem identity7337 : scanCanonicalize (H12AffineFastState.compose env7337 (packedSelected [0,2,4,6,7,9,13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound7337 : packedSelected [0,2,4,6,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env7338 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,170,37989,262144,62641,32768,321577,41088,20481,32770,8328,53465,294912,276720,310421,2185,33824,40969,61516,168,34359738368,33417]

theorem envBound7338 : H12AffineFastState.Bounded env7338 := by
  intro p hp
  have h : env7338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7337_7338 : H12AffineEnvironment.transform 15 170 env7337 = env7338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env7337 == env7338) = true)

theorem identity7338 : scanCanonicalize (H12AffineFastState.compose env7338 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7338 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7339 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,170,13509,262144,21521,8352,280713,32,20481,8354,8328,28793,270496,276720,269365,2185,9344,169,20716,168,34359738368,8745]

theorem envBound7339 : H12AffineFastState.Bounded env7339 := by
  intro p hp
  have h : env7339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7338_7339 : H12AffineEnvironment.transform 14 8352 env7338 = env7339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7338 == env7339) = true)

theorem identity7339 : scanCanonicalize (H12AffineFastState.compose env7339 (packedSelected [0,4,6,7,9,13] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound7339 : packedSelected [0,4,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env7340 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,170,13509,23588,21521,8352,5293,32,20481,8354,8328,28793,31876,25812,16401,2185,9344,169,20716,168,34359738368,8745]

theorem envBound7340 : H12AffineFastState.Bounded env7340 := by
  intro p hp
  have h : env7340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7339_7340 : H12AffineEnvironment.transform 17 23588 env7339 = env7340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env7339 == env7340) = true)

theorem identity7340 : scanCanonicalize (H12AffineFastState.compose env7340 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound7340 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7341 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,16384,137,170,5356,23588,21521,137,5293,32,20481,139,161,20560,23725,17661,16401,2185,1193,169,20716,168,34359738368,512]

theorem envBound7341 : H12AffineFastState.Bounded env7341 := by
  intro p hp
  have h : env7341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7340_7341 : H12AffineEnvironment.transform 12 41 env7340 = env7341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env7340 == env7341) = true)

theorem identity7341 : scanCanonicalize (H12AffineFastState.compose env7341 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4792) := by decide +kernel

theorem selectedBound7341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7342 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,4792,137,170,5356,3740,1705,137,5293,32,697,139,161,744,3605,5701,4777,2185,1193,169,596,168,34359738368,512]

theorem envBound7342 : H12AffineFastState.Bounded env7342 := by
  intro p hp
  have h : env7342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7341_7342 : H12AffineEnvironment.transform 13 4792 env7341 = env7342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4792 env7341 == env7342) = true)

theorem identity7342 : scanCanonicalize (H12AffineFastState.compose env7342 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7342 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7343 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4705,80,115,5173,3653,1648,80,5236,32,608,82,120,561,3605,5701,4720,2128,1136,112,596,113,34359738368,512]

theorem envBound7343 : H12AffineFastState.Bounded env7343 := by
  intro p hp
  have h : env7343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7342_7343 : H12AffineEnvironment.transform 6 89 env7342 = env7343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7342 == env7343) = true)

theorem identity7343 : scanCanonicalize (H12AffineFastState.compose env7343 (packedSelected [0,7,11] rootPS)) = affineNative (2^(34+1) ^^^ 4128) := by decide +kernel

theorem selectedBound7343 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env7344 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4705,80,115,5173,3653,1648,80,5236,32,608,82,120,561,3605,5701,4720,2128,1136,112,596,113,4128,512]

theorem envBound7344 : H12AffineFastState.Bounded env7344 := by
  intro p hp
  have h : env7344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7343_7344 : H12AffineEnvironment.transform 34 4128 env7343 = env7344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4128 env7343 == env7344) = true)

theorem identity7344 : scanCanonicalize (H12AffineFastState.compose env7344 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3685) := by decide +kernel

theorem selectedBound7344 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7345 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,3685,41,3076,80,115,2640,3653,1648,80,2577,32,608,82,120,561,3605,2080,3093,2128,1136,112,596,113,3653,512]

theorem envBound7345 : H12AffineFastState.Bounded env7345 := by
  intro p hp
  have h : env7345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7344_7345 : H12AffineEnvironment.transform 11 3685 env7344 = env7345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3685 env7344 == env7345) = true)

theorem identity7345 : scanCanonicalize (H12AffineFastState.compose env7345 (packedSelected [2,5,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound7345 : packedSelected [2,5,8,15] rootPS < 2^1333 := by decide +kernel

def env7346 : List Nat := [2,4,8,16,32,64,89,36,512,581,2048,2080,41,2625,80,115,2640,2048,53,80,2577,32,608,82,120,561,2128,2080,2640,2128,565,112,596,113,2048,512]

theorem envBound7346 : H12AffineFastState.Bounded env7346 := by
  intro p hp
  have h : env7346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7345_7346 : H12AffineEnvironment.transform 9 581 env7345 = env7346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env7345 == env7346) = true)

theorem identity7346 : scanCanonicalize (H12AffineFastState.compose env7346 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound7346 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env7347 : List Nat := [2,4,8,16,32,64,89,36,512,581,43,11,41,618,80,115,635,43,53,80,570,32,608,82,120,561,123,11,635,123,565,112,596,113,43,512]

theorem envBound7347 : H12AffineFastState.Bounded env7347 := by
  intro p hp
  have h : env7347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7346_7347 : H12AffineEnvironment.transform 10 43 env7346 = env7347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env7346 == env7347) = true)

theorem identity7347 : scanCanonicalize (H12AffineFastState.compose env7347 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7347 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7348 : List Nat := [2,4,8,16,32,64,89,36,11,78,43,11,41,97,80,115,112,43,53,80,49,32,107,82,120,58,123,11,112,123,62,112,95,113,43,11]

theorem envBound7348 : H12AffineFastState.Bounded env7348 := by
  intro p hp
  have h : env7348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7347_7348 : H12AffineEnvironment.transform 8 11 env7347 = env7348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7347 == env7348) = true)

theorem identity7348 : scanCanonicalize (H12AffineFastState.compose env7348 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7348 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env7349 : List Nat := [2,4,8,16,32,59,34,36,11,53,43,11,41,26,43,8,11,43,53,43,49,32,16,41,3,58,0,11,11,0,62,11,36,10,43,11]

theorem envBound7349 : H12AffineFastState.Bounded env7349 := by
  intro p hp
  have h : env7349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7348_7349 : H12AffineEnvironment.transform 5 59 env7348 = env7349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7348 == env7349) = true)

theorem identity7349 : scanCanonicalize (H12AffineFastState.compose env7349 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound7349 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env7350 : List Nat := [0,4,8,16,32,57,32,36,9,53,41,9,41,24,41,8,9,41,53,41,49,32,16,41,1,56,0,9,9,0,60,9,36,8,41,9]

theorem envBound7350 : H12AffineFastState.Bounded env7350 := by
  intro p hp
  have h : env7350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7349_7350 : H12AffineEnvironment.transform 0 0 env7349 = env7350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env7349 == env7350) = true)

theorem identity7350 : scanCanonicalize (H12AffineFastState.compose env7350 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound7350 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7351 : List Nat := [0,4,8,16,16,9,16,20,9,5,25,9,25,24,25,8,9,25,5,25,1,16,16,25,1,8,0,9,9,0,12,9,20,8,25,9]

theorem envBound7351 : H12AffineFastState.Bounded env7351 := by
  intro p hp
  have h : env7351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7350_7351 : H12AffineEnvironment.transform 4 16 env7350 = env7351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env7350 == env7351) = true)

theorem identity7351 : scanCanonicalize (H12AffineFastState.compose env7351 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound7351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7352 : List Nat := [0,4,8,9,9,9,9,13,9,5,0,9,0,1,0,8,9,0,5,0,1,9,9,0,1,8,0,9,9,0,12,9,13,8,0,9]

theorem envBound7352 : H12AffineFastState.Bounded env7352 := by
  intro p hp
  have h : env7352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7351_7352 : H12AffineEnvironment.transform 3 9 env7351 = env7352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env7351 == env7352) = true)

theorem identity7352 : scanCanonicalize (H12AffineFastState.compose env7352 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound7352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7353 : List Nat := [0,4,5,4,4,4,4,0,4,5,0,4,0,1,0,5,4,0,5,0,1,4,4,0,1,5,0,4,4,0,1,4,0,5,0,4]

theorem envBound7353 : H12AffineFastState.Bounded env7353 := by
  intro p hp
  have h : env7353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7352_7353 : H12AffineEnvironment.transform 2 5 env7352 = env7353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env7352 == env7353) = true)

def env7354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8988133,8328,599234,360618,11105475,11232451,8957381,99703,40969,525568,8955364,34359738368,98851]

theorem envBound7354 : H12AffineFastState.Bounded env7354 := by
  intro p hp
  have h : env7354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7102_7354 : H12AffineEnvironment.transform 21 41089 env7102 = env7354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env7102 == env7354) = true)

theorem identity7354 : scanCanonicalize (H12AffineFastState.compose env7354 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7354 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7355 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8987672,8328,599234,360618,11105475,11232451,8956984,99466,40969,525565,8954905,34359738368,98851]

theorem envBound7355 : H12AffineFastState.Bounded env7355 := by
  intro p hp
  have h : env7355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7354_7355 : H12AffineEnvironment.transform 7 253 env7354 = env7355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7354 == env7355) = true)

theorem identity7355 : scanCanonicalize (H12AffineFastState.compose env7355 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound7355 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7356 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32803,131072,262144,524288,32768,2097152,41089,8388608,8954939,8328,566497,262281,11072736,11199712,8956984,1193,40969,525565,8954905,34359738368,512]

theorem envBound7356 : H12AffineFastState.Bounded env7356 := by
  intro p hp
  have h : env7356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7355_7356 : H12AffineEnvironment.transform 15 32803 env7355 = env7356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env7355 == env7356) = true)

theorem identity7356 : scanCanonicalize (H12AffineFastState.compose env7356 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound7356 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7357 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32803,131072,262144,524288,32768,17597,41089,8388608,8954939,8328,566497,262281,8958045,9085021,8956984,1193,40969,525565,8954905,34359738368,512]

theorem envBound7357 : H12AffineFastState.Bounded env7357 := by
  intro p hp
  have h : env7357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7356_7357 : H12AffineEnvironment.transform 20 17597 env7356 = env7357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env7356 == env7357) = true)

def env7358 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,524288,32768,17597,32801,8388608,8946843,40,558145,262281,8950013,9076989,8948888,1193,32937,525565,8946873,34359738368,512]

theorem envBound7358 : H12AffineFastState.Bounded env7358 := by
  intro p hp
  have h : env7358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7357_7358 : H12AffineEnvironment.transform 12 160 env7357 = env7358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7357 == env7358) = true)

theorem identity7358 : scanCanonicalize (H12AffineFastState.compose env7358 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 433189) := by decide +kernel

theorem selectedBound7358 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7359 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,524288,32768,17597,32801,433189,923838,40,558145,262281,920792,793816,921789,1193,32937,525565,923804,34359738368,512]

theorem envBound7359 : H12AffineFastState.Bounded env7359 := by
  intro p hp
  have h : env7359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7358_7359 : H12AffineEnvironment.transform 22 433189 env7358 = env7359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 433189 env7358 == env7359) = true)

theorem identity7359 : scanCanonicalize (H12AffineFastState.compose env7359 (packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS)) = affineNative (2^(18+1) ^^^ 432180) := by decide +kernel

theorem selectedBound7359 : packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env7360 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,432180,32768,17597,32801,433189,32906,40,400501,262281,38124,165100,34953,1193,32937,433353,32936,34359738368,512]

theorem envBound7360 : H12AffineFastState.Bounded env7360 := by
  intro p hp
  have h : env7360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7359_7360 : H12AffineEnvironment.transform 18 432180 env7359 = env7360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432180 env7359 == env7360) = true)

theorem identity7360 : scanCanonicalize (H12AffineFastState.compose env7360 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 164073) := by decide +kernel

theorem selectedBound7360 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7361 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,432180,32768,17597,32801,433189,32906,40,400501,262281,38124,165100,34953,1193,32937,433353,32936,164073,512]

theorem envBound7361 : H12AffineFastState.Bounded env7361 := by
  intro p hp
  have h : env7361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7360_7361 : H12AffineEnvironment.transform 34 164073 env7360 = env7361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 164073 env7360 == env7361) = true)

theorem identity7361 : scanCanonicalize (H12AffineFastState.compose env7361 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 38125) := by decide +kernel

theorem selectedBound7361 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7362 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,38125,262144,265433,32768,17597,32801,264392,32906,40,297112,262281,38124,4097,34953,1193,32937,264228,32936,5124,512]

theorem envBound7362 : H12AffineFastState.Bounded env7362 := by
  intro p hp
  have h : env7362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7361_7362 : H12AffineEnvironment.transform 16 38125 env7361 = env7362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38125 env7361 == env7362) = true)

def env7363 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,524288,32768,17597,32800,8388608,8946842,41,558144,262281,8950012,9076988,8948889,1193,32936,525565,8946872,34359738368,512]

theorem envBound7363 : H12AffineFastState.Bounded env7363 := by
  intro p hp
  have h : env7363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7357_7363 : H12AffineEnvironment.transform 12 161 env7357 = env7363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7357 == env7363) = true)

theorem identity7363 : scanCanonicalize (H12AffineFastState.compose env7363 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 432181) := by decide +kernel

theorem selectedBound7363 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7364 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432181,32768,17597,32800,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32936,433352,8789133,34359738368,512]

theorem envBound7364 : H12AffineFastState.Bounded env7364 := by
  intro p hp
  have h : env7364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7363_7364 : H12AffineEnvironment.transform 18 432181 env7363 = env7364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432181 env7363 == env7364) = true)

def env7365 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432181,32768,17597,32800,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32936,433352,8789133,8702152,512]

theorem envBound7365 : H12AffineFastState.Bounded env7365 := by
  intro p hp
  have h : env7365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7364_7365 : H12AffineEnvironment.transform 34 8702152 env7364 = env7365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702152 env7364 == env7365) = true)

theorem identity7365 : scanCanonicalize (H12AffineFastState.compose env7365 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound7365 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7366 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5356,262144,298201,32768,17597,32800,8388608,8652867,41,264345,262281,8657957,8657097,8650816,1193,32936,296996,8652897,8702152,512]

theorem envBound7366 : H12AffineFastState.Bounded env7366 := by
  intro p hp
  have h : env7366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7365_7366 : H12AffineEnvironment.transform 16 5356 env7365 = env7366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env7365 == env7366) = true)

theorem identity7366 : scanCanonicalize (H12AffineFastState.compose env7366 (packedSelected [4,9,11] rootPS)) = affineNative (2^(22+1) ^^^ 297161) := by decide +kernel

theorem selectedBound7366 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env7367 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5356,262144,298201,32768,17597,32800,297161,32906,41,264345,262281,38124,36864,34953,1193,32936,296996,32936,16385,512]

theorem envBound7367 : H12AffineFastState.Bounded env7367 := by
  intro p hp
  have h : env7367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7366_7367 : H12AffineEnvironment.transform 22 297161 env7366 = env7367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297161 env7366 == env7367) = true)

theorem identity7367 : scanCanonicalize (H12AffineFastState.compose env7367 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7367 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7368 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,32768,32803,5188,262144,298097,32768,17429,32800,297057,32802,41,264241,262177,37956,36864,34849,1025,32768,296996,32768,16385,512]

theorem envBound7368 : H12AffineFastState.Bounded env7368 := by
  intro p hp
  have h : env7368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7367_7368 : H12AffineEnvironment.transform 6 40 env7367 = env7368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7367 == env7368) = true)

theorem identity7368 : scanCanonicalize (H12AffineFastState.compose env7368 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7368 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7369 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,32768,32803,5188,2081,33872,32768,17429,32800,32832,32802,41,16,2048,37956,36864,34849,1025,32768,32773,32768,16385,512]

theorem envBound7369 : H12AffineFastState.Bounded env7369 := by
  intro p hp
  have h : env7369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7368_7369 : H12AffineEnvironment.transform 17 2081 env7368 = env7369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env7368 == env7369) = true)

def env7370 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432181,32768,17597,32800,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32936,433352,8789133,8702153,512]

theorem envBound7370 : H12AffineFastState.Bounded env7370 := by
  intro p hp
  have h : env7370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7364_7370 : H12AffineEnvironment.transform 34 8702153 env7364 = env7370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702153 env7364 == env7370) = true)

theorem identity7370 : scanCanonicalize (H12AffineFastState.compose env7370 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound7370 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7371 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,2185,168124,32768,17597,32800,8388608,8524838,41,136444,2048,8519744,8392768,8526885,1193,32936,169025,8524804,8437824,512]

theorem envBound7371 : H12AffineFastState.Bounded env7371 := by
  intro p hp
  have h : env7371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7370_7371 : H12AffineEnvironment.transform 17 2185 env7370 = env7371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env7370 == env7371) = true)

theorem identity7371 : scanCanonicalize (H12AffineFastState.compose env7371 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 64) := by decide +kernel

theorem selectedBound7371 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env7372 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,2185,168124,32768,17597,32800,64,136294,41,136444,2048,131072,4096,138341,1193,32936,169025,136260,49152,512]

theorem envBound7372 : H12AffineFastState.Bounded env7372 := by
  intro p hp
  have h : env7372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7371_7372 : H12AffineEnvironment.transform 22 64 env7371 = env7372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env7371 == env7372) = true)

theorem identity7372 : scanCanonicalize (H12AffineFastState.compose env7372 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound7372 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7373 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5356,2185,33872,32768,17597,32800,64,138,41,16,2048,5356,4096,2185,1193,32936,32941,168,49152,512]

theorem envBound7373 : H12AffineFastState.Bounded env7373 := by
  intro p hp
  have h : env7373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7372_7373 : H12AffineEnvironment.transform 16 5356 env7372 = env7373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env7372 == env7373) = true)

theorem identity7373 : scanCanonicalize (H12AffineFastState.compose env7373 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound7373 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7374 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,0,35,5356,2185,1104,0,17597,32,64,138,41,16,2048,5356,4096,2185,1193,168,173,168,16384,512]

theorem envBound7374 : H12AffineFastState.Bounded env7374 := by
  intro p hp
  have h : env7374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7373_7374 : H12AffineEnvironment.transform 14 0 env7373 = env7374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env7373 == env7374) = true)

theorem identity7374 : scanCanonicalize (H12AffineFastState.compose env7374 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound7374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7375 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,88,16384,0,35,5141,2160,1104,0,17476,32,64,115,41,16,2048,5141,4096,2160,1104,81,84,81,16384,512]

theorem envBound7375 : H12AffineFastState.Bounded env7375 := by
  intro p hp
  have h : env7375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7374_7375 : H12AffineEnvironment.transform 6 121 env7374 = env7375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env7374 == env7375) = true)

theorem identity7375 : scanCanonicalize (H12AffineFastState.compose env7375 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7376 : List Nat := [2,4,8,16,32,59,2,4,512,1024,2048,4096,35,16384,0,35,5141,2059,1067,0,17471,32,59,8,41,16,2048,5141,4096,2059,1067,42,47,42,16384,512]

theorem envBound7376 : H12AffineFastState.Bounded env7376 := by
  intro p hp
  have h : env7376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7375_7376 : H12AffineEnvironment.transform 5 59 env7375 = env7376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7375 == env7376) = true)

theorem identity7376 : scanCanonicalize (H12AffineFastState.compose env7376 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound7376 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7377 : List Nat := [2,4,8,16,32,59,2,4,512,47,2048,4096,35,16384,0,35,4154,2059,4,0,16400,32,59,8,41,16,2048,4154,4096,2059,4,42,47,42,16384,512]

theorem envBound7377 : H12AffineFastState.Bounded env7377 := by
  intro p hp
  have h : env7377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7376_7377 : H12AffineEnvironment.transform 9 47 env7376 = env7377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env7376 == env7377) = true)

theorem identity7377 : scanCanonicalize (H12AffineFastState.compose env7377 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7377 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7378 : List Nat := [2,4,8,16,1,26,2,4,512,14,2048,4096,2,16384,0,2,4123,2059,4,0,16400,1,26,8,8,16,2048,4123,4096,2059,4,11,14,11,16384,512]

theorem envBound7378 : H12AffineFastState.Bounded env7378 := by
  intro p hp
  have h : env7378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7377_7378 : H12AffineEnvironment.transform 4 1 env7377 = env7378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7377 == env7378) = true)

theorem identity7378 : scanCanonicalize (H12AffineFastState.compose env7378 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7378 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env7379 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,4096,2,16384,0,2,4113,2049,4,0,16400,1,16,2,2,16,2048,4113,4096,2049,4,1,4,1,16384,512]

theorem envBound7379 : H12AffineFastState.Bounded env7379 := by
  intro p hp
  have h : env7379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7378_7379 : H12AffineEnvironment.transform 2 2 env7378 = env7379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7378 == env7379) = true)

def env7380 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,16384,0,2,17,2049,4,0,16400,1,16,2,2,16,2048,17,0,2049,4,1,4,1,16384,512]

theorem envBound7380 : H12AffineFastState.Bounded env7380 := by
  intro p hp
  have h : env7380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7379_7380 : H12AffineEnvironment.transform 11 0 env7379 = env7380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env7379 == env7380) = true)

theorem identity7380 : scanCanonicalize (H12AffineFastState.compose env7380 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound7380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7381 : List Nat := [2,4,2,16,1,16,2,4,19,4,2048,0,2,16384,0,2,17,2049,4,0,16400,1,16,2,2,16,2048,17,0,2049,4,1,4,1,16384,19]

theorem envBound7381 : H12AffineFastState.Bounded env7381 := by
  intro p hp
  have h : env7381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7380_7381 : H12AffineEnvironment.transform 8 19 env7380 = env7381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env7380 == env7381) = true)

def env7382 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,0,2,16384,0,2,1,2049,4,0,16384,1,0,2,2,0,2048,1,0,2049,4,1,4,1,16384,3]

theorem envBound7382 : H12AffineFastState.Bounded env7382 := by
  intro p hp
  have h : env7382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7381_7382 : H12AffineEnvironment.transform 3 0 env7381 = env7382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env7381 == env7382) = true)

theorem identity7382 : scanCanonicalize (H12AffineFastState.compose env7382 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2052) := by decide +kernel

theorem selectedBound7382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7383 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,0,2,2052,0,2,1,2049,4,0,2052,1,0,2,2,0,2048,1,0,2049,4,1,4,1,2052,3]

theorem envBound7383 : H12AffineFastState.Bounded env7383 := by
  intro p hp
  have h : env7383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7382_7383 : H12AffineEnvironment.transform 13 2052 env7382 = env7383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2052 env7382 == env7383) = true)

def leafEnv7383 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,0,2,2052,0,2,1,2049,4,0,2052,1,0,2,4,2,1,0,2048,1,0,2049,4,1,4,1,4,2,2052,3,1,2052,0]

def active7383 : List Nat := [0,1,10]

def tree7383 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7383 : H12WitnessSearch.Good tree7383 := H12GlobalWitnessIndex.good

theorem leafIdentity7383 : H12AffineFastState.composeSystem env7383 rootObs = leafEnv7383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7383 rootObs == leafEnv7383) = true)

theorem terminalChecked7383 : H12PackedTerminal.terminalCheckFast leafEnv7383 active7383 tree7383 = true := by decide +kernel

def env7384 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,0,2,16384,0,2,0,2049,4,0,16385,1,1,2,2,1,2048,0,0,2049,4,1,4,1,16384,2]

theorem envBound7384 : H12AffineFastState.Bounded env7384 := by
  intro p hp
  have h : env7384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7381_7384 : H12AffineEnvironment.transform 3 1 env7381 = env7384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env7381 == env7384) = true)

theorem identity7384 : scanCanonicalize (H12AffineFastState.compose env7384 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2054) := by decide +kernel

theorem selectedBound7384 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7385 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,0,2,2054,0,2,0,2049,4,0,2055,1,1,2,2,1,2048,0,0,2049,4,1,4,1,2054,2]

theorem envBound7385 : H12AffineFastState.Bounded env7385 := by
  intro p hp
  have h : env7385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7384_7385 : H12AffineEnvironment.transform 13 2054 env7384 = env7385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2054 env7384 == env7385) = true)

def leafEnv7385 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,0,2,2054,0,2,0,2049,4,0,2055,1,1,2,4,2,1,1,2048,0,0,2049,4,1,4,1,4,2,2054,2,1,2055,0]

def active7385 : List Nat := [0,1,10]

def tree7385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7385 : H12WitnessSearch.Good tree7385 := H12GlobalWitnessIndex.good

theorem leafIdentity7385 : H12AffineFastState.composeSystem env7385 rootObs = leafEnv7385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7385 rootObs == leafEnv7385) = true)

theorem terminalChecked7385 : H12PackedTerminal.terminalCheckFast leafEnv7385 active7385 tree7385 = true := by decide +kernel

def env7386 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,16384,0,2,16,2049,4,0,16400,1,16,2,2,16,2048,16,1,2049,4,1,4,1,16384,512]

theorem envBound7386 : H12AffineFastState.Bounded env7386 := by
  intro p hp
  have h : env7386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7379_7386 : H12AffineEnvironment.transform 11 1 env7379 = env7386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env7379 == env7386) = true)

theorem identity7386 : scanCanonicalize (H12AffineFastState.compose env7386 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound7386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7387 : List Nat := [2,4,2,16,1,16,2,4,3,4,2048,1,2,16384,0,2,16,2049,4,0,16400,1,16,2,2,16,2048,16,1,2049,4,1,4,1,16384,3]

theorem envBound7387 : H12AffineFastState.Bounded env7387 := by
  intro p hp
  have h : env7387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7386_7387 : H12AffineEnvironment.transform 8 3 env7386 = env7387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env7386 == env7387) = true)

def env7388 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,1,2,16384,0,2,0,2049,4,0,16384,1,0,2,2,0,2048,0,1,2049,4,1,4,1,16384,3]

theorem envBound7388 : H12AffineFastState.Bounded env7388 := by
  intro p hp
  have h : env7388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7387_7388 : H12AffineEnvironment.transform 3 0 env7387 = env7388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env7387 == env7388) = true)

theorem identity7388 : scanCanonicalize (H12AffineFastState.compose env7388 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2053) := by decide +kernel

theorem selectedBound7388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7389 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,1,2,2053,0,2,0,2049,4,0,2053,1,0,2,2,0,2048,0,1,2049,4,1,4,1,2053,3]

theorem envBound7389 : H12AffineFastState.Bounded env7389 := by
  intro p hp
  have h : env7389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7388_7389 : H12AffineEnvironment.transform 13 2053 env7388 = env7389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2053 env7388 == env7389) = true)

def leafEnv7389 : List Nat := [2,4,2,0,1,0,2,4,3,4,2048,1,2,2053,0,2,0,2049,4,0,2053,1,0,2,4,2,1,0,2048,0,1,2049,4,1,4,1,4,2,2053,3,1,2053,0]

def active7389 : List Nat := [0,1,10]

def tree7389 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7389 : H12WitnessSearch.Good tree7389 := H12GlobalWitnessIndex.good

theorem leafIdentity7389 : H12AffineFastState.composeSystem env7389 rootObs = leafEnv7389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7389 rootObs == leafEnv7389) = true)

theorem terminalChecked7389 : H12PackedTerminal.terminalCheckFast leafEnv7389 active7389 tree7389 = true := by decide +kernel

def env7390 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,1,2,16384,0,2,1,2049,4,0,16385,1,1,2,2,1,2048,1,1,2049,4,1,4,1,16384,3]

theorem envBound7390 : H12AffineFastState.Bounded env7390 := by
  intro p hp
  have h : env7390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7387_7390 : H12AffineEnvironment.transform 3 1 env7387 = env7390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env7387 == env7390) = true)

theorem identity7390 : scanCanonicalize (H12AffineFastState.compose env7390 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2054) := by decide +kernel

theorem selectedBound7390 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7391 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,1,2,2054,0,2,1,2049,4,0,2055,1,1,2,2,1,2048,1,1,2049,4,1,4,1,2054,3]

theorem envBound7391 : H12AffineFastState.Bounded env7391 := by
  intro p hp
  have h : env7391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7390_7391 : H12AffineEnvironment.transform 13 2054 env7390 = env7391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2054 env7390 == env7391) = true)

def leafEnv7391 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,1,2,2054,0,2,1,2049,4,0,2055,1,1,2,4,2,1,1,2048,1,1,2049,4,1,4,1,4,2,2054,3,1,2055,0]

def active7391 : List Nat := [0,1,10]

def tree7391 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7391 : H12WitnessSearch.Good tree7391 := H12GlobalWitnessIndex.good

theorem leafIdentity7391 : H12AffineFastState.composeSystem env7391 rootObs = leafEnv7391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7391 rootObs == leafEnv7391) = true)

theorem terminalChecked7391 : H12PackedTerminal.terminalCheckFast leafEnv7391 active7391 tree7391 = true := by decide +kernel

def env7392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374096,1086893389,525568,1073743905,34359738368,25733062]

theorem envBound7392 : H12AffineFastState.Bounded env7392 := by
  intro p hp
  have h : env7392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6669_7392 : H12AffineEnvironment.transform 28 268570625 env6669 = env7392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env6669 == env7392) = true)

theorem identity7392 : scanCanonicalize (H12AffineFastState.compose env7392 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 17080671) := by decide +kernel

theorem selectedBound7392 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env7393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,17080671,268435456,268570625,1073741824,92374096,1086893389,525568,1073743905,34359738368,25733062]

theorem envBound7393 : H12AffineFastState.Bounded env7393 := by
  intro p hp
  have h : env7393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7392_7393 : H12AffineEnvironment.transform 26 17080671 env7392 = env7393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17080671 env7392 == env7393) = true)

def env7394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,17080671,268435456,268570625,2080,92374096,13149549,525568,1,34359738368,25733062]

theorem envBound7394 : H12AffineFastState.Bounded env7394 := by
  intro p hp
  have h : env7394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7393_7394 : H12AffineEnvironment.transform 29 2080 env7393 = env7394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2080 env7393 == env7394) = true)

def env7395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,67108864,17039531,268435456,268570625,2080,92349860,13108377,525568,1,34359738368,25691698]

theorem envBound7395 : H12AffineFastState.Bounded env7395 := by
  intro p hp
  have h : env7395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7394_7395 : H12AffineEnvironment.transform 14 8692 env7394 = env7395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env7394 == env7395) = true)

def env7396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,13182096,8328,67108864,13444155,268435456,268570625,2080,71827764,13108377,525568,1,34359738368,4268706]

theorem envBound7396 : H12AffineFastState.Bounded env7396 := by
  intro p hp
  have h : env7396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7395_7396 : H12AffineEnvironment.transform 23 13182096 env7395 = env7396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13182096 env7395 == env7396) = true)

theorem identity7396 : scanCanonicalize (H12AffineFastState.compose env7396 (packedSelected [3,5,8,10,12,15,17,21,28,31,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7396 : packedSelected [3,5,8,10,12,15,17,21,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env7397 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,8388608,13182096,8328,67108864,13444155,268435456,268570625,2080,71827657,13108377,525565,1,34359738368,4268706]

theorem envBound7397 : H12AffineFastState.Bounded env7397 := by
  intro p hp
  have h : env7397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7396_7397 : H12AffineEnvironment.transform 7 253 env7396 = env7397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7396 == env7397) = true)

def env7398 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,8388608,13182096,8328,8388688,13444155,268435456,268570625,2080,13107353,13108377,525565,1,34359738368,4268706]

theorem envBound7398 : H12AffineFastState.Bounded env7398 := by
  intro p hp
  have h : env7398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7397_7398 : H12AffineEnvironment.transform 25 8388688 env7397 = env7398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8388688 env7397 == env7398) = true)

theorem identity7398 : scanCanonicalize (H12AffineFastState.compose env7398 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(34+1) ^^^ 269182075) := by decide +kernel

theorem selectedBound7398 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env7399 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,8388608,13182096,8328,8388688,13444155,268435456,268570625,2080,13107353,13108377,525565,1,269182075,4268706]

theorem envBound7399 : H12AffineFastState.Bounded env7399 := by
  intro p hp
  have h : env7399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7398_7399 : H12AffineEnvironment.transform 34 269182075 env7398 = env7399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 269182075 env7398 == env7399) = true)

theorem identity7399 : scanCanonicalize (H12AffineFastState.compose env7399 (packedSelected [0,1,3,5,7,8,9,10,13,14,19,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound7399 : packedSelected [0,1,3,5,7,8,9,10,13,14,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env7400 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73890,8388608,8913970,8328,8388688,9176217,268435456,268570625,2080,8986683,8987707,525565,1,269182075,512]

theorem envBound7400 : H12AffineFastState.Bounded env7400 := by
  intro p hp
  have h : env7400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7399_7400 : H12AffineEnvironment.transform 21 73890 env7399 = env7400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env7399 == env7400) = true)

theorem identity7400 : scanCanonicalize (H12AffineFastState.compose env7400 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound7400 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7401 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8322,131072,262144,524288,8201,2097152,32,8388608,8913970,8328,8388688,9176217,268435456,268570625,2080,8913081,8914105,525565,1,269108473,512]

theorem envBound7401 : H12AffineFastState.Bounded env7401 := by
  intro p hp
  have h : env7401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7400_7401 : H12AffineEnvironment.transform 15 8322 env7400 = env7401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env7400 == env7401) = true)

theorem identity7401 : scanCanonicalize (H12AffineFastState.compose env7401 (packedSelected [13,17] rootPS)) = affineNative (2^(22+1) ^^^ 525496) := by decide +kernel

theorem selectedBound7401 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7402 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8322,131072,262144,524288,8201,2097152,32,525496,138,8328,525544,262177,268435456,268570625,2080,1025,1,525565,1,269108473,512]

theorem envBound7402 : H12AffineFastState.Bounded env7402 := by
  intro p hp
  have h : env7402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7401_7402 : H12AffineEnvironment.transform 22 525496 env7401 = env7402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525496 env7401 == env7402) = true)

def env7403 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,8388608,13182096,8328,8388689,13444155,268435456,268570625,2080,13107352,13108377,525565,1,34359738368,4268706]

theorem envBound7403 : H12AffineFastState.Bounded env7403 := by
  intro p hp
  have h : env7403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7397_7403 : H12AffineEnvironment.transform 25 8388689 env7397 = env7403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8388689 env7397 == env7403) = true)

theorem identity7403 : scanCanonicalize (H12AffineFastState.compose env7403 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(27+1) ^^^ 4924507) := by decide +kernel

theorem selectedBound7403 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env7404 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,8388608,13182096,8328,8388689,13444155,4924507,4797530,2080,13107352,13108377,525565,1,34359738368,4268706]

theorem envBound7404 : H12AffineFastState.Bounded env7404 := by
  intro p hp
  have h : env7404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7403_7404 : H12AffineEnvironment.transform 27 4924507 env7403 = env7404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 4924507 env7403 == env7404) = true)

def env7405 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941088,4194304,8388608,13182096,8328,8388689,13444155,4924507,4797530,2080,13107352,13108377,525565,1,34359738368,4268706]

theorem envBound7405 : H12AffineFastState.Bounded env7405 := by
  intro p hp
  have h : env7405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7404_7405 : H12AffineEnvironment.transform 20 941088 env7404 = env7405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 941088 env7404 == env7405) = true)

theorem identity7405 : scanCanonicalize (H12AffineFastState.compose env7405 (packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS)) = affineNative (2^(34+1) ^^^ 13198363) := by decide +kernel

theorem selectedBound7405 : packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env7406 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941088,4194304,8388608,13182096,8328,8388689,13444155,4924507,4797530,2080,13107352,13108377,525565,1,13198363,4268706]

theorem envBound7406 : H12AffineFastState.Bounded env7406 := by
  intro p hp
  have h : env7406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7405_7406 : H12AffineEnvironment.transform 34 13198363 env7405 = env7406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 13198363 env7405 == env7406) = true)

theorem identity7406 : scanCanonicalize (H12AffineFastState.compose env7406 (packedSelected [1,3,5,8,10,13,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound7406 : packedSelected [1,3,5,8,10,13,19,21] rootPS < 2^1333 := by decide +kernel

def env7407 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,131072,262144,524288,8201,941088,4194304,8388608,13108243,8328,8388689,13370552,4850904,4723929,2080,13107352,13108377,525565,1,13124760,4194849]

theorem envBound7407 : H12AffineFastState.Bounded env7407 := by
  intro p hp
  have h : env7407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7406_7407 : H12AffineEnvironment.transform 15 8323 env7406 = env7407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env7406 == env7407) = true)

theorem identity7407 : scanCanonicalize (H12AffineFastState.compose env7407 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 4719768) := by decide +kernel

theorem selectedBound7407 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env7408 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,131072,262144,524288,8201,941088,4194304,4719768,139,8328,4719817,262176,4850904,4723929,2080,1024,1,525565,1,16384,4194849]

theorem envBound7408 : H12AffineFastState.Bounded env7408 := by
  intro p hp
  have h : env7408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7407_7408 : H12AffineEnvironment.transform 22 4719768 env7407 = env7408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4719768 env7407 == env7408) = true)

theorem identity7408 : scanCanonicalize (H12AffineFastState.compose env7408 (packedSelected [0,4,6,7,9,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound7408 : packedSelected [0,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env7409 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,131072,262144,524288,8201,941088,33,525497,139,8328,525544,262176,656633,529656,2080,1024,1,525565,1,16384,512]

theorem envBound7409 : H12AffineFastState.Bounded env7409 := by
  intro p hp
  have h : env7409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7408_7409 : H12AffineEnvironment.transform 21 33 env7408 = env7409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7408 == env7409) = true)

theorem identity7409 : scanCanonicalize (H12AffineFastState.compose env7409 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 16031) := by decide +kernel

theorem selectedBound7409 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env7410 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,16031,262144,524288,8201,811711,33,525497,139,8328,525544,262176,539238,529656,2080,1024,1,525565,1,16384,512]

theorem envBound7410 : H12AffineFastState.Bounded env7410 := by
  intro p hp
  have h : env7410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7409_7410 : H12AffineEnvironment.transform 16 16031 env7409 = env7410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16031 env7409 == env7410) = true)

theorem identity7410 : scanCanonicalize (H12AffineFastState.compose env7410 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(18+1) ^^^ 10774) := by decide +kernel

theorem selectedBound7410 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env7411 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,16031,262144,10774,8201,280745,33,11951,139,8328,12030,262176,4208,16110,2080,1024,1,12011,1,16384,512]

theorem envBound7411 : H12AffineFastState.Bounded env7411 := by
  intro p hp
  have h : env7411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7410_7411 : H12AffineEnvironment.transform 18 10774 env7410 = env7411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 10774 env7410 == env7411) = true)

theorem identity7411 : scanCanonicalize (H12AffineFastState.compose env7411 (packedSelected [2,14] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7411 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env7412 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,16031,2080,10774,8201,16521,33,11951,139,8328,12030,2048,4208,16110,2080,1024,1,12011,1,16384,512]

theorem envBound7412 : H12AffineFastState.Bounded env7412 := by
  intro p hp
  have h : env7412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7411_7412 : H12AffineEnvironment.transform 17 2080 env7411 = env7412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7411 == env7412) = true)

theorem identity7412 : scanCanonicalize (H12AffineFastState.compose env7412 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound7412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7413 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5237,8201,8323,16031,2080,10774,8201,5372,33,11951,139,8328,12030,2048,4208,16110,2080,1024,1,12011,1,5237,512]

theorem envBound7413 : H12AffineFastState.Bounded env7413 := by
  intro p hp
  have h : env7413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7412_7413 : H12AffineEnvironment.transform 13 5237 env7412 = env7413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env7412 == env7413) = true)

theorem identity7413 : scanCanonicalize (H12AffineFastState.compose env7413 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound7413 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7414 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,6201,5237,6192,6330,1702,2080,4655,6192,5372,33,5782,139,6321,5831,2048,4208,1751,2080,1024,1,5842,1,5237,512]

theorem envBound7414 : H12AffineFastState.Bounded env7414 := by
  intro p hp
  have h : env7414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7413_7414 : H12AffineEnvironment.transform 12 6201 env7413 = env7414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env7413 == env7414) = true)

def env7415 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,6201,5237,6192,6162,1550,2080,4655,6192,5204,33,5694,35,6169,5743,2048,4208,1663,2080,1024,1,5754,1,5237,512]

theorem envBound7415 : H12AffineFastState.Bounded env7415 := by
  intro p hp
  have h : env7415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7414_7415 : H12AffineEnvironment.transform 6 40 env7414 = env7415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7414 == env7415) = true)

theorem identity7415 : scanCanonicalize (H12AffineFastState.compose env7415 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound7415 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7416 : List Nat := [2,4,8,16,32,64,40,85,512,1024,522,4096,4659,5237,4666,4632,1550,554,4655,4666,5204,33,5694,35,4627,5743,522,4208,1663,554,1024,1,5754,1,5237,512]

theorem envBound7416 : H12AffineFastState.Bounded env7416 := by
  intro p hp
  have h : env7416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7415_7416 : H12AffineEnvironment.transform 10 522 env7415 = env7416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env7415 == env7416) = true)

def env7417 : List Nat := [2,4,8,16,32,48,40,37,512,1024,522,4096,4659,5125,4666,4632,1550,554,4655,4666,5156,33,5694,35,4627,5663,522,4096,1551,554,1024,1,5642,1,5125,512]

theorem envBound7417 : H12AffineFastState.Bounded env7417 := by
  intro p hp
  have h : env7417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7416_7417 : H12AffineEnvironment.transform 5 48 env7416 = env7417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7416 == env7417) = true)

theorem identity7417 : scanCanonicalize (H12AffineFastState.compose env7417 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1592) := by decide +kernel

theorem selectedBound7417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7418 : List Nat := [2,4,8,16,32,48,40,37,512,1024,522,1592,1035,573,1026,1056,1550,554,1047,1026,540,33,6,35,1067,39,522,1592,1551,554,1024,1,50,1,573,512]

theorem envBound7418 : H12AffineFastState.Bounded env7418 := by
  intro p hp
  have h : env7418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7417_7418 : H12AffineEnvironment.transform 11 1592 env7417 = env7418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1592 env7417 == env7418) = true)

def leafEnv7418 : List Nat := [2,4,8,16,32,48,40,37,512,1024,522,1592,1035,573,1026,1056,1550,554,1047,1026,540,33,6,35,1046,1067,1,39,522,1592,1551,554,1024,1,50,1,18,1025,573,512,1,540,0]

def active7418 : List Nat := [0,1,2,3,4,8,9]

def tree7418 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7418 : H12WitnessSearch.Good tree7418 := H12GlobalWitnessIndex.good

theorem leafIdentity7418 : H12AffineFastState.composeSystem env7418 rootObs = leafEnv7418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7418 rootObs == leafEnv7418) = true)

theorem terminalChecked7418 : H12PackedTerminal.terminalCheckFast leafEnv7418 active7418 tree7418 = true := by decide +kernel

def env7419 : List Nat := [2,4,8,16,32,49,40,36,512,1024,522,4096,4659,5124,4666,4632,1550,554,4655,4666,5157,33,5694,35,4627,5662,522,4097,1550,554,1024,1,5643,1,5124,512]

theorem envBound7419 : H12AffineFastState.Bounded env7419 := by
  intro p hp
  have h : env7419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7416_7419 : H12AffineEnvironment.transform 5 49 env7416 = env7419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7416 == env7419) = true)

theorem identity7419 : scanCanonicalize (H12AffineFastState.compose env7419 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound7419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7420 : List Nat := [2,4,8,16,32,49,40,36,512,3,522,4096,4659,4103,4666,4632,525,554,4655,4666,4134,33,4669,35,4627,4637,522,4097,525,554,3,1,4616,1,4103,512]

theorem envBound7420 : H12AffineFastState.Bounded env7420 := by
  intro p hp
  have h : env7420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7419_7420 : H12AffineEnvironment.transform 9 3 env7419 = env7420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env7419 == env7420) = true)

def leafEnv7420 : List Nat := [2,4,8,16,32,49,40,36,512,3,522,4096,4659,4103,4666,4632,525,554,4655,4666,4134,33,4669,35,4654,4627,1,4637,522,4097,525,554,3,1,4616,1,4649,4665,4103,512,1,4134,0]

def active7420 : List Nat := [0,1,2,3,4,8,11]

def tree7420 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7420 : H12WitnessSearch.Good tree7420 := H12GlobalWitnessIndex.good

theorem leafIdentity7420 : H12AffineFastState.composeSystem env7420 rootObs = leafEnv7420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7420 rootObs == leafEnv7420) = true)

theorem terminalChecked7420 : H12PackedTerminal.terminalCheckFast leafEnv7420 active7420 tree7420 = true := by decide +kernel

def env7421 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,6201,5237,6192,6163,1551,2080,4655,6192,5205,33,5695,34,6168,5742,2048,4208,1662,2080,1024,1,5755,1,5237,512]

theorem envBound7421 : H12AffineFastState.Bounded env7421 := by
  intro p hp
  have h : env7421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7414_7421 : H12AffineEnvironment.transform 6 41 env7414 = env7421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7414 == env7421) = true)

theorem identity7421 : scanCanonicalize (H12AffineFastState.compose env7421 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound7421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7422 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,3189,1100,2048,1093,1126,1551,2080,3674,1093,2080,33,2634,34,1133,2587,2048,3077,1662,2080,1024,1,2574,1,2048,512]

theorem envBound7422 : H12AffineFastState.Bounded env7422 := by
  intro p hp
  have h : env7422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7421_7422 : H12AffineEnvironment.transform 11 3189 env7421 = env7422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env7421 == env7422) = true)

def env7423 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941089,4194304,8388608,13182096,8328,8388689,13444155,4924507,4797530,2080,13107352,13108377,525565,1,34359738368,4268706]

theorem envBound7423 : H12AffineFastState.Bounded env7423 := by
  intro p hp
  have h : env7423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7404_7423 : H12AffineEnvironment.transform 20 941089 env7404 = env7423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 941089 env7404 == env7423) = true)

theorem identity7423 : scanCanonicalize (H12AffineFastState.compose env7423 (packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS)) = affineNative (2^(34+1) ^^^ 13124760) := by decide +kernel

theorem selectedBound7423 : packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env7424 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941089,4194304,8388608,13182096,8328,8388689,13444155,4924507,4797530,2080,13107352,13108377,525565,1,13124760,4268706]

theorem envBound7424 : H12AffineFastState.Bounded env7424 := by
  intro p hp
  have h : env7424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7423_7424 : H12AffineEnvironment.transform 34 13124760 env7423 = env7424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 13124760 env7423 == env7424) = true)

theorem identity7424 : scanCanonicalize (H12AffineFastState.compose env7424 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,14,15,23] rootPS)) = affineNative (2^(22+1) ^^^ 525497) := by decide +kernel

theorem selectedBound7424 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env7425 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941089,4194304,525497,4268073,8328,525544,4530306,4924507,4797530,2080,4195361,4194336,525565,1,4210721,4268706]

theorem envBound7425 : H12AffineFastState.Bounded env7425 := by
  intro p hp
  have h : env7425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7424_7425 : H12AffineEnvironment.transform 22 525497 env7424 = env7425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525497 env7424 == env7425) = true)

theorem identity7425 : scanCanonicalize (H12AffineFastState.compose env7425 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound7425 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env7426 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,941089,33,525497,73736,8328,525544,336035,730234,603259,2080,1024,1,525565,1,16384,74371]

theorem envBound7426 : H12AffineFastState.Bounded env7426 := by
  intro p hp
  have h : env7426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7425_7426 : H12AffineEnvironment.transform 21 33 env7425 = env7426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7425 == env7426) = true)

theorem identity7426 : scanCanonicalize (H12AffineFastState.compose env7426 (packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound7426 : packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env7427 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,131072,262144,524288,8201,941089,33,525497,139,8328,525544,262176,656633,529656,2080,1024,1,525565,1,16384,512]

end H12CloudChart0