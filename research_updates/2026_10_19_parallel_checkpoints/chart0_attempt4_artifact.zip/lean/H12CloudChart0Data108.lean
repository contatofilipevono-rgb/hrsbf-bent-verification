import H12CloudChart0Data107

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env27364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147457,188870,8328,65,4302890,2319690,2233681,149996,75223,6521862,257,2188650,2196686,513]

theorem envBound27364 : H12AffineFastState.Bounded env27364 := by
  intro p hp
  have h : env27364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27363_27364 : H12AffineEnvironment.transform 23 188870 env27363 = env27364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env27363 == env27364) = true)

def env27365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35188,1025,32769,2097152,4194304,153,41310,8328,65,4302890,2172370,2119113,2420,75223,6407326,257,2188650,2196686,513]

theorem envBound27365 : H12AffineFastState.Bounded env27365 := by
  intro p hp
  have h : env27365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27364_27365 : H12AffineEnvironment.transform 16 16536 env27364 = env27365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env27364 == env27365) = true)

theorem identity27365 : scanCanonicalize (H12AffineFastState.compose env27365 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27365 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302890,2172250,2118977,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound27366 : H12AffineFastState.Bounded env27366 := by
  intro p hp
  have h : env27366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27365_27366 : H12AffineEnvironment.transform 6 8 env27365 = env27366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27365 == env27366) = true)

theorem identity27366 : scanCanonicalize (H12AffineFastState.compose env27366 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound27366 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115734,4194304,17,41310,8192,65,4302890,57676,102743,2420,75103,4194304,257,41340,16464,513]

theorem envBound27367 : H12AffineFastState.Bounded env27367 := by
  intro p hp
  have h : env27367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27366_27367 : H12AffineEnvironment.transform 20 115734 env27366 = env27367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env27366 == env27367) = true)

def env27368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91198,4194304,17,374,8192,65,4261890,16740,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound27368 : H12AffineFastState.Bounded env27368 := by
  intro p hp
  have h : env27368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27367_27368 : H12AffineEnvironment.transform 14 8232 env27367 = env27368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env27367 == env27368) = true)

theorem identity27368 : scanCanonicalize (H12AffineFastState.compose env27368 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27368 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env27369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,373,65536,16400,2049,1025,372,83299,4194304,17,374,349,65,4261890,16740,69666,2420,66562,4194304,257,340,16464,513]

theorem envBound27369 : H12AffineFastState.Bounded env27369 := by
  intro p hp
  have h : env27369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27368_27369 : H12AffineEnvironment.transform 12 349 env27368 = env27369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27368 == env27369) = true)

theorem identity27369 : scanCanonicalize (H12AffineFastState.compose env27369 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27369 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env27370 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,65536,16400,2049,1025,0,82967,4194304,17,2,41,65,4261890,16400,69666,2048,66562,4194304,117,32,16464,513]

theorem envBound27370 : H12AffineFastState.Bounded env27370 := by
  intro p hp
  have h : env27370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27369_27370 : H12AffineEnvironment.transform 7 116 env27369 = env27370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27369 == env27370) = true)

theorem identity27370 : scanCanonicalize (H12AffineFastState.compose env27370 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound27370 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27371 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,34,16400,2049,1025,0,17461,4194304,17,2,41,65,4196384,16400,4096,2048,1056,4194304,117,32,16464,513]

theorem envBound27371 : H12AffineFastState.Bounded env27371 := by
  intro p hp
  have h : env27371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27370_27371 : H12AffineEnvironment.transform 15 34 env27370 = env27371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env27370 == env27371) = true)

theorem identity27371 : scanCanonicalize (H12AffineFastState.compose env27371 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27371 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27372 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,34,16400,2049,1025,0,17461,4194304,17,2,41,16,4196384,16400,4096,2048,1056,4194304,36,32,16385,513]

theorem envBound27372 : H12AffineFastState.Bounded env27372 := by
  intro p hp
  have h : env27372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27371_27372 : H12AffineEnvironment.transform 5 17 env27371 = env27372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27371 == env27372) = true)

theorem identity27372 : scanCanonicalize (H12AffineFastState.compose env27372 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound27372 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27373 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5172,2049,1025,0,4113,4194304,17,2,41,16,4196384,5172,4096,2048,1056,4194304,36,32,5157,513]

theorem envBound27373 : H12AffineFastState.Bounded env27373 := by
  intro p hp
  have h : env27373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27372_27373 : H12AffineEnvironment.transform 13 5156 env27372 = env27373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env27372 == env27373) = true)

theorem identity27373 : scanCanonicalize (H12AffineFastState.compose env27373 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound27373 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27374 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5172,2049,1025,0,4113,33,17,2,41,16,2049,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound27374 : H12AffineFastState.Bounded env27374 := by
  intro p hp
  have h : env27374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27373_27374 : H12AffineEnvironment.transform 21 33 env27373 = env27374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env27373 == env27374) = true)

def env27375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91199,4194304,17,375,8192,65,4261891,16741,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound27375 : H12AffineFastState.Bounded env27375 := by
  intro p hp
  have h : env27375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27367_27375 : H12AffineEnvironment.transform 14 8233 env27367 = env27375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env27367 == env27375) = true)

theorem identity27375 : scanCanonicalize (H12AffineFastState.compose env27375 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27375 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env27376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,65536,16400,2421,1025,0,82967,4194304,17,375,40,65,4261891,16741,69974,2420,66935,4194304,257,341,16464,513]

theorem envBound27376 : H12AffineFastState.Bounded env27376 := by
  intro p hp
  have h : env27376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27375_27376 : H12AffineEnvironment.transform 12 40 env27375 = env27376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27375 == env27376) = true)

theorem identity27376 : scanCanonicalize (H12AffineFastState.compose env27376 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27376 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,65536,16400,2421,1025,0,82967,32,17,375,40,65,67619,16741,69974,2420,66935,32,257,341,16464,513]

theorem envBound27377 : H12AffineFastState.Bounded env27377 := by
  intro p hp
  have h : env27377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27376_27377 : H12AffineEnvironment.transform 21 32 env27376 = env27377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27376 == env27377) = true)

theorem identity27377 : scanCanonicalize (H12AffineFastState.compose env27377 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27377 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env27378 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,65536,16400,2048,1025,0,82967,32,17,2,40,65,67619,16400,69667,2049,66562,32,116,32,16464,513]

theorem envBound27378 : H12AffineFastState.Bounded env27378 := by
  intro p hp
  have h : env27378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27377_27378 : H12AffineEnvironment.transform 7 117 env27377 = env27378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27377 == env27378) = true)

theorem identity27378 : scanCanonicalize (H12AffineFastState.compose env27378 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound27378 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27379 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,35,16400,2048,1025,0,17460,32,17,2,40,65,2048,16400,4096,2049,1057,32,116,32,16464,513]

theorem envBound27379 : H12AffineFastState.Bounded env27379 := by
  intro p hp
  have h : env27379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27378_27379 : H12AffineEnvironment.transform 15 35 env27378 = env27379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env27378 == env27379) = true)

theorem identity27379 : scanCanonicalize (H12AffineFastState.compose env27379 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound27379 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27380 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1140,40,16384,1,35,16400,2048,1025,0,17460,32,17,2,40,65,2048,16400,1140,2049,1057,32,116,32,16464,513]

theorem envBound27380 : H12AffineFastState.Bounded env27380 := by
  intro p hp
  have h : env27380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27379_27380 : H12AffineEnvironment.transform 11 1140 env27379 = env27380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env27379 == env27380) = true)

theorem identity27380 : scanCanonicalize (H12AffineFastState.compose env27380 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3684) := by decide +kernel

theorem selectedBound27380 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27381 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1140,40,3684,1,35,3700,2048,1025,0,2640,32,17,2,40,65,2048,3700,1140,2049,1057,32,116,32,3636,513]

theorem envBound27381 : H12AffineFastState.Bounded env27381 := by
  intro p hp
  have h : env27381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27380_27381 : H12AffineEnvironment.transform 13 3684 env27380 = env27381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3684 env27380 == env27381) = true)

theorem identity27381 : scanCanonicalize (H12AffineFastState.compose env27381 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27381 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27382 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1061,40,3637,1,35,3621,2048,1025,0,2561,32,17,2,40,16,2048,3621,1061,2049,1057,32,37,32,3636,513]

theorem envBound27382 : H12AffineFastState.Bounded env27382 := by
  intro p hp
  have h : env27382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27381_27382 : H12AffineEnvironment.transform 5 17 env27381 = env27382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27381 == env27382) = true)

theorem identity27382 : scanCanonicalize (H12AffineFastState.compose env27382 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27383 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1028,9,3604,1,2,3588,2048,1025,0,2561,1,17,2,9,16,2048,3588,1028,2049,1024,1,4,1,3605,513]

theorem envBound27383 : H12AffineFastState.Bounded env27383 := by
  intro p hp
  have h : env27383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27382_27383 : H12AffineEnvironment.transform 4 1 env27382 = env27383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27382 == env27383) = true)

theorem identity27383 : scanCanonicalize (H12AffineFastState.compose env27383 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound27383 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27384 : List Nat := [2,4,8,16,1,17,8,5,512,517,2048,513,9,2065,1,2,2049,2048,516,0,2561,1,17,2,9,16,2048,2049,513,2049,517,1,4,1,2064,513]

theorem envBound27384 : H12AffineFastState.Bounded env27384 := by
  intro p hp
  have h : env27384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27383_27384 : H12AffineEnvironment.transform 9 517 env27383 = env27384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env27383 == env27384) = true)

theorem identity27384 : scanCanonicalize (H12AffineFastState.compose env27384 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27384 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27385 : List Nat := [2,4,8,16,1,17,8,5,0,5,2048,1,9,2065,1,2,2049,2048,4,0,2049,1,17,2,9,16,2048,2049,1,2049,5,1,4,1,2064,1]

theorem envBound27385 : H12AffineFastState.Bounded env27385 := by
  intro p hp
  have h : env27385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27384_27385 : H12AffineEnvironment.transform 8 0 env27384 = env27385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27384 == env27385) = true)

def env27386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35189,1025,32769,2097152,4194304,152,41311,8328,65,4302890,2172371,2119112,2421,75223,6407327,257,2188650,2196686,513]

theorem envBound27386 : H12AffineFastState.Bounded env27386 := by
  intro p hp
  have h : env27386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27364_27386 : H12AffineEnvironment.transform 16 16537 env27364 = env27386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env27364 == env27386) = true)

theorem identity27386 : scanCanonicalize (H12AffineFastState.compose env27386 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound27386 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1025,8660,2097152,4194304,152,138,8328,65,4262399,2172371,2119112,2421,75223,6382922,257,2188650,2172187,513]

theorem envBound27387 : H12AffineFastState.Bounded env27387 := by
  intro p hp
  have h : env27387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27386_27387 : H12AffineEnvironment.transform 14 8661 env27386 = env27387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env27386 == env27387) = true)

theorem identity27387 : scanCanonicalize (H12AffineFastState.compose env27387 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound27387 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16537,10400,1025,8660,2097152,4194304,152,138,8328,65,4204925,2098513,2119112,2421,1365,6309320,257,2115048,2098585,513]

theorem envBound27388 : H12AffineFastState.Bounded env27388 := by
  intro p hp
  have h : env27388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27387_27388 : H12AffineEnvironment.transform 15 8322 env27387 = env27388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env27387 == env27388) = true)

theorem identity27388 : scanCanonicalize (H12AffineFastState.compose env27388 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound27388 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env27389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16537,10400,1025,8660,2097152,168,152,138,8328,65,10709,2098513,2119112,2421,1365,2114912,257,2115048,2098585,513]

theorem envBound27389 : H12AffineFastState.Bounded env27389 := by
  intro p hp
  have h : env27389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27388_27389 : H12AffineEnvironment.transform 21 168 env27388 = env27389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env27388 == env27389) = true)

theorem identity27389 : scanCanonicalize (H12AffineFastState.compose env27389 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27389 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,8322,16537,10400,1025,8580,2097152,168,152,138,8328,17,10629,2098433,2119064,2341,1285,2114864,257,2115000,2098585,513]

theorem envBound27390 : H12AffineFastState.Bounded env27390 := by
  intro p hp
  have h : env27390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27389_27390 : H12AffineEnvironment.transform 5 16 env27389 = env27390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27389 == env27390) = true)

theorem identity27390 : scanCanonicalize (H12AffineFastState.compose env27390 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27390 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,136,399,16537,2477,1025,137,2097152,168,152,138,389,17,2184,2098433,2119064,2341,1285,2114864,257,2115000,2098585,513]

theorem envBound27391 : H12AffineFastState.Bounded env27391 := by
  intro p hp
  have h : env27391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27390_27391 : H12AffineEnvironment.transform 12 269 env27390 = env27391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27390 == env27391) = true)

theorem identity27391 : scanCanonicalize (H12AffineFastState.compose env27391 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound27391 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env27392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5293,136,399,5172,2477,1025,137,2097152,168,152,138,389,17,2184,2098433,2097461,2341,1285,2101661,257,2101525,2098585,513]

theorem envBound27392 : H12AffineFastState.Bounded env27392 := by
  intro p hp
  have h : env27392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27391_27392 : H12AffineEnvironment.transform 13 5293 env27391 = env27392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env27391 == env27392) = true)

theorem identity27392 : scanCanonicalize (H12AffineFastState.compose env27392 (packedSelected [0,1,3,7,11,18] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound27392 : packedSelected [0,1,3,7,11,18] rootPS < 2^1333 := by decide +kernel

def env27393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5293,136,399,5172,2477,1025,137,4405,168,152,138,389,17,2184,5172,4096,2341,1285,168,257,32,5292,513]

theorem envBound27393 : H12AffineFastState.Bounded env27393 := by
  intro p hp
  have h : env27393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27392_27393 : H12AffineEnvironment.transform 20 4405 env27392 = env27393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env27392 == env27393) = true)

theorem identity27393 : scanCanonicalize (H12AffineFastState.compose env27393 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27393 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27394 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,0,263,5172,2341,1025,1,4405,32,16,2,269,17,2048,5172,4096,2341,1285,32,257,32,5156,513]

theorem envBound27394 : H12AffineFastState.Bounded env27394 := by
  intro p hp
  have h : env27394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27393_27394 : H12AffineEnvironment.transform 6 8 env27393 = env27394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27393 == env27394) = true)

theorem identity27394 : scanCanonicalize (H12AffineFastState.compose env27394 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound27394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27395 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,269,1297,0,263,1280,2341,1025,1,1,32,16,2,269,17,2048,1280,308,2341,1285,32,257,32,1296,513]

theorem envBound27395 : H12AffineFastState.Bounded env27395 := by
  intro p hp
  have h : env27395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27394_27395 : H12AffineEnvironment.transform 11 308 env27394 = env27395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env27394 == env27395) = true)

theorem identity27395 : scanCanonicalize (H12AffineFastState.compose env27395 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27395 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27396 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,308,269,293,0,263,308,2341,53,1,1,32,16,2,269,17,2048,308,308,2341,305,32,257,32,292,513]

theorem envBound27396 : H12AffineFastState.Bounded env27396 := by
  intro p hp
  have h : env27396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27395_27396 : H12AffineEnvironment.transform 9 52 env27395 = env27396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27395 == env27396) = true)

theorem identity27396 : scanCanonicalize (H12AffineFastState.compose env27396 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound27396 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27397 : List Nat := [2,4,8,16,32,16,8,62,512,52,2048,10,51,27,0,57,10,2075,53,1,1,32,16,2,51,17,2048,10,10,2075,15,32,63,32,26,513]

theorem envBound27397 : H12AffineFastState.Bounded env27397 := by
  intro p hp
  have h : env27397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27396_27397 : H12AffineEnvironment.transform 7 62 env27396 = env27397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env27396 == env27397) = true)

theorem identity27397 : scanCanonicalize (H12AffineFastState.compose env27397 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27398 : List Nat := [2,4,8,11,32,11,8,37,512,47,2048,10,40,0,0,34,10,2048,46,1,1,32,11,2,40,10,2048,10,10,2048,15,32,36,32,1,513]

theorem envBound27398 : H12AffineFastState.Bounded env27398 := by
  intro p hp
  have h : env27398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27397_27398 : H12AffineEnvironment.transform 3 11 env27397 = env27398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27397 == env27398) = true)

theorem identity27398 : scanCanonicalize (H12AffineFastState.compose env27398 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27399 : List Nat := [2,4,8,11,32,11,8,37,512,47,1,10,40,0,0,34,10,1,46,1,1,32,11,2,40,10,1,10,10,1,15,32,36,32,1,513]

theorem envBound27399 : H12AffineFastState.Bounded env27399 := by
  intro p hp
  have h : env27399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27398_27399 : H12AffineEnvironment.transform 10 1 env27398 = env27399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27398 == env27399) = true)

def env27400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147456,16777216,8328,65,21187052,18973836,2233680,149996,17024016,23160256,257,19104941,19096841,16966598]

theorem envBound27400 : H12AffineFastState.Bounded env27400 := by
  intro p hp
  have h : env27400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27362_27400 : H12AffineEnvironment.transform 17 182765 env27362 = env27400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182765 env27362 == env27400) = true)

def env27401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35189,1025,32769,2097152,4194304,152,16777216,8328,65,21039476,18973836,2119112,2420,16876680,23160256,257,18990133,18949521,16819038]

theorem envBound27401 : H12AffineFastState.Bounded env27401 := by
  intro p hp
  have h : env27401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27400_27401 : H12AffineEnvironment.transform 16 16536 env27400 = env27401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env27400 == env27401) = true)

theorem identity27401 : scanCanonicalize (H12AffineFastState.compose env27401 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound27401 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35189,1025,32769,2097152,4194304,152,138,8328,65,4262398,2196486,2119112,2420,99330,6382922,257,2213055,2172187,41940]

theorem envBound27402 : H12AffineFastState.Bounded env27402 := by
  intro p hp
  have h : env27402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27401_27402 : H12AffineEnvironment.transform 23 138 env27401 = env27402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env27401 == env27402) = true)

def env27403 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35109,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196486,2119064,2340,99330,6382874,257,2213055,2172187,41860]

theorem envBound27403 : H12AffineFastState.Bounded env27403 := by
  intro p hp
  have h : env27403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27402_27403 : H12AffineEnvironment.transform 5 16 env27402 = env27403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27402 == env27403) = true)

def env27404 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13728,32768,65536,13624,35109,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196486,2105400,2340,99330,6361274,257,2208031,2172187,41860]

theorem envBound27404 : H12AffineFastState.Bounded env27404 := by
  intro p hp
  have h : env27404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27403_27404 : H12AffineEnvironment.transform 13 13728 env27403 = env27404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env27403 == env27404) = true)

theorem identity27404 : scanCanonicalize (H12AffineFastState.compose env27404 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound27404 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS < 2^1333 := by decide +kernel

def env27405 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5156,32768,65536,5308,35109,1025,32769,2097152,4194304,152,138,268,17,4262318,2196486,2097596,2340,99330,6361274,257,2199707,2163871,33280]

theorem envBound27405 : H12AffineFastState.Bounded env27405 := by
  intro p hp
  have h : env27405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27404_27405 : H12AffineEnvironment.transform 12 388 env27404 = env27405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env27404 == env27405) = true)

theorem identity27405 : scanCanonicalize (H12AffineFastState.compose env27405 (packedSelected [3,4,5,12,14,16,19,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 2101524) := by decide +kernel

theorem selectedBound27405 : packedSelected [3,4,5,12,14,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env27406 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5156,32768,65536,5308,35109,1025,32769,2097152,2101524,152,138,268,17,2169018,2196486,2097596,2340,99330,65966,257,2199707,2163871,33280]

theorem envBound27406 : H12AffineFastState.Bounded env27406 := by
  intro p hp
  have h : env27406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27405_27406 : H12AffineEnvironment.transform 21 2101524 env27405 = env27406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101524 env27405 == env27406) = true)

theorem identity27406 : scanCanonicalize (H12AffineFastState.compose env27406 (packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27406 : packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env27407 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,65536,5173,35109,1025,32769,2097152,2101524,17,3,268,17,2168883,2196486,2097461,2340,99330,65831,257,2199570,2163734,33280]

theorem envBound27407 : H12AffineFastState.Bounded env27407 := by
  intro p hp
  have h : env27407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27406_27407 : H12AffineEnvironment.transform 6 9 env27406 = env27407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27406 == env27407) = true)

theorem identity27407 : scanCanonicalize (H12AffineFastState.compose env27407 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound27407 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27408 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33030,5173,35109,1025,32769,2097152,2101524,17,3,268,17,2136373,2098432,2097461,2340,1284,32801,257,2101524,2131216,33280]

theorem envBound27408 : H12AffineFastState.Bounded env27408 := by
  intro p hp
  have h : env27408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27407_27408 : H12AffineEnvironment.transform 15 33030 env27407 = env27408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env27407 == env27408) = true)

theorem identity27408 : scanCanonicalize (H12AffineFastState.compose env27408 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 37172) := by decide +kernel

theorem selectedBound27408 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env27409 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33030,5173,35109,1025,32769,37172,32800,17,3,268,17,2049,37940,36865,2340,1284,32801,257,32800,5156,33280]

theorem envBound27409 : H12AffineFastState.Bounded env27409 := by
  intro p hp
  have h : env27409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27408_27409 : H12AffineEnvironment.transform 20 37172 env27408 = env27409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37172 env27408 == env27409) = true)

theorem identity27409 : scanCanonicalize (H12AffineFastState.compose env27409 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound27409 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27410 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,292,34,5173,2049,1025,293,4112,260,17,3,268,17,2049,5392,4389,2340,1284,261,257,260,5156,804]

theorem envBound27410 : H12AffineFastState.Bounded env27410 := by
  intro p hp
  have h : env27410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27409_27410 : H12AffineEnvironment.transform 14 292 env27409 = env27410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env27409 == env27410) = true)

theorem identity27410 : scanCanonicalize (H12AffineFastState.compose env27410 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27410 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env27411 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5125,261,3,5140,2049,1025,260,4112,260,17,3,268,17,2049,5392,4356,2309,1284,261,257,260,5125,773]

theorem envBound27411 : H12AffineFastState.Bounded env27411 := by
  intro p hp
  have h : env27411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27410_27411 : H12AffineEnvironment.transform 4 1 env27410 = env27411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27410 == env27411) = true)

def env27412 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13729,32768,65536,13625,35109,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196486,2105401,2340,99330,6361275,257,2208030,2172187,41860]

theorem envBound27412 : H12AffineFastState.Bounded env27412 := by
  intro p hp
  have h : env27412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27403_27412 : H12AffineEnvironment.transform 13 13729 env27403 = env27412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env27403 == env27412) = true)

theorem identity27412 : scanCanonicalize (H12AffineFastState.compose env27412 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27412 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS < 2^1333 := by decide +kernel

def env27413 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,32768,65536,5173,35109,1025,32769,2097152,4194304,152,138,388,17,4262318,2196486,2097461,2340,99330,6361275,257,2199570,2163735,33416]

theorem envBound27413 : H12AffineFastState.Bounded env27413 := by
  intro p hp
  have h : env27413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27412_27413 : H12AffineEnvironment.transform 12 268 env27412 = env27413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27412 == env27413) = true)

theorem identity27413 : scanCanonicalize (H12AffineFastState.compose env27413 (packedSelected [0,1,3,4,7,8,10,12,15,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 37309) := by decide +kernel

theorem selectedBound27413 : packedSelected [0,1,3,4,7,8,10,12,15,22,24] rootPS < 2^1333 := by decide +kernel

def env27414 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,32768,65536,5173,35109,1025,32769,37309,4194304,152,138,388,17,4262318,71099,37000,2340,99330,4292870,257,65967,103850,33416]

theorem envBound27414 : H12AffineFastState.Bounded env27414 := by
  intro p hp
  have h : env27414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27413_27414 : H12AffineEnvironment.transform 20 37309 env27413 = env27414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37309 env27413 == env27414) = true)

theorem identity27414 : scanCanonicalize (H12AffineFastState.compose env27414 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27414 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,1,65536,5173,2340,1025,0,4540,4194304,152,138,388,17,4262318,71099,4233,2340,66563,4260103,257,65967,71083,649]

theorem envBound27415 : H12AffineFastState.Bounded env27415 := by
  intro p hp
  have h : env27415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27414_27415 : H12AffineEnvironment.transform 14 1 env27414 = env27415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27414 == env27415) = true)

theorem identity27415 : scanCanonicalize (H12AffineFastState.compose env27415 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(21+1) ^^^ 65967) := by decide +kernel

theorem selectedBound27415 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,1,65536,5173,2340,1025,0,4540,65967,152,138,388,17,2049,71099,4233,2340,66563,168,257,65967,71083,649]

theorem envBound27416 : H12AffineFastState.Bounded env27416 := by
  intro p hp
  have h : env27416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27415_27416 : H12AffineEnvironment.transform 21 65967 env27415 = env27416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65967 env27415 == env27416) = true)

def env27417 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35108,1025,32769,2097152,4194304,152,138,8328,16,4262319,2196486,2119065,2341,99330,6382875,257,2213055,2172187,41861]

theorem envBound27417 : H12AffineFastState.Bounded env27417 := by
  intro p hp
  have h : env27417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27402_27417 : H12AffineEnvironment.transform 5 17 env27402 = env27417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27402 == env27417) = true)

theorem identity27417 : scanCanonicalize (H12AffineFastState.compose env27417 (packedSelected [2,4,6,8,10,17,18,19,20,22,23,26,28] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound27417 : packedSelected [2,4,6,8,10,17,18,19,20,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env27418 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35108,1025,32769,2097152,73771,152,138,8328,16,10628,2196486,2119065,2341,99330,2114864,257,2213055,2172187,41861]

theorem envBound27418 : H12AffineFastState.Bounded env27418 := by
  intro p hp
  have h : env27418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27417_27418 : H12AffineEnvironment.transform 21 73771 env27417 = env27418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env27417 == env27418) = true)

def env27419 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35076,1025,32769,2097152,73739,152,138,8328,16,10628,2196486,2119065,2309,99330,2114832,257,2213023,2172187,41861]

theorem envBound27419 : H12AffineFastState.Bounded env27419 := by
  intro p hp
  have h : env27419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27418_27419 : H12AffineEnvironment.transform 4 0 env27418 = env27419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27418 == env27419) = true)

theorem identity27419 : scanCanonicalize (H12AffineFastState.compose env27419 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27419 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27420 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35076,1025,32769,2097152,73739,16,2,8192,16,10508,2196486,2118929,2309,99330,2114832,257,2212887,2172187,41741]

theorem envBound27420 : H12AffineFastState.Bounded env27420 := by
  intro p hp
  have h : env27420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27419_27420 : H12AffineEnvironment.transform 6 8 env27419 = env27420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27419 == env27420) = true)

theorem identity27420 : scanCanonicalize (H12AffineFastState.compose env27420 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound27420 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env27421 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35076,1025,32769,17681,73739,16,2,8192,16,10508,114967,4096,2309,99330,1,257,98566,90122,41741]

theorem envBound27421 : H12AffineFastState.Bounded env27421 := by
  intro p hp
  have h : env27421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27420_27421 : H12AffineEnvironment.transform 20 17681 env27420 = env27421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env27420 == env27421) = true)

theorem identity27421 : scanCanonicalize (H12AffineFastState.compose env27421 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound27421 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env27422 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,16400,10249,1025,8460,17681,73739,16,2,8192,16,10508,90138,4096,2309,75023,1,257,73739,90122,512]

theorem envBound27422 : H12AffineFastState.Bounded env27422 := by
  intro p hp
  have h : env27422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27421_27422 : H12AffineEnvironment.transform 14 8461 env27421 = env27422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env27421 == env27422) = true)

theorem identity27422 : scanCanonicalize (H12AffineFastState.compose env27422 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19478) := by decide +kernel

theorem selectedBound27422 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env27423 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8461,19478,16400,10249,1025,8460,17681,27677,16,2,8192,16,10508,11276,4096,2309,26905,1,257,27677,11292,512]

theorem envBound27423 : H12AffineFastState.Bounded env27423 := by
  intro p hp
  have h : env27423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27422_27423 : H12AffineEnvironment.transform 15 19478 env27422 = env27423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19478 env27422 == env27423) = true)

theorem identity27423 : scanCanonicalize (H12AffineFastState.compose env27423 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound27423 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env27424 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,7433,16384,7172,19478,16400,5376,1025,7173,17681,20756,16,2,7433,16,5125,4357,4096,2309,21520,1,257,20756,4373,512]

theorem envBound27424 : H12AffineFastState.Bounded env27424 := by
  intro p hp
  have h : env27424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27423_27424 : H12AffineEnvironment.transform 12 7433 env27423 = env27424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env27423 == env27424) = true)

theorem identity27424 : scanCanonicalize (H12AffineFastState.compose env27424 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27424 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env27425 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,6169,16384,6420,18694,16400,4112,273,6421,16385,20756,16,2,6169,16,4373,4357,4096,2309,20736,1,257,20756,4373,512]

theorem envBound27425 : H12AffineFastState.Bounded env27425 := by
  intro p hp
  have h : env27425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27424_27425 : H12AffineEnvironment.transform 9 272 env27424 = env27425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27424 == env27425) = true)

theorem identity27425 : scanCanonicalize (H12AffineFastState.compose env27425 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound27425 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27426 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,6169,2049,6420,263,2065,4112,273,6421,2048,6421,16,2,6169,16,4373,4357,4096,2309,6401,1,257,6421,4373,512]

theorem envBound27426 : H12AffineFastState.Bounded env27426 := by
  intro p hp
  have h : env27426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27425_27426 : H12AffineEnvironment.transform 13 2049 env27425 = env27426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env27425 == env27426) = true)

theorem identity27426 : scanCanonicalize (H12AffineFastState.compose env27426 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound27426 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env27427 : List Nat := [2,4,8,16,0,17,8,256,512,272,260,4096,4381,261,4112,263,277,4112,273,4113,260,4113,16,2,4381,16,4373,4357,4096,1,4101,1,257,4113,4373,512]

theorem envBound27427 : H12AffineFastState.Bounded env27427 := by
  intro p hp
  have h : env27427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27426_27427 : H12AffineEnvironment.transform 10 260 env27426 = env27427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env27426 == env27427) = true)

theorem identity27427 : scanCanonicalize (H12AffineFastState.compose env27427 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27427 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27428 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,4096,4121,1,4112,3,17,4112,21,4113,0,4113,16,2,4121,16,4113,4097,4096,1,4101,1,5,4113,4113,512]

theorem envBound27428 : H12AffineFastState.Bounded env27428 := by
  intro p hp
  have h : env27428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27427_27428 : H12AffineEnvironment.transform 7 4 env27427 = env27428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27427 == env27428) = true)

def env27429 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35077,1025,32769,2097152,73738,152,138,8328,16,10628,2196486,2119065,2308,99330,2114833,257,2213022,2172187,41861]

theorem envBound27429 : H12AffineFastState.Bounded env27429 := by
  intro p hp
  have h : env27429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27418_27429 : H12AffineEnvironment.transform 4 1 env27418 = env27429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27418 == env27429) = true)

theorem identity27429 : scanCanonicalize (H12AffineFastState.compose env27429 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27429 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27430 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,16536,10249,1025,8461,2097152,73738,152,138,8328,16,10628,2172170,2119065,2308,75022,2114833,257,2188690,2172187,649]

theorem envBound27430 : H12AffineFastState.Bounded env27430 := by
  intro p hp
  have h : env27430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27429_27430 : H12AffineEnvironment.transform 14 8460 env27429 = env27430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27429 == env27430) = true)

theorem identity27430 : scanCanonicalize (H12AffineFastState.compose env27430 (packedSelected [3,4,5,9,10,11,17] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound27430 : packedSelected [3,4,5,9,10,11,17] rootPS < 2^1333 := by decide +kernel

def env27431 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,16536,10249,1025,8461,82967,73738,152,138,8328,16,10628,24861,70030,2308,75022,65798,257,8581,24844,649]

theorem envBound27431 : H12AffineFastState.Bounded env27431 := by
  intro p hp
  have h : env27431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27430_27431 : H12AffineEnvironment.transform 20 82967 env27430 = env27431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env27430 == env27431) = true)

theorem identity27431 : scanCanonicalize (H12AffineFastState.compose env27431 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27431 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env27432 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,389,16384,137,65536,16536,2444,1025,136,82967,65935,152,138,269,16,2049,16536,70030,2308,66699,65798,257,0,16521,649]

theorem envBound27432 : H12AffineFastState.Bounded env27432 := by
  intro p hp
  have h : env27432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27431_27432 : H12AffineEnvironment.transform 12 389 env27431 = env27432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27431 == env27432) = true)

theorem identity27432 : scanCanonicalize (H12AffineFastState.compose env27432 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound27432 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27433 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,389,16384,137,398,16536,2444,1025,136,17817,1,152,138,269,16,2049,16536,4096,2308,1285,136,257,0,16521,649]

theorem envBound27433 : H12AffineFastState.Bounded env27433 := by
  intro p hp
  have h : env27433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27432_27433 : H12AffineEnvironment.transform 15 398 env27432 = env27433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env27432 == env27433) = true)

theorem identity27433 : scanCanonicalize (H12AffineFastState.compose env27433 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27433 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env27434 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,268,16384,0,263,16401,2309,1025,1,17680,1,17,3,269,16,2049,16401,4096,2308,1285,1,257,0,16384,512]

theorem envBound27434 : H12AffineFastState.Bounded env27434 := by
  intro p hp
  have h : env27434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27433_27434 : H12AffineEnvironment.transform 6 9 env27433 = env27434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27433 == env27434) = true)

theorem identity27434 : scanCanonicalize (H12AffineFastState.compose env27434 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27434 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27435 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,16384,0,2,16401,2048,1025,1,17429,1,17,3,8,16,2049,16401,4096,2049,1024,1,4,0,16384,512]

theorem envBound27435 : H12AffineFastState.Bounded env27435 := by
  intro p hp
  have h : env27435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27434_27435 : H12AffineEnvironment.transform 7 5 env27434 = env27435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27434 == env27435) = true)

theorem identity27435 : scanCanonicalize (H12AffineFastState.compose env27435 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound27435 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27436 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1025,1,4112,1,17,3,8,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound27436 : H12AffineFastState.Bounded env27436 := by
  intro p hp
  have h : env27436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27435_27436 : H12AffineEnvironment.transform 13 5125 env27435 = env27436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env27435 == env27436) = true)

def env27437 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,0,2,1028,2048,1025,1,0,1,17,3,8,16,2049,1028,16,2049,1024,1,4,0,1045,512]

theorem envBound27437 : H12AffineFastState.Bounded env27437 := by
  intro p hp
  have h : env27437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27436_27437 : H12AffineEnvironment.transform 11 16 env27436 = env27437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27436 == env27437) = true)

theorem identity27437 : scanCanonicalize (H12AffineFastState.compose env27437 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound27437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27438 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,0,0,2,17,2048,20,1,0,1,17,3,8,16,2049,17,16,2049,21,1,4,0,0,512]

theorem envBound27438 : H12AffineFastState.Bounded env27438 := by
  intro p hp
  have h : env27438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27437_27438 : H12AffineEnvironment.transform 9 21 env27437 = env27438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27437 == env27438) = true)

theorem identity27438 : scanCanonicalize (H12AffineFastState.compose env27438 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound27438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27439 : List Nat := [2,4,8,16,1,17,9,5,512,21,542,16,9,0,0,2,17,542,20,1,0,1,17,3,8,16,543,17,16,543,21,1,4,0,0,512]

theorem envBound27439 : H12AffineFastState.Bounded env27439 := by
  intro p hp
  have h : env27439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27438_27439 : H12AffineEnvironment.transform 10 542 env27438 = env27439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env27438 == env27439) = true)

def leafEnv27439 : List Nat := [2,4,8,16,1,17,9,5,512,21,542,16,9,0,0,2,17,542,20,1,0,1,17,3,20,8,1,16,543,17,16,543,21,1,4,0,5,3,0,512,1,0,0]

def active27439 : List Nat := [0,1,2,3,8]

def tree27439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27439 : H12WitnessSearch.Good tree27439 := H12GlobalWitnessIndex.good

theorem leafIdentity27439 : H12AffineFastState.composeSystem env27439 rootObs = leafEnv27439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27439 rootObs == leafEnv27439) = true)

theorem terminalChecked27439 : H12PackedTerminal.terminalCheckFast leafEnv27439 active27439 tree27439 = true := by decide +kernel

def env27440 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,0,2,1029,2048,1025,1,1,1,17,3,8,16,2049,1029,17,2049,1024,1,4,0,1044,512]

theorem envBound27440 : H12AffineFastState.Bounded env27440 := by
  intro p hp
  have h : env27440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27436_27440 : H12AffineEnvironment.transform 11 17 env27436 = env27440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27436 == env27440) = true)

def env27441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35188,1025,32769,2097152,4194304,153,16777216,8328,65,21039477,18973836,2119113,2421,16876681,23160256,257,18990132,18949520,16819039]

theorem envBound27441 : H12AffineFastState.Bounded env27441 := by
  intro p hp
  have h : env27441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27400_27441 : H12AffineEnvironment.transform 16 16537 env27400 = env27441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env27400 == env27441) = true)

theorem identity27441 : scanCanonicalize (H12AffineFastState.compose env27441 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41430) := by decide +kernel

theorem selectedBound27441 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35188,1025,32769,2097152,4194304,153,41430,8328,65,4303011,2172250,2119113,2421,75103,6407190,257,2188770,2196550,649]

theorem envBound27442 : H12AffineFastState.Bounded env27442 := by
  intro p hp
  have h : env27442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27441_27442 : H12AffineEnvironment.transform 23 41430 env27441 = env27442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41430 env27441 == env27442) = true)

def env27443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302891,2172250,2118977,2421,75103,6407190,257,2188650,2196550,513]

theorem envBound27443 : H12AffineFastState.Bounded env27443 := by
  intro p hp
  have h : env27443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27442_27443 : H12AffineEnvironment.transform 6 8 env27442 = env27443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27442 == env27443) = true)

theorem identity27443 : scanCanonicalize (H12AffineFastState.compose env27443 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound27443 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env27444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115734,4194304,17,41310,8192,65,4302891,57676,102743,2421,75103,4194304,257,41340,16464,513]

theorem envBound27444 : H12AffineFastState.Bounded env27444 := by
  intro p hp
  have h : env27444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27443_27444 : H12AffineEnvironment.transform 20 115734 env27443 = env27444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env27443 == env27444) = true)

theorem identity27444 : scanCanonicalize (H12AffineFastState.compose env27444 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27444 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env27445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91466,4194304,17,2,8192,65,4262263,16400,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound27445 : H12AffineFastState.Bounded env27445 := by
  intro p hp
  have h : env27445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27444_27445 : H12AffineEnvironment.transform 14 8540 env27444 = env27445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27444 == env27445) = true)

theorem identity27445 : scanCanonicalize (H12AffineFastState.compose env27445 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27445 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env27446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91466,32,17,2,8192,65,67927,16400,77835,2421,75103,32,257,32,16464,513]

theorem envBound27446 : H12AffineFastState.Bounded env27446 := by
  intro p hp
  have h : env27446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27445_27446 : H12AffineEnvironment.transform 21 32 env27445 = env27446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27445 == env27446) = true)

def env27447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,41311,8193,65,4302890,2172250,2118976,2421,75103,6407190,257,2188651,2196550,512]

theorem envBound27447 : H12AffineFastState.Bounded env27447 := by
  intro p hp
  have h : env27447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27442_27447 : H12AffineEnvironment.transform 6 9 env27442 = env27447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27442 == env27447) = true)

theorem identity27447 : scanCanonicalize (H12AffineFastState.compose env27447 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound27447 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,17460,4194304,16,41311,8193,65,4302890,90478,4468,2421,75103,4292642,257,74079,114802,512]

theorem envBound27448 : H12AffineFastState.Bounded env27448 := by
  intro p hp
  have h : env27448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27447_27448 : H12AffineEnvironment.transform 20 17460 env27447 = env27448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env27447 == env27448) = true)

theorem identity27448 : scanCanonicalize (H12AffineFastState.compose env27448 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33143) := by decide +kernel

theorem selectedBound27448 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33143,16400,35188,1025,32769,17460,4194304,16,41311,8193,65,4204893,57369,4468,2421,42024,4194645,257,41000,16645,512]

theorem envBound27449 : H12AffineFastState.Bounded env27449 := by
  intro p hp
  have h : env27449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27448_27449 : H12AffineEnvironment.transform 15 33143 env27448 = env27449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33143 env27448 == env27449) = true)

theorem identity27449 : scanCanonicalize (H12AffineFastState.compose env27449 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound27449 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env27450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33143,16400,35188,1025,32769,17460,41340,16,41311,8193,65,34849,57369,4468,2421,42024,41001,257,41000,16645,512]

theorem envBound27450 : H12AffineFastState.Bounded env27450 := by
  intro p hp
  have h : env27450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27449_27450 : H12AffineEnvironment.transform 21 41340 env27449 = env27450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env27449 == env27450) = true)

theorem identity27450 : scanCanonicalize (H12AffineFastState.compose env27450 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27450 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8315,16400,10360,1025,8461,17460,112,16,83,8193,65,10541,16661,4468,2421,1316,293,257,292,16645,512]

theorem envBound27451 : H12AffineFastState.Bounded env27451 := by
  intro p hp
  have h : env27451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27450_27451 : H12AffineEnvironment.transform 14 8460 env27450 = env27451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27450 == env27451) = true)

theorem identity27451 : scanCanonicalize (H12AffineFastState.compose env27451 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,17,18,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27451 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env27452 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,16384,8200,8315,16400,10360,1025,8201,17460,112,16,83,8193,65,10281,16401,4208,2161,1056,33,5,32,16385,512]

theorem envBound27452 : H12AffineFastState.Bounded env27452 := by
  intro p hp
  have h : env27452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27451_27452 : H12AffineEnvironment.transform 7 4 env27451 = env27452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27451 == env27452) = true)

theorem identity27452 : scanCanonicalize (H12AffineFastState.compose env27452 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound27452 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env27453 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8,16384,0,115,16400,2160,1025,1,17460,112,16,83,9,65,2081,16401,4208,2161,1056,33,5,32,16385,512]

theorem envBound27453 : H12AffineFastState.Bounded env27453 := by
  intro p hp
  have h : env27453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27452_27453 : H12AffineEnvironment.transform 12 8 env27452 = env27453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env27452 == env27453) = true)

theorem identity27453 : scanCanonicalize (H12AffineFastState.compose env27453 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27453 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27454 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,16384,0,35,16400,2080,1025,1,17460,32,16,3,9,17,2081,16401,4128,2081,1056,33,5,32,16385,512]

theorem envBound27454 : H12AffineFastState.Bounded env27454 := by
  intro p hp
  have h : env27454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27453_27454 : H12AffineEnvironment.transform 5 16 env27453 = env27454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27453 == env27454) = true)

theorem identity27454 : scanCanonicalize (H12AffineFastState.compose env27454 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27454 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27455 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,8,16384,0,3,16400,2048,1025,1,17428,0,16,3,9,17,2049,16401,4096,2049,1024,1,5,0,16385,512]

theorem envBound27455 : H12AffineFastState.Bounded env27455 := by
  intro p hp
  have h : env27455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27454_27455 : H12AffineEnvironment.transform 4 0 env27454 = env27455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27454 == env27455) = true)

theorem identity27455 : scanCanonicalize (H12AffineFastState.compose env27455 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound27455 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27456 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,8,5125,0,3,5141,2048,1025,1,4113,0,16,3,9,17,2049,5140,4096,2049,1024,1,5,0,5124,512]

theorem envBound27456 : H12AffineFastState.Bounded env27456 := by
  intro p hp
  have h : env27456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27455_27456 : H12AffineEnvironment.transform 13 5125 env27455 = env27456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env27455 == env27456) = true)

theorem identity27456 : scanCanonicalize (H12AffineFastState.compose env27456 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound27456 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27457 : List Nat := [2,4,8,16,0,16,9,4,512,1024,523,4096,8,5125,0,3,5141,523,1025,1,4113,0,16,3,9,17,522,5140,4096,522,1024,1,5,0,5124,512]

theorem envBound27457 : H12AffineFastState.Bounded env27457 := by
  intro p hp
  have h : env27457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27456_27457 : H12AffineEnvironment.transform 10 523 env27456 = env27457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env27456 == env27457) = true)

def env27458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound27458 : H12AffineFastState.Bounded env27458 := by
  intro p hp
  have h : env27458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27209_27458 : H12AffineEnvironment.transform 26 30393345 env27209 = env27458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env27209 == env27458) = true)

def env27459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound27459 : H12AffineFastState.Bounded env27459 := by
  intro p hp
  have h : env27459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27458_27459 : H12AffineEnvironment.transform 18 1024 env27458 = env27459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env27458 == env27459) = true)

theorem identity27459 : scanCanonicalize (H12AffineFastState.compose env27459 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396460) := by decide +kernel

theorem selectedBound27459 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,16777216,8328,65,29868033,17270817,8804860,8830977,25265168,21457261,256,25675777,25635237,25207751]

theorem envBound27460 : H12AffineFastState.Bounded env27460 := by
  intro p hp
  have h : env27460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27459_27460 : H12AffineEnvironment.transform 20 396460 env27459 = env27460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396460 env27459 == env27460) = true)

def env27461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,8887584,8328,65,4218145,8393985,8804860,8830977,399664,12645453,256,21793,46213,474855]

theorem envBound27461 : H12AffineFastState.Bounded env27461 := by
  intro p hp
  have h : env27461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27460_27461 : H12AffineEnvironment.transform 23 8887584 env27460 = env27461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887584 env27460 == env27461) = true)

def env27462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452648,95496,8328,65,4218145,458025,45524,10281,399664,4594789,256,21793,46213,474855]

theorem envBound27462 : H12AffineFastState.Bounded env27462 := by
  intro p hp
  have h : env27462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27461_27462 : H12AffineEnvironment.transform 22 452648 env27461 = env27462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env27461 == env27462) = true)

def env27463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452648,95496,8328,65,292257,458025,45524,10281,399664,144613,256,21793,46213,474855]

theorem envBound27463 : H12AffineFastState.Bounded env27463 := by
  intro p hp
  have h : env27463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27462_27463 : H12AffineEnvironment.transform 21 272512 env27462 = env27463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27462 == env27463) = true)

theorem identity27463 : scanCanonicalize (H12AffineFastState.compose env27463 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound27463 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58516,180408,16,95496,8328,65,171417,5393,45524,10281,61704,144613,256,21793,46213,120543]

theorem envBound27464 : H12AffineFastState.Bounded env27464 := by
  intro p hp
  have h : env27464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27463_27464 : H12AffineEnvironment.transform 17 190520 env27463 = env27464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env27463 == env27464) = true)

def env27465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58396,180272,16,95496,8192,65,171281,5393,45404,10281,61704,144493,256,21793,46093,120407]

theorem envBound27465 : H12AffineFastState.Bounded env27465 := by
  intro p hp
  have h : env27465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27464_27465 : H12AffineEnvironment.transform 6 8 env27464 = env27465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27464 == env27465) = true)

theorem identity27465 : scanCanonicalize (H12AffineFastState.compose env27465 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27465 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,130174,1024,32769,58396,119926,16,95496,8192,65,100695,5393,45404,10281,61704,73771,256,21793,46093,120407]

theorem envBound27466 : H12AffineFastState.Bounded env27466 := by
  intro p hp
  have h : env27466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27465_27466 : H12AffineEnvironment.transform 16 70726 env27465 = env27466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27465 == env27466) = true)

theorem identity27466 : scanCanonicalize (H12AffineFastState.compose env27466 (packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27466 : packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env27467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,70726,108926,1024,32769,45340,98678,16,73736,8192,65,100695,5393,45404,10281,41992,73771,256,33,46093,99159]

theorem envBound27467 : H12AffineFastState.Bounded env27467 := by
  intro p hp
  have h : env27467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27466_27467 : H12AffineEnvironment.transform 13 5376 env27466 = env27467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27466 == env27467) = true)

theorem identity27467 : scanCanonicalize (H12AffineFastState.compose env27467 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound27467 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env27468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40971,46157,2421,1024,32769,45340,8573,16,32771,8192,65,10588,5393,45404,10281,41992,32800,256,33,46093,9052]

theorem envBound27468 : H12AffineFastState.Bounded env27468 := by
  intro p hp
  have h : env27468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27467_27468 : H12AffineEnvironment.transform 15 40971 env27467 = env27468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env27467 == env27468) = true)

theorem identity27468 : scanCanonicalize (H12AffineFastState.compose env27468 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound27468 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env27469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,80,8283,13341,2421,1024,81,12620,8573,16,83,8192,65,10588,5393,12556,10281,9304,112,256,33,13405,9052]

theorem envBound27469 : H12AffineFastState.Bounded env27469 := by
  intro p hp
  have h : env27469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27468_27469 : H12AffineEnvironment.transform 14 80 env27468 = env27469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env27468 == env27469) = true)

theorem identity27469 : scanCanonicalize (H12AffineFastState.compose env27469 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27469 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env27470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,342,5392,2421,1024,81,4161,112,16,83,269,65,2129,5393,4097,2340,1365,112,256,33,5456,593]

theorem envBound27470 : H12AffineFastState.Bounded env27470 := by
  intro p hp
  have h : env27470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27469_27470 : H12AffineEnvironment.transform 12 269 env27469 = env27470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27469 == env27470) = true)

theorem identity27470 : scanCanonicalize (H12AffineFastState.compose env27470 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27470 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27471 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5376,80,342,5392,2388,1024,81,4161,81,16,83,269,65,2129,5393,4097,2309,1365,81,256,0,5456,593]

theorem envBound27471 : H12AffineFastState.Bounded env27471 := by
  intro p hp
  have h : env27471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27470_27471 : H12AffineEnvironment.transform 4 1 env27470 = env27471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27470 == env27471) = true)

theorem identity27471 : scanCanonicalize (H12AffineFastState.compose env27471 (packedSelected [1,2,4,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound27471 : packedSelected [1,2,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env27472 : List Nat := [2,4,8,16,1,64,8,256,512,1024,80,4096,269,5376,80,342,5392,260,1024,81,4161,81,16,83,269,65,1,5393,4097,341,1365,81,256,0,5456,593]

theorem envBound27472 : H12AffineFastState.Bounded env27472 := by
  intro p hp
  have h : env27472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27471_27472 : H12AffineEnvironment.transform 10 80 env27471 = env27472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env27471 == env27472) = true)

theorem identity27472 : scanCanonicalize (H12AffineFastState.compose env27472 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound27472 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env27473 : List Nat := [2,4,8,16,1,64,8,256,512,1024,80,17,269,1297,80,342,1281,260,1024,81,80,81,16,83,269,65,1,1280,16,341,1365,81,256,0,1345,593]

theorem envBound27473 : H12AffineFastState.Bounded env27473 := by
  intro p hp
  have h : env27473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27472_27473 : H12AffineEnvironment.transform 11 17 env27472 = env27473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27472 == env27473) = true)

theorem identity27473 : scanCanonicalize (H12AffineFastState.compose env27473 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound27473 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env27474 : List Nat := [2,4,8,16,1,64,8,256,512,69,80,17,269,340,80,342,324,260,69,81,80,81,16,83,269,65,1,325,16,341,272,81,256,0,260,593]

theorem envBound27474 : H12AffineFastState.Bounded env27474 := by
  intro p hp
  have h : env27474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27473_27474 : H12AffineEnvironment.transform 9 69 env27473 = env27474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env27473 == env27474) = true)

theorem identity27474 : scanCanonicalize (H12AffineFastState.compose env27474 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27474 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27475 : List Nat := [2,4,8,16,1,16,8,256,512,21,0,17,269,260,0,262,276,260,21,1,0,1,16,3,269,17,1,277,16,261,272,1,256,0,260,513]

theorem envBound27475 : H12AffineFastState.Bounded env27475 := by
  intro p hp
  have h : env27475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27474_27475 : H12AffineEnvironment.transform 5 16 env27474 = env27475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27474 == env27475) = true)

theorem identity27475 : scanCanonicalize (H12AffineFastState.compose env27475 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27476 : List Nat := [2,4,8,0,1,0,8,256,512,5,0,1,269,260,0,262,260,260,5,1,0,1,0,3,269,1,1,261,0,261,256,1,256,0,260,513]

theorem envBound27476 : H12AffineFastState.Bounded env27476 := by
  intro p hp
  have h : env27476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27475_27476 : H12AffineEnvironment.transform 3 0 env27475 = env27476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27475 == env27476) = true)

theorem identity27476 : scanCanonicalize (H12AffineFastState.compose env27476 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound27476 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27477 : List Nat := [2,4,8,0,1,0,8,256,261,5,0,1,269,260,0,262,260,260,5,1,0,1,0,3,269,1,1,261,0,261,256,1,256,0,260,260]

theorem envBound27477 : H12AffineFastState.Bounded env27477 := by
  intro p hp
  have h : env27477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27476_27477 : H12AffineEnvironment.transform 8 261 env27476 = env27477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env27476 == env27477) = true)

theorem identity27477 : scanCanonicalize (H12AffineFastState.compose env27477 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27478 : List Nat := [2,4,8,0,1,0,8,5,0,5,0,1,8,1,0,3,1,1,5,1,0,1,0,3,8,1,1,0,0,0,5,1,5,0,1,1]

theorem envBound27478 : H12AffineFastState.Bounded env27478 := by
  intro p hp
  have h : env27478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27477_27478 : H12AffineEnvironment.transform 7 5 env27477 = env27478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27477 == env27478) = true)

def env27479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58397,180273,16,95496,8193,65,171280,5393,45405,10281,61704,144492,256,21793,46092,120406]

theorem envBound27479 : H12AffineFastState.Bounded env27479 := by
  intro p hp
  have h : env27479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27464_27479 : H12AffineEnvironment.transform 6 9 env27464 = env27479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27464 == env27479) = true)

theorem identity27479 : scanCanonicalize (H12AffineFastState.compose env27479 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound27479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,89379,1024,32769,58397,95530,16,95496,8193,65,75787,5393,45405,10281,61704,98679,256,21793,46092,120406]

theorem envBound27480 : H12AffineFastState.Bounded env27480 := by
  intro p hp
  have h : env27480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27479_27480 : H12AffineEnvironment.transform 16 111899 env27479 = env27480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env27479 == env27480) = true)

theorem identity27480 : scanCanonicalize (H12AffineFastState.compose env27480 (packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound27480 : packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29822,49509,10589,1024,32769,58397,340,16,374,8193,65,23669,5393,45405,10281,61704,62729,256,21793,46092,41512]

theorem envBound27481 : H12AffineFastState.Bounded env27481 := by
  intro p hp
  have h : env27481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27480_27481 : H12AffineEnvironment.transform 15 29822 env27480 = env27481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env27480 == env27481) = true)

theorem identity27481 : scanCanonicalize (H12AffineFastState.compose env27481 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound27481 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,343,46156,10589,1024,32769,37172,340,16,374,8193,65,10588,5393,45405,10281,33825,32800,256,8200,46092,41512]

theorem envBound27482 : H12AffineFastState.Bounded env27482 := by
  intro p hp
  have h : env27482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27481_27482 : H12AffineEnvironment.transform 13 13609 env27481 = env27482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env27481 == env27482) = true)

theorem identity27482 : scanCanonicalize (H12AffineFastState.compose env27482 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound27482 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8233,343,5221,10589,1024,8232,12573,340,16,374,8193,65,10588,5393,4468,10281,9224,8201,256,8200,5157,513]

theorem envBound27483 : H12AffineFastState.Bounded env27483 := by
  intro p hp
  have h : env27483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27482_27483 : H12AffineEnvironment.transform 14 8233 env27482 = env27483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env27482 == env27483) = true)

theorem identity27483 : scanCanonicalize (H12AffineFastState.compose env27483 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27483 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27484 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12344,8233,343,4468,10589,273,8232,12573,340,16,374,8193,65,10588,4096,4468,10281,8473,8201,256,8200,4404,513]

theorem envBound27484 : H12AffineFastState.Bounded env27484 := by
  intro p hp
  have h : env27484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27483_27484 : H12AffineEnvironment.transform 9 273 env27483 = env27484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27483 == env27484) = true)

theorem identity27484 : scanCanonicalize (H12AffineFastState.compose env27484 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27484 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27485 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12344,8233,262,4389,10508,273,8232,12573,261,16,295,8193,16,10509,4096,4389,10281,8473,8201,256,8200,4404,513]

theorem envBound27485 : H12AffineFastState.Bounded env27485 := by
  intro p hp
  have h : env27485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27484_27485 : H12AffineEnvironment.transform 5 17 env27484 = env27485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27484 == env27485) = true)

theorem identity27485 : scanCanonicalize (H12AffineFastState.compose env27485 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27485 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27486 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,8192,12344,8233,35,4096,10281,52,8232,12344,32,16,2,8193,16,10280,4096,4096,10281,8252,8201,37,8200,4113,513]

theorem envBound27486 : H12AffineFastState.Bounded env27486 := by
  intro p hp
  have h : env27486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27485_27486 : H12AffineEnvironment.transform 7 37 env27485 = env27486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27485 == env27486) = true)

theorem identity27486 : scanCanonicalize (H12AffineFastState.compose env27486 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound27486 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27487 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,8192,8232,8233,35,16,10281,52,8232,8232,32,16,2,8193,16,10280,16,16,10281,8252,8201,37,8200,1,513]

theorem envBound27487 : H12AffineFastState.Bounded env27487 := by
  intro p hp
  have h : env27487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27486_27487 : H12AffineEnvironment.transform 11 16 env27486 = env27487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27486 == env27487) = true)

theorem identity27487 : scanCanonicalize (H12AffineFastState.compose env27487 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound27487 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env27488 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,2617,2577,2576,35,16,528,52,2577,2577,32,16,2,2616,16,529,16,16,528,2565,2608,37,2609,1,513]

theorem envBound27488 : H12AffineFastState.Bounded env27488 := by
  intro p hp
  have h : env27488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27487_27488 : H12AffineEnvironment.transform 12 2617 env27487 = env27488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env27487 == env27488) = true)

theorem identity27488 : scanCanonicalize (H12AffineFastState.compose env27488 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27488 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env27489 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,16,2585,2577,2576,3,16,528,20,2577,2577,0,16,2,2584,16,529,16,16,528,2565,2576,5,2577,1,513]

theorem envBound27489 : H12AffineFastState.Bounded env27489 := by
  intro p hp
  have h : env27489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27488_27489 : H12AffineEnvironment.transform 4 0 env27488 = env27489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27488 == env27489) = true)

theorem identity27489 : scanCanonicalize (H12AffineFastState.compose env27489 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27490 : List Nat := [2,4,8,16,0,17,9,5,512,20,0,16,537,529,528,3,16,528,20,529,529,0,16,2,536,16,529,16,16,528,517,528,5,529,1,513]

theorem envBound27490 : H12AffineFastState.Bounded env27490 := by
  intro p hp
  have h : env27490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27489_27490 : H12AffineEnvironment.transform 10 0 env27489 = env27490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27489 == env27490) = true)

theorem identity27490 : scanCanonicalize (H12AffineFastState.compose env27490 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound27490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27491 : List Nat := [2,4,8,16,0,17,9,5,17,20,0,16,8,0,1,3,16,1,20,0,0,0,16,2,9,16,0,16,16,1,20,1,5,0,1,16]

theorem envBound27491 : H12AffineFastState.Bounded env27491 := by
  intro p hp
  have h : env27491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27490_27491 : H12AffineEnvironment.transform 8 17 env27490 = env27491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env27490 == env27491) = true)

theorem identity27491 : scanCanonicalize (H12AffineFastState.compose env27491 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27492 : List Nat := [2,4,8,0,0,1,9,5,1,4,0,0,8,0,1,3,0,1,4,0,0,0,0,2,9,0,0,0,0,1,4,1,5,0,1,0]

theorem envBound27492 : H12AffineFastState.Bounded env27492 := by
  intro p hp
  have h : env27492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27491_27492 : H12AffineEnvironment.transform 3 0 env27491 = env27492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27491 == env27492) = true)

def env27493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452648,95496,8328,65,292256,458025,45524,10281,399664,144612,256,21793,46213,474855]

theorem envBound27493 : H12AffineFastState.Bounded env27493 := by
  intro p hp
  have h : env27493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27462_27493 : H12AffineEnvironment.transform 21 272513 env27462 = env27493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27462 == env27493) = true)

def env27494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272393,452648,95496,8192,65,292136,458025,45404,10281,399664,144492,256,21793,46093,474735]

theorem envBound27494 : H12AffineFastState.Bounded env27494 := by
  intro p hp
  have h : env27494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27493_27494 : H12AffineEnvironment.transform 6 8 env27493 = env27494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27493 == env27494) = true)

def env27495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272393,272440,95496,8192,65,292136,277817,45404,10281,317728,62588,256,21793,46093,392831]

theorem envBound27495 : H12AffineFastState.Bounded env27495 := by
  intro p hp
  have h : env27495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27494_27495 : H12AffineEnvironment.transform 16 49168 env27494 = env27495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27494 == env27495) = true)

theorem identity27495 : scanCanonicalize (H12AffineFastState.compose env27495 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound27495 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130174,1024,32769,77898,119927,119878,95496,8192,65,100694,115015,45404,10281,75102,62588,256,21793,46093,513]

theorem envBound27496 : H12AffineFastState.Bounded env27496 := by
  intro p hp
  have h : env27496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27495_27496 : H12AffineEnvironment.transform 17 130174 env27495 = env27496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env27495 == env27496) = true)

theorem identity27496 : scanCanonicalize (H12AffineFastState.compose env27496 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound27496 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10280,1024,32769,58396,33,16,41310,8192,65,23808,5393,45404,10281,61704,62588,256,21793,46093,513]

theorem envBound27497 : H12AffineFastState.Bounded env27497 := by
  intro p hp
  have h : env27497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27496_27497 : H12AffineEnvironment.transform 15 54358 env27496 = env27497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env27496 == env27497) = true)

theorem identity27497 : scanCanonicalize (H12AffineFastState.compose env27497 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound27497 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,262,5440,10280,1024,21841,12620,33,16,29710,8192,65,23808,5393,25612,10281,9304,8492,256,21793,24925,513]

theorem envBound27498 : H12AffineFastState.Bounded env27498 := by
  intro p hp
  have h : env27498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27497_27498 : H12AffineEnvironment.transform 14 21840 env27497 = env27498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env27497 == env27498) = true)

theorem identity27498 : scanCanonicalize (H12AffineFastState.compose env27498 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27498 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8461,262,5440,10280,1024,8460,12620,33,16,83,8192,65,10589,5393,4177,10281,9304,8492,256,8572,5376,513]

theorem envBound27499 : H12AffineFastState.Bounded env27499 := by
  intro p hp
  have h : env27499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27498_27499 : H12AffineEnvironment.transform 13 13405 env27498 = env27499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27498 == env27499) = true)

theorem identity27499 : scanCanonicalize (H12AffineFastState.compose env27499 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27499 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,262,5440,2420,1024,80,4112,33,16,83,348,65,2049,5393,4177,2421,1284,112,256,32,5376,513]

theorem envBound27500 : H12AffineFastState.Bounded env27500 := by
  intro p hp
  have h : env27500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27499_27500 : H12AffineEnvironment.transform 12 348 env27499 = env27500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27499 == env27500) = true)

theorem identity27500 : scanCanonicalize (H12AffineFastState.compose env27500 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1361) := by decide +kernel

theorem selectedBound27500 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env27501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1361,4096,348,5377,81,262,5440,1061,1024,80,4112,33,16,83,348,65,1360,5393,4177,1060,1284,112,256,32,5376,513]

theorem envBound27501 : H12AffineFastState.Bounded env27501 := by
  intro p hp
  have h : env27501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27500_27501 : H12AffineEnvironment.transform 10 1361 env27500 = env27501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1361 env27500 == env27501) = true)

theorem identity27501 : scanCanonicalize (H12AffineFastState.compose env27501 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound27501 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env27502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1361,1,348,1280,81,262,1345,1061,1024,80,17,33,16,83,348,65,1360,1296,80,1060,1284,112,256,32,1281,513]

theorem envBound27502 : H12AffineFastState.Bounded env27502 := by
  intro p hp
  have h : env27502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27501_27502 : H12AffineEnvironment.transform 11 1 env27501 = env27502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27501 == env27502) = true)

theorem identity27502 : scanCanonicalize (H12AffineFastState.compose env27502 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27502 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env27503 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1280,1,269,1280,0,262,1296,1061,1024,1,17,33,16,2,269,16,1281,1296,1,1060,1284,33,256,32,1281,513]

theorem envBound27503 : H12AffineFastState.Bounded env27503 := by
  intro p hp
  have h : env27503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27502_27503 : H12AffineEnvironment.transform 5 17 env27502 = env27503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27502 == env27503) = true)

theorem identity27503 : scanCanonicalize (H12AffineFastState.compose env27503 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27504 : List Nat := [2,4,8,16,32,17,8,256,512,52,308,1,269,308,0,262,292,17,52,1,17,33,16,2,269,16,309,292,1,16,304,33,256,32,309,513]

theorem envBound27504 : H12AffineFastState.Bounded env27504 := by
  intro p hp
  have h : env27504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27503_27504 : H12AffineEnvironment.transform 9 52 env27503 = env27504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27503 == env27504) = true)

theorem identity27504 : scanCanonicalize (H12AffineFastState.compose env27504 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27505 : List Nat := [2,4,8,16,32,17,8,256,1,52,308,1,269,308,0,262,292,17,52,1,17,33,16,2,269,16,309,292,1,16,304,33,256,32,309,0]

theorem envBound27505 : H12AffineFastState.Bounded env27505 := by
  intro p hp
  have h : env27505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27504_27505 : H12AffineEnvironment.transform 8 1 env27504 = env27505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27504 == env27505) = true)

def env27506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272393,272441,95496,8192,65,292136,277816,45404,10281,317729,62589,256,21793,46093,392830]

theorem envBound27506 : H12AffineFastState.Bounded env27506 := by
  intro p hp
  have h : env27506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27494_27506 : H12AffineEnvironment.transform 16 49169 env27494 = env27506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27494 == env27506) = true)

theorem identity27506 : scanCanonicalize (H12AffineFastState.compose env27506 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27506 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1024,32769,314421,272393,272441,41311,8192,65,292136,277816,45404,10281,317729,62589,256,21793,46093,272937]

theorem envBound27507 : H12AffineFastState.Bounded env27507 := by
  intro p hp
  have h : env27507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27506_27507 : H12AffineEnvironment.transform 15 54359 env27506 = env27507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27506 == env27507) = true)

theorem identity27507 : scanCanonicalize (H12AffineFastState.compose env27507 (packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27507 : packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,41051,46109,262144,1024,32769,309305,272393,272441,41311,8192,65,262436,277816,45404,10281,306477,32881,256,8493,46093,272937]

theorem envBound27508 : H12AffineFastState.Bounded env27508 := by
  intro p hp
  have h : env27508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27507_27508 : H12AffineEnvironment.transform 13 13324 env27507 = env27508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27507 == env27508) = true)

theorem identity27508 : scanCanonicalize (H12AffineFastState.compose env27508 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound27508 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,41051,46109,43048,1024,32769,4113,32801,32785,41311,8192,65,43276,38160,45404,10281,1285,32881,256,8493,46093,33281]

theorem envBound27509 : H12AffineFastState.Bounded env27509 := by
  intro p hp
  have h : env27509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27508_27509 : H12AffineEnvironment.transform 17 43048 env27508 = env27509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env27508 == env27509) = true)

theorem identity27509 : scanCanonicalize (H12AffineFastState.compose env27509 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27509 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27510 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,40970,46109,43048,1024,32769,4113,32801,32785,41230,8192,16,43276,38160,45325,10281,1285,32800,256,8493,46093,33281]

theorem envBound27510 : H12AffineFastState.Bounded env27510 := by
  intro p hp
  have h : env27510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27509_27510 : H12AffineEnvironment.transform 5 17 env27509 = env27510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27509 == env27510) = true)

theorem identity27510 : scanCanonicalize (H12AffineFastState.compose env27510 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27510 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27511 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8460,262,5393,2340,1024,8461,4113,8493,8477,2,8192,16,2048,13340,4097,10281,1285,8492,256,8493,5377,8973]

theorem envBound27511 : H12AffineFastState.Bounded env27511 := by
  intro p hp
  have h : env27511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27510_27511 : H12AffineEnvironment.transform 14 8460 env27510 = env27511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27510 == env27511) = true)

theorem identity27511 : scanCanonicalize (H12AffineFastState.compose env27511 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27511 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27512 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,8192,12344,8460,262,4389,2340,52,8461,4113,8493,8477,2,8192,16,2048,12328,4097,10281,305,8492,256,8493,4405,8973]

theorem envBound27512 : H12AffineFastState.Bounded env27512 := by
  intro p hp
  have h : env27512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27511_27512 : H12AffineEnvironment.transform 9 52 env27511 = env27512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27511 == env27512) = true)

theorem identity27512 : scanCanonicalize (H12AffineFastState.compose env27512 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27512 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27513 : List Nat := [2,4,8,16,0,17,8,256,512,20,2048,4096,8192,12312,8460,262,4357,2308,20,8461,4113,8461,8477,2,8192,16,2048,12296,4097,10249,273,8460,256,8461,4373,8973]

theorem envBound27513 : H12AffineFastState.Bounded env27513 := by
  intro p hp
  have h : env27513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27512_27513 : H12AffineEnvironment.transform 4 0 env27512 = env27513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27512 == env27513) = true)

theorem identity27513 : scanCanonicalize (H12AffineFastState.compose env27513 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27513 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27514 : List Nat := [2,4,8,16,0,17,8,256,512,20,2048,4096,269,4373,1,262,4357,2308,20,0,4113,0,16,2,269,16,2048,4357,4097,2308,273,1,256,0,4373,512]

theorem envBound27514 : H12AffineFastState.Bounded env27514 := by
  intro p hp
  have h : env27514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27513_27514 : H12AffineEnvironment.transform 12 269 env27513 = env27514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27513 == env27514) = true)

theorem identity27514 : scanCanonicalize (H12AffineFastState.compose env27514 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound27514 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27515 : List Nat := [2,4,8,16,0,17,8,256,512,20,783,4096,269,4373,1,262,4357,523,20,0,4113,0,16,2,269,16,783,4357,4097,523,273,1,256,0,4373,512]

theorem envBound27515 : H12AffineFastState.Bounded env27515 := by
  intro p hp
  have h : env27515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27514_27515 : H12AffineEnvironment.transform 10 783 env27514 = env27515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env27514 == env27515) = true)

theorem identity27515 : scanCanonicalize (H12AffineFastState.compose env27515 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound27515 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27516 : List Nat := [2,4,8,16,0,17,8,256,512,20,783,539,269,782,1,262,798,523,20,0,522,0,16,2,269,16,783,798,538,523,273,1,256,0,782,512]

theorem envBound27516 : H12AffineFastState.Bounded env27516 := by
  intro p hp
  have h : env27516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27515_27516 : H12AffineEnvironment.transform 11 539 env27515 = env27516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env27515 == env27516) = true)

theorem identity27516 : scanCanonicalize (H12AffineFastState.compose env27516 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27516 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27517 : List Nat := [2,4,8,16,0,17,8,4,512,20,523,539,9,522,1,2,538,523,20,0,522,0,16,2,9,16,523,538,538,523,21,1,4,0,522,512]

theorem envBound27517 : H12AffineFastState.Bounded env27517 := by
  intro p hp
  have h : env27517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27516_27517 : H12AffineEnvironment.transform 7 4 env27516 = env27517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27516 == env27517) = true)

theorem identity27517 : scanCanonicalize (H12AffineFastState.compose env27517 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound27517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27518 : List Nat := [2,4,8,16,0,17,8,4,14,20,5,21,9,4,1,2,20,5,20,0,4,0,16,2,9,16,5,20,20,5,21,1,4,0,4,14]

theorem envBound27518 : H12AffineFastState.Bounded env27518 := by
  intro p hp
  have h : env27518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27517_27518 : H12AffineEnvironment.transform 8 14 env27517 = env27518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env27517 == env27518) = true)

theorem identity27518 : scanCanonicalize (H12AffineFastState.compose env27518 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27519 : List Nat := [0,4,8,16,0,17,8,4,12,20,5,21,9,4,1,0,20,5,20,0,4,0,16,0,9,16,5,20,20,5,21,1,4,0,4,12]

theorem envBound27519 : H12AffineFastState.Bounded env27519 := by
  intro p hp
  have h : env27519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27518_27519 : H12AffineEnvironment.transform 0 0 env27518 = env27519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27518 == env27519) = true)

def env27520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272392,452648,95496,8193,65,292137,458025,45405,10281,399664,144493,256,21793,46092,474734]

theorem envBound27520 : H12AffineFastState.Bounded env27520 := by
  intro p hp
  have h : env27520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27493_27520 : H12AffineEnvironment.transform 6 9 env27493 = env27520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27493 == env27520) = true)

def env27521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272392,272440,95496,8193,65,292137,277817,45405,10281,317728,62589,256,21793,46092,392830]

theorem envBound27521 : H12AffineFastState.Bounded env27521 := by
  intro p hp
  have h : env27521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27520_27521 : H12AffineEnvironment.transform 16 49168 env27520 = env27521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27520 == env27521) = true)

theorem identity27521 : scanCanonicalize (H12AffineFastState.compose env27521 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound27521 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,49168,262144,1024,32769,314421,272392,272440,3,8193,65,292137,277817,45405,10281,317728,62589,256,21793,46092,297845]

theorem envBound27522 : H12AffineFastState.Bounded env27522 := by
  intro p hp
  have h : env27522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27521_27522 : H12AffineEnvironment.transform 15 29963 env27521 = env27522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env27521 == env27522) = true)

theorem identity27522 : scanCanonicalize (H12AffineFastState.compose env27522 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound27522 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8312,29963,24680,262144,1024,8313,289869,272392,272440,3,8193,65,292137,277817,4389,10281,293208,21509,256,21793,5236,273165]

theorem envBound27523 : H12AffineFastState.Bounded env27523 := by
  intro p hp
  have h : env27523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27522_27523 : H12AffineEnvironment.transform 14 8312 env27522 = env27523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env27522 == env27523) = true)

theorem identity27523 : scanCanonicalize (H12AffineFastState.compose env27523 (packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27523 : packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS < 2^1333 := by decide +kernel

def env27524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,373,21510,16741,262144,1024,372,281920,264453,264501,3,268,65,283684,269364,4389,2340,284757,21509,256,21793,5236,264704]

theorem envBound27524 : H12AffineFastState.Bounded env27524 := by
  intro p hp
  have h : env27524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27523_27524 : H12AffineEnvironment.transform 12 269 env27523 = env27524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27523 == env27524) = true)

theorem identity27524 : scanCanonicalize (H12AffineFastState.compose env27524 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound27524 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env27525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,373,21510,16741,23589,1024,372,4453,21792,21776,3,268,65,2049,16401,4389,2340,1136,21509,256,21793,5236,22053]

theorem envBound27525 : H12AffineFastState.Bounded env27525 := by
  intro p hp
  have h : env27525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27524_27525 : H12AffineEnvironment.transform 17 23589 env27524 = env27525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env27524 == env27525) = true)

theorem identity27525 : scanCanonicalize (H12AffineFastState.compose env27525 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27525 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env27526 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,80,21510,16448,23589,1024,81,4160,21509,21557,3,41,65,2049,16401,4096,2049,1136,21509,37,21508,5236,22053]

theorem envBound27526 : H12AffineFastState.Bounded env27526 := by
  intro p hp
  have h : env27526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27525_27526 : H12AffineEnvironment.transform 7 37 env27525 = env27526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27525 == env27526) = true)

theorem identity27526 : scanCanonicalize (H12AffineFastState.compose env27526 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound27526 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env27527 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,80,35,5221,2048,1024,81,4160,32,16,3,41,65,2049,5172,4096,2049,1136,32,37,33,5236,512]

theorem envBound27527 : H12AffineFastState.Bounded env27527 := by
  intro p hp
  have h : env27527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27526_27527 : H12AffineEnvironment.transform 13 5157 env27526 = env27527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env27526 == env27527) = true)

theorem identity27527 : scanCanonicalize (H12AffineFastState.compose env27527 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27527 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27528 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5157,32,35,5141,2048,1024,33,4144,32,16,3,41,49,2049,5172,4096,2049,1024,32,37,33,5124,512]

theorem envBound27528 : H12AffineFastState.Bounded env27528 := by
  intro p hp
  have h : env27528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27527_27528 : H12AffineEnvironment.transform 5 48 env27527 = env27528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27527 == env27528) = true)

def env27529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272392,272441,95496,8193,65,292137,277816,45405,10281,317729,62588,256,21793,46092,392831]

theorem envBound27529 : H12AffineFastState.Bounded env27529 := by
  intro p hp
  have h : env27529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27520_27529 : H12AffineEnvironment.transform 16 49169 env27520 = env27529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27520 == env27529) = true)

theorem identity27529 : scanCanonicalize (H12AffineFastState.compose env27529 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound27529 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89379,1024,32769,102679,95531,95514,95496,8193,65,75786,90139,45405,10281,99330,62588,256,21793,46092,41820]

theorem envBound27530 : H12AffineFastState.Bounded env27530 := by
  intro p hp
  have h : env27530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27529_27530 : H12AffineEnvironment.transform 17 89379 env27529 = env27530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env27529 == env27530) = true)

theorem identity27530 : scanCanonicalize (H12AffineFastState.compose env27530 (packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound27530 : packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32803,49169,56576,1024,32769,4404,62728,62777,62763,8193,65,43049,57400,45405,10281,1057,62588,256,21793,46092,41820]

theorem envBound27531 : H12AffineFastState.Bounded env27531 := by
  intro p hp
  have h : env27531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27530_27531 : H12AffineEnvironment.transform 15 32803 env27530 = env27531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env27530 == env27531) = true)

theorem identity27531 : scanCanonicalize (H12AffineFastState.compose env27531 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27531 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,32803,46109,43276,1024,32769,4404,33028,33077,33063,8193,65,43049,37940,45405,10281,1057,32880,256,8493,46092,41820]

theorem envBound27532 : H12AffineFastState.Bounded env27532 := by
  intro p hp
  have h : env27532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27531_27532 : H12AffineEnvironment.transform 13 13324 env27531 = env27532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27531 == env27532) = true)

theorem identity27532 : scanCanonicalize (H12AffineFastState.compose env27532 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27532 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env27533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,35,13341,10508,1024,1,4404,260,309,295,8193,65,10281,5172,12637,10281,1057,112,256,8493,13324,9052]

theorem envBound27533 : H12AffineFastState.Bounded env27533 := by
  intro p hp
  have h : env27533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27532_27533 : H12AffineEnvironment.transform 14 0 env27532 = env27533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27532 == env27533) = true)

theorem identity27533 : scanCanonicalize (H12AffineFastState.compose env27533 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27533 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env27534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5156,0,35,5173,2340,1024,1,4404,260,309,295,41,65,2049,5172,4469,2049,1057,112,256,261,5156,884]

theorem envBound27534 : H12AffineFastState.Bounded env27534 := by
  intro p hp
  have h : env27534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27533_27534 : H12AffineEnvironment.transform 12 40 env27533 = env27534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27533 == env27534) = true)

theorem identity27534 : scanCanonicalize (H12AffineFastState.compose env27534 (packedSelected [0,3,4,5,6,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27534 : packedSelected [0,3,4,5,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27535 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,40,5156,0,35,5173,2340,1024,1,4404,260,309,295,41,49,2049,5172,4357,2049,1057,0,256,261,5156,772]

theorem envBound27535 : H12AffineFastState.Bounded env27535 := by
  intro p hp
  have h : env27535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27534_27535 : H12AffineEnvironment.transform 5 48 env27534 = env27535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27534 == env27535) = true)

theorem identity27535 : scanCanonicalize (H12AffineFastState.compose env27535 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27535 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27536 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4113,33,16,2,41,49,2049,5172,4128,2049,1057,0,37,32,5156,545]

theorem envBound27536 : H12AffineFastState.Bounded env27536 := by
  intro p hp
  have h : env27536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27535_27536 : H12AffineEnvironment.transform 7 37 env27535 = env27536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27535 == env27536) = true)

def env27537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452649,95497,8328,65,4218145,458024,45525,10280,399664,4594788,256,21793,46213,474855]

theorem envBound27537 : H12AffineFastState.Bounded env27537 := by
  intro p hp
  have h : env27537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27461_27537 : H12AffineEnvironment.transform 22 452649 env27461 = env27537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env27461 == env27537) = true)

def env27538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452649,95497,8328,65,292257,458024,45525,10280,399664,144612,256,21793,46213,474855]

theorem envBound27538 : H12AffineFastState.Bounded env27538 := by
  intro p hp
  have h : env27538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27537_27538 : H12AffineEnvironment.transform 21 272512 env27537 = env27538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27537 == env27538) = true)

theorem identity27538 : scanCanonicalize (H12AffineFastState.compose env27538 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound27538 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4160,144492,62661,95497,8328,65,158029,57796,45525,10280,1500,144612,256,21793,46213,74251]

theorem envBound27539 : H12AffineFastState.Bounded env27539 := by
  intro p hp
  have h : env27539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27538_27539 : H12AffineEnvironment.transform 17 138476 env27538 = env27539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env27538 == env27539) = true)

theorem identity27539 : scanCanonicalize (H12AffineFastState.compose env27539 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27539 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138476,1024,32769,4160,144492,62661,21763,8328,65,158029,57796,45525,10280,1500,144612,256,21793,46213,513]

theorem envBound27540 : H12AffineFastState.Bounded env27540 := by
  intro p hp
  have h : env27540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27539_27540 : H12AffineEnvironment.transform 15 8202 env27539 = env27540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27539 == env27540) = true)

theorem identity27540 : scanCanonicalize (H12AffineFastState.compose env27540 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound27540 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env27541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,2421,1024,32769,4160,8693,62661,21763,8328,65,31956,57796,45525,10280,1500,8573,256,21793,46213,513]

theorem envBound27541 : H12AffineFastState.Bounded env27541 := by
  intro p hp
  have h : env27541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27540_27541 : H12AffineEnvironment.transform 16 5529 env27540 = env27541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env27540 == env27541) = true)

theorem identity27541 : scanCanonicalize (H12AffineFastState.compose env27541 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound27541 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env27542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8202,5529,2421,1024,21760,4160,8693,8644,21763,8328,65,31956,13509,25812,10280,1500,8573,256,21793,24964,513]

theorem envBound27542 : H12AffineFastState.Bounded env27542 := by
  intro p hp
  have h : env27542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27541_27542 : H12AffineEnvironment.transform 14 21761 env27541 = env27542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env27541 == env27542) = true)

theorem identity27542 : scanCanonicalize (H12AffineFastState.compose env27542 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27542 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,137,8202,5529,2421,1024,136,4160,8693,8644,139,8328,65,10588,13509,12636,10280,1500,8573,256,169,13324,513]

theorem envBound27543 : H12AffineFastState.Bounded env27543 := by
  intro p hp
  have h : env27543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27542_27543 : H12AffineEnvironment.transform 13 5512 env27542 = env27543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27542 == env27543) = true)

def env27544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452649,95497,8328,65,292256,458024,45525,10280,399664,144613,256,21793,46213,474855]

theorem envBound27544 : H12AffineFastState.Bounded env27544 := by
  intro p hp
  have h : env27544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27537_27544 : H12AffineEnvironment.transform 21 272513 env27537 = env27544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27537 == env27544) = true)

theorem identity27544 : scanCanonicalize (H12AffineFastState.compose env27544 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound27544 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396460,272513,400636,95497,8328,65,292256,395773,17664,10280,399664,144613,256,21793,16464,474855]

theorem envBound27545 : H12AffineFastState.Bounded env27545 := by
  intro p hp
  have h : env27545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27544_27545 : H12AffineEnvironment.transform 14 29909 env27544 = env27545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env27544 == env27545) = true)

def env27546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140300,33,144476,95497,8328,65,23808,139613,17664,10280,143760,144613,256,21793,16464,202311]

theorem envBound27546 : H12AffineFastState.Bounded env27546 := by
  intro p hp
  have h : env27546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27545_27546 : H12AffineEnvironment.transform 17 10400 env27545 = env27546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27545 == env27546) = true)

theorem identity27546 : scanCanonicalize (H12AffineFastState.compose env27546 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound27546 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env27547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,5528,10400,1024,29908,12692,33,8644,95497,8328,65,23808,13509,17664,10280,9224,8573,256,21793,16464,66527]

theorem envBound27547 : H12AffineFastState.Bounded env27547 := by
  intro p hp
  have h : env27547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27546_27547 : H12AffineEnvironment.transform 16 5528 env27546 = env27547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env27546 == env27547) = true)

theorem identity27547 : scanCanonicalize (H12AffineFastState.compose env27547 (packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound27547 : packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,65536,5528,2421,1024,21761,4161,33,17,87260,349,65,23808,5392,17664,2557,1501,168,256,21793,16464,66527]

theorem envBound27548 : H12AffineFastState.Bounded env27548 := by
  intro p hp
  have h : env27548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27547_27548 : H12AffineEnvironment.transform 12 469 env27547 = env27548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env27547 == env27548) = true)

theorem identity27548 : scanCanonicalize (H12AffineFastState.compose env27548 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27548 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env27549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,65536,5528,2421,1024,137,4161,33,17,65876,349,65,2184,5392,4232,2557,1501,168,256,169,5592,66527]

theorem envBound27549 : H12AffineFastState.Bounded env27549 := by
  intro p hp
  have h : env27549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27548_27549 : H12AffineEnvironment.transform 13 5512 env27548 = env27549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27548 == env27549) = true)

theorem identity27549 : scanCanonicalize (H12AffineFastState.compose env27549 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound27549 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,478,5528,2421,1024,137,4161,33,17,138,349,65,2184,5392,4232,2557,1501,168,256,169,5592,513]

theorem envBound27550 : H12AffineFastState.Bounded env27550 := by
  intro p hp
  have h : env27550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27549_27550 : H12AffineEnvironment.transform 15 478 env27549 = env27550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env27549 == env27550) = true)

def env27551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140301,32,144477,95497,8328,65,23809,139612,17664,10280,143761,144613,256,21793,16464,202310]

theorem envBound27551 : H12AffineFastState.Bounded env27551 := by
  intro p hp
  have h : env27551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27545_27551 : H12AffineEnvironment.transform 17 10401 env27545 = env27551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27545 == env27551) = true)

theorem identity27551 : scanCanonicalize (H12AffineFastState.compose env27551 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27551 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env27552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,131072,10401,1024,136,140301,32,144477,65877,8328,65,10589,139612,12636,10280,143761,144613,256,8573,13324,202310]

theorem envBound27552 : H12AffineFastState.Bounded env27552 := by
  intro p hp
  have h : env27552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27551_27552 : H12AffineEnvironment.transform 13 13404 env27551 = env27552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27551 == env27552) = true)

theorem identity27552 : scanCanonicalize (H12AffineFastState.compose env27552 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound27552 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env27553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,70727,10401,1024,136,77898,32,73754,65877,8328,65,10589,79131,12636,10280,75222,73890,256,8573,13324,513]

theorem envBound27553 : H12AffineFastState.Bounded env27553 := by
  intro p hp
  have h : env27553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27552_27553 : H12AffineEnvironment.transform 16 70727 env27552 = env27553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env27552 == env27553) = true)

theorem identity27553 : scanCanonicalize (H12AffineFastState.compose env27553 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27553 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,65536,70727,10280,1024,1,77898,32,73754,65877,8193,65,10589,79131,12636,10280,75103,73771,256,8573,13324,513]

theorem envBound27554 : H12AffineFastState.Bounded env27554 := by
  intro p hp
  have h : env27554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27553_27554 : H12AffineEnvironment.transform 6 9 env27553 = env27554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27553 == env27554) = true)

theorem identity27554 : scanCanonicalize (H12AffineFastState.compose env27554 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27554 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27555 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,0,65536,69975,10280,272,1,77898,32,73754,65877,8193,65,10589,77835,12636,10280,73807,73771,256,8573,12572,513]

theorem envBound27555 : H12AffineFastState.Bounded env27555 := by
  intro p hp
  have h : env27555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27554_27555 : H12AffineEnvironment.transform 9 272 env27554 = env27555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27554 == env27555) = true)

theorem identity27555 : scanCanonicalize (H12AffineFastState.compose env27555 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound27555 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27556 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,8192,10588,0,65536,67911,10280,272,1,75866,32,73754,65877,8193,65,10589,75803,10572,10280,73807,73771,256,8573,10508,513]

theorem envBound27556 : H12AffineFastState.Bounded env27556 := by
  intro p hp
  have h : env27556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27555_27556 : H12AffineEnvironment.transform 11 2064 env27555 = env27556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env27555 == env27556) = true)

theorem identity27556 : scanCanonicalize (H12AffineFastState.compose env27556 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27556 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27557 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,8192,10588,0,342,2065,10280,272,1,10508,32,8524,3,8193,65,10589,10573,10572,10280,8473,8573,256,8573,10508,513]

theorem envBound27557 : H12AffineFastState.Bounded env27557 := by
  intro p hp
  have h : env27557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27556_27557 : H12AffineEnvironment.transform 15 342 env27556 = env27557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27556 == env27557) = true)

def env27558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,8887585,8328,65,4218144,8393984,8804860,8830977,399665,12645452,256,21792,46212,474854]

theorem envBound27558 : H12AffineFastState.Bounded env27558 := by
  intro p hp
  have h : env27558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27460_27558 : H12AffineEnvironment.transform 23 8887585 env27460 = env27558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887585 env27460 == env27558) = true)

def env27559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452648,95497,8328,65,4218144,458024,45524,10281,399665,4594788,256,21792,46212,474854]

theorem envBound27559 : H12AffineFastState.Bounded env27559 := by
  intro p hp
  have h : env27559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27558_27559 : H12AffineEnvironment.transform 22 452648 env27558 = env27559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env27558 == env27559) = true)

def env27560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452648,95497,8328,65,292256,458024,45524,10281,399665,144612,256,21792,46212,474854]

theorem envBound27560 : H12AffineFastState.Bounded env27560 := by
  intro p hp
  have h : env27560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27559_27560 : H12AffineEnvironment.transform 21 272512 env27559 = env27560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27559 == env27560) = true)

theorem identity27560 : scanCanonicalize (H12AffineFastState.compose env27560 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound27560 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,396460,272512,452648,41430,8328,65,292256,458024,45524,10281,399665,144612,256,21792,46212,453177]

theorem envBound27561 : H12AffineFastState.Bounded env27561 := by
  intro p hp
  have h : env27561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27560_27561 : H12AffineEnvironment.transform 15 54495 env27560 = env27561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env27560 == env27561) = true)

def env27562 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,396460,272512,452648,41350,8328,17,292256,458024,45444,10281,399665,144564,256,21792,46212,453177]

theorem envBound27562 : H12AffineFastState.Bounded env27562 := by
  intro p hp
  have h : env27562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27561_27562 : H12AffineEnvironment.transform 5 16 env27561 = env27562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27561 == env27562) = true)

theorem identity27562 : scanCanonicalize (H12AffineFastState.compose env27562 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound27562 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env27563 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,32041,1024,32769,160133,21929,169217,41350,8328,17,2185,163841,45444,10281,156696,144564,256,21792,46212,169744]

theorem envBound27563 : H12AffineFastState.Bounded env27563 := by
  intro p hp
  have h : env27563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27562_27563 : H12AffineEnvironment.transform 17 32041 env27562 = env27563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env27562 == env27563) = true)

theorem identity27563 : scanCanonicalize (H12AffineFastState.compose env27563 (packedSelected [0,9,10,17,18,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound27563 : packedSelected [0,9,10,17,18,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env27564 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46109,32041,1024,32769,50584,21929,8476,41350,8328,17,2185,13340,45444,10281,53253,32937,256,21792,46212,8973]

theorem envBound27564 : H12AffineFastState.Bounded env27564 := by
  intro p hp
  have h : env27564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27563_27564 : H12AffineEnvironment.transform 16 46109 env27563 = env27564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env27563 == env27564) = true)

theorem identity27564 : scanCanonicalize (H12AffineFastState.compose env27564 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27564 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env27565 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,54415,38296,23724,1024,32769,50584,21929,153,32771,269,17,2185,5529,36865,2476,53253,32937,256,21792,38145,648]

theorem envBound27565 : H12AffineFastState.Bounded env27565 := by
  intro p hp
  have h : env27565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27564_27565 : H12AffineEnvironment.transform 12 389 env27564 = env27565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27564 == env27565) = true)

theorem identity27565 : scanCanonicalize (H12AffineFastState.compose env27565 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound27565 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env27566 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4248,32768,33815,38296,3124,1024,32769,38144,1329,153,32771,269,17,2185,5529,36865,2476,32925,32937,256,1464,38145,648]

theorem envBound27566 : H12AffineFastState.Bounded env27566 := by
  intro p hp
  have h : env27566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27565_27566 : H12AffineEnvironment.transform 13 4248 env27565 = env27566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env27565 == env27566) = true)

theorem identity27566 : scanCanonicalize (H12AffineFastState.compose env27566 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27566 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env27567 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4248,0,1047,5528,3124,1024,1,5376,1329,153,3,269,17,2185,5529,4097,2476,157,169,256,1464,5377,648]

theorem envBound27567 : H12AffineFastState.Bounded env27567 := by
  intro p hp
  have h : env27567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27566_27567 : H12AffineEnvironment.transform 14 0 env27566 = env27567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27566 == env27567) = true)

theorem identity27567 : scanCanonicalize (H12AffineFastState.compose env27567 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27567 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27568 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,40,4248,0,1047,5173,3124,1024,1,5293,1180,153,3,160,17,2185,5172,4097,2049,157,169,173,1045,5292,648]

theorem envBound27568 : H12AffineFastState.Bounded env27568 := by
  intro p hp
  have h : env27568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27567_27568 : H12AffineEnvironment.transform 7 173 env27567 = env27568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27567 == env27568) = true)

theorem identity27568 : scanCanonicalize (H12AffineFastState.compose env27568 (packedSelected [1,2,3,4,5,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound27568 : packedSelected [1,2,3,4,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27569 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1029,40,1181,0,1047,48,3124,1024,1,168,1180,153,3,160,17,2185,49,1028,2049,157,169,173,1045,169,648]

theorem envBound27569 : H12AffineFastState.Bounded env27569 := by
  intro p hp
  have h : env27569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27568_27569 : H12AffineEnvironment.transform 11 1029 env27568 = env27569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env27568 == env27569) = true)

theorem identity27569 : scanCanonicalize (H12AffineFastState.compose env27569 (packedSelected [0,2,4,6,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27569 : packedSelected [0,2,4,6,7,10] rootPS < 2^1333 := by decide +kernel

def env27570 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,1029,9,1181,0,1047,17,3093,1024,1,137,1180,153,3,129,17,2185,16,1028,2049,157,136,140,1045,136,648]

theorem envBound27570 : H12AffineFastState.Bounded env27570 := by
  intro p hp
  have h : env27570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27569_27570 : H12AffineEnvironment.transform 4 1 env27569 = env27570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27569 == env27570) = true)

theorem identity27570 : scanCanonicalize (H12AffineFastState.compose env27570 (packedSelected [0,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound27570 : packedSelected [0,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27571 : List Nat := [2,4,8,16,1,16,128,140,512,156,2048,153,9,1,0,139,17,2185,156,1,137,0,153,3,129,17,2185,16,152,2049,157,136,140,137,136,648]

theorem envBound27571 : H12AffineFastState.Bounded env27571 := by
  intro p hp
  have h : env27571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27570_27571 : H12AffineEnvironment.transform 9 156 env27570 = env27571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env27570 == env27571) = true)

theorem identity27571 : scanCanonicalize (H12AffineFastState.compose env27571 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27572 : List Nat := [2,4,8,1,1,1,128,140,512,141,2048,136,9,1,0,139,0,2185,141,1,137,0,136,3,129,0,2185,1,137,2049,140,136,140,137,136,648]

theorem envBound27572 : H12AffineFastState.Bounded env27572 := by
  intro p hp
  have h : env27572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27571_27572 : H12AffineEnvironment.transform 3 1 env27571 = env27572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27571 == env27572) = true)

theorem identity27572 : scanCanonicalize (H12AffineFastState.compose env27572 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27573 : List Nat := [2,4,8,1,1,1,128,140,0,141,2048,136,9,1,0,139,0,2185,141,1,137,0,136,3,129,0,2185,1,137,2049,140,136,140,137,136,136]

theorem envBound27573 : H12AffineFastState.Bounded env27573 := by
  intro p hp
  have h : env27573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27572_27573 : H12AffineEnvironment.transform 8 0 env27572 = env27573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27572 == env27573) = true)

def env27574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,396460,272512,452648,41351,8328,16,292256,458024,45445,10281,399665,144565,256,21792,46212,453177]

theorem envBound27574 : H12AffineFastState.Bounded env27574 := by
  intro p hp
  have h : env27574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27561_27574 : H12AffineEnvironment.transform 5 17 env27561 = env27574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27561 == env27574) = true)

theorem identity27574 : scanCanonicalize (H12AffineFastState.compose env27574 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound27574 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env27575 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,262144,1024,32769,276657,272512,318517,41351,8328,16,292256,313653,45445,10281,273708,168,256,21792,46212,319012]

theorem envBound27575 : H12AffineFastState.Bounded env27575 := by
  intro p hp
  have h : env27575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27574_27575 : H12AffineEnvironment.transform 16 13341 env27574 = env27575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env27574 == env27575) = true)

theorem identity27575 : scanCanonicalize (H12AffineFastState.compose env27575 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound27575 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env27576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,2476,1024,32769,12573,8492,54681,41351,8328,16,31756,49305,45445,10281,9344,168,256,21792,46212,55176]

theorem envBound27576 : H12AffineFastState.Bounded env27576 := by
  intro p hp
  have h : env27576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27575_27576 : H12AffineEnvironment.transform 17 2476 env27575 = env27576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env27575 == env27576) = true)

theorem identity27576 : scanCanonicalize (H12AffineFastState.compose env27576 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound27576 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env27577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21897,263,13341,2476,1024,21896,12573,8492,16,29710,8328,16,31756,5392,25612,10281,9344,168,256,21792,24845,513]

theorem envBound27577 : H12AffineFastState.Bounded env27577 := by
  intro p hp
  have h : env27577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27576_27577 : H12AffineEnvironment.transform 14 21897 env27576 = env27577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env27576 == env27577) = true)

theorem identity27577 : scanCanonicalize (H12AffineFastState.compose env27577 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27577 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env27578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,0,263,13341,2476,1024,1,12573,8492,16,8583,8328,16,10629,5392,12677,10281,9344,168,256,169,13444,513]

theorem envBound27578 : H12AffineFastState.Bounded env27578 := by
  intro p hp
  have h : env27578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27577_27578 : H12AffineEnvironment.transform 13 5513 env27577 = env27578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27577 == env27578) = true)

theorem identity27578 : scanCanonicalize (H12AffineFastState.compose env27578 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27578 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27579 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,13341,2341,1024,1,12573,8492,16,8462,8193,16,10508,5392,12556,10281,9225,33,256,32,13325,513]

theorem envBound27579 : H12AffineFastState.Bounded env27579 := by
  intro p hp
  have h : env27579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27578_27579 : H12AffineEnvironment.transform 6 9 env27578 = env27579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27578 == env27579) = true)

theorem identity27579 : scanCanonicalize (H12AffineFastState.compose env27579 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound27579 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27580 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2350,8192,3118,0,263,11571,2341,1024,1,10291,8492,16,8462,8193,16,10508,3134,10274,10281,9225,33,256,32,11555,513]

theorem envBound27580 : H12AffineFastState.Bounded env27580 := by
  intro p hp
  have h : env27580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27579_27580 : H12AffineEnvironment.transform 11 2350 env27579 = env27580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env27579 == env27580) = true)

theorem identity27580 : scanCanonicalize (H12AffineFastState.compose env27580 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound27580 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27581 : List Nat := [2,4,8,16,32,17,9,256,512,1024,271,33,8192,1313,0,263,9276,42,1024,1,8508,8492,16,8462,8193,16,8195,1329,8493,8486,9225,33,256,32,9260,513]

theorem envBound27581 : H12AffineFastState.Bounded env27581 := by
  intro p hp
  have h : env27581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27580_27581 : H12AffineEnvironment.transform 10 271 env27580 = env27581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env27580 == env27581) = true)

theorem identity27581 : scanCanonicalize (H12AffineFastState.compose env27581 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound27581 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27582 : List Nat := [2,4,8,16,32,17,9,256,512,1024,271,33,1085,1313,0,263,1,42,1024,1,1281,1297,16,1331,1084,16,1086,1329,1296,1307,52,33,256,32,17,513]

theorem envBound27582 : H12AffineFastState.Bounded env27582 := by
  intro p hp
  have h : env27582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27581_27582 : H12AffineEnvironment.transform 12 1085 env27581 = env27582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env27581 == env27582) = true)

theorem identity27582 : scanCanonicalize (H12AffineFastState.compose env27582 (packedSelected [0,1,5,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound27582 : packedSelected [0,1,5,9,11] rootPS < 2^1333 := by decide +kernel

def env27583 : List Nat := [2,4,8,16,32,17,9,63,512,1024,48,33,1085,1054,0,56,1,42,1024,1,1086,1070,16,1036,1084,16,1086,1038,1071,1060,52,33,63,32,17,513]

theorem envBound27583 : H12AffineFastState.Bounded env27583 := by
  intro p hp
  have h : env27583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27582_27583 : H12AffineEnvironment.transform 7 63 env27582 = env27583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env27582 == env27583) = true)

theorem identity27583 : scanCanonicalize (H12AffineFastState.compose env27583 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound27583 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env27584 : List Nat := [2,4,8,16,27,17,9,4,512,1024,11,26,1030,1054,0,3,1,17,1024,1,1029,1045,16,1036,1031,16,1029,1038,1044,1055,15,26,4,27,17,513]

theorem envBound27584 : H12AffineFastState.Bounded env27584 := by
  intro p hp
  have h : env27584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27583_27584 : H12AffineEnvironment.transform 4 27 env27583 = env27584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env27583 == env27584) = true)

theorem identity27584 : scanCanonicalize (H12AffineFastState.compose env27584 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound27584 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env27585 : List Nat := [2,4,8,12,7,13,9,4,512,1024,11,6,1030,1026,0,3,1,13,1024,1,1029,1033,12,1036,1031,12,1029,1038,1032,1027,15,6,4,7,13,513]

theorem envBound27585 : H12AffineFastState.Bounded env27585 := by
  intro p hp
  have h : env27585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27584_27585 : H12AffineEnvironment.transform 3 12 env27584 = env27585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env27584 == env27585) = true)

theorem identity27585 : scanCanonicalize (H12AffineFastState.compose env27585 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound27585 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27586 : List Nat := [2,4,8,12,7,13,9,4,512,15,11,6,9,13,0,3,1,13,15,1,10,6,12,3,8,12,10,1,7,12,15,6,4,7,13,513]

theorem envBound27586 : H12AffineFastState.Bounded env27586 := by
  intro p hp
  have h : env27586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27585_27586 : H12AffineEnvironment.transform 9 15 env27585 = env27586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env27585 == env27586) = true)

theorem identity27586 : scanCanonicalize (H12AffineFastState.compose env27586 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27586 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27587 : List Nat := [2,2,8,10,1,11,9,2,512,9,11,0,9,11,0,3,1,11,9,1,10,0,10,3,8,10,10,1,1,10,9,0,2,1,11,513]

theorem envBound27587 : H12AffineFastState.Bounded env27587 := by
  intro p hp
  have h : env27587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27586_27587 : H12AffineEnvironment.transform 1 2 env27586 = env27587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27586 == env27587) = true)

theorem identity27587 : scanCanonicalize (H12AffineFastState.compose env27587 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27588 : List Nat := [1,1,8,9,1,8,9,1,512,9,8,0,9,8,0,0,1,8,9,1,9,0,9,0,8,9,9,1,1,9,9,0,1,1,8,513]

theorem envBound27588 : H12AffineFastState.Bounded env27588 := by
  intro p hp
  have h : env27588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27587_27588 : H12AffineEnvironment.transform 0 1 env27587 = env27588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27587 == env27588) = true)

theorem identity27588 : scanCanonicalize (H12AffineFastState.compose env27588 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27589 : List Nat := [1,1,1,0,1,1,0,1,512,0,1,0,0,1,0,0,1,1,0,1,0,0,0,0,1,0,0,1,1,0,0,0,1,1,1,513]

theorem envBound27589 : H12AffineFastState.Bounded env27589 := by
  intro p hp
  have h : env27589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27588_27589 : H12AffineEnvironment.transform 2 1 env27588 = env27589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27588 == env27589) = true)

def env27590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452648,95497,8328,65,292257,458024,45524,10281,399665,144613,256,21792,46212,474854]

theorem envBound27590 : H12AffineFastState.Bounded env27590 := by
  intro p hp
  have h : env27590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27559_27590 : H12AffineEnvironment.transform 21 272513 env27559 = env27590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27559 == env27590) = true)

theorem identity27590 : scanCanonicalize (H12AffineFastState.compose env27590 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212199) := by decide +kernel

theorem selectedBound27590 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212199,1024,32769,77899,201830,120015,95497,8328,65,215366,115151,45524,10281,75222,144613,256,21792,46212,513]

theorem envBound27591 : H12AffineFastState.Bounded env27591 := by
  intro p hp
  have h : env27591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27590_27591 : H12AffineEnvironment.transform 17 212199 env27590 = env27591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212199 env27590 == env27591) = true)

def env27592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,77899,201830,119879,95497,8192,65,215366,115015,45404,10281,75102,144493,256,21792,46092,513]

theorem envBound27592 : H12AffineFastState.Bounded env27592 := by
  intro p hp
  have h : env27592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27591_27592 : H12AffineEnvironment.transform 6 8 env27591 = env27592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27591 == env27592) = true)

theorem identity27592 : scanCanonicalize (H12AffineFastState.compose env27592 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound27592 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10280,1024,32769,77899,33,119879,95497,8192,65,23809,115015,45404,10281,75102,73770,256,21792,46092,513]

theorem envBound27593 : H12AffineFastState.Bounded env27593 := by
  intro p hp
  have h : env27593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27592_27593 : H12AffineEnvironment.transform 16 70727 env27592 = env27593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env27592 == env27593) = true)

theorem identity27593 : scanCanonicalize (H12AffineFastState.compose env27593 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27593 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env27594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,70727,10280,1024,8541,77899,33,95515,95497,8192,65,23809,90139,4096,10281,75102,73770,256,21792,5456,513]

theorem envBound27594 : H12AffineFastState.Bounded env27594 := by
  intro p hp
  have h : env27594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27593_27594 : H12AffineEnvironment.transform 14 8540 env27593 = env27594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27593 == env27594) = true)

theorem identity27594 : scanCanonicalize (H12AffineFastState.compose env27594 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound27594 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21591,16400,10280,1024,8541,25628,33,8524,8542,8192,65,23809,13388,4096,10281,28937,29821,256,21792,5456,513]

theorem envBound27595 : H12AffineFastState.Bounded env27595 := by
  intro p hp
  have h : env27595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27594_27595 : H12AffineEnvironment.transform 15 21591 env27594 = env27595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env27594 == env27595) = true)

theorem identity27595 : scanCanonicalize (H12AffineFastState.compose env27595 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27595 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21591,16400,2420,1024,1,17728,33,16,2,348,65,23809,5392,4096,2421,20565,21793,256,21792,5456,513]

theorem envBound27596 : H12AffineFastState.Bounded env27596 := by
  intro p hp
  have h : env27596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27595_27596 : H12AffineEnvironment.transform 12 348 env27595 = env27596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27595 == env27596) = true)

theorem identity27596 : scanCanonicalize (H12AffineFastState.compose env27596 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27596 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5392,2420,1024,1,4160,33,16,2,348,65,2049,5392,4096,2421,1365,33,256,32,5456,513]

theorem envBound27597 : H12AffineFastState.Bounded env27597 := by
  intro p hp
  have h : env27597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27596_27597 : H12AffineEnvironment.transform 13 5376 env27596 = env27597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27596 == env27597) = true)

theorem identity27597 : scanCanonicalize (H12AffineFastState.compose env27597 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound27597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27598 : List Nat := [2,4,8,16,32,64,8,256,512,564,2048,4096,348,4916,0,343,4900,2420,564,1,4160,33,16,2,348,65,2049,4900,4096,2421,865,33,256,32,4964,513]

theorem envBound27598 : H12AffineFastState.Bounded env27598 := by
  intro p hp
  have h : env27598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27597_27598 : H12AffineEnvironment.transform 9 564 env27597 = env27598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env27597 == env27598) = true)

theorem identity27598 : scanCanonicalize (H12AffineFastState.compose env27598 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27598 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27599 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,4096,269,4916,0,262,4900,2341,564,1,4113,33,16,2,269,16,2049,4900,4096,2340,816,33,256,32,4917,513]

theorem envBound27599 : H12AffineFastState.Bounded env27599 := by
  intro p hp
  have h : env27599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27598_27599 : H12AffineEnvironment.transform 5 17 env27598 = env27599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27598 == env27599) = true)

theorem identity27599 : scanCanonicalize (H12AffineFastState.compose env27599 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound27599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27600 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,512,269,308,0,262,292,2341,564,1,529,33,16,2,269,16,2049,292,512,2340,816,33,256,32,309,513]

theorem envBound27600 : H12AffineFastState.Bounded env27600 := by
  intro p hp
  have h : env27600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27599_27600 : H12AffineEnvironment.transform 11 512 env27599 = env27600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env27599 == env27600) = true)

theorem identity27600 : scanCanonicalize (H12AffineFastState.compose env27600 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound27600 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27601 : List Nat := [2,4,8,16,32,17,8,256,512,564,820,512,269,308,0,262,292,529,564,1,529,33,16,2,269,16,821,292,512,528,816,33,256,32,309,513]

theorem envBound27601 : H12AffineFastState.Bounded env27601 := by
  intro p hp
  have h : env27601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27600_27601 : H12AffineEnvironment.transform 10 820 env27600 = env27601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env27600 == env27601) = true)

theorem identity27601 : scanCanonicalize (H12AffineFastState.compose env27601 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound27601 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27602 : List Nat := [2,4,8,16,32,17,8,256,292,272,16,292,269,308,0,262,292,309,272,1,309,33,16,2,269,16,17,292,292,308,20,33,256,32,309,293]

theorem envBound27602 : H12AffineFastState.Bounded env27602 := by
  intro p hp
  have h : env27602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27601_27602 : H12AffineEnvironment.transform 8 292 env27601 = env27602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env27601 == env27602) = true)

theorem identity27602 : scanCanonicalize (H12AffineFastState.compose env27602 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27602 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27603 : List Nat := [2,4,8,16,16,17,8,256,276,272,16,276,269,260,0,262,276,261,272,1,261,17,16,2,269,16,17,276,276,260,20,17,256,16,261,277]

theorem envBound27603 : H12AffineFastState.Bounded env27603 := by
  intro p hp
  have h : env27603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27602_27603 : H12AffineEnvironment.transform 4 16 env27602 = env27603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27602 == env27603) = true)

theorem identity27603 : scanCanonicalize (H12AffineFastState.compose env27603 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27603 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27604 : List Nat := [2,4,8,16,16,17,8,21,1,5,16,1,24,17,0,19,1,16,5,1,16,17,16,2,24,16,17,1,1,17,20,17,21,16,16,0]

theorem envBound27604 : H12AffineFastState.Bounded env27604 := by
  intro p hp
  have h : env27604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27603_27604 : H12AffineEnvironment.transform 7 21 env27603 = env27604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27603 == env27604) = true)

theorem identity27604 : scanCanonicalize (H12AffineFastState.compose env27604 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27605 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,1,9,0,0,2,1,1,5,1,1,0,1,2,9,1,0,1,1,0,5,0,4,1,1,0]

theorem envBound27605 : H12AffineFastState.Bounded env27605 := by
  intro p hp
  have h : env27605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27604_27605 : H12AffineEnvironment.transform 3 1 env27604 = env27605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27604 == env27605) = true)

def env27606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201830,119878,95497,8193,65,215366,115014,45405,10281,75103,144492,256,21792,46093,513]

theorem envBound27606 : H12AffineFastState.Bounded env27606 := by
  intro p hp
  have h : env27606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27591_27606 : H12AffineEnvironment.transform 6 9 env27591 = env27606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27591 == env27606) = true)

theorem identity27606 : scanCanonicalize (H12AffineFastState.compose env27606 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound27606 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,23669,1024,32769,77899,29821,119878,95497,8193,65,10589,115014,45405,10281,75103,87159,256,21792,46093,513]

theorem envBound27607 : H12AffineFastState.Bounded env27607 := by
  intro p hp
  have h : env27607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27606_27607 : H12AffineEnvironment.transform 16 90139 env27606 = env27607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env27606 == env27607) = true)

theorem identity27607 : scanCanonicalize (H12AffineFastState.compose env27607 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound27607 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,49217,23669,1024,32769,36881,29821,29724,54611,8193,65,10589,24860,45405,10281,34053,62509,256,21792,46093,513]

theorem envBound27608 : H12AffineFastState.Bounded env27608 := by
  intro p hp
  have h : env27608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27607_27608 : H12AffineEnvironment.transform 15 41050 env27607 = env27608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env27607 == env27608) = true)

theorem identity27608 : scanCanonicalize (H12AffineFastState.compose env27608 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound27608 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env27609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1125,9279,17444,23669,1024,1124,5236,29821,29724,20790,8193,65,10589,24860,13624,10281,352,28744,256,21792,12392,513]

theorem envBound27609 : H12AffineFastState.Bounded env27609 := by
  intro p hp
  have h : env27609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27608_27609 : H12AffineEnvironment.transform 14 1125 env27608 = env27609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env27608 == env27609) = true)

theorem identity27609 : scanCanonicalize (H12AffineFastState.compose env27609 (packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27609 : packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env27610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1125,9279,12328,10361,1024,1124,5236,113,16,9530,8193,65,10589,5392,13624,10281,352,1092,256,8492,12392,513]

theorem envBound27610 : H12AffineFastState.Bounded env27610 := by
  intro p hp
  have h : env27610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27609_27610 : H12AffineEnvironment.transform 13 13324 env27609 = env27610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27609 == env27610) = true)

theorem identity27610 : scanCanonicalize (H12AffineFastState.compose env27610 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound27610 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4452,1125,343,5440,3345,1024,1124,5236,113,16,82,1385,65,3125,5392,4176,3393,352,1092,256,1092,5376,513]

theorem envBound27611 : H12AffineFastState.Bounded env27611 := by
  intro p hp
  have h : env27611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27610_27611 : H12AffineEnvironment.transform 12 1384 env27610 = env27611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env27610 == env27611) = true)

theorem identity27611 : scanCanonicalize (H12AffineFastState.compose env27611 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound27611 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,884,1384,528,1125,343,1588,3345,1024,1124,1792,113,16,82,1385,65,3125,1636,804,3393,352,1092,256,1092,1652,513]

theorem envBound27612 : H12AffineFastState.Bounded env27612 := by
  intro p hp
  have h : env27612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27611_27612 : H12AffineEnvironment.transform 11 884 env27611 = env27612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env27611 == env27612) = true)

theorem identity27612 : scanCanonicalize (H12AffineFastState.compose env27612 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound27612 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1280,884,1384,528,1125,343,1588,17,1024,1124,1792,113,16,82,1385,65,309,1636,804,65,352,1092,256,1092,1652,513]

theorem envBound27613 : H12AffineFastState.Bounded env27613 := by
  intro p hp
  have h : env27613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27612_27613 : H12AffineEnvironment.transform 10 1280 env27612 = env27613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env27612 == env27613) = true)

theorem identity27613 : scanCanonicalize (H12AffineFastState.compose env27613 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound27613 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env27614 : List Nat := [2,4,8,16,32,64,9,256,65,1024,1280,309,1384,81,1125,343,1141,17,1024,1124,1345,113,16,82,1385,65,309,1061,357,65,352,1092,256,1092,1077,64]

theorem envBound27614 : H12AffineFastState.Bounded env27614 := by
  intro p hp
  have h : env27614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27613_27614 : H12AffineEnvironment.transform 8 65 env27613 = env27614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env27613 == env27614) = true)

theorem identity27614 : scanCanonicalize (H12AffineFastState.compose env27614 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27614 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env27615 : List Nat := [2,4,8,16,32,64,9,36,65,1024,1060,17,1100,81,1125,115,1141,17,1024,1124,1125,113,16,82,1101,65,17,1061,65,65,68,1092,36,1092,1077,64]

theorem envBound27615 : H12AffineFastState.Bounded env27615 := by
  intro p hp
  have h : env27615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27614_27615 : H12AffineEnvironment.transform 7 36 env27614 = env27615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27614 == env27615) = true)

theorem identity27615 : scanCanonicalize (H12AffineFastState.compose env27615 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27615 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env27616 : List Nat := [2,4,8,16,32,64,9,36,65,52,16,17,120,81,81,115,65,17,52,80,81,113,16,82,121,65,17,17,65,65,68,112,36,112,1,64]

theorem envBound27616 : H12AffineFastState.Bounded env27616 := by
  intro p hp
  have h : env27616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27615_27616 : H12AffineEnvironment.transform 9 52 env27615 = env27616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27615 == env27616) = true)

theorem identity27616 : scanCanonicalize (H12AffineFastState.compose env27616 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27617 : List Nat := [2,4,8,16,32,0,9,36,1,52,16,17,56,17,17,51,1,17,52,16,17,49,16,18,57,1,17,17,1,1,4,48,36,48,1,0]

theorem envBound27617 : H12AffineFastState.Bounded env27617 := by
  intro p hp
  have h : env27617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27616_27617 : H12AffineEnvironment.transform 5 0 env27616 = env27617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27616 == env27617) = true)

def env27618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452649,95496,8328,65,4218144,458025,45525,10280,399665,4594789,256,21792,46212,474854]

theorem envBound27618 : H12AffineFastState.Bounded env27618 := by
  intro p hp
  have h : env27618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27558_27618 : H12AffineEnvironment.transform 22 452649 env27558 = env27618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env27558 == env27618) = true)

def env27619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452649,95496,8328,65,292256,458025,45525,10280,399665,144613,256,21792,46212,474854]

theorem envBound27619 : H12AffineFastState.Bounded env27619 := by
  intro p hp
  have h : env27619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27618_27619 : H12AffineEnvironment.transform 21 272512 env27618 = env27619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27618 == env27619) = true)

theorem identity27619 : scanCanonicalize (H12AffineFastState.compose env27619 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27619 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396460,272512,452649,21762,8328,65,292256,458025,45525,10280,399665,144613,256,21792,46212,401132]

theorem envBound27620 : H12AffineFastState.Bounded env27620 := by
  intro p hp
  have h : env27620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27619_27620 : H12AffineEnvironment.transform 15 8202 env27619 = env27620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27619 == env27620) = true)

def env27621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396324,272392,452649,21762,8192,65,292136,458025,45405,10280,399665,144493,256,21792,46092,400996]

theorem envBound27621 : H12AffineFastState.Bounded env27621 := by
  intro p hp
  have h : env27621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27620_27621 : H12AffineEnvironment.transform 6 8 env27620 = env27621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27620 == env27621) = true)

end H12CloudChart0