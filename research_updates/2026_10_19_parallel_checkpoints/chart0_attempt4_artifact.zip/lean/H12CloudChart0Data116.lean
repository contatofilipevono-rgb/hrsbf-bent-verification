import H12CloudChart0Data115

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound29417 : H12AffineFastState.Bounded env29417 := by
  intro p hp
  have h : env29417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29416_29417 : H12AffineEnvironment.transform 9 273 env29416 = env29417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29416 == env29417) = true)

theorem identity29417 : scanCanonicalize (H12AffineFastState.compose env29417 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound29417 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29418 : List Nat := [2,4,8,16,32,64,9,256,10,273,373,309,349,292,81,343,356,1,272,80,292,32,16,3,348,64,373,309,357,1,21,112,257,33,293,90]

theorem envBound29418 : H12AffineFastState.Bounded env29418 := by
  intro p hp
  have h : env29418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29417_29418 : H12AffineEnvironment.transform 8 10 env29417 = env29418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env29417 == env29418) = true)

theorem identity29418 : scanCanonicalize (H12AffineFastState.compose env29418 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29418 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29419 : List Nat := [2,4,8,16,32,64,9,36,10,53,81,17,121,0,81,115,64,1,52,80,0,32,16,3,120,64,81,17,65,1,21,112,37,33,1,90]

theorem envBound29419 : H12AffineFastState.Bounded env29419 := by
  intro p hp
  have h : env29419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29418_29419 : H12AffineEnvironment.transform 7 36 env29418 = env29419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29418 == env29419) = true)

theorem identity29419 : scanCanonicalize (H12AffineFastState.compose env29419 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29419 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29420 : List Nat := [2,4,8,16,0,64,9,4,10,21,81,17,89,0,81,83,64,1,20,80,0,0,16,3,88,64,81,17,65,1,21,80,5,1,1,90]

theorem envBound29420 : H12AffineFastState.Bounded env29420 := by
  intro p hp
  have h : env29420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29419_29420 : H12AffineEnvironment.transform 4 0 env29419 = env29420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29419 == env29420) = true)

theorem identity29420 : scanCanonicalize (H12AffineFastState.compose env29420 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29421 : List Nat := [2,4,8,16,0,17,9,4,10,21,0,17,8,0,0,2,17,1,20,1,0,0,16,3,9,17,0,17,16,1,21,1,5,1,1,11]

theorem envBound29421 : H12AffineFastState.Bounded env29421 := by
  intro p hp
  have h : env29421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29420_29421 : H12AffineEnvironment.transform 5 17 env29420 = env29421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29420 == env29421) = true)

theorem identity29421 : scanCanonicalize (H12AffineFastState.compose env29421 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29422 : List Nat := [2,0,8,16,0,17,9,0,10,17,0,17,8,0,0,2,17,1,16,1,0,0,16,3,9,17,0,17,16,1,17,1,1,1,1,11]

theorem envBound29422 : H12AffineFastState.Bounded env29422 := by
  intro p hp
  have h : env29422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29421_29422 : H12AffineEnvironment.transform 1 0 env29421 = env29422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29421 == env29422) = true)

theorem identity29422 : scanCanonicalize (H12AffineFastState.compose env29422 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29423 : List Nat := [2,0,1,16,0,17,0,0,3,17,0,17,1,0,0,2,17,1,16,1,0,0,16,3,0,17,0,17,16,1,17,1,1,1,1,2]

theorem envBound29423 : H12AffineFastState.Bounded env29423 := by
  intro p hp
  have h : env29423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29422_29423 : H12AffineEnvironment.transform 2 1 env29422 = env29423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29422 == env29423) = true)

def env29424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272513,180225,95497,8328,64,23944,185600,45525,262144,143641,400588,257,21793,46212,202446]

theorem envBound29424 : H12AffineFastState.Bounded env29424 := by
  intro p hp
  have h : env29424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29382_29424 : H12AffineEnvironment.transform 21 272513 env29382 = env29424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29382 == env29424) = true)

theorem identity29424 : scanCanonicalize (H12AffineFastState.compose env29424 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound29424 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115871,272513,73755,95497,8328,64,23944,79130,45525,262144,119043,392406,257,21793,46212,63188]

theorem envBound29425 : H12AffineFastState.Bounded env29425 := by
  intro p hp
  have h : env29425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29424_29425 : H12AffineEnvironment.transform 16 122906 env29424 = env29425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env29424 == env29425) = true)

def env29426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10400,1025,32769,115871,33,73755,95497,8328,64,23944,79130,45525,10400,119043,119926,257,21793,46212,63188]

theorem envBound29426 : H12AffineFastState.Bounded env29426 := by
  intro p hp
  have h : env29426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29425_29426 : H12AffineEnvironment.transform 17 10400 env29425 = env29426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29425 == env29426) = true)

theorem identity29426 : scanCanonicalize (H12AffineFastState.compose env29426 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound29426 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env29427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,5393,10400,1025,32769,12692,33,54544,32770,8328,64,23944,49169,45525,10400,9224,8573,257,21793,46212,63188]

theorem envBound29427 : H12AffineFastState.Bounded env29427 := by
  intro p hp
  have h : env29427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29426_29427 : H12AffineEnvironment.transform 15 62731 env29426 = env29427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env29426 == env29427) = true)

theorem identity29427 : scanCanonicalize (H12AffineFastState.compose env29427 (packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29427 : packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env29428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,33111,5393,10400,1025,32769,12692,33,41292,32770,8328,64,10708,46157,45525,10400,9224,8573,257,8573,46212,33416]

theorem envBound29428 : H12AffineFastState.Bounded env29428 := by
  intro p hp
  have h : env29428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29427_29428 : H12AffineEnvironment.transform 13 13404 env29427 = env29428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29427 == env29428) = true)

theorem identity29428 : scanCanonicalize (H12AffineFastState.compose env29428 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29428 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env29429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8541,8202,5393,10400,1025,8540,12692,33,17,8543,8328,64,10708,5392,4232,10400,9224,8573,257,8573,5593,9173]

theorem envBound29429 : H12AffineFastState.Bounded env29429 := by
  intro p hp
  have h : env29429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29428_29429 : H12AffineEnvironment.transform 14 8541 env29428 = env29429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29428 == env29429) = true)

theorem identity29429 : scanCanonicalize (H12AffineFastState.compose env29429 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound29429 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5393,2420,1025,136,4160,33,17,139,348,64,2048,5392,4232,2420,1500,169,257,169,5593,513]

theorem envBound29430 : H12AffineFastState.Bounded env29430 := by
  intro p hp
  have h : env29430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29429_29430 : H12AffineEnvironment.transform 12 468 env29429 = env29430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env29429 == env29430) = true)

def env29431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10401,1025,32769,115871,32,73755,95497,8328,64,23944,79130,45525,10401,119043,119927,257,21793,46212,63188]

theorem envBound29431 : H12AffineFastState.Bounded env29431 := by
  intro p hp
  have h : env29431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29425_29431 : H12AffineEnvironment.transform 17 10401 env29425 = env29431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29425 == env29431) = true)

theorem identity29431 : scanCanonicalize (H12AffineFastState.compose env29431 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29431 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env29432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10401,1025,29789,78019,32,73755,95497,8328,64,23944,79130,17801,10401,75103,73771,257,21793,16600,648]

theorem envBound29432 : H12AffineFastState.Bounded env29432 := by
  intro p hp
  have h : env29432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29431_29432 : H12AffineEnvironment.transform 14 29788 env29431 = env29432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29431 == env29432) = true)

theorem identity29432 : scanCanonicalize (H12AffineFastState.compose env29432 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound29432 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env29433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,21510,16448,10401,1025,29789,25797,32,29725,8463,8328,64,23944,24860,17801,10401,29017,29741,257,21793,16600,648]

theorem envBound29433 : H12AffineFastState.Bounded env29433 := by
  intro p hp
  have h : env29433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29432_29433 : H12AffineEnvironment.transform 15 21510 env29432 = env29433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env29432 == env29433) = true)

theorem identity29433 : scanCanonicalize (H12AffineFastState.compose env29433 (packedSelected [2,6,9,11,14,16,17,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29433 : packedSelected [2,6,9,11,14,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env29434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,0,8282,13340,10401,1025,1,4249,32,65,8463,8328,64,10708,5440,12757,10401,1285,113,257,8573,13444,648]

theorem envBound29434 : H12AffineFastState.Bounded env29434 := by
  intro p hp
  have h : env29434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29433_29434 : H12AffineEnvironment.transform 13 13404 env29433 = env29434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29433 == env29434) = true)

theorem identity29434 : scanCanonicalize (H12AffineFastState.compose env29434 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1504) := by decide +kernel

theorem selectedBound29434 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env29435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1504,4540,0,1466,4604,3393,1025,1,4249,32,65,1263,1384,64,3124,5440,5173,3393,1285,113,257,1181,4452,648]

theorem envBound29435 : H12AffineFastState.Bounded env29435 := by
  intro p hp
  have h : env29435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29434_29435 : H12AffineEnvironment.transform 12 1504 env29434 = env29435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1504 env29434 == env29435) = true)

theorem identity29435 : scanCanonicalize (H12AffineFastState.compose env29435 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29435 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29436 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,1173,4297,0,1231,4233,3124,1025,1,4249,32,65,1263,1053,64,3124,5173,5173,3124,1136,113,116,1181,4113,648]

theorem envBound29436 : H12AffineFastState.Bounded env29436 := by
  intro p hp
  have h : env29436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29435_29436 : H12AffineEnvironment.transform 7 117 env29435 = env29436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29435 == env29436) = true)

theorem identity29436 : scanCanonicalize (H12AffineFastState.compose env29436 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29436 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29437 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,4096,240,4297,0,170,4233,2129,100,1,4249,32,65,138,120,64,2129,4176,4176,2129,21,113,116,248,4113,648]

theorem envBound29437 : H12AffineFastState.Bounded env29437 := by
  intro p hp
  have h : env29437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29436_29437 : H12AffineEnvironment.transform 9 101 env29436 = env29437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29436 == env29437) = true)

theorem identity29437 : scanCanonicalize (H12AffineFastState.compose env29437 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29437 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29438 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,4096,161,4248,0,170,4233,2048,53,1,4249,32,16,138,41,17,2048,4097,4097,2048,21,32,37,169,4113,648]

theorem envBound29438 : H12AffineFastState.Bounded env29438 := by
  intro p hp
  have h : env29438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29437_29438 : H12AffineEnvironment.transform 5 17 env29437 = env29438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29437 == env29438) = true)

theorem identity29438 : scanCanonicalize (H12AffineFastState.compose env29438 (packedSelected [0,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29438 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env29439 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,41,4112,0,34,4097,2048,53,1,4113,32,16,2,41,17,2048,4097,4097,2048,21,32,37,33,4113,512]

theorem envBound29439 : H12AffineFastState.Bounded env29439 := by
  intro p hp
  have h : env29439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29438_29439 : H12AffineEnvironment.transform 6 8 env29438 = env29439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29438 == env29439) = true)

theorem identity29439 : scanCanonicalize (H12AffineFastState.compose env29439 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound29439 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29440 : List Nat := [2,4,8,16,32,17,8,36,512,52,37,4096,41,4112,0,34,4097,37,53,1,4113,32,16,2,41,17,37,4097,4097,37,21,32,37,33,4113,512]

theorem envBound29440 : H12AffineFastState.Bounded env29440 := by
  intro p hp
  have h : env29440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29439_29440 : H12AffineEnvironment.transform 10 37 env29439 = env29440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env29439 == env29440) = true)

theorem identity29440 : scanCanonicalize (H12AffineFastState.compose env29440 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound29440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29441 : List Nat := [2,4,8,16,32,17,8,36,45,52,37,4096,41,4112,0,34,4097,37,53,1,4113,32,16,2,41,17,37,4097,4097,37,21,32,37,33,4113,45]

theorem envBound29441 : H12AffineFastState.Bounded env29441 := by
  intro p hp
  have h : env29441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29440_29441 : H12AffineEnvironment.transform 8 45 env29440 = env29441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env29440 == env29441) = true)

theorem identity29441 : scanCanonicalize (H12AffineFastState.compose env29441 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound29441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29442 : List Nat := [2,4,8,16,32,17,8,36,45,52,37,32,41,48,0,34,33,37,53,1,49,32,16,2,41,17,37,33,33,37,21,32,37,33,49,45]

theorem envBound29442 : H12AffineFastState.Bounded env29442 := by
  intro p hp
  have h : env29442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29441_29442 : H12AffineEnvironment.transform 11 32 env29441 = env29442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env29441 == env29442) = true)

theorem identity29442 : scanCanonicalize (H12AffineFastState.compose env29442 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound29442 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29443 : List Nat := [2,4,7,16,32,17,7,36,34,52,37,32,38,48,0,34,33,37,53,1,49,32,16,2,38,17,37,33,33,37,21,32,37,33,49,34]

theorem envBound29443 : H12AffineFastState.Bounded env29443 := by
  intro p hp
  have h : env29443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29442_29443 : H12AffineEnvironment.transform 2 7 env29442 = env29443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env29442 == env29443) = true)

theorem identity29443 : scanCanonicalize (H12AffineFastState.compose env29443 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound29443 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29444 : List Nat := [2,4,7,16,4,17,7,0,6,16,1,4,2,20,0,6,5,1,17,1,21,4,16,2,2,17,1,5,5,1,21,4,1,5,21,6]

theorem envBound29444 : H12AffineFastState.Bounded env29444 := by
  intro p hp
  have h : env29444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29443_29444 : H12AffineEnvironment.transform 4 4 env29443 = env29444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env29443 == env29444) = true)

theorem identity29444 : scanCanonicalize (H12AffineFastState.compose env29444 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29444 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29445 : List Nat := [2,4,7,0,4,1,7,0,6,0,1,4,2,4,0,6,5,1,1,1,5,4,0,2,2,1,1,5,5,1,5,4,1,5,5,6]

theorem envBound29445 : H12AffineFastState.Bounded env29445 := by
  intro p hp
  have h : env29445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29444_29445 : H12AffineEnvironment.transform 3 0 env29444 = env29445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29444 == env29445) = true)

theorem identity29445 : scanCanonicalize (H12AffineFastState.compose env29445 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29445 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29446 : List Nat := [2,0,3,0,0,1,3,0,2,0,1,0,2,0,0,2,1,1,1,1,1,0,0,2,2,1,1,1,1,1,1,0,1,1,1,2]

theorem envBound29446 : H12AffineFastState.Bounded env29446 := by
  intro p hp
  have h : env29446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29445_29446 : H12AffineEnvironment.transform 1 0 env29445 = env29446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29445 == env29446) = true)

def env29447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,8388608,8631561,8328,64,4486408,8393984,8548820,8830977,143640,12645453,257,21792,46213,202447]

theorem envBound29447 : H12AffineFastState.Bounded env29447 := by
  intro p hp
  have h : env29447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29329_29447 : H12AffineEnvironment.transform 23 8631561 env29329 = env29447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631561 env29329 == env29447) = true)

def env29448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,180224,95497,8328,64,4486408,185600,45524,262145,143640,4338765,257,21792,46213,202447]

theorem envBound29448 : H12AffineFastState.Bounded env29448 := by
  intro p hp
  have h : env29448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29447_29448 : H12AffineEnvironment.transform 22 180224 env29447 = env29448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env29447 == env29448) = true)

def env29449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272512,180224,95497,8328,64,23944,185600,45524,262145,143640,400589,257,21792,46213,202447]

theorem envBound29449 : H12AffineFastState.Bounded env29449 := by
  intro p hp
  have h : env29449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29448_29449 : H12AffineEnvironment.transform 21 272512 env29448 = env29449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29448 == env29449) = true)

theorem identity29449 : scanCanonicalize (H12AffineFastState.compose env29449 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound29449 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272512,17,95497,8328,64,23944,5393,45524,262145,61705,318684,257,21792,46213,120542]

theorem envBound29450 : H12AffineFastState.Bounded env29450 := by
  intro p hp
  have h : env29450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29449_29450 : H12AffineEnvironment.transform 16 49169 env29449 = env29450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29449 == env29450) = true)

def env29451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,17,95497,8192,64,23808,5393,45404,262145,61705,318548,257,21792,46093,120406]

theorem envBound29451 : H12AffineFastState.Bounded env29451 := by
  intro p hp
  have h : env29451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29450_29451 : H12AffineEnvironment.transform 6 8 env29450 = env29451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29450 == env29451) = true)

theorem identity29451 : scanCanonicalize (H12AffineFastState.compose env29451 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound29451 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130175,1025,32769,58396,119927,17,95497,8192,64,23808,5393,45404,130174,61705,73771,257,21792,46093,120406]

theorem envBound29452 : H12AffineFastState.Bounded env29452 := by
  intro p hp
  have h : env29452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29451_29452 : H12AffineEnvironment.transform 17 130175 env29451 = env29452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env29451 == env29452) = true)

theorem identity29452 : scanCanonicalize (H12AffineFastState.compose env29452 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound29452 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env29453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,49169,43049,1025,32769,58396,32801,17,8543,8192,64,23808,5393,45404,43048,61705,29821,257,21792,46093,33280]

theorem envBound29453 : H12AffineFastState.Bounded env29453 := by
  intro p hp
  have h : env29453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29452_29453 : H12AffineEnvironment.transform 15 21590 env29452 = env29453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env29452 == env29453) = true)

theorem identity29453 : scanCanonicalize (H12AffineFastState.compose env29453 (packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29453 : packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env29454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,8283,46108,43049,1025,32769,36881,32801,17,8543,8192,64,10509,5393,45404,43048,34052,112,257,8493,46093,33280]

theorem envBound29454 : H12AffineFastState.Bounded env29454 := by
  intro p hp
  have h : env29454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29453_29454 : H12AffineEnvironment.transform 13 13325 env29453 = env29454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29453 == env29454) = true)

theorem identity29454 : scanCanonicalize (H12AffineFastState.compose env29454 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound29454 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8461,8283,5393,2340,1025,8460,12572,8492,17,8543,8192,64,10509,5393,4177,2341,9225,112,257,8493,5376,8973]

theorem envBound29455 : H12AffineFastState.Bounded env29455 := by
  intro p hp
  have h : env29455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29454_29455 : H12AffineEnvironment.transform 14 8461 env29454 = env29455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env29454 == env29455) = true)

theorem identity29455 : scanCanonicalize (H12AffineFastState.compose env29455 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29455 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,0,342,5393,2340,1025,1,4113,33,17,82,269,64,2048,5393,4177,2341,1284,112,257,32,5376,512]

theorem envBound29456 : H12AffineFastState.Bounded env29456 := by
  intro p hp
  have h : env29456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29455_29456 : H12AffineEnvironment.transform 12 269 env29455 = env29456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29455 == env29456) = true)

theorem identity29456 : scanCanonicalize (H12AffineFastState.compose env29456 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29457 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5376,0,342,5393,2309,1025,1,4113,0,17,82,269,64,2048,5393,4177,2308,1284,81,257,1,5376,512]

theorem envBound29457 : H12AffineFastState.Bounded env29457 := by
  intro p hp
  have h : env29457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29456_29457 : H12AffineEnvironment.transform 4 1 env29456 = env29457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29456 == env29457) = true)

theorem identity29457 : scanCanonicalize (H12AffineFastState.compose env29457 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29457 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29458 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,4096,269,4113,0,342,4096,2309,272,1,4113,0,17,82,269,64,2048,4096,4177,2308,21,81,257,1,4113,512]

theorem envBound29458 : H12AffineFastState.Bounded env29458 := by
  intro p hp
  have h : env29458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29457_29458 : H12AffineEnvironment.transform 9 273 env29457 = env29458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29457 == env29458) = true)

theorem identity29458 : scanCanonicalize (H12AffineFastState.compose env29458 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound29458 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29459 : List Nat := [2,4,8,16,1,64,8,256,512,273,340,4096,269,4113,0,342,4096,81,272,1,4113,0,17,82,269,64,340,4096,4177,80,21,81,257,1,4113,512]

theorem envBound29459 : H12AffineFastState.Bounded env29459 := by
  intro p hp
  have h : env29459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29458_29459 : H12AffineEnvironment.transform 10 340 env29458 = env29459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env29458 == env29459) = true)

theorem identity29459 : scanCanonicalize (H12AffineFastState.compose env29459 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound29459 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29460 : List Nat := [2,4,8,16,1,64,8,256,512,273,340,64,269,81,0,342,64,81,272,1,81,0,17,82,269,64,340,64,17,80,21,81,257,1,81,512]

theorem envBound29460 : H12AffineFastState.Bounded env29460 := by
  intro p hp
  have h : env29460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29459_29460 : H12AffineEnvironment.transform 11 64 env29459 = env29460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env29459 == env29460) = true)

theorem identity29460 : scanCanonicalize (H12AffineFastState.compose env29460 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29460 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29461 : List Nat := [2,4,8,16,1,17,8,256,512,273,261,17,269,0,0,263,17,0,272,1,0,0,17,3,269,17,261,17,17,1,21,0,257,1,0,512]

theorem envBound29461 : H12AffineFastState.Bounded env29461 := by
  intro p hp
  have h : env29461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29460_29461 : H12AffineEnvironment.transform 5 17 env29460 = env29461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29460 == env29461) = true)

theorem identity29461 : scanCanonicalize (H12AffineFastState.compose env29461 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29462 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,0,0,3,17,0,20,1,0,0,17,3,9,17,1,17,17,1,21,0,5,1,0,512]

theorem envBound29462 : H12AffineFastState.Bounded env29462 := by
  intro p hp
  have h : env29462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29461_29462 : H12AffineEnvironment.transform 7 4 env29461 = env29462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29461 == env29462) = true)

theorem identity29462 : scanCanonicalize (H12AffineFastState.compose env29462 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29463 : List Nat := [2,4,8,16,1,17,8,4,1,21,1,17,9,0,0,3,17,0,20,1,0,0,17,3,9,17,1,17,17,1,21,0,5,1,0,1]

theorem envBound29463 : H12AffineFastState.Bounded env29463 := by
  intro p hp
  have h : env29463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29462_29463 : H12AffineEnvironment.transform 8 1 env29462 = env29463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29462 == env29463) = true)

theorem identity29463 : scanCanonicalize (H12AffineFastState.compose env29463 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29464 : List Nat := [2,4,8,5,1,4,8,4,1,0,1,4,9,0,0,3,4,0,1,1,0,0,4,3,9,4,1,4,4,1,0,0,5,1,0,1]

theorem envBound29464 : H12AffineFastState.Bounded env29464 := by
  intro p hp
  have h : env29464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29463_29464 : H12AffineEnvironment.transform 3 5 env29463 = env29464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29463 == env29464) = true)

def env29465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,17,95497,8193,64,23809,5393,45405,262145,61705,318549,257,21792,46092,120407]

theorem envBound29465 : H12AffineFastState.Bounded env29465 := by
  intro p hp
  have h : env29465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29450_29465 : H12AffineEnvironment.transform 6 9 env29450 = env29465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29450 == env29465) = true)

theorem identity29465 : scanCanonicalize (H12AffineFastState.compose env29465 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound29465 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89378,1025,32769,58397,95531,17,95497,8193,64,23809,5393,45405,89379,61705,98679,257,21792,46092,120407]

theorem envBound29466 : H12AffineFastState.Bounded env29466 := by
  intro p hp
  have h : env29466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29465_29466 : H12AffineEnvironment.transform 17 89378 env29465 = env29466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env29465 == env29466) = true)

theorem identity29466 : scanCanonicalize (H12AffineFastState.compose env29466 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound29466 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29823,49169,10589,1025,32769,58397,340,17,374,8193,64,23809,5393,45405,10588,61705,62728,257,21792,46092,41512]

theorem envBound29467 : H12AffineFastState.Bounded env29467 := by
  intro p hp
  have h : env29467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29466_29467 : H12AffineEnvironment.transform 15 29823 env29466 = env29467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env29466 == env29467) = true)

theorem identity29467 : scanCanonicalize (H12AffineFastState.compose env29467 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound29467 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env29468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,34,46156,10589,1025,32769,36928,340,17,374,8193,64,10588,5393,45405,10588,34132,33109,257,8573,46092,41512]

theorem envBound29468 : H12AffineFastState.Bounded env29468 := by
  intro p hp
  have h : env29468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29467_29468 : H12AffineEnvironment.transform 13 13405 env29467 = env29468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env29467 == env29468) = true)

theorem identity29468 : scanCanonicalize (H12AffineFastState.compose env29468 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound29468 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8233,34,5221,10589,1025,8232,12393,340,17,374,8193,64,10588,5393,4468,10588,9597,8572,257,8573,5157,513]

theorem envBound29469 : H12AffineFastState.Bounded env29469 := by
  intro p hp
  have h : env29469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29468_29469 : H12AffineEnvironment.transform 14 8233 env29468 = env29469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env29468 == env29469) = true)

theorem identity29469 : scanCanonicalize (H12AffineFastState.compose env29469 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound29469 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4453,1297,34,5221,3173,1025,1296,5457,340,17,374,1337,64,3172,5393,4468,3172,69,1092,257,1093,5157,513]

theorem envBound29470 : H12AffineFastState.Bounded env29470 := by
  intro p hp
  have h : env29470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29469_29470 : H12AffineEnvironment.transform 12 1336 env29469 = env29470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env29469 == env29470) = true)

theorem identity29470 : scanCanonicalize (H12AffineFastState.compose env29470 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29470 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29471 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4453,0,34,4468,2420,272,1,4160,340,17,374,40,64,2421,4096,4468,2421,69,341,257,340,4404,513]

theorem envBound29471 : H12AffineFastState.Bounded env29471 := by
  intro p hp
  have h : env29471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29470_29471 : H12AffineEnvironment.transform 9 273 env29470 = env29471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29470 == env29471) = true)

theorem identity29471 : scanCanonicalize (H12AffineFastState.compose env29471 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29471 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29472 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,41,4405,0,34,4388,2340,272,1,4112,260,17,294,40,16,2341,4096,4388,2341,21,261,257,260,4404,513]

theorem envBound29472 : H12AffineFastState.Bounded env29472 := by
  intro p hp
  have h : env29472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29471_29472 : H12AffineEnvironment.transform 5 16 env29471 = env29472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29471 == env29472) = true)

theorem identity29472 : scanCanonicalize (H12AffineFastState.compose env29472 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound29472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29473 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,32,41,277,0,34,260,2340,272,1,48,260,17,294,40,16,2341,32,260,2341,21,261,257,260,276,513]

theorem envBound29473 : H12AffineFastState.Bounded env29473 := by
  intro p hp
  have h : env29473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29472_29473 : H12AffineEnvironment.transform 11 32 env29472 = env29473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env29472 == env29473) = true)

theorem identity29473 : scanCanonicalize (H12AffineFastState.compose env29473 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound29473 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29474 : List Nat := [2,4,8,16,32,16,9,256,512,273,789,32,41,277,0,34,260,561,272,1,48,260,17,294,40,16,560,32,260,560,21,261,257,260,276,513]

theorem envBound29474 : H12AffineFastState.Bounded env29474 := by
  intro p hp
  have h : env29474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29473_29474 : H12AffineEnvironment.transform 10 789 env29473 = env29474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env29473 == env29474) = true)

theorem identity29474 : scanCanonicalize (H12AffineFastState.compose env29474 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29474 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29475 : List Nat := [2,4,8,16,0,16,9,256,512,273,789,0,9,277,0,2,260,529,272,1,16,260,17,262,8,16,528,0,260,528,21,261,257,260,276,513]

theorem envBound29475 : H12AffineFastState.Bounded env29475 := by
  intro p hp
  have h : env29475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29474_29475 : H12AffineEnvironment.transform 4 0 env29474 = env29475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29474 == env29475) = true)

theorem identity29475 : scanCanonicalize (H12AffineFastState.compose env29475 (packedSelected [1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound29475 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env29476 : List Nat := [2,4,8,16,0,16,9,256,17,273,260,0,9,277,0,2,260,0,272,1,16,260,17,262,8,16,1,0,260,1,21,261,257,260,276,16]

theorem envBound29476 : H12AffineFastState.Bounded env29476 := by
  intro p hp
  have h : env29476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29475_29476 : H12AffineEnvironment.transform 8 17 env29475 = env29476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env29475 == env29476) = true)

theorem identity29476 : scanCanonicalize (H12AffineFastState.compose env29476 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29476 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29477 : List Nat := [2,4,8,1,0,1,9,256,0,256,260,0,9,260,0,2,260,0,257,1,1,260,0,262,8,1,1,0,260,1,4,261,257,260,261,1]

theorem envBound29477 : H12AffineFastState.Bounded env29477 := by
  intro p hp
  have h : env29477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29476_29477 : H12AffineEnvironment.transform 3 1 env29476 = env29477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29476 == env29477) = true)

theorem identity29477 : scanCanonicalize (H12AffineFastState.compose env29477 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29478 : List Nat := [2,4,8,1,0,1,9,4,0,4,0,0,9,0,0,2,0,0,5,1,1,0,0,2,8,1,1,0,0,1,4,1,5,0,1,1]

theorem envBound29478 : H12AffineFastState.Bounded env29478 := by
  intro p hp
  have h : env29478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29477_29478 : H12AffineEnvironment.transform 7 4 env29477 = env29478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29477 == env29478) = true)

def env29479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272513,180224,95497,8328,64,23945,185600,45524,262145,143640,400588,257,21792,46213,202447]

theorem envBound29479 : H12AffineFastState.Bounded env29479 := by
  intro p hp
  have h : env29479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29448_29479 : H12AffineEnvironment.transform 21 272513 env29448 = env29479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29448 == env29479) = true)

def env29480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272393,180224,95497,8192,64,23809,185600,45404,262145,143640,400452,257,21792,46093,202311]

theorem envBound29480 : H12AffineFastState.Bounded env29480 := by
  intro p hp
  have h : env29480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29479_29480 : H12AffineEnvironment.transform 6 8 env29479 = env29480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29479 == env29480) = true)

def env29481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,16,95497,8192,64,23809,5392,45404,262145,61704,318548,257,21792,46093,120407]

theorem envBound29481 : H12AffineFastState.Bounded env29481 := by
  intro p hp
  have h : env29481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29480_29481 : H12AffineEnvironment.transform 16 49168 env29480 = env29481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29480 == env29481) = true)

theorem identity29481 : scanCanonicalize (H12AffineFastState.compose env29481 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound29481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,58397,272393,16,41311,8192,64,23809,5392,45404,262145,61704,318548,257,21792,46093,513]

theorem envBound29482 : H12AffineFastState.Bounded env29482 := by
  intro p hp
  have h : env29482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29481_29482 : H12AffineEnvironment.transform 15 54358 env29481 = env29482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env29481 == env29482) = true)

theorem identity29482 : scanCanonicalize (H12AffineFastState.compose env29482 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29482 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40970,46156,262144,1025,32769,36929,272393,16,41311,8192,64,10589,5392,45404,262145,34132,305160,257,8572,46093,513]

theorem envBound29483 : H12AffineFastState.Bounded env29483 := by
  intro p hp
  have h : env29483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29482_29483 : H12AffineEnvironment.transform 13 13404 env29482 = env29483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29482 == env29483) = true)

theorem identity29483 : scanCanonicalize (H12AffineFastState.compose env29483 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29483 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33111,38161,262144,1025,32769,36929,264532,16,32770,349,64,2048,5392,36865,262145,34132,297301,257,33,38224,513]

theorem envBound29484 : H12AffineFastState.Bounded env29484 := by
  intro p hp
  have h : env29484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29483_29484 : H12AffineEnvironment.transform 12 349 env29483 = env29484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29483 == env29484) = true)

theorem identity29484 : scanCanonicalize (H12AffineFastState.compose env29484 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29484 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33111,38161,2420,1025,32769,36929,32,16,32770,349,64,2048,5392,36865,2421,34132,32801,257,33,38224,513]

theorem envBound29485 : H12AffineFastState.Bounded env29485 := by
  intro p hp
  have h : env29485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29484_29485 : H12AffineEnvironment.transform 17 2420 env29484 = env29485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29484 == env29485) = true)

theorem identity29485 : scanCanonicalize (H12AffineFastState.compose env29485 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29485 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29486 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,32768,33111,36865,2420,273,32769,36929,32,16,32770,349,64,2048,4096,36865,2421,32836,32801,257,33,36928,513]

theorem envBound29486 : H12AffineFastState.Bounded env29486 := by
  intro p hp
  have h : env29486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29485_29486 : H12AffineEnvironment.transform 9 272 env29485 = env29486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29485 == env29486) = true)

theorem identity29486 : scanCanonicalize (H12AffineFastState.compose env29486 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound29486 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env29487 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,2129,2310,6224,2420,273,2128,6160,32,16,2131,349,64,2048,4096,6224,2421,2069,2160,257,33,6161,513]

theorem envBound29487 : H12AffineFastState.Bounded env29487 := by
  intro p hp
  have h : env29487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29486_29487 : H12AffineEnvironment.transform 14 2129 env29486 = env29487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env29486 == env29487) = true)

theorem identity29487 : scanCanonicalize (H12AffineFastState.compose env29487 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound29487 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29488 : List Nat := [2,4,8,16,32,64,8,256,512,272,293,4096,349,4113,372,35,4469,81,273,373,4405,32,16,374,349,64,293,4096,4469,80,304,341,257,33,4404,513]

theorem envBound29488 : H12AffineFastState.Bounded env29488 := by
  intro p hp
  have h : env29488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29487_29488 : H12AffineEnvironment.transform 10 293 env29487 = env29488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env29487 == env29488) = true)

theorem identity29488 : scanCanonicalize (H12AffineFastState.compose env29488 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound29488 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env29489 : List Nat := [2,4,8,16,32,64,8,256,64,272,293,4096,349,4113,372,35,4469,81,273,373,4405,32,16,374,349,64,293,4096,4469,80,304,341,257,33,4404,65]

theorem envBound29489 : H12AffineFastState.Bounded env29489 := by
  intro p hp
  have h : env29489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29488_29489 : H12AffineEnvironment.transform 8 64 env29488 = env29489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env29488 == env29489) = true)

theorem identity29489 : scanCanonicalize (H12AffineFastState.compose env29489 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound29489 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29490 : List Nat := [2,4,8,16,32,64,8,256,64,272,293,356,349,373,372,35,17,81,273,373,81,32,16,374,349,64,293,356,17,80,304,341,257,33,80,65]

theorem envBound29490 : H12AffineFastState.Bounded env29490 := by
  intro p hp
  have h : env29490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29489_29490 : H12AffineEnvironment.transform 11 356 env29489 = env29490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env29489 == env29490) = true)

theorem identity29490 : scanCanonicalize (H12AffineFastState.compose env29490 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29490 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env29491 : List Nat := [2,4,8,16,32,64,8,116,64,100,81,16,41,1,0,35,17,81,101,1,81,32,16,2,41,64,81,16,17,80,68,33,117,33,80,65]

theorem envBound29491 : H12AffineFastState.Bounded env29491 := by
  intro p hp
  have h : env29491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29490_29491 : H12AffineEnvironment.transform 7 116 env29490 = env29491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29490 == env29491) = true)

theorem identity29491 : scanCanonicalize (H12AffineFastState.compose env29491 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29492 : List Nat := [2,4,8,16,0,64,8,84,64,68,81,16,9,1,0,3,17,81,69,1,81,0,16,2,9,64,81,16,17,80,68,1,85,1,80,65]

theorem envBound29492 : H12AffineFastState.Bounded env29492 := by
  intro p hp
  have h : env29492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29491_29492 : H12AffineEnvironment.transform 4 0 env29491 = env29492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29491 == env29492) = true)

theorem identity29492 : scanCanonicalize (H12AffineFastState.compose env29492 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29493 : List Nat := [2,4,8,0,0,64,8,68,64,68,65,0,9,1,0,3,1,65,69,1,65,0,0,2,9,64,65,0,1,64,68,1,69,1,64,65]

theorem envBound29493 : H12AffineFastState.Bounded env29493 := by
  intro p hp
  have h : env29493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29492_29493 : H12AffineEnvironment.transform 3 0 env29492 = env29493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29492 == env29493) = true)

theorem identity29493 : scanCanonicalize (H12AffineFastState.compose env29493 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound29493 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29494 : List Nat := [2,4,8,0,0,0,8,4,0,4,1,0,9,1,0,3,1,1,5,1,1,0,0,2,9,0,1,0,1,0,4,1,5,1,0,1]

theorem envBound29494 : H12AffineFastState.Bounded env29494 := by
  intro p hp
  have h : env29494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29493_29494 : H12AffineEnvironment.transform 5 0 env29493 = env29494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env29493 == env29494) = true)

def env29495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,17,95497,8192,64,23809,5393,45404,262145,61705,318549,257,21792,46093,120406]

theorem envBound29495 : H12AffineFastState.Bounded env29495 := by
  intro p hp
  have h : env29495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29480_29495 : H12AffineEnvironment.transform 16 49169 env29480 = env29495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29480 == env29495) = true)

theorem identity29495 : scanCanonicalize (H12AffineFastState.compose env29495 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound29495 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130175,1025,32769,58396,119926,17,95497,8192,64,23809,5393,45404,130174,61705,73770,257,21792,46093,120406]

theorem envBound29496 : H12AffineFastState.Bounded env29496 := by
  intro p hp
  have h : env29496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29495_29496 : H12AffineEnvironment.transform 17 130175 env29495 = env29496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env29495 == env29496) = true)

theorem identity29496 : scanCanonicalize (H12AffineFastState.compose env29496 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29496 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env29497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,16401,97407,1025,1,25628,87158,17,95497,8192,64,23809,5393,12636,97406,28937,73770,257,21792,13325,87638]

theorem envBound29497 : H12AffineFastState.Bounded env29497 := by
  intro p hp
  have h : env29497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29496_29497 : H12AffineEnvironment.transform 14 0 env29496 = env29497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29496 == env29497) = true)

theorem identity29497 : scanCanonicalize (H12AffineFastState.compose env29497 (packedSelected [0,1,3,5,7,8,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound29497 : packedSelected [0,1,3,5,7,8,14,15,23] rootPS < 2^1333 := by decide +kernel

def env29498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,0,65536,13341,67699,1025,1,4112,73850,17,65797,8192,64,10509,5393,12636,67698,1285,73770,257,8492,13325,74330]

theorem envBound29498 : H12AffineFastState.Bounded env29498 := by
  intro p hp
  have h : env29498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29497_29498 : H12AffineEnvironment.transform 13 13324 env29497 = env29498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env29497 == env29498) = true)

theorem identity29498 : scanCanonicalize (H12AffineFastState.compose env29498 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29498 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29499 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,65536,13341,67619,1025,1,4112,73770,17,65797,8192,16,10509,5393,12556,67618,1285,73770,257,8492,13325,74250]

theorem envBound29499 : H12AffineFastState.Bounded env29499 := by
  intro p hp
  have h : env29499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29498_29499 : H12AffineEnvironment.transform 5 16 env29498 = env29499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29498 == env29499) = true)

theorem identity29499 : scanCanonicalize (H12AffineFastState.compose env29499 (packedSelected [0,3,4,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 6707) := by decide +kernel

theorem selectedBound29499 : packedSelected [0,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env29500 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,6707,13341,4624,1025,1,4112,14873,17,6966,8192,16,10509,5393,12556,4625,1285,14873,257,8492,13325,14393]

theorem envBound29500 : H12AffineFastState.Bounded env29500 := by
  intro p hp
  have h : env29500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29499_29500 : H12AffineEnvironment.transform 15 6707 env29499 = env29500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6707 env29499 == env29500) = true)

theorem identity29500 : scanCanonicalize (H12AffineFastState.compose env29500 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29500 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29501 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,6707,5393,4624,1025,1,4112,6933,17,6966,268,16,2049,5393,4096,4625,1285,6933,257,32,5377,6453]

theorem envBound29501 : H12AffineFastState.Bounded env29501 := by
  intro p hp
  have h : env29501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29500_29501 : H12AffineEnvironment.transform 12 268 env29500 = env29501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29500 == env29501) = true)

theorem identity29501 : scanCanonicalize (H12AffineFastState.compose env29501 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound29501 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29502 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1077,268,309,0,3590,292,1573,1025,1,1061,3872,17,3843,268,16,2049,292,1077,1572,1285,3872,257,32,308,3328]

theorem envBound29502 : H12AffineFastState.Bounded env29502 := by
  intro p hp
  have h : env29502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29501_29502 : H12AffineEnvironment.transform 11 1077 env29501 = env29502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env29501 == env29502) = true)

theorem identity29502 : scanCanonicalize (H12AffineFastState.compose env29502 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound29502 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env29503 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,1077,268,309,0,775,292,1573,1025,1,1061,545,17,514,268,16,1280,292,1077,1572,1285,545,257,32,308,1]

theorem envBound29503 : H12AffineFastState.Bounded env29503 := by
  intro p hp
  have h : env29503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29502_29503 : H12AffineEnvironment.transform 10 1281 env29502 = env29503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env29502 == env29503) = true)

theorem identity29503 : scanCanonicalize (H12AffineFastState.compose env29503 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound29503 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29504 : List Nat := [2,4,8,16,32,16,8,256,512,784,529,805,268,309,0,775,292,309,785,1,821,545,17,514,268,16,528,292,805,308,533,545,257,32,308,1]

theorem envBound29504 : H12AffineFastState.Bounded env29504 := by
  intro p hp
  have h : env29504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29503_29504 : H12AffineEnvironment.transform 9 784 env29503 = env29504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env29503 == env29504) = true)

theorem identity29504 : scanCanonicalize (H12AffineFastState.compose env29504 (packedSelected [0,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29504 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env29505 : List Nat := [2,4,8,16,32,16,8,37,512,565,529,512,41,16,0,546,1,16,564,1,528,545,17,514,41,16,528,1,512,17,533,545,36,32,17,1]

theorem envBound29505 : H12AffineFastState.Bounded env29505 := by
  intro p hp
  have h : env29505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29504_29505 : H12AffineEnvironment.transform 7 37 env29504 = env29505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29504 == env29505) = true)

theorem identity29505 : scanCanonicalize (H12AffineFastState.compose env29505 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29505 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env29506 : List Nat := [2,4,8,16,32,16,8,37,0,53,17,0,41,16,0,34,1,16,52,1,16,33,17,2,41,16,16,1,0,17,21,33,36,32,17,1]

theorem envBound29506 : H12AffineFastState.Bounded env29506 := by
  intro p hp
  have h : env29506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29505_29506 : H12AffineEnvironment.transform 8 0 env29505 = env29506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29505 == env29506) = true)

theorem identity29506 : scanCanonicalize (H12AffineFastState.compose env29506 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29507 : List Nat := [2,4,8,16,10,16,8,15,0,31,17,0,3,16,0,8,1,16,30,1,16,11,17,2,3,16,16,1,0,17,21,11,14,10,17,1]

theorem envBound29507 : H12AffineFastState.Bounded env29507 := by
  intro p hp
  have h : env29507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29506_29507 : H12AffineEnvironment.transform 4 10 env29506 = env29507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29506 == env29507) = true)

def env29508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272392,180224,95497,8193,64,23808,185600,45405,262145,143640,400453,257,21792,46092,202310]

theorem envBound29508 : H12AffineFastState.Bounded env29508 := by
  intro p hp
  have h : env29508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29479_29508 : H12AffineEnvironment.transform 6 9 env29479 = env29508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29479 == env29508) = true)

def env29509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,16,95497,8193,64,23808,5392,45405,262145,61704,318549,257,21792,46092,120406]

theorem envBound29509 : H12AffineFastState.Bounded env29509 := by
  intro p hp
  have h : env29509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29508_29509 : H12AffineEnvironment.transform 16 49168 env29508 = env29509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29508 == env29509) = true)

theorem identity29509 : scanCanonicalize (H12AffineFastState.compose env29509 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound29509 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,49168,262144,1025,32769,58396,272392,16,3,8193,64,23808,5392,45405,262145,61704,318549,257,21792,46092,41820]

theorem envBound29510 : H12AffineFastState.Bounded env29510 := by
  intro p hp
  have h : env29510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29509_29510 : H12AffineEnvironment.transform 15 29962 env29509 = env29510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env29509 == env29510) = true)

theorem identity29510 : scanCanonicalize (H12AffineFastState.compose env29510 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound29510 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,49168,35109,1025,32769,58396,41261,16,3,8193,64,23808,5392,45405,35108,61704,21872,257,21792,46092,41820]

theorem envBound29511 : H12AffineFastState.Bounded env29511 := by
  intro p hp
  have h : env29511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29510_29511 : H12AffineEnvironment.transform 17 35109 env29510 = env29511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env29510 == env29511) = true)

theorem identity29511 : scanCanonicalize (H12AffineFastState.compose env29511 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound29511 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env29512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,35,46393,35109,1025,32769,37173,41261,16,3,8193,64,10281,5392,45405,35108,33825,8281,257,8201,46092,41820]

theorem envBound29512 : H12AffineFastState.Bounded env29512 := by
  intro p hp
  have h : env29512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29511_29512 : H12AffineEnvironment.transform 13 13609 env29511 = env29512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env29511 == env29512) = true)

theorem identity29512 : scanCanonicalize (H12AffineFastState.compose env29512 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29512 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env29513 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13609,32768,35,46393,35109,1025,32769,37173,41261,16,3,8193,17,10281,5392,45324,35108,33825,8200,257,8201,46092,41741]

theorem envBound29513 : H12AffineFastState.Bounded env29513 := by
  intro p hp
  have h : env29513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29512_29513 : H12AffineEnvironment.transform 5 17 env29512 = env29513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29512 == env29513) = true)

theorem identity29513 : scanCanonicalize (H12AffineFastState.compose env29513 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29513 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29514 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,13324,32768,35,46108,34816,1025,32769,36880,40968,16,3,8193,17,10281,5173,45097,34817,33825,8200,36,8201,46092,41512]

theorem envBound29514 : H12AffineFastState.Bounded env29514 := by
  intro p hp
  have h : env29514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29513_29514 : H12AffineEnvironment.transform 7 37 env29513 = env29514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29513 == env29514) = true)

theorem identity29514 : scanCanonicalize (H12AffineFastState.compose env29514 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound29514 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env29515 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,32768,35,37940,34816,1025,32769,36880,32800,16,3,41,17,2049,5173,36865,34817,33825,32,36,33,37924,33280]

theorem envBound29515 : H12AffineFastState.Bounded env29515 := by
  intro p hp
  have h : env29515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29514_29515 : H12AffineEnvironment.transform 12 40 env29514 = env29515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env29514 == env29515) = true)

theorem identity29515 : scanCanonicalize (H12AffineFastState.compose env29515 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29515 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29516 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,1,35,5173,2049,1025,0,4113,33,16,3,41,17,2049,5173,4096,2048,1056,32,36,33,5157,513]

theorem envBound29516 : H12AffineFastState.Bounded env29516 := by
  intro p hp
  have h : env29516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29515_29516 : H12AffineEnvironment.transform 14 1 env29515 = env29516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29515 == env29516) = true)

theorem identity29516 : scanCanonicalize (H12AffineFastState.compose env29516 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound29516 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29517 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,40,2049,1,35,2064,2049,1025,0,3124,33,16,3,41,17,2049,2064,3109,2048,1056,32,36,33,2048,513]

theorem envBound29517 : H12AffineFastState.Bounded env29517 := by
  intro p hp
  have h : env29517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29516_29517 : H12AffineEnvironment.transform 11 3109 env29516 = env29517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env29516 == env29517) = true)

theorem identity29517 : scanCanonicalize (H12AffineFastState.compose env29517 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29517 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29518 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2064,40,2049,1,35,2064,2049,52,0,2049,33,16,3,41,17,2049,2064,2064,2048,21,32,36,33,2048,513]

theorem envBound29518 : H12AffineFastState.Bounded env29518 := by
  intro p hp
  have h : env29518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29517_29518 : H12AffineEnvironment.transform 9 53 env29517 = env29518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29517 == env29518) = true)

theorem identity29518 : scanCanonicalize (H12AffineFastState.compose env29518 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound29518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29519 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,512,40,529,1,35,512,529,52,0,529,33,16,3,41,17,529,512,512,528,21,32,36,33,528,513]

theorem envBound29519 : H12AffineFastState.Bounded env29519 := by
  intro p hp
  have h : env29519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29518_29519 : H12AffineEnvironment.transform 10 528 env29518 = env29519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env29518 == env29519) = true)

theorem identity29519 : scanCanonicalize (H12AffineFastState.compose env29519 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound29519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29520 : List Nat := [2,4,8,16,32,17,9,37,27,53,11,27,40,10,1,35,27,10,52,0,10,33,16,3,41,17,10,27,27,11,21,32,36,33,11,26]

theorem envBound29520 : H12AffineFastState.Bounded env29520 := by
  intro p hp
  have h : env29520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29519_29520 : H12AffineEnvironment.transform 8 27 env29519 = env29520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env29519 == env29520) = true)

def env29521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,17,95497,8193,64,23808,5393,45405,262145,61705,318548,257,21792,46092,120407]

theorem envBound29521 : H12AffineFastState.Bounded env29521 := by
  intro p hp
  have h : env29521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29508_29521 : H12AffineEnvironment.transform 16 49169 env29508 = env29521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29508 == env29521) = true)

theorem identity29521 : scanCanonicalize (H12AffineFastState.compose env29521 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound29521 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89378,1025,32769,58397,95530,17,95497,8193,64,23808,5393,45405,89379,61705,98678,257,21792,46092,120407]

theorem envBound29522 : H12AffineFastState.Bounded env29522 := by
  intro p hp
  have h : env29522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29521_29522 : H12AffineEnvironment.transform 17 89378 env29521 = env29522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env29521 == env29522) = true)

theorem identity29522 : scanCanonicalize (H12AffineFastState.compose env29522 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54643) := by decide +kernel

theorem selectedBound29522 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54643,49169,34897,1025,32769,58397,41049,17,41082,8193,64,23808,5393,45405,34896,61705,21509,257,21792,46092,804]

theorem envBound29523 : H12AffineFastState.Bounded env29523 := by
  intro p hp
  have h : env29523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29522_29523 : H12AffineEnvironment.transform 15 54643 env29522 = env29523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54643 env29522 == env29523) = true)

theorem identity29523 : scanCanonicalize (H12AffineFastState.compose env29523 (packedSelected [0,4,14,18,20,22,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29523 : packedSelected [0,4,14,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env29524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,41342,46108,34897,1025,32769,36880,41049,17,41082,8193,64,10509,5393,45405,34896,34052,8200,257,8493,46092,804]

theorem envBound29524 : H12AffineFastState.Bounded env29524 := by
  intro p hp
  have h : env29524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29523_29524 : H12AffineEnvironment.transform 13 13325 env29523 = env29524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29523 == env29524) = true)

theorem identity29524 : scanCanonicalize (H12AffineFastState.compose env29524 (packedSelected [2,3,6,9,10,11,14,16,18,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29524 : packedSelected [2,3,6,9,10,11,14,16,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env29525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8495,13389,2048,1025,80,4161,8200,17,8235,8193,64,10509,5393,12556,2049,1365,8200,257,8493,13405,804]

theorem envBound29525 : H12AffineFastState.Bounded env29525 := by
  intro p hp
  have h : env29525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29524_29525 : H12AffineEnvironment.transform 14 81 env29524 = env29525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29524 == env29525) = true)

theorem identity29525 : scanCanonicalize (H12AffineFastState.compose env29525 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound29525 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env29526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5488,81,82,5424,2048,1025,80,4161,373,17,342,380,64,2160,5393,4209,2049,1365,373,257,80,5408,804]

theorem envBound29526 : H12AffineFastState.Bounded env29526 := by
  intro p hp
  have h : env29526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29525_29526 : H12AffineEnvironment.transform 12 381 env29525 = env29526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env29525 == env29526) = true)

theorem identity29526 : scanCanonicalize (H12AffineFastState.compose env29526 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29526 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29527 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,268,5377,32,35,5424,2048,1025,33,4144,260,17,295,269,49,2049,5393,4096,2049,1316,260,257,33,5408,804]

theorem envBound29527 : H12AffineFastState.Bounded env29527 := by
  intro p hp
  have h : env29527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29526_29527 : H12AffineEnvironment.transform 5 49 env29526 = env29527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29526 == env29527) = true)

theorem identity29527 : scanCanonicalize (H12AffineFastState.compose env29527 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29527 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29528 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5377,0,3,5392,2048,1025,1,4112,260,17,263,269,17,2049,5393,4096,2049,1284,260,257,1,5376,772]

theorem envBound29528 : H12AffineFastState.Bounded env29528 := by
  intro p hp
  have h : env29528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29527_29528 : H12AffineEnvironment.transform 4 0 env29527 = env29528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29527 == env29528) = true)

theorem identity29528 : scanCanonicalize (H12AffineFastState.compose env29528 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound29528 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env29529 : List Nat := [2,4,8,16,0,17,9,256,512,1024,783,4096,268,5377,0,3,5392,783,1025,1,4112,260,17,263,269,17,782,5393,4096,782,1284,260,257,1,5376,772]

theorem envBound29529 : H12AffineFastState.Bounded env29529 := by
  intro p hp
  have h : env29529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29528_29529 : H12AffineEnvironment.transform 10 783 env29528 = env29529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env29528 == env29529) = true)

theorem identity29529 : scanCanonicalize (H12AffineFastState.compose env29529 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29529 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29530 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,8,5125,0,3,5140,523,1025,1,4112,0,17,3,9,17,522,5141,4096,522,1024,0,5,1,5124,512]

theorem envBound29530 : H12AffineFastState.Bounded env29530 := by
  intro p hp
  have h : env29530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29529_29530 : H12AffineEnvironment.transform 7 4 env29529 = env29530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29529 == env29530) = true)

def env29531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,180225,95496,8328,64,4486408,185601,45525,262144,143640,4338764,257,21792,46213,202447]

theorem envBound29531 : H12AffineFastState.Bounded env29531 := by
  intro p hp
  have h : env29531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29447_29531 : H12AffineEnvironment.transform 22 180225 env29447 = env29531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env29447 == env29531) = true)

def env29532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272512,180225,95496,8328,64,23944,185601,45525,262144,143640,400588,257,21792,46213,202447]

theorem envBound29532 : H12AffineFastState.Bounded env29532 := by
  intro p hp
  have h : env29532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29531_29532 : H12AffineEnvironment.transform 21 272512 env29531 = env29532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29531 == env29532) = true)

theorem identity29532 : scanCanonicalize (H12AffineFastState.compose env29532 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound29532 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4161,272512,62661,95496,8328,64,23944,57797,45525,262144,1500,272392,257,21792,46213,74251]

theorem envBound29533 : H12AffineFastState.Bounded env29533 := by
  intro p hp
  have h : env29533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29532_29533 : H12AffineEnvironment.transform 16 13508 env29532 = env29533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env29532 == env29533) = true)

theorem identity29533 : scanCanonicalize (H12AffineFastState.compose env29533 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29533 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env29534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,262144,1025,32769,4161,272512,62661,21762,8328,64,23944,57797,45525,262144,1500,272392,257,21792,46213,513]

theorem envBound29534 : H12AffineFastState.Bounded env29534 := by
  intro p hp
  have h : env29534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29533_29534 : H12AffineEnvironment.transform 15 8202 env29533 = env29534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29533 == env29534) = true)

theorem identity29534 : scanCanonicalize (H12AffineFastState.compose env29534 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound29534 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env29535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,2557,1025,32769,4161,8573,62661,21762,8328,64,23944,57797,45525,2557,1500,8693,257,21792,46213,513]

theorem envBound29535 : H12AffineFastState.Bounded env29535 := by
  intro p hp
  have h : env29535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29534_29535 : H12AffineEnvironment.transform 17 2557 env29534 = env29535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env29534 == env29535) = true)

theorem identity29535 : scanCanonicalize (H12AffineFastState.compose env29535 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29535 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env29536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,13508,2557,1025,0,4161,8573,29892,21762,8328,64,23944,25028,12756,2557,1500,8693,257,21792,13444,513]

theorem envBound29536 : H12AffineFastState.Bounded env29536 := by
  intro p hp
  have h : env29536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29535_29536 : H12AffineEnvironment.transform 14 1 env29535 = env29536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29535 == env29536) = true)

theorem identity29536 : scanCanonicalize (H12AffineFastState.compose env29536 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound29536 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env29537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,1,8202,13508,2557,1025,0,4161,8573,8525,139,8328,64,2049,13389,12756,2557,1500,8693,257,169,13444,513]

theorem envBound29537 : H12AffineFastState.Bounded env29537 := by
  intro p hp
  have h : env29537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29536_29537 : H12AffineEnvironment.transform 13 5513 env29536 = env29537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29536 == env29537) = true)

theorem identity29537 : scanCanonicalize (H12AffineFastState.compose env29537 (packedSelected [0,2,6,7,17] rootPS)) = affineNative (2^(12+1) ^^^ 6493) := by decide +kernel

theorem selectedBound29537 : packedSelected [0,2,6,7,17] rootPS < 2^1333 := by decide +kernel

def env29538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6493,5513,1,6487,3481,2557,1025,0,4161,6176,6160,139,6613,64,2049,3344,2185,2557,1500,6312,257,169,3545,513]

theorem envBound29538 : H12AffineFastState.Bounded env29538 := by
  intro p hp
  have h : env29538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29537_29538 : H12AffineEnvironment.transform 12 6493 env29537 = env29538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6493 env29537 == env29538) = true)

theorem identity29538 : scanCanonicalize (H12AffineFastState.compose env29538 (packedSelected [0,1,2,3,5,6,7,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29538 : packedSelected [0,1,2,3,5,6,7,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6493,5377,1,6487,3345,2421,1025,0,4161,6176,6160,3,6493,64,2049,3344,2049,2421,1364,6176,257,33,3409,513]

theorem envBound29539 : H12AffineFastState.Bounded env29539 := by
  intro p hp
  have h : env29539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29538_29539 : H12AffineEnvironment.transform 6 8 env29538 = env29539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29538 == env29539) = true)

theorem identity29539 : scanCanonicalize (H12AffineFastState.compose env29539 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound29539 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env29540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2048,349,3329,1,343,3345,2421,1025,0,2113,32,16,3,349,64,2049,3344,2049,2421,1364,32,257,33,3409,513]

theorem envBound29540 : H12AffineFastState.Bounded env29540 := by
  intro p hp
  have h : env29540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29539_29540 : H12AffineEnvironment.transform 11 2048 env29539 = env29540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env29539 == env29540) = true)

theorem identity29540 : scanCanonicalize (H12AffineFastState.compose env29540 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound29540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1573,1573,349,804,1,343,820,1872,1025,0,1636,32,16,3,349,64,1572,821,1572,1872,1364,32,257,33,884,513]

theorem envBound29541 : H12AffineFastState.Bounded env29541 := by
  intro p hp
  have h : env29541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29540_29541 : H12AffineEnvironment.transform 10 1573 env29540 = env29541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env29540 == env29541) = true)

theorem identity29541 : scanCanonicalize (H12AffineFastState.compose env29541 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29541 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29542 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1573,1573,268,804,1,262,820,1793,1025,0,1589,32,16,3,268,17,1572,821,1572,1793,1285,32,257,33,805,513]

theorem envBound29542 : H12AffineFastState.Bounded env29542 := by
  intro p hp
  have h : env29542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29541_29542 : H12AffineEnvironment.transform 5 17 env29541 = env29542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29541 == env29542) = true)

theorem identity29542 : scanCanonicalize (H12AffineFastState.compose env29542 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound29542 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29543 : List Nat := [2,4,8,16,32,17,8,53,512,1024,1573,1573,57,529,1,51,513,1588,1025,0,1589,32,16,3,57,17,1572,512,1572,1588,1072,32,52,33,528,513]

theorem envBound29543 : H12AffineFastState.Bounded env29543 := by
  intro p hp
  have h : env29543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29542_29543 : H12AffineEnvironment.transform 7 53 env29542 = env29543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env29542 == env29543) = true)

theorem identity29543 : scanCanonicalize (H12AffineFastState.compose env29543 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound29543 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29544 : List Nat := [2,4,8,16,32,17,8,53,512,564,17,17,57,529,1,51,513,0,565,0,1,32,16,3,57,17,16,512,16,0,516,32,52,33,528,513]

theorem envBound29544 : H12AffineFastState.Bounded env29544 := by
  intro p hp
  have h : env29544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29543_29544 : H12AffineEnvironment.transform 9 564 env29543 = env29544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env29543 == env29544) = true)

def env29545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,272513,180225,95496,8328,64,23945,185601,45525,262144,143640,400589,257,21792,46213,202447]

theorem envBound29545 : H12AffineFastState.Bounded env29545 := by
  intro p hp
  have h : env29545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29531_29545 : H12AffineEnvironment.transform 21 272513 env29531 = env29545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29531 == env29545) = true)

theorem identity29545 : scanCanonicalize (H12AffineFastState.compose env29545 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29545 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140421,272513,144597,95496,8328,64,23945,139733,17665,262144,143640,400589,257,21792,16465,202447]

theorem envBound29546 : H12AffineFastState.Bounded env29546 := by
  intro p hp
  have h : env29546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29545_29546 : H12AffineEnvironment.transform 14 29908 env29545 = env29546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29545 == env29546) = true)

theorem identity29546 : scanCanonicalize (H12AffineFastState.compose env29546 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound29546 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env29547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,76158,1025,29909,140421,66047,144597,95496,8328,64,23945,139733,17665,76158,143640,210355,257,21792,16465,202447]

theorem envBound29547 : H12AffineFastState.Bounded env29547 := by
  intro p hp
  have h : env29547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29546_29547 : H12AffineEnvironment.transform 17 76158 env29546 = env29547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env29546 == env29547) = true)

def env29548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,76158,1025,29789,140301,65911,144477,95496,8192,64,23809,139613,17665,76158,143640,210235,257,21792,16465,202311]

theorem envBound29548 : H12AffineFastState.Bounded env29548 := by
  intro p hp
  have h : env29548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29547_29548 : H12AffineEnvironment.transform 6 8 env29547 = env29548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29547 == env29548) = true)

theorem identity29548 : scanCanonicalize (H12AffineFastState.compose env29548 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound29548 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,76158,1025,29789,77899,65911,73755,95496,8192,64,23809,79131,17665,76158,75102,8573,257,21792,16465,513]

theorem envBound29549 : H12AffineFastState.Bounded env29549 := by
  intro p hp
  have h : env29549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29548_29549 : H12AffineEnvironment.transform 16 70726 env29548 = env29549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env29548 == env29549) = true)

theorem identity29549 : scanCanonicalize (H12AffineFastState.compose env29549 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29549 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,70726,76158,1025,8541,77899,65911,73755,73736,8192,64,2049,79131,4097,76158,75102,8573,257,32,5457,513]

theorem envBound29550 : H12AffineFastState.Bounded env29550 := by
  intro p hp
  have h : env29550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29549_29550 : H12AffineEnvironment.transform 13 5376 env29549 = env29550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29549 == env29550) = true)

theorem identity29550 : scanCanonicalize (H12AffineFastState.compose env29550 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29550 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env29551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,70726,67618,1025,1,69911,65911,65863,65876,348,64,2049,70727,4097,67618,66562,33,257,32,5457,513]

theorem envBound29551 : H12AffineFastState.Bounded env29551 := by
  intro p hp
  have h : env29551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29550_29551 : H12AffineEnvironment.transform 12 348 env29550 = env29551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29550 == env29551) = true)

theorem identity29551 : scanCanonicalize (H12AffineFastState.compose env29551 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound29551 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env29552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5376,0,65536,70726,66915,1025,1,69911,65911,65863,65876,348,64,1344,70727,4097,66915,66562,33,257,32,5457,513]

theorem envBound29552 : H12AffineFastState.Bounded env29552 := by
  intro p hp
  have h : env29552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29551_29552 : H12AffineEnvironment.transform 10 1345 env29551 = env29552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29551 == env29552) = true)

theorem identity29552 : scanCanonicalize (H12AffineFastState.compose env29552 (packedSelected [0,1,4,5,7,9,10,18] rootPS)) = affineNative (2^(15+1) ^^^ 5207) := by decide +kernel

theorem selectedBound29552 : packedSelected [0,1,4,5,7,9,10,18] rootPS < 2^1333 := by decide +kernel

def env29553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5376,0,5207,17,4404,1025,1,1344,5408,5392,5379,348,64,1344,16,4097,4404,4181,33,257,32,5457,513]

theorem envBound29553 : H12AffineFastState.Bounded env29553 := by
  intro p hp
  have h : env29553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29552_29553 : H12AffineEnvironment.transform 15 5207 env29552 = env29553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5207 env29552 == env29553) = true)

theorem identity29553 : scanCanonicalize (H12AffineFastState.compose env29553 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound29553 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1360,348,80,0,263,17,1124,1025,1,1344,112,64,83,348,64,1344,16,1361,1124,1285,33,257,32,1,513]

theorem envBound29554 : H12AffineFastState.Bounded env29554 := by
  intro p hp
  have h : env29554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29553_29554 : H12AffineEnvironment.transform 11 1360 env29553 = env29554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env29553 == env29554) = true)

theorem identity29554 : scanCanonicalize (H12AffineFastState.compose env29554 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29554 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29555 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,1280,268,0,0,263,17,1076,1025,1,1296,32,16,3,268,16,1296,16,1281,1076,1285,33,257,32,1,513]

theorem envBound29555 : H12AffineFastState.Bounded env29555 := by
  intro p hp
  have h : env29555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29554_29555 : H12AffineEnvironment.transform 5 16 env29554 = env29555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29554 == env29555) = true)

theorem identity29555 : scanCanonicalize (H12AffineFastState.compose env29555 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29555 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29556 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,16,268,0,0,263,17,292,273,1,0,32,16,3,268,16,0,16,17,292,21,33,257,32,1,513]

theorem envBound29556 : H12AffineFastState.Bounded env29556 := by
  intro p hp
  have h : env29556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29555_29556 : H12AffineEnvironment.transform 9 272 env29555 = env29556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29555 == env29556) = true)

theorem identity29556 : scanCanonicalize (H12AffineFastState.compose env29556 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29556 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29557 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,16,40,0,0,35,17,0,53,1,0,32,16,3,40,16,0,16,17,0,21,33,37,32,1,513]

theorem envBound29557 : H12AffineFastState.Bounded env29557 := by
  intro p hp
  have h : env29557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29556_29557 : H12AffineEnvironment.transform 7 36 env29556 = env29557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29556 == env29557) = true)

theorem identity29557 : scanCanonicalize (H12AffineFastState.compose env29557 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29557 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29558 : List Nat := [2,4,8,16,1,16,8,5,512,21,1,16,9,0,0,2,17,0,20,1,0,1,16,3,9,16,0,16,17,0,21,0,4,1,1,513]

theorem envBound29558 : H12AffineFastState.Bounded env29558 := by
  intro p hp
  have h : env29558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29557_29558 : H12AffineEnvironment.transform 4 1 env29557 = env29558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29557 == env29558) = true)

theorem identity29558 : scanCanonicalize (H12AffineFastState.compose env29558 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29559 : List Nat := [2,4,8,0,1,0,8,5,512,5,1,0,9,0,0,2,1,0,4,1,0,1,0,3,9,0,0,0,1,0,5,0,4,1,1,513]

theorem envBound29559 : H12AffineFastState.Bounded env29559 := by
  intro p hp
  have h : env29559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29558_29559 : H12AffineEnvironment.transform 3 0 env29558 = env29559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29558 == env29559) = true)

def env29560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,76158,1025,29788,140300,65910,144476,95496,8193,64,23808,139612,17665,76158,143640,210234,257,21792,16465,202310]

theorem envBound29560 : H12AffineFastState.Bounded env29560 := by
  intro p hp
  have h : env29560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29547_29560 : H12AffineEnvironment.transform 6 9 env29547 = env29560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29547 == env29560) = true)

theorem identity29560 : scanCanonicalize (H12AffineFastState.compose env29560 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound29560 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,131072,76158,1025,1,140300,65910,144476,65877,8193,64,10589,139612,12636,76158,143640,210234,257,8573,13324,202310]

theorem envBound29561 : H12AffineFastState.Bounded env29561 := by
  intro p hp
  have h : env29561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29560_29561 : H12AffineEnvironment.transform 13 13405 env29560 = env29561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env29560 == env29561) = true)

theorem identity29561 : scanCanonicalize (H12AffineFastState.compose env29561 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29561 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,0,65536,131072,67927,1025,1,132133,65910,136309,65877,40,64,2420,131445,4469,67927,135473,202003,257,340,5157,202310]

theorem envBound29562 : H12AffineFastState.Bounded env29562 := by
  intro p hp
  have h : env29562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29561_29562 : H12AffineEnvironment.transform 12 41 env29561 = env29562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29561 == env29562) = true)

theorem identity29562 : scanCanonicalize (H12AffineFastState.compose env29562 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 71011) := by decide +kernel

theorem selectedBound29562 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,0,65536,71011,67927,1025,1,69958,65910,65814,65877,40,64,2420,70678,4469,67927,66642,112,257,340,5157,805]

theorem envBound29563 : H12AffineFastState.Bounded env29563 := by
  intro p hp
  have h : env29563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29562_29563 : H12AffineEnvironment.transform 16 71011 env29562 = env29563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 71011 env29562 == env29563) = true)

theorem identity29563 : scanCanonicalize (H12AffineFastState.compose env29563 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29563 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,0,262,5221,2129,1025,1,4160,112,16,83,40,64,2420,5392,4469,2129,1364,112,257,340,5157,805]

theorem envBound29564 : H12AffineFastState.Bounded env29564 := by
  intro p hp
  have h : env29564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29563_29564 : H12AffineEnvironment.transform 15 262 env29563 = env29564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29563 == env29564) = true)

theorem identity29564 : scanCanonicalize (H12AffineFastState.compose env29564 (packedSelected [0,1,2,6,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound29564 : packedSelected [0,1,2,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,41,1076,0,262,1061,2129,1025,1,0,112,16,83,40,64,2420,1360,309,2129,1364,112,257,340,1125,805]

theorem envBound29565 : H12AffineFastState.Bounded env29565 := by
  intro p hp
  have h : env29565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29564_29565 : H12AffineEnvironment.transform 11 64 env29564 = env29565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env29564 == env29565) = true)

theorem identity29565 : scanCanonicalize (H12AffineFastState.compose env29565 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29565 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env29566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,64,41,1076,0,262,1061,81,1025,1,0,112,16,83,40,64,372,1360,309,81,1364,112,257,340,1125,805]

theorem envBound29566 : H12AffineFastState.Bounded env29566 := by
  intro p hp
  have h : env29566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29565_29566 : H12AffineEnvironment.transform 10 0 env29565 = env29566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29565 == env29566) = true)

theorem identity29566 : scanCanonicalize (H12AffineFastState.compose env29566 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29566 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29567 : List Nat := [2,4,8,16,32,64,9,37,512,1024,0,64,41,1076,0,35,1061,81,1025,1,0,112,16,83,40,64,81,1141,16,81,1137,112,36,113,1125,512]

theorem envBound29567 : H12AffineFastState.Bounded env29567 := by
  intro p hp
  have h : env29567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29566_29567 : H12AffineEnvironment.transform 7 37 env29566 = env29567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29566 == env29567) = true)

theorem identity29567 : scanCanonicalize (H12AffineFastState.compose env29567 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29568 : List Nat := [2,4,8,0,32,64,9,37,512,1024,0,64,41,1060,0,35,1061,65,1025,1,0,96,0,67,40,64,65,1125,0,65,1121,96,36,97,1125,512]

theorem envBound29568 : H12AffineFastState.Bounded env29568 := by
  intro p hp
  have h : env29568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29567_29568 : H12AffineEnvironment.transform 3 0 env29567 = env29568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29567 == env29568) = true)

theorem identity29568 : scanCanonicalize (H12AffineFastState.compose env29568 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound29568 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29569 : List Nat := [2,4,8,0,32,64,9,37,33,1024,0,64,41,1060,0,35,1061,65,1025,1,0,96,0,67,40,64,65,1125,0,65,1121,96,36,97,1125,33]

theorem envBound29569 : H12AffineFastState.Bounded env29569 := by
  intro p hp
  have h : env29569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29568_29569 : H12AffineEnvironment.transform 8 33 env29568 = env29569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env29568 == env29569) = true)

theorem identity29569 : scanCanonicalize (H12AffineFastState.compose env29569 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound29569 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29570 : List Nat := [2,4,8,0,32,33,9,37,33,1024,0,33,41,1060,0,35,1061,32,1025,1,0,1,0,34,40,33,32,1028,0,32,1024,1,36,0,1028,33]

theorem envBound29570 : H12AffineFastState.Bounded env29570 := by
  intro p hp
  have h : env29570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29569_29570 : H12AffineEnvironment.transform 5 33 env29569 = env29570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env29569 == env29570) = true)

theorem identity29570 : scanCanonicalize (H12AffineFastState.compose env29570 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29571 : List Nat := [2,4,8,0,0,1,9,5,1,1024,0,1,9,1028,0,3,1029,0,1025,1,0,1,0,2,8,1,0,1028,0,0,1024,1,4,0,1028,1]

theorem envBound29571 : H12AffineFastState.Bounded env29571 := by
  intro p hp
  have h : env29571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29570_29571 : H12AffineEnvironment.transform 4 0 env29570 = env29571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29570 == env29571) = true)

theorem identity29571 : scanCanonicalize (H12AffineFastState.compose env29571 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29571 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29572 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,1,9,1,0,3,0,0,4,1,0,1,0,2,8,1,0,1,0,0,5,1,4,0,1,1]

theorem envBound29572 : H12AffineFastState.Bounded env29572 := by
  intro p hp
  have h : env29572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29571_29572 : H12AffineEnvironment.transform 9 5 env29571 = env29572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29571 == env29572) = true)

theorem identity29572 : scanCanonicalize (H12AffineFastState.compose env29572 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29572 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29573 : List Nat := [2,1,8,0,0,1,9,0,1,0,0,1,9,1,0,3,0,0,1,1,0,1,0,2,8,1,0,1,0,0,0,1,1,0,1,1]

theorem envBound29573 : H12AffineFastState.Bounded env29573 := by
  intro p hp
  have h : env29573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29572_29573 : H12AffineEnvironment.transform 1 1 env29572 = env29573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29572 == env29573) = true)

def env29574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound29574 : H12AffineFastState.Bounded env29574 := by
  intro p hp
  have h : env29574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29146_29574 : H12AffineEnvironment.transform 26 30393345 env29146 = env29574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env29146 == env29574) = true)

def env29575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound29575 : H12AffineFastState.Bounded env29575 := by
  intro p hp
  have h : env29575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29574_29575 : H12AffineEnvironment.transform 18 1024 env29574 = env29575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29574 == env29575) = true)

theorem identity29575 : scanCanonicalize (H12AffineFastState.compose env29575 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41412) := by decide +kernel

theorem selectedBound29575 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21455301,18973837,2159765,418245,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound29576 : H12AffineFastState.Bounded env29576 := by
  intro p hp
  have h : env29576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29575_29576 : H12AffineEnvironment.transform 22 41412 env29575 = env29576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41412 env29575 == env29576) = true)

def env29577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21331969,18973837,2159765,294913,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound29577 : H12AffineFastState.Bounded env29577 := by
  intro p hp
  have h : env29577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29576_29577 : H12AffineEnvironment.transform 16 57796 env29576 = env29577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env29576 == env29577) = true)

def env29578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10280,1024,32769,2097152,4194304,41412,16777216,8328,64,21080105,18973837,2159765,43049,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound29578 : H12AffineFastState.Bounded env29578 := by
  intro p hp
  have h : env29578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29577_29578 : H12AffineEnvironment.transform 17 10280 env29577 = env29578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29577 == env29578) = true)

theorem identity29578 : scanCanonicalize (H12AffineFastState.compose env29578 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound29578 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10280,1024,32769,2097152,4194304,41412,138,8328,64,4303011,2196487,2159765,43049,75103,6382922,256,2188770,2196551,649]

theorem envBound29579 : H12AffineFastState.Bounded env29579 := by
  intro p hp
  have h : env29579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29578_29579 : H12AffineEnvironment.transform 23 138 env29578 = env29579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env29578 == env29579) = true)

def env29580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302891,2196487,2159645,43049,75103,6382922,256,2188650,2196551,513]

theorem envBound29580 : H12AffineFastState.Bounded env29580 := by
  intro p hp
  have h : env29580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29579_29580 : H12AffineEnvironment.transform 6 8 env29579 = env29580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29579 == env29580) = true)

theorem identity29580 : scanCanonicalize (H12AffineFastState.compose env29580 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 50497) := by decide +kernel

theorem selectedBound29580 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env29581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,50497,4194304,41292,2,8192,64,4302891,82246,12636,43049,75103,4300811,256,106539,82182,513]

theorem envBound29581 : H12AffineFastState.Bounded env29581 := by
  intro p hp
  have h : env29581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29580_29581 : H12AffineEnvironment.transform 20 50497 env29580 = env29581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50497 env29580 == env29581) = true)

theorem identity29581 : scanCanonicalize (H12AffineFastState.compose env29581 (packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29581 : packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS < 2^1333 := by decide +kernel

def env29582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57676,10280,1024,32769,50497,4194304,41292,2,8192,64,4237692,16401,12636,43049,9224,4235612,256,41340,16465,513]

theorem envBound29582 : H12AffineFastState.Bounded env29582 := by
  intro p hp
  have h : env29582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29581_29582 : H12AffineEnvironment.transform 15 343 env29581 = env29582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29581 == env29582) = true)

theorem identity29582 : scanCanonicalize (H12AffineFastState.compose env29582 (packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound29582 : packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57676,10280,1024,32769,50497,41340,41292,2,8192,64,2048,16401,12636,43049,9224,32,256,41340,16465,513]

theorem envBound29583 : H12AffineFastState.Bounded env29583 := by
  intro p hp
  have h : env29583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29582_29583 : H12AffineEnvironment.transform 21 41340 env29582 = env29583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env29582 == env29583) = true)

theorem identity29583 : scanCanonicalize (H12AffineFastState.compose env29583 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29583 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16400,10280,1024,8541,25629,32,16,2,8192,64,2048,16401,12636,2421,9224,32,256,32,16465,513]

theorem envBound29584 : H12AffineFastState.Bounded env29584 := by
  intro p hp
  have h : env29584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29583_29584 : H12AffineEnvironment.transform 14 8540 env29583 = env29584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29583 == env29584) = true)

def env29585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,3,8193,64,4302890,2196487,2159644,43049,75103,6382922,256,2188651,2196551,512]

theorem envBound29585 : H12AffineFastState.Bounded env29585 := by
  intro p hp
  have h : env29585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29579_29585 : H12AffineEnvironment.transform 6 9 env29579 = env29585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29579 == env29585) = true)

theorem identity29585 : scanCanonicalize (H12AffineFastState.compose env29585 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound29585 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,32,41293,3,8193,64,108554,2196487,2159644,43049,75103,2188650,256,2188651,2196551,512]

theorem envBound29586 : H12AffineFastState.Bounded env29586 := by
  intro p hp
  have h : env29586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29585_29586 : H12AffineEnvironment.transform 21 32 env29585 = env29586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29585 == env29586) = true)

theorem identity29586 : scanCanonicalize (H12AffineFastState.compose env29586 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29586 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57677,10280,1024,32769,2097152,32,41293,3,8193,64,34817,2139148,2159644,43049,1364,2114913,256,2114912,2139212,512]

theorem envBound29587 : H12AffineFastState.Bounded env29587 := by
  intro p hp
  have h : env29587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29586_29587 : H12AffineEnvironment.transform 15 8203 env29586 = env29587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29586 == env29587) = true)

theorem identity29587 : scanCanonicalize (H12AffineFastState.compose env29587 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29587 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49216,2341,1024,32769,2097152,32,32832,3,268,64,34817,2131201,2151697,35108,1364,2114913,256,2114912,2131265,512]

theorem envBound29588 : H12AffineFastState.Bounded env29588 := by
  intro p hp
  have h : env29588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29587_29588 : H12AffineEnvironment.transform 12 269 env29587 = env29588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29587 == env29588) = true)

theorem identity29588 : scanCanonicalize (H12AffineFastState.compose env29588 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound29588 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49216,2341,1024,32769,50449,32,32832,3,268,64,34817,16400,4096,35108,1364,32880,256,32881,16464,512]

theorem envBound29589 : H12AffineFastState.Bounded env29589 := by
  intro p hp
  have h : env29589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29588_29589 : H12AffineEnvironment.transform 20 50449 env29588 = env29589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env29588 == env29589) = true)

theorem identity29589 : scanCanonicalize (H12AffineFastState.compose env29589 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21792) := by decide +kernel

theorem selectedBound29589 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21792,262,5472,2341,1024,21793,4145,32,21856,3,268,64,23841,16400,4096,23556,1364,21840,256,21841,16464,512]

theorem envBound29590 : H12AffineFastState.Bounded env29590 := by
  intro p hp
  have h : env29590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29589_29590 : H12AffineEnvironment.transform 14 21792 env29589 = env29590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21792 env29589 == env29590) = true)

theorem identity29590 : scanCanonicalize (H12AffineFastState.compose env29590 (packedSelected [6,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound29590 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env29591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,340,262,5472,2341,1024,341,4145,32,276,3,268,64,2389,5220,4096,2160,1364,292,256,293,5156,512]

theorem envBound29591 : H12AffineFastState.Bounded env29591 := by
  intro p hp
  have h : env29591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29590_29591 : H12AffineEnvironment.transform 13 5236 env29590 = env29591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env29590 == env29591) = true)

theorem identity29591 : scanCanonicalize (H12AffineFastState.compose env29591 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29591 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env29592 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,269,5125,293,262,5393,2341,1024,292,4145,32,276,3,268,49,2340,5141,4096,2049,1317,292,256,293,5156,512]

theorem envBound29592 : H12AffineFastState.Bounded env29592 := by
  intro p hp
  have h : env29592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29591_29592 : H12AffineEnvironment.transform 5 49 env29591 = env29592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29591 == env29592) = true)

theorem identity29592 : scanCanonicalize (H12AffineFastState.compose env29592 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29592 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env29593 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,9,5125,33,2,5141,2081,1024,32,4145,32,16,3,8,49,2080,5141,4096,2049,1057,32,4,33,5156,512]

theorem envBound29593 : H12AffineFastState.Bounded env29593 := by
  intro p hp
  have h : env29593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29592_29593 : H12AffineEnvironment.transform 7 4 env29592 = env29593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29592 == env29593) = true)

theorem identity29593 : scanCanonicalize (H12AffineFastState.compose env29593 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29593 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env29594 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,0,2,5141,2048,1024,1,4112,1,16,3,8,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound29594 : H12AffineFastState.Bounded env29594 := by
  intro p hp
  have h : env29594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29593_29594 : H12AffineEnvironment.transform 4 1 env29593 = env29594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29593 == env29594) = true)

def env29595 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1045,0,2,1029,2048,1024,1,0,1,16,3,8,16,2049,1029,16,2049,1024,1,4,0,1045,512]

theorem envBound29595 : H12AffineFastState.Bounded env29595 := by
  intro p hp
  have h : env29595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29594_29595 : H12AffineEnvironment.transform 11 16 env29594 = env29595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env29594 == env29595) = true)

def env29596 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1044,0,2,1028,2048,1024,1,1,1,16,3,8,16,2049,1028,17,2049,1024,1,4,0,1044,512]

theorem envBound29596 : H12AffineFastState.Bounded env29596 := by
  intro p hp
  have h : env29596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29594_29596 : H12AffineEnvironment.transform 11 17 env29594 = env29596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29594 == env29596) = true)

theorem identity29596 : scanCanonicalize (H12AffineFastState.compose env29596 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29597 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,1,0,2,17,2048,21,1,1,1,16,3,8,16,2049,17,17,2049,21,1,4,0,1,512]

theorem envBound29597 : H12AffineFastState.Bounded env29597 := by
  intro p hp
  have h : env29597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29596_29597 : H12AffineEnvironment.transform 9 21 env29596 = env29597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29596 == env29597) = true)

theorem identity29597 : scanCanonicalize (H12AffineFastState.compose env29597 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29598 : List Nat := [2,4,8,5,1,5,9,4,512,0,2048,4,9,1,0,2,4,2048,0,1,1,1,5,3,8,5,2049,4,4,2049,0,1,4,0,1,512]

theorem envBound29598 : H12AffineFastState.Bounded env29598 := by
  intro p hp
  have h : env29598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29597_29598 : H12AffineEnvironment.transform 3 5 env29597 = env29598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29597 == env29598) = true)

def leafEnv29598 : List Nat := [2,4,8,5,1,5,9,4,512,0,2048,4,9,1,0,2,4,2048,0,1,1,1,5,3,0,8,1,5,2049,4,4,2049,0,1,4,0,4,3,1,512,1,1,0]

def active29598 : List Nat := [0,1,2,8,10]

def tree29598 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29598 : H12WitnessSearch.Good tree29598 := H12GlobalWitnessIndex.good

theorem leafIdentity29598 : H12AffineFastState.composeSystem env29598 rootObs = leafEnv29598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29598 rootObs == leafEnv29598) = true)

theorem terminalChecked29598 : H12PackedTerminal.terminalCheckFast leafEnv29598 active29598 tree29598 = true := by decide +kernel

def env29599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10281,1024,32769,2097152,4194304,41412,16777216,8328,64,21080104,18973837,2159765,43048,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound29599 : H12AffineFastState.Bounded env29599 := by
  intro p hp
  have h : env29599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29577_29599 : H12AffineEnvironment.transform 17 10281 env29577 = env29599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29577 == env29599) = true)

theorem identity29599 : scanCanonicalize (H12AffineFastState.compose env29599 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound29599 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10281,1024,32769,2097152,4194304,41412,41310,8328,64,4262262,2172371,2159765,43048,99467,6407326,256,2212918,2172307,41821]

theorem envBound29600 : H12AffineFastState.Bounded env29600 := by
  intro p hp
  have h : env29600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29599_29600 : H12AffineEnvironment.transform 23 41310 env29599 = env29600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env29599 == env29600) = true)

theorem identity29600 : scanCanonicalize (H12AffineFastState.compose env29600 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29600 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57796,10281,1024,32769,2097152,4194304,41412,41310,8328,64,4205044,2098513,2159765,43048,41993,6349852,256,2155700,2098449,41821]

theorem envBound29601 : H12AffineFastState.Bounded env29601 := by
  intro p hp
  have h : env29601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29600_29601 : H12AffineEnvironment.transform 15 8322 env29600 = env29601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29600 == env29601) = true)

theorem identity29601 : scanCanonicalize (H12AffineFastState.compose env29601 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 29124) := by decide +kernel

theorem selectedBound29601 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env29602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29124,8322,4096,10281,1024,29125,2097152,4194304,20480,20634,8328,64,4205044,2098513,2098513,23020,21965,6297048,256,2102640,2098449,21145]

theorem envBound29602 : H12AffineFastState.Bounded env29602 := by
  intro p hp
  have h : env29602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29601_29602 : H12AffineEnvironment.transform 14 29124 env29601 = env29602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29124 env29601 == env29602) = true)

theorem identity29602 : scanCanonicalize (H12AffineFastState.compose env29602 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound29602 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env29603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29124,8322,4096,10281,1024,29125,2097152,169,20480,20634,8328,64,10589,2098513,2098513,23020,21965,2102641,256,2102640,2098449,21145]

theorem envBound29603 : H12AffineFastState.Bounded env29603 := by
  intro p hp
  have h : env29603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29602_29603 : H12AffineEnvironment.transform 21 169 env29602 = env29603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env29602 == env29603) = true)

theorem identity29603 : scanCanonicalize (H12AffineFastState.compose env29603 (packedSelected [0,1,2,3,6,7,16,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29603 : packedSelected [0,1,2,3,6,7,16,24,28] rootPS < 2^1333 := by decide +kernel

def env29604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8202,4096,10281,1024,29005,2097152,33,20480,20498,8192,64,10589,2098513,2098513,22884,21829,2102641,256,2102640,2098449,21009]

theorem envBound29604 : H12AffineFastState.Bounded env29604 := by
  intro p hp
  have h : env29604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29603_29604 : H12AffineEnvironment.transform 6 8 env29603 = env29604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29603 == env29604) = true)

theorem identity29604 : scanCanonicalize (H12AffineFastState.compose env29604 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 12621) := by decide +kernel

theorem selectedBound29604 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8202,4096,10281,1024,29005,12621,33,20480,20498,8192,64,10589,13340,13340,22884,21829,9276,256,9277,13404,21009]

theorem envBound29605 : H12AffineFastState.Bounded env29605 := by
  intro p hp
  have h : env29605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29604_29605 : H12AffineEnvironment.transform 20 12621 env29604 = env29605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12621 env29604 == env29605) = true)

theorem identity29605 : scanCanonicalize (H12AffineFastState.compose env29605 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29605 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env29606 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,28728,8202,4096,10281,1024,28729,12345,33,20480,20498,8192,64,10281,13340,13340,22544,21553,9276,116,9277,13404,21009]

theorem envBound29606 : H12AffineFastState.Bounded env29606 := by
  intro p hp
  have h : env29606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29605_29606 : H12AffineEnvironment.transform 7 116 env29605 = env29606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29605 == env29606) = true)

theorem identity29606 : scanCanonicalize (H12AffineFastState.compose env29606 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound29606 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env29607 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4112,8232,8202,4096,10281,1024,8233,12345,33,16,2,8192,64,10281,13340,13340,2048,1057,9276,116,9277,13404,513]

theorem envBound29607 : H12AffineFastState.Bounded env29607 := by
  intro p hp
  have h : env29607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29606_29607 : H12AffineEnvironment.transform 13 4112 env29606 = env29607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env29606 == env29607) = true)

theorem identity29607 : scanCanonicalize (H12AffineFastState.compose env29607 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 632) := by decide +kernel

theorem selectedBound29607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29608 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,632,4112,592,626,4096,2641,1024,593,4673,33,16,2,632,64,2641,5732,5732,2048,1057,1604,116,1605,5668,513]

theorem envBound29608 : H12AffineFastState.Bounded env29608 := by
  intro p hp
  have h : env29608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29607_29608 : H12AffineEnvironment.transform 12 632 env29607 = env29608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 632 env29607 == env29608) = true)

theorem identity29608 : scanCanonicalize (H12AffineFastState.compose env29608 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound29608 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env29609 : List Nat := [2,4,8,16,32,64,8,116,512,1024,592,4096,632,4112,592,626,4096,1,1024,593,4673,33,16,2,632,64,1,5732,5732,592,1057,1604,116,1605,5668,513]

theorem envBound29609 : H12AffineFastState.Bounded env29609 := by
  intro p hp
  have h : env29609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29608_29609 : H12AffineEnvironment.transform 10 592 env29608 = env29609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env29608 == env29609) = true)

theorem identity29609 : scanCanonicalize (H12AffineFastState.compose env29609 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound29609 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29610 : List Nat := [2,4,8,16,32,64,8,116,80,1024,0,4096,40,4112,0,34,4096,1,1024,1,4113,33,16,2,40,64,1,5172,5172,0,1057,1044,116,1045,5236,81]

theorem envBound29610 : H12AffineFastState.Bounded env29610 := by
  intro p hp
  have h : env29610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29609_29610 : H12AffineEnvironment.transform 8 80 env29609 = env29610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env29609 == env29610) = true)

theorem identity29610 : scanCanonicalize (H12AffineFastState.compose env29610 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound29610 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29611 : List Nat := [2,4,8,16,32,64,8,116,80,1024,0,1125,40,1141,0,34,1125,1,1024,1,1140,33,16,2,40,64,1,81,81,0,1057,1044,116,1045,17,81]

theorem envBound29611 : H12AffineFastState.Bounded env29611 := by
  intro p hp
  have h : env29611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29610_29611 : H12AffineEnvironment.transform 11 1125 env29610 = env29611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env29610 == env29611) = true)

theorem identity29611 : scanCanonicalize (H12AffineFastState.compose env29611 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29611 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29612 : List Nat := [2,4,8,16,32,64,8,116,80,21,0,112,40,96,0,34,112,1,21,1,97,33,16,2,40,64,1,81,81,0,52,1,116,0,17,81]

theorem envBound29612 : H12AffineFastState.Bounded env29612 := by
  intro p hp
  have h : env29612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29611_29612 : H12AffineEnvironment.transform 9 21 env29611 = env29612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29611 == env29612) = true)

theorem identity29612 : scanCanonicalize (H12AffineFastState.compose env29612 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29612 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29613 : List Nat := [2,4,8,1,32,64,8,101,65,4,0,97,40,96,0,34,97,1,4,1,97,33,1,2,40,64,1,64,64,0,37,1,101,0,0,64]

theorem envBound29613 : H12AffineFastState.Bounded env29613 := by
  intro p hp
  have h : env29613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29612_29613 : H12AffineEnvironment.transform 3 1 env29612 = env29613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29612 == env29613) = true)

theorem identity29613 : scanCanonicalize (H12AffineFastState.compose env29613 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29613 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29614 : List Nat := [2,4,8,1,0,64,8,69,65,4,0,65,8,64,0,2,65,1,4,1,65,1,1,2,8,64,1,64,64,0,5,1,69,0,0,64]

theorem envBound29614 : H12AffineFastState.Bounded env29614 := by
  intro p hp
  have h : env29614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29613_29614 : H12AffineEnvironment.transform 4 0 env29613 = env29614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29613 == env29614) = true)

def env29615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41412,16777216,8328,64,21331968,18973837,2159765,294912,16852437,23160256,256,18965864,18973901,16777731]

theorem envBound29615 : H12AffineFastState.Bounded env29615 := by
  intro p hp
  have h : env29615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29576_29615 : H12AffineEnvironment.transform 16 57797 env29576 = env29615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env29576 == env29615) = true)

theorem identity29615 : scanCanonicalize (H12AffineFastState.compose env29615 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound29615 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41412,2,8328,64,4554754,2196623,2159765,294912,75223,6383042,256,2188650,2196687,513]

theorem envBound29616 : H12AffineFastState.Bounded env29616 := by
  intro p hp
  have h : env29616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29615_29616 : H12AffineEnvironment.transform 23 2 env29615 = env29616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env29615 == env29616) = true)

def env29617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10280,1024,32769,2097152,4194304,41412,2,8328,64,4302890,2196623,2159765,43048,75223,6383042,256,2188650,2196687,513]

theorem envBound29617 : H12AffineFastState.Bounded env29617 := by
  intro p hp
  have h : env29617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29616_29617 : H12AffineEnvironment.transform 17 10280 env29616 = env29617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29616 == env29617) = true)

theorem identity29617 : scanCanonicalize (H12AffineFastState.compose env29617 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29617 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302890,2196487,2159645,43048,75103,6382922,256,2188650,2196551,513]

theorem envBound29618 : H12AffineFastState.Bounded env29618 := by
  intro p hp
  have h : env29618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29617_29618 : H12AffineEnvironment.transform 6 8 env29617 = env29618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29617 == env29618) = true)

theorem identity29618 : scanCanonicalize (H12AffineFastState.compose env29618 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound29618 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env29619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,115734,4194304,41292,2,8192,64,4302890,16401,77835,43048,75103,4235612,256,41340,16465,513]

theorem envBound29619 : H12AffineFastState.Bounded env29619 := by
  intro p hp
  have h : env29619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29618_29619 : H12AffineEnvironment.transform 20 115734 env29618 = env29619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env29618 == env29619) = true)

theorem identity29619 : scanCanonicalize (H12AffineFastState.compose env29619 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29619 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env29620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91467,4194304,17,2,8192,64,4262263,16401,77835,2421,75103,4194305,256,33,16465,513]

theorem envBound29620 : H12AffineFastState.Bounded env29620 := by
  intro p hp
  have h : env29620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29619_29620 : H12AffineEnvironment.transform 14 8541 env29619 = env29620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29619 == env29620) = true)

theorem identity29620 : scanCanonicalize (H12AffineFastState.compose env29620 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29620 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1024,8540,17729,4194304,17,2,8192,64,4204925,16401,4097,2421,1365,4194305,256,33,16465,513]

theorem envBound29621 : H12AffineFastState.Bounded env29621 := by
  intro p hp
  have h : env29621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29620_29621 : H12AffineEnvironment.transform 15 8202 env29620 = env29621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29620 == env29621) = true)

theorem identity29621 : scanCanonicalize (H12AffineFastState.compose env29621 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29621 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29622 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10280,1024,8461,17680,4194304,17,2,8192,17,4204844,16401,4097,2340,1284,4194305,256,33,16384,513]

theorem envBound29622 : H12AffineFastState.Bounded env29622 := by
  intro p hp
  have h : env29622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29621_29622 : H12AffineEnvironment.transform 5 17 env29621 = env29622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29621 == env29622) = true)

theorem identity29622 : scanCanonicalize (H12AffineFastState.compose env29622 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound29622 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env29623 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3101,16384,3345,3095,16400,1077,1024,3344,17680,4194304,17,2,3101,17,4195633,16401,4097,2340,1284,4194305,256,33,16384,513]

theorem envBound29623 : H12AffineFastState.Bounded env29623 := by
  intro p hp
  have h : env29623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29622_29623 : H12AffineEnvironment.transform 12 3101 env29622 = env29623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env29622 == env29623) = true)

theorem identity29623 : scanCanonicalize (H12AffineFastState.compose env29623 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound29623 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29624 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3101,16384,3345,3095,16400,1077,1024,3344,17680,33,17,2,3101,17,1296,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound29624 : H12AffineFastState.Bounded env29624 := by
  intro p hp
  have h : env29624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29623_29624 : H12AffineEnvironment.transform 21 33 env29623 = env29624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29623 == env29624) = true)

theorem identity29624 : scanCanonicalize (H12AffineFastState.compose env29624 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound29624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29625 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2325,3101,16384,3345,3095,16400,1077,1024,3344,17680,33,17,2,3101,17,1296,16401,2324,2340,1284,32,256,33,16384,513]

theorem envBound29625 : H12AffineFastState.Bounded env29625 := by
  intro p hp
  have h : env29625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29624_29625 : H12AffineEnvironment.transform 11 2325 env29624 = env29625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env29624 == env29625) = true)

theorem identity29625 : scanCanonicalize (H12AffineFastState.compose env29625 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound29625 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29626 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1556,1793,521,16384,773,515,16400,1077,1024,772,17680,33,17,2,521,17,1296,16401,1792,1840,1284,32,256,33,16384,513]

theorem envBound29626 : H12AffineFastState.Bounded env29626 := by
  intro p hp
  have h : env29626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29625_29626 : H12AffineEnvironment.transform 10 1556 env29625 = env29626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env29625 == env29626) = true)

theorem identity29626 : scanCanonicalize (H12AffineFastState.compose env29626 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound29626 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env29627 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1556,1793,521,292,773,515,308,1077,1024,772,1076,33,17,2,521,17,1296,309,1792,1840,1284,32,256,33,292,513]

theorem envBound29627 : H12AffineFastState.Bounded env29627 := by
  intro p hp
  have h : env29627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29626_29627 : H12AffineEnvironment.transform 13 292 env29626 = env29627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env29626 == env29627) = true)

theorem identity29627 : scanCanonicalize (H12AffineFastState.compose env29627 (packedSelected [1,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound29627 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env29628 : List Nat := [2,4,8,16,32,17,8,256,260,1024,1296,1029,269,292,1,263,308,1077,1024,0,1076,33,17,2,269,17,1296,309,1028,1076,1284,32,256,33,292,261]

theorem envBound29628 : H12AffineFastState.Bounded env29628 := by
  intro p hp
  have h : env29628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29627_29628 : H12AffineEnvironment.transform 8 260 env29627 = env29628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env29627 == env29628) = true)

theorem identity29628 : scanCanonicalize (H12AffineFastState.compose env29628 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29628 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29629 : List Nat := [2,4,8,16,32,17,8,256,260,52,292,49,269,292,1,263,308,1,52,0,0,33,17,2,269,17,292,309,48,0,304,32,256,33,292,261]

theorem envBound29629 : H12AffineFastState.Bounded env29629 := by
  intro p hp
  have h : env29629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29628_29629 : H12AffineEnvironment.transform 9 52 env29628 = env29629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29628 == env29629) = true)

theorem identity29629 : scanCanonicalize (H12AffineFastState.compose env29629 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29629 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29630 : List Nat := [2,4,8,16,16,17,8,256,260,4,276,1,269,276,1,263,260,1,4,0,0,17,17,2,269,17,276,261,0,0,256,16,256,17,276,261]

theorem envBound29630 : H12AffineFastState.Bounded env29630 := by
  intro p hp
  have h : env29630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29629_29630 : H12AffineEnvironment.transform 4 16 env29629 = env29630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29629 == env29630) = true)

theorem identity29630 : scanCanonicalize (H12AffineFastState.compose env29630 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29630 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29631 : List Nat := [2,4,8,16,16,17,8,5,1,4,17,1,8,17,1,2,1,1,4,0,0,17,17,2,8,17,17,0,0,0,5,16,5,17,17,0]

theorem envBound29631 : H12AffineFastState.Bounded env29631 := by
  intro p hp
  have h : env29631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29630_29631 : H12AffineEnvironment.transform 7 5 env29630 = env29631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29630 == env29631) = true)

theorem identity29631 : scanCanonicalize (H12AffineFastState.compose env29631 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29631 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29632 : List Nat := [2,4,2,16,16,17,2,5,1,4,17,1,2,17,1,2,1,1,4,0,0,17,17,2,2,17,17,0,0,0,5,16,5,17,17,0]

theorem envBound29632 : H12AffineFastState.Bounded env29632 := by
  intro p hp
  have h : env29632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29631_29632 : H12AffineEnvironment.transform 2 2 env29631 = env29632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29631 == env29632) = true)

def env29633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10281,1024,32769,2097152,4194304,41412,2,8328,64,4302891,2196623,2159765,43049,75223,6383042,256,2188650,2196687,513]

theorem envBound29633 : H12AffineFastState.Bounded env29633 := by
  intro p hp
  have h : env29633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29616_29633 : H12AffineEnvironment.transform 17 10281 env29616 = env29633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29616 == env29633) = true)

theorem identity29633 : scanCanonicalize (H12AffineFastState.compose env29633 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29633 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16537,10281,1024,8541,2097152,4194304,152,2,8328,64,4262263,2172371,2119113,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound29634 : H12AffineFastState.Bounded env29634 := by
  intro p hp
  have h : env29634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29633_29634 : H12AffineEnvironment.transform 14 8540 env29633 = env29634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29633 == env29634) = true)

theorem identity29634 : scanCanonicalize (H12AffineFastState.compose env29634 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound29634 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,16537,10281,1024,8541,2097152,4194304,152,2,8328,64,4205044,2098512,2119113,2421,1364,6309185,256,2115049,2098448,513]

theorem envBound29635 : H12AffineFastState.Bounded env29635 := by
  intro p hp
  have h : env29635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29634_29635 : H12AffineEnvironment.transform 15 8323 env29634 = env29635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env29634 == env29635) = true)

theorem identity29635 : scanCanonicalize (H12AffineFastState.compose env29635 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound29635 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env29636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,16537,10281,1024,8541,5456,4194304,152,2,8328,64,4205044,4096,16537,2421,1364,4214801,256,20665,4160,513]

theorem envBound29636 : H12AffineFastState.Bounded env29636 := by
  intro p hp
  have h : env29636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29635_29636 : H12AffineEnvironment.transform 20 5456 env29635 = env29636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env29635 == env29636) = true)

theorem identity29636 : scanCanonicalize (H12AffineFastState.compose env29636 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound29636 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8323,4232,10281,1024,8541,5456,4194304,152,2,8328,64,4205044,4096,4232,2421,1364,4194304,256,168,4160,513]

theorem envBound29637 : H12AffineFastState.Bounded env29637 := by
  intro p hp
  have h : env29637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29636_29637 : H12AffineEnvironment.transform 13 4113 env29636 = env29637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env29636 == env29637) = true)

theorem identity29637 : scanCanonicalize (H12AffineFastState.compose env29637 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound29637 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env29638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8323,4232,10281,1024,8541,5456,8612,152,2,8328,64,2128,4096,4232,2421,1364,8612,256,168,4160,513]

theorem envBound29638 : H12AffineFastState.Bounded env29638 := by
  intro p hp
  have h : env29638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29637_29638 : H12AffineEnvironment.transform 21 8612 env29637 = env29638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env29637 == env29638) = true)

theorem identity29638 : scanCanonicalize (H12AffineFastState.compose env29638 (packedSelected [0,1,4,5,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound29638 : packedSelected [0,1,4,5,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env29639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,4113,137,342,4232,2556,1024,136,5456,113,152,2,349,64,2128,4096,4232,2421,1364,113,256,168,4160,513]

theorem envBound29639 : H12AffineFastState.Bounded env29639 := by
  intro p hp
  have h : env29639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29638_29639 : H12AffineEnvironment.transform 12 469 env29638 = env29639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env29638 == env29639) = true)

theorem identity29639 : scanCanonicalize (H12AffineFastState.compose env29639 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29639 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29640 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,4113,80,342,4177,2341,1024,81,5456,113,65,2,349,64,2128,4096,4177,2421,1364,113,256,113,4160,513]

theorem envBound29640 : H12AffineFastState.Bounded env29640 := by
  intro p hp
  have h : env29640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29639_29640 : H12AffineEnvironment.transform 6 89 env29639 = env29640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29639 == env29640) = true)

theorem identity29640 : scanCanonicalize (H12AffineFastState.compose env29640 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29640 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29641 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,1,263,4096,2341,1024,0,5377,32,16,2,268,17,2049,4096,4096,2340,1285,32,256,32,4113,513]

theorem envBound29641 : H12AffineFastState.Bounded env29641 := by
  intro p hp
  have h : env29641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29640_29641 : H12AffineEnvironment.transform 5 17 env29640 = env29641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29640 == env29641) = true)

theorem identity29641 : scanCanonicalize (H12AffineFastState.compose env29641 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29642 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,268,4113,1,263,4096,2341,53,0,4404,32,16,2,268,17,2049,4096,4096,2340,304,32,256,32,4113,513]

theorem envBound29642 : H12AffineFastState.Bounded env29642 := by
  intro p hp
  have h : env29642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29641_29642 : H12AffineEnvironment.transform 9 53 env29641 = env29642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29641 == env29642) = true)

theorem identity29642 : scanCanonicalize (H12AffineFastState.compose env29642 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound29642 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29643 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,561,268,544,1,263,561,2341,53,0,773,32,16,2,268,17,2049,561,561,2340,304,32,256,32,544,513]

theorem envBound29643 : H12AffineFastState.Bounded env29643 := by
  intro p hp
  have h : env29643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29642_29643 : H12AffineEnvironment.transform 11 561 env29642 = env29643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env29642 == env29643) = true)

def env29644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound29644 : H12AffineFastState.Bounded env29644 := by
  intro p hp
  have h : env29644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29574_29644 : H12AffineEnvironment.transform 18 1025 env29574 = env29644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29574 == env29644) = true)

theorem identity29644 : scanCanonicalize (H12AffineFastState.compose env29644 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213317) := by decide +kernel

theorem selectedBound29644 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213317,8328,64,12878149,2278857,10507601,8830976,8570196,6431877,257,10651112,10642508,8643203]

theorem envBound29645 : H12AffineFastState.Bounded env29645 := by
  intro p hp
  have h : env29645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29644_29645 : H12AffineEnvironment.transform 23 213317 env29644 = env29645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213317 env29644 == env29645) = true)

def env29646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281672,213317,8328,64,6705549,2278857,165273,2363592,2102684,6431877,257,21792,46212,2175563]

theorem envBound29646 : H12AffineFastState.Bounded env29646 := by
  intro p hp
  have h : env29646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29645_29646 : H12AffineEnvironment.transform 22 2281672 env29645 = env29646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281672 env29645 == env29646) = true)

def env29647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590741,2098513,17665,2363592,2102684,6349853,257,21792,46212,2175563]

theorem envBound29647 : H12AffineFastState.Bounded env29647 := by
  intro p hp
  have h : env29647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29646_29647 : H12AffineEnvironment.transform 16 49304 env29646 = env29647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env29646 == env29647) = true)

def env29648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144661,2098513,17665,2363592,2102684,2411677,257,21792,46212,2175563]

theorem envBound29648 : H12AffineFastState.Bounded env29648 := by
  intro p hp
  have h : env29648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29647_29648 : H12AffineEnvironment.transform 21 272512 env29647 = env29648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29647 == env29648) = true)

def env29649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101328,98645,8192,64,2144541,2098513,17665,2363456,2102548,2411541,257,21792,46092,2175563]

theorem envBound29649 : H12AffineFastState.Bounded env29649 := by
  intro p hp
  have h : env29649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29648_29649 : H12AffineEnvironment.transform 6 8 env29648 = env29649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29648 == env29649) = true)

theorem identity29649 : scanCanonicalize (H12AffineFastState.compose env29649 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29649 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,262144,1025,1,2097152,272392,2101328,65877,8192,64,2111773,2098513,17665,2363456,2102548,2378773,257,21792,13324,2175563]

theorem envBound29650 : H12AffineFastState.Bounded env29650 := by
  intro p hp
  have h : env29650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29649_29650 : H12AffineEnvironment.transform 14 0 env29649 = env29650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29649 == env29650) = true)

theorem identity29650 : scanCanonicalize (H12AffineFastState.compose env29650 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29650 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env29651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,65536,13341,262144,1025,1,2097152,272392,2101328,65877,8192,64,2111773,2098513,12556,2363456,2102548,2373656,257,8493,13324,2175563]

theorem envBound29651 : H12AffineFastState.Bounded env29651 := by
  intro p hp
  have h : env29651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29650_29651 : H12AffineEnvironment.transform 13 13325 env29650 = env29651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29650 == env29651) = true)

theorem identity29651 : scanCanonicalize (H12AffineFastState.compose env29651 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound29651 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env29652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,65536,13341,67618,1025,1,2097152,73770,2101328,65877,8192,64,2111773,2098513,12556,2168930,2102548,2175034,257,8493,13324,2175563]

theorem envBound29652 : H12AffineFastState.Bounded env29652 := by
  intro p hp
  have h : env29652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29651_29652 : H12AffineEnvironment.transform 17 67618 env29651 = env29652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env29651 == env29652) = true)

theorem identity29652 : scanCanonicalize (H12AffineFastState.compose env29652 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29652 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env29653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1025,1,2097152,32,2101328,8543,8192,64,2111773,2098513,12556,2111592,2102548,2101296,257,8493,13324,2101825]

theorem envBound29653 : H12AffineFastState.Bounded env29653 := by
  intro p hp
  have h : env29653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29652_29653 : H12AffineEnvironment.transform 15 8202 env29652 = env29653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29652 == env29653) = true)

theorem identity29653 : scanCanonicalize (H12AffineFastState.compose env29653 (packedSelected [0,2,4,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 12344) := by decide +kernel

theorem selectedBound29653 : packedSelected [0,2,4,11,14,16] rootPS < 2^1333 := by decide +kernel

def env29654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1025,1,12344,32,8296,8543,8192,64,2341,13673,12556,2128,9516,8200,257,8493,13324,8825]

theorem envBound29654 : H12AffineFastState.Bounded env29654 := by
  intro p hp
  have h : env29654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29653_29654 : H12AffineEnvironment.transform 20 12344 env29653 = env29654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12344 env29653 == env29654) = true)

theorem identity29654 : scanCanonicalize (H12AffineFastState.compose env29654 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29654 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env29655 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1025,1,12344,32,8248,8463,8192,16,2341,13625,12556,2048,9516,8200,257,8493,13324,8745]

theorem envBound29655 : H12AffineFastState.Bounded env29655 := by
  intro p hp
  have h : env29655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29654_29655 : H12AffineEnvironment.transform 5 16 env29654 = env29655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29654 == env29655) = true)

theorem identity29655 : scanCanonicalize (H12AffineFastState.compose env29655 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29655 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env29656 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5156,0,35,5172,2049,1025,1,4113,32,17,294,41,16,2341,5392,4389,2048,1285,33,257,260,5157,512]

theorem envBound29656 : H12AffineFastState.Bounded env29656 := by
  intro p hp
  have h : env29656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29655_29656 : H12AffineEnvironment.transform 12 41 env29655 = env29656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29655 == env29656) = true)

theorem identity29656 : scanCanonicalize (H12AffineFastState.compose env29656 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29656 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29657 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,41,5156,0,35,5172,2049,1025,1,4113,32,17,35,41,16,2080,5141,4128,2048,1024,33,4,1,5157,512]

theorem envBound29657 : H12AffineFastState.Bounded env29657 := by
  intro p hp
  have h : env29657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29656_29657 : H12AffineEnvironment.transform 7 5 env29656 = env29657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29656 == env29657) = true)

theorem identity29657 : scanCanonicalize (H12AffineFastState.compose env29657 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound29657 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29658 : List Nat := [2,4,8,16,32,16,8,5,512,1024,522,4096,41,5156,0,35,5172,523,1025,1,4113,32,17,35,41,16,554,5141,4128,522,1024,33,4,1,5157,512]

theorem envBound29658 : H12AffineFastState.Bounded env29658 := by
  intro p hp
  have h : env29658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29657_29658 : H12AffineEnvironment.transform 10 522 env29657 = env29658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env29657 == env29658) = true)

def env29659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101328,98644,8193,64,2144540,2098513,17665,2363457,2102549,2411540,257,21792,46093,2175563]

theorem envBound29659 : H12AffineFastState.Bounded env29659 := by
  intro p hp
  have h : env29659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29648_29659 : H12AffineEnvironment.transform 6 9 env29648 = env29659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29648 == env29659) = true)

theorem identity29659 : scanCanonicalize (H12AffineFastState.compose env29659 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound29659 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272393,73754,98644,8193,64,100694,79131,17665,335883,75103,392286,257,21792,46093,513]

theorem envBound29660 : H12AffineFastState.Bounded env29660 := by
  intro p hp
  have h : env29660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29659_29660 : H12AffineEnvironment.transform 20 77898 env29659 = env29660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env29659 == env29660) = true)

theorem identity29660 : scanCanonicalize (H12AffineFastState.compose env29660 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound29660 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,77898,41341,73754,98644,8193,64,100694,79131,17665,108927,75103,95530,257,21792,46093,513]

theorem envBound29661 : H12AffineFastState.Bounded env29661 := by
  intro p hp
  have h : env29661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29660_29661 : H12AffineEnvironment.transform 17 35188 env29660 = env29661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env29660 == env29661) = true)

theorem identity29661 : scanCanonicalize (H12AffineFastState.compose env29661 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29661 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env29662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35188,1025,32769,77898,41341,73754,98644,8193,64,100694,79131,4096,108927,75103,73771,257,33,46093,513]

theorem envBound29662 : H12AffineFastState.Bounded env29662 := by
  intro p hp
  have h : env29662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29661_29662 : H12AffineEnvironment.transform 13 5377 env29661 = env29662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29661 == env29662) = true)

theorem identity29662 : scanCanonicalize (H12AffineFastState.compose env29662 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound29662 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env29663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33030,38160,35188,1025,32769,45388,41341,41244,82,8193,64,2128,46109,4096,10361,42073,41261,257,33,46093,513]

theorem envBound29663 : H12AffineFastState.Bounded env29663 := by
  intro p hp
  have h : env29663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29662_29663 : H12AffineEnvironment.transform 15 33030 env29662 = env29663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env29662 == env29663) = true)

theorem identity29663 : scanCanonicalize (H12AffineFastState.compose env29663 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29663 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env29664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33030,38160,35188,1025,32769,36880,32801,32832,82,349,64,2128,38209,4096,2341,34053,32881,257,33,38225,513]

theorem envBound29664 : H12AffineFastState.Bounded env29664 := by
  intro p hp
  have h : env29664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29663_29664 : H12AffineEnvironment.transform 12 348 env29663 = env29664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29663 == env29664) = true)

theorem identity29664 : scanCanonicalize (H12AffineFastState.compose env29664 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29664 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env29665 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,32768,33030,38160,35109,1025,32769,36880,32801,32785,3,268,17,2049,38160,4096,2341,34053,32800,257,33,38144,513]

theorem envBound29665 : H12AffineFastState.Bounded env29665 := by
  intro p hp
  have h : env29665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29664_29665 : H12AffineEnvironment.transform 5 17 env29664 = env29665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29664 == env29665) = true)

theorem identity29665 : scanCanonicalize (H12AffineFastState.compose env29665 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29665 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29666 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1025,0,4113,32,16,3,268,17,2049,5393,4096,2341,1284,33,257,33,5377,513]

theorem envBound29666 : H12AffineFastState.Bounded env29666 := by
  intro p hp
  have h : env29666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29665_29666 : H12AffineEnvironment.transform 14 1 env29665 = env29666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29665 == env29666) = true)

theorem identity29666 : scanCanonicalize (H12AffineFastState.compose env29666 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29667 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,1,263,4389,2340,53,0,4113,32,16,3,268,17,2049,4389,4096,2341,304,33,257,33,4405,513]

theorem envBound29667 : H12AffineFastState.Bounded env29667 := by
  intro p hp
  have h : env29667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29666_29667 : H12AffineEnvironment.transform 9 52 env29666 = env29667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29666 == env29667) = true)

theorem identity29667 : scanCanonicalize (H12AffineFastState.compose env29667 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29667 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29668 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4112,1,34,4096,2049,53,0,4113,32,16,3,41,17,2049,4096,4096,2048,21,33,36,33,4112,513]

theorem envBound29668 : H12AffineFastState.Bounded env29668 := by
  intro p hp
  have h : env29668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29667_29668 : H12AffineEnvironment.transform 7 37 env29667 = env29668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29667 == env29668) = true)

theorem identity29668 : scanCanonicalize (H12AffineFastState.compose env29668 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound29668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29669 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2577,40,2561,1,34,2577,2049,53,0,2560,32,16,3,41,17,2049,2577,2577,2048,21,33,36,33,2561,513]

theorem envBound29669 : H12AffineFastState.Bounded env29669 := by
  intro p hp
  have h : env29669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29668_29669 : H12AffineEnvironment.transform 11 2577 env29668 = env29669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env29668 == env29669) = true)

theorem identity29669 : scanCanonicalize (H12AffineFastState.compose env29669 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound29669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29670 : List Nat := [2,4,8,16,32,17,9,37,512,52,58,555,40,571,1,34,555,59,53,0,570,32,16,3,41,17,59,555,555,58,21,33,36,33,571,513]

theorem envBound29670 : H12AffineFastState.Bounded env29670 := by
  intro p hp
  have h : env29670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29669_29670 : H12AffineEnvironment.transform 10 58 env29669 = env29670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env29669 == env29670) = true)

theorem identity29670 : scanCanonicalize (H12AffineFastState.compose env29670 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound29670 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29671 : List Nat := [2,4,8,16,26,17,9,31,512,14,0,529,18,513,1,24,529,1,15,0,512,26,16,3,19,17,1,529,529,0,21,27,30,27,513,513]

end H12CloudChart0