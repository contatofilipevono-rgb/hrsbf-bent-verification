import H12CloudChart0Data111

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound28392 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28393 : List Nat := [2,4,8,16,32,17,128,36,512,52,136,152,161,137,137,34,16,1,53,136,137,32,17,3,41,17,1,153,153,1,156,32,37,33,1,649]

theorem envBound28393 : H12AffineFastState.Bounded env28393 := by
  intro p hp
  have h : env28393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28392_28393 : H12AffineEnvironment.transform 10 136 env28392 = env28393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env28392 == env28393) = true)

theorem identity28393 : scanCanonicalize (H12AffineFastState.compose env28393 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28393 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28394 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,16,41,1,1,34,16,1,53,0,1,32,17,3,41,17,1,17,17,1,20,32,37,33,1,513]

theorem envBound28394 : H12AffineFastState.Bounded env28394 := by
  intro p hp
  have h : env28394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28393_28394 : H12AffineEnvironment.transform 6 8 env28393 = env28394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28393 == env28394) = true)

theorem identity28394 : scanCanonicalize (H12AffineFastState.compose env28394 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28394 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28395 : List Nat := [2,4,8,16,16,17,8,20,512,4,0,16,25,1,1,18,16,1,5,0,1,16,17,3,25,17,1,17,17,1,20,16,21,17,1,513]

theorem envBound28395 : H12AffineFastState.Bounded env28395 := by
  intro p hp
  have h : env28395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28394_28395 : H12AffineEnvironment.transform 4 16 env28394 = env28395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28394 == env28395) = true)

def env28396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180273,144477,243089,8328,64,43476,139613,160076,56437,1501,33,257,21792,46213,74250]

theorem envBound28396 : H12AffineFastState.Bounded env28396 := by
  intro p hp
  have h : env28396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28376_28396 : H12AffineEnvironment.transform 17 10281 env28376 = env28396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28376 == env28396) = true)

def env28397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,21793,41293,73857,8328,64,43476,46157,58460,56437,1501,33,257,21792,46213,74250]

theorem envBound28397 : H12AffineFastState.Bounded env28397 := by
  intro p hp
  have h : env28397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28396_28397 : H12AffineEnvironment.transform 16 38160 env28396 = env28397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28396 == env28397) = true)

theorem identity28397 : scanCanonicalize (H12AffineFastState.compose env28397 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28397 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4160,21793,41293,138,8328,64,43476,46157,58460,56437,1501,33,257,21792,46213,513]

theorem envBound28398 : H12AffineFastState.Bounded env28398 := by
  intro p hp
  have h : env28398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28397_28398 : H12AffineEnvironment.transform 15 8203 env28397 = env28398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28397 == env28398) = true)

theorem identity28398 : scanCanonicalize (H12AffineFastState.compose env28398 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28398 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,38160,10281,1025,32769,4160,169,41293,138,8328,64,43476,46157,45524,35325,1501,33,257,168,46213,513]

theorem envBound28399 : H12AffineFastState.Bounded env28399 := by
  intro p hp
  have h : env28399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28398_28399 : H12AffineEnvironment.transform 13 5512 env28398 = env28399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28398 == env28399) = true)

theorem identity28399 : scanCanonicalize (H12AffineFastState.compose env28399 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28399 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,32768,34,38160,2048,1025,32769,4160,169,33124,138,161,64,35325,37988,37373,35325,1501,33,257,168,38060,513]

theorem envBound28400 : H12AffineFastState.Bounded env28400 := by
  intro p hp
  have h : env28400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28399_28400 : H12AffineEnvironment.transform 12 41 env28399 = env28400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28399 == env28400) = true)

theorem identity28400 : scanCanonicalize (H12AffineFastState.compose env28400 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound28400 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env28401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,373,34,5221,2048,1025,372,4160,169,17,138,161,64,2184,5393,4232,2184,1501,33,257,168,5593,513]

theorem envBound28401 : H12AffineFastState.Bounded env28401 := by
  intro p hp
  have h : env28401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28400_28401 : H12AffineEnvironment.transform 14 373 env28400 = env28401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env28400 == env28401) = true)

theorem identity28401 : scanCanonicalize (H12AffineFastState.compose env28401 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28401 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5376,373,34,5221,2048,1025,372,4160,33,17,2,41,64,2048,5393,4096,2048,1365,33,257,32,5457,513]

theorem envBound28402 : H12AffineFastState.Bounded env28402 := by
  intro p hp
  have h : env28402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28401_28402 : H12AffineEnvironment.transform 6 8 env28401 = env28402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28401 == env28402) = true)

def env28403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,21792,41292,73856,8328,64,43476,46156,58461,56437,1501,33,257,21792,46213,74250]

theorem envBound28403 : H12AffineFastState.Bounded env28403 := by
  intro p hp
  have h : env28403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28396_28403 : H12AffineEnvironment.transform 16 38161 env28396 = env28403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28396 == env28403) = true)

theorem identity28403 : scanCanonicalize (H12AffineFastState.compose env28403 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound28403 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1025,32769,4160,21792,41292,2,8328,64,43476,46156,58461,56437,1501,33,257,21792,46213,648]

theorem envBound28404 : H12AffineFastState.Bounded env28404 := by
  intro p hp
  have h : env28404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28403_28404 : H12AffineEnvironment.transform 15 8322 env28403 = env28404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env28403 == env28404) = true)

theorem identity28404 : scanCanonicalize (H12AffineFastState.compose env28404 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28404 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env28405 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8283,38161,10281,1025,32769,4160,21792,41292,2,8273,64,43277,46156,58461,56437,1284,33,257,21792,46172,593]

theorem envBound28405 : H12AffineFastState.Bounded env28405 := by
  intro p hp
  have h : env28405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28404_28405 : H12AffineEnvironment.transform 6 89 env28404 = env28405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28404 == env28405) = true)

theorem identity28405 : scanCanonicalize (H12AffineFastState.compose env28405 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound28405 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env28406 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21840,8283,16449,10281,1025,21841,4160,21792,29724,2,8273,64,31837,24860,12557,2341,1284,33,257,21792,24844,593]

theorem envBound28406 : H12AffineFastState.Bounded env28406 := by
  intro p hp
  have h : env28406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28405_28406 : H12AffineEnvironment.transform 14 21840 env28405 = env28406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env28405 == env28406) = true)

theorem identity28406 : scanCanonicalize (H12AffineFastState.compose env28406 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28406 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28407 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21840,342,16449,2340,1025,21841,4160,21792,21777,2,348,64,23888,16401,4096,2341,1284,33,257,21792,16385,593]

theorem envBound28407 : H12AffineFastState.Bounded env28407 := by
  intro p hp
  have h : env28407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28406_28407 : H12AffineEnvironment.transform 12 269 env28406 = env28407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28406 == env28407) = true)

theorem identity28407 : scanCanonicalize (H12AffineFastState.compose env28407 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28407 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env28408 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,1,342,5392,2340,1025,0,4160,113,64,2,348,64,2049,5440,4096,2341,1284,33,257,113,5456,593]

theorem envBound28408 : H12AffineFastState.Bounded env28408 := by
  intro p hp
  have h : env28408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28407_28408 : H12AffineEnvironment.transform 13 5457 env28407 = env28408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env28407 == env28408) = true)

theorem identity28408 : scanCanonicalize (H12AffineFastState.compose env28408 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28408 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28409 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,263,5392,2340,1025,0,4113,32,17,2,269,17,2049,5393,4096,2341,1284,33,257,32,5377,512]

theorem envBound28409 : H12AffineFastState.Bounded env28409 := by
  intro p hp
  have h : env28409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28408_28409 : H12AffineEnvironment.transform 5 17 env28408 = env28409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28408 == env28409) = true)

theorem identity28409 : scanCanonicalize (H12AffineFastState.compose env28409 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28409 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28410 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,269,5376,1,263,5392,2309,1025,0,4113,1,17,2,269,17,2049,5393,4096,2308,1284,0,257,1,5377,512]

theorem envBound28410 : H12AffineFastState.Bounded env28410 := by
  intro p hp
  have h : env28410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28409_28410 : H12AffineEnvironment.transform 4 1 env28409 = env28410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28409 == env28410) = true)

theorem identity28410 : scanCanonicalize (H12AffineFastState.compose env28410 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound28410 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28411 : List Nat := [2,4,8,16,1,17,8,256,512,1024,522,4096,269,5376,1,263,5392,783,1025,0,4113,1,17,2,269,17,523,5393,4096,782,1284,0,257,1,5377,512]

theorem envBound28411 : H12AffineFastState.Bounded env28411 := by
  intro p hp
  have h : env28411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28410_28411 : H12AffineEnvironment.transform 10 522 env28410 = env28411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env28410 == env28411) = true)

def env28412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144476,243089,8328,64,43477,139612,160076,324701,1500,272393,257,21792,46213,74251]

theorem envBound28412 : H12AffineFastState.Bounded env28412 := by
  intro p hp
  have h : env28412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28375_28412 : H12AffineEnvironment.transform 20 4161 env28375 = env28412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28375 == env28412) = true)

theorem identity28412 : scanCanonicalize (H12AffineFastState.compose env28412 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound28412 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272513,62661,95496,8328,64,43477,57797,45525,324701,1500,272393,257,21792,46213,74251]

theorem envBound28413 : H12AffineFastState.Bounded env28413 := by
  intro p hp
  have h : env28413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28412_28413 : H12AffineEnvironment.transform 16 49305 env28412 = env28413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env28412 == env28413) = true)

theorem identity28413 : scanCanonicalize (H12AffineFastState.compose env28413 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28413 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,262144,1025,32769,4161,272513,62661,21762,8328,64,43477,57797,45525,324701,1500,272393,257,21792,46213,513]

theorem envBound28414 : H12AffineFastState.Bounded env28414 := by
  intro p hp
  have h : env28414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28413_28414 : H12AffineEnvironment.transform 15 8202 env28413 = env28414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28413 == env28414) = true)

theorem identity28414 : scanCanonicalize (H12AffineFastState.compose env28414 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound28414 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env28415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,10401,1025,32769,4161,32,62661,21762,8328,64,43477,57797,45525,56572,1500,168,257,21792,46213,513]

theorem envBound28415 : H12AffineFastState.Bounded env28415 := by
  intro p hp
  have h : env28415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28414_28415 : H12AffineEnvironment.transform 17 10401 env28414 = env28415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28414 == env28415) = true)

theorem identity28415 : scanCanonicalize (H12AffineFastState.compose env28415 (packedSelected [2,4,6,9,10,11,15,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 7561) := by decide +kernel

theorem selectedBound28415 : packedSelected [2,4,6,9,10,11,15,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env28416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,7561,8202,23824,10401,1025,7560,4161,32,26956,21762,8328,64,13404,31820,11356,16757,1500,168,257,21792,10508,513]

theorem envBound28416 : H12AffineFastState.Bounded env28416 := by
  intro p hp
  have h : env28416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28415_28416 : H12AffineEnvironment.transform 14 7561 env28415 = env28416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7561 env28415 == env28416) = true)

theorem identity28416 : scanCanonicalize (H12AffineFastState.compose env28416 (packedSelected [0,1,2,3,5,6,7,8,9,11,15,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound28416 : packedSelected [0,1,2,3,5,6,7,8,9,11,15,17,22] rootPS < 2^1333 := by decide +kernel

def env28417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,16384,137,8202,16400,10401,1025,136,3393,32,26956,18434,8328,64,10588,24908,11356,16757,1500,168,257,18464,10508,513]

theorem envBound28417 : H12AffineFastState.Bounded env28417 := by
  intro p hp
  have h : env28417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28416_28417 : H12AffineEnvironment.transform 11 3328 env28416 = env28417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env28416 == env28417) = true)

theorem identity28417 : scanCanonicalize (H12AffineFastState.compose env28417 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound28417 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env28418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,2209,16384,137,2219,16400,0,1025,136,3393,32,16877,18434,2089,64,509,18925,1277,16757,1500,168,257,18464,429,513]

theorem envBound28418 : H12AffineFastState.Bounded env28418 := by
  intro p hp
  have h : env28418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28417_28418 : H12AffineEnvironment.transform 12 2209 env28417 = env28418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env28417 == env28418) = true)

theorem identity28418 : scanCanonicalize (H12AffineFastState.compose env28418 (packedSelected [1,2,4,5,6,8,9,12,15,17,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound28418 : packedSelected [1,2,4,5,6,8,9,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env28419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,2209,1260,137,2219,1276,0,1025,136,3393,32,1281,3310,2089,64,509,3329,1277,1433,1500,168,257,3276,429,513]

theorem envBound28419 : H12AffineFastState.Bounded env28419 := by
  intro p hp
  have h : env28419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28418_28419 : H12AffineEnvironment.transform 13 1260 env28418 = env28419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env28418 == env28419) = true)

theorem identity28419 : scanCanonicalize (H12AffineFastState.compose env28419 (packedSelected [1,2,3,4,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28419 : packedSelected [1,2,3,4,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28420 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3328,2169,1076,81,2163,1060,0,1025,80,3393,32,1281,3126,2089,64,293,3329,1061,1345,1284,112,257,3092,373,513]

theorem envBound28420 : H12AffineFastState.Bounded env28420 := by
  intro p hp
  have h : env28420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28419_28420 : H12AffineEnvironment.transform 6 88 env28419 = env28420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28419 == env28420) = true)

theorem identity28420 : scanCanonicalize (H12AffineFastState.compose env28420 (packedSelected [6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound28420 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env28421 : List Nat := [2,4,8,16,32,64,88,256,512,1024,293,1061,348,1076,81,342,1060,0,1025,80,1124,32,1281,1299,268,64,293,1060,1061,1345,1284,112,257,1329,373,513]

theorem envBound28421 : H12AffineFastState.Bounded env28421 := by
  intro p hp
  have h : env28421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28420_28421 : H12AffineEnvironment.transform 10 293 env28420 = env28421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env28420 == env28421) = true)

theorem identity28421 : scanCanonicalize (H12AffineFastState.compose env28421 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28421 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env28422 : List Nat := [2,4,8,16,32,64,88,117,512,1024,80,1061,41,1076,81,35,1060,0,1025,80,1124,32,1140,1126,121,64,80,1060,1061,1076,1137,112,116,1092,0,513]

theorem envBound28422 : H12AffineFastState.Bounded env28422 := by
  intro p hp
  have h : env28422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28421_28422 : H12AffineEnvironment.transform 7 117 env28421 = env28422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28421 == env28422) = true)

theorem identity28422 : scanCanonicalize (H12AffineFastState.compose env28422 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28422 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28423 : List Nat := [2,4,8,16,32,64,88,117,512,101,80,64,41,81,81,35,65,0,100,80,1,32,17,3,121,64,80,65,64,81,20,112,116,33,0,513]

theorem envBound28423 : H12AffineFastState.Bounded env28423 := by
  intro p hp
  have h : env28423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28422_28423 : H12AffineEnvironment.transform 9 101 env28422 = env28423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28422 == env28423) = true)

theorem identity28423 : scanCanonicalize (H12AffineFastState.compose env28423 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28424 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,41,0,0,35,16,0,53,1,1,32,17,3,40,17,1,16,17,0,20,33,37,33,0,513]

theorem envBound28424 : H12AffineFastState.Bounded env28424 := by
  intro p hp
  have h : env28424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28423_28424 : H12AffineEnvironment.transform 5 17 env28423 = env28424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28423 == env28424) = true)

theorem identity28424 : scanCanonicalize (H12AffineFastState.compose env28424 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28424 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28425 : List Nat := [2,4,8,16,10,17,9,14,512,30,1,17,3,0,0,9,16,0,31,1,1,10,17,3,2,17,1,16,17,0,20,11,15,11,0,513]

theorem envBound28425 : H12AffineFastState.Bounded env28425 := by
  intro p hp
  have h : env28425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28424_28425 : H12AffineEnvironment.transform 4 10 env28424 = env28425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28424 == env28425) = true)

theorem identity28425 : scanCanonicalize (H12AffineFastState.compose env28425 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28426 : List Nat := [2,4,8,0,10,1,9,14,512,14,1,1,3,0,0,9,0,0,15,1,1,10,1,3,2,1,1,0,1,0,4,11,15,11,0,513]

theorem envBound28426 : H12AffineFastState.Bounded env28426 := by
  intro p hp
  have h : env28426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28425_28426 : H12AffineEnvironment.transform 3 0 env28425 = env28426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28425 == env28426) = true)

theorem identity28426 : scanCanonicalize (H12AffineFastState.compose env28426 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28426 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28427 : List Nat := [2,4,8,0,10,1,9,14,0,14,1,1,3,0,0,9,0,0,15,1,1,10,1,3,2,1,1,0,1,0,4,11,15,11,0,1]

theorem envBound28427 : H12AffineFastState.Bounded env28427 := by
  intro p hp
  have h : env28427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28426_28427 : H12AffineEnvironment.transform 8 0 env28426 = env28427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28426 == env28427) = true)

def env28428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237469,243089,8328,64,2144661,2240797,160076,2417692,2102685,2373705,257,21792,46213,2175562]

theorem envBound28428 : H12AffineFastState.Bounded env28428 := by
  intro p hp
  have h : env28428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28374_28428 : H12AffineEnvironment.transform 21 452633 env28374 = env28428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env28374 == env28428) = true)

def env28429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144477,243089,8328,64,43477,139613,160076,324700,1501,272393,257,21792,46213,74250]

theorem envBound28429 : H12AffineFastState.Bounded env28429 := by
  intro p hp
  have h : env28429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28428_28429 : H12AffineEnvironment.transform 20 4160 env28428 = env28429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28428 == env28429) = true)

theorem identity28429 : scanCanonicalize (H12AffineFastState.compose env28429 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound28429 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,17,98781,8328,64,43477,5393,17664,324700,1501,272393,257,21792,46213,74250]

theorem envBound28430 : H12AffineFastState.Bounded env28430 := by
  intro p hp
  have h : env28430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28429_28430 : H12AffineEnvironment.transform 16 13388 env28429 = env28430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env28429 == env28430) = true)

def env28431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,17,98645,8192,64,43357,5393,17664,324700,1365,272393,257,21792,46093,74250]

theorem envBound28431 : H12AffineFastState.Bounded env28431 := by
  intro p hp
  have h : env28431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28430_28431 : H12AffineEnvironment.transform 6 8 env28430 = env28431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28430 == env28431) = true)

theorem identity28431 : scanCanonicalize (H12AffineFastState.compose env28431 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound28431 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,108926,1025,32769,4160,95531,17,98645,8192,64,43357,5393,17664,89378,1365,98679,257,21792,46093,74250]

theorem envBound28432 : H12AffineFastState.Bounded env28432 := by
  intro p hp
  have h : env28432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28431_28432 : H12AffineEnvironment.transform 17 108926 env28431 = env28432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env28431 == env28432) = true)

theorem identity28432 : scanCanonicalize (H12AffineFastState.compose env28432 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28432 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env28433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,65536,13388,108926,1025,32769,4160,73851,17,98645,8192,64,43357,5393,4176,67698,1365,98679,257,112,46093,74250]

theorem envBound28433 : H12AffineFastState.Bounded env28433 := by
  intro p hp
  have h : env28433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28432_28433 : H12AffineEnvironment.transform 13 5456 env28432 = env28433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28432 == env28433) = true)

theorem identity28433 : scanCanonicalize (H12AffineFastState.compose env28433 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28433 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env28434 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5236,32768,65536,13388,108634,1025,32769,4160,73851,17,98417,8192,64,43129,5173,4176,67698,1137,98387,37,112,46093,74250]

theorem envBound28434 : H12AffineFastState.Bounded env28434 := by
  intro p hp
  have h : env28434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28433_28434 : H12AffineEnvironment.transform 7 36 env28433 = env28434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28433 == env28434) = true)

def env28435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,17,98644,8193,64,43356,5393,17664,324700,1364,272393,257,21792,46092,74250]

theorem envBound28435 : H12AffineFastState.Bounded env28435 := by
  intro p hp
  have h : env28435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28430_28435 : H12AffineEnvironment.transform 6 9 env28430 = env28435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28430 == env28435) = true)

theorem identity28435 : scanCanonicalize (H12AffineFastState.compose env28435 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound28435 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67618,1025,32769,4160,119927,17,98644,8193,64,43356,5393,17664,130174,1364,73771,257,21792,46092,74250]

theorem envBound28436 : H12AffineFastState.Bounded env28436 := by
  intro p hp
  have h : env28436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28435_28436 : H12AffineEnvironment.transform 17 67618 env28435 = env28436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env28435 == env28436) = true)

theorem identity28436 : scanCanonicalize (H12AffineFastState.compose env28436 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound28436 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env28437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,13388,23668,1025,32769,4160,32801,17,54530,8193,64,43356,5393,17664,43048,1364,29821,257,21792,46092,30300]

theorem envBound28437 : H12AffineFastState.Bounded env28437 := by
  intro p hp
  have h : env28437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28436_28437 : H12AffineEnvironment.transform 15 21590 env28436 = env28437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env28436 == env28437) = true)

theorem identity28437 : scanCanonicalize (H12AffineFastState.compose env28437 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28437 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env28438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21590,5392,23668,1025,32769,4160,32801,17,54530,349,64,34816,5393,17664,35188,1364,21793,257,21792,38224,22272]

theorem envBound28438 : H12AffineFastState.Bounded env28438 := by
  intro p hp
  have h : env28438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28437_28438 : H12AffineEnvironment.transform 12 348 env28437 = env28438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28437 == env28438) = true)

theorem identity28438 : scanCanonicalize (H12AffineFastState.compose env28438 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28438 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,262,5392,2340,1025,32769,4160,32801,17,32850,349,64,34816,5393,4176,35188,1364,113,257,112,38224,592]

theorem envBound28439 : H12AffineFastState.Bounded env28439 := by
  intro p hp
  have h : env28439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28438_28439 : H12AffineEnvironment.transform 13 5456 env28438 = env28439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28438 == env28439) = true)

theorem identity28439 : scanCanonicalize (H12AffineFastState.compose env28439 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28439 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28440 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,32768,262,5392,2340,1025,32769,4112,32801,17,32770,269,16,34816,5393,4096,35108,1284,33,257,32,38144,512]

theorem envBound28440 : H12AffineFastState.Bounded env28440 := by
  intro p hp
  have h : env28440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28439_28440 : H12AffineEnvironment.transform 5 16 env28439 = env28440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28439 == env28440) = true)

theorem identity28440 : scanCanonicalize (H12AffineFastState.compose env28440 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound28440 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28441 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,32,262,5392,2340,1025,33,4112,1,17,34,269,16,2080,5393,4096,2308,1284,33,257,32,5408,512]

theorem envBound28441 : H12AffineFastState.Bounded env28441 := by
  intro p hp
  have h : env28441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28440_28441 : H12AffineEnvironment.transform 14 32 env28440 = env28441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env28440 == env28441) = true)

theorem identity28441 : scanCanonicalize (H12AffineFastState.compose env28441 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28442 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5124,32,2,5140,2080,1025,33,4112,1,17,34,9,16,2080,5141,4096,2048,1024,33,5,32,5156,512]

theorem envBound28442 : H12AffineFastState.Bounded env28442 := by
  intro p hp
  have h : env28442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28441_28442 : H12AffineEnvironment.transform 7 4 env28441 = env28442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28441 == env28442) = true)

theorem identity28442 : scanCanonicalize (H12AffineFastState.compose env28442 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound28442 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env28443 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1567,4096,8,5124,32,2,5140,1599,1025,33,4112,1,17,34,9,16,1599,5141,4096,1567,1024,33,5,32,5156,512]

theorem envBound28443 : H12AffineFastState.Bounded env28443 := by
  intro p hp
  have h : env28443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28442_28443 : H12AffineEnvironment.transform 10 1567 env28442 = env28443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env28442 == env28443) = true)

def env28444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144476,243089,8328,64,43476,139612,160076,324701,1500,272392,257,21792,46213,74251]

theorem envBound28444 : H12AffineFastState.Bounded env28444 := by
  intro p hp
  have h : env28444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28428_28444 : H12AffineEnvironment.transform 20 4161 env28428 = env28444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28428 == env28444) = true)

theorem identity28444 : scanCanonicalize (H12AffineFastState.compose env28444 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28444 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,400589,144476,213317,8328,64,23808,139612,160076,262281,1500,272392,257,21792,16465,74251]

theorem envBound28445 : H12AffineFastState.Bounded env28445 := by
  intro p hp
  have h : env28445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28444_28445 : H12AffineEnvironment.transform 14 29908 env28444 = env28445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28444 == env28445) = true)

def env28446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32240,1025,29909,4161,155965,144476,213317,8328,64,23808,139612,160076,32121,1500,22008,257,21792,16465,74251]

theorem envBound28446 : H12AffineFastState.Bounded env28446 := by
  intro p hp
  have h : env28446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28445_28446 : H12AffineEnvironment.transform 17 32240 env28445 = env28446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env28445 == env28446) = true)

theorem identity28446 : scanCanonicalize (H12AffineFastState.compose env28446 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound28446 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79298,32240,1025,29909,4161,87295,65950,29831,8328,64,23808,70814,83086,32121,1500,22008,257,21792,16465,74251]

theorem envBound28447 : H12AffineFastState.Bounded env28447 := by
  intro p hp
  have h : env28447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28446_28447 : H12AffineEnvironment.transform 16 79298 env28446 = env28447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env28446 == env28447) = true)

def env28448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32241,1025,29909,4161,155964,144476,213317,8328,64,23808,139612,160076,32120,1500,22009,257,21792,16465,74251]

theorem envBound28448 : H12AffineFastState.Bounded env28448 := by
  intro p hp
  have h : env28448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28445_28448 : H12AffineEnvironment.transform 17 32241 env28445 = env28448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env28445 == env28448) = true)

theorem identity28448 : scanCanonicalize (H12AffineFastState.compose env28448 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound28448 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79179,32241,1025,29909,4161,87159,65815,29710,8328,64,23808,70679,82951,32120,1500,22009,257,21792,16465,74251]

theorem envBound28449 : H12AffineFastState.Bounded env28449 := by
  intro p hp
  have h : env28449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28448_28449 : H12AffineEnvironment.transform 16 79179 env28448 = env28449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env28448 == env28449) = true)

theorem identity28449 : scanCanonicalize (H12AffineFastState.compose env28449 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound28449 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30083,16584,32241,1025,29909,4161,8692,29844,29710,8328,64,23808,24980,12676,32120,1500,22009,257,21792,16465,22408]

theorem envBound28450 : H12AffineFastState.Bounded env28450 := by
  intro p hp
  have h : env28450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28449_28450 : H12AffineEnvironment.transform 15 30083 env28449 = env28450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env28449 == env28450) = true)

theorem identity28450 : scanCanonicalize (H12AffineFastState.compose env28450 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound28450 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env28451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,21590,16584,23588,1025,21760,4161,33,21825,21979,349,64,23808,16449,4177,23725,1500,22009,257,21792,16465,22408]

theorem envBound28451 : H12AffineFastState.Bounded env28451 := by
  intro p hp
  have h : env28451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28450_28451 : H12AffineEnvironment.transform 12 469 env28450 = env28451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env28450 == env28451) = true)

theorem identity28451 : scanCanonicalize (H12AffineFastState.compose env28451 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28451 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,479,5441,2477,1025,137,4161,33,200,82,349,64,2185,5576,4177,2340,1500,112,257,169,5592,513]

theorem envBound28452 : H12AffineFastState.Bounded env28452 := by
  intro p hp
  have h : env28452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28451_28452 : H12AffineEnvironment.transform 13 5513 env28451 = env28452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28451 == env28452) = true)

theorem identity28452 : scanCanonicalize (H12AffineFastState.compose env28452 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28453 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,81,262,5441,2420,1025,80,4161,33,17,82,349,64,2128,5393,4177,2340,1285,112,257,112,5377,513]

theorem envBound28453 : H12AffineFastState.Bounded env28453 := by
  intro p hp
  have h : env28453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28452_28453 : H12AffineEnvironment.transform 6 89 env28452 = env28453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28452 == env28453) = true)

theorem identity28453 : scanCanonicalize (H12AffineFastState.compose env28453 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound28453 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28454 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,773,268,1621,81,262,1604,2420,1025,80,836,33,17,82,349,64,2128,1556,852,2340,1285,112,257,112,1540,513]

theorem envBound28454 : H12AffineFastState.Bounded env28454 := by
  intro p hp
  have h : env28454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28453_28454 : H12AffineEnvironment.transform 11 773 env28453 = env28454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env28453 == env28454) = true)

theorem identity28454 : scanCanonicalize (H12AffineFastState.compose env28454 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound28454 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env28455 : List Nat := [2,4,8,16,32,64,89,256,512,1024,815,773,268,1621,81,262,1604,603,1025,80,836,33,17,82,349,64,895,1556,852,523,1285,112,257,112,1540,513]

theorem envBound28455 : H12AffineFastState.Bounded env28455 := by
  intro p hp
  have h : env28455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28454_28455 : H12AffineEnvironment.transform 10 815 env28454 = env28455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env28454 == env28455) = true)

theorem identity28455 : scanCanonicalize (H12AffineFastState.compose env28455 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound28455 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28456 : List Nat := [2,4,8,16,32,64,89,256,512,305,815,773,268,868,81,262,885,603,304,80,836,33,17,82,349,64,895,805,852,523,52,112,257,112,821,513]

theorem envBound28456 : H12AffineFastState.Bounded env28456 := by
  intro p hp
  have h : env28456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28455_28456 : H12AffineEnvironment.transform 9 305 env28455 = env28456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env28455 == env28456) = true)

theorem identity28456 : scanCanonicalize (H12AffineFastState.compose env28456 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28456 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28457 : List Nat := [2,4,8,16,32,64,89,4,512,53,555,513,8,608,81,2,625,603,52,80,576,33,17,82,89,64,635,545,592,523,52,112,5,112,561,513]

theorem envBound28457 : H12AffineFastState.Bounded env28457 := by
  intro p hp
  have h : env28457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28456_28457 : H12AffineEnvironment.transform 7 4 env28456 = env28457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28456 == env28457) = true)

theorem identity28457 : scanCanonicalize (H12AffineFastState.compose env28457 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound28457 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28458 : List Nat := [2,4,8,16,22,64,89,4,512,3,541,513,8,598,81,2,583,603,2,80,576,23,17,82,89,64,589,535,592,523,2,70,5,70,519,513]

theorem envBound28458 : H12AffineFastState.Bounded env28458 := by
  intro p hp
  have h : env28458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28457_28458 : H12AffineEnvironment.transform 4 22 env28457 = env28458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env28457 == env28458) = true)

def env28459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound28459 : H12AffineFastState.Bounded env28459 := by
  intro p hp
  have h : env28459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27808_28459 : H12AffineEnvironment.transform 25 65 env27808 = env28459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env27808 == env28459) = true)

def env28460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound28460 : H12AffineFastState.Bounded env28460 := by
  intro p hp
  have h : env28460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28459_28460 : H12AffineEnvironment.transform 26 30393344 env28459 = env28460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env28459 == env28460) = true)

def env28461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound28461 : H12AffineFastState.Bounded env28461 := by
  intro p hp
  have h : env28461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28460_28461 : H12AffineEnvironment.transform 18 1024 env28460 = env28461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28460 == env28461) = true)

theorem identity28461 : scanCanonicalize (H12AffineFastState.compose env28461 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874365) := by decide +kernel

theorem selectedBound28461 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874365,8328,65,4237693,10939888,10507600,8830977,453997,15076541,256,2534865,2509940,510650]

theorem envBound28462 : H12AffineFastState.Bounded env28462 := by
  intro p hp
  have h : env28462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28461_28462 : H12AffineEnvironment.transform 23 8874365 env28461 = env28462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874365 env28461 == env28462) = true)

def env28463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,8388608,8874365,8328,65,4237693,8393984,8826272,8830977,453997,12645453,256,21793,46212,510650]

theorem envBound28463 : H12AffineFastState.Bounded env28463 := by
  intro p hp
  have h : env28463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28462_28463 : H12AffineEnvironment.transform 20 456944 env28462 = env28463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env28462 == env28463) = true)

def env28464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,98781,8328,65,4237693,458144,17664,10401,453997,4594925,256,21793,46212,510650]

theorem envBound28464 : H12AffineFastState.Bounded env28464 := by
  intro p hp
  have h : env28464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28463_28464 : H12AffineEnvironment.transform 22 452768 env28463 = env28464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env28463 == env28464) = true)

def env28465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,98781,8328,65,295421,458144,17664,10401,453997,144493,256,21793,46212,510650]

theorem envBound28465 : H12AffineFastState.Bounded env28465 := by
  intro p hp
  have h : env28465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28464_28465 : H12AffineEnvironment.transform 21 272512 env28464 = env28465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28464 == env28465) = true)

theorem identity28465 : scanCanonicalize (H12AffineFastState.compose env28465 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound28465 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180272,16,98781,8328,65,158029,5392,17664,10401,1501,144493,256,21793,46212,74250]

theorem envBound28466 : H12AffineFastState.Bounded env28466 := by
  intro p hp
  have h : env28466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28465_28466 : H12AffineEnvironment.transform 17 190640 env28465 = env28466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env28465 == env28466) = true)

theorem identity28466 : scanCanonicalize (H12AffineFastState.compose env28466 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28466 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,180272,16,41430,8328,65,158029,5392,17664,10401,1501,144493,256,21793,46212,513]

theorem envBound28467 : H12AffineFastState.Bounded env28467 := by
  intro p hp
  have h : env28467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28466_28467 : H12AffineEnvironment.transform 15 8203 env28466 = env28467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28466 == env28467) = true)

theorem identity28467 : scanCanonicalize (H12AffineFastState.compose env28467 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound28467 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43169,1024,32769,4160,32801,16,41430,8328,65,10588,5392,17664,10401,1501,29820,256,21793,46212,513]

theorem envBound28468 : H12AffineFastState.Bounded env28468 := by
  intro p hp
  have h : env28468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28467_28468 : H12AffineEnvironment.transform 16 16401 env28467 = env28468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28467 == env28468) = true)

theorem identity28468 : scanCanonicalize (H12AffineFastState.compose env28468 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28468 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13388,43169,1024,32769,4160,32801,16,41430,8328,65,10588,5392,12637,10401,1501,33,256,8572,46212,513]

theorem envBound28469 : H12AffineFastState.Bounded env28469 := by
  intro p hp
  have h : env28469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28468_28469 : H12AffineEnvironment.transform 13 13405 env28468 = env28469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28468 == env28469) = true)

theorem identity28469 : scanCanonicalize (H12AffineFastState.compose env28469 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28469 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,13388,2556,1024,8540,4160,8572,16,139,8328,65,10588,5392,12637,10401,1501,33,256,8572,5593,513]

theorem envBound28470 : H12AffineFastState.Bounded env28470 := by
  intro p hp
  have h : env28470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28469_28470 : H12AffineEnvironment.transform 14 8541 env28469 = env28470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28469 == env28470) = true)

theorem identity28470 : scanCanonicalize (H12AffineFastState.compose env28470 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28470 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,343,5392,2556,1024,0,4160,32,16,139,468,65,2048,5392,4097,2557,1501,33,256,32,5593,513]

theorem envBound28471 : H12AffineFastState.Bounded env28471 := by
  intro p hp
  have h : env28471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28470_28471 : H12AffineEnvironment.transform 12 348 env28470 = env28471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28470 == env28471) = true)

theorem identity28471 : scanCanonicalize (H12AffineFastState.compose env28471 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound28471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2420,348,3189,1,343,3172,2556,1024,0,2356,32,16,139,468,65,2048,3172,2421,2557,1501,33,256,32,3245,513]

theorem envBound28472 : H12AffineFastState.Bounded env28472 := by
  intro p hp
  have h : env28472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28471_28472 : H12AffineEnvironment.transform 11 2420 env28471 = env28472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env28471 == env28472) = true)

theorem identity28472 : scanCanonicalize (H12AffineFastState.compose env28472 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound28472 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env28473 : List Nat := [2,4,8,16,32,64,128,231,512,1024,2048,2195,187,3189,1,176,3172,2075,1024,0,2259,32,16,139,51,65,2048,3172,2194,2074,1082,33,231,32,3245,513]

theorem envBound28473 : H12AffineFastState.Bounded env28473 := by
  intro p hp
  have h : env28473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28472_28473 : H12AffineEnvironment.transform 7 231 env28472 = env28473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env28472 == env28473) = true)

def env28474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,98781,8328,65,295420,458144,17664,10401,453997,144492,256,21793,46212,510650]

theorem envBound28474 : H12AffineFastState.Bounded env28474 := by
  intro p hp
  have h : env28474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28464_28474 : H12AffineEnvironment.transform 21 272513 env28464 = env28474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28464 == env28474) = true)

def env28475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452648,98645,8192,65,295284,458024,17664,10281,453997,144492,256,21793,46092,510514]

theorem envBound28475 : H12AffineFastState.Bounded env28475 := by
  intro p hp
  have h : env28475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28474_28475 : H12AffineEnvironment.transform 6 8 env28474 = env28475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28474 == env28475) = true)

theorem identity28475 : scanCanonicalize (H12AffineFastState.compose env28475 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound28475 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,309353,272393,305209,98645,8192,65,295284,310585,17664,10281,306556,29821,256,21793,46092,363043]

theorem envBound28476 : H12AffineFastState.Bounded env28476 := by
  intro p hp
  have h : env28476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28475_28476 : H12AffineEnvironment.transform 16 16401 env28475 = env28476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28475 == env28476) = true)

theorem identity28476 : scanCanonicalize (H12AffineFastState.compose env28476 (packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound28476 : packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,76159,1024,32769,102678,65910,98630,98645,8192,65,108555,103494,17664,10281,99331,29821,256,21793,46092,41820]

theorem envBound28477 : H12AffineFastState.Bounded env28477 := by
  intro p hp
  have h : env28477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28476_28477 : H12AffineEnvironment.transform 17 76159 env28476 = env28477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env28476 == env28477) = true)

theorem identity28477 : scanCanonicalize (H12AffineFastState.compose env28477 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28477 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2421,1024,32769,45340,8572,41292,41311,8192,65,34817,46156,17664,10281,41993,29821,256,21793,46092,41820]

theorem envBound28478 : H12AffineFastState.Bounded env28478 := by
  intro p hp
  have h : env28478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28477_28478 : H12AffineEnvironment.transform 15 8202 env28477 = env28478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28477 == env28478) = true)

theorem identity28478 : scanCanonicalize (H12AffineFastState.compose env28478 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound28478 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env28479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,8202,16401,2421,1024,30073,17508,8572,21556,21543,8192,65,32121,16692,17664,10281,20849,29821,256,21793,16756,22052]

theorem envBound28479 : H12AffineFastState.Bounded env28479 := by
  intro p hp
  have h : env28479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28478_28479 : H12AffineEnvironment.transform 14 30072 env28478 = env28479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env28478 == env28479) = true)

theorem identity28479 : scanCanonicalize (H12AffineFastState.compose env28479 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound28479 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8541,8202,5172,2421,1024,8540,4161,8572,17,2,8192,65,10588,5393,4389,10281,1364,8280,256,260,5457,513]

theorem envBound28480 : H12AffineFastState.Bounded env28480 := by
  intro p hp
  have h : env28480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28479_28480 : H12AffineEnvironment.transform 13 5157 env28479 = env28480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env28479 == env28480) = true)

def env28481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452649,98644,8193,65,295285,458025,17664,10280,453997,144492,256,21793,46093,510515]

theorem envBound28481 : H12AffineFastState.Bounded env28481 := by
  intro p hp
  have h : env28481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28474_28481 : H12AffineEnvironment.transform 6 9 env28474 = env28481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28474 == env28481) = true)

theorem identity28481 : scanCanonicalize (H12AffineFastState.compose env28481 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound28481 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254010,73755,98644,8193,65,215367,79131,17664,10280,75103,144492,256,21793,46093,513]

theorem envBound28482 : H12AffineFastState.Bounded env28482 := by
  intro p hp
  have h : env28482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28481_28482 : H12AffineEnvironment.transform 17 247858 env28481 = env28482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env28481 == env28482) = true)

theorem identity28482 : scanCanonicalize (H12AffineFastState.compose env28482 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound28482 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,77899,33,73755,98644,8193,65,43356,79131,17664,10280,75103,119927,256,21793,46093,513]

theorem envBound28483 : H12AffineFastState.Bounded env28483 := by
  intro p hp
  have h : env28483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28482_28483 : H12AffineEnvironment.transform 16 122907 env28482 = env28483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env28482 == env28483) = true)

theorem identity28483 : scanCanonicalize (H12AffineFastState.compose env28483 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28483 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env28484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4160,33,16,41311,8193,65,43356,5392,17664,10280,1364,62588,256,21793,46093,513]

theorem envBound28484 : H12AffineFastState.Bounded env28484 := by
  intro p hp
  have h : env28484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28483_28484 : H12AffineEnvironment.transform 15 8203 env28483 = env28484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28483 == env28484) = true)

theorem identity28484 : scanCanonicalize (H12AffineFastState.compose env28484 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28484 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49168,2340,1024,32769,4160,33,16,32850,268,65,34897,5392,17664,2341,1364,54641,256,21793,38144,513]

theorem envBound28485 : H12AffineFastState.Bounded env28485 := by
  intro p hp
  have h : env28485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28484_28485 : H12AffineEnvironment.transform 12 269 env28484 = env28485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28484 == env28485) = true)

theorem identity28485 : scanCanonicalize (H12AffineFastState.compose env28485 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28485 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,262,38209,2340,1024,32769,4160,33,16,32850,268,65,34897,5392,4177,2341,1364,32800,256,112,38144,513]

theorem envBound28486 : H12AffineFastState.Bounded env28486 := by
  intro p hp
  have h : env28486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28485_28486 : H12AffineEnvironment.transform 13 5457 env28485 = env28486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env28485 == env28486) = true)

theorem identity28486 : scanCanonicalize (H12AffineFastState.compose env28486 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound28486 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,81,262,5392,2340,1024,80,4160,33,16,3,268,65,2048,5392,4177,2341,1364,113,256,112,5457,513]

theorem envBound28487 : H12AffineFastState.Bounded env28487 := by
  intro p hp
  have h : env28487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28486_28487 : H12AffineEnvironment.transform 14 81 env28486 = env28487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env28486 == env28487) = true)

theorem identity28487 : scanCanonicalize (H12AffineFastState.compose env28487 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound28487 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2096,269,3425,81,262,3360,2340,1024,80,2160,33,16,3,268,65,2048,3360,2145,2341,1364,113,256,112,3425,513]

theorem envBound28488 : H12AffineFastState.Bounded env28488 := by
  intro p hp
  have h : env28488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28487_28488 : H12AffineEnvironment.transform 11 2096 env28487 = env28488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env28487 == env28488) = true)

theorem identity28488 : scanCanonicalize (H12AffineFastState.compose env28488 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound28488 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28489 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,2096,269,2128,81,262,2065,2340,305,80,2160,33,16,3,268,65,2048,2065,2145,2341,101,113,256,112,2128,513]

theorem envBound28489 : H12AffineFastState.Bounded env28489 := by
  intro p hp
  have h : env28489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28488_28489 : H12AffineEnvironment.transform 9 305 env28488 = env28489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env28488 == env28489) = true)

theorem identity28489 : scanCanonicalize (H12AffineFastState.compose env28489 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound28489 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28490 : List Nat := [2,4,8,16,32,49,9,256,512,305,2048,2096,269,2081,32,262,2065,2340,305,33,2049,33,16,3,268,48,2048,2065,2064,2341,20,0,256,1,2081,513]

theorem envBound28490 : H12AffineFastState.Bounded env28490 := by
  intro p hp
  have h : env28490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28489_28490 : H12AffineEnvironment.transform 5 49 env28489 = env28490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env28489 == env28490) = true)

theorem identity28490 : scanCanonicalize (H12AffineFastState.compose env28490 (packedSelected [3,5,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28490 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env28491 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,2064,269,2049,0,262,2065,2308,273,1,2049,1,16,3,268,16,2048,2065,2064,2309,20,0,256,1,2049,513]

theorem envBound28491 : H12AffineFastState.Bounded env28491 := by
  intro p hp
  have h : env28491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28490_28491 : H12AffineEnvironment.transform 4 0 env28490 = env28491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28490 == env28491) = true)

theorem identity28491 : scanCanonicalize (H12AffineFastState.compose env28491 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound28491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28492 : List Nat := [2,4,8,16,0,17,9,256,512,273,260,276,269,261,0,262,277,0,273,1,261,1,16,3,268,16,260,277,276,1,20,0,256,1,261,513]

theorem envBound28492 : H12AffineFastState.Bounded env28492 := by
  intro p hp
  have h : env28492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28491_28492 : H12AffineEnvironment.transform 10 260 env28491 = env28492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env28491 == env28492) = true)

def env28493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,98780,8328,65,4237693,458145,17665,10400,453997,4594924,256,21793,46212,510650]

theorem envBound28493 : H12AffineFastState.Bounded env28493 := by
  intro p hp
  have h : env28493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28463_28493 : H12AffineEnvironment.transform 22 452769 env28463 = env28493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env28463 == env28493) = true)

def env28494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,98780,8328,65,295421,458145,17665,10400,453997,144492,256,21793,46212,510650]

theorem envBound28494 : H12AffineFastState.Bounded env28494 := by
  intro p hp
  have h : env28494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28493_28494 : H12AffineEnvironment.transform 21 272512 env28493 = env28494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28493 == env28494) = true)

theorem identity28494 : scanCanonicalize (H12AffineFastState.compose env28494 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound28494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58516,144612,62661,98780,8328,65,171417,57797,17665,10400,61705,144492,256,21793,46212,120542]

theorem envBound28495 : H12AffineFastState.Bounded env28495 := by
  intro p hp
  have h : env28495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28494_28495 : H12AffineEnvironment.transform 17 138340 env28494 = env28495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env28494 == env28495) = true)

def env28496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144492,62541,98644,8192,65,171281,57677,17665,10280,61705,144492,256,21793,46092,120406]

theorem envBound28496 : H12AffineFastState.Bounded env28496 := by
  intro p hp
  have h : env28496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28495_28496 : H12AffineEnvironment.transform 6 8 env28495 = env28496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28495 == env28496) = true)

theorem identity28496 : scanCanonicalize (H12AffineFastState.compose env28496 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 114739) := by decide +kernel

theorem selectedBound28496 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env28497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,114739,121943,1024,32769,58396,128095,62541,98644,8192,65,89378,57677,17665,10280,61705,128095,256,21793,46092,120406]

theorem envBound28497 : H12AffineFastState.Bounded env28497 := by
  intro p hp
  have h : env28497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28496_28497 : H12AffineEnvironment.transform 16 114739 env28496 = env28497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114739 env28496 == env28497) = true)

theorem identity28497 : scanCanonicalize (H12AffineFastState.compose env28497 (packedSelected [4,7,8,9,10,11,12,15,16,20,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound28497 : packedSelected [4,7,8,9,10,11,12,15,16,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env28498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,65536,79130,76158,1024,29992,4405,65910,356,95357,8192,65,89378,5220,17665,10280,1056,65910,256,21793,16677,74623]

theorem envBound28498 : H12AffineFastState.Bounded env28498 := by
  intro p hp
  have h : env28498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28497_28498 : H12AffineEnvironment.transform 14 29993 env28497 = env28498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env28497 == env28498) = true)

theorem identity28498 : scanCanonicalize (H12AffineFastState.compose env28498 (packedSelected [0,1,2,3,5,6,8,10,11,14,16,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound28498 : packedSelected [0,1,2,3,5,6,8,10,11,14,16,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env28499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,1,65536,79130,76158,1024,0,4405,65910,356,65877,8192,65,75786,5220,12329,10280,1056,65910,256,8201,13325,74623]

theorem envBound28499 : H12AffineFastState.Bounded env28499 := by
  intro p hp
  have h : env28499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28498_28499 : H12AffineEnvironment.transform 13 13608 env28498 = env28499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env28498 == env28499) = true)

theorem identity28499 : scanCanonicalize (H12AffineFastState.compose env28499 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound28499 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env28500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,1,8574,5220,2048,1024,0,4405,8200,356,8235,8192,65,2420,5220,12329,10280,1056,8200,256,8201,13325,513]

theorem envBound28500 : H12AffineFastState.Bounded env28500 := by
  intro p hp
  have h : env28500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28499_28500 : H12AffineEnvironment.transform 15 8574 env28499 = env28500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env28499 == env28500) = true)

theorem identity28500 : scanCanonicalize (H12AffineFastState.compose env28500 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound28500 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4113,1,1095,5220,2048,1024,0,4405,1329,356,1298,1337,65,2420,5220,5392,3345,1056,1329,256,1328,4404,513]

theorem envBound28501 : H12AffineFastState.Bounded env28501 := by
  intro p hp
  have h : env28501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28500_28501 : H12AffineEnvironment.transform 12 1337 env28500 = env28501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env28500 == env28501) = true)

theorem identity28501 : scanCanonicalize (H12AffineFastState.compose env28501 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28501 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env28502 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,4113,1,1047,5172,2048,1024,0,4405,1329,308,1298,1337,17,2340,5172,5392,3345,1056,1329,256,1328,4404,513]

theorem envBound28502 : H12AffineFastState.Bounded env28502 := by
  intro p hp
  have h : env28502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28501_28502 : H12AffineEnvironment.transform 5 16 env28501 = env28502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28501 == env28502) = true)

theorem identity28502 : scanCanonicalize (H12AffineFastState.compose env28502 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28502 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env28503 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1053,4113,1,1047,5172,2048,1024,0,4113,1045,16,1078,1053,17,2048,5172,5172,3125,1056,1045,36,1044,4112,513]

theorem envBound28503 : H12AffineFastState.Bounded env28503 := by
  intro p hp
  have h : env28503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28502_28503 : H12AffineEnvironment.transform 7 36 env28502 = env28503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28502 == env28503) = true)

theorem identity28503 : scanCanonicalize (H12AffineFastState.compose env28503 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound28503 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28504 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,513,1053,528,1,1047,1589,2048,1024,0,528,1045,16,1078,1053,17,2048,1589,1589,3125,1056,1045,36,1044,529,513]

theorem envBound28504 : H12AffineFastState.Bounded env28504 := by
  intro p hp
  have h : env28504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28503_28504 : H12AffineEnvironment.transform 11 513 env28503 = env28504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env28503 == env28504) = true)

theorem identity28504 : scanCanonicalize (H12AffineFastState.compose env28504 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound28504 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28505 : List Nat := [2,4,8,16,32,16,8,36,512,20,2048,513,9,528,1,3,545,2048,20,0,528,1,16,34,9,17,2048,545,545,2081,52,1,36,0,529,513]

theorem envBound28505 : H12AffineFastState.Bounded env28505 := by
  intro p hp
  have h : env28505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28504_28505 : H12AffineEnvironment.transform 9 20 env28504 = env28505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28504 == env28505) = true)

theorem identity28505 : scanCanonicalize (H12AffineFastState.compose env28505 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound28505 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28506 : List Nat := [2,4,8,16,32,16,8,36,33,20,2048,32,9,49,1,3,0,2048,20,0,49,1,16,34,9,17,2048,0,0,2081,52,1,36,0,48,32]

theorem envBound28506 : H12AffineFastState.Bounded env28506 := by
  intro p hp
  have h : env28506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28505_28506 : H12AffineEnvironment.transform 8 33 env28505 = env28506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env28505 == env28506) = true)

theorem identity28506 : scanCanonicalize (H12AffineFastState.compose env28506 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound28506 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28507 : List Nat := [2,4,8,16,32,16,8,36,33,20,49,32,9,49,1,3,0,49,20,0,49,1,16,34,9,17,49,0,0,16,52,1,36,0,48,32]

theorem envBound28507 : H12AffineFastState.Bounded env28507 := by
  intro p hp
  have h : env28507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28506_28507 : H12AffineEnvironment.transform 10 49 env28506 = env28507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env28506 == env28507) = true)

theorem identity28507 : scanCanonicalize (H12AffineFastState.compose env28507 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28507 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28508 : List Nat := [2,4,8,16,0,16,8,4,1,20,17,0,9,17,1,3,0,17,20,0,17,1,16,2,9,17,17,0,0,16,20,1,4,0,16,0]

theorem envBound28508 : H12AffineFastState.Bounded env28508 := by
  intro p hp
  have h : env28508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28507_28508 : H12AffineEnvironment.transform 4 0 env28507 = env28508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28507 == env28508) = true)

def env28509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144493,62540,98645,8193,65,171280,57676,17665,10281,61705,144492,256,21793,46093,120407]

theorem envBound28509 : H12AffineFastState.Bounded env28509 := by
  intro p hp
  have h : env28509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28495_28509 : H12AffineEnvironment.transform 6 9 env28495 = env28509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28495 == env28509) = true)

theorem identity28509 : scanCanonicalize (H12AffineFastState.compose env28509 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28509 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env28510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138340,1024,32769,45340,144493,41293,98645,8193,65,171280,46157,4096,10281,41992,144492,256,32,46093,99158]

theorem envBound28510 : H12AffineFastState.Bounded env28510 := by
  intro p hp
  have h : env28510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28509_28510 : H12AffineEnvironment.transform 13 5377 env28509 = env28510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28509 == env28510) = true)

theorem identity28510 : scanCanonicalize (H12AffineFastState.compose env28510 (packedSelected [1,3,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound28510 : packedSelected [1,3,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41051,131072,138340,1024,32769,45340,144493,41293,8462,8193,65,171280,46157,4096,10281,41992,144492,256,32,46093,8973]

theorem envBound28511 : H12AffineFastState.Bounded env28511 := by
  intro p hp
  have h : env28511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28510_28511 : H12AffineEnvironment.transform 15 41051 env28510 = env28511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env28510 == env28511) = true)

theorem identity28511 : scanCanonicalize (H12AffineFastState.compose env28511 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound28511 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env28512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,343,131072,138340,1024,8461,4112,144493,65,8462,8193,65,146460,5441,4096,10281,1284,144492,256,32,5377,8973]

theorem envBound28512 : H12AffineFastState.Bounded env28512 := by
  intro p hp
  have h : env28512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28511_28512 : H12AffineEnvironment.transform 14 8460 env28511 = env28512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env28511 == env28512) = true)

theorem identity28512 : scanCanonicalize (H12AffineFastState.compose env28512 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28512 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28513 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,262,131072,138293,1024,8461,4112,144444,16,8462,8193,16,146460,5392,4096,10281,1284,144445,256,32,5377,8973]

theorem envBound28513 : H12AffineFastState.Bounded env28513 := by
  intro p hp
  have h : env28513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28512_28513 : H12AffineEnvironment.transform 5 17 env28512 = env28513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28512 == env28513) = true)

theorem identity28513 : scanCanonicalize (H12AffineFastState.compose env28513 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28513 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28514 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8460,262,131072,138261,1024,8461,4112,144412,16,8462,8193,16,146460,5392,4096,10249,1284,144413,256,0,5377,8973]

theorem envBound28514 : H12AffineFastState.Bounded env28514 := by
  intro p hp
  have h : env28514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28513_28514 : H12AffineEnvironment.transform 4 0 env28513 = env28514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28513 == env28514) = true)

theorem identity28514 : scanCanonicalize (H12AffineFastState.compose env28514 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound28514 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28515 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8460,262,5393,2308,1024,8461,4112,8461,16,8462,8193,16,10509,5392,4096,10249,1284,8460,256,0,5377,8973]

theorem envBound28515 : H12AffineFastState.Bounded env28515 := by
  intro p hp
  have h : env28515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28514_28515 : H12AffineEnvironment.transform 16 5393 env28514 = env28515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env28514 == env28515) = true)

theorem identity28515 : scanCanonicalize (H12AffineFastState.compose env28515 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound28515 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28516 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,8192,1306,8460,262,1290,2308,1024,8461,11,8461,16,8462,8193,16,10509,1291,27,10249,1284,8460,256,0,1306,8973]

theorem envBound28516 : H12AffineFastState.Bounded env28516 := by
  intro p hp
  have h : env28516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28515_28516 : H12AffineEnvironment.transform 11 27 env28515 = env28516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env28515 == env28516) = true)

theorem identity28516 : scanCanonicalize (H12AffineFastState.compose env28516 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound28516 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env28517 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,2056,1306,2308,262,1290,2308,1024,2309,11,2309,16,2310,2057,16,261,1291,27,1,1284,2308,256,0,1306,2821]

theorem envBound28517 : H12AffineFastState.Bounded env28517 := by
  intro p hp
  have h : env28517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28516_28517 : H12AffineEnvironment.transform 12 2056 env28516 = env28517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env28516 == env28517) = true)

theorem identity28517 : scanCanonicalize (H12AffineFastState.compose env28517 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28517 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28518 : List Nat := [2,4,8,16,0,17,9,256,512,4,2048,27,2056,286,2308,262,270,2308,4,2309,11,2309,16,2310,2057,16,261,271,27,1,256,2308,256,0,286,2821]

theorem envBound28518 : H12AffineFastState.Bounded env28518 := by
  intro p hp
  have h : env28518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28517_28518 : H12AffineEnvironment.transform 9 4 env28517 = env28518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28517 == env28518) = true)

theorem identity28518 : scanCanonicalize (H12AffineFastState.compose env28518 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28519 : List Nat := [2,4,8,0,0,1,9,256,512,4,2048,11,2056,270,2308,262,270,2308,4,2309,11,2309,0,2310,2057,0,261,271,11,1,256,2308,256,0,270,2821]

theorem envBound28519 : H12AffineFastState.Bounded env28519 := by
  intro p hp
  have h : env28519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28518_28519 : H12AffineEnvironment.transform 3 0 env28518 = env28519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28518 == env28519) = true)

def env28520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,98780,8328,65,295420,458145,17665,10400,453997,144493,256,21793,46212,510650]

theorem envBound28520 : H12AffineFastState.Bounded env28520 := by
  intro p hp
  have h : env28520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28493_28520 : H12AffineEnvironment.transform 21 272513 env28493 = env28520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28493 == env28520) = true)

theorem identity28520 : scanCanonicalize (H12AffineFastState.compose env28520 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound28520 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396325,272513,400500,95497,8328,65,292137,395636,17665,10400,399800,144493,256,21793,16465,474735]

theorem envBound28521 : H12AffineFastState.Bounded env28521 := by
  intro p hp
  have h : env28521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28520_28521 : H12AffineEnvironment.transform 14 29909 env28520 = env28521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env28520 == env28521) = true)

def env28522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140421,33,144596,95497,8328,65,23945,139732,17665,10400,143640,144493,256,21793,16465,202447]

theorem envBound28522 : H12AffineFastState.Bounded env28522 := by
  intro p hp
  have h : env28522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28521_28522 : H12AffineEnvironment.transform 17 10400 env28521 = env28522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env28521 == env28522) = true)

theorem identity28522 : scanCanonicalize (H12AffineFastState.compose env28522 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound28522 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env28523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10400,1024,29908,83102,33,87247,95497,8328,65,23945,82383,17665,10400,86275,87158,256,21793,16465,30420]

theorem envBound28523 : H12AffineFastState.Bounded env28523 := by
  intro p hp
  have h : env28523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28522_28523 : H12AffineEnvironment.transform 16 90139 env28522 = env28523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env28522 == env28523) = true)

theorem identity28523 : scanCanonicalize (H12AffineFastState.compose env28523 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound28523 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env28524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,65536,70862,10400,1024,1,77899,33,73754,66012,8328,65,10588,79130,12756,10400,75222,73891,256,8692,13444,513]

theorem envBound28524 : H12AffineFastState.Bounded env28524 := by
  intro p hp
  have h : env28524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28523_28524 : H12AffineEnvironment.transform 13 13525 env28523 = env28524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env28523 == env28524) = true)

theorem identity28524 : scanCanonicalize (H12AffineFastState.compose env28524 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28524 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env28525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,262,5576,10400,1024,1,12621,33,8476,218,8328,65,10588,13340,12756,10400,9424,8613,256,8692,13444,513]

theorem envBound28525 : H12AffineFastState.Bounded env28525 := by
  intro p hp
  have h : env28525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28524_28525 : H12AffineEnvironment.transform 15 262 env28524 = env28525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28524 == env28525) = true)

theorem identity28525 : scanCanonicalize (H12AffineFastState.compose env28525 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28525 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env28526 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13325,0,262,5392,10360,1024,1,12621,33,8476,2,8272,65,10588,13340,12556,10360,9224,8573,256,8492,13404,513]

theorem envBound28526 : H12AffineFastState.Bounded env28526 := by
  intro p hp
  have h : env28526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28525_28526 : H12AffineEnvironment.transform 6 88 env28525 = env28526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28525 == env28526) = true)

theorem identity28526 : scanCanonicalize (H12AffineFastState.compose env28526 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28526 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env28527 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,262,5392,10281,1024,1,12572,33,8476,2,8193,16,10509,13340,12556,10281,9224,8492,256,8492,13325,513]

theorem envBound28527 : H12AffineFastState.Bounded env28527 := by
  intro p hp
  have h : env28527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28526_28527 : H12AffineEnvironment.transform 5 17 env28526 = env28527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28526 == env28527) = true)

def env28528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140420,32,144597,95497,8328,65,23944,139733,17665,10400,143641,144493,256,21793,16465,202446]

theorem envBound28528 : H12AffineFastState.Bounded env28528 := by
  intro p hp
  have h : env28528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28521_28528 : H12AffineEnvironment.transform 17 10401 env28521 = env28528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28521 == env28528) = true)

theorem identity28528 : scanCanonicalize (H12AffineFastState.compose env28528 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound28528 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env28529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79251,10401,1024,29908,69911,32,65862,95497,8328,65,23944,70726,17665,10400,66698,66046,256,21793,16465,9053]

theorem envBound28529 : H12AffineFastState.Bounded env28529 := by
  intro p hp
  have h : env28529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28528_28529 : H12AffineEnvironment.transform 16 79251 env28528 = env28529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env28528 == env28529) = true)

theorem identity28529 : scanCanonicalize (H12AffineFastState.compose env28529 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound28529 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS < 2^1333 := by decide +kernel

def env28530 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,29909,65536,78958,10401,1024,29908,69866,32,65723,95476,8328,65,23669,70726,17660,10400,66698,65539,253,21724,16465,8864]

theorem envBound28530 : H12AffineFastState.Bounded env28530 := by
  intro p hp
  have h : env28530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28529_28530 : H12AffineEnvironment.transform 7 253 env28529 = env28530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env28529 == env28530) = true)

theorem identity28530 : scanCanonicalize (H12AffineFastState.compose env28530 (packedSelected [1,2,3,4,6,8,11,12,15,16,19,22,23,24,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound28530 : packedSelected [1,2,3,4,6,8,11,12,15,16,19,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env28531 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13524,1,65536,78958,10401,1024,0,69866,32,65723,65568,8328,65,10401,70726,12328,10400,66698,65539,253,8200,13445,8864]

theorem envBound28531 : H12AffineFastState.Bounded env28531 := by
  intro p hp
  have h : env28531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28530_28531 : H12AffineEnvironment.transform 13 13524 env28530 = env28531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env28530 == env28531) = true)

theorem identity28531 : scanCanonicalize (H12AffineFastState.compose env28531 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound28531 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env28532 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13524,1,170,13508,10401,1024,0,4160,32,17,138,8328,65,10401,5356,12328,10400,1056,169,253,8200,13445,8864]

theorem envBound28532 : H12AffineFastState.Bounded env28532 := by
  intro p hp
  have h : env28532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28531_28532 : H12AffineEnvironment.transform 15 170 env28531 = env28532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env28531 == env28532) = true)

theorem identity28532 : scanCanonicalize (H12AffineFastState.compose env28532 (packedSelected [0,6,7,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound28532 : packedSelected [0,6,7,11,15] rootPS < 2^1333 := by decide +kernel

def env28533 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,9,5341,1,170,5325,2216,1024,0,4160,32,17,138,129,65,2216,5356,4129,2217,1056,169,253,1,5260,681]

theorem envBound28533 : H12AffineFastState.Bounded env28533 := by
  intro p hp
  have h : env28533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28532_28533 : H12AffineEnvironment.transform 12 9 env28532 = env28533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env28532 == env28533) = true)

theorem identity28533 : scanCanonicalize (H12AffineFastState.compose env28533 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28533 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env28534 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,9,5260,1,170,5276,2216,1024,0,4113,32,17,138,129,16,2216,5309,4129,2217,1056,169,172,1,5260,681]

theorem envBound28534 : H12AffineFastState.Bounded env28534 := by
  intro p hp
  have h : env28534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28533_28534 : H12AffineEnvironment.transform 5 17 env28533 = env28534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28533 == env28534) = true)

def env28535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,8388608,8874365,8328,65,4237693,8393985,8826273,8830977,453997,12645452,256,21792,46213,510650]

theorem envBound28535 : H12AffineFastState.Bounded env28535 := by
  intro p hp
  have h : env28535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28462_28535 : H12AffineEnvironment.transform 20 456945 env28462 = env28535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env28462 == env28535) = true)

def env28536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,98781,8328,65,4237693,458145,17665,10401,453997,4594924,256,21792,46213,510650]

theorem envBound28536 : H12AffineFastState.Bounded env28536 := by
  intro p hp
  have h : env28536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28535_28536 : H12AffineEnvironment.transform 22 452768 env28535 = env28536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env28535 == env28536) = true)

def env28537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,98781,8328,65,295421,458145,17665,10401,453997,144492,256,21792,46213,510650]

theorem envBound28537 : H12AffineFastState.Bounded env28537 := by
  intro p hp
  have h : env28537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28536_28537 : H12AffineEnvironment.transform 21 272512 env28536 = env28537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28536 == env28537) = true)

theorem identity28537 : scanCanonicalize (H12AffineFastState.compose env28537 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28537 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456945,272512,452768,41430,8328,65,295421,458145,17665,10401,453997,144492,256,21792,46213,453297]

theorem envBound28538 : H12AffineFastState.Bounded env28538 := by
  intro p hp
  have h : env28538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28537_28538 : H12AffineEnvironment.transform 15 8203 env28537 = env28538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28537 == env28538) = true)

theorem identity28538 : scanCanonicalize (H12AffineFastState.compose env28538 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28538 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env28539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,262144,1024,1,424177,272512,420000,8662,8328,65,262653,425377,17665,10401,421229,144492,256,21792,13445,420529]

theorem envBound28539 : H12AffineFastState.Bounded env28539 := by
  intro p hp
  have h : env28539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28538_28539 : H12AffineEnvironment.transform 14 0 env28538 = env28539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28538 == env28539) = true)

theorem identity28539 : scanCanonicalize (H12AffineFastState.compose env28539 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound28539 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,10401,1024,1,151632,33,147457,8662,8328,65,10588,152832,17665,10401,148940,144492,256,21792,13445,147984]

theorem envBound28540 : H12AffineFastState.Bounded env28540 := by
  intro p hp
  have h : env28540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28539_28540 : H12AffineEnvironment.transform 17 10401 env28539 = env28540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28539 == env28540) = true)

theorem identity28540 : scanCanonicalize (H12AffineFastState.compose env28540 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound28540 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,25029,10401,1024,1,12693,33,8644,8662,8328,65,10588,13509,17665,10401,9225,21929,256,21792,13445,9173]

theorem envBound28541 : H12AffineFastState.Bounded env28541 := by
  intro p hp
  have h : env28541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28540_28541 : H12AffineEnvironment.transform 16 25029 env28540 = env28541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env28540 == env28541) = true)

theorem identity28541 : scanCanonicalize (H12AffineFastState.compose env28541 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28541 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env28542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,342,16536,2556,1024,1,4296,33,153,139,469,65,2049,5528,17665,2556,1364,21929,256,21792,5592,648]

theorem envBound28542 : H12AffineFastState.Bounded env28542 := by
  intro p hp
  have h : env28542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28541_28542 : H12AffineEnvironment.transform 12 349 env28541 = env28542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28541 == env28542) = true)

theorem identity28542 : scanCanonicalize (H12AffineFastState.compose env28542 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28542 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env28543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,0,342,5392,2556,1024,1,4296,33,153,139,469,65,2049,5528,4233,2556,1364,33,256,168,5592,648]

theorem envBound28543 : H12AffineFastState.Bounded env28543 := by
  intro p hp
  have h : env28543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28542_28543 : H12AffineEnvironment.transform 13 5512 env28542 = env28543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28542 == env28543) = true)

theorem identity28543 : scanCanonicalize (H12AffineFastState.compose env28543 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28543 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4160,33,17,3,349,65,2049,5392,4097,2420,1364,33,256,32,5456,512]

theorem envBound28544 : H12AffineFastState.Bounded env28544 := by
  intro p hp
  have h : env28544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28543_28544 : H12AffineEnvironment.transform 6 8 env28543 = env28544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28543 == env28544) = true)

theorem identity28544 : scanCanonicalize (H12AffineFastState.compose env28544 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2619) := by decide +kernel

theorem selectedBound28544 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2619,349,3899,0,342,3883,2420,1024,1,2683,33,17,3,349,65,2049,3883,2618,2420,1364,33,256,32,3947,512]

theorem envBound28545 : H12AffineFastState.Bounded env28545 := by
  intro p hp
  have h : env28545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28544_28545 : H12AffineEnvironment.transform 11 2619 env28544 = env28545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2619 env28544 == env28545) = true)

theorem identity28545 : scanCanonicalize (H12AffineFastState.compose env28545 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound28545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28546 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2619,300,3899,0,295,3883,2309,1024,1,2570,33,17,3,300,48,2049,3883,2618,2309,1317,33,256,32,3866,512]

theorem envBound28546 : H12AffineFastState.Bounded env28546 := by
  intro p hp
  have h : env28546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28545_28546 : H12AffineEnvironment.transform 5 49 env28545 = env28546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env28545 == env28546) = true)

theorem identity28546 : scanCanonicalize (H12AffineFastState.compose env28546 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound28546 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28547 : List Nat := [2,4,8,16,32,49,8,256,512,1024,1329,1802,300,522,0,295,538,1076,1024,1,1851,33,17,3,300,48,1328,538,1803,1076,1317,33,256,32,555,512]

theorem envBound28547 : H12AffineFastState.Bounded env28547 := by
  intro p hp
  have h : env28547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28546_28547 : H12AffineEnvironment.transform 10 1329 env28546 = env28547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env28546 == env28547) = true)

theorem identity28547 : scanCanonicalize (H12AffineFastState.compose env28547 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound28547 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28548 : List Nat := [2,4,8,16,32,49,8,256,271,1024,1329,1029,300,261,0,295,277,1076,1024,1,1076,33,17,3,300,48,1328,277,1028,1076,1317,33,256,32,292,271]

theorem envBound28548 : H12AffineFastState.Bounded env28548 := by
  intro p hp
  have h : env28548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28547_28548 : H12AffineEnvironment.transform 8 271 env28547 = env28548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env28547 == env28548) = true)

theorem identity28548 : scanCanonicalize (H12AffineFastState.compose env28548 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound28548 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env28549 : List Nat := [2,4,8,16,32,49,8,256,271,21,292,16,300,261,0,295,277,33,21,1,33,33,17,3,300,48,293,277,17,33,304,33,256,32,292,271]

theorem envBound28549 : H12AffineFastState.Bounded env28549 := by
  intro p hp
  have h : env28549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28548_28549 : H12AffineEnvironment.transform 9 21 env28548 = env28549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env28548 == env28549) = true)

theorem identity28549 : scanCanonicalize (H12AffineFastState.compose env28549 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28549 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28550 : List Nat := [2,4,8,16,32,49,8,36,43,21,0,16,8,33,0,3,49,33,21,1,33,33,17,3,8,48,1,49,17,33,20,33,36,32,0,43]

theorem envBound28550 : H12AffineFastState.Bounded env28550 := by
  intro p hp
  have h : env28550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28549_28550 : H12AffineEnvironment.transform 7 36 env28549 = env28550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28549 == env28550) = true)

theorem identity28550 : scanCanonicalize (H12AffineFastState.compose env28550 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28551 : List Nat := [2,4,8,16,0,17,8,4,11,21,0,16,8,1,0,3,17,1,21,1,1,1,17,3,8,16,1,17,17,1,20,1,4,0,0,11]

theorem envBound28551 : H12AffineFastState.Bounded env28551 := by
  intro p hp
  have h : env28551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28550_28551 : H12AffineEnvironment.transform 4 0 env28550 = env28551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28550 == env28551) = true)

theorem identity28551 : scanCanonicalize (H12AffineFastState.compose env28551 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound28551 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28552 : List Nat := [2,4,8,5,0,4,8,4,11,0,0,5,8,1,0,3,4,1,0,1,1,1,4,3,8,5,1,4,4,1,1,1,4,0,0,11]

theorem envBound28552 : H12AffineFastState.Bounded env28552 := by
  intro p hp
  have h : env28552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28551_28552 : H12AffineEnvironment.transform 3 5 env28551 = env28552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env28551 == env28552) = true)

theorem identity28552 : scanCanonicalize (H12AffineFastState.compose env28552 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28552 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28553 : List Nat := [2,4,1,5,0,4,1,4,2,0,0,5,1,1,0,3,4,1,0,1,1,1,4,3,1,5,1,4,4,1,1,1,4,0,0,2]

theorem envBound28553 : H12AffineFastState.Bounded env28553 := by
  intro p hp
  have h : env28553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28552_28553 : H12AffineEnvironment.transform 2 1 env28552 = env28553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28552 == env28553) = true)

def env28554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,98781,8328,65,295420,458145,17665,10401,453997,144493,256,21792,46213,510650]

theorem envBound28554 : H12AffineFastState.Bounded env28554 := by
  intro p hp
  have h : env28554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28536_28554 : H12AffineEnvironment.transform 21 272513 env28536 = env28554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28536 == env28554) = true)

theorem identity28554 : scanCanonicalize (H12AffineFastState.compose env28554 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound28554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,77898,254010,73755,98781,8328,65,215367,79130,17665,10401,75222,144493,256,21792,46213,513]

theorem envBound28555 : H12AffineFastState.Bounded env28555 := by
  intro p hp
  have h : env28555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28554_28555 : H12AffineEnvironment.transform 17 247995 env28554 = env28555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env28554 == env28555) = true)

def env28556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77898,254010,73755,98645,8192,65,215367,79130,17665,10281,75102,144493,256,21792,46093,513]

theorem envBound28556 : H12AffineFastState.Bounded env28556 := by
  intro p hp
  have h : env28556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28555_28556 : H12AffineEnvironment.transform 6 8 env28555 = env28556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28555 == env28556) = true)

theorem identity28556 : scanCanonicalize (H12AffineFastState.compose env28556 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound28556 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env28557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,43048,1024,32769,77898,32801,73755,98645,8192,65,10588,79130,17665,10281,75102,87158,256,21792,46093,513]

theorem envBound28557 : H12AffineFastState.Bounded env28557 := by
  intro p hp
  have h : env28557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28556_28557 : H12AffineEnvironment.transform 16 90139 env28556 = env28557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env28556 == env28557) = true)

theorem identity28557 : scanCanonicalize (H12AffineFastState.compose env28557 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound28557 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,46109,43048,1024,32769,58444,32801,62493,21843,8192,65,10588,57628,17665,10281,61784,32880,256,21792,46093,513]

theorem envBound28558 : H12AffineFastState.Bounded env28558 := by
  intro p hp
  have h : env28558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28557_28558 : H12AffineEnvironment.transform 15 54278 env28557 = env28558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env28557 == env28558) = true)

theorem identity28558 : scanCanonicalize (H12AffineFastState.compose env28558 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 20837) := by decide +kernel

theorem selectedBound28558 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env28559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20837,1379,25976,31053,1024,20836,13609,20804,9592,21843,8192,65,10588,12409,17665,10281,8253,20757,256,21792,25960,513]

theorem envBound28559 : H12AffineFastState.Bounded env28559 := by
  intro p hp
  have h : env28559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28558_28559 : H12AffineEnvironment.transform 14 20837 env28558 = env28559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20837 env28558 == env28559) = true)

theorem identity28559 : scanCanonicalize (H12AffineFastState.compose env28559 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound28559 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS < 2^1333 := by decide +kernel

def env28560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,16384,20837,1379,16401,23588,1024,20836,4160,20804,17,21843,1385,65,3125,5392,17665,3392,1364,20757,256,21792,16385,513]

theorem envBound28560 : H12AffineFastState.Bounded env28560 := by
  intro p hp
  have h : env28560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28559_28560 : H12AffineEnvironment.transform 12 1385 env28559 = env28560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env28559 == env28560) = true)

theorem identity28560 : scanCanonicalize (H12AffineFastState.compose env28560 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28560 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28561 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,16384,20837,262,16401,22593,101,20836,4160,20804,17,20790,268,65,2128,4469,16740,2341,305,20757,256,20805,16385,513]

theorem envBound28561 : H12AffineFastState.Bounded env28561 := by
  intro p hp
  have h : env28561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28560_28561 : H12AffineEnvironment.transform 9 101 env28560 = env28561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28560 == env28561) = true)

theorem identity28561 : scanCanonicalize (H12AffineFastState.compose env28561 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound28561 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28562 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4161,292,262,4176,2048,101,293,4160,261,17,375,268,65,2128,4469,4389,2341,305,340,256,260,4160,513]

theorem envBound28562 : H12AffineFastState.Bounded env28562 := by
  intro p hp
  have h : env28562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28561_28562 : H12AffineEnvironment.transform 13 4161 env28561 = env28562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env28561 == env28562) = true)

theorem identity28562 : scanCanonicalize (H12AffineFastState.compose env28562 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28562 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env28563 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4113,292,262,4096,2048,53,293,4112,261,17,295,268,17,2048,4389,4389,2341,305,260,256,260,4112,513]

theorem envBound28563 : H12AffineFastState.Bounded env28563 := by
  intro p hp
  have h : env28563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28562_28563 : H12AffineEnvironment.transform 5 16 env28562 = env28563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28562 == env28563) = true)

def env28564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77898,254010,73755,98644,8193,65,215367,79130,17665,10280,75103,144493,256,21792,46092,513]

theorem envBound28564 : H12AffineFastState.Bounded env28564 := by
  intro p hp
  have h : env28564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28555_28564 : H12AffineEnvironment.transform 6 9 env28555 = env28564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28555 == env28564) = true)

theorem identity28564 : scanCanonicalize (H12AffineFastState.compose env28564 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound28564 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,77898,33,73755,98644,8193,65,43356,79130,17665,10280,75103,119926,256,21792,46092,513]

theorem envBound28565 : H12AffineFastState.Bounded env28565 := by
  intro p hp
  have h : env28565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28564_28565 : H12AffineEnvironment.transform 16 122907 env28564 = env28565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env28564 == env28565) = true)

theorem identity28565 : scanCanonicalize (H12AffineFastState.compose env28565 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28565 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env28566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4161,33,16,41311,8193,65,43356,5393,17665,10280,1364,62589,256,21792,46092,513]

theorem envBound28566 : H12AffineFastState.Bounded env28566 := by
  intro p hp
  have h : env28566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28565_28566 : H12AffineEnvironment.transform 15 8203 env28565 = env28566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28565 == env28566) = true)

theorem identity28566 : scanCanonicalize (H12AffineFastState.compose env28566 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28566 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49168,2340,1024,32769,4161,33,16,32850,268,65,34897,5393,17665,2341,1364,54640,256,21792,38145,513]

theorem envBound28567 : H12AffineFastState.Bounded env28567 := by
  intro p hp
  have h : env28567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28566_28567 : H12AffineEnvironment.transform 12 269 env28566 = env28567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28566 == env28567) = true)

theorem identity28567 : scanCanonicalize (H12AffineFastState.compose env28567 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28567 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,262,38208,2340,1024,32769,4161,33,16,32850,268,65,34897,5393,4177,2341,1364,32800,256,112,38145,513]

theorem envBound28568 : H12AffineFastState.Bounded env28568 := by
  intro p hp
  have h : env28568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28567_28568 : H12AffineEnvironment.transform 13 5456 env28567 = env28568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28567 == env28568) = true)

theorem identity28568 : scanCanonicalize (H12AffineFastState.compose env28568 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound28568 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,81,262,5393,2340,1024,80,4161,33,16,3,268,65,2048,5393,4177,2341,1364,113,256,112,5456,513]

theorem envBound28569 : H12AffineFastState.Bounded env28569 := by
  intro p hp
  have h : env28569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28568_28569 : H12AffineEnvironment.transform 14 81 env28568 = env28569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env28568 == env28569) = true)

theorem identity28569 : scanCanonicalize (H12AffineFastState.compose env28569 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound28569 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2144,269,3376,81,262,3441,2340,1024,80,2081,33,16,3,268,65,2048,3441,2097,2341,1364,113,256,112,3376,513]

theorem envBound28570 : H12AffineFastState.Bounded env28570 := by
  intro p hp
  have h : env28570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28569_28570 : H12AffineEnvironment.transform 11 2144 env28569 = env28570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env28569 == env28570) = true)

theorem identity28570 : scanCanonicalize (H12AffineFastState.compose env28570 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 352) := by decide +kernel

theorem selectedBound28570 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28571 : List Nat := [2,4,8,16,32,64,9,256,512,352,2048,2144,269,2128,81,262,2065,2340,352,80,2081,33,16,3,268,65,2048,2065,2097,2341,52,113,256,112,2128,513]

theorem envBound28571 : H12AffineFastState.Bounded env28571 := by
  intro p hp
  have h : env28571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28570_28571 : H12AffineEnvironment.transform 9 352 env28570 = env28571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 352 env28570 == env28571) = true)

theorem identity28571 : scanCanonicalize (H12AffineFastState.compose env28571 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28571 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28572 : List Nat := [2,4,8,16,1,64,9,256,512,321,2048,2113,269,2128,81,262,2065,2309,321,80,2048,0,16,3,268,65,2048,2065,2064,2308,21,80,256,81,2128,513]

theorem envBound28572 : H12AffineFastState.Bounded env28572 := by
  intro p hp
  have h : env28572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28571_28572 : H12AffineEnvironment.transform 4 1 env28571 = env28572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28571 == env28572) = true)

theorem identity28572 : scanCanonicalize (H12AffineFastState.compose env28572 (packedSelected [3,5,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28572 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env28573 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,2064,269,2049,0,262,2065,2309,272,1,2048,0,16,3,268,16,2048,2065,2064,2308,21,1,256,0,2049,513]

theorem envBound28573 : H12AffineFastState.Bounded env28573 := by
  intro p hp
  have h : env28573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28572_28573 : H12AffineEnvironment.transform 5 17 env28572 = env28573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28572 == env28573) = true)

theorem identity28573 : scanCanonicalize (H12AffineFastState.compose env28573 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound28573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28574 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,276,269,261,0,262,277,1,272,1,260,0,16,3,268,16,260,277,276,0,21,1,256,0,261,513]

theorem envBound28574 : H12AffineFastState.Bounded env28574 := by
  intro p hp
  have h : env28574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28573_28574 : H12AffineEnvironment.transform 10 260 env28573 = env28574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env28573 == env28574) = true)

def env28575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,98780,8328,65,4237693,458144,17664,10400,453997,4594925,256,21792,46213,510650]

theorem envBound28575 : H12AffineFastState.Bounded env28575 := by
  intro p hp
  have h : env28575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28535_28575 : H12AffineEnvironment.transform 22 452769 env28535 = env28575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env28535 == env28575) = true)

def env28576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,98780,8328,65,295421,458144,17664,10400,453997,144493,256,21792,46213,510650]

theorem envBound28576 : H12AffineFastState.Bounded env28576 := by
  intro p hp
  have h : env28576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28575_28576 : H12AffineEnvironment.transform 21 272512 env28575 = env28576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28575 == env28576) = true)

theorem identity28576 : scanCanonicalize (H12AffineFastState.compose env28576 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound28576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456945,272512,452769,21762,8328,65,295421,458144,17664,10400,453997,144493,256,21792,46213,400996]

theorem envBound28577 : H12AffineFastState.Bounded env28577 := by
  intro p hp
  have h : env28577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28576_28577 : H12AffineEnvironment.transform 15 54494 env28576 = env28577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env28576 == env28577) = true)

def env28578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456825,272392,452649,21762,8192,65,295285,458024,17664,10280,453997,144493,256,21792,46093,400996]

theorem envBound28578 : H12AffineFastState.Bounded env28578 := by
  intro p hp
  have h : env28578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28577_28578 : H12AffineEnvironment.transform 6 8 env28577 = env28578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28577 == env28578) = true)

theorem identity28578 : scanCanonicalize (H12AffineFastState.compose env28578 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 37988) := by decide +kernel

theorem selectedBound28578 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env28579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,37988,262144,1024,32769,289821,272392,293965,21762,8192,65,295285,289100,17664,10280,293129,40969,256,21792,46093,297472]

theorem envBound28579 : H12AffineFastState.Bounded env28579 := by
  intro p hp
  have h : env28579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28578_28579 : H12AffineEnvironment.transform 16 37988 env28578 = env28579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37988 env28578 == env28579) = true)

theorem identity28579 : scanCanonicalize (H12AffineFastState.compose env28579 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64605) := by decide +kernel

theorem selectedBound28579 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env28580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,37988,64605,1024,32769,36928,54357,32784,21762,8192,65,32040,38161,17664,10280,34132,40969,256,21792,46093,30301]

theorem envBound28580 : H12AffineFastState.Bounded env28580 := by
  intro p hp
  have h : env28580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28579_28580 : H12AffineEnvironment.transform 17 64605 env28579 = env28580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64605 env28579 == env28580) = true)

theorem identity28580 : scanCanonicalize (H12AffineFastState.compose env28580 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound28580 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,16741,10588,1024,21760,17729,340,21777,21762,8192,65,32040,16400,17664,10280,20565,29960,256,21792,24844,30301]

theorem envBound28581 : H12AffineFastState.Bounded env28581 := by
  intro p hp
  have h : env28581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28580_28581 : H12AffineEnvironment.transform 14 21761 env28580 = env28581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env28580 == env28581) = true)

theorem identity28581 : scanCanonicalize (H12AffineFastState.compose env28581 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28581 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,21761,343,16741,2421,1024,21760,17729,340,21777,21762,41,65,23809,16400,17664,2049,20565,21793,256,21792,16677,22132]

theorem envBound28582 : H12AffineFastState.Bounded env28582 := by
  intro p hp
  have h : env28582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28581_28582 : H12AffineEnvironment.transform 12 41 env28581 = env28582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28581 == env28582) = true)

theorem identity28582 : scanCanonicalize (H12AffineFastState.compose env28582 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound28582 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env28583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,41,16384,18804,343,16741,2421,1024,18805,17729,340,18788,18807,41,65,16756,16400,17664,2049,19488,18772,256,18773,16677,18945]

theorem envBound28583 : H12AffineFastState.Bounded env28583 := by
  intro p hp
  have h : env28583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28582_28583 : H12AffineEnvironment.transform 11 3189 env28582 = env28583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env28582 == env28583) = true)

theorem identity28583 : scanCanonicalize (H12AffineFastState.compose env28583 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound28583 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,41,2128,292,343,2357,2421,1024,293,3345,340,308,295,41,65,2340,2112,3408,2049,1136,260,256,261,2421,593]

theorem envBound28584 : H12AffineFastState.Bounded env28584 := by
  intro p hp
  have h : env28584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28583_28584 : H12AffineEnvironment.transform 13 2128 env28583 = env28584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env28583 == env28584) = true)

theorem identity28584 : scanCanonicalize (H12AffineFastState.compose env28584 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28584 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env28585 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,41,2049,292,262,2357,2340,1024,293,3345,261,308,295,41,16,2340,2065,3329,2049,1057,260,256,261,2340,512]

theorem envBound28585 : H12AffineFastState.Bounded env28585 := by
  intro p hp
  have h : env28585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28584_28585 : H12AffineEnvironment.transform 5 17 env28584 = env28585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28584 == env28585) = true)

theorem identity28585 : scanCanonicalize (H12AffineFastState.compose env28585 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound28585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28586 : List Nat := [2,4,8,16,32,17,8,15,512,1024,2048,3108,41,2049,43,9,2106,2091,1024,42,3102,10,59,40,41,16,2091,2065,3086,2049,1057,11,15,10,2091,512]

theorem envBound28586 : H12AffineFastState.Bounded env28586 := by
  intro p hp
  have h : env28586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28585_28586 : H12AffineEnvironment.transform 7 15 env28585 = env28586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env28585 == env28586) = true)

theorem identity28586 : scanCanonicalize (H12AffineFastState.compose env28586 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28586 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28587 : List Nat := [2,4,8,16,0,17,8,15,512,1024,2048,3076,9,2049,11,9,2074,2059,1024,10,3102,10,27,8,9,16,2059,2065,3086,2049,1025,11,15,10,2059,512]

theorem envBound28587 : H12AffineFastState.Bounded env28587 := by
  intro p hp
  have h : env28587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28586_28587 : H12AffineEnvironment.transform 4 0 env28586 = env28587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28586 == env28587) = true)

def env28588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456824,272393,452648,21762,8193,65,295284,458025,17664,10281,453997,144493,256,21792,46092,400996]

theorem envBound28588 : H12AffineFastState.Bounded env28588 := by
  intro p hp
  have h : env28588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28577_28588 : H12AffineEnvironment.transform 6 9 env28577 = env28588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28577 == env28588) = true)

theorem identity28588 : scanCanonicalize (H12AffineFastState.compose env28588 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound28588 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env28589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1024,32769,165201,21792,169217,21762,8193,65,64605,163840,17664,10281,168004,144493,256,21792,46092,156493]

theorem envBound28589 : H12AffineFastState.Bounded env28589 := by
  intro p hp
  have h : env28589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28588_28589 : H12AffineEnvironment.transform 17 32041 env28588 = env28589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env28588 == env28589) = true)

theorem identity28589 : scanCanonicalize (H12AffineFastState.compose env28589 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound28589 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env28590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,131072,32041,1024,8461,140381,21792,144397,21762,8193,65,23889,139532,17664,10281,143688,144493,256,21792,5376,156493]

theorem envBound28590 : H12AffineFastState.Bounded env28590 := by
  intro p hp
  have h : env28590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28589_28590 : H12AffineEnvironment.transform 14 8460 env28589 = env28590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env28589 == env28590) = true)

theorem identity28590 : scanCanonicalize (H12AffineFastState.compose env28590 (packedSelected [16,17,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound28590 : packedSelected [16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env28591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,24861,32041,1024,8461,17728,21792,21776,21762,8193,65,23889,16401,17664,10281,20565,21872,256,21792,5376,592]

theorem envBound28591 : H12AffineFastState.Bounded env28591 := by
  intro p hp
  have h : env28591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28590_28591 : H12AffineEnvironment.transform 16 24861 env28590 = env28591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env28590 == env28591) = true)

theorem identity28591 : scanCanonicalize (H12AffineFastState.compose env28591 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28592 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29962,24861,32041,1024,8461,17681,21792,21776,21762,8193,16,23808,16401,17664,10281,20484,21793,256,21792,5376,513]

theorem envBound28592 : H12AffineFastState.Bounded env28592 := by
  intro p hp
  have h : env28592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28591_28592 : H12AffineEnvironment.transform 5 17 env28591 = env28592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28591 == env28592) = true)

theorem identity28592 : scanCanonicalize (H12AffineFastState.compose env28592 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28592 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28593 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,21511,16400,23588,1024,0,17681,21792,21776,21762,268,16,23808,16401,17664,2340,20484,21793,256,21792,5376,513]

theorem envBound28593 : H12AffineFastState.Bounded env28593 := by
  intro p hp
  have h : env28593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28592_28593 : H12AffineEnvironment.transform 12 269 env28592 = env28593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28592 == env28593) = true)

def env28594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,98780,8328,65,295420,458144,17664,10400,453997,144492,256,21792,46213,510650]

theorem envBound28594 : H12AffineFastState.Bounded env28594 := by
  intro p hp
  have h : env28594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28575_28594 : H12AffineEnvironment.transform 21 272513 env28575 = env28594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28575 == env28594) = true)

theorem identity28594 : scanCanonicalize (H12AffineFastState.compose env28594 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound28594 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115870,201966,120014,98780,8328,65,245139,115151,17664,10400,119042,144492,256,21792,46213,63189]

theorem envBound28595 : H12AffineFastState.Bounded env28595 := by
  intro p hp
  have h : env28595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28594_28595 : H12AffineEnvironment.transform 17 212079 env28594 = env28595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env28594 == env28595) = true)

def env28596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115870,120062,120014,98780,8328,65,97667,115151,17664,10400,119042,62588,256,21792,46213,63189]

theorem envBound28596 : H12AffineFastState.Bounded env28596 := by
  intro p hp
  have h : env28596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28595_28596 : H12AffineEnvironment.transform 16 49168 env28595 = env28596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env28595 == env28596) = true)

theorem identity28596 : scanCanonicalize (H12AffineFastState.compose env28596 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28596 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env28597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49168,32041,1024,32769,17864,21928,21912,138,8328,65,64725,16537,17664,10400,20564,62588,256,21792,46213,63189]

theorem envBound28597 : H12AffineFastState.Bounded env28597 := by
  intro p hp
  have h : env28597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28596_28597 : H12AffineEnvironment.transform 15 33110 env28596 = env28597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28596 == env28597) = true)

theorem identity28597 : scanCanonicalize (H12AffineFastState.compose env28597 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28597 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env28598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,33110,49168,23668,1024,32769,17864,21928,21912,138,469,65,56712,16537,17664,2557,20564,54561,256,21792,38360,55176]

theorem envBound28598 : H12AffineFastState.Bounded env28598 := by
  intro p hp
  have h : env28598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28597_28598 : H12AffineEnvironment.transform 12 349 env28597 = env28598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28597 == env28598) = true)

theorem identity28598 : scanCanonicalize (H12AffineFastState.compose env28598 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28598 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,32768,33110,38297,2557,1024,32769,4161,33,17,138,469,65,34817,5392,4233,2557,1501,32936,256,169,38360,33281]

theorem envBound28599 : H12AffineFastState.Bounded env28599 := by
  intro p hp
  have h : env28599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28598_28599 : H12AffineEnvironment.transform 13 5513 env28598 = env28599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28598 == env28599) = true)

theorem identity28599 : scanCanonicalize (H12AffineFastState.compose env28599 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28599 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env28600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,342,5529,2557,1024,1,4161,33,17,138,469,65,2049,5392,4233,2557,1501,168,256,169,5592,513]

theorem envBound28600 : H12AffineFastState.Bounded env28600 := by
  intro p hp
  have h : env28600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28599_28600 : H12AffineEnvironment.transform 14 0 env28599 = env28600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28599 == env28600) = true)

theorem identity28600 : scanCanonicalize (H12AffineFastState.compose env28600 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28600 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28601 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,0,342,5441,2341,1024,1,4161,33,17,82,269,65,2049,5392,4177,2341,1285,112,256,113,5376,513]

theorem envBound28601 : H12AffineFastState.Bounded env28601 := by
  intro p hp
  have h : env28601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28600_28601 : H12AffineEnvironment.transform 6 88 env28600 = env28601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28600 == env28601) = true)

theorem identity28601 : scanCanonicalize (H12AffineFastState.compose env28601 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1604) := by decide +kernel

theorem selectedBound28601 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28602 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1604,349,789,0,342,773,2341,1024,1,1541,33,17,82,269,65,2049,852,1557,2341,1285,112,256,113,836,513]

theorem envBound28602 : H12AffineFastState.Bounded env28602 := by
  intro p hp
  have h : env28602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28601_28602 : H12AffineEnvironment.transform 11 1604 env28601 = env28602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1604 env28601 == env28602) = true)

theorem identity28602 : scanCanonicalize (H12AffineFastState.compose env28602 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound28602 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28603 : List Nat := [2,4,8,16,32,64,88,256,512,1024,772,1604,349,789,0,342,773,545,1024,1,1541,33,17,82,269,65,773,852,1557,545,1285,112,256,113,836,513]

theorem envBound28603 : H12AffineFastState.Bounded env28603 := by
  intro p hp
  have h : env28603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28602_28603 : H12AffineEnvironment.transform 10 772 env28602 = env28603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env28602 == env28603) = true)

theorem identity28603 : scanCanonicalize (H12AffineFastState.compose env28603 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound28603 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28604 : List Nat := [2,4,8,16,32,64,88,256,512,368,772,820,349,789,0,342,773,545,368,1,885,33,17,82,269,65,773,852,869,545,117,112,256,113,836,513]

theorem envBound28604 : H12AffineFastState.Bounded env28604 := by
  intro p hp
  have h : env28604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28603_28604 : H12AffineEnvironment.transform 9 368 env28603 = env28604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env28603 == env28604) = true)

theorem identity28604 : scanCanonicalize (H12AffineFastState.compose env28604 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound28604 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env28605 : List Nat := [2,4,8,16,32,64,88,52,512,68,560,512,105,545,0,98,561,545,68,1,577,33,17,82,57,65,561,608,593,545,117,112,52,113,624,513]

theorem envBound28605 : H12AffineFastState.Bounded env28605 := by
  intro p hp
  have h : env28605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28604_28605 : H12AffineEnvironment.transform 7 52 env28604 = env28605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env28604 == env28605) = true)

theorem identity28605 : scanCanonicalize (H12AffineFastState.compose env28605 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28605 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env28606 : List Nat := [2,4,8,16,32,48,40,52,512,52,560,512,25,545,0,18,561,545,52,1,561,33,17,34,57,49,561,528,545,545,5,0,52,1,512,513]

theorem envBound28606 : H12AffineFastState.Bounded env28606 := by
  intro p hp
  have h : env28606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28605_28606 : H12AffineEnvironment.transform 5 48 env28605 = env28606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28605 == env28606) = true)

theorem identity28606 : scanCanonicalize (H12AffineFastState.compose env28606 (packedSelected [15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28606 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env28607 : List Nat := [2,4,8,16,0,16,8,20,512,20,528,512,25,513,0,18,529,513,20,1,529,1,17,2,25,17,529,528,513,513,5,0,20,1,512,513]

theorem envBound28607 : H12AffineFastState.Bounded env28607 := by
  intro p hp
  have h : env28607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28606_28607 : H12AffineEnvironment.transform 4 0 env28606 = env28607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28606 == env28607) = true)

theorem identity28607 : scanCanonicalize (H12AffineFastState.compose env28607 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28607 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28608 : List Nat := [2,4,8,1,0,1,8,5,512,5,513,512,8,513,0,3,512,513,5,1,512,1,0,2,8,0,512,513,513,513,5,0,5,1,512,513]

theorem envBound28608 : H12AffineFastState.Bounded env28608 := by
  intro p hp
  have h : env28608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28607_28608 : H12AffineEnvironment.transform 3 1 env28607 = env28608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28607 == env28608) = true)

theorem identity28608 : scanCanonicalize (H12AffineFastState.compose env28608 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28609 : List Nat := [2,4,8,1,0,1,8,5,0,5,1,0,8,1,0,3,0,1,5,1,0,1,0,2,8,0,0,1,1,1,5,0,5,1,0,1]

theorem envBound28609 : H12AffineFastState.Bounded env28609 := by
  intro p hp
  have h : env28609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28608_28609 : H12AffineEnvironment.transform 8 0 env28608 = env28609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28608 == env28609) = true)

theorem identity28609 : scanCanonicalize (H12AffineFastState.compose env28609 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28610 : List Nat := [2,4,3,1,0,1,3,5,0,5,1,0,3,1,0,3,0,1,5,1,0,1,0,2,3,0,0,1,1,1,5,0,5,1,0,1]

theorem envBound28610 : H12AffineFastState.Bounded env28610 := by
  intro p hp
  have h : env28610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28609_28610 : H12AffineEnvironment.transform 2 3 env28609 = env28610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28609 == env28610) = true)

def env28611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115870,120063,120014,98780,8328,65,97666,115151,17664,10400,119042,62589,256,21792,46213,63189]

theorem envBound28611 : H12AffineFastState.Bounded env28611 := by
  intro p hp
  have h : env28611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28595_28611 : H12AffineEnvironment.transform 16 49169 env28595 = env28611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env28595 == env28611) = true)

theorem identity28611 : scanCanonicalize (H12AffineFastState.compose env28611 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28611 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env28612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,65536,49169,122227,1024,32769,115870,120063,120014,98780,389,65,89231,115151,17664,2477,119042,54640,256,21792,38280,55256]

theorem envBound28612 : H12AffineFastState.Bounded env28612 := by
  intro p hp
  have h : env28612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28611_28612 : H12AffineEnvironment.transform 12 269 env28611 = env28612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28611 == env28612) = true)

theorem identity28612 : scanCanonicalize (H12AffineFastState.compose env28612 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28612 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env28613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,33110,49169,23589,1024,32769,17864,21929,21912,138,389,65,56793,16537,17664,2477,20564,54640,256,21792,38280,55256]

theorem envBound28613 : H12AffineFastState.Bounded env28613 := by
  intro p hp
  have h : env28613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28612_28613 : H12AffineEnvironment.transform 15 33110 env28612 = env28613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28612 == env28613) = true)

theorem identity28613 : scanCanonicalize (H12AffineFastState.compose env28613 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28613 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env28614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33110,49169,23589,1024,32769,17728,21793,21776,2,269,65,56657,16401,17664,2341,20564,54640,256,21792,38144,55120]

theorem envBound28614 : H12AffineFastState.Bounded env28614 := by
  intro p hp
  have h : env28614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28613_28614 : H12AffineEnvironment.transform 6 8 env28613 = env28614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28613 == env28614) = true)

theorem identity28614 : scanCanonicalize (H12AffineFastState.compose env28614 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28614 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,33110,38160,2340,1024,32769,4161,32,17,2,269,65,34896,5392,4097,2341,1365,32881,256,33,38144,33361]

theorem envBound28615 : H12AffineFastState.Bounded env28615 := by
  intro p hp
  have h : env28615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28614_28615 : H12AffineEnvironment.transform 13 5377 env28614 = env28615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28614 == env28615) = true)

theorem identity28615 : scanCanonicalize (H12AffineFastState.compose env28615 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound28615 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,113,295,5473,2340,1024,112,4161,32,17,2,269,65,2081,5392,4097,2341,1365,0,256,33,5489,544]

theorem envBound28616 : H12AffineFastState.Bounded env28616 := by
  intro p hp
  have h : env28616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28615_28616 : H12AffineEnvironment.transform 14 113 env28615 = env28616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env28615 == env28616) = true)

theorem identity28616 : scanCanonicalize (H12AffineFastState.compose env28616 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28616 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env28617 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,269,5377,1,295,5393,2340,1024,0,4145,32,17,2,269,49,2081,5392,4097,2341,1317,0,256,33,5377,544]

theorem envBound28617 : H12AffineFastState.Bounded env28617 := by
  intro p hp
  have h : env28617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28616_28617 : H12AffineEnvironment.transform 5 48 env28616 = env28617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28616 == env28617) = true)

theorem identity28617 : scanCanonicalize (H12AffineFastState.compose env28617 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28617 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28618 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,1,263,5393,2308,1024,0,4113,0,17,2,269,17,2049,5392,4097,2309,1285,0,256,1,5377,512]

theorem envBound28618 : H12AffineFastState.Bounded env28618 := by
  intro p hp
  have h : env28618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28617_28618 : H12AffineEnvironment.transform 4 0 env28617 = env28618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28617 == env28618) = true)

theorem identity28618 : scanCanonicalize (H12AffineFastState.compose env28618 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28618 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28619 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,1,2,5140,2049,1024,0,4113,0,17,2,8,17,2049,5141,4097,2048,1024,0,5,1,5124,512]

theorem envBound28619 : H12AffineFastState.Bounded env28619 := by
  intro p hp
  have h : env28619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28618_28619 : H12AffineEnvironment.transform 7 5 env28618 = env28619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28618 == env28619) = true)

def env28620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound28620 : H12AffineFastState.Bounded env28620 := by
  intro p hp
  have h : env28620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28460_28620 : H12AffineEnvironment.transform 18 1025 env28460 = env28620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28460 == env28620) = true)

theorem identity28620 : scanCanonicalize (H12AffineFastState.compose env28620 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound28620 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575676,18973836,10507600,8538621,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound28621 : H12AffineFastState.Bounded env28621 := by
  intro p hp
  have h : env28621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28620_28621 : H12AffineEnvironment.transform 17 35325 env28620 = env28621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env28620 == env28621) = true)

def env28622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575540,18973700,10507600,8538485,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound28622 : H12AffineFastState.Bounded env28622 := by
  intro p hp
  have h : env28622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28621_28622 : H12AffineEnvironment.transform 6 8 env28621 = env28622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28621 == env28622) = true)

def env28623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,16777216,8192,65,21039476,18973700,2233680,2421,17024016,23160136,257,19104805,19096841,16966478]

theorem envBound28623 : H12AffineFastState.Bounded env28623 := by
  intro p hp
  have h : env28623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28622_28623 : H12AffineEnvironment.transform 22 147456 env28622 = env28623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env28622 == env28623) = true)

def env28624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973700,2118976,2421,16876544,23160136,257,18990133,18949401,16819038]

theorem envBound28624 : H12AffineFastState.Bounded env28624 := by
  intro p hp
  have h : env28624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28623_28624 : H12AffineEnvironment.transform 16 16400 env28623 = env28624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28623 == env28624) = true)

theorem identity28624 : scanCanonicalize (H12AffineFastState.compose env28624 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound28624 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,3,8192,65,4262263,2196487,2118976,2421,99331,6382923,257,2212918,2172186,41821]

theorem envBound28625 : H12AffineFastState.Bounded env28625 := by
  intro p hp
  have h : env28625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28624_28625 : H12AffineEnvironment.transform 23 3 env28624 = env28625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env28624 == env28625) = true)

def env28626 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35109,1025,32769,2097152,4194304,16,3,8192,17,4262183,2196487,2118928,2341,99331,6382875,257,2212918,2172186,41741]

theorem envBound28626 : H12AffineFastState.Bounded env28626 := by
  intro p hp
  have h : env28626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28625_28626 : H12AffineEnvironment.transform 5 16 env28625 = env28626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28625 == env28626) = true)

theorem identity28626 : scanCanonicalize (H12AffineFastState.compose env28626 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound28626 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28627 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16400,35109,1025,32769,2097152,4194304,16,3,8192,17,4229153,2098433,2118928,2341,1285,6349853,257,2114864,2139164,41741]

theorem envBound28627 : H12AffineFastState.Bounded env28627 := by
  intro p hp
  have h : env28627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28626_28627 : H12AffineEnvironment.transform 15 33030 env28626 = env28627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env28626 == env28627) = true)

theorem identity28627 : scanCanonicalize (H12AffineFastState.compose env28627 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound28627 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env28628 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,16400,35109,1025,32769,50449,4194304,16,3,8192,17,4229153,49168,36865,2341,1285,4202764,257,32801,24845,41741]

theorem envBound28628 : H12AffineFastState.Bounded env28628 := by
  intro p hp
  have h : env28628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28627_28628 : H12AffineEnvironment.transform 20 50449 env28627 = env28628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env28627 == env28628) = true)

def env28629 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35108,1025,32769,2097152,4194304,16,3,8192,16,4262182,2196487,2118929,2340,99331,6382874,257,2212918,2172186,41740]

theorem envBound28629 : H12AffineFastState.Bounded env28629 := by
  intro p hp
  have h : env28629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28625_28629 : H12AffineEnvironment.transform 5 17 env28625 = env28629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28625 == env28629) = true)

theorem identity28629 : scanCanonicalize (H12AffineFastState.compose env28629 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound28629 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28630 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35108,1025,32769,2097152,73770,16,3,8192,16,10508,2196487,2118929,2340,99331,2114864,257,2212918,2172186,41740]

theorem envBound28630 : H12AffineFastState.Bounded env28630 := by
  intro p hp
  have h : env28630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28629_28630 : H12AffineEnvironment.transform 21 73770 env28629 = env28630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env28629 == env28630) = true)

theorem identity28630 : scanCanonicalize (H12AffineFastState.compose env28630 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28630 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env28631 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16400,35108,1025,32769,2097152,65830,16,3,268,16,2048,2196487,2118929,2340,99331,2114864,257,2212918,2163734,33280]

theorem envBound28631 : H12AffineFastState.Bounded env28631 := by
  intro p hp
  have h : env28631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28630_28631 : H12AffineEnvironment.transform 12 268 env28630 = env28631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28630 == env28631) = true)

theorem identity28631 : scanCanonicalize (H12AffineFastState.compose env28631 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82966) := by decide +kernel

theorem selectedBound28631 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28632 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16400,35108,1025,32769,82966,65830,16,3,268,16,2048,49169,69895,2340,99331,65830,257,32800,16384,33280]

theorem envBound28632 : H12AffineFastState.Bounded env28632 := by
  intro p hp
  have h : env28632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28631_28632 : H12AffineEnvironment.transform 20 82966 env28631 = env28632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82966 env28631 == env28632) = true)

theorem identity28632 : scanCanonicalize (H12AffineFastState.compose env28632 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound28632 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28633 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,33030,16400,35108,1025,32769,50448,32800,16,3,268,16,2048,49169,36865,2340,1285,32800,257,32800,16384,33280]

theorem envBound28633 : H12AffineFastState.Bounded env28633 := by
  intro p hp
  have h : env28633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28632_28633 : H12AffineEnvironment.transform 15 33030 env28632 = env28633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env28632 == env28633) = true)

theorem identity28633 : scanCanonicalize (H12AffineFastState.compose env28633 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3621) := by decide +kernel

theorem selectedBound28633 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28634 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,3621,32768,33030,3637,35108,1025,32769,35637,32800,16,3,268,16,2048,36404,36865,2340,1285,32800,257,32800,3621,33280]

theorem envBound28634 : H12AffineFastState.Bounded env28634 := by
  intro p hp
  have h : env28634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28633_28634 : H12AffineEnvironment.transform 13 3621 env28633 = env28634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3621 env28633 == env28634) = true)

theorem identity28634 : scanCanonicalize (H12AffineFastState.compose env28634 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound28634 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env28635 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,268,3621,32768,33030,3637,35108,1025,32769,35637,32800,16,3,268,16,2048,36404,35876,2340,1285,32800,257,32800,3621,33280]

theorem envBound28635 : H12AffineFastState.Bounded env28635 := by
  intro p hp
  have h : env28635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28634_28635 : H12AffineEnvironment.transform 11 3109 env28634 = env28635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env28634 == env28635) = true)

theorem identity28635 : scanCanonicalize (H12AffineFastState.compose env28635 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound28635 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env28636 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,3109,56,3621,32768,32818,3637,34832,1025,32769,35329,32800,16,3,56,16,2048,36404,35876,2064,1073,32800,53,32800,3621,33280]

theorem envBound28636 : H12AffineFastState.Bounded env28636 := by
  intro p hp
  have h : env28636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28635_28636 : H12AffineEnvironment.transform 7 52 env28635 = env28636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env28635 == env28636) = true)

theorem identity28636 : scanCanonicalize (H12AffineFastState.compose env28636 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28636 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28637 : List Nat := [2,4,8,16,32,17,8,52,1,1024,2048,3109,56,3108,32768,32818,3124,34832,1025,32769,34816,32800,16,3,56,16,2048,35893,35876,2064,1073,32800,53,32800,3108,32769]

theorem envBound28637 : H12AffineFastState.Bounded env28637 := by
  intro p hp
  have h : env28637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28636_28637 : H12AffineEnvironment.transform 8 1 env28636 = env28637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28636 == env28637) = true)

theorem identity28637 : scanCanonicalize (H12AffineFastState.compose env28637 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound28637 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28638 : List Nat := [2,4,8,16,32,17,8,52,1,1024,1077,16,56,17,32768,32818,1,33829,1025,32769,33845,32800,16,3,56,16,1077,32768,32785,1061,1073,32800,53,32800,17,32769]

theorem envBound28638 : H12AffineFastState.Bounded env28638 := by
  intro p hp
  have h : env28638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28637_28638 : H12AffineEnvironment.transform 10 1077 env28637 = env28638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env28637 == env28638) = true)

theorem identity28638 : scanCanonicalize (H12AffineFastState.compose env28638 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28638 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28639 : List Nat := [2,4,8,16,32,17,8,52,1,53,0,16,56,17,32768,32818,1,32784,52,32769,32768,32800,16,3,56,16,0,32768,32785,16,4,32800,53,32800,17,32769]

theorem envBound28639 : H12AffineFastState.Bounded env28639 := by
  intro p hp
  have h : env28639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28638_28639 : H12AffineEnvironment.transform 9 53 env28638 = env28639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28638 == env28639) = true)

theorem identity28639 : scanCanonicalize (H12AffineFastState.compose env28639 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28639 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28640 : List Nat := [2,4,8,1,32,0,8,37,1,36,0,1,41,0,32768,32803,1,32769,37,32769,32768,32800,1,3,41,1,0,32768,32768,1,4,32800,36,32800,0,32769]

theorem envBound28640 : H12AffineFastState.Bounded env28640 := by
  intro p hp
  have h : env28640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28639_28640 : H12AffineEnvironment.transform 3 1 env28639 = env28640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28639 == env28640) = true)

theorem identity28640 : scanCanonicalize (H12AffineFastState.compose env28640 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28641 : List Nat := [2,4,8,1,32,0,8,37,1,36,0,1,41,0,1,34,1,0,37,0,1,33,1,3,41,1,0,1,1,1,4,33,36,33,0,0]

theorem envBound28641 : H12AffineFastState.Bounded env28641 := by
  intro p hp
  have h : env28641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28640_28641 : H12AffineEnvironment.transform 14 1 env28640 = env28641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28640 == env28641) = true)

theorem identity28641 : scanCanonicalize (H12AffineFastState.compose env28641 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28642 : List Nat := [2,4,8,1,10,0,8,15,1,14,0,1,3,0,1,8,1,0,15,0,1,11,1,3,3,1,0,1,1,1,4,11,14,11,0,0]

theorem envBound28642 : H12AffineFastState.Bounded env28642 := by
  intro p hp
  have h : env28642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28641_28642 : H12AffineEnvironment.transform 4 10 env28641 = env28642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28641 == env28642) = true)

def env28643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,16777216,8192,65,21039476,18973700,2118977,2421,16876545,23160136,257,18990132,18949400,16819039]

theorem envBound28643 : H12AffineFastState.Bounded env28643 := by
  intro p hp
  have h : env28643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28623_28643 : H12AffineEnvironment.transform 16 16401 env28623 = env28643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28623 == env28643) = true)

theorem identity28643 : scanCanonicalize (H12AffineFastState.compose env28643 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound28643 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41310,8192,65,4302890,2172250,2118977,2421,75103,6407190,257,2188650,2196550,513]

theorem envBound28644 : H12AffineFastState.Bounded env28644 := by
  intro p hp
  have h : env28644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28643_28644 : H12AffineEnvironment.transform 23 41310 env28643 = env28644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env28643 == env28644) = true)

theorem identity28644 : scanCanonicalize (H12AffineFastState.compose env28644 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound28644 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env28645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115734,4194304,17,41310,8192,65,4302890,57676,102743,2421,75103,4194304,257,41340,16464,513]

theorem envBound28645 : H12AffineFastState.Bounded env28645 := by
  intro p hp
  have h : env28645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28644_28645 : H12AffineEnvironment.transform 20 115734 env28644 = env28645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env28644 == env28645) = true)

theorem identity28645 : scanCanonicalize (H12AffineFastState.compose env28645 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28645 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env28646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,91466,4194304,17,2,8192,65,4262262,16400,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound28646 : H12AffineFastState.Bounded env28646 := by
  intro p hp
  have h : env28646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28645_28646 : H12AffineEnvironment.transform 14 8540 env28645 = env28646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28645 == env28646) = true)

theorem identity28646 : scanCanonicalize (H12AffineFastState.compose env28646 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound28646 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,91466,8572,17,2,8192,65,75786,16400,77835,2421,75103,8572,257,32,16464,513]

theorem envBound28647 : H12AffineFastState.Bounded env28647 := by
  intro p hp
  have h : env28647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28646_28647 : H12AffineEnvironment.transform 21 8572 env28646 = env28647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env28646 == env28647) = true)

def env28648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,16777216,8192,65,21039477,18973700,2233681,2420,17024017,23160136,257,19104804,19096840,16966479]

theorem envBound28648 : H12AffineFastState.Bounded env28648 := by
  intro p hp
  have h : env28648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28622_28648 : H12AffineEnvironment.transform 22 147457 env28622 = env28648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env28622 == env28648) = true)

theorem identity28648 : scanCanonicalize (H12AffineFastState.compose env28648 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound28648 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env28649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,188750,8192,65,4450363,2319690,2233681,2420,75103,6521862,257,2188650,2196550,513]

theorem envBound28649 : H12AffineFastState.Bounded env28649 := by
  intro p hp
  have h : env28649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28648_28649 : H12AffineEnvironment.transform 23 188750 env28648 = env28649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env28648 == env28649) = true)

def env28650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41310,8192,65,4302891,2172250,2118977,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound28650 : H12AffineFastState.Bounded env28650 := by
  intro p hp
  have h : env28650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28649_28650 : H12AffineEnvironment.transform 16 16400 env28649 = env28650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28649 == env28650) = true)

theorem identity28650 : scanCanonicalize (H12AffineFastState.compose env28650 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound28650 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env28651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115734,4194304,17,41310,8192,65,4302891,57676,102743,2420,75103,4194304,257,41340,16464,513]

theorem envBound28651 : H12AffineFastState.Bounded env28651 := by
  intro p hp
  have h : env28651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28650_28651 : H12AffineEnvironment.transform 20 115734 env28650 = env28651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env28650 == env28651) = true)

def env28652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91198,4194304,17,374,8192,65,4261891,16740,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound28652 : H12AffineFastState.Bounded env28652 := by
  intro p hp
  have h : env28652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28651_28652 : H12AffineEnvironment.transform 14 8232 env28651 = env28652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env28651 == env28652) = true)

theorem identity28652 : scanCanonicalize (H12AffineFastState.compose env28652 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

end H12CloudChart0