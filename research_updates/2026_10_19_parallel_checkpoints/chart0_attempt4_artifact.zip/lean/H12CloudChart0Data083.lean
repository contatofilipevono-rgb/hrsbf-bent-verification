import H12CloudChart0Data082

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound20957 : H12AffineFastState.Bounded env20957 := by
  intro p hp
  have h : env20957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20956_20957 : H12AffineEnvironment.transform 15 8202 env20956 = env20957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20956 == env20957) = true)

theorem identity20957 : scanCanonicalize (H12AffineFastState.compose env20957 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound20957 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env20958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,300,16384,248,294,5608,2308,1025,249,17728,169,21777,2,420,64,2185,16400,17665,2308,20700,33,257,21792,5457,22273]

theorem envBound20958 : H12AffineFastState.Bounded env20958 := by
  intro p hp
  have h : env20958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20957_20958 : H12AffineEnvironment.transform 12 300 env20957 = env20958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env20957 == env20958) = true)

theorem identity20958 : scanCanonicalize (H12AffineFastState.compose env20958 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5544) := by decide +kernel

theorem selectedBound20958 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,300,5544,248,294,5608,2308,1025,249,4328,169,185,2,420,64,2185,5560,4265,2308,1396,33,257,136,5457,681]

theorem envBound20959 : H12AffineFastState.Bounded env20959 := by
  intro p hp
  have h : env20959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20958_20959 : H12AffineEnvironment.transform 13 5544 env20958 = env20959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5544 env20958 == env20959) = true)

theorem identity20959 : scanCanonicalize (H12AffineFastState.compose env20959 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20959 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env20960 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,300,5376,80,294,5440,2308,1025,81,4160,1,17,2,268,64,2081,5392,4097,2308,1396,33,257,32,5457,513]

theorem envBound20960 : H12AffineFastState.Bounded env20960 := by
  intro p hp
  have h : env20960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20959_20960 : H12AffineEnvironment.transform 6 40 env20959 = env20960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20959 == env20960) = true)

theorem identity20960 : scanCanonicalize (H12AffineFastState.compose env20960 (packedSelected [1,2,3,4,5,7,8,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound20960 : packedSelected [1,2,3,4,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env20961 : List Nat := [2,4,8,16,32,64,40,256,512,613,2048,4096,300,4965,80,294,4901,2308,612,81,4160,1,17,2,268,64,2081,4981,4097,2308,785,33,257,32,4916,513]

theorem envBound20961 : H12AffineFastState.Bounded env20961 := by
  intro p hp
  have h : env20961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20960_20961 : H12AffineEnvironment.transform 9 613 env20960 = env20961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env20960 == env20961) = true)

def env20962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,58516,168,62661,98780,8328,64,2185,57796,17665,35325,61704,32,257,21792,46213,120543]

theorem envBound20962 : H12AffineFastState.Bounded env20962 := by
  intro p hp
  have h : env20962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20954_20962 : H12AffineEnvironment.transform 17 10281 env20954 = env20962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20954 == env20962) = true)

theorem identity20962 : scanCanonicalize (H12AffineFastState.compose env20962 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound20962 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env20963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,65536,38160,10281,1025,32769,45160,168,41017,98780,8328,64,2185,46392,4605,35325,42484,32,257,476,46213,98851]

theorem envBound20963 : H12AffineFastState.Bounded env20963 := by
  intro p hp
  have h : env20963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20962_20963 : H12AffineEnvironment.transform 13 5372 env20962 = env20963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env20962 == env20963) = true)

theorem identity20963 : scanCanonicalize (H12AffineFastState.compose env20963 (packedSelected [2,4,6,7,8,10,11,12,14,15,16,17,18,19,20,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound20963 : packedSelected [2,4,6,7,8,10,11,12,14,15,16,17,18,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env20964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8313,65536,13673,10281,1025,8312,4113,168,64,74149,8328,64,2185,5441,4605,10628,1421,32,257,476,5372,74330]

theorem envBound20964 : H12AffineFastState.Bounded env20964 := by
  intro p hp
  have h : env20964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20963_20964 : H12AffineEnvironment.transform 14 8313 env20963 = env20964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env20963 == env20964) = true)

theorem identity20964 : scanCanonicalize (H12AffineFastState.compose env20964 (packedSelected [1,3,4,5,8,9,10,14,16,17,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound20964 : packedSelected [1,3,4,5,8,9,10,14,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env20965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8313,8403,13673,10281,1025,8312,4113,168,64,374,8328,64,2185,5441,4605,10628,1421,32,257,476,5372,649]

theorem envBound20965 : H12AffineFastState.Bounded env20965 := by
  intro p hp
  have h : env20965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20964_20965 : H12AffineEnvironment.transform 15 8403 env20964 = env20965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env20964 == env20965) = true)

theorem identity20965 : scanCanonicalize (H12AffineFastState.compose env20965 (packedSelected [1,2,3,5,6,8,11,12,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound20965 : packedSelected [1,2,3,5,6,8,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env20966 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4452,8313,8403,12529,10281,409,8312,4113,168,64,374,8328,64,2185,4313,4605,10628,21,32,257,476,4452,649]

theorem envBound20966 : H12AffineFastState.Bounded env20966 := by
  intro p hp
  have h : env20966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20965_20966 : H12AffineEnvironment.transform 9 408 env20965 = env20966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env20965 == env20966) = true)

theorem identity20966 : scanCanonicalize (H12AffineFastState.compose env20966 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20966 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env20967 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,8192,4160,8313,8403,12529,10281,189,8312,4113,168,64,82,8328,64,2185,4313,4313,10400,21,32,37,248,4160,649]

theorem envBound20967 : H12AffineFastState.Bounded env20967 := by
  intro p hp
  have h : env20967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20966_20967 : H12AffineEnvironment.transform 7 36 env20966 = env20967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20966 == env20967) = true)

theorem identity20967 : scanCanonicalize (H12AffineFastState.compose env20967 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20967 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20968 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,8192,4160,8313,8283,12409,10281,53,8312,4113,32,64,82,8192,64,2049,4177,4177,10280,21,32,37,112,4160,513]

theorem envBound20968 : H12AffineFastState.Bounded env20968 := by
  intro p hp
  have h : env20968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20967_20968 : H12AffineEnvironment.transform 6 8 env20967 = env20968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20967 == env20968) = true)

theorem identity20968 : scanCanonicalize (H12AffineFastState.compose env20968 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound20968 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20969 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,6200,4160,6209,6243,2113,4113,53,6208,4113,32,64,82,6200,64,2049,4177,4177,4112,21,32,37,112,4160,513]

theorem envBound20969 : H12AffineFastState.Bounded env20969 := by
  intro p hp
  have h : env20969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20968_20969 : H12AffineEnvironment.transform 12 6200 env20968 = env20969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env20968 == env20969) = true)

theorem identity20969 : scanCanonicalize (H12AffineFastState.compose env20969 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20969 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env20970 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,6200,4113,6160,6194,2064,4113,53,6161,4113,32,17,3,6200,17,2049,4096,4096,4112,21,32,37,33,4113,513]

theorem envBound20970 : H12AffineFastState.Bounded env20970 := by
  intro p hp
  have h : env20970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20969_20970 : H12AffineEnvironment.transform 5 17 env20969 = env20970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20969 == env20970) = true)

theorem identity20970 : scanCanonicalize (H12AffineFastState.compose env20970 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound20970 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20971 : List Nat := [2,4,8,16,32,17,8,36,512,52,529,4096,4649,4113,4609,4643,513,4113,53,4608,4113,32,17,3,4649,17,528,4096,4096,4112,21,32,37,33,4113,513]

theorem envBound20971 : H12AffineFastState.Bounded env20971 := by
  intro p hp
  have h : env20971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20970_20971 : H12AffineEnvironment.transform 10 529 env20970 = env20971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env20970 == env20971) = true)

def env20972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603933,2098513,17664,2377024,2102684,6349853,257,21792,46213,2175563]

theorem envBound20972 : H12AffineFastState.Bounded env20972 := by
  intro p hp
  have h : env20972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20929_20972 : H12AffineEnvironment.transform 16 38161 env20929 = env20972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env20929 == env20972) = true)

def env20973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157597,2098513,17664,2377024,2102684,2411677,257,21792,46213,2175563]

theorem envBound20973 : H12AffineFastState.Bounded env20973 := by
  intro p hp
  have h : env20973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20972_20973 : H12AffineEnvironment.transform 21 272512 env20972 = env20973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20972 == env20973) = true)

def env20974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272392,2101328,98645,8192,64,2157597,2098513,17664,2377024,2102548,2411541,257,21792,46093,2175563]

theorem envBound20974 : H12AffineFastState.Bounded env20974 := by
  intro p hp
  have h : env20974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20973_20974 : H12AffineEnvironment.transform 6 8 env20973 = env20974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20973 == env20974) = true)

theorem identity20974 : scanCanonicalize (H12AffineFastState.compose env20974 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound20974 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,2097152,272392,2101328,87125,8192,64,2111773,2098513,17664,2377024,2102548,2365717,257,21792,24845,2175563]

theorem envBound20975 : H12AffineFastState.Bounded env20975 := by
  intro p hp
  have h : env20975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20974_20975 : H12AffineEnvironment.transform 14 21760 env20974 = env20975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env20974 == env20975) = true)

def env20976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,4160,272392,16,87125,8192,64,10589,5393,17664,283904,1364,264533,257,21792,24845,74251]

theorem envBound20976 : H12AffineFastState.Bounded env20976 := by
  intro p hp
  have h : env20976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20975_20976 : H12AffineEnvironment.transform 20 4160 env20975 = env20976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20975 == env20976) = true)

theorem identity20976 : scanCanonicalize (H12AffineFastState.compose env20976 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound20976 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21591,16401,262144,1025,21761,4160,272392,16,2,8192,64,10589,5393,17664,283904,1364,264533,257,21792,24845,30300]

theorem envBound20977 : H12AffineFastState.Bounded env20977 := by
  intro p hp
  have h : env20977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20976_20977 : H12AffineEnvironment.transform 15 21591 env20976 = env20977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env20976 == env20977) = true)

theorem identity20977 : scanCanonicalize (H12AffineFastState.compose env20977 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound20977 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env20978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21591,16401,2421,1025,21761,4160,8573,16,2,8192,64,10589,5393,17664,23669,1364,32,257,21792,24845,30300]

theorem envBound20978 : H12AffineFastState.Bounded env20978 := by
  intro p hp
  have h : env20978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20977_20978 : H12AffineEnvironment.transform 17 2421 env20977 = env20978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env20977 == env20978) = true)

theorem identity20978 : scanCanonicalize (H12AffineFastState.compose env20978 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound20978 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env20979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8313,8494,13672,2421,1025,8312,4160,8573,16,2,8192,64,10589,5393,12409,10508,1364,32,257,8281,5236,805]

theorem envBound20979 : H12AffineFastState.Bounded env20979 := by
  intro p hp
  have h : env20979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20978_20979 : H12AffineEnvironment.transform 13 13689 env20978 = env20979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env20978 == env20979) = true)

def env20980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,4161,272392,17,87125,8192,64,10588,5392,17664,283905,1365,264532,257,21792,24845,74250]

theorem envBound20980 : H12AffineFastState.Bounded env20980 := by
  intro p hp
  have h : env20980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20975_20980 : H12AffineEnvironment.transform 20 4161 env20975 = env20980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20975 == env20980) = true)

theorem identity20980 : scanCanonicalize (H12AffineFastState.compose env20980 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound20980 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,97407,1025,21761,4161,87159,17,87125,8192,64,10588,5392,17664,76158,1365,95531,257,21792,24845,74250]

theorem envBound20981 : H12AffineFastState.Bounded env20981 := by
  intro p hp
  have h : env20981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20980_20981 : H12AffineEnvironment.transform 17 97407 env20980 = env20981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env20980 == env20981) = true)

theorem identity20981 : scanCanonicalize (H12AffineFastState.compose env20981 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20981 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,16401,23669,1025,21761,4161,29821,17,29791,8192,64,10588,5392,17664,2420,1365,21793,257,21792,24845,512]

theorem envBound20982 : H12AffineFastState.Bounded env20982 := by
  intro p hp
  have h : env20982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20981_20982 : H12AffineEnvironment.transform 15 8202 env20981 = env20982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20981 == env20982) = true)

theorem identity20982 : scanCanonicalize (H12AffineFastState.compose env20982 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound20982 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,293,8202,5172,2128,1025,292,4161,8280,17,8314,8192,64,10588,5392,4389,2420,1365,260,257,261,13608,512]

theorem envBound20983 : H12AffineFastState.Bounded env20983 := by
  intro p hp
  have h : env20983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20982_20983 : H12AffineEnvironment.transform 13 5157 env20982 = env20983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env20982 == env20983) = true)

theorem identity20983 : scanCanonicalize (H12AffineFastState.compose env20983 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound20983 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env20984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2563,5157,293,2569,5172,2128,1025,292,4161,2651,17,2681,2563,64,863,5392,4389,2420,1365,260,257,261,7979,512]

theorem envBound20984 : H12AffineFastState.Bounded env20984 := by
  intro p hp
  have h : env20984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20983_20984 : H12AffineEnvironment.transform 12 2563 env20983 = env20984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env20983 == env20984) = true)

theorem identity20984 : scanCanonicalize (H12AffineFastState.compose env20984 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20984 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env20985 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2563,5157,293,2569,5172,2049,1025,292,4112,2570,17,2600,2563,17,782,5392,4389,2341,1284,260,257,261,7979,512]

theorem envBound20985 : H12AffineFastState.Bounded env20985 := by
  intro p hp
  have h : env20985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20984_20985 : H12AffineEnvironment.transform 5 17 env20984 = env20985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20984 == env20985) = true)

theorem identity20985 : scanCanonicalize (H12AffineFastState.compose env20985 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound20985 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env20986 : List Nat := [2,4,8,16,32,17,8,256,512,1024,554,4096,41,5157,293,35,5172,555,1025,292,4112,32,17,2,41,17,782,5392,4389,783,1284,260,257,261,5377,512]

theorem envBound20986 : H12AffineFastState.Bounded env20986 := by
  intro p hp
  have h : env20986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20985_20986 : H12AffineEnvironment.transform 10 554 env20985 = env20986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env20985 == env20986) = true)

theorem identity20986 : scanCanonicalize (H12AffineFastState.compose env20986 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20986 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20987 : List Nat := [2,4,8,16,0,17,8,256,512,1024,522,4096,9,5125,261,3,5140,523,1025,260,4112,0,17,2,9,17,782,5392,4357,783,1284,260,257,261,5377,512]

theorem envBound20987 : H12AffineFastState.Bounded env20987 := by
  intro p hp
  have h : env20987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20986_20987 : H12AffineEnvironment.transform 4 0 env20986 = env20987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20986 == env20987) = true)

def env20988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272393,2101328,98644,8193,64,2157597,2098513,17664,2377024,2102549,2411540,257,21792,46092,2175563]

theorem envBound20988 : H12AffineFastState.Bounded env20988 := by
  intro p hp
  have h : env20988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20973_20988 : H12AffineEnvironment.transform 6 9 env20973 = env20988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20973 == env20988) = true)

theorem identity20988 : scanCanonicalize (H12AffineFastState.compose env20988 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound20988 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272393,73754,98644,8193,64,121943,79131,17664,357642,75103,392286,257,21792,46092,513]

theorem envBound20989 : H12AffineFastState.Bounded env20989 := by
  intro p hp
  have h : env20989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20988_20989 : H12AffineEnvironment.transform 20 77898 env20988 = env20989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env20988 == env20989) = true)

def env20990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,77898,33,73754,98644,8193,64,121943,79131,17664,89378,75103,119926,257,21792,46092,513]

theorem envBound20990 : H12AffineFastState.Bounded env20990 := by
  intro p hp
  have h : env20990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20989_20990 : H12AffineEnvironment.transform 17 10280 env20989 = env20990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20989 == env20990) = true)

theorem identity20990 : scanCanonicalize (H12AffineFastState.compose env20990 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20990 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env20991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,38161,2420,1025,32769,69910,33,65862,98644,349,64,121943,70727,17664,89378,66563,119926,257,21792,38224,513]

theorem envBound20991 : H12AffineFastState.Bounded env20991 := by
  intro p hp
  have h : env20991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20990_20991 : H12AffineEnvironment.transform 12 348 env20990 = env20991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20990 == env20991) = true)

theorem identity20991 : scanCanonicalize (H12AffineFastState.compose env20991 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound20991 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,16401,2420,1025,21761,69910,33,65862,87124,349,64,67927,70727,17664,89378,66563,65910,257,21792,16464,513]

theorem envBound20992 : H12AffineFastState.Bounded env20992 := by
  intro p hp
  have h : env20992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20991_20992 : H12AffineEnvironment.transform 14 21760 env20991 = env20992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env20991 == env20992) = true)

theorem identity20992 : scanCanonicalize (H12AffineFastState.compose env20992 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20992 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,5393,2420,1025,1,69910,33,65862,65876,349,64,67927,70727,4096,67618,66563,65910,257,32,5456,513]

theorem envBound20993 : H12AffineFastState.Bounded env20993 := by
  intro p hp
  have h : env20993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20992_20993 : H12AffineEnvironment.transform 13 5376 env20992 = env20993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20992 == env20993) = true)

theorem identity20993 : scanCanonicalize (H12AffineFastState.compose env20993 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound20993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2420,1025,1,4161,33,17,3,349,64,2048,5392,4096,2421,1364,33,257,32,5456,513]

theorem envBound20994 : H12AffineFastState.Bounded env20994 := by
  intro p hp
  have h : env20994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20993_20994 : H12AffineEnvironment.transform 15 343 env20993 = env20994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env20993 == env20994) = true)

theorem identity20994 : scanCanonicalize (H12AffineFastState.compose env20994 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound20994 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2415,348,3183,0,343,3198,2420,1025,1,2350,33,17,3,349,64,2048,3199,2415,2421,1364,33,257,32,3135,513]

theorem envBound20995 : H12AffineFastState.Bounded env20995 := by
  intro p hp
  have h : env20995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20994_20995 : H12AffineEnvironment.transform 11 2415 env20994 = env20995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env20994 == env20995) = true)

theorem identity20995 : scanCanonicalize (H12AffineFastState.compose env20995 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound20995 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20996 : List Nat := [2,4,8,16,32,64,9,256,512,266,2048,2415,348,2405,0,343,2420,2420,267,1,2350,33,17,3,349,64,2048,2421,2415,2421,94,33,257,32,2357,513]

theorem envBound20996 : H12AffineFastState.Bounded env20996 := by
  intro p hp
  have h : env20996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20995_20996 : H12AffineEnvironment.transform 9 266 env20995 = env20996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env20995 == env20996) = true)

theorem identity20996 : scanCanonicalize (H12AffineFastState.compose env20996 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20996 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20997 : List Nat := [2,4,8,16,1,64,9,256,512,266,2048,2382,348,2372,0,343,2389,2389,267,1,2319,0,17,3,349,64,2048,2388,2382,2388,94,0,257,1,2324,513]

theorem envBound20997 : H12AffineFastState.Bounded env20997 := by
  intro p hp
  have h : env20997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20996_20997 : H12AffineEnvironment.transform 4 1 env20996 = env20997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20996 == env20997) = true)

theorem identity20997 : scanCanonicalize (H12AffineFastState.compose env20997 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20997 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env20998 : List Nat := [2,4,8,16,1,16,9,256,512,266,2048,2334,268,2324,0,263,2309,2309,267,1,2319,0,17,3,269,16,2048,2308,2334,2308,14,0,257,1,2324,513]

theorem envBound20998 : H12AffineFastState.Bounded env20998 := by
  intro p hp
  have h : env20998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20997_20998 : H12AffineEnvironment.transform 5 16 env20997 = env20998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20997 == env20998) = true)

theorem identity20998 : scanCanonicalize (H12AffineFastState.compose env20998 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound20998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20999 : List Nat := [2,4,8,16,1,16,9,14,512,4,2048,2064,2,2074,0,9,2059,2059,5,1,2049,0,17,3,3,16,2048,2058,2064,2058,14,0,15,1,2074,513]

theorem envBound20999 : H12AffineFastState.Bounded env20999 := by
  intro p hp
  have h : env20999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20998_20999 : H12AffineEnvironment.transform 7 14 env20998 = env20999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env20998 == env20999) = true)

theorem identity20999 : scanCanonicalize (H12AffineFastState.compose env20999 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound20999 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21000 : List Nat := [2,4,8,16,1,16,9,14,17,4,2048,2064,2,2074,0,9,2059,2059,5,1,2049,0,17,3,3,16,2048,2058,2064,2058,14,0,15,1,2074,16]

theorem envBound21000 : H12AffineFastState.Bounded env21000 := by
  intro p hp
  have h : env21000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20999_21000 : H12AffineEnvironment.transform 8 17 env20999 = env21000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env20999 == env21000) = true)

theorem identity21000 : scanCanonicalize (H12AffineFastState.compose env21000 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound21000 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21001 : List Nat := [2,4,8,16,1,16,9,14,17,4,26,10,2,0,0,9,17,17,5,1,27,0,17,3,3,16,26,16,10,16,14,0,15,1,0,16]

theorem envBound21001 : H12AffineFastState.Bounded env21001 := by
  intro p hp
  have h : env21001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21000_21001 : H12AffineEnvironment.transform 10 26 env21000 = env21001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env21000 == env21001) = true)

theorem identity21001 : scanCanonicalize (H12AffineFastState.compose env21001 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound21001 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21002 : List Nat := [2,3,8,16,1,16,9,9,17,3,26,10,2,0,0,9,17,17,2,1,27,0,17,3,3,16,26,16,10,16,9,0,8,1,0,16]

theorem envBound21002 : H12AffineFastState.Bounded env21002 := by
  intro p hp
  have h : env21002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21001_21002 : H12AffineEnvironment.transform 1 3 env21001 = env21002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env21001 == env21002) = true)

theorem identity21002 : scanCanonicalize (H12AffineFastState.compose env21002 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound21002 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env21003 : List Nat := [2,3,8,11,1,11,9,9,10,3,1,10,2,0,0,9,10,10,2,1,0,0,10,3,3,11,1,11,10,11,9,0,8,1,0,11]

theorem envBound21003 : H12AffineFastState.Bounded env21003 := by
  intro p hp
  have h : env21003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21002_21003 : H12AffineEnvironment.transform 3 11 env21002 = env21003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env21002 == env21003) = true)

theorem identity21003 : scanCanonicalize (H12AffineFastState.compose env21003 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound21003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21004 : List Nat := [0,1,8,9,1,9,9,9,8,1,1,8,0,0,0,9,8,8,0,1,0,0,8,1,1,9,1,9,8,9,9,0,8,1,0,9]

theorem envBound21004 : H12AffineFastState.Bounded env21004 := by
  intro p hp
  have h : env21004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21003_21004 : H12AffineEnvironment.transform 0 0 env21003 = env21004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env21003 == env21004) = true)

def env21005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,77898,32,73754,98644,8193,64,121943,79131,17664,89379,75103,119927,257,21792,46092,513]

theorem envBound21005 : H12AffineFastState.Bounded env21005 := by
  intro p hp
  have h : env21005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20989_21005 : H12AffineEnvironment.transform 17 10281 env20989 = env21005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20989 == env21005) = true)

theorem identity21005 : scanCanonicalize (H12AffineFastState.compose env21005 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21005 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4160,32,16,41310,8193,64,64605,5393,17664,32041,1365,62589,257,21792,46092,513]

theorem envBound21006 : H12AffineFastState.Bounded env21006 := by
  intro p hp
  have h : env21006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21005_21006 : H12AffineEnvironment.transform 15 8202 env21005 = env21006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21005 == env21006) = true)

theorem identity21006 : scanCanonicalize (H12AffineFastState.compose env21006 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound21006 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21007 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38161,1125,1025,32769,4160,32,16,36114,3149,64,53265,5393,17664,20837,1365,55345,257,21792,38976,513]

theorem envBound21007 : H12AffineFastState.Bounded env21007 := by
  intro p hp
  have h : env21007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21006_21007 : H12AffineEnvironment.transform 12 3148 env21006 = env21007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env21006 == env21007) = true)

theorem identity21007 : scanCanonicalize (H12AffineFastState.compose env21007 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound21007 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21760,3142,16401,1125,1025,21761,4160,32,16,22546,3149,64,1297,5393,17664,20837,1365,3377,257,21792,19776,513]

theorem envBound21008 : H12AffineFastState.Bounded env21008 := by
  intro p hp
  have h : env21008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21007_21008 : H12AffineEnvironment.transform 14 21760 env21007 = env21008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env21007 == env21008) = true)

theorem identity21008 : scanCanonicalize (H12AffineFastState.compose env21008 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,16384,21760,343,16401,1125,1025,21761,4160,32,16,21763,348,64,1297,5393,17664,20837,1365,32,257,21792,16465,513]

theorem envBound21009 : H12AffineFastState.Bounded env21009 := by
  intro p hp
  have h : env21009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21008_21009 : H12AffineEnvironment.transform 10 1297 env21008 = env21009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env21008 == env21009) = true)

theorem identity21009 : scanCanonicalize (H12AffineFastState.compose env21009 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound21009 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,4405,1077,343,4388,1125,1025,1076,4160,32,16,1078,348,64,1297,5393,5173,80,1365,32,257,1045,4452,513]

theorem envBound21010 : H12AffineFastState.Bounded env21010 := by
  intro p hp
  have h : env21010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21009_21010 : H12AffineEnvironment.transform 13 4405 env21009 = env21010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env21009 == env21010) = true)

theorem identity21010 : scanCanonicalize (H12AffineFastState.compose env21010 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21010 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env21011 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1124,4096,40,4160,1077,34,4177,1125,1025,1076,4160,32,16,1078,41,64,1124,5220,5173,80,1056,32,116,1045,4113,513]

theorem envBound21011 : H12AffineFastState.Bounded env21011 := by
  intro p hp
  have h : env21011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21010_21011 : H12AffineEnvironment.transform 7 117 env21010 = env21011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21010 == env21011) = true)

theorem identity21011 : scanCanonicalize (H12AffineFastState.compose env21011 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21011 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env21012 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,4096,40,4160,80,34,4177,0,100,81,4160,32,16,83,41,64,1,4097,4176,80,69,32,116,112,4113,513]

theorem envBound21012 : H12AffineFastState.Bounded env21012 := by
  intro p hp
  have h : env21012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21011_21012 : H12AffineEnvironment.transform 9 101 env21011 = env21012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21011 == env21012) = true)

theorem identity21012 : scanCanonicalize (H12AffineFastState.compose env21012 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21012 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21013 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,17,40,81,80,34,64,0,100,81,81,32,16,83,41,64,1,16,65,80,69,32,116,112,0,513]

theorem envBound21013 : H12AffineFastState.Bounded env21013 := by
  intro p hp
  have h : env21013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21012_21013 : H12AffineEnvironment.transform 11 17 env21012 = env21013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21012 == env21013) = true)

def env21014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157596,2098513,17664,2377024,2102684,2411676,257,21792,46213,2175563]

theorem envBound21014 : H12AffineFastState.Bounded env21014 := by
  intro p hp
  have h : env21014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20972_21014 : H12AffineEnvironment.transform 21 272513 env20972 = env21014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20972 == env21014) = true)

theorem identity21014 : scanCanonicalize (H12AffineFastState.compose env21014 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound21014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272513,17,98781,8328,64,64605,5392,17664,283905,1501,318685,257,21792,46213,74250]

theorem envBound21015 : H12AffineFastState.Bounded env21015 := by
  intro p hp
  have h : env21015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21014_21015 : H12AffineEnvironment.transform 20 4161 env21014 = env21015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21014 == env21015) = true)

theorem identity21015 : scanCanonicalize (H12AffineFastState.compose env21015 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21015 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4161,272513,17,41430,8328,64,64605,5392,17664,283905,1501,318685,257,21792,46213,513]

theorem envBound21016 : H12AffineFastState.Bounded env21016 := by
  intro p hp
  have h : env21016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21015_21016 : H12AffineEnvironment.transform 15 8203 env21015 = env21016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21015 == env21016) = true)

def env21017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,201933,8328,64,6705549,2265153,184337,2377024,2102685,6451469,257,21793,46212,2175562]

theorem envBound21017 : H12AffineFastState.Bounded env21017 := by
  intro p hp
  have h : env21017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20928_21017 : H12AffineEnvironment.transform 23 201933 env20928 = env21017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201933 env20928 == env21017) = true)

def env21018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603933,2098513,17665,2377024,2102685,6349853,257,21793,46212,2175562]

theorem envBound21018 : H12AffineFastState.Bounded env21018 := by
  intro p hp
  have h : env21018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21017_21018 : H12AffineEnvironment.transform 16 38160 env21017 = env21018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21017 == env21018) = true)

def env21019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157597,2098513,17665,2377024,2102685,2411677,257,21793,46212,2175562]

theorem envBound21019 : H12AffineFastState.Bounded env21019 := by
  intro p hp
  have h : env21019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21018_21019 : H12AffineEnvironment.transform 21 272512 env21018 = env21019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21018 == env21019) = true)

theorem identity21019 : scanCanonicalize (H12AffineFastState.compose env21019 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound21019 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77899,272512,73754,98781,8328,64,121942,79130,17665,357643,75222,392406,257,21793,46212,513]

theorem envBound21020 : H12AffineFastState.Bounded env21020 := by
  intro p hp
  have h : env21020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21019_21020 : H12AffineEnvironment.transform 20 77899 env21019 = env21020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env21019 == env21020) = true)

def env21021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77899,272392,73754,98645,8192,64,121942,79130,17665,357643,75102,392286,257,21793,46092,513]

theorem envBound21021 : H12AffineFastState.Bounded env21021 := by
  intro p hp
  have h : env21021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21020_21021 : H12AffineEnvironment.transform 6 8 env21020 = env21021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21020 == env21021) = true)

theorem identity21021 : scanCanonicalize (H12AffineFastState.compose env21021 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound21021 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,50496,272392,54545,29790,8192,64,10589,49169,17665,294912,53333,264533,257,21793,46092,513]

theorem envBound21022 : H12AffineFastState.Bounded env21022 := by
  intro p hp
  have h : env21022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21021_21022 : H12AffineEnvironment.transform 15 62731 env21021 = env21022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env21021 == env21022) = true)

theorem identity21022 : scanCanonicalize (H12AffineFastState.compose env21022 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound21022 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env21023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,35,24632,262144,1025,29993,12392,272392,8249,29790,8192,64,10589,13625,17665,292136,9597,264533,257,21793,16676,513]

theorem envBound21023 : H12AffineFastState.Bounded env21023 := by
  intro p hp
  have h : env21023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21022_21023 : H12AffineEnvironment.transform 14 29992 env21022 = env21023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env21022 == env21023) = true)

theorem identity21023 : scanCanonicalize (H12AffineFastState.compose env21023 (packedSelected [0,2,4,6,9,17,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound21023 : packedSelected [0,2,4,6,9,17,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env21024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,1,35,5393,262144,1025,0,12392,272392,8249,375,8192,64,10589,13625,12328,262145,9597,264533,257,8200,13325,513]

theorem envBound21024 : H12AffineFastState.Bounded env21024 := by
  intro p hp
  have h : env21024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21023_21024 : H12AffineEnvironment.transform 13 13609 env21023 = env21024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env21023 == env21024) = true)

theorem identity21024 : scanCanonicalize (H12AffineFastState.compose env21024 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11341) := by decide +kernel

theorem selectedBound21024 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,1,35,5393,11341,1025,0,12392,1093,8249,375,8192,64,10589,13625,12328,11340,9597,9496,257,8200,13325,513]

theorem envBound21025 : H12AffineFastState.Bounded env21025 := by
  intro p hp
  have h : env21025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21024_21025 : H12AffineEnvironment.transform 17 11341 env21024 = env21025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11341 env21024 == env21025) = true)

theorem identity21025 : scanCanonicalize (H12AffineFastState.compose env21025 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21025 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21026 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,12621,1,35,4469,10281,101,0,12392,33,8249,375,8192,64,10589,12637,12328,10280,8473,8572,257,8200,12393,513]

theorem envBound21026 : H12AffineFastState.Bounded env21026 := by
  intro p hp
  have h : env21026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21025_21026 : H12AffineEnvironment.transform 9 100 env21025 = env21026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21025 == env21026) = true)

theorem identity21026 : scanCanonicalize (H12AffineFastState.compose env21026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21027 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,12344,1,35,4096,10281,101,0,12392,33,8249,2,8192,64,10280,12328,12328,10280,8300,8201,116,8200,12393,513]

theorem envBound21027 : H12AffineFastState.Bounded env21027 := by
  intro p hp
  have h : env21027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21026_21027 : H12AffineEnvironment.transform 7 117 env21026 = env21027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21026 == env21027) = true)

def env21028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77899,272393,73754,98644,8193,64,121942,79130,17665,357643,75103,392287,257,21793,46093,513]

theorem envBound21028 : H12AffineFastState.Bounded env21028 := by
  intro p hp
  have h : env21028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21020_21028 : H12AffineEnvironment.transform 6 9 env21020 = env21028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21020 == env21028) = true)

def env21029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,77899,33,73754,98644,8193,64,121942,79130,17665,89379,75103,119927,257,21793,46093,513]

theorem envBound21029 : H12AffineFastState.Bounded env21029 := by
  intro p hp
  have h : env21029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21028_21029 : H12AffineEnvironment.transform 17 10280 env21028 = env21029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21028 == env21029) = true)

theorem identity21029 : scanCanonicalize (H12AffineFastState.compose env21029 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21029 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env21030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,38160,2420,1025,32769,69911,33,65862,98644,349,64,121942,70726,17665,89379,66563,119927,257,21793,38225,513]

theorem envBound21030 : H12AffineFastState.Bounded env21030 := by
  intro p hp
  have h : env21030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21029_21030 : H12AffineEnvironment.transform 12 348 env21029 = env21030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21029 == env21030) = true)

theorem identity21030 : scanCanonicalize (H12AffineFastState.compose env21030 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21030 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,16401,2420,1025,21760,69911,33,65862,87125,349,64,67927,70726,17665,89379,66563,65910,257,21793,16464,513]

theorem envBound21031 : H12AffineFastState.Bounded env21031 := by
  intro p hp
  have h : env21031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21030_21031 : H12AffineEnvironment.transform 14 21761 env21030 = env21031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env21030 == env21031) = true)

theorem identity21031 : scanCanonicalize (H12AffineFastState.compose env21031 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21031 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,65536,5392,2420,1025,1,69911,33,65862,65876,349,64,67927,70726,4096,67618,66563,65910,257,32,5457,513]

theorem envBound21032 : H12AffineFastState.Bounded env21032 := by
  intro p hp
  have h : env21032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21031_21032 : H12AffineEnvironment.transform 13 5377 env21031 = env21032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21031 == env21032) = true)

theorem identity21032 : scanCanonicalize (H12AffineFastState.compose env21032 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21032 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5392,2420,1025,1,4160,33,17,3,349,64,2048,5393,4096,2421,1364,33,257,32,5457,513]

theorem envBound21033 : H12AffineFastState.Bounded env21033 := by
  intro p hp
  have h : env21033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21032_21033 : H12AffineEnvironment.transform 15 343 env21032 = env21033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21032 == env21033) = true)

theorem identity21033 : scanCanonicalize (H12AffineFastState.compose env21033 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2414) := by decide +kernel

theorem selectedBound21033 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2414,348,3183,0,343,3198,2420,1025,1,2350,33,17,3,349,64,2048,3199,2414,2421,1364,33,257,32,3135,513]

theorem envBound21034 : H12AffineFastState.Bounded env21034 := by
  intro p hp
  have h : env21034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21033_21034 : H12AffineEnvironment.transform 11 2414 env21033 = env21034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env21033 == env21034) = true)

theorem identity21034 : scanCanonicalize (H12AffineFastState.compose env21034 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound21034 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21035 : List Nat := [2,4,8,16,32,64,9,256,512,266,2048,2414,348,2405,0,343,2420,2420,267,1,2350,33,17,3,349,64,2048,2421,2414,2421,94,33,257,32,2357,513]

theorem envBound21035 : H12AffineFastState.Bounded env21035 := by
  intro p hp
  have h : env21035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21034_21035 : H12AffineEnvironment.transform 9 266 env21034 = env21035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env21034 == env21035) = true)

theorem identity21035 : scanCanonicalize (H12AffineFastState.compose env21035 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21035 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21036 : List Nat := [2,4,8,16,1,64,9,256,512,266,2048,2383,348,2372,0,343,2389,2389,267,1,2319,0,17,3,349,64,2048,2388,2383,2388,94,0,257,1,2324,513]

theorem envBound21036 : H12AffineFastState.Bounded env21036 := by
  intro p hp
  have h : env21036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21035_21036 : H12AffineEnvironment.transform 4 1 env21035 = env21036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21035 == env21036) = true)

theorem identity21036 : scanCanonicalize (H12AffineFastState.compose env21036 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21036 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env21037 : List Nat := [2,4,8,16,1,16,9,256,512,266,2048,2335,268,2324,0,263,2309,2309,267,1,2319,0,17,3,269,16,2048,2308,2335,2308,14,0,257,1,2324,513]

theorem envBound21037 : H12AffineFastState.Bounded env21037 := by
  intro p hp
  have h : env21037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21036_21037 : H12AffineEnvironment.transform 5 16 env21036 = env21037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21036 == env21037) = true)

theorem identity21037 : scanCanonicalize (H12AffineFastState.compose env21037 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound21037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21038 : List Nat := [2,4,8,16,1,16,9,15,512,5,2048,2064,3,2075,0,8,2058,2058,4,1,2048,0,17,3,2,16,2048,2059,2064,2059,14,0,14,1,2075,513]

theorem envBound21038 : H12AffineFastState.Bounded env21038 := by
  intro p hp
  have h : env21038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21037_21038 : H12AffineEnvironment.transform 7 15 env21037 = env21038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env21037 == env21038) = true)

theorem identity21038 : scanCanonicalize (H12AffineFastState.compose env21038 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound21038 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21039 : List Nat := [2,4,8,16,1,16,9,15,17,5,2048,2064,3,2075,0,8,2058,2058,4,1,2048,0,17,3,2,16,2048,2059,2064,2059,14,0,14,1,2075,16]

theorem envBound21039 : H12AffineFastState.Bounded env21039 := by
  intro p hp
  have h : env21039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21038_21039 : H12AffineEnvironment.transform 8 17 env21038 = env21039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env21038 == env21039) = true)

theorem identity21039 : scanCanonicalize (H12AffineFastState.compose env21039 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound21039 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21040 : List Nat := [2,4,8,16,1,16,9,15,17,5,27,11,3,0,0,8,17,17,4,1,27,0,17,3,2,16,27,16,11,16,14,0,14,1,0,16]

theorem envBound21040 : H12AffineFastState.Bounded env21040 := by
  intro p hp
  have h : env21040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21039_21040 : H12AffineEnvironment.transform 10 27 env21039 = env21040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env21039 == env21040) = true)

theorem identity21040 : scanCanonicalize (H12AffineFastState.compose env21040 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound21040 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21041 : List Nat := [2,3,8,16,1,16,9,8,17,2,27,11,3,0,0,8,17,17,3,1,27,0,17,3,2,16,27,16,11,16,9,0,9,1,0,16]

theorem envBound21041 : H12AffineFastState.Bounded env21041 := by
  intro p hp
  have h : env21041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21040_21041 : H12AffineEnvironment.transform 1 3 env21040 = env21041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env21040 == env21041) = true)

theorem identity21041 : scanCanonicalize (H12AffineFastState.compose env21041 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21041 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env21042 : List Nat := [2,3,8,10,1,10,9,8,11,2,1,11,3,0,0,8,11,11,3,1,1,0,11,3,2,10,1,10,11,10,9,0,9,1,0,10]

theorem envBound21042 : H12AffineFastState.Bounded env21042 := by
  intro p hp
  have h : env21042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21041_21042 : H12AffineEnvironment.transform 3 10 env21041 = env21042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21041 == env21042) = true)

theorem identity21042 : scanCanonicalize (H12AffineFastState.compose env21042 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound21042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21043 : List Nat := [2,3,1,3,1,3,0,1,2,2,1,2,3,0,0,1,2,2,3,1,1,0,2,3,2,3,1,3,2,3,0,0,0,1,0,3]

theorem envBound21043 : H12AffineFastState.Bounded env21043 := by
  intro p hp
  have h : env21043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21042_21043 : H12AffineEnvironment.transform 2 1 env21042 = env21043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env21042 == env21043) = true)

def env21044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77899,32,73754,98644,8193,64,121942,79130,17665,89378,75103,119926,257,21793,46093,513]

theorem envBound21044 : H12AffineFastState.Bounded env21044 := by
  intro p hp
  have h : env21044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21028_21044 : H12AffineEnvironment.transform 17 10281 env21028 = env21044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21028 == env21044) = true)

theorem identity21044 : scanCanonicalize (H12AffineFastState.compose env21044 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21044 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4161,32,16,41310,8193,64,64604,5392,17665,32040,1365,62588,257,21793,46093,513]

theorem envBound21045 : H12AffineFastState.Bounded env21045 := by
  intro p hp
  have h : env21045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21044_21045 : H12AffineEnvironment.transform 15 8202 env21044 = env21045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21044 == env21045) = true)

theorem identity21045 : scanCanonicalize (H12AffineFastState.compose env21045 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound21045 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38160,1125,1025,32769,4161,32,16,36114,3149,64,53264,5392,17665,20836,1365,55344,257,21793,38977,513]

theorem envBound21046 : H12AffineFastState.Bounded env21046 := by
  intro p hp
  have h : env21046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21045_21046 : H12AffineEnvironment.transform 12 3148 env21045 = env21046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env21045 == env21046) = true)

theorem identity21046 : scanCanonicalize (H12AffineFastState.compose env21046 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21046 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21761,3142,16401,1125,1025,21760,4161,32,16,22547,3149,64,1297,5392,17665,20836,1365,3377,257,21793,19776,513]

theorem envBound21047 : H12AffineFastState.Bounded env21047 := by
  intro p hp
  have h : env21047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21046_21047 : H12AffineEnvironment.transform 14 21761 env21046 = env21047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env21046 == env21047) = true)

theorem identity21047 : scanCanonicalize (H12AffineFastState.compose env21047 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21047 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,16384,21761,343,16401,1125,1025,21760,4161,32,16,21762,348,64,1297,5392,17665,20836,1365,32,257,21793,16465,513]

theorem envBound21048 : H12AffineFastState.Bounded env21048 := by
  intro p hp
  have h : env21048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21047_21048 : H12AffineEnvironment.transform 10 1297 env21047 = env21048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env21047 == env21048) = true)

theorem identity21048 : scanCanonicalize (H12AffineFastState.compose env21048 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound21048 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,4405,1076,343,4388,1125,1025,1077,4161,32,16,1079,348,64,1297,5392,5172,81,1365,32,257,1044,4452,513]

theorem envBound21049 : H12AffineFastState.Bounded env21049 := by
  intro p hp
  have h : env21049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21048_21049 : H12AffineEnvironment.transform 13 4405 env21048 = env21049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env21048 == env21049) = true)

theorem identity21049 : scanCanonicalize (H12AffineFastState.compose env21049 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21049 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env21050 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1124,4096,40,4160,1076,34,4177,1125,1025,1077,4161,32,16,1079,41,64,1124,5221,5172,81,1056,32,116,1044,4113,513]

theorem envBound21050 : H12AffineFastState.Bounded env21050 := by
  intro p hp
  have h : env21050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21049_21050 : H12AffineEnvironment.transform 7 117 env21049 = env21050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21049 == env21050) = true)

theorem identity21050 : scanCanonicalize (H12AffineFastState.compose env21050 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21050 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env21051 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,4096,40,4113,1076,34,4096,1076,1025,1077,4112,32,16,1079,41,17,1077,5172,5172,0,1056,32,37,1044,4113,513]

theorem envBound21051 : H12AffineFastState.Bounded env21051 := by
  intro p hp
  have h : env21051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21050_21051 : H12AffineEnvironment.transform 5 17 env21050 = env21051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21050 == env21051) = true)

theorem identity21051 : scanCanonicalize (H12AffineFastState.compose env21051 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21051 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21052 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,4096,40,4113,0,34,4096,0,53,1,4112,32,16,3,41,17,1,4096,4096,0,20,32,37,32,4113,513]

theorem envBound21052 : H12AffineFastState.Bounded env21052 := by
  intro p hp
  have h : env21052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21051_21052 : H12AffineEnvironment.transform 9 52 env21051 = env21052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21051 == env21052) = true)

theorem identity21052 : scanCanonicalize (H12AffineFastState.compose env21052 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21052 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21053 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,40,0,0,34,17,0,53,1,1,32,16,3,41,17,1,17,17,0,20,32,37,32,0,513]

theorem envBound21053 : H12AffineFastState.Bounded env21053 := by
  intro p hp
  have h : env21053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21052_21053 : H12AffineEnvironment.transform 11 17 env21052 = env21053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21052 == env21053) = true)

theorem identity21053 : scanCanonicalize (H12AffineFastState.compose env21053 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound21053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21054 : List Nat := [2,4,8,16,11,17,9,15,512,31,1,17,3,0,0,9,17,0,30,1,1,11,16,3,2,17,1,17,17,0,20,11,14,11,0,513]

theorem envBound21054 : H12AffineFastState.Bounded env21054 := by
  intro p hp
  have h : env21054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21053_21054 : H12AffineEnvironment.transform 4 11 env21053 = env21054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env21053 == env21054) = true)

def env21055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157596,2098513,17665,2377024,2102685,2411676,257,21793,46212,2175562]

theorem envBound21055 : H12AffineFastState.Bounded env21055 := by
  intro p hp
  have h : env21055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21018_21055 : H12AffineEnvironment.transform 21 272513 env21018 = env21055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21018 == env21055) = true)

theorem identity21055 : scanCanonicalize (H12AffineFastState.compose env21055 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21055 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272513,2101329,41430,8328,64,2157596,2098513,17665,2377024,2102685,2411676,257,21793,46212,2101825]

theorem envBound21056 : H12AffineFastState.Bounded env21056 := by
  intro p hp
  have h : env21056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21055_21056 : H12AffineEnvironment.transform 15 8203 env21055 = env21056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21055 == env21056) = true)

def env21057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272393,2101329,41310,8192,64,2157596,2098513,17665,2377024,2102549,2411540,257,21793,46092,2101825]

theorem envBound21057 : H12AffineFastState.Bounded env21057 := by
  intro p hp
  have h : env21057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21056_21057 : H12AffineEnvironment.transform 6 8 env21056 = env21057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21056 == env21057) = true)

theorem identity21057 : scanCanonicalize (H12AffineFastState.compose env21057 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301365) := by decide +kernel

theorem selectedBound21057 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,301365,272393,297316,41310,8192,64,292137,302180,17665,56437,298016,21793,257,21793,46092,297844]

theorem envBound21058 : H12AffineFastState.Bounded env21058 := by
  intro p hp
  have h : env21058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21057_21058 : H12AffineEnvironment.transform 20 301365 env21057 = env21058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301365 env21057 == env21058) = true)

theorem identity21058 : scanCanonicalize (H12AffineFastState.compose env21058 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21058 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,38160,262144,1025,32769,301365,264225,297316,33142,40,64,283905,302180,17665,56437,298016,21793,257,21793,37924,297844]

theorem envBound21059 : H12AffineFastState.Bounded env21059 := by
  intro p hp
  have h : env21059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21058_21059 : H12AffineEnvironment.transform 12 40 env21058 = env21059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21058 == env21059) = true)

theorem identity21059 : scanCanonicalize (H12AffineFastState.compose env21059 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21059 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env21060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21761,35,16401,262144,1025,21760,281652,264225,285797,21623,40,64,283905,280933,17665,2420,284961,21793,257,21793,16677,286325]

theorem envBound21060 : H12AffineFastState.Bounded env21060 := by
  intro p hp
  have h : env21060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21059_21060 : H12AffineEnvironment.transform 14 21761 env21059 = env21060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env21059 == env21060) = true)

theorem identity21060 : scanCanonicalize (H12AffineFastState.compose env21060 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound21060 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env21061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21761,35,16401,23669,1025,21760,4161,21588,16,21623,40,64,2420,5392,17665,2420,1364,21793,257,21793,16677,512]

theorem envBound21061 : H12AffineFastState.Bounded env21061 := by
  intro p hp
  have h : env21061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21060_21061 : H12AffineEnvironment.transform 17 23669 env21060 = env21061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env21060 == env21061) = true)

theorem identity21061 : scanCanonicalize (H12AffineFastState.compose env21061 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound21061 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,260,35,5140,2160,1025,261,4161,81,16,114,40,64,2420,5392,4356,2420,1364,292,257,292,5408,512]

theorem envBound21062 : H12AffineFastState.Bounded env21062 := by
  intro p hp
  have h : env21062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21061_21062 : H12AffineEnvironment.transform 13 5125 env21061 = env21062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env21061 == env21062) = true)

theorem identity21062 : scanCanonicalize (H12AffineFastState.compose env21062 (packedSelected [6,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21062 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env21063 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5125,33,35,5140,2160,1025,32,4161,81,16,114,40,64,2129,5173,4129,2129,1137,1,36,1,5125,512]

theorem envBound21063 : H12AffineFastState.Bounded env21063 := by
  intro p hp
  have h : env21063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21062_21063 : H12AffineEnvironment.transform 7 37 env21062 = env21063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21062 == env21063) = true)

theorem identity21063 : scanCanonicalize (H12AffineFastState.compose env21063 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound21063 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env21064 : List Nat := [2,4,8,16,32,64,8,37,512,1024,577,4096,40,5125,33,35,5140,561,1025,32,4161,81,16,114,40,64,528,5173,4129,528,1137,1,36,1,5125,512]

theorem envBound21064 : H12AffineFastState.Bounded env21064 := by
  intro p hp
  have h : env21064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21063_21064 : H12AffineEnvironment.transform 10 577 env21063 = env21064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env21063 == env21064) = true)

theorem identity21064 : scanCanonicalize (H12AffineFastState.compose env21064 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound21064 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21065 : List Nat := [2,4,8,16,32,64,8,37,512,5,577,4096,40,4096,33,35,4113,561,4,32,4161,81,16,114,40,64,528,4144,4129,528,116,1,36,1,4096,512]

theorem envBound21065 : H12AffineFastState.Bounded env21065 := by
  intro p hp
  have h : env21065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21064_21065 : H12AffineEnvironment.transform 9 5 env21064 = env21065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env21064 == env21065) = true)

theorem identity21065 : scanCanonicalize (H12AffineFastState.compose env21065 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound21065 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env21066 : List Nat := [2,4,8,16,32,64,8,37,512,5,577,112,40,112,33,35,97,561,4,32,49,81,16,114,40,64,528,64,81,528,116,1,36,1,112,512]

theorem envBound21066 : H12AffineFastState.Bounded env21066 := by
  intro p hp
  have h : env21066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21065_21066 : H12AffineEnvironment.transform 11 112 env21065 = env21066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env21065 == env21066) = true)

theorem identity21066 : scanCanonicalize (H12AffineFastState.compose env21066 (packedSelected [3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound21066 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env21067 : List Nat := [2,4,8,16,32,64,8,37,80,5,17,112,40,112,33,35,97,97,4,32,49,81,16,114,40,64,64,64,81,64,116,1,36,1,112,80]

theorem envBound21067 : H12AffineFastState.Bounded env21067 := by
  intro p hp
  have h : env21067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21066_21067 : H12AffineEnvironment.transform 8 80 env21066 = env21067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env21066 == env21067) = true)

def env21068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,2097152,272392,2101329,41311,8193,64,2157596,2098513,17665,2377024,2102548,2411541,257,21793,46093,2101825]

theorem envBound21068 : H12AffineFastState.Bounded env21068 := by
  intro p hp
  have h : env21068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21056_21068 : H12AffineEnvironment.transform 6 9 env21056 = env21068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21056 == env21068) = true)

theorem identity21068 : scanCanonicalize (H12AffineFastState.compose env21068 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276585) := by decide +kernel

theorem selectedBound21068 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,276585,272392,272440,41311,8193,64,316533,277816,17665,32041,273789,62588,257,21793,46093,272936]

theorem envBound21069 : H12AffineFastState.Bounded env21069 := by
  intro p hp
  have h : env21069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21068_21069 : H12AffineEnvironment.transform 20 276585 env21068 = env21069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276585 env21068 == env21069) = true)

def env21070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603932,2098512,17664,2377024,2102685,6349852,257,21793,46212,2175562]

theorem envBound21070 : H12AffineFastState.Bounded env21070 := by
  intro p hp
  have h : env21070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21017_21070 : H12AffineEnvironment.transform 16 38161 env21017 = env21070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env21017 == env21070) = true)

def env21071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157596,2098512,17664,2377024,2102685,2411676,257,21793,46212,2175562]

theorem envBound21071 : H12AffineFastState.Bounded env21071 := by
  intro p hp
  have h : env21071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21070_21071 : H12AffineEnvironment.transform 21 272512 env21070 = env21071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21070 == env21071) = true)

theorem identity21071 : scanCanonicalize (H12AffineFastState.compose env21071 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound21071 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,120014,98780,8328,64,75906,115150,17664,360926,119043,329730,257,21793,46212,63188]

theorem envBound21072 : H12AffineFastState.Bounded env21072 := by
  intro p hp
  have h : env21072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21071_21072 : H12AffineEnvironment.transform 20 115870 env21071 = env21072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env21071 == env21072) = true)

def env21073 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,119966,98700,8328,16,75906,115102,17664,360846,119043,329730,257,21793,46212,63108]

theorem envBound21073 : H12AffineFastState.Bounded env21073 := by
  intro p hp
  have h : env21073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21072_21073 : H12AffineEnvironment.transform 5 16 env21072 = env21073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21072 == env21073) = true)

def env21074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115734,272392,119830,98564,8192,16,75786,114966,17664,360710,119043,329730,257,21793,46092,62988]

theorem envBound21074 : H12AffineFastState.Bounded env21074 := by
  intro p hp
  have h : env21074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21073_21074 : H12AffineEnvironment.transform 6 8 env21073 = env21074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21073 == env21074) = true)

theorem identity21074 : scanCanonicalize (H12AffineFastState.compose env21074 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound21074 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env21075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,34817,1025,32769,115734,40969,119830,98564,8192,16,75786,114966,17664,67847,119043,98307,257,21793,46092,62988]

theorem envBound21075 : H12AffineFastState.Bounded env21075 := by
  intro p hp
  have h : env21075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21074_21075 : H12AffineEnvironment.transform 17 34817 env21074 = env21075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env21074 == env21075) = true)

theorem identity21075 : scanCanonicalize (H12AffineFastState.compose env21075 (packedSelected [0,4,14,16,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound21075 : packedSelected [0,4,14,16,22,27] rootPS < 2^1333 := by decide +kernel

def env21076 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,38161,34817,1025,32769,17681,40969,21777,3,8192,16,43277,16401,17664,34816,20484,260,257,21793,46092,62988]

theorem envBound21076 : H12AffineFastState.Bounded env21076 := by
  intro p hp
  have h : env21076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21075_21076 : H12AffineEnvironment.transform 15 33031 env21075 = env21076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env21075 == env21076) = true)

theorem identity21076 : scanCanonicalize (H12AffineFastState.compose env21076 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(14+1) ^^^ 15373) := by decide +kernel

theorem selectedBound21076 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env21077 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,15373,15626,10524,13324,1025,15372,17681,7172,21777,3,8192,16,5376,16401,17664,13325,20484,260,257,21793,2049,18945]

theorem envBound21077 : H12AffineFastState.Bounded env21077 := by
  intro p hp
  have h : env21077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21076_21077 : H12AffineEnvironment.transform 14 15373 env21076 = env21077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15373 env21076 == env21077) = true)

theorem identity21077 : scanCanonicalize (H12AffineFastState.compose env21077 (packedSelected [1,2,3,5,6,8,10,15,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21077 : packedSelected [1,2,3,5,6,8,10,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env21078 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,15373,15407,10297,13324,1025,15372,17460,7172,21556,3,8192,16,5157,16401,17445,13325,20484,33,36,21508,2049,18945]

theorem envBound21078 : H12AffineFastState.Bounded env21078 := by
  intro p hp
  have h : env21078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21077_21078 : H12AffineEnvironment.transform 7 37 env21077 = env21078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21077 == env21078) = true)

theorem identity21078 : scanCanonicalize (H12AffineFastState.compose env21078 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21078 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21079 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,16384,7204,7174,2064,5157,1025,7205,17460,7172,21556,3,41,16,5157,16401,17445,5156,20484,33,36,21508,2049,18945]

theorem envBound21079 : H12AffineFastState.Bounded env21079 := by
  intro p hp
  have h : env21079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21078_21079 : H12AffineEnvironment.transform 12 41 env21078 = env21079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21078 == env21079) = true)

theorem identity21079 : scanCanonicalize (H12AffineFastState.compose env21079 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21079 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env21080 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,17,41,16384,3125,3095,2064,1076,1025,3124,17460,3093,17445,3,41,16,1076,16401,17445,1077,16405,33,36,17429,2049,18945]

theorem envBound21080 : H12AffineFastState.Bounded env21080 := by
  intro p hp
  have h : env21080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21079_21080 : H12AffineEnvironment.transform 11 17 env21079 = env21080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21079 == env21080) = true)

def env21081 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115735,272393,119831,98565,8193,16,75787,114967,17664,360711,119043,329730,257,21793,46093,62989]

theorem envBound21081 : H12AffineFastState.Bounded env21081 := by
  intro p hp
  have h : env21081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21073_21081 : H12AffineEnvironment.transform 6 9 env21073 = env21081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21073 == env21081) = true)

theorem identity21081 : scanCanonicalize (H12AffineFastState.compose env21081 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound21081 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env21082 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130094,1025,32769,115735,119847,119831,98565,8193,16,75787,114967,17664,32041,119043,62508,257,21793,46093,62989]

theorem envBound21082 : H12AffineFastState.Bounded env21082 := by
  intro p hp
  have h : env21082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21081_21082 : H12AffineEnvironment.transform 17 130094 env21081 = env21082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env21081 == env21082) = true)

theorem identity21082 : scanCanonicalize (H12AffineFastState.compose env21082 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound21082 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21083 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24861,67618,1025,29709,77851,73771,73755,95497,8193,16,75787,79131,17664,32041,75023,32,257,21793,16385,513]

theorem envBound21083 : H12AffineFastState.Bounded env21083 := by
  intro p hp
  have h : env21083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21082_21083 : H12AffineEnvironment.transform 14 29708 env21082 = env21083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env21082 == env21083) = true)

theorem identity21083 : scanCanonicalize (H12AffineFastState.compose env21083 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21083 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21084 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,65536,16400,67618,1025,21760,69910,65830,65814,87044,268,16,67846,70678,17664,23588,66562,32,257,21793,16385,513]

theorem envBound21084 : H12AffineFastState.Bounded env21084 := by
  intro p hp
  have h : env21084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21083_21084 : H12AffineEnvironment.transform 12 269 env21083 = env21084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21083 == env21084) = true)

theorem identity21084 : scanCanonicalize (H12AffineFastState.compose env21084 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21084 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21085 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,65536,5393,67618,1025,1,69910,65830,65814,65797,268,16,67846,70678,4097,2341,66562,32,257,32,5376,513]

theorem envBound21085 : H12AffineFastState.Bounded env21085 := by
  intro p hp
  have h : env21085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21084_21085 : H12AffineEnvironment.transform 13 5377 env21084 = env21085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21084 == env21085) = true)

theorem identity21085 : scanCanonicalize (H12AffineFastState.compose env21085 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21085 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21086 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4112,32,16,3,268,16,2048,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound21086 : H12AffineFastState.Bounded env21086 := by
  intro p hp
  have h : env21086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21085_21086 : H12AffineEnvironment.transform 15 262 env21085 = env21086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21085 == env21086) = true)

theorem identity21086 : scanCanonicalize (H12AffineFastState.compose env21086 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21086 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21087 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,4096,269,4357,0,262,4373,2340,5,1,4112,32,16,3,268,16,2048,4372,4097,2341,256,32,257,32,4356,513]

theorem envBound21087 : H12AffineFastState.Bounded env21087 := by
  intro p hp
  have h : env21087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21086_21087 : H12AffineEnvironment.transform 9 4 env21086 = env21087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21086 == env21087) = true)

theorem identity21087 : scanCanonicalize (H12AffineFastState.compose env21087 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound21087 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21088 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,821,269,560,0,262,544,2340,5,1,805,32,16,3,268,16,2048,545,820,2341,256,32,257,32,561,513]

theorem envBound21088 : H12AffineFastState.Bounded env21088 := by
  intro p hp
  have h : env21088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21087_21088 : H12AffineEnvironment.transform 11 821 env21087 = env21088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env21087 == env21088) = true)

theorem identity21088 : scanCanonicalize (H12AffineFastState.compose env21088 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound21088 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21089 : List Nat := [2,4,8,16,32,16,9,256,512,4,277,821,269,560,0,262,544,49,5,1,805,32,16,3,268,16,277,545,820,48,256,32,257,32,561,513]

theorem envBound21089 : H12AffineFastState.Bounded env21089 := by
  intro p hp
  have h : env21089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21088_21089 : H12AffineEnvironment.transform 10 277 env21088 = env21089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env21088 == env21089) = true)

theorem identity21089 : scanCanonicalize (H12AffineFastState.compose env21089 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21089 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21090 : List Nat := [2,4,8,16,32,16,9,256,33,4,277,276,269,17,0,262,1,49,5,1,260,32,16,3,268,16,277,0,277,48,256,32,257,32,16,32]

theorem envBound21090 : H12AffineFastState.Bounded env21090 := by
  intro p hp
  have h : env21090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21089_21090 : H12AffineEnvironment.transform 8 33 env21089 = env21090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21089 == env21090) = true)

theorem identity21090 : scanCanonicalize (H12AffineFastState.compose env21090 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21090 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21091 : List Nat := [2,4,8,16,16,16,9,256,17,4,277,276,269,17,0,262,1,1,5,1,260,16,16,3,268,16,277,0,277,0,256,16,257,16,16,16]

theorem envBound21091 : H12AffineFastState.Bounded env21091 := by
  intro p hp
  have h : env21091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21090_21091 : H12AffineEnvironment.transform 4 16 env21090 = env21091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21090 == env21091) = true)

theorem identity21091 : scanCanonicalize (H12AffineFastState.compose env21091 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21091 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21092 : List Nat := [2,4,8,0,0,0,9,256,1,4,261,260,269,1,0,262,1,1,5,1,260,0,0,3,268,0,261,0,261,0,256,0,257,0,0,0]

theorem envBound21092 : H12AffineFastState.Bounded env21092 := by
  intro p hp
  have h : env21092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21091_21092 : H12AffineEnvironment.transform 3 0 env21091 = env21092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21091 == env21092) = true)

theorem identity21092 : scanCanonicalize (H12AffineFastState.compose env21092 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21092 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env21093 : List Nat := [2,4,8,0,0,0,9,4,1,4,1,0,9,1,0,2,1,1,5,1,0,0,0,3,8,0,1,0,1,0,4,0,5,0,0,0]

theorem envBound21093 : H12AffineFastState.Bounded env21093 := by
  intro p hp
  have h : env21093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21092_21093 : H12AffineEnvironment.transform 7 4 env21092 = env21093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21092 == env21093) = true)

def env21094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,115870,272512,119967,98701,8328,17,75906,115103,17664,360847,119043,329730,257,21793,46212,63109]

theorem envBound21094 : H12AffineFastState.Bounded env21094 := by
  intro p hp
  have h : env21094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21072_21094 : H12AffineEnvironment.transform 5 17 env21072 = env21094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21072 == env21094) = true)

theorem identity21094 : scanCanonicalize (H12AffineFastState.compose env21094 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21094 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env21095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,115870,168,119967,98701,8328,17,75906,115103,17664,108967,119043,73770,257,21793,46212,63109]

theorem envBound21095 : H12AffineFastState.Bounded env21095 := by
  intro p hp
  have h : env21095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21094_21095 : H12AffineEnvironment.transform 17 10280 env21094 = env21095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21094 == env21095) = true)

theorem identity21095 : scanCanonicalize (H12AffineFastState.compose env21095 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound21095 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env21096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,65536,5529,10280,1025,137,82966,168,87063,65797,8328,17,75906,82199,17664,76079,86411,73770,257,21793,13324,30221]

theorem envBound21096 : H12AffineFastState.Bounded env21096 := by
  intro p hp
  have h : env21096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21095_21096 : H12AffineEnvironment.transform 14 136 env21095 = env21096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env21095 == env21096) = true)

theorem identity21096 : scanCanonicalize (H12AffineFastState.compose env21096 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound21096 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env21097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,136,65536,5529,10280,1025,137,77971,168,73874,65797,8328,17,75906,79250,12677,76079,75022,73770,257,8612,13324,648]

theorem envBound21097 : H12AffineFastState.Bounded env21097 := by
  intro p hp
  have h : env21097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21096_21097 : H12AffineEnvironment.transform 13 13445 env21096 = env21097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env21096 == env21097) = true)

theorem identity21097 : scanCanonicalize (H12AffineFastState.compose env21097 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21097 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env21098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,136,8202,5529,10280,1025,137,4249,168,152,8463,8328,17,2184,5528,12677,2341,1284,32,257,8612,13324,648]

theorem envBound21098 : H12AffineFastState.Bounded env21098 := by
  intro p hp
  have h : env21098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21097_21098 : H12AffineEnvironment.transform 15 8202 env21097 = env21098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21097 == env21098) = true)

theorem identity21098 : scanCanonicalize (H12AffineFastState.compose env21098 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21098 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env21099 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,5392,10280,1025,0,4112,33,17,8463,8193,17,2049,5393,12556,2341,1284,32,257,8493,13324,513]

theorem envBound21099 : H12AffineFastState.Bounded env21099 := by
  intro p hp
  have h : env21099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21098_21099 : H12AffineEnvironment.transform 6 9 env21098 = env21099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21098 == env21099) = true)

theorem identity21099 : scanCanonicalize (H12AffineFastState.compose env21099 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21099 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21100 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4112,33,17,3,269,17,2049,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound21100 : H12AffineFastState.Bounded env21100 := by
  intro p hp
  have h : env21100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21099_21100 : H12AffineEnvironment.transform 12 268 env21099 = env21100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21099 == env21100) = true)

theorem identity21100 : scanCanonicalize (H12AffineFastState.compose env21100 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21100 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21101 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4112,33,17,3,40,17,2049,5172,4096,2048,1057,32,36,33,5157,513]

theorem envBound21101 : H12AffineFastState.Bounded env21101 := by
  intro p hp
  have h : env21101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21100_21101 : H12AffineEnvironment.transform 7 37 env21100 = env21101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21100 == env21101) = true)

theorem identity21101 : scanCanonicalize (H12AffineFastState.compose env21101 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound21101 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21102 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1599,4096,41,5157,1,35,5173,1598,1025,0,4112,33,17,3,40,17,1598,5172,4096,1599,1057,32,36,33,5157,513]

theorem envBound21102 : H12AffineFastState.Bounded env21102 := by
  intro p hp
  have h : env21102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21101_21102 : H12AffineEnvironment.transform 10 1599 env21101 = env21102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env21101 == env21102) = true)

theorem identity21102 : scanCanonicalize (H12AffineFastState.compose env21102 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound21102 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21103 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1599,1551,41,554,1,35,570,1598,1025,0,1567,33,17,3,40,17,1598,571,1551,1599,1057,32,36,33,554,513]

theorem envBound21103 : H12AffineFastState.Bounded env21103 := by
  intro p hp
  have h : env21103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21102_21103 : H12AffineEnvironment.transform 11 1551 env21102 = env21103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env21102 == env21103) = true)

theorem identity21103 : scanCanonicalize (H12AffineFastState.compose env21103 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21103 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21104 : List Nat := [2,4,8,16,32,17,9,37,512,53,522,570,41,554,1,35,570,523,52,0,554,33,17,3,40,17,523,571,570,522,20,32,36,33,554,513]

theorem envBound21104 : H12AffineFastState.Bounded env21104 := by
  intro p hp
  have h : env21104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21103_21104 : H12AffineEnvironment.transform 9 53 env21103 = env21104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21103 == env21104) = true)

theorem identity21104 : scanCanonicalize (H12AffineFastState.compose env21104 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound21104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21105 : List Nat := [2,4,8,16,32,17,9,37,4,53,14,62,41,46,1,35,62,15,52,0,46,33,17,3,40,17,15,63,62,14,20,32,36,33,46,5]

theorem envBound21105 : H12AffineFastState.Bounded env21105 := by
  intro p hp
  have h : env21105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21104_21105 : H12AffineEnvironment.transform 8 4 env21104 = env21105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env21104 == env21105) = true)

theorem identity21105 : scanCanonicalize (H12AffineFastState.compose env21105 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound21105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21106 : List Nat := [2,4,8,12,32,13,9,37,4,41,14,34,41,46,1,35,34,15,40,0,46,33,13,3,40,13,15,35,34,14,8,32,36,33,46,5]

theorem envBound21106 : H12AffineFastState.Bounded env21106 := by
  intro p hp
  have h : env21106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21105_21106 : H12AffineEnvironment.transform 3 12 env21105 = env21106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env21105 == env21106) = true)

def env21107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157597,2098512,17664,2377024,2102685,2411677,257,21793,46212,2175562]

theorem envBound21107 : H12AffineFastState.Bounded env21107 := by
  intro p hp
  have h : env21107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21070_21107 : H12AffineEnvironment.transform 21 272513 env21070 = env21107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21070 == env21107) = true)

theorem identity21107 : scanCanonicalize (H12AffineFastState.compose env21107 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound21107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38161,262144,1025,32769,2097152,272513,2101328,21763,8328,64,2157597,2098512,17664,2377024,2102685,2411677,257,21793,46212,2156181]

theorem envBound21108 : H12AffineFastState.Bounded env21108 := by
  intro p hp
  have h : env21108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21107_21108 : H12AffineEnvironment.transform 15 54495 env21107 = env21108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env21107 == env21108) = true)

def env21109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,2097152,272393,2101328,21763,8192,64,2157597,2098512,17664,2377024,2102549,2411541,257,21793,46092,2156061]

theorem envBound21109 : H12AffineFastState.Bounded env21109 := by
  intro p hp
  have h : env21109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21108_21109 : H12AffineEnvironment.transform 6 8 env21108 = env21109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21108 == env21109) = true)

theorem identity21109 : scanCanonicalize (H12AffineFastState.compose env21109 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 322589) := by decide +kernel

theorem selectedBound21109 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env21110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,322589,272393,326733,21763,8192,64,262144,321869,17664,43357,325896,8200,257,21793,46092,264704]

theorem envBound21110 : H12AffineFastState.Bounded env21110 := by
  intro p hp
  have h : env21110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21109_21110 : H12AffineEnvironment.transform 20 322589 env21109 = env21110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322589 env21109 == env21110) = true)

theorem identity21110 : scanCanonicalize (H12AffineFastState.compose env21110 (packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound21110 : packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,56576,1025,32769,12573,62729,8525,21763,8192,64,56576,13389,17664,43357,9224,8200,257,21793,46092,55040]

theorem envBound21111 : H12AffineFastState.Bounded env21111 := by
  intro p hp
  have h : env21111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21110_21111 : H12AffineEnvironment.transform 17 56576 env21110 = env21111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env21110 == env21111) = true)

theorem identity21111 : scanCanonicalize (H12AffineFastState.compose env21111 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound21111 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40971,38161,43356,1025,32769,12573,33109,8525,8543,8192,64,43356,13389,12636,43357,9224,8200,257,8573,46092,41820]

theorem envBound21112 : H12AffineFastState.Bounded env21112 := by
  intro p hp
  have h : env21112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21111_21112 : H12AffineEnvironment.transform 13 13404 env21111 = env21112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env21111 == env21112) = true)

theorem identity21112 : scanCanonicalize (H12AffineFastState.compose env21112 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound21112 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env21113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8233,34,13624,2421,1025,8232,12573,8572,8525,8543,8192,64,2421,13389,12636,2420,9224,8200,257,8573,5157,885]

theorem envBound21113 : H12AffineFastState.Bounded env21113 := by
  intro p hp
  have h : env21113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21112_21113 : H12AffineEnvironment.transform 14 8233 env21112 = env21113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env21112 == env21113) = true)

theorem identity21113 : scanCanonicalize (H12AffineFastState.compose env21113 (packedSelected [1,3,8,10,12,15,18,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21113 : packedSelected [1,3,8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env21114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,372,34,5221,2421,1025,373,4160,33,16,2,349,64,2421,5392,4097,2420,1365,341,257,32,5157,885]

theorem envBound21114 : H12AffineFastState.Bounded env21114 := by
  intro p hp
  have h : env21114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21113_21114 : H12AffineEnvironment.transform 12 349 env21113 = env21114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21113 == env21114) = true)

theorem identity21114 : scanCanonicalize (H12AffineFastState.compose env21114 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21114 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21115 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,5156,81,34,5221,2128,1025,80,4160,33,16,2,120,64,2128,5173,4097,2129,1136,112,36,32,5157,592]

theorem envBound21115 : H12AffineFastState.Bounded env21115 := by
  intro p hp
  have h : env21115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21114_21115 : H12AffineEnvironment.transform 7 37 env21114 = env21115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21114 == env21115) = true)

theorem identity21115 : scanCanonicalize (H12AffineFastState.compose env21115 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound21115 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env21116 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,120,2048,81,34,2113,2128,1025,80,3172,33,16,2,120,64,2128,2065,3109,2129,1136,112,36,32,2049,592]

theorem envBound21116 : H12AffineFastState.Bounded env21116 := by
  intro p hp
  have h : env21116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21115_21116 : H12AffineEnvironment.transform 11 3108 env21115 = env21116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env21115 == env21116) = true)

theorem identity21116 : scanCanonicalize (H12AffineFastState.compose env21116 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound21116 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21117 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,17,120,1077,81,34,1140,1125,1025,80,81,33,16,2,120,64,1125,1060,16,1124,1136,112,36,32,1076,592]

theorem envBound21117 : H12AffineFastState.Bounded env21117 := by
  intro p hp
  have h : env21117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21116_21117 : H12AffineEnvironment.transform 10 1077 env21116 = env21117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env21116 == env21117) = true)

theorem identity21117 : scanCanonicalize (H12AffineFastState.compose env21117 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound21117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21118 : List Nat := [2,4,8,16,32,64,8,37,512,36,17,17,120,17,81,34,80,65,37,80,81,33,16,2,120,64,65,0,16,64,84,112,36,32,16,592]

theorem envBound21118 : H12AffineFastState.Bounded env21118 := by
  intro p hp
  have h : env21118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21117_21118 : H12AffineEnvironment.transform 9 36 env21117 = env21118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env21117 == env21118) = true)

theorem identity21118 : scanCanonicalize (H12AffineFastState.compose env21118 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21118 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env21119 : List Nat := [2,4,8,1,32,64,8,37,512,36,0,0,105,0,64,34,65,65,37,65,64,33,1,2,105,64,65,0,1,64,69,97,36,32,1,577]

theorem envBound21119 : H12AffineFastState.Bounded env21119 := by
  intro p hp
  have h : env21119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21118_21119 : H12AffineEnvironment.transform 3 1 env21118 = env21119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21118 == env21119) = true)

def env21120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,2097152,272392,2101328,21763,8193,64,2157597,2098512,17664,2377024,2102548,2411540,257,21793,46093,2156060]

theorem envBound21120 : H12AffineFastState.Bounded env21120 := by
  intro p hp
  have h : env21120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21108_21120 : H12AffineEnvironment.transform 6 9 env21108 = env21120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21108 == env21120) = true)

theorem identity21120 : scanCanonicalize (H12AffineFastState.compose env21120 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound21120 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env21121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,17729,272392,21777,21763,8193,64,43356,16401,17664,262145,20565,297301,257,21793,46093,41821]

theorem envBound21121 : H12AffineFastState.Bounded env21121 := by
  intro p hp
  have h : env21121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21120_21121 : H12AffineEnvironment.transform 20 17729 env21120 = env21121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env21120 == env21121) = true)

theorem identity21121 : scanCanonicalize (H12AffineFastState.compose env21121 (packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21121 : packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env21122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,54358,38161,262144,1025,32769,17729,264452,21777,21763,269,64,34896,16401,17664,262145,20565,297301,257,21793,38145,33361]

theorem envBound21122 : H12AffineFastState.Bounded env21122 := by
  intro p hp
  have h : env21122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21121_21122 : H12AffineEnvironment.transform 12 268 env21121 = env21122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21121 == env21122) = true)

theorem identity21122 : scanCanonicalize (H12AffineFastState.compose env21122 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound21122 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,54358,38161,35108,1025,32769,17729,32800,21777,21763,269,64,34896,16401,17664,35109,20565,113,257,21793,38145,33361]

theorem envBound21123 : H12AffineFastState.Bounded env21123 := by
  intro p hp
  have h : env21123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21122_21123 : H12AffineEnvironment.transform 17 35108 env21122 = env21123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env21122 == env21123) = true)

theorem identity21123 : scanCanonicalize (H12AffineFastState.compose env21123 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21123 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21124 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,54278,38161,35108,1025,32769,17681,32800,21777,21763,269,16,34816,16401,17664,35109,20485,33,257,21793,38145,33281]

theorem envBound21124 : H12AffineFastState.Bounded env21124 := by
  intro p hp
  have h : env21124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21123_21124 : H12AffineEnvironment.transform 5 16 env21123 = env21124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21123 == env21124) = true)

theorem identity21124 : scanCanonicalize (H12AffineFastState.compose env21124 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21124 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env21125 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,32768,33031,38161,35108,1025,32769,4112,32800,16,2,269,16,34816,5392,4097,35109,1284,33,257,32,38145,33281]

theorem envBound21125 : H12AffineFastState.Bounded env21125 := by
  intro p hp
  have h : env21125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21124_21125 : H12AffineEnvironment.transform 13 5377 env21124 = env21125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21124 == env21125) = true)

theorem identity21125 : scanCanonicalize (H12AffineFastState.compose env21125 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21125 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21126 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1297,1046,4096,3125,1025,1296,4112,1329,16,2,269,16,3345,5392,4097,3124,1284,33,257,32,4112,1808]

theorem envBound21126 : H12AffineFastState.Bounded env21126 := by
  intro p hp
  have h : env21126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21125_21126 : H12AffineEnvironment.transform 14 1297 env21125 = env21126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env21125 == env21126) = true)

def env21127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound21127 : H12AffineFastState.Bounded env21127 := by
  intro p hp
  have h : env21127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20775_21127 : H12AffineEnvironment.transform 26 30393345 env20775 = env21127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env20775 == env21127) = true)

def env21128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound21128 : H12AffineFastState.Bounded env21128 := by
  intro p hp
  have h : env21128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21127_21128 : H12AffineEnvironment.transform 18 1024 env21127 = env21128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21127 == env21128) = true)

def env21129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6705549,8393985,10507600,8830977,2102685,12645453,256,21793,46212,2175563]

theorem envBound21129 : H12AffineFastState.Bounded env21129 := by
  intro p hp
  have h : env21129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21128_21129 : H12AffineEnvironment.transform 23 10588556 env21128 = env21129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env21128 == env21129) = true)

def env21130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98780,8328,64,6705549,2098513,17664,2543697,2102685,6349853,256,21793,46212,2175563]

theorem envBound21130 : H12AffineFastState.Bounded env21130 := by
  intro p hp
  have h : env21130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21129_21130 : H12AffineEnvironment.transform 22 2101328 env21129 = env21130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21129 == env21130) = true)

def env21131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98780,8328,64,2259213,2098513,17664,2543697,2102685,2411677,256,21793,46212,2175563]

theorem envBound21131 : H12AffineFastState.Bounded env21131 := by
  intro p hp
  have h : env21131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21130_21131 : H12AffineEnvironment.transform 21 272512 env21130 = env21131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21130 == env21131) = true)

theorem identity21131 : scanCanonicalize (H12AffineFastState.compose env21131 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound21131 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,272512,16,98780,8328,64,158029,5393,17664,442385,1501,318685,256,21793,46212,74251]

theorem envBound21132 : H12AffineFastState.Bounded env21132 := by
  intro p hp
  have h : env21132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21131_21132 : H12AffineEnvironment.transform 20 4160 env21131 = env21132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21131 == env21132) = true)

theorem identity21132 : scanCanonicalize (H12AffineFastState.compose env21132 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21132 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,272512,16,41430,8328,64,158029,5393,17664,442385,1501,318685,256,21793,46212,513]

theorem envBound21133 : H12AffineFastState.Bounded env21133 := by
  intro p hp
  have h : env21133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21132_21133 : H12AffineEnvironment.transform 15 8202 env21132 = env21133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21132 == env21133) = true)

theorem identity21133 : scanCanonicalize (H12AffineFastState.compose env21133 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound21133 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4160,272512,16,41430,8328,64,56657,5393,17664,291853,1501,318685,256,21793,46212,513]

theorem envBound21134 : H12AffineFastState.Bounded env21134 := by
  intro p hp
  have h : env21134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21133_21134 : H12AffineEnvironment.transform 16 46108 env21133 = env21134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env21133 == env21134) = true)

def env21135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4160,272392,16,41310,8192,64,56657,5393,17664,291853,1365,318549,256,21793,46092,513]

theorem envBound21135 : H12AffineFastState.Bounded env21135 := by
  intro p hp
  have h : env21135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21134_21135 : H12AffineEnvironment.transform 6 8 env21134 = env21135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21134 == env21135) = true)

theorem identity21135 : scanCanonicalize (H12AffineFastState.compose env21135 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21135 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5440,262144,1024,8541,4160,272392,16,2,8192,64,31757,5393,17664,291853,1365,294153,256,21793,5456,513]

theorem envBound21136 : H12AffineFastState.Bounded env21136 := by
  intro p hp
  have h : env21136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21135_21136 : H12AffineEnvironment.transform 14 8540 env21135 = env21136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21135 == env21136) = true)

theorem identity21136 : scanCanonicalize (H12AffineFastState.compose env21136 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 23888) := by decide +kernel

theorem selectedBound21136 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5440,23888,1024,8541,4160,30040,16,2,8192,64,31757,5393,17664,10589,1365,8281,256,21793,5456,513]

theorem envBound21137 : H12AffineFastState.Bounded env21137 := by
  intro p hp
  have h : env21137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21136_21137 : H12AffineEnvironment.transform 17 23888 env21136 = env21137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23888 env21136 == env21137) = true)

theorem identity21137 : scanCanonicalize (H12AffineFastState.compose env21137 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21137 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21138 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,8202,4176,22592,272,8541,4160,28744,16,2,8192,64,31005,4097,16400,10589,69,8281,256,20529,4160,513]

theorem envBound21138 : H12AffineFastState.Bounded env21138 := by
  intro p hp
  have h : env21138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21137_21138 : H12AffineEnvironment.transform 9 272 env21137 = env21138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21137 == env21138) = true)

theorem identity21138 : scanCanonicalize (H12AffineFastState.compose env21138 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound21138 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21139 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12393,8540,8202,4176,10281,272,8541,4160,33,16,2,8192,64,2420,4097,12409,10589,69,8281,256,8280,4160,513]

theorem envBound21139 : H12AffineFastState.Bounded env21139 := by
  intro p hp
  have h : env21139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21138_21139 : H12AffineEnvironment.transform 13 12393 env21138 = env21139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env21138 == env21139) = true)

theorem identity21139 : scanCanonicalize (H12AffineFastState.compose env21139 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21139 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env21140 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4161,372,34,4176,2049,272,373,4160,33,16,2,40,64,2420,4097,4177,2421,69,113,256,112,4160,513]

theorem envBound21140 : H12AffineFastState.Bounded env21140 := by
  intro p hp
  have h : env21140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21139_21140 : H12AffineEnvironment.transform 12 40 env21139 = env21140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21139 == env21140) = true)

def env21141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4160,272393,16,41311,8193,64,56657,5393,17664,291853,1364,318548,256,21793,46093,513]

theorem envBound21141 : H12AffineFastState.Bounded env21141 := by
  intro p hp
  have h : env21141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21134_21141 : H12AffineEnvironment.transform 6 9 env21134 = env21141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21134 == env21141) = true)

theorem identity21141 : scanCanonicalize (H12AffineFastState.compose env21141 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21141 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env21142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16448,262144,1024,29789,4160,272393,16,21763,8193,64,10509,5393,17664,291853,1364,272392,256,21793,16465,513]

theorem envBound21142 : H12AffineFastState.Bounded env21142 := by
  intro p hp
  have h : env21142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21141_21142 : H12AffineEnvironment.transform 14 29788 env21141 = env21142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21141 == env21142) = true)

theorem identity21142 : scanCanonicalize (H12AffineFastState.compose env21142 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound21142 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16448,2421,1024,29789,4160,8572,16,21763,8193,64,10509,5393,17664,32120,1364,8573,256,21793,16465,513]

theorem envBound21143 : H12AffineFastState.Bounded env21143 := by
  intro p hp
  have h : env21143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21142_21143 : H12AffineEnvironment.transform 17 2421 env21142 = env21143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env21142 == env21143) = true)

theorem identity21143 : scanCanonicalize (H12AffineFastState.compose env21143 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21143 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21144 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,16401,2340,1024,29708,4113,8493,16,21763,8193,17,10509,5393,17664,32041,1285,8492,256,21793,16384,513]

theorem envBound21144 : H12AffineFastState.Bounded env21144 := by
  intro p hp
  have h : env21144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21143_21144 : H12AffineEnvironment.transform 5 17 env21143 = env21144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21143 == env21144) = true)

theorem identity21144 : scanCanonicalize (H12AffineFastState.compose env21144 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21144 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env21145 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28729,8202,16401,2340,52,28728,4113,8493,16,20791,8193,17,10509,4389,16692,31005,305,8492,256,20757,16384,513]

theorem envBound21145 : H12AffineFastState.Bounded env21145 := by
  intro p hp
  have h : env21145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21144_21145 : H12AffineEnvironment.transform 9 52 env21144 = env21145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21144 == env21145) = true)

theorem identity21145 : scanCanonicalize (H12AffineFastState.compose env21145 (packedSelected [0,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 14621) := by decide +kernel

theorem selectedBound21145 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env21146 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,14621,2340,8202,14604,2340,52,2341,4113,8493,16,10282,8193,17,10509,4389,14377,0,305,8492,256,10248,14621,513]

theorem envBound21146 : H12AffineFastState.Bounded env21146 := by
  intro p hp
  have h : env21146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21145_21146 : H12AffineEnvironment.transform 13 14621 env21145 = env21146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14621 env21145 == env21146) = true)

theorem identity21146 : scanCanonicalize (H12AffineFastState.compose env21146 (packedSelected [6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound21146 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env21147 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,2316,4113,2340,2310,4096,2340,52,2341,4113,2081,16,294,2317,17,1,4389,4389,0,305,2080,256,260,4113,513]

theorem envBound21147 : H12AffineFastState.Bounded env21147 := by
  intro p hp
  have h : env21147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21146_21147 : H12AffineEnvironment.transform 12 2316 env21146 = env21147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env21146 == env21147) = true)

theorem identity21147 : scanCanonicalize (H12AffineFastState.compose env21147 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21147 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21148 : List Nat := [2,4,8,16,32,17,9,256,512,52,292,4096,40,4113,0,34,4096,0,52,1,4113,261,16,294,41,17,1,4389,4389,0,305,260,256,260,4113,513]

theorem envBound21148 : H12AffineFastState.Bounded env21148 := by
  intro p hp
  have h : env21148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21147_21148 : H12AffineEnvironment.transform 10 292 env21147 = env21148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21147 == env21148) = true)

theorem identity21148 : scanCanonicalize (H12AffineFastState.compose env21148 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21148 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21149 : List Nat := [2,4,8,16,32,17,9,37,512,52,1,4096,40,4113,0,34,4096,0,52,1,4113,32,16,3,41,17,1,4096,4096,0,20,33,37,33,4113,513]

theorem envBound21149 : H12AffineFastState.Bounded env21149 := by
  intro p hp
  have h : env21149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21148_21149 : H12AffineEnvironment.transform 7 37 env21148 = env21149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21148 == env21149) = true)

theorem identity21149 : scanCanonicalize (H12AffineFastState.compose env21149 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21150 : List Nat := [2,4,8,16,17,17,9,20,512,5,1,4096,25,4113,0,19,4096,0,5,1,4113,17,16,3,24,17,1,4096,4096,0,20,16,20,16,4113,513]

theorem envBound21150 : H12AffineFastState.Bounded env21150 := by
  intro p hp
  have h : env21150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21149_21150 : H12AffineEnvironment.transform 4 17 env21149 = env21150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21149 == env21150) = true)

theorem identity21150 : scanCanonicalize (H12AffineFastState.compose env21150 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound21150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21151 : List Nat := [2,4,8,16,17,17,9,20,512,5,1,16,25,1,0,19,16,0,5,1,1,17,16,3,24,17,1,16,16,0,20,16,20,16,1,513]

theorem envBound21151 : H12AffineFastState.Bounded env21151 := by
  intro p hp
  have h : env21151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21150_21151 : H12AffineEnvironment.transform 11 16 env21150 = env21151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21150 == env21151) = true)

def env21152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98780,8328,64,2259212,2098513,17664,2543697,2102685,2411676,256,21793,46212,2175563]

theorem envBound21152 : H12AffineFastState.Bounded env21152 := by
  intro p hp
  have h : env21152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21130_21152 : H12AffineEnvironment.transform 21 272513 env21130 = env21152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21130 == env21152) = true)

def env21153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272393,2101328,98644,8192,64,2259212,2098513,17664,2543697,2102549,2411540,256,21793,46092,2175563]

theorem envBound21153 : H12AffineFastState.Bounded env21153 := by
  intro p hp
  have h : env21153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21152_21153 : H12AffineEnvironment.transform 6 8 env21152 = env21153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21152 == env21153) = true)

theorem identity21153 : scanCanonicalize (H12AffineFastState.compose env21153 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 225370) := by decide +kernel

theorem selectedBound21153 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,225370,272393,221194,98644,8192,64,67926,226571,17664,368651,222543,506958,256,21793,46092,147985]

theorem envBound21154 : H12AffineFastState.Bounded env21154 := by
  intro p hp
  have h : env21154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21153_21154 : H12AffineEnvironment.transform 20 225370 env21153 = env21154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 225370 env21153 == env21154) = true)

theorem identity21154 : scanCanonicalize (H12AffineFastState.compose env21154 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound21154 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1024,32769,225370,41340,221194,98644,8192,64,67926,226571,17664,76158,222543,210235,256,21793,46092,147985]

theorem envBound21155 : H12AffineFastState.Bounded env21155 := by
  intro p hp
  have h : env21155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21154_21155 : H12AffineEnvironment.transform 17 35189 env21154 = env21155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env21154 == env21155) = true)

theorem identity21155 : scanCanonicalize (H12AffineFastState.compose env21155 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound21155 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1024,32769,4161,41340,17,98644,8192,64,67926,5392,17664,76158,1364,21792,256,21793,46092,74250]

theorem envBound21156 : H12AffineFastState.Bounded env21156 := by
  intro p hp
  have h : env21156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21155_21156 : H12AffineEnvironment.transform 16 90139 env21155 = env21156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env21155 == env21156) = true)

theorem identity21156 : scanCanonicalize (H12AffineFastState.compose env21156 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21156 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1024,32769,4161,41340,17,41311,8192,64,10589,5392,17664,2421,1364,21792,256,21793,46092,513]

theorem envBound21157 : H12AffineFastState.Bounded env21157 := by
  intro p hp
  have h : env21157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21156_21157 : H12AffineEnvironment.transform 15 8203 env21156 = env21157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21156 == env21157) = true)

theorem identity21157 : scanCanonicalize (H12AffineFastState.compose env21157 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound21157 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,8203,16400,3124,1024,1344,4161,9277,17,9246,8192,64,10589,5392,17664,2421,1364,21792,256,21793,12621,513]

theorem envBound21158 : H12AffineFastState.Bounded env21158 := by
  intro p hp
  have h : env21158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21157_21158 : H12AffineEnvironment.transform 14 1345 env21157 = env21158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env21157 == env21158) = true)

theorem identity21158 : scanCanonicalize (H12AffineFastState.compose env21158 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound21158 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,1345,8203,12408,3124,1024,1344,4161,9277,17,9246,8192,64,10589,5392,13672,2421,1364,9544,256,9545,12621,513]

theorem envBound21159 : H12AffineFastState.Bounded env21159 := by
  intro p hp
  have h : env21159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21158_21159 : H12AffineEnvironment.transform 13 12392 env21158 = env21159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env21158 == env21159) = true)

theorem identity21159 : scanCanonicalize (H12AffineFastState.compose env21159 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21159 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,4112,1345,115,4096,3124,1024,1344,4161,1093,17,1126,120,64,2341,5392,5392,2421,1364,1328,256,1329,4405,513]

theorem envBound21160 : H12AffineFastState.Bounded env21160 := by
  intro p hp
  have h : env21160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21159_21160 : H12AffineEnvironment.transform 12 120 env21159 = env21160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21159 == env21160) = true)

theorem identity21160 : scanCanonicalize (H12AffineFastState.compose env21160 (packedSelected [5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound21160 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env21161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,120,2421,1345,115,2405,3124,1024,1344,2340,1093,17,1126,120,64,2341,3189,3189,2421,1364,1328,256,1329,2128,513]

theorem envBound21161 : H12AffineFastState.Bounded env21161 := by
  intro p hp
  have h : env21161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21160_21161 : H12AffineEnvironment.transform 11 2405 env21160 = env21161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env21160 == env21161) = true)

theorem identity21161 : scanCanonicalize (H12AffineFastState.compose env21161 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound21161 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1076,1361,120,1345,1345,115,1361,0,1024,1344,1296,1093,17,1126,120,64,1297,65,65,1345,1364,1328,256,1329,1124,513]

theorem envBound21162 : H12AffineFastState.Bounded env21162 := by
  intro p hp
  have h : env21162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21161_21162 : H12AffineEnvironment.transform 10 1076 env21161 = env21162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env21161 == env21162) = true)

theorem identity21162 : scanCanonicalize (H12AffineFastState.compose env21162 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21162 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env21163 : List Nat := [2,4,8,16,32,64,8,256,512,53,1,356,120,372,372,115,356,0,53,373,293,112,17,83,120,64,292,65,65,372,353,261,256,260,81,513]

theorem envBound21163 : H12AffineFastState.Bounded env21163 := by
  intro p hp
  have h : env21163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21162_21163 : H12AffineEnvironment.transform 9 53 env21162 = env21163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21162 == env21163) = true)

theorem identity21163 : scanCanonicalize (H12AffineFastState.compose env21163 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21163 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21164 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,17,120,1,1,115,17,0,53,0,80,112,17,83,120,64,81,65,65,1,20,112,117,113,81,513]

theorem envBound21164 : H12AffineFastState.Bounded env21164 := by
  intro p hp
  have h : env21164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21163_21164 : H12AffineEnvironment.transform 7 117 env21163 = env21164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21163 == env21164) = true)

def env21165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272392,2101328,98645,8193,64,2259212,2098513,17664,2543697,2102548,2411541,256,21793,46093,2175563]

theorem envBound21165 : H12AffineFastState.Bounded env21165 := by
  intro p hp
  have h : env21165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21152_21165 : H12AffineEnvironment.transform 6 9 env21152 = env21165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21152 == env21165) = true)

def env21166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,272392,16,98645,8193,64,158028,5393,17664,442385,1364,318549,256,21793,46093,74251]

theorem envBound21166 : H12AffineFastState.Bounded env21166 := by
  intro p hp
  have h : env21166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21165_21166 : H12AffineEnvironment.transform 20 4160 env21165 = env21166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21165 == env21166) = true)

theorem identity21166 : scanCanonicalize (H12AffineFastState.compose env21166 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21166 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,272392,16,41311,8193,64,158028,5393,17664,442385,1364,318549,256,21793,46093,513]

theorem envBound21167 : H12AffineFastState.Bounded env21167 := by
  intro p hp
  have h : env21167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21166_21167 : H12AffineEnvironment.transform 15 8202 env21166 = env21167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21166 == env21167) = true)

theorem identity21167 : scanCanonicalize (H12AffineFastState.compose env21167 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound21167 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4160,272392,16,41311,8193,64,56657,5393,17664,291852,1364,318549,256,21793,46093,513]

theorem envBound21168 : H12AffineFastState.Bounded env21168 := by
  intro p hp
  have h : env21168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21167_21168 : H12AffineEnvironment.transform 16 46109 env21167 = env21168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env21167 == env21168) = true)

theorem identity21168 : scanCanonicalize (H12AffineFastState.compose env21168 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21168 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env21169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,38209,262144,1024,32769,4160,264532,16,32771,349,64,56657,5393,17664,283984,1364,318549,256,21793,38225,513]

theorem envBound21169 : H12AffineFastState.Bounded env21169 := by
  intro p hp
  have h : env21169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21168_21169 : H12AffineEnvironment.transform 12 348 env21168 = env21169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21168 == env21169) = true)

theorem identity21169 : scanCanonicalize (H12AffineFastState.compose env21169 (packedSelected [1,3,4,5,8,9,10,14,20,26] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound21169 : packedSelected [1,3,4,5,8,9,10,14,20,26] rootPS < 2^1333 := by decide +kernel

def env21170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,38209,56436,1024,32769,4160,54560,16,32771,349,64,56657,5393,17664,35108,1364,33,256,21793,38225,513]

theorem envBound21170 : H12AffineFastState.Bounded env21170 := by
  intro p hp
  have h : env21170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21169_21170 : H12AffineEnvironment.transform 17 56436 env21169 = env21170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env21169 == env21170) = true)

theorem identity21170 : scanCanonicalize (H12AffineFastState.compose env21170 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound21170 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env21171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,342,16401,2340,1024,21841,4160,112,16,21843,349,64,2049,5393,17664,23668,1364,33,256,21793,16385,513]

theorem envBound21171 : H12AffineFastState.Bounded env21171 := by
  intro p hp
  have h : env21171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21170_21171 : H12AffineEnvironment.transform 14 21840 env21170 = env21171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env21170 == env21171) = true)

theorem identity21171 : scanCanonicalize (H12AffineFastState.compose env21171 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3840) := by decide +kernel

theorem selectedBound21171 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env21172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3840,348,16384,19024,342,16401,2340,1024,19025,3904,112,16,19027,349,64,2049,2577,17664,17268,1364,33,256,18977,16385,513]

theorem envBound21172 : H12AffineFastState.Bounded env21172 := by
  intro p hp
  have h : env21172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21171_21172 : H12AffineEnvironment.transform 11 3840 env21171 = env21172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3840 env21171 == env21172) = true)

theorem identity21172 : scanCanonicalize (H12AffineFastState.compose env21172 (packedSelected [2,4,6,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 529) := by decide +kernel

theorem selectedBound21172 : packedSelected [2,4,6,7,10] rootPS < 2^1333 := by decide +kernel

def env21173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3840,348,529,2113,342,512,2340,1024,2112,3904,112,16,2114,349,64,2049,2577,1809,357,1364,33,256,2096,528,513]

theorem envBound21173 : H12AffineFastState.Bounded env21173 := by
  intro p hp
  have h : env21173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21172_21173 : H12AffineEnvironment.transform 13 529 env21172 = env21173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 529 env21172 == env21173) = true)

theorem identity21173 : scanCanonicalize (H12AffineFastState.compose env21173 (packedSelected [5,6,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound21173 : packedSelected [5,6,8,11,18] rootPS < 2^1333 := by decide +kernel

def env21174 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3668,8,529,2113,2,512,2160,1024,2112,3604,112,16,2114,9,64,2049,2577,1605,49,1024,33,84,2096,528,513]

theorem envBound21174 : H12AffineFastState.Bounded env21174 := by
  intro p hp
  have h : env21174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21173_21174 : H12AffineEnvironment.transform 7 84 env21173 = env21174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env21173 == env21174) = true)

theorem identity21174 : scanCanonicalize (H12AffineFastState.compose env21174 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21174 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21175 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3588,8,529,2065,2,512,2080,1024,2064,3604,32,16,2066,9,16,2049,2577,1557,49,1024,33,4,2096,528,513]

theorem envBound21175 : H12AffineFastState.Bounded env21175 := by
  intro p hp
  have h : env21175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21174_21175 : H12AffineEnvironment.transform 5 16 env21174 = env21175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21174 == env21175) = true)

theorem identity21175 : scanCanonicalize (H12AffineFastState.compose env21175 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound21175 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env21176 : List Nat := [2,4,8,16,32,16,9,4,512,1024,16,1556,8,529,1,2,512,48,1024,0,1540,32,16,2,9,16,17,513,1557,49,1024,33,4,32,528,513]

theorem envBound21176 : H12AffineFastState.Bounded env21176 := by
  intro p hp
  have h : env21176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21175_21176 : H12AffineEnvironment.transform 10 16 env21175 = env21176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env21175 == env21176) = true)

theorem identity21176 : scanCanonicalize (H12AffineFastState.compose env21176 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21177 : List Nat := [2,4,8,16,32,16,9,4,512,20,16,512,8,529,1,2,512,48,20,0,528,32,16,2,9,16,17,513,513,49,20,33,4,32,528,513]

theorem envBound21177 : H12AffineFastState.Bounded env21177 := by
  intro p hp
  have h : env21177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21176_21177 : H12AffineEnvironment.transform 9 20 env21176 = env21177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21176 == env21177) = true)

theorem identity21177 : scanCanonicalize (H12AffineFastState.compose env21177 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21177 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21178 : List Nat := [2,4,8,16,1,16,9,4,512,20,16,512,8,529,1,2,512,17,20,0,528,1,16,2,9,16,17,513,513,16,20,0,4,1,528,513]

theorem envBound21178 : H12AffineFastState.Bounded env21178 := by
  intro p hp
  have h : env21178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21177_21178 : H12AffineEnvironment.transform 4 1 env21177 = env21178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21177 == env21178) = true)

theorem identity21178 : scanCanonicalize (H12AffineFastState.compose env21178 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound21178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21179 : List Nat := [2,4,8,16,1,16,9,4,16,20,16,16,8,1,1,2,16,17,20,0,0,1,16,2,9,16,17,17,17,16,20,0,4,1,0,17]

theorem envBound21179 : H12AffineFastState.Bounded env21179 := by
  intro p hp
  have h : env21179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21178_21179 : H12AffineEnvironment.transform 8 16 env21178 = env21179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env21178 == env21179) = true)

def env21180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,272392,17,98645,8193,64,158029,5392,17664,442384,1365,318548,256,21793,46093,74250]

theorem envBound21180 : H12AffineFastState.Bounded env21180 := by
  intro p hp
  have h : env21180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21165_21180 : H12AffineEnvironment.transform 20 4161 env21165 = env21180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21165 == env21180) = true)

theorem identity21180 : scanCanonicalize (H12AffineFastState.compose env21180 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound21180 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,67619,1024,32769,4161,73771,17,98645,8193,64,158029,5392,17664,247859,1365,119927,256,21793,46093,74250]

theorem envBound21181 : H12AffineFastState.Bounded env21181 := by
  intro p hp
  have h : env21181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21180_21181 : H12AffineEnvironment.transform 17 67619 env21180 = env21181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env21180 == env21181) = true)

theorem identity21181 : scanCanonicalize (H12AffineFastState.compose env21181 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21181 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env21182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1024,32769,4161,32,17,41310,8193,64,158029,5392,17664,190520,1365,62588,256,21793,46093,513]

theorem envBound21182 : H12AffineFastState.Bounded env21182 := by
  intro p hp
  have h : env21182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21181_21182 : H12AffineEnvironment.transform 15 8203 env21181 = env21182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21181 == env21182) = true)

theorem identity21182 : scanCanonicalize (H12AffineFastState.compose env21182 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21182 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1024,32769,4161,32,17,41310,8193,64,146509,5392,4096,179512,1365,41340,256,33,46093,513]

theorem envBound21183 : H12AffineFastState.Bounded env21183 := by
  intro p hp
  have h : env21183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21182_21183 : H12AffineEnvironment.transform 13 5376 env21182 = env21183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21182 == env21183) = true)

theorem identity21183 : scanCanonicalize (H12AffineFastState.compose env21183 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound21183 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13340,10280,1024,32769,4161,32,17,41310,8193,64,2129,5392,4096,35108,1365,41340,256,33,46093,513]

theorem envBound21184 : H12AffineFastState.Bounded env21184 := by
  intro p hp
  have h : env21184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21183_21184 : H12AffineEnvironment.transform 16 13340 env21183 = env21184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env21183 == env21184) = true)

def env21185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98781,8328,64,6705549,2098512,17665,2543696,2102685,6349852,256,21793,46212,2175563]

theorem envBound21185 : H12AffineFastState.Bounded env21185 := by
  intro p hp
  have h : env21185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21129_21185 : H12AffineEnvironment.transform 22 2101329 env21129 = env21185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21129 == env21185) = true)

def env21186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98781,8328,64,2259213,2098512,17665,2543696,2102685,2411676,256,21793,46212,2175563]

theorem envBound21186 : H12AffineFastState.Bounded env21186 := by
  intro p hp
  have h : env21186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21185_21186 : H12AffineEnvironment.transform 21 272512 env21185 = env21186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21185 == env21186) = true)

theorem identity21186 : scanCanonicalize (H12AffineFastState.compose env21186 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound21186 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,272512,62661,98781,8328,64,171417,57796,17665,406724,61705,272392,256,21793,46212,120543]

theorem envBound21187 : H12AffineFastState.Bounded env21187 := by
  intro p hp
  have h : env21187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21186_21187 : H12AffineEnvironment.transform 20 58516 env21186 = env21187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env21186 == env21187) = true)

def env21188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,272392,62541,98645,8192,64,171281,57676,17665,406604,61705,272392,256,21793,46092,120407]

theorem envBound21188 : H12AffineFastState.Bounded env21188 := by
  intro p hp
  have h : env21188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21187_21188 : H12AffineEnvironment.transform 6 8 env21187 = env21188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21187 == env21188) = true)

theorem identity21188 : scanCanonicalize (H12AffineFastState.compose env21188 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 244847) := by decide +kernel

theorem selectedBound21188 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env21189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,244847,1024,32769,58396,234599,62541,98645,8192,64,171281,57676,17665,100387,61705,234599,256,21793,46092,120407]

theorem envBound21189 : H12AffineFastState.Bounded env21189 := by
  intro p hp
  have h : env21189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21188_21189 : H12AffineEnvironment.transform 17 244847 env21188 = env21189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 244847 env21188 == env21189) = true)

theorem identity21189 : scanCanonicalize (H12AffineFastState.compose env21189 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound21189 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,79130,35189,1024,32769,58396,41341,62541,98645,8192,64,108555,57676,17665,100387,61705,41341,256,21793,46092,120407]

theorem envBound21190 : H12AffineFastState.Bounded env21190 := by
  intro p hp
  have h : env21190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21189_21190 : H12AffineEnvironment.transform 16 79130 env21189 = env21190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env21189 == env21190) = true)

theorem identity21190 : scanCanonicalize (H12AffineFastState.compose env21190 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound21190 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env21191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,65536,79130,35189,1024,32769,37172,41341,33125,98645,8192,64,108555,37988,12329,100387,33825,41341,256,8201,46092,107391]

theorem envBound21191 : H12AffineFastState.Bounded env21191 := by
  intro p hp
  have h : env21191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21190_21191 : H12AffineEnvironment.transform 13 13608 env21190 = env21191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env21190 == env21191) = true)

theorem identity21191 : scanCanonicalize (H12AffineFastState.compose env21191 (packedSelected [1,3,4,5,9,10,12,14,15,19,20,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21191 : packedSelected [1,3,4,5,9,10,12,14,15,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env21192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,33111,46157,35189,1024,32769,37172,41341,33125,2,8192,64,10588,37988,12329,2420,33825,41341,256,8201,46092,8744]

theorem envBound21192 : H12AffineFastState.Bounded env21192 := by
  intro p hp
  have h : env21192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21191_21192 : H12AffineEnvironment.transform 15 33111 env21191 = env21192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21191 == env21192) = true)

theorem identity21192 : scanCanonicalize (H12AffineFastState.compose env21192 (packedSelected [0,1,2,3,6,7,11,16,17,18,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21192 : packedSelected [0,1,2,3,6,7,11,16,17,18,24,28] rootPS < 2^1333 := by decide +kernel

def env21193 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13324,32768,32883,46157,34897,1024,32769,36880,41049,32833,2,8192,64,10360,37988,12329,2128,33825,41049,36,8201,46092,8744]

theorem envBound21193 : H12AffineFastState.Bounded env21193 := by
  intro p hp
  have h : env21193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21192_21193 : H12AffineEnvironment.transform 7 36 env21192 = env21193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21192 == env21193) = true)

theorem identity21193 : scanCanonicalize (H12AffineFastState.compose env21193 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21193 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env21194 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,32768,32883,37989,34897,1024,32769,36880,32881,32833,2,40,64,2128,37988,4097,2128,33825,32881,36,33,37924,512]

theorem envBound21194 : H12AffineFastState.Bounded env21194 := by
  intro p hp
  have h : env21194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21193_21194 : H12AffineEnvironment.transform 12 40 env21193 = env21194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21193 == env21194) = true)

theorem identity21194 : scanCanonicalize (H12AffineFastState.compose env21194 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound21194 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21195 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,33,82,5188,2160,1024,32,4145,80,96,2,40,64,2128,5189,4097,2128,1024,80,36,33,5125,512]

theorem envBound21195 : H12AffineFastState.Bounded env21195 := by
  intro p hp
  have h : env21195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21194_21195 : H12AffineEnvironment.transform 14 33 env21194 = env21195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env21194 == env21195) = true)

def env21196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,272393,62540,98644,8193,64,171280,57677,17665,406605,61705,272392,256,21793,46093,120406]

theorem envBound21196 : H12AffineFastState.Bounded env21196 := by
  intro p hp
  have h : env21196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21187_21196 : H12AffineEnvironment.transform 6 9 env21187 = env21196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21187 == env21196) = true)

theorem identity21196 : scanCanonicalize (H12AffineFastState.compose env21196 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21196 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env21197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,33,62540,98644,8193,64,171280,57677,17665,138341,61705,32,256,21793,46093,120406]

theorem envBound21197 : H12AffineFastState.Bounded env21197 := by
  intro p hp
  have h : env21197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21196_21197 : H12AffineEnvironment.transform 17 10280 env21196 = env21197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21196 == env21197) = true)

theorem identity21197 : scanCanonicalize (H12AffineFastState.compose env21197 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound21197 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,58397,33,62540,21763,8193,64,171280,57677,17665,138341,61705,32,256,21793,46093,513]

theorem envBound21198 : H12AffineFastState.Bounded env21198 := by
  intro p hp
  have h : env21198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21197_21198 : H12AffineEnvironment.transform 15 54359 env21197 = env21198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env21197 == env21198) = true)

theorem identity21198 : scanCanonicalize (H12AffineFastState.compose env21198 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound21198 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env21199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49217,10280,1024,32769,58397,33,62540,21763,8193,64,23889,57677,17665,56356,61705,32,256,21793,46093,513]

theorem envBound21199 : H12AffineFastState.Bounded env21199 := by
  intro p hp
  have h : env21199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21198_21199 : H12AffineEnvironment.transform 16 49217 env21198 = env21199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env21198 == env21199) = true)

theorem identity21199 : scanCanonicalize (H12AffineFastState.compose env21199 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21199 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env21200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21591,16449,10280,1024,1,25629,33,29772,21763,8193,64,23889,24909,17665,23588,28937,32,256,21793,13325,513]

theorem envBound21200 : H12AffineFastState.Bounded env21200 := by
  intro p hp
  have h : env21200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21199_21200 : H12AffineEnvironment.transform 14 0 env21199 = env21200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21199 == env21200) = true)

theorem identity21200 : scanCanonicalize (H12AffineFastState.compose env21200 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21200 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8202,13340,10280,1024,1,4160,33,17,8542,8193,64,10508,5392,12636,10361,1364,32,256,8572,13325,513]

theorem envBound21201 : H12AffineFastState.Bounded env21201 := by
  intro p hp
  have h : env21201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21200_21201 : H12AffineEnvironment.transform 13 13405 env21200 = env21201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21200 == env21201) = true)

theorem identity21201 : scanCanonicalize (H12AffineFastState.compose env21201 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21201 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21202 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,13340,10280,1024,1,4113,33,17,8463,8193,17,10508,5392,12557,10280,1285,32,256,8493,13325,513]

theorem envBound21202 : H12AffineFastState.Bounded env21202 := by
  intro p hp
  have h : env21202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21201_21202 : H12AffineEnvironment.transform 5 17 env21201 = env21202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21201 == env21202) = true)

theorem identity21202 : scanCanonicalize (H12AffineFastState.compose env21202 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21202 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21203 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8192,13324,0,8202,13340,10280,1024,1,4113,33,17,8202,8193,17,10249,5141,12296,10280,1024,32,5,8232,13325,513]

theorem envBound21203 : H12AffineFastState.Bounded env21203 := by
  intro p hp
  have h : env21203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21202_21203 : H12AffineEnvironment.transform 7 5 env21202 = env21203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21202 == env21203) = true)

theorem identity21203 : scanCanonicalize (H12AffineFastState.compose env21203 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound21203 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env21204 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1567,4096,8192,13324,0,8202,13340,9783,1024,1,4113,33,17,8202,8193,17,9750,5141,12296,9783,1024,32,5,8232,13325,513]

theorem envBound21204 : H12AffineFastState.Bounded env21204 := by
  intro p hp
  have h : env21204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21203_21204 : H12AffineEnvironment.transform 10 1567 env21203 = env21204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env21203 == env21204) = true)

theorem identity21204 : scanCanonicalize (H12AffineFastState.compose env21204 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21204 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21205 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1567,4096,41,5157,0,35,5173,1566,1024,1,4113,33,17,35,40,17,1599,5141,4129,1566,1024,32,5,1,5156,513]

theorem envBound21205 : H12AffineFastState.Bounded env21205 := by
  intro p hp
  have h : env21205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21204_21205 : H12AffineEnvironment.transform 12 41 env21204 = env21205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21204 == env21205) = true)

theorem identity21205 : scanCanonicalize (H12AffineFastState.compose env21205 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21205 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env21206 : List Nat := [2,4,8,16,0,17,9,5,512,1024,1567,4096,9,5125,0,3,5141,1566,1024,1,4113,1,17,3,8,17,1567,5141,4097,1566,1024,0,5,1,5124,513]

theorem envBound21206 : H12AffineFastState.Bounded env21206 := by
  intro p hp
  have h : env21206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21205_21206 : H12AffineEnvironment.transform 4 0 env21205 = env21206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21205 == env21206) = true)

theorem identity21206 : scanCanonicalize (H12AffineFastState.compose env21206 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21207 : List Nat := [2,4,8,16,0,17,9,5,512,20,523,4096,9,4113,0,3,4097,522,20,1,4113,1,17,3,8,17,523,4097,4097,522,20,0,5,1,4112,513]

theorem envBound21207 : H12AffineFastState.Bounded env21207 := by
  intro p hp
  have h : env21207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21206_21207 : H12AffineEnvironment.transform 9 20 env21206 = env21207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21206 == env21207) = true)

theorem identity21207 : scanCanonicalize (H12AffineFastState.compose env21207 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21207 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21208 : List Nat := [2,0,8,16,0,17,9,1,512,16,523,4096,9,4113,0,3,4097,522,16,1,4113,1,17,3,8,17,523,4097,4097,522,16,0,1,1,4112,513]

theorem envBound21208 : H12AffineFastState.Bounded env21208 := by
  intro p hp
  have h : env21208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21207_21208 : H12AffineEnvironment.transform 1 0 env21207 = env21208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21207 == env21208) = true)

theorem identity21208 : scanCanonicalize (H12AffineFastState.compose env21208 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 18) := by decide +kernel

theorem selectedBound21208 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21209 : List Nat := [2,0,8,16,0,17,9,1,512,16,523,18,9,3,0,3,19,522,16,1,3,1,17,3,8,17,523,19,19,522,16,0,1,1,2,513]

theorem envBound21209 : H12AffineFastState.Bounded env21209 := by
  intro p hp
  have h : env21209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21208_21209 : H12AffineEnvironment.transform 11 18 env21208 = env21209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 18 env21208 == env21209) = true)

def env21210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98781,8328,64,2259212,2098512,17665,2543696,2102685,2411677,256,21793,46212,2175563]

theorem envBound21210 : H12AffineFastState.Bounded env21210 := by
  intro p hp
  have h : env21210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21185_21210 : H12AffineEnvironment.transform 21 272513 env21185 = env21210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21185 == env21210) = true)

theorem identity21210 : scanCanonicalize (H12AffineFastState.compose env21210 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21210 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,2101329,95496,8328,64,2259212,2098512,17665,2499717,2102685,2373704,256,21793,16465,2175563]

theorem envBound21211 : H12AffineFastState.Bounded env21211 := by
  intro p hp
  have h : env21211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21210_21211 : H12AffineEnvironment.transform 14 29909 env21210 = env21211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21210 == env21211) = true)

def env21212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272513,2101329,73736,8328,64,2239500,2098512,4097,2499717,2102685,2373704,256,33,5457,2175563]

theorem envBound21212 : H12AffineFastState.Bounded env21212 := by
  intro p hp
  have h : env21212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21211_21212 : H12AffineEnvironment.transform 13 5376 env21211 = env21212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21211 == env21212) = true)

def env21213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,4160,272513,17,73736,8328,64,146508,5392,4097,406725,1501,272392,256,33,5457,74251]

theorem envBound21213 : H12AffineFastState.Bounded env21213 := by
  intro p hp
  have h : env21213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21212_21213 : H12AffineEnvironment.transform 20 4160 env21212 = env21213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21212 == env21213) = true)

theorem identity21213 : scanCanonicalize (H12AffineFastState.compose env21213 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound21213 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,67618,1024,8660,4160,73891,17,73736,8328,64,146508,5392,4097,212199,1501,73770,256,33,5457,74251]

theorem envBound21214 : H12AffineFastState.Bounded env21214 := by
  intro p hp
  have h : env21214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21213_21214 : H12AffineEnvironment.transform 17 67618 env21213 = env21214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env21213 == env21214) = true)

theorem identity21214 : scanCanonicalize (H12AffineFastState.compose env21214 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound21214 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,294,131072,2308,1024,8660,4160,8581,17,8494,8328,64,146508,5392,4097,146881,1501,8460,256,33,5457,9005]

theorem envBound21215 : H12AffineFastState.Bounded env21215 := by
  intro p hp
  have h : env21215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21214_21215 : H12AffineEnvironment.transform 15 294 env21214 = env21215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env21214 == env21215) = true)

theorem identity21215 : scanCanonicalize (H12AffineFastState.compose env21215 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound21215 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,294,13373,2308,1024,8660,4160,8581,17,8494,8328,64,2161,5392,4097,2556,1501,8460,256,33,5457,9005]

theorem envBound21216 : H12AffineFastState.Bounded env21216 := by
  intro p hp
  have h : env21216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0