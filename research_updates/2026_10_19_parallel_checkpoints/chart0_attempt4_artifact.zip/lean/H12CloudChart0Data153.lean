import H12CloudChart0Data152

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env38790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,66047,65863,98780,468,64,2049,70727,17664,100386,66698,54696,257,21793,38361,513]

theorem envBound38790 : H12AffineFastState.Bounded env38790 := by
  intro p hp
  have h : env38790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38789_38790 : H12AffineEnvironment.transform 12 348 env38789 = env38790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38789 == env38790) = true)

def env38791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,65911,65863,98644,348,64,2049,70727,17664,100386,66562,54560,257,21793,38225,513]

theorem envBound38791 : H12AffineFastState.Bounded env38791 := by
  intro p hp
  have h : env38791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38790_38791 : H12AffineEnvironment.transform 6 8 env38790 = env38791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38790 == env38791) = true)

theorem identity38791 : scanCanonicalize (H12AffineFastState.compose env38791 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound38791 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env38792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21510,5441,23588,1025,32769,17680,21873,21825,54610,348,64,2049,16449,17664,56356,20484,54560,257,21793,38225,513]

theorem envBound38792 : H12AffineFastState.Bounded env38792 := by
  intro p hp
  have h : env38792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38791_38792 : H12AffineEnvironment.transform 15 21510 env38791 = env38792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env38791 == env38792) = true)

theorem identity38792 : scanCanonicalize (H12AffineFastState.compose env38792 (packedSelected [1,2,6,8,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound38792 : packedSelected [1,2,6,8,10,14,15] rootPS < 2^1333 := by decide +kernel

def env38793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,293,32768,5411,5441,7425,1025,32769,1077,5204,5220,38007,348,64,2049,356,1061,40193,4385,37893,257,5124,38225,513]

theorem envBound38793 : H12AffineFastState.Bounded env38793 := by
  intro p hp
  have h : env38793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38792_38793 : H12AffineEnvironment.transform 13 293 env38792 = env38793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env38792 == env38793) = true)

theorem identity38793 : scanCanonicalize (H12AffineFastState.compose env38793 (packedSelected [1,2,6,8,10,11,12,23] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound38793 : packedSelected [1,2,6,8,10,11,12,23] rootPS < 2^1333 := by decide +kernel

def env38794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,348,293,32768,342,308,2420,1025,32769,1077,33,17,32770,348,64,2049,356,1061,35188,1364,32880,257,113,33060,513]

theorem envBound38794 : H12AffineFastState.Bounded env38794 := by
  intro p hp
  have h : env38794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38793_38794 : H12AffineEnvironment.transform 11 1141 env38793 = env38794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env38793 == env38794) = true)

theorem identity38794 : scanCanonicalize (H12AffineFastState.compose env38794 (packedSelected [4,7] rootPS)) = affineNative (2^(14+1) ^^^ 3636) := by decide +kernel

theorem selectedBound38794 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,348,293,3636,342,308,2420,1025,3637,1077,33,17,3638,348,64,2049,356,1061,1856,1364,3652,257,113,3856,513]

theorem envBound38795 : H12AffineFastState.Bounded env38795 := by
  intro p hp
  have h : env38795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38794_38795 : H12AffineEnvironment.transform 14 3636 env38794 = env38795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3636 env38794 == env38795) = true)

theorem identity38795 : scanCanonicalize (H12AffineFastState.compose env38795 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1620) := by decide +kernel

theorem selectedBound38795 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env38796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1620,1141,348,293,96,342,308,1824,1025,97,1077,33,17,98,348,64,1621,356,1061,1856,1364,16,257,113,324,513]

theorem envBound38796 : H12AffineFastState.Bounded env38796 := by
  intro p hp
  have h : env38796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38795_38796 : H12AffineEnvironment.transform 10 1620 env38795 = env38796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1620 env38795 == env38796) = true)

theorem identity38796 : scanCanonicalize (H12AffineFastState.compose env38796 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound38796 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env38797 : List Nat := [2,4,8,16,32,32,8,256,512,1024,1588,1045,316,293,0,310,308,1824,1025,1,1077,33,17,2,316,32,1589,260,1061,1824,1332,16,257,17,292,513]

theorem envBound38797 : H12AffineFastState.Bounded env38797 := by
  intro p hp
  have h : env38797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38796_38797 : H12AffineEnvironment.transform 5 32 env38796 = env38797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env38796 == env38797) = true)

theorem identity38797 : scanCanonicalize (H12AffineFastState.compose env38797 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38798 : List Nat := [2,4,8,16,1,1,8,256,512,1024,1557,1045,285,260,0,279,277,1793,1025,1,1044,0,17,2,285,1,1556,260,1028,1793,1301,16,257,17,261,513]

theorem envBound38798 : H12AffineFastState.Bounded env38798 := by
  intro p hp
  have h : env38798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38797_38798 : H12AffineEnvironment.transform 4 1 env38797 = env38798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38797 == env38798) = true)

theorem identity38798 : scanCanonicalize (H12AffineFastState.compose env38798 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound38798 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38799 : List Nat := [2,4,8,16,1,1,8,256,512,533,0,512,285,260,0,279,277,276,532,1,513,0,17,2,285,1,1,260,529,276,768,16,257,17,261,513]

theorem envBound38799 : H12AffineFastState.Bounded env38799 := by
  intro p hp
  have h : env38799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38798_38799 : H12AffineEnvironment.transform 9 533 env38798 = env38799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env38798 == env38799) = true)

theorem identity38799 : scanCanonicalize (H12AffineFastState.compose env38799 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound38799 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38800 : List Nat := [2,4,8,16,1,1,8,256,277,256,0,277,285,260,0,279,277,276,257,1,276,0,17,2,285,1,1,260,260,276,21,16,257,17,261,276]

theorem envBound38800 : H12AffineFastState.Bounded env38800 := by
  intro p hp
  have h : env38800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38799_38800 : H12AffineEnvironment.transform 8 277 env38799 = env38800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env38799 == env38800) = true)

theorem identity38800 : scanCanonicalize (H12AffineFastState.compose env38800 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38800 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38801 : List Nat := [2,4,8,16,1,1,8,4,17,4,0,17,25,0,0,19,17,16,5,1,16,0,17,2,25,1,1,0,0,16,21,16,5,17,1,16]

theorem envBound38801 : H12AffineFastState.Bounded env38801 := by
  intro p hp
  have h : env38801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38800_38801 : H12AffineEnvironment.transform 7 4 env38800 = env38801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38800 == env38801) = true)

theorem identity38801 : scanCanonicalize (H12AffineFastState.compose env38801 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38802 : List Nat := [2,4,8,0,1,1,8,4,1,4,0,1,9,0,0,3,1,0,5,1,0,0,1,2,9,1,1,0,0,0,5,0,5,1,1,0]

theorem envBound38802 : H12AffineFastState.Bounded env38802 := by
  intro p hp
  have h : env38802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38801_38802 : H12AffineEnvironment.transform 3 0 env38801 = env38802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38801 == env38802) = true)

def env38803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,65910,65863,98645,349,64,2049,70727,17664,100386,66563,54561,257,21793,38224,513]

theorem envBound38803 : H12AffineFastState.Bounded env38803 := by
  intro p hp
  have h : env38803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38790_38803 : H12AffineEnvironment.transform 6 9 env38790 = env38803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38790 == env38803) = true)

theorem identity38803 : scanCanonicalize (H12AffineFastState.compose env38803 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound38803 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33110,49169,35188,1025,32769,36928,32800,32785,3,349,64,2049,38161,17664,2420,34133,54561,257,21793,38224,513]

theorem envBound38804 : H12AffineFastState.Bounded env38804 := by
  intro p hp
  have h : env38804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38803_38804 : H12AffineEnvironment.transform 15 33110 env38803 = env38804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env38803 == env38804) = true)

theorem identity38804 : scanCanonicalize (H12AffineFastState.compose env38804 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,343,16400,2421,1025,0,4161,33,16,3,349,64,2049,5392,17664,2420,1364,21792,257,21793,5457,513]

theorem envBound38805 : H12AffineFastState.Bounded env38805 := by
  intro p hp
  have h : env38805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38804_38805 : H12AffineEnvironment.transform 14 1 env38804 = env38805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38804 == env38805) = true)

theorem identity38805 : scanCanonicalize (H12AffineFastState.compose env38805 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38805 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38806 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1025,0,4112,33,16,3,268,17,2049,5392,17664,2341,1285,21792,257,21793,5376,513]

theorem envBound38806 : H12AffineFastState.Bounded env38806 := by
  intro p hp
  have h : env38806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38805_38806 : H12AffineEnvironment.transform 5 17 env38805 = env38806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38805 == env38806) = true)

theorem identity38806 : scanCanonicalize (H12AffineFastState.compose env38806 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38806 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38807 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,1,262,16400,2340,273,0,4112,33,16,3,268,17,2049,4096,16400,2341,21,20528,257,20529,4112,513]

theorem envBound38807 : H12AffineFastState.Bounded env38807 := by
  intro p hp
  have h : env38807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38806_38807 : H12AffineEnvironment.transform 9 272 env38806 = env38807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38806 == env38807) = true)

theorem identity38807 : scanCanonicalize (H12AffineFastState.compose env38807 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound38807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38808 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,4113,1,262,4097,2340,273,0,4112,33,16,3,268,17,2049,4096,4097,2341,21,33,257,32,4112,513]

theorem envBound38808 : H12AffineFastState.Bounded env38808 := by
  intro p hp
  have h : env38808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38807_38808 : H12AffineEnvironment.transform 13 4113 env38807 = env38808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env38807 == env38808) = true)

theorem identity38808 : scanCanonicalize (H12AffineFastState.compose env38808 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38808 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38809 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,1,34,4097,2048,53,0,4112,33,16,3,40,17,2049,4096,4097,2049,21,33,37,32,4112,513]

theorem envBound38809 : H12AffineFastState.Bounded env38809 := by
  intro p hp
  have h : env38809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38808_38809 : H12AffineEnvironment.transform 7 36 env38808 = env38809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38808 == env38809) = true)

theorem identity38809 : scanCanonicalize (H12AffineFastState.compose env38809 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38809 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38810 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,8,4113,1,3,4097,2048,20,0,4112,0,16,3,9,17,2049,4096,4097,2049,21,0,4,1,4112,513]

theorem envBound38810 : H12AffineFastState.Bounded env38810 := by
  intro p hp
  have h : env38810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38809_38810 : H12AffineEnvironment.transform 4 1 env38809 = env38810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38809 == env38810) = true)

theorem identity38810 : scanCanonicalize (H12AffineFastState.compose env38810 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound38810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38811 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,513,8,528,1,3,512,2048,20,0,529,0,16,3,9,17,2049,513,512,2049,21,0,4,1,529,513]

theorem envBound38811 : H12AffineFastState.Bounded env38811 := by
  intro p hp
  have h : env38811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38810_38811 : H12AffineEnvironment.transform 11 513 env38810 = env38811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env38810 == env38811) = true)

theorem identity38811 : scanCanonicalize (H12AffineFastState.compose env38811 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound38811 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38812 : List Nat := [2,4,8,16,1,17,9,5,512,21,529,513,8,528,1,3,512,529,20,0,529,0,16,3,9,17,528,513,512,528,21,0,4,1,529,513]

theorem envBound38812 : H12AffineFastState.Bounded env38812 := by
  intro p hp
  have h : env38812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38811_38812 : H12AffineEnvironment.transform 10 529 env38811 = env38812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env38811 == env38812) = true)

def env38813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound38813 : H12AffineFastState.Bounded env38813 := by
  intro p hp
  have h : env38813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38094_38813 : H12AffineEnvironment.transform 25 65 env38094 = env38813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env38094 == env38813) = true)

def env38814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound38814 : H12AffineFastState.Bounded env38814 := by
  intro p hp
  have h : env38814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38813_38814 : H12AffineEnvironment.transform 26 30393344 env38813 = env38814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env38813 == env38814) = true)

def env38815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound38815 : H12AffineFastState.Bounded env38815 := by
  intro p hp
  have h : env38815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38814_38815 : H12AffineEnvironment.transform 18 1024 env38814 = env38815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env38814 == env38815) = true)

theorem identity38815 : scanCanonicalize (H12AffineFastState.compose env38815 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493478) := by decide +kernel

theorem selectedBound38815 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493478,8328,65,14797862,493738,10507600,8830976,10979382,4680166,256,8898698,8857902,10924001]

theorem envBound38816 : H12AffineFastState.Bounded env38816 := by
  intro p hp
  have h : env38816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38815_38816 : H12AffineEnvironment.transform 23 2493478 env38815 = env38816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493478 env38815 == env38816) = true)

def env38817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797862,115150,10507600,8423780,10600786,4268162,256,8487406,8478794,10544773]

theorem envBound38817 : H12AffineFastState.Bounded env38817 := by
  intro p hp
  have h : env38817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38816_38817 : H12AffineEnvironment.transform 17 149860 env38816 = env38817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env38816 == env38817) = true)

def env38818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,8388608,21762,8328,65,12704870,115150,8406288,8423780,8507666,4268162,256,8487406,8478794,8451781]

theorem envBound38818 : H12AffineFastState.Bounded env38818 := by
  intro p hp
  have h : env38818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38817_38818 : H12AffineEnvironment.transform 20 4160 env38817 = env38818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38817 == env38818) = true)

def env38819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363552,21762,8328,65,215366,115150,4378672,4332612,4408370,4268162,256,4396238,4453738,4350949]

theorem envBound38819 : H12AffineFastState.Bounded env38819 := by
  intro p hp
  have h : env38819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38818_38819 : H12AffineEnvironment.transform 22 4363552 env38818 = env38819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env38818 == env38819) = true)

theorem identity38819 : scanCanonicalize (H12AffineFastState.compose env38819 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38819 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,4194304,4363552,21762,8328,65,158028,57796,4378672,4332612,4351032,4194440,256,4338884,4380000,4350949]

theorem envBound38820 : H12AffineFastState.Bounded env38820 := by
  intro p hp
  have h : env38820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38819_38820 : H12AffineEnvironment.transform 15 8202 env38819 = env38820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38819 == env38820) = true)

theorem identity38820 : scanCanonicalize (H12AffineFastState.compose env38820 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound38820 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,156132,62660,21762,8328,65,158028,57796,45524,32160,1500,156012,256,21792,46212,513]

theorem envBound38821 : H12AffineFastState.Bounded env38821 := by
  intro p hp
  have h : env38821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38820_38821 : H12AffineEnvironment.transform 21 156132 env38820 = env38821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env38820 == env38821) = true)

theorem identity38821 : scanCanonicalize (H12AffineFastState.compose env38821 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound38821 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env38822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,23805,1024,32769,4160,29821,62660,21762,8328,65,31957,57796,45524,32160,1500,29941,256,21792,46212,513]

theorem envBound38822 : H12AffineFastState.Bounded env38822 := by
  intro p hp
  have h : env38822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38821_38822 : H12AffineEnvironment.transform 16 5529 env38821 = env38822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env38821 == env38822) = true)

theorem identity38822 : scanCanonicalize (H12AffineFastState.compose env38822 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38822 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env38823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8202,5529,10401,1024,32769,4160,33,32920,8542,8328,65,2185,38296,45524,2556,1500,169,256,8572,46212,513]

theorem envBound38823 : H12AffineFastState.Bounded env38823 := by
  intro p hp
  have h : env38823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38822_38823 : H12AffineEnvironment.transform 13 13404 env38822 = env38823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38822 == env38823) = true)

theorem identity38823 : scanCanonicalize (H12AffineFastState.compose env38823 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound38823 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env38824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7301,2265,32768,7311,5529,5156,1024,32769,4160,33,32920,7643,7181,65,2185,38296,36177,2556,1500,169,256,7673,34817,513]

theorem envBound38824 : H12AffineFastState.Bounded env38824 := by
  intro p hp
  have h : env38824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38823_38824 : H12AffineEnvironment.transform 12 7301 env38823 = env38824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env38823 == env38824) = true)

theorem identity38824 : scanCanonicalize (H12AffineFastState.compose env38824 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound38824 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env38825 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,6428,2265,32768,6422,4096,4541,409,32769,4160,33,32920,6210,6548,65,2185,36865,35016,2556,69,169,256,6240,34817,513]

theorem envBound38825 : H12AffineFastState.Bounded env38825 := by
  intro p hp
  have h : env38825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38824_38825 : H12AffineEnvironment.transform 9 409 env38824 = env38825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env38824 == env38825) = true)

theorem identity38825 : scanCanonicalize (H12AffineFastState.compose env38825 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound38825 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env38826 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,6428,2265,137,6422,4096,4541,409,136,4160,33,17,6210,6548,65,2185,4232,2113,2556,69,169,256,6240,2184,513]

theorem envBound38826 : H12AffineFastState.Bounded env38826 := by
  intro p hp
  have h : env38826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38825_38826 : H12AffineEnvironment.transform 14 137 env38825 = env38826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env38825 == env38826) = true)

theorem identity38826 : scanCanonicalize (H12AffineFastState.compose env38826 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound38826 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env38827 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2493,161,2265,137,171,2493,2048,409,136,2557,33,17,511,41,65,2185,2357,2113,2556,69,169,256,477,2184,513]

theorem envBound38827 : H12AffineFastState.Bounded env38827 := by
  intro p hp
  have h : env38827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38826_38827 : H12AffineEnvironment.transform 11 2493 env38826 = env38827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env38826 == env38827) = true)

theorem identity38827 : scanCanonicalize (H12AffineFastState.compose env38827 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound38827 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env38828 : List Nat := [2,4,8,16,32,64,128,172,512,53,2048,2065,161,2265,137,171,2065,2048,53,136,2129,33,17,83,41,65,2185,2201,2113,2128,69,169,172,113,2184,513]

theorem envBound38828 : H12AffineFastState.Bounded env38828 := by
  intro p hp
  have h : env38828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38827_38828 : H12AffineEnvironment.transform 7 172 env38827 = env38828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38827 == env38828) = true)

theorem identity38828 : scanCanonicalize (H12AffineFastState.compose env38828 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38828 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env38829 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,2065,161,2184,137,171,2065,2048,53,136,2048,33,17,2,41,16,2185,2201,2064,2049,20,169,172,32,2184,513]

theorem envBound38829 : H12AffineFastState.Bounded env38829 := by
  intro p hp
  have h : env38829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38828_38829 : H12AffineEnvironment.transform 5 17 env38828 = env38829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38828 == env38829) = true)

def env38830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363553,21762,8328,65,215367,115150,4378673,4332613,4408371,4268162,256,4396239,4453739,4350948]

theorem envBound38830 : H12AffineFastState.Bounded env38830 := by
  intro p hp
  have h : env38830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38818_38830 : H12AffineEnvironment.transform 22 4363553 env38818 = env38830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env38818 == env38830) = true)

theorem identity38830 : scanCanonicalize (H12AffineFastState.compose env38830 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound38830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243003,73754,21762,8328,65,215367,115150,91402,108926,61704,169401,256,41460,16464,120543]

theorem envBound38831 : H12AffineFastState.Bounded env38831 := by
  intro p hp
  have h : env38831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38830_38831 : H12AffineEnvironment.transform 21 243003 env38830 = env38831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env38830 == env38831) = true)

def env38832 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243003,73754,21762,8272,65,215367,114966,91402,108926,61704,169313,256,41260,16464,120327]

theorem envBound38832 : H12AffineFastState.Bounded env38832 := by
  intro p hp
  have h : env38832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38831_38832 : H12AffineEnvironment.transform 6 88 env38831 = env38832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env38831 == env38832) = true)

theorem identity38832 : scanCanonicalize (H12AffineFastState.compose env38832 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound38832 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env38833 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,46108,64888,1024,32769,4160,65831,73754,21762,8272,65,130395,114966,91402,108926,61704,8573,256,41260,16464,120327]

theorem envBound38833 : H12AffineFastState.Bounded env38833 := by
  intro p hp
  have h : env38833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38832_38833 : H12AffineEnvironment.transform 16 46108 env38832 = env38833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env38832 == env38833) = true)

theorem identity38833 : scanCanonicalize (H12AffineFastState.compose env38833 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound38833 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env38834 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54278,46108,64888,1024,32769,4160,54561,62492,21762,8272,65,10589,5392,45324,32120,61704,8573,256,41260,16464,513]

theorem envBound38834 : H12AffineFastState.Bounded env38834 := by
  intro p hp
  have h : env38834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38833_38834 : H12AffineEnvironment.transform 15 54278 env38833 = env38834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env38833 == env38834) = true)

theorem identity38834 : scanCanonicalize (H12AffineFastState.compose env38834 (packedSelected [15,17,38] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound38834 : packedSelected [15,17,38] rootPS < 2^1333 := by decide +kernel

def env38835 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29709,8203,16401,2421,1024,29708,4160,8492,17,21762,8272,65,10589,5392,17665,32120,1285,8573,256,21793,16464,513]

theorem envBound38835 : H12AffineFastState.Bounded env38835 := by
  intro p hp
  have h : env38835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38834_38835 : H12AffineEnvironment.transform 14 29709 env38834 = env38835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env38834 == env38835) = true)

theorem identity38835 : scanCanonicalize (H12AffineFastState.compose env38835 (packedSelected [1,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound38835 : packedSelected [1,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env38836 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,120,16384,21621,115,16401,2421,1024,21620,4160,340,17,21762,40,65,2341,5392,17665,23808,1285,261,256,21793,16464,513]

theorem envBound38836 : H12AffineFastState.Bounded env38836 := by
  intro p hp
  have h : env38836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38835_38836 : H12AffineEnvironment.transform 12 120 env38835 = env38836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env38835 == env38836) = true)

theorem identity38836 : scanCanonicalize (H12AffineFastState.compose env38836 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound38836 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env38837 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,120,5157,80,115,5172,2421,1024,81,4160,340,17,295,40,65,2341,5392,4388,2341,1285,261,256,260,5237,513]

theorem envBound38837 : H12AffineFastState.Bounded env38837 := by
  intro p hp
  have h : env38837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38836_38837 : H12AffineEnvironment.transform 13 5157 env38836 = env38837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env38836 == env38837) = true)

theorem identity38837 : scanCanonicalize (H12AffineFastState.compose env38837 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38837 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env38838 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,120,5157,80,115,5172,2048,1024,81,4160,33,17,82,40,65,2128,5221,4177,2128,1136,112,117,113,5237,513]

theorem envBound38838 : H12AffineFastState.Bounded env38838 := by
  intro p hp
  have h : env38838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38837_38838 : H12AffineEnvironment.transform 7 117 env38837 = env38838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38837 == env38838) = true)

def env38839 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4112,33,17,2,40,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound38839 : H12AffineFastState.Bounded env38839 := by
  intro p hp
  have h : env38839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38838_38839 : H12AffineEnvironment.transform 5 16 env38838 = env38839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38838 == env38839) = true)

def env38840 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,0,35,1028,2048,1024,1,32,33,17,2,40,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound38840 : H12AffineFastState.Bounded env38840 := by
  intro p hp
  have h : env38840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38839_38840 : H12AffineEnvironment.transform 11 48 env38839 = env38840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38839 == env38840) = true)

theorem identity38840 : scanCanonicalize (H12AffineFastState.compose env38840 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound38840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38841 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,48,40,1045,0,35,1028,33,1024,1,32,33,17,2,40,17,33,1029,49,33,1056,32,37,33,1045,513]

theorem envBound38841 : H12AffineFastState.Bounded env38841 := by
  intro p hp
  have h : env38841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38840_38841 : H12AffineEnvironment.transform 10 33 env38840 = env38841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env38840 == env38841) = true)

def env38842 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,40,33,0,35,48,33,52,1,32,33,17,2,40,17,33,49,49,33,20,32,37,33,33,513]

theorem envBound38842 : H12AffineFastState.Bounded env38842 := by
  intro p hp
  have h : env38842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38841_38842 : H12AffineEnvironment.transform 9 52 env38841 = env38842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38841 == env38842) = true)

theorem identity38842 : scanCanonicalize (H12AffineFastState.compose env38842 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38842 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38843 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,48,40,33,0,35,48,33,52,1,32,33,17,2,40,17,33,49,49,33,20,32,37,33,33,43]

theorem envBound38843 : H12AffineFastState.Bounded env38843 := by
  intro p hp
  have h : env38843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38842_38843 : H12AffineEnvironment.transform 8 42 env38842 = env38843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38842 == env38843) = true)

def leafEnv38843 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,48,40,33,0,35,48,33,52,1,32,33,17,2,20,40,1,17,33,49,49,33,20,32,37,33,4,35,33,43,1,32,0]

def active38843 : List Nat := [0,1,2,3,4]

def tree38843 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38843 : H12WitnessSearch.Good tree38843 := H12GlobalWitnessIndex.good

theorem leafIdentity38843 : H12AffineFastState.composeSystem env38843 rootObs = leafEnv38843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38843 rootObs == leafEnv38843) = true)

theorem terminalChecked38843 : H12PackedTerminal.terminalCheckFast leafEnv38843 active38843 tree38843 = true := by decide +kernel

def env38844 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,40,32,0,35,49,33,53,1,32,33,17,2,40,17,33,48,49,33,21,32,37,33,32,513]

theorem envBound38844 : H12AffineFastState.Bounded env38844 := by
  intro p hp
  have h : env38844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38841_38844 : H12AffineEnvironment.transform 9 53 env38841 = env38844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38841 == env38844) = true)

def env38845 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,0,35,1029,2048,1024,1,33,33,17,2,40,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound38845 : H12AffineFastState.Bounded env38845 := by
  intro p hp
  have h : env38845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38839_38845 : H12AffineEnvironment.transform 11 49 env38839 = env38845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38839 == env38845) = true)

theorem identity38845 : scanCanonicalize (H12AffineFastState.compose env38845 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound38845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38846 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,49,40,1044,0,35,1029,1044,1024,1,33,33,17,2,40,17,1044,1028,48,1044,1056,32,37,33,1044,513]

theorem envBound38846 : H12AffineFastState.Bounded env38846 := by
  intro p hp
  have h : env38846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38845_38846 : H12AffineEnvironment.transform 10 1044 env38845 = env38846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env38845 == env38846) = true)

def env38847 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,40,32,0,35,49,32,52,1,33,33,17,2,40,17,32,48,48,32,20,32,37,33,32,513]

theorem envBound38847 : H12AffineFastState.Bounded env38847 := by
  intro p hp
  have h : env38847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38846_38847 : H12AffineEnvironment.transform 9 52 env38846 = env38847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38846 == env38847) = true)

theorem identity38847 : scanCanonicalize (H12AffineFastState.compose env38847 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38848 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,49,40,32,0,35,49,32,52,1,33,33,17,2,40,17,32,48,48,32,20,32,37,33,32,42]

theorem envBound38848 : H12AffineFastState.Bounded env38848 := by
  intro p hp
  have h : env38848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38847_38848 : H12AffineEnvironment.transform 8 43 env38847 = env38848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38847 == env38848) = true)

def leafEnv38848 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,49,40,32,0,35,49,32,52,1,33,33,17,2,20,40,1,17,32,48,48,32,20,32,37,33,4,35,32,42,1,33,0]

def active38848 : List Nat := [0,1,2,3,4]

def tree38848 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38848 : H12WitnessSearch.Good tree38848 := H12GlobalWitnessIndex.good

theorem leafIdentity38848 : H12AffineFastState.composeSystem env38848 rootObs = leafEnv38848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38848 rootObs == leafEnv38848) = true)

theorem terminalChecked38848 : H12PackedTerminal.terminalCheckFast leafEnv38848 active38848 tree38848 = true := by decide +kernel

def env38849 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,40,33,0,35,48,33,53,1,33,33,17,2,40,17,33,49,48,33,21,32,37,33,33,513]

theorem envBound38849 : H12AffineFastState.Bounded env38849 := by
  intro p hp
  have h : env38849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38846_38849 : H12AffineEnvironment.transform 9 53 env38846 = env38849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38846 == env38849) = true)

def env38850 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,34,5172,2048,1024,0,4113,33,17,3,40,16,2049,5172,4096,2049,1057,33,36,32,5156,513]

theorem envBound38850 : H12AffineFastState.Bounded env38850 := by
  intro p hp
  have h : env38850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38838_38850 : H12AffineEnvironment.transform 5 17 env38838 = env38850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38838 == env38850) = true)

theorem identity38850 : scanCanonicalize (H12AffineFastState.compose env38850 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38851 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,1,34,4097,2048,53,0,4113,33,17,3,40,16,2049,4097,4096,2049,20,33,36,32,4113,513]

theorem envBound38851 : H12AffineFastState.Bounded env38851 := by
  intro p hp
  have h : env38851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38850_38851 : H12AffineEnvironment.transform 9 53 env38850 = env38851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38850 == env38851) = true)

theorem identity38851 : scanCanonicalize (H12AffineFastState.compose env38851 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound38851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38852 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,33,41,49,1,34,32,2048,53,0,48,33,17,3,40,16,2049,32,33,2049,20,33,36,32,48,513]

theorem envBound38852 : H12AffineFastState.Bounded env38852 := by
  intro p hp
  have h : env38852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38851_38852 : H12AffineEnvironment.transform 11 33 env38851 = env38852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env38851 == env38852) = true)

theorem identity38852 : scanCanonicalize (H12AffineFastState.compose env38852 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound38852 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38853 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,41,49,1,34,32,49,53,0,48,33,17,3,40,16,48,32,33,48,20,33,36,32,48,513]

theorem envBound38853 : H12AffineFastState.Bounded env38853 := by
  intro p hp
  have h : env38853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38852_38853 : H12AffineEnvironment.transform 10 49 env38852 = env38853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env38852 == env38853) = true)

def leafEnv38853 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,41,49,1,34,32,49,53,0,48,33,17,3,20,40,1,16,48,32,33,48,20,33,36,32,4,35,48,513,1,49,0]

def active38853 : List Nat := [0,1,2,3,4,8]

def tree38853 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38853 : H12WitnessSearch.Good tree38853 := H12GlobalWitnessIndex.good

theorem leafIdentity38853 : H12AffineFastState.composeSystem env38853 rootObs = leafEnv38853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38853 rootObs == leafEnv38853) = true)

theorem terminalChecked38853 : H12PackedTerminal.terminalCheckFast leafEnv38853 active38853 tree38853 = true := by decide +kernel

def env38854 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243003,73754,21762,8273,65,215367,114967,91402,108926,61704,169312,256,41261,16464,120326]

theorem envBound38854 : H12AffineFastState.Bounded env38854 := by
  intro p hp
  have h : env38854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38831_38854 : H12AffineEnvironment.transform 6 89 env38831 = env38854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env38831 == env38854) = true)

theorem identity38854 : scanCanonicalize (H12AffineFastState.compose env38854 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38854 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env38855 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,0,65536,131072,149860,1024,1,4160,210235,73754,21762,8273,65,215367,82199,91402,76158,28936,136544,256,8493,16464,87558]

theorem envBound38855 : H12AffineFastState.Bounded env38855 := by
  intro p hp
  have h : env38855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38854_38855 : H12AffineEnvironment.transform 14 0 env38854 = env38855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38854 == env38855) = true)

theorem identity38855 : scanCanonicalize (H12AffineFastState.compose env38855 (packedSelected [0,9,10,16,17,18,20,22,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound38855 : packedSelected [0,9,10,16,17,18,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env38856 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,0,21590,131072,149860,1024,1,4160,156013,29772,21762,8273,65,138513,5441,12636,32040,28936,136544,256,8493,16464,592]

theorem envBound38856 : H12AffineFastState.Bounded env38856 := by
  intro p hp
  have h : env38856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38855_38856 : H12AffineEnvironment.transform 15 21590 env38855 = env38856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env38855 == env38856) = true)

theorem identity38856 : scanCanonicalize (H12AffineFastState.compose env38856 (packedSelected [0,1,2,6,7,8,12,15,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound38856 : packedSelected [0,1,2,6,7,8,12,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env38857 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,0,21590,13340,32120,1024,1,4160,21873,29772,21762,8273,65,10509,5441,12636,32040,28936,8572,256,8493,16464,592]

theorem envBound38857 : H12AffineFastState.Bounded env38857 := by
  intro p hp
  have h : env38857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38856_38857 : H12AffineEnvironment.transform 16 13340 env38856 = env38857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env38856 == env38857) = true)

theorem identity38857 : scanCanonicalize (H12AffineFastState.compose env38857 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound38857 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env38858 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13325,0,8283,13340,2421,1024,1,4160,8572,65,8463,8273,65,10509,5441,12636,2341,1285,8572,256,8493,13405,592]

theorem envBound38858 : H12AffineFastState.Bounded env38858 := by
  intro p hp
  have h : env38858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38857_38858 : H12AffineEnvironment.transform 13 13325 env38857 = env38858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env38857 == env38858) = true)

theorem identity38858 : scanCanonicalize (H12AffineFastState.compose env38858 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound38858 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env38859 : List Nat := [2,4,8,16,32,64,89,256,512,298,2048,4096,8192,12583,0,8283,12598,2421,298,1,4160,8572,65,8463,8273,65,10509,4203,12636,2341,47,8572,256,8493,12663,592]

theorem envBound38859 : H12AffineFastState.Bounded env38859 := by
  intro p hp
  have h : env38859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38858_38859 : H12AffineEnvironment.transform 9 298 env38858 = env38859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env38858 == env38859) = true)

theorem identity38859 : scanCanonicalize (H12AffineFastState.compose env38859 (packedSelected [0,2,3,4,5,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound38859 : packedSelected [0,2,3,4,5,10,11,14] rootPS < 2^1333 := by decide +kernel

def env38860 : List Nat := [2,4,8,16,32,64,89,256,512,298,2048,2603,8192,11020,0,8283,11037,2421,298,1,2667,8572,65,8463,8273,65,10509,2624,11127,2341,47,8572,256,8493,11100,592]

theorem envBound38860 : H12AffineFastState.Bounded env38860 := by
  intro p hp
  have h : env38860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38859_38860 : H12AffineEnvironment.transform 11 2603 env38859 = env38860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env38859 == env38860) = true)

theorem identity38860 : scanCanonicalize (H12AffineFastState.compose env38860 (packedSelected [0,1,2,3,4,5,8,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound38860 : packedSelected [0,1,2,3,4,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env38861 : List Nat := [2,4,8,16,32,64,89,256,75,298,2048,2144,8192,10567,0,8283,10582,2421,298,1,2080,8572,65,8463,8273,65,10509,2059,10556,2341,47,8572,256,8493,10519,27]

theorem envBound38861 : H12AffineFastState.Bounded env38861 := by
  intro p hp
  have h : env38861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38860_38861 : H12AffineEnvironment.transform 8 75 env38860 = env38861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env38860 == env38861) = true)

theorem identity38861 : scanCanonicalize (H12AffineFastState.compose env38861 (packedSelected [0,1,4,5,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2333) := by decide +kernel

theorem selectedBound38861 : packedSelected [0,1,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env38862 : List Nat := [2,4,8,16,32,64,89,256,75,298,2048,2144,2333,90,0,2374,75,2421,298,1,2080,2145,65,2066,2380,65,16,2059,33,2341,47,2145,256,2096,10,27]

theorem envBound38862 : H12AffineFastState.Bounded env38862 := by
  intro p hp
  have h : env38862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38861_38862 : H12AffineEnvironment.transform 12 2333 env38861 = env38862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2333 env38861 == env38862) = true)

theorem identity38862 : scanCanonicalize (H12AffineFastState.compose env38862 (packedSelected [17] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound38862 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38863 : List Nat := [2,4,8,16,32,64,89,256,75,298,64,32,349,90,0,262,75,309,298,1,96,33,65,82,268,65,16,75,33,357,47,33,256,112,10,27]

theorem envBound38863 : H12AffineFastState.Bounded env38863 := by
  intro p hp
  have h : env38863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38862_38863 : H12AffineEnvironment.transform 10 64 env38862 = env38863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env38862 == env38863) = true)

theorem identity38863 : scanCanonicalize (H12AffineFastState.compose env38863 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound38863 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env38864 : List Nat := [2,4,8,16,32,64,89,85,75,127,64,32,8,90,0,83,75,96,127,1,96,33,65,82,89,65,16,75,33,48,47,33,85,112,10,27]

theorem envBound38864 : H12AffineFastState.Bounded env38864 := by
  intro p hp
  have h : env38864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38863_38864 : H12AffineEnvironment.transform 7 85 env38863 = env38864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env38863 == env38864) = true)

def env38865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,8388608,21763,8328,65,12704871,115150,8406289,8423780,8507667,4268162,256,8487406,8478794,8451780]

theorem envBound38865 : H12AffineFastState.Bounded env38865 := by
  intro p hp
  have h : env38865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38817_38865 : H12AffineEnvironment.transform 20 4161 env38817 = env38865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38817 == env38865) = true)

def env38866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363552,21763,8328,65,215367,115150,4378673,4332612,4408371,4268162,256,4396238,4453738,4350948]

theorem envBound38866 : H12AffineFastState.Bounded env38866 := by
  intro p hp
  have h : env38866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38865_38866 : H12AffineEnvironment.transform 22 4363552 env38865 = env38866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env38865 == env38866) = true)

theorem identity38866 : scanCanonicalize (H12AffineFastState.compose env38866 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound38866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149860,1024,32769,4161,4194304,4363552,21763,8328,65,171416,5393,4378673,4332612,4362476,4256861,256,4374545,4334005,4350948]

theorem envBound38867 : H12AffineFastState.Bounded env38867 := by
  intro p hp
  have h : env38867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38866_38867 : H12AffineEnvironment.transform 15 54495 env38866 = env38867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env38866 == env38867) = true)

def env38868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149860,1024,32769,4161,169400,152,21763,8328,65,171416,5393,17801,35324,1364,156133,256,21929,46093,63068]

theorem envBound38868 : H12AffineFastState.Bounded env38868 := by
  intro p hp
  have h : env38868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38867_38868 : H12AffineEnvironment.transform 21 169400 env38867 = env38868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env38867 == env38868) = true)

theorem identity38868 : scanCanonicalize (H12AffineFastState.compose env38868 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound38868 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env38869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46277,64929,1024,32769,4161,8573,152,21763,8328,65,10589,5393,17801,35324,1364,54560,256,21929,46093,63068]

theorem envBound38869 : H12AffineFastState.Bounded env38869 := by
  intro p hp
  have h : env38869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38868_38869 : H12AffineEnvironment.transform 16 46277 env38868 = env38869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env38868 == env38869) = true)

def env38870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46157,64809,1024,32769,4161,8573,16,21763,8192,65,10589,5393,17665,35188,1364,54560,256,21793,46093,63068]

theorem envBound38870 : H12AffineFastState.Bounded env38870 := by
  intro p hp
  have h : env38870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38869_38870 : H12AffineEnvironment.transform 6 8 env38869 = env38870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38869 == env38870) = true)

theorem identity38870 : scanCanonicalize (H12AffineFastState.compose env38870 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound38870 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,342,24908,10280,1024,21760,4161,8573,16,21763,8192,65,10589,5393,17665,23669,1364,33,256,21793,24844,9053]

theorem envBound38871 : H12AffineFastState.Bounded env38871 := by
  intro p hp
  have h : env38871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38870_38871 : H12AffineEnvironment.transform 14 21761 env38870 = env38871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38870 == env38871) = true)

theorem identity38871 : scanCanonicalize (H12AffineFastState.compose env38871 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38871 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env38872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,16400,2420,1024,21760,4161,33,16,21763,348,65,2049,5393,17665,23669,1364,33,256,21793,16464,513]

theorem envBound38872 : H12AffineFastState.Bounded env38872 := by
  intro p hp
  have h : env38872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38871_38872 : H12AffineEnvironment.transform 12 348 env38871 = env38872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38871 == env38872) = true)

theorem identity38872 : scanCanonicalize (H12AffineFastState.compose env38872 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38872 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38873 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,263,16400,2341,1024,21760,4112,33,16,21763,269,16,2049,5393,17665,23588,1285,33,256,21793,16385,513]

theorem envBound38873 : H12AffineFastState.Bounded env38873 := by
  intro p hp
  have h : env38873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38872_38873 : H12AffineEnvironment.transform 5 17 env38872 = env38873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38872 == env38873) = true)

theorem identity38873 : scanCanonicalize (H12AffineFastState.compose env38873 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3857) := by decide +kernel

theorem selectedBound38873 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38874 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3857,269,16384,18960,263,16400,2341,1024,18961,3841,33,16,18962,269,16,2049,2560,17665,17205,1285,33,256,18992,16385,513]

theorem envBound38874 : H12AffineFastState.Bounded env38874 := by
  intro p hp
  have h : env38874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38873_38874 : H12AffineEnvironment.transform 11 3857 env38873 = env38874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3857 env38873 == env38874) = true)

theorem identity38874 : scanCanonicalize (H12AffineFastState.compose env38874 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound38874 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env38875 : List Nat := [2,4,8,16,32,17,8,256,512,516,2048,2325,269,16384,18960,263,16400,2341,516,18961,2309,33,16,18962,269,16,2049,2560,17157,17205,769,33,256,18992,16385,513]

theorem envBound38875 : H12AffineFastState.Bounded env38875 := by
  intro p hp
  have h : env38875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38874_38875 : H12AffineEnvironment.transform 9 516 env38874 = env38875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env38874 == env38875) = true)

theorem identity38875 : scanCanonicalize (H12AffineFastState.compose env38875 (packedSelected [0,2,9] rootPS)) = affineNative (2^(13+1) ^^^ 2357) := by decide +kernel

theorem selectedBound38875 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env38876 : List Nat := [2,4,8,16,32,17,8,256,512,516,2048,2325,269,2357,805,263,2341,2341,516,804,2309,33,16,807,269,16,2049,2560,2608,2560,769,33,256,773,2356,513]

theorem envBound38876 : H12AffineFastState.Bounded env38876 := by
  intro p hp
  have h : env38876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38875_38876 : H12AffineEnvironment.transform 13 2357 env38875 = env38876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2357 env38875 == env38876) = true)

theorem identity38876 : scanCanonicalize (H12AffineFastState.compose env38876 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound38876 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env38877 : List Nat := [2,4,8,16,32,17,8,256,292,288,2048,2325,269,2357,1,263,2341,2341,288,0,2309,33,16,3,269,16,2049,2340,2324,2340,37,33,256,33,2356,293]

theorem envBound38877 : H12AffineFastState.Bounded env38877 := by
  intro p hp
  have h : env38877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38876_38877 : H12AffineEnvironment.transform 8 292 env38876 = env38877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env38876 == env38877) = true)

theorem identity38877 : scanCanonicalize (H12AffineFastState.compose env38877 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound38877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38878 : List Nat := [2,4,8,16,32,17,8,256,292,288,292,49,269,17,1,263,1,1,288,0,33,33,16,3,269,16,293,0,48,0,37,33,256,33,16,293]

theorem envBound38878 : H12AffineFastState.Bounded env38878 := by
  intro p hp
  have h : env38878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38877_38878 : H12AffineEnvironment.transform 10 292 env38877 = env38878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env38877 == env38878) = true)

def env38879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46156,64808,1024,32769,4161,8573,17,21763,8193,65,10589,5393,17664,35189,1364,54560,256,21792,46093,63068]

theorem envBound38879 : H12AffineFastState.Bounded env38879 := by
  intro p hp
  have h : env38879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38869_38879 : H12AffineEnvironment.transform 6 9 env38869 = env38879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38869 == env38879) = true)

theorem identity38879 : scanCanonicalize (H12AffineFastState.compose env38879 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,5393,23669,1024,8540,4161,8573,17,21763,8193,65,10589,5393,17664,10280,1364,29821,256,21792,5456,22273]

theorem envBound38880 : H12AffineFastState.Bounded env38880 := by
  intro p hp
  have h : env38880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38879_38880 : H12AffineEnvironment.transform 14 8541 env38879 = env38880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38879 == env38880) = true)

theorem identity38880 : scanCanonicalize (H12AffineFastState.compose env38880 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38880 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5393,2421,1024,8540,4161,8573,17,3,8193,65,10589,5393,4096,10280,1364,8573,256,32,5456,513]

theorem envBound38881 : H12AffineFastState.Bounded env38881 := by
  intro p hp
  have h : env38881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38880_38881 : H12AffineEnvironment.transform 13 5376 env38880 = env38881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38880 == env38881) = true)

theorem identity38881 : scanCanonicalize (H12AffineFastState.compose env38881 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38881 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2421,1024,0,4161,33,17,3,349,65,2049,5393,4096,2420,1364,33,256,32,5456,513]

theorem envBound38882 : H12AffineFastState.Bounded env38882 := by
  intro p hp
  have h : env38882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38881_38882 : H12AffineEnvironment.transform 12 348 env38881 = env38882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38881 == env38882) = true)

theorem identity38882 : scanCanonicalize (H12AffineFastState.compose env38882 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38882 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38883 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,262,5393,2340,1024,0,4112,33,17,3,268,16,2049,5393,4096,2341,1285,33,256,32,5377,513]

theorem envBound38883 : H12AffineFastState.Bounded env38883 := by
  intro p hp
  have h : env38883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38882_38883 : H12AffineEnvironment.transform 5 17 env38882 = env38883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38882 == env38883) = true)

theorem identity38883 : scanCanonicalize (H12AffineFastState.compose env38883 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38883 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38884 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,1,262,4096,2340,273,0,4112,33,17,3,268,16,2049,4096,4096,2341,20,33,256,32,4112,513]

theorem envBound38884 : H12AffineFastState.Bounded env38884 := by
  intro p hp
  have h : env38884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38883_38884 : H12AffineEnvironment.transform 9 273 env38883 = env38884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38883 == env38884) = true)

theorem identity38884 : scanCanonicalize (H12AffineFastState.compose env38884 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound38884 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38885 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2064,269,2049,1,262,2064,2340,273,0,2048,33,17,3,268,16,2049,2064,2064,2341,20,33,256,32,2048,513]

theorem envBound38885 : H12AffineFastState.Bounded env38885 := by
  intro p hp
  have h : env38885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38884_38885 : H12AffineEnvironment.transform 11 2064 env38884 = env38885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env38884 == env38885) = true)

theorem identity38885 : scanCanonicalize (H12AffineFastState.compose env38885 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38885 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38886 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,41,2049,1,34,2064,2048,53,0,2048,33,17,3,40,16,2049,2064,2064,2049,20,33,36,32,2048,513]

theorem envBound38886 : H12AffineFastState.Bounded env38886 := by
  intro p hp
  have h : env38886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38885_38886 : H12AffineEnvironment.transform 7 36 env38885 = env38886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38885 == env38886) = true)

theorem identity38886 : scanCanonicalize (H12AffineFastState.compose env38886 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38887 : List Nat := [2,4,8,11,32,10,9,36,512,46,2048,2059,41,2049,1,34,2059,2048,46,0,2048,33,10,3,40,11,2049,2059,2059,2049,15,33,36,32,2048,513]

theorem envBound38887 : H12AffineFastState.Bounded env38887 := by
  intro p hp
  have h : env38887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38886_38887 : H12AffineEnvironment.transform 3 11 env38886 = env38887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38886 == env38887) = true)

def env38888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149860,1024,32769,4161,169401,153,21763,8328,65,171416,5393,17800,35325,1365,156132,256,21928,46092,63069]

theorem envBound38888 : H12AffineFastState.Bounded env38888 := by
  intro p hp
  have h : env38888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38867_38888 : H12AffineEnvironment.transform 21 169401 env38867 = env38888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env38867 == env38888) = true)

theorem identity38888 : scanCanonicalize (H12AffineFastState.compose env38888 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound38888 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env38889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33166,131072,138293,1024,32769,4161,169401,153,82,8328,65,171416,5393,4313,35325,1365,144565,256,249,46092,41740]

theorem envBound38889 : H12AffineFastState.Bounded env38889 := by
  intro p hp
  have h : env38889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38888_38889 : H12AffineEnvironment.transform 13 5457 env38888 = env38889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env38888 == env38889) = true)

theorem identity38889 : scanCanonicalize (H12AffineFastState.compose env38889 (packedSelected [0,1,4,7,18,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound38889 : packedSelected [0,1,4,7,18,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33166,46157,43128,1024,32769,4161,8692,153,82,8328,65,10709,5393,4313,35325,1365,33016,256,249,46092,41740]

theorem envBound38890 : H12AffineFastState.Bounded env38890 := by
  intro p hp
  have h : env38890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38889_38890 : H12AffineEnvironment.transform 16 46157 env38889 = env38890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env38889 == env38890) = true)

theorem identity38890 : scanCanonicalize (H12AffineFastState.compose env38890 (packedSelected [1,4,5,7,8,9,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound38890 : packedSelected [1,4,5,7,8,9,24,27] rootPS < 2^1333 := by decide +kernel

def env38891 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,32768,33110,46157,43128,1024,32769,4161,8492,65,82,8272,65,10509,5393,4097,35109,1365,32800,256,33,46092,41740]

theorem envBound38891 : H12AffineFastState.Bounded env38891 := by
  intro p hp
  have h : env38891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38890_38891 : H12AffineEnvironment.transform 6 88 env38890 = env38891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env38890 == env38891) = true)

theorem identity38891 : scanCanonicalize (H12AffineFastState.compose env38891 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38891 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env38892 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8541,8203,5392,2341,1024,8540,4161,8492,65,82,8272,65,10509,5393,4097,10360,1365,8573,256,33,5457,593]

theorem envBound38892 : H12AffineFastState.Bounded env38892 := by
  intro p hp
  have h : env38892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38891_38892 : H12AffineEnvironment.transform 14 8541 env38891 = env38892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38891 == env38892) = true)

theorem identity38892 : scanCanonicalize (H12AffineFastState.compose env38892 (packedSelected [0,4,7,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38892 : packedSelected [0,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env38893 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,5392,2341,1024,8460,4113,8492,17,2,8192,17,10509,5393,4097,10280,1285,8493,256,33,5377,513]

theorem envBound38893 : H12AffineFastState.Bounded env38893 := by
  intro p hp
  have h : env38893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38892_38893 : H12AffineEnvironment.transform 5 16 env38892 = env38893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38892 == env38893) = true)

theorem identity38893 : scanCanonicalize (H12AffineFastState.compose env38893 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38894 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8233,8203,5172,2049,1024,8232,4113,8200,17,2,8192,17,10281,5173,4097,10280,1057,8201,36,33,5157,513]

theorem envBound38894 : H12AffineFastState.Bounded env38894 := by
  intro p hp
  have h : env38894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38893_38894 : H12AffineEnvironment.transform 7 36 env38893 = env38894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38893 == env38894) = true)

theorem identity38894 : scanCanonicalize (H12AffineFastState.compose env38894 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38894 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38895 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5172,2049,1024,1,4113,33,17,2,41,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound38895 : H12AffineFastState.Bounded env38895 := by
  intro p hp
  have h : env38895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38894_38895 : H12AffineEnvironment.transform 12 41 env38894 = env38895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38894 == env38895) = true)

def env38896 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,0,34,1028,2049,1024,1,33,33,17,2,41,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound38896 : H12AffineFastState.Bounded env38896 := by
  intro p hp
  have h : env38896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38895_38896 : H12AffineEnvironment.transform 11 48 env38895 = env38896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38895 == env38896) = true)

theorem identity38896 : scanCanonicalize (H12AffineFastState.compose env38896 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound38896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38897 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,48,41,528,0,34,513,2049,517,1,33,33,17,2,41,17,2048,512,49,2049,548,32,36,33,528,513]

theorem envBound38897 : H12AffineFastState.Bounded env38897 := by
  intro p hp
  have h : env38897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38896_38897 : H12AffineEnvironment.transform 9 517 env38896 = env38897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env38896 == env38897) = true)

def env38898 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,41,32,0,34,49,2049,53,1,33,33,17,2,41,17,2048,48,49,2049,20,32,36,33,32,49]

theorem envBound38898 : H12AffineFastState.Bounded env38898 := by
  intro p hp
  have h : env38898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38897_38898 : H12AffineEnvironment.transform 8 48 env38897 = env38898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38897 == env38898) = true)

def env38899 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,41,33,0,34,48,2049,52,1,33,33,17,2,41,17,2048,49,49,2049,21,32,36,33,33,48]

theorem envBound38899 : H12AffineFastState.Bounded env38899 := by
  intro p hp
  have h : env38899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38897_38899 : H12AffineEnvironment.transform 8 49 env38897 = env38899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38897 == env38899) = true)

theorem identity38899 : scanCanonicalize (H12AffineFastState.compose env38899 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38900 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,42,41,33,0,34,42,2049,46,1,33,33,11,2,41,11,2048,43,43,2049,15,32,36,33,33,42]

theorem envBound38900 : H12AffineFastState.Bounded env38900 := by
  intro p hp
  have h : env38900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38899_38900 : H12AffineEnvironment.transform 3 10 env38899 = env38900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38899 == env38900) = true)

def leafEnv38900 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,42,41,33,0,34,42,2049,46,1,33,33,11,2,15,41,1,11,2048,43,43,2049,15,32,36,33,4,34,33,42,1,33,0]

def active38900 : List Nat := [0,1,2,4,10]

def tree38900 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38900 : H12WitnessSearch.Good tree38900 := H12GlobalWitnessIndex.good

theorem leafIdentity38900 : H12AffineFastState.composeSystem env38900 rootObs = leafEnv38900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38900 rootObs == leafEnv38900) = true)

theorem terminalChecked38900 : H12PackedTerminal.terminalCheckFast leafEnv38900 active38900 tree38900 = true := by decide +kernel

def env38901 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,0,34,1029,2049,1024,1,32,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound38901 : H12AffineFastState.Bounded env38901 := by
  intro p hp
  have h : env38901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38895_38901 : H12AffineEnvironment.transform 11 49 env38895 = env38901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38895 == env38901) = true)

theorem identity38901 : scanCanonicalize (H12AffineFastState.compose env38901 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound38901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38902 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,49,41,1044,0,34,1029,2049,1024,1,32,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,49]

theorem envBound38902 : H12AffineFastState.Bounded env38902 := by
  intro p hp
  have h : env38902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38901_38902 : H12AffineEnvironment.transform 8 48 env38901 = env38902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38901 == env38902) = true)

def env38903 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,41,32,0,34,49,2049,52,1,32,33,17,2,41,17,2048,48,48,2049,21,32,36,33,32,49]

theorem envBound38903 : H12AffineFastState.Bounded env38903 := by
  intro p hp
  have h : env38903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38902_38903 : H12AffineEnvironment.transform 9 52 env38902 = env38903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38902 == env38903) = true)

theorem identity38903 : scanCanonicalize (H12AffineFastState.compose env38903 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38904 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,43,41,32,0,34,43,2049,46,1,32,33,11,2,41,11,2048,42,42,2049,15,32,36,33,32,43]

theorem envBound38904 : H12AffineFastState.Bounded env38904 := by
  intro p hp
  have h : env38904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38903_38904 : H12AffineEnvironment.transform 3 10 env38903 = env38904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38903 == env38904) = true)

def leafEnv38904 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,43,41,32,0,34,43,2049,46,1,32,33,11,2,15,41,1,11,2048,42,42,2049,15,32,36,33,4,34,32,43,1,32,0]

def active38904 : List Nat := [0,1,2,4,10]

def tree38904 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38904 : H12WitnessSearch.Good tree38904 := H12GlobalWitnessIndex.good

theorem leafIdentity38904 : H12AffineFastState.composeSystem env38904 rootObs = leafEnv38904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38904 rootObs == leafEnv38904) = true)

theorem terminalChecked38904 : H12PackedTerminal.terminalCheckFast leafEnv38904 active38904 tree38904 = true := by decide +kernel

def env38905 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,41,33,0,34,48,2049,53,1,32,33,17,2,41,17,2048,49,48,2049,20,32,36,33,33,49]

theorem envBound38905 : H12AffineFastState.Bounded env38905 := by
  intro p hp
  have h : env38905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38902_38905 : H12AffineEnvironment.transform 9 53 env38902 = env38905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38902 == env38905) = true)

def env38906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363553,21763,8328,65,215366,115150,4378672,4332613,4408370,4268162,256,4396239,4453739,4350949]

theorem envBound38906 : H12AffineFastState.Bounded env38906 := by
  intro p hp
  have h : env38906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38865_38906 : H12AffineEnvironment.transform 22 4363553 env38865 = env38906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env38865 == env38906) = true)

theorem identity38906 : scanCanonicalize (H12AffineFastState.compose env38906 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound38906 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,213486,120015,21763,8328,65,215366,115150,102878,89515,1500,156012,256,21793,46213,74251]

theorem envBound38907 : H12AffineFastState.Bounded env38907 := by
  intro p hp
  have h : env38907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38906_38907 : H12AffineEnvironment.transform 21 213486 env38906 = env38907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env38906 == env38907) = true)

def env38908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10400,1024,32769,4161,73770,120015,21763,8328,65,75906,115150,102878,89515,1500,168,256,21793,46213,74251]

theorem envBound38908 : H12AffineFastState.Bounded env38908 := by
  intro p hp
  have h : env38908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_38908 : H12AffineEnvironment.transform 16 25028 env38907 = env38908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env38907 == env38908) = true)

theorem identity38908 : scanCanonicalize (H12AffineFastState.compose env38908 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound38908 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env38909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,25028,10400,1024,32769,4161,54560,8645,21763,8328,65,56712,13508,25812,43169,1500,168,256,21793,46213,55041]

theorem envBound38909 : H12AffineFastState.Bounded env38909 := by
  intro p hp
  have h : env38909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38908_38909 : H12AffineEnvironment.transform 15 62730 env38908 = env38909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env38908 == env38909) = true)

theorem identity38909 : scanCanonicalize (H12AffineFastState.compose env38909 (packedSelected [0,2,3,6,8,12,14,15,18,19,24,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound38909 : packedSelected [0,2,3,6,8,12,14,15,18,19,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env38910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,33246,5392,10400,1024,32769,4161,41460,8645,8663,8328,65,43356,13508,4096,43169,1500,168,256,8693,46213,41941]

theorem envBound38910 : H12AffineFastState.Bounded env38910 := by
  intro p hp
  have h : env38910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38909_38910 : H12AffineEnvironment.transform 13 13524 env38909 = env38910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env38909 == env38910) = true)

theorem identity38910 : scanCanonicalize (H12AffineFastState.compose env38910 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38910 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env38911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8541,8323,5392,10400,1024,8540,4161,169,8645,8663,8328,65,2049,13508,4096,2556,1500,168,256,8693,5592,648]

theorem envBound38911 : H12AffineFastState.Bounded env38911 := by
  intro p hp
  have h : env38911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38910_38911 : H12AffineEnvironment.transform 14 8541 env38910 = env38911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38910 == env38911) = true)

theorem identity38911 : scanCanonicalize (H12AffineFastState.compose env38911 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38911 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,478,5392,2557,1024,1,4161,169,152,138,469,65,2049,5529,4096,2556,1500,168,256,168,5592,648]

theorem envBound38912 : H12AffineFastState.Bounded env38912 := by
  intro p hp
  have h : env38912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38911_38912 : H12AffineEnvironment.transform 12 349 env38911 = env38912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38911 == env38912) = true)

theorem identity38912 : scanCanonicalize (H12AffineFastState.compose env38912 (packedSelected [2,3,5,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound38912 : packedSelected [2,3,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38913 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,349,4589,0,478,4468,2557,100,1,4161,169,152,138,469,65,2049,4605,4096,2556,440,168,256,168,4540,648]

theorem envBound38913 : H12AffineFastState.Bounded env38913 := by
  intro p hp
  have h : env38913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38912_38913 : H12AffineEnvironment.transform 9 100 env38912 = env38913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env38912 == env38913) = true)

theorem identity38913 : scanCanonicalize (H12AffineFastState.compose env38913 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound38913 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env38914 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2493,349,2128,0,478,2249,2557,100,1,2556,169,152,138,469,65,2049,2112,2493,2556,440,168,256,168,2049,648]

theorem envBound38914 : H12AffineFastState.Bounded env38914 := by
  intro p hp
  have h : env38914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38913_38914 : H12AffineEnvironment.transform 11 2493 env38913 = env38914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env38913 == env38914) = true)

theorem identity38914 : scanCanonicalize (H12AffineFastState.compose env38914 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound38914 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38915 : List Nat := [2,4,8,16,32,64,128,252,512,100,2048,2113,161,2128,0,34,2249,2049,100,1,2048,169,152,138,41,65,2049,2112,2113,2048,68,168,252,168,2049,648]

theorem envBound38915 : H12AffineFastState.Bounded env38915 := by
  intro p hp
  have h : env38915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38914_38915 : H12AffineEnvironment.transform 7 252 env38914 = env38915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env38914 == env38915) = true)

theorem identity38915 : scanCanonicalize (H12AffineFastState.compose env38915 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38915 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38916 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,2065,161,2048,0,34,2201,2049,52,1,2048,169,152,138,41,17,2049,2064,2065,2048,20,168,172,168,2049,648]

theorem envBound38916 : H12AffineFastState.Bounded env38916 := by
  intro p hp
  have h : env38916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38915_38916 : H12AffineEnvironment.transform 5 16 env38915 = env38916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38915 == env38916) = true)

theorem identity38916 : scanCanonicalize (H12AffineFastState.compose env38916 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38916 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38917 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,41,2048,0,34,2065,2049,52,1,2048,33,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2049,512]

theorem envBound38917 : H12AffineFastState.Bounded env38917 := by
  intro p hp
  have h : env38917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38916_38917 : H12AffineEnvironment.transform 6 8 env38916 = env38917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38916 == env38917) = true)

theorem identity38917 : scanCanonicalize (H12AffineFastState.compose env38917 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound38917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38918 : List Nat := [2,4,8,16,20,16,8,16,512,0,2048,2065,29,2048,0,22,2065,2049,0,1,2048,21,16,2,29,17,2049,2064,2065,2048,20,20,16,20,2049,512]

theorem envBound38918 : H12AffineFastState.Bounded env38918 := by
  intro p hp
  have h : env38918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38917_38918 : H12AffineEnvironment.transform 4 20 env38917 = env38918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env38917 == env38918) = true)

theorem identity38918 : scanCanonicalize (H12AffineFastState.compose env38918 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound38918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38919 : List Nat := [2,4,8,16,20,16,8,16,512,0,525,540,29,525,0,22,540,524,0,1,525,21,16,2,29,17,524,541,540,525,20,20,16,20,524,512]

theorem envBound38919 : H12AffineFastState.Bounded env38919 := by
  intro p hp
  have h : env38919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38918_38919 : H12AffineEnvironment.transform 10 525 env38918 = env38919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env38918 == env38919) = true)

theorem identity38919 : scanCanonicalize (H12AffineFastState.compose env38919 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound38919 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38920 : List Nat := [2,4,8,5,1,5,8,5,512,0,525,521,8,525,0,3,521,524,0,1,525,0,5,2,8,4,524,520,521,525,1,1,5,1,524,512]

theorem envBound38920 : H12AffineFastState.Bounded env38920 := by
  intro p hp
  have h : env38920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38919_38920 : H12AffineEnvironment.transform 3 5 env38919 = env38920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env38919 == env38920) = true)

theorem identity38920 : scanCanonicalize (H12AffineFastState.compose env38920 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38920 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38921 : List Nat := [2,2,8,3,1,3,8,3,512,0,523,521,8,523,0,3,521,522,0,1,523,0,3,2,8,2,522,520,521,523,1,1,3,1,522,512]

theorem envBound38921 : H12AffineFastState.Bounded env38921 := by
  intro p hp
  have h : env38921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38920_38921 : H12AffineEnvironment.transform 1 2 env38920 = env38921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38920 == env38921) = true)

def env38922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10401,1024,32769,4161,73771,120015,21763,8328,65,75907,115150,102878,89515,1500,169,256,21793,46213,74251]

theorem envBound38922 : H12AffineFastState.Bounded env38922 := by
  intro p hp
  have h : env38922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_38922 : H12AffineEnvironment.transform 16 25029 env38907 = env38922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env38907 == env38922) = true)

theorem identity38922 : scanCanonicalize (H12AffineFastState.compose env38922 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound38922 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env38923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62591,25029,10401,1024,32769,4161,54356,8368,21763,8328,65,56572,13745,26017,43476,1500,169,256,21793,46213,54900]

theorem envBound38923 : H12AffineFastState.Bounded env38923 := by
  intro p hp
  have h : env38923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38922_38923 : H12AffineEnvironment.transform 15 62591 env38922 = env38923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env38922 == env38923) = true)

theorem identity38923 : scanCanonicalize (H12AffineFastState.compose env38923 (packedSelected [1,2,3,5,12,14,15,18,26,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound38923 : packedSelected [1,2,3,5,12,14,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env38924 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,62591,24860,10360,1024,32769,4161,54356,8297,21763,8273,65,56357,13672,25976,43277,1285,112,256,21793,46172,54900]

theorem envBound38924 : H12AffineFastState.Bounded env38924 := by
  intro p hp
  have h : env38924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38923_38924 : H12AffineEnvironment.transform 6 89 env38923 = env38924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env38923 == env38924) = true)

theorem identity38924 : scanCanonicalize (H12AffineFastState.compose env38924 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound38924 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env38925 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21620,8203,24860,10360,1024,21621,4161,32,8297,21763,8273,65,2129,13672,25976,32121,1285,112,256,21793,24616,512]

theorem envBound38925 : H12AffineFastState.Bounded env38925 := by
  intro p hp
  have h : env38925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38924_38925 : H12AffineEnvironment.transform 14 21620 env38924 = env38925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env38924 == env38925) = true)

theorem identity38925 : scanCanonicalize (H12AffineFastState.compose env38925 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38925 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env38926 : List Nat := [2,4,8,16,32,64,89,4,512,1024,2048,4096,8192,16384,21620,8203,24600,10360,1024,21621,4161,32,8297,21511,8273,65,2129,13420,25724,31869,1025,112,4,21541,24616,512]

theorem envBound38926 : H12AffineFastState.Bounded env38926 := by
  intro p hp
  have h : env38926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38925_38926 : H12AffineEnvironment.transform 7 4 env38925 = env38926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38925 == env38926) = true)

theorem identity38926 : scanCanonicalize (H12AffineFastState.compose env38926 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38926 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env38927 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8192,16384,21541,8203,24600,10281,1024,21540,4112,32,8248,21511,8192,16,2048,13373,25645,31788,1025,33,4,21541,24616,512]

theorem envBound38927 : H12AffineFastState.Bounded env38927 := by
  intro p hp
  have h : env38927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38926_38927 : H12AffineEnvironment.transform 5 17 env38926 = env38927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38926 == env38927) = true)

theorem identity38927 : scanCanonicalize (H12AffineFastState.compose env38927 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38927 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38928 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,41,16384,21541,34,16433,2048,1024,21540,4112,32,17,21511,41,16,2048,5140,17412,23557,1025,33,4,21541,16385,512]

theorem envBound38928 : H12AffineFastState.Bounded env38928 := by
  intro p hp
  have h : env38928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38927_38928 : H12AffineEnvironment.transform 12 41 env38927 = env38928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38927 == env38928) = true)

theorem identity38928 : scanCanonicalize (H12AffineFastState.compose env38928 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound38928 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38929 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,41,4145,1044,34,4096,2048,1024,1045,4112,32,17,1078,41,16,2048,5140,5173,3124,1025,33,4,1044,4144,512]

theorem envBound38929 : H12AffineFastState.Bounded env38929 := by
  intro p hp
  have h : env38929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38928_38929 : H12AffineEnvironment.transform 13 4145 env38928 = env38929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env38928 == env38929) = true)

theorem identity38929 : scanCanonicalize (H12AffineFastState.compose env38929 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound38929 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env38930 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2097,41,2048,1044,34,2097,2048,1024,1045,2081,32,17,1078,41,16,2048,3109,3076,3124,1025,33,4,1044,2049,512]

theorem envBound38930 : H12AffineFastState.Bounded env38930 := by
  intro p hp
  have h : env38930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38929_38930 : H12AffineEnvironment.transform 11 2097 env38929 = env38930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env38929 == env38930) = true)

theorem identity38930 : scanCanonicalize (H12AffineFastState.compose env38930 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38930 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38931 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,2097,41,2048,32,34,2097,2048,52,33,2081,32,17,2,41,16,2048,2065,2096,2048,53,33,4,32,2049,512]

theorem envBound38931 : H12AffineFastState.Bounded env38931 := by
  intro p hp
  have h : env38931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38930_38931 : H12AffineEnvironment.transform 9 52 env38930 = env38931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38930 == env38931) = true)

theorem identity38931 : scanCanonicalize (H12AffineFastState.compose env38931 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38931 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38932 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,8,2048,1,3,2064,2048,21,0,2048,1,17,2,8,16,2048,2065,2065,2048,20,0,4,1,2049,512]

theorem envBound38932 : H12AffineFastState.Bounded env38932 := by
  intro p hp
  have h : env38932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38931_38932 : H12AffineEnvironment.transform 4 1 env38931 = env38932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38931 == env38932) = true)

theorem identity38932 : scanCanonicalize (H12AffineFastState.compose env38932 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound38932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38933 : List Nat := [2,4,8,16,1,17,8,4,14,21,2048,2064,8,2048,1,3,2064,2048,21,0,2048,1,17,2,8,16,2048,2065,2065,2048,20,0,4,1,2049,14]

theorem envBound38933 : H12AffineFastState.Bounded env38933 := by
  intro p hp
  have h : env38933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38932_38933 : H12AffineEnvironment.transform 8 14 env38932 = env38933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env38932 == env38933) = true)

def env38934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797862,115151,10507600,8423781,10600787,4268163,256,8487407,8478795,10544772]

theorem envBound38934 : H12AffineFastState.Bounded env38934 := by
  intro p hp
  have h : env38934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38816_38934 : H12AffineEnvironment.transform 17 149861 env38816 = env38934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env38816 == env38934) = true)

def env38935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,8388608,21763,8328,65,12704870,115151,8406288,8423781,8507667,4268163,256,8487407,8478795,8451780]

theorem envBound38935 : H12AffineFastState.Bounded env38935 := by
  intro p hp
  have h : env38935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38934_38935 : H12AffineEnvironment.transform 20 4160 env38934 = env38935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38934 == env38935) = true)

def env38936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363552,21763,8328,65,215366,115151,4378672,4332613,4408371,4268163,256,4396239,4453739,4350948]

theorem envBound38936 : H12AffineFastState.Bounded env38936 := by
  intro p hp
  have h : env38936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38935_38936 : H12AffineEnvironment.transform 22 4363552 env38935 = env38936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env38935 == env38936) = true)

theorem identity38936 : scanCanonicalize (H12AffineFastState.compose env38936 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound38936 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1024,29908,4160,4194304,4350453,21763,8328,65,215366,79130,4334821,4332613,4408371,4268163,256,4396239,4391358,4350948]

theorem envBound38937 : H12AffineFastState.Bounded env38937 := by
  intro p hp
  have h : env38937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38936_38937 : H12AffineEnvironment.transform 14 29909 env38936 = env38937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env38936 == env38937) = true)

def env38938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1024,29908,4160,32,156117,21763,8328,65,215366,79130,140485,138341,214035,73891,256,201967,197022,156612]

theorem envBound38938 : H12AffineFastState.Bounded env38938 := by
  intro p hp
  have h : env38938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38937_38938 : H12AffineEnvironment.transform 21 32 env38937 = env38938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38937 == env38938) = true)

theorem identity38938 : scanCanonicalize (H12AffineFastState.compose env38938 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound38938 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env38939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82382,67755,1024,29908,4160,32,73755,21763,8328,65,2184,79130,91403,89515,1501,73891,256,21793,16464,74250]

theorem envBound38939 : H12AffineFastState.Bounded env38939 := by
  intro p hp
  have h : env38939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38938_38939 : H12AffineEnvironment.transform 16 82382 env38938 = env38939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env38938 == env38939) = true)

theorem identity38939 : scanCanonicalize (H12AffineFastState.compose env38939 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound38939 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38940 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,65536,82199,67698,1024,29709,4160,32,73755,21763,8273,65,2129,79130,91403,89458,1284,73850,256,21793,16464,74250]

theorem envBound38940 : H12AffineFastState.Bounded env38940 := by
  intro p hp
  have h : env38940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38939_38940 : H12AffineEnvironment.transform 6 89 env38939 = env38940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env38939 == env38940) = true)

theorem identity38940 : scanCanonicalize (H12AffineFastState.compose env38940 (packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38940 : packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env38941 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,342,16449,2340,1024,29709,4160,32,8525,21763,8273,65,2129,13388,25693,23588,1284,8492,256,21793,16464,9052]

theorem envBound38941 : H12AffineFastState.Bounded env38941 := by
  intro p hp
  have h : env38941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38940_38941 : H12AffineEnvironment.transform 15 342 env38940 = env38941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38940 == env38941) = true)

theorem identity38941 : scanCanonicalize (H12AffineFastState.compose env38941 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound38941 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38942 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8540,342,5393,2340,1024,8541,4160,32,8525,83,8273,65,2129,13388,12557,2420,1284,8492,256,113,5376,9052]

theorem envBound38942 : H12AffineFastState.Bounded env38942 := by
  intro p hp
  have h : env38942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38941_38942 : H12AffineEnvironment.transform 13 5456 env38941 = env38942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env38941 == env38942) = true)

theorem identity38942 : scanCanonicalize (H12AffineFastState.compose env38942 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound38942 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env38943 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,88,5456,260,342,5393,2340,1024,261,4160,32,277,83,9,65,2129,5140,4437,2420,1284,372,256,113,5376,772]

theorem envBound38943 : H12AffineFastState.Bounded env38943 := by
  intro p hp
  have h : env38943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38942_38943 : H12AffineEnvironment.transform 12 88 env38942 = env38943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env38942 == env38943) = true)

theorem identity38943 : scanCanonicalize (H12AffineFastState.compose env38943 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38943 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38944 : List Nat := [2,4,8,16,32,64,89,4,512,1024,2048,4096,88,5204,0,82,5141,2080,1024,1,4160,32,17,83,9,65,2129,5140,4177,2160,1024,112,4,113,5124,512]

theorem envBound38944 : H12AffineFastState.Bounded env38944 := by
  intro p hp
  have h : env38944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38943_38944 : H12AffineEnvironment.transform 7 4 env38943 = env38944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38943 == env38944) = true)

theorem identity38944 : scanCanonicalize (H12AffineFastState.compose env38944 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound38944 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38945 : List Nat := [2,4,8,16,32,49,40,4,512,1024,2048,4096,41,5157,0,35,5141,2080,1024,1,4145,32,17,34,9,48,2080,5140,4128,2049,1024,1,4,0,5124,512]

theorem envBound38945 : H12AffineFastState.Bounded env38945 := by
  intro p hp
  have h : env38945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38944_38945 : H12AffineEnvironment.transform 5 49 env38944 = env38945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env38944 == env38945) = true)

theorem identity38945 : scanCanonicalize (H12AffineFastState.compose env38945 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38945 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env38946 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,0,2,5141,2049,1024,1,4112,1,17,3,9,17,2049,5140,4097,2049,1024,1,4,0,5124,512]

theorem envBound38946 : H12AffineFastState.Bounded env38946 := by
  intro p hp
  have h : env38946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38945_38946 : H12AffineEnvironment.transform 4 1 env38945 = env38946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38945 == env38946) = true)

theorem identity38946 : scanCanonicalize (H12AffineFastState.compose env38946 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38947 : List Nat := [2,4,8,1,1,1,9,4,512,1024,2048,4096,8,5124,0,2,5124,2049,1024,1,4097,1,0,3,9,0,2049,5125,4097,2049,1024,1,4,0,5124,512]

theorem envBound38947 : H12AffineFastState.Bounded env38947 := by
  intro p hp
  have h : env38947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38946_38947 : H12AffineEnvironment.transform 3 1 env38946 = env38947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38946 == env38947) = true)

theorem identity38947 : scanCanonicalize (H12AffineFastState.compose env38947 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound38947 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38948 : List Nat := [2,4,8,1,1,1,9,4,512,1024,2048,512,8,1540,0,2,1540,2049,1024,1,513,1,0,3,9,0,2049,1541,513,2049,1024,1,4,0,1540,512]

theorem envBound38948 : H12AffineFastState.Bounded env38948 := by
  intro p hp
  have h : env38948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38947_38948 : H12AffineEnvironment.transform 11 512 env38947 = env38948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env38947 == env38948) = true)

theorem identity38948 : scanCanonicalize (H12AffineFastState.compose env38948 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound38948 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38949 : List Nat := [2,4,8,1,1,1,9,4,512,1024,513,512,8,1540,0,2,1540,512,1024,1,513,1,0,3,9,0,512,1541,513,512,1024,1,4,0,1540,512]

theorem envBound38949 : H12AffineFastState.Bounded env38949 := by
  intro p hp
  have h : env38949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38948_38949 : H12AffineEnvironment.transform 10 513 env38948 = env38949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env38948 == env38949) = true)

def env38950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1024,29908,4160,33,156116,21763,8328,65,215366,79130,140484,138340,214034,73890,256,201966,197023,156613]

theorem envBound38950 : H12AffineFastState.Bounded env38950 := by
  intro p hp
  have h : env38950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38937_38950 : H12AffineEnvironment.transform 21 33 env38937 = env38950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env38937 == env38950) = true)

theorem identity38950 : scanCanonicalize (H12AffineFastState.compose env38950 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound38950 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env38951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79251,97526,1024,29908,4160,33,87111,21763,8328,65,31957,79130,69975,76279,29057,73890,256,8573,13324,87638]

theorem envBound38951 : H12AffineFastState.Bounded env38951 := by
  intro p hp
  have h : env38951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38950_38951 : H12AffineEnvironment.transform 16 79251 env38950 = env38951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env38950 == env38951) = true)

theorem identity38951 : scanCanonicalize (H12AffineFastState.compose env38951 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound38951 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,13508,32161,1024,29908,4160,33,21776,21763,8328,65,31957,13389,4096,10400,29057,8693,256,8573,13324,22273]

theorem envBound38952 : H12AffineFastState.Bounded env38952 := by
  intro p hp
  have h : env38952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38951_38952 : H12AffineEnvironment.transform 15 343 env38951 = env38952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env38951 == env38952) = true)

theorem identity38952 : scanCanonicalize (H12AffineFastState.compose env38952 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound38952 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env38953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,2185,15452,343,13508,13608,1024,15453,4160,33,7577,7562,8328,65,13404,13389,4096,10400,14600,8693,256,8573,13324,8072]

theorem envBound38953 : H12AffineFastState.Bounded env38953 := by
  intro p hp
  have h : env38953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38952_38953 : H12AffineEnvironment.transform 13 2185 env38952 = env38953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env38952 == env38953) = true)

theorem identity38953 : scanCanonicalize (H12AffineFastState.compose env38953 (packedSelected [2,3,4,6,9,11,15,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38953 : packedSelected [2,3,4,6,9,11,15,17,24] rootPS < 2^1333 := by decide +kernel

def env38954 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2185,15373,262,13461,13608,1024,15372,4113,33,7577,7562,8328,16,13325,13340,4096,10400,14600,8612,256,8492,13324,8072]

theorem envBound38954 : H12AffineFastState.Bounded env38954 := by
  intro p hp
  have h : env38954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38953_38954 : H12AffineEnvironment.transform 5 17 env38953 = env38954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38953 == env38954) = true)

theorem identity38954 : scanCanonicalize (H12AffineFastState.compose env38954 (packedSelected [0,1,2,6,7,8,10,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 3220) := by decide +kernel

theorem selectedBound38954 : packedSelected [0,1,2,6,7,8,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env38955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3220,2185,4249,262,6145,6588,1024,4248,4113,33,7577,7562,3100,16,6297,6280,4096,1076,5532,3376,256,3512,6296,8072]

theorem envBound38955 : H12AffineFastState.Bounded env38955 := by
  intro p hp
  have h : env38955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38954_38955 : H12AffineEnvironment.transform 12 3220 env38954 = env38955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3220 env38954 == env38955) = true)

theorem identity38955 : scanCanonicalize (H12AffineFastState.compose env38955 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound38955 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env38956 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,3220,2185,3124,262,1196,1297,1024,3125,3260,33,308,295,3100,16,1076,1061,3245,1076,2353,3376,256,3512,1077,805]

theorem envBound38956 : H12AffineFastState.Bounded env38956 := by
  intro p hp
  have h : env38956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38955_38956 : H12AffineEnvironment.transform 11 3245 env38955 = env38956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env38955 == env38956) = true)

theorem identity38956 : scanCanonicalize (H12AffineFastState.compose env38956 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound38956 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env38957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1281,1336,293,1432,262,1196,1297,1024,1433,1296,33,308,295,1456,16,1076,1061,1281,1076,157,1180,256,1044,1077,805]

theorem envBound38957 : H12AffineFastState.Bounded env38957 := by
  intro p hp
  have h : env38957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38956_38957 : H12AffineEnvironment.transform 10 428 env38956 = env38957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env38956 == env38957) = true)

theorem identity38957 : scanCanonicalize (H12AffineFastState.compose env38957 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38957 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38958 : List Nat := [2,4,8,16,32,17,128,256,512,52,428,309,268,293,428,262,152,293,52,429,292,33,308,295,388,16,0,17,309,0,157,168,256,32,1,805]

theorem envBound38958 : H12AffineFastState.Bounded env38958 := by
  intro p hp
  have h : env38958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38957_38958 : H12AffineEnvironment.transform 9 52 env38957 = env38958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38957 == env38958) = true)

theorem identity38958 : scanCanonicalize (H12AffineFastState.compose env38958 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38958 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env38959 : List Nat := [2,4,8,16,32,17,128,36,512,52,136,17,40,1,136,34,152,1,52,137,0,33,16,3,160,16,0,17,17,0,157,168,36,32,1,513]

theorem envBound38959 : H12AffineFastState.Bounded env38959 := by
  intro p hp
  have h : env38959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38958_38959 : H12AffineEnvironment.transform 7 36 env38958 = env38959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38958 == env38959) = true)

theorem identity38959 : scanCanonicalize (H12AffineFastState.compose env38959 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38959 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38960 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,17,40,1,0,34,16,1,52,1,0,33,16,3,40,16,0,17,17,0,21,32,36,32,1,513]

theorem envBound38960 : H12AffineFastState.Bounded env38960 := by
  intro p hp
  have h : env38960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38959_38960 : H12AffineEnvironment.transform 6 8 env38959 = env38960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38959 == env38960) = true)

theorem identity38960 : scanCanonicalize (H12AffineFastState.compose env38960 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound38960 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38961 : List Nat := [2,4,8,16,32,17,8,36,5,52,0,17,40,1,0,34,16,1,52,1,0,33,16,3,40,16,0,17,17,0,21,32,36,32,1,4]

theorem envBound38961 : H12AffineFastState.Bounded env38961 := by
  intro p hp
  have h : env38961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38960_38961 : H12AffineEnvironment.transform 8 5 env38960 = env38961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env38960 == env38961) = true)

theorem identity38961 : scanCanonicalize (H12AffineFastState.compose env38961 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound38961 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38962 : List Nat := [2,4,8,2,32,3,8,36,5,38,0,3,40,1,0,34,2,1,38,1,0,33,2,3,40,2,0,3,3,0,7,32,36,32,1,4]

theorem envBound38962 : H12AffineFastState.Bounded env38962 := by
  intro p hp
  have h : env38962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38961_38962 : H12AffineEnvironment.transform 3 2 env38961 = env38962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env38961 == env38962) = true)

theorem identity38962 : scanCanonicalize (H12AffineFastState.compose env38962 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38963 : List Nat := [0,4,8,0,32,1,8,36,5,36,0,1,40,1,0,32,0,1,36,1,0,33,0,1,40,0,0,1,1,0,5,32,36,32,1,4]

theorem envBound38963 : H12AffineFastState.Bounded env38963 := by
  intro p hp
  have h : env38963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38962_38963 : H12AffineEnvironment.transform 0 0 env38962 = env38963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38962 == env38963) = true)

theorem identity38963 : scanCanonicalize (H12AffineFastState.compose env38963 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38963 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38964 : List Nat := [0,4,1,0,32,1,1,36,5,36,0,1,33,1,0,32,0,1,36,1,0,33,0,1,33,0,0,1,1,0,5,32,36,32,1,4]

theorem envBound38964 : H12AffineFastState.Bounded env38964 := by
  intro p hp
  have h : env38964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38963_38964 : H12AffineEnvironment.transform 2 1 env38963 = env38964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38963 == env38964) = true)

theorem identity38964 : scanCanonicalize (H12AffineFastState.compose env38964 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38964 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38965 : List Nat := [0,4,1,0,0,1,1,4,5,4,0,1,1,1,0,0,0,1,4,1,0,1,0,1,1,0,0,1,1,0,5,0,4,0,1,4]

theorem envBound38965 : H12AffineFastState.Bounded env38965 := by
  intro p hp
  have h : env38965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38964_38965 : H12AffineEnvironment.transform 4 0 env38964 = env38965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38964 == env38965) = true)

def env38966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363553,21763,8328,65,215367,115151,4378673,4332612,4408370,4268163,256,4396238,4453738,4350949]

theorem envBound38966 : H12AffineFastState.Bounded env38966 := by
  intro p hp
  have h : env38966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38935_38966 : H12AffineEnvironment.transform 22 4363553 env38935 = env38966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env38935 == env38966) = true)

theorem identity38966 : scanCanonicalize (H12AffineFastState.compose env38966 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound38966 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156132,62661,21763,8328,65,215367,115151,45525,32160,75222,213351,256,95530,103566,513]

theorem envBound38967 : H12AffineFastState.Bounded env38967 := by
  intro p hp
  have h : env38967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38966_38967 : H12AffineEnvironment.transform 21 156132 env38966 = env38967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env38966 == env38967) = true)

def env38968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156012,62541,21763,8192,65,215367,115015,45405,32040,75102,213351,256,95530,103430,513]

theorem envBound38968 : H12AffineFastState.Bounded env38968 := by
  intro p hp
  have h : env38968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38967_38968 : H12AffineEnvironment.transform 6 8 env38967 = env38968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38967 == env38968) = true)

theorem identity38968 : scanCanonicalize (H12AffineFastState.compose env38968 (packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound38968 : packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env38969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32040,1024,32769,4160,21793,62541,21763,8192,65,97546,115015,45405,32040,75102,95530,256,95530,103430,513]

theorem envBound38969 : H12AffineFastState.Bounded env38969 := by
  intro p hp
  have h : env38969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38968_38969 : H12AffineEnvironment.transform 16 13389 env38968 = env38969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env38968 == env38969) = true)

theorem identity38969 : scanCanonicalize (H12AffineFastState.compose env38969 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound38969 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env38970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,32040,1024,32769,4160,21793,62541,21763,8192,65,43357,5392,45405,32040,61705,41341,256,41341,16465,513]

theorem envBound38970 : H12AffineFastState.Bounded env38970 := by
  intro p hp
  have h : env38970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38969_38970 : H12AffineEnvironment.transform 15 54359 env38969 = env38970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env38969 == env38970) = true)

theorem identity38970 : scanCanonicalize (H12AffineFastState.compose env38970 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound38970 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13389,32040,1024,29789,4160,21793,17,21763,8192,65,23809,5392,17665,32040,1365,21793,256,21793,16465,513]

theorem envBound38971 : H12AffineFastState.Bounded env38971 := by
  intro p hp
  have h : env38971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38970_38971 : H12AffineEnvironment.transform 14 29788 env38970 = env38971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env38970 == env38971) = true)

theorem identity38971 : scanCanonicalize (H12AffineFastState.compose env38971 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38971 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21840,263,5441,23588,1024,21841,4160,21793,17,21763,268,65,23809,5392,17665,23588,1365,21793,256,21793,16465,513]

theorem envBound38972 : H12AffineFastState.Bounded env38972 := by
  intro p hp
  have h : env38972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38971_38972 : H12AffineEnvironment.transform 12 268 env38971 = env38972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38971 == env38972) = true)

theorem identity38972 : scanCanonicalize (H12AffineFastState.compose env38972 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound38972 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env38973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,6161,3393,263,5441,1077,1024,3392,4160,3376,17,3346,268,65,1296,5392,7440,1077,1365,3376,256,3376,6208,513]

theorem envBound38973 : H12AffineFastState.Bounded env38973 := by
  intro p hp
  have h : env38973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38972_38973 : H12AffineEnvironment.transform 13 6161 env38972 = env38973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env38972 == env38973) = true)

theorem identity38973 : scanCanonicalize (H12AffineFastState.compose env38973 (packedSelected [6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound38973 : packedSelected [6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,268,5457,1,263,5441,1077,1024,0,4160,112,17,82,268,65,1296,5392,4176,1077,1365,112,256,112,5376,513]

theorem envBound38974 : H12AffineFastState.Bounded env38974 := by
  intro p hp
  have h : env38974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38973_38974 : H12AffineEnvironment.transform 10 1344 env38973 = env38974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env38973 == env38974) = true)

theorem identity38974 : scanCanonicalize (H12AffineFastState.compose env38974 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound38974 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,42,268,1403,1,263,1387,1077,1024,0,106,112,17,82,268,65,1296,1338,122,1077,1365,112,256,112,1322,513]

theorem envBound38975 : H12AffineFastState.Bounded env38975 := by
  intro p hp
  have h : env38975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38974_38975 : H12AffineEnvironment.transform 11 42 env38974 = env38975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env38974 == env38975) = true)

def env38976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156013,62540,21763,8193,65,215367,115014,45404,32041,75103,213351,256,95530,103431,513]

theorem envBound38976 : H12AffineFastState.Bounded env38976 := by
  intro p hp
  have h : env38976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38967_38976 : H12AffineEnvironment.transform 6 9 env38967 = env38976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38967 == env38976) = true)

theorem identity38976 : scanCanonicalize (H12AffineFastState.compose env38976 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound38976 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,76159,1024,32769,4160,65911,62540,21763,8193,65,10589,115014,45404,32041,75103,8573,256,95530,103431,513]

theorem envBound38977 : H12AffineFastState.Bounded env38977 := by
  intro p hp
  have h : env38977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38976_38977 : H12AffineEnvironment.transform 16 90138 env38976 = env38977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env38976 == env38977) = true)

theorem identity38977 : scanCanonicalize (H12AffineFastState.compose env38977 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53575) := by decide +kernel

theorem selectedBound38977 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env38978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53575,45405,63544,1024,32769,4160,53296,62540,21763,8193,65,10589,4097,45404,32041,62488,8573,256,42093,17728,513]

theorem envBound38978 : H12AffineFastState.Bounded env38978 := by
  intro p hp
  have h : env38978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38977_38978 : H12AffineEnvironment.transform 15 53575 env38977 = env38978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53575 env38977 == env38978) = true)

theorem identity38978 : scanCanonicalize (H12AffineFastState.compose env38978 (packedSelected [0,1,4,5,8,9,12,15,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 28728) := by decide +kernel

theorem selectedBound38978 : packedSelected [0,1,4,5,8,9,12,15,20,24,27] rootPS < 2^1333 := by decide +kernel

def env38979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,28728,8575,16741,2048,1024,28729,4160,8200,1140,21763,8193,65,10589,4097,16740,32041,1056,8573,256,21589,17728,513]

theorem envBound38979 : H12AffineFastState.Bounded env38979 := by
  intro p hp
  have h : env38979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38978_38979 : H12AffineEnvironment.transform 14 28728 env38978 = env38979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28728 env38978 == env38979) = true)

theorem identity38979 : scanCanonicalize (H12AffineFastState.compose env38979 (packedSelected [0,1,3,4,7,8,9,10,14,15,17,18,23,24,38] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound38979 : packedSelected [0,1,3,4,7,8,9,10,14,15,17,18,23,24,38] rootPS < 2^1333 := by decide +kernel

def env38980 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,28728,8575,16741,2048,321,28729,4160,8200,309,20546,8193,65,10589,4097,16740,30824,353,8573,256,20756,16385,513]

theorem envBound38980 : H12AffineFastState.Bounded env38980 := by
  intro p hp
  have h : env38980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38979_38980 : H12AffineEnvironment.transform 9 321 env38979 = env38980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38979 == env38980) = true)

theorem identity38980 : scanCanonicalize (H12AffineFastState.compose env38980 (packedSelected [0,3,5,7,10,12,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound38980 : packedSelected [0,3,5,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env38981 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12392,80,8575,12557,2048,321,81,4160,8200,309,8234,8193,65,10589,4097,12556,2048,353,8573,256,8572,12393,513]

theorem envBound38981 : H12AffineFastState.Bounded env38981 := by
  intro p hp
  have h : env38981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38980_38981 : H12AffineEnvironment.transform 13 12392 env38980 = env38981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env38980 == env38981) = true)

theorem identity38981 : scanCanonicalize (H12AffineFastState.compose env38981 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38981 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38982 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,269,4453,80,114,4096,2048,321,81,4160,261,309,295,268,65,2128,4097,4097,2048,353,112,256,113,4452,513]

theorem envBound38982 : H12AffineFastState.Bounded env38982 := by
  intro p hp
  have h : env38982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38981_38982 : H12AffineEnvironment.transform 12 269 env38981 = env38982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38981 == env38982) = true)

theorem identity38982 : scanCanonicalize (H12AffineFastState.compose env38982 (packedSelected [11,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38982 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env38983 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4112,80,114,4096,2048,52,81,4160,112,64,82,121,65,2128,4097,4097,2048,20,112,117,113,4113,513]

theorem envBound38983 : H12AffineFastState.Bounded env38983 := by
  intro p hp
  have h : env38983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38982_38983 : H12AffineEnvironment.transform 7 117 env38982 = env38983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38982 == env38983) = true)

theorem identity38983 : scanCanonicalize (H12AffineFastState.compose env38983 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound38983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38984 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,576,120,592,80,114,576,2048,52,81,512,112,64,82,121,65,2128,577,577,2048,20,112,117,113,593,513]

theorem envBound38984 : H12AffineFastState.Bounded env38984 := by
  intro p hp
  have h : env38984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38983_38984 : H12AffineEnvironment.transform 11 576 env38983 = env38984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env38983 == env38984) = true)

def env38985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,8388608,21762,8328,65,12704871,115151,8406289,8423781,8507666,4268163,256,8487407,8478795,8451781]

theorem envBound38985 : H12AffineFastState.Bounded env38985 := by
  intro p hp
  have h : env38985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38934_38985 : H12AffineEnvironment.transform 20 4161 env38934 = env38985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38934 == env38985) = true)

def env38986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363552,21762,8328,65,215367,115151,4378673,4332613,4408370,4268163,256,4396239,4453739,4350949]

theorem envBound38986 : H12AffineFastState.Bounded env38986 := by
  intro p hp
  have h : env38986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38985_38986 : H12AffineEnvironment.transform 22 4363552 env38985 = env38986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env38985 == env38986) = true)

def env38987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169400,152,21762,8328,65,215367,115151,17801,35325,119178,243003,256,98679,90323,63069]

theorem envBound38987 : H12AffineFastState.Bounded env38987 := by
  intro p hp
  have h : env38987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38986_38987 : H12AffineEnvironment.transform 21 169400 env38986 = env38987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env38986 == env38987) = true)

def env38988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21928,152,21762,8328,65,100695,115151,17801,35325,119178,95531,256,98679,90323,63069]

theorem envBound38988 : H12AffineFastState.Bounded env38988 := by
  intro p hp
  have h : env38988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38987_38988 : H12AffineEnvironment.transform 16 49168 env38987 = env38988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env38987 == env38988) = true)

theorem identity38988 : scanCanonicalize (H12AffineFastState.compose env38988 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1024,8540,4161,21928,152,21762,8328,65,75786,90258,17801,10400,94423,95531,256,73770,90323,22272]

theorem envBound38989 : H12AffineFastState.Bounded env38989 := by
  intro p hp
  have h : env38989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38988_38989 : H12AffineEnvironment.transform 14 8541 env38988 = env38989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38988 == env38989) = true)

theorem identity38989 : scanCanonicalize (H12AffineFastState.compose env38989 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound38989 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,21726,24909,10280,1024,8540,4161,21928,152,21762,8328,65,31956,13388,17801,10400,9225,8693,256,29940,13325,22272]

theorem envBound38990 : H12AffineFastState.Bounded env38990 := by
  intro p hp
  have h : env38990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38989_38990 : H12AffineEnvironment.transform 15 21726 env38989 = env38990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env38989 == env38990) = true)

theorem identity38990 : scanCanonicalize (H12AffineFastState.compose env38990 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38990 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env38991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,1,21726,16401,2420,1024,0,4161,21928,152,21762,468,65,23944,5392,17801,2556,1365,169,256,21928,5457,22272]

theorem envBound38991 : H12AffineFastState.Bounded env38991 := by
  intro p hp
  have h : env38991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38990_38991 : H12AffineEnvironment.transform 12 348 env38990 = env38991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38990 == env38991) = true)

theorem identity38991 : scanCanonicalize (H12AffineFastState.compose env38991 (packedSelected [3,5,10,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound38991 : packedSelected [3,5,10,18,23] rootPS < 2^1333 := by decide +kernel

def env38992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5592,1,262,5577,2420,1024,0,4161,112,152,218,468,65,2128,5392,4177,2556,1365,169,256,112,5457,728]

theorem envBound38992 : H12AffineFastState.Bounded env38992 := by
  intro p hp
  have h : env38992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38991_38992 : H12AffineEnvironment.transform 13 5592 env38991 = env38992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env38991 == env38992) = true)

def env38993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21929,152,21762,8328,65,100694,115151,17801,35325,119178,95530,256,98679,90323,63069]

theorem envBound38993 : H12AffineFastState.Bounded env38993 := by
  intro p hp
  have h : env38993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38987_38993 : H12AffineEnvironment.transform 16 49169 env38987 = env38993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env38987 == env38993) = true)

theorem identity38993 : scanCanonicalize (H12AffineFastState.compose env38993 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound38993 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10400,1024,8661,4161,21929,152,21762,8328,65,75906,90139,17801,10281,94302,95530,256,73891,90323,22409]

theorem envBound38994 : H12AffineFastState.Bounded env38994 := by
  intro p hp
  have h : env38994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38993_38994 : H12AffineEnvironment.transform 14 8660 env38993 = env38994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env38993 == env38994) = true)

theorem identity38994 : scanCanonicalize (H12AffineFastState.compose env38994 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound38994 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,30082,25029,10400,1024,8661,4161,21929,152,21762,8328,65,23808,5529,17801,10281,1500,168,256,21793,5457,22409]

theorem envBound38995 : H12AffineFastState.Bounded env38995 := by
  intro p hp
  have h : env38995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38994_38995 : H12AffineEnvironment.transform 15 30082 env38994 = env38995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env38994 == env38995) = true)

theorem identity38995 : scanCanonicalize (H12AffineFastState.compose env38995 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound38995 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8660,8202,13389,10400,1024,8661,4161,33,152,138,8328,65,2184,5529,4097,10281,1500,168,256,169,5457,513]

theorem envBound38996 : H12AffineFastState.Bounded env38996 := by
  intro p hp
  have h : env38996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38995_38996 : H12AffineEnvironment.transform 13 5512 env38995 = env38996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env38995 == env38996) = true)

theorem identity38996 : scanCanonicalize (H12AffineFastState.compose env38996 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound38996 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38997 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,8192,5489,8493,8202,13389,10329,1024,8492,4161,33,97,115,8305,65,2161,5472,4097,10281,1317,81,256,80,5457,513]

theorem envBound38997 : H12AffineFastState.Bounded env38997 := by
  intro p hp
  have h : env38997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38996_38997 : H12AffineEnvironment.transform 6 121 env38996 = env38997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env38996 == env38997) = true)

theorem identity38997 : scanCanonicalize (H12AffineFastState.compose env38997 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38997 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38998 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,5377,8493,8202,13373,10281,1024,8492,4145,33,17,3,8193,49,2049,5392,4097,10281,1317,33,256,32,5409,513]

theorem envBound38998 : H12AffineFastState.Bounded env38998 := by
  intro p hp
  have h : env38998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38997_38998 : H12AffineEnvironment.transform 5 48 env38997 = env38998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38997 == env38998) = true)

theorem identity38998 : scanCanonicalize (H12AffineFastState.compose env38998 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38998 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38999 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,269,5377,32,263,5424,2340,1024,33,4145,33,17,3,268,49,2049,5392,4097,2340,1317,33,256,32,5409,513]

theorem envBound38999 : H12AffineFastState.Bounded env38999 := by
  intro p hp
  have h : env38999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38998_38999 : H12AffineEnvironment.transform 12 269 env38998 = env38999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38998 == env38999) = true)

theorem identity38999 : scanCanonicalize (H12AffineFastState.compose env38999 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound38999 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39000 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,512,269,1793,32,263,1840,2340,1024,33,561,33,17,3,268,49,2049,1808,513,2340,1317,33,256,32,1825,513]

theorem envBound39000 : H12AffineFastState.Bounded env39000 := by
  intro p hp
  have h : env39000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38999_39000 : H12AffineEnvironment.transform 11 512 env38999 = env39000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env38999 == env39000) = true)

theorem identity39000 : scanCanonicalize (H12AffineFastState.compose env39000 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1840) := by decide +kernel

theorem selectedBound39000 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39001 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1840,512,269,1793,32,263,1840,1556,1024,33,561,33,17,3,268,49,1841,1808,513,1556,1317,33,256,32,1825,513]

theorem envBound39001 : H12AffineFastState.Bounded env39001 := by
  intro p hp
  have h : env39001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39000_39001 : H12AffineEnvironment.transform 10 1840 env39000 = env39001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1840 env39000 == env39001) = true)

theorem identity39001 : scanCanonicalize (H12AffineFastState.compose env39001 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39001 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39002 : List Nat := [2,4,8,16,32,48,9,4,512,1024,1588,512,9,1541,32,3,1588,1556,1024,33,561,33,17,3,8,49,1589,1556,513,1556,1057,33,4,32,1573,513]

theorem envBound39002 : H12AffineFastState.Bounded env39002 := by
  intro p hp
  have h : env39002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39001_39002 : H12AffineEnvironment.transform 7 4 env39001 = env39002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39001 == env39002) = true)

theorem identity39002 : scanCanonicalize (H12AffineFastState.compose env39002 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39002 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39003 : List Nat := [2,4,8,16,32,48,9,4,512,5,561,512,9,512,32,3,561,529,5,33,561,33,17,3,8,49,560,529,513,529,36,33,4,32,544,513]

theorem envBound39003 : H12AffineFastState.Bounded env39003 := by
  intro p hp
  have h : env39003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39002_39003 : H12AffineEnvironment.transform 9 5 env39002 = env39003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39002 == env39003) = true)

theorem identity39003 : scanCanonicalize (H12AffineFastState.compose env39003 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39003 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env39004 : List Nat := [2,4,8,16,17,1,9,4,512,5,512,512,9,512,17,3,512,529,5,16,512,16,17,3,8,0,513,529,513,529,21,16,4,17,529,513]

theorem envBound39004 : H12AffineFastState.Bounded env39004 := by
  intro p hp
  have h : env39004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39003_39004 : H12AffineEnvironment.transform 4 17 env39003 = env39004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39003 == env39004) = true)

theorem identity39004 : scanCanonicalize (H12AffineFastState.compose env39004 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39004 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39005 : List Nat := [2,4,8,0,1,1,9,4,512,5,512,512,9,512,1,3,512,513,5,0,512,0,1,3,8,0,513,513,513,513,5,0,4,1,513,513]

theorem envBound39005 : H12AffineFastState.Bounded env39005 := by
  intro p hp
  have h : env39005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39004_39005 : H12AffineEnvironment.transform 3 0 env39004 = env39005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39004 == env39005) = true)

theorem identity39005 : scanCanonicalize (H12AffineFastState.compose env39005 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39006 : List Nat := [2,4,8,0,1,1,9,4,0,5,0,0,9,0,1,3,0,1,5,0,0,0,1,3,8,0,1,1,1,1,5,0,4,1,1,1]

theorem envBound39006 : H12AffineFastState.Bounded env39006 := by
  intro p hp
  have h : env39006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39005_39006 : H12AffineEnvironment.transform 8 0 env39005 = env39006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39005 == env39006) = true)

theorem identity39006 : scanCanonicalize (H12AffineFastState.compose env39006 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39007 : List Nat := [2,4,3,0,1,1,2,4,0,5,0,0,2,0,1,3,0,1,5,0,0,0,1,3,3,0,1,1,1,1,5,0,4,1,1,1]

theorem envBound39007 : H12AffineFastState.Bounded env39007 := by
  intro p hp
  have h : env39007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39006_39007 : H12AffineEnvironment.transform 2 3 env39006 = env39007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39006 == env39007) = true)

def env39008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169401,153,21762,8328,65,215367,115151,17800,35324,119179,243002,256,98678,90322,63068]

theorem envBound39008 : H12AffineFastState.Bounded env39008 := by
  intro p hp
  have h : env39008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38986_39008 : H12AffineEnvironment.transform 21 169401 env38986 = env39008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env38986 == env39008) = true)

def env39009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21929,153,21762,8328,65,100695,115151,17800,35324,119179,95530,256,98678,90322,63068]

theorem envBound39009 : H12AffineFastState.Bounded env39009 := by
  intro p hp
  have h : env39009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39008_39009 : H12AffineEnvironment.transform 16 49168 env39008 = env39009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env39008 == env39009) = true)

theorem identity39009 : scanCanonicalize (H12AffineFastState.compose env39009 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39009 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21793,17,21762,8192,65,100695,115015,17664,35188,119043,95530,256,98678,90202,63068]

theorem envBound39010 : H12AffineFastState.Bounded env39010 := by
  intro p hp
  have h : env39010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39009_39010 : H12AffineEnvironment.transform 6 8 env39009 = env39010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39009 == env39010) = true)

theorem identity39010 : scanCanonicalize (H12AffineFastState.compose env39010 (packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound39010 : packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,24861,10360,1024,8460,4161,21793,17,21762,8192,65,75866,90186,17664,10361,94222,95530,256,73851,90202,22353]

theorem envBound39011 : H12AffineFastState.Bounded env39011 := by
  intro p hp
  have h : env39011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39010_39011 : H12AffineEnvironment.transform 14 8461 env39010 = env39011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env39010 == env39011) = true)

theorem identity39011 : scanCanonicalize (H12AffineFastState.compose env39011 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39011 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env39012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,29962,24861,10360,1024,8460,4161,21793,17,21762,8192,65,23888,5440,17664,10361,1284,32,256,21873,5456,22353]

theorem envBound39012 : H12AffineFastState.Bounded env39012 := by
  intro p hp
  have h : env39012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39011_39012 : H12AffineEnvironment.transform 15 29962 env39011 = env39012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39011 == env39012) = true)

theorem identity39012 : scanCanonicalize (H12AffineFastState.compose env39012 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39012 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env39013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8461,342,5441,10360,1024,8460,4161,8573,17,8542,8192,65,10508,5440,12636,10361,1284,32,256,8493,5456,8973]

theorem envBound39013 : H12AffineFastState.Bounded env39013 := by
  intro p hp
  have h : env39013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39012_39013 : H12AffineEnvironment.transform 13 13404 env39012 = env39013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39012 == env39013) = true)

theorem identity39013 : scanCanonicalize (H12AffineFastState.compose env39013 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39013 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,80,342,5441,2341,1024,81,4161,32,17,3,349,65,2129,5440,4097,2340,1284,32,256,112,5456,592]

theorem envBound39014 : H12AffineFastState.Bounded env39014 := by
  intro p hp
  have h : env39014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39013_39014 : H12AffineEnvironment.transform 12 349 env39013 = env39014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39013 == env39014) = true)

theorem identity39014 : scanCanonicalize (H12AffineFastState.compose env39014 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39014 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39015 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,80,34,5173,2129,1024,81,4161,32,17,3,41,65,2129,5172,4097,2128,1136,32,116,112,5156,592]

theorem envBound39015 : H12AffineFastState.Bounded env39015 := by
  intro p hp
  have h : env39015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39014_39015 : H12AffineEnvironment.transform 7 116 env39014 = env39015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39014 == env39015) = true)

theorem identity39015 : scanCanonicalize (H12AffineFastState.compose env39015 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39016 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,41,4161,80,34,4097,2129,52,81,4161,32,17,3,41,65,2129,4096,4097,2128,68,32,116,112,4112,592]

theorem envBound39016 : H12AffineFastState.Bounded env39016 := by
  intro p hp
  have h : env39016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39015_39016 : H12AffineEnvironment.transform 9 52 env39015 = env39016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39015 == env39016) = true)

theorem identity39016 : scanCanonicalize (H12AffineFastState.compose env39016 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39016 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env39017 : List Nat := [2,4,8,16,17,64,8,69,512,5,2048,4096,24,4161,80,19,4097,2129,5,81,4161,17,17,3,24,65,2129,4096,4097,2128,68,17,69,65,4112,592]

theorem envBound39017 : H12AffineFastState.Bounded env39017 := by
  intro p hp
  have h : env39017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39016_39017 : H12AffineEnvironment.transform 4 17 env39016 = env39017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39016 == env39017) = true)

theorem identity39017 : scanCanonicalize (H12AffineFastState.compose env39017 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound39017 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env39018 : List Nat := [2,4,8,16,17,64,8,69,512,5,2048,2065,24,2128,80,19,2064,2129,5,81,2128,17,17,3,24,65,2129,2065,2064,2128,68,17,69,65,2049,592]

theorem envBound39018 : H12AffineFastState.Bounded env39018 := by
  intro p hp
  have h : env39018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39017_39018 : H12AffineEnvironment.transform 11 2065 env39017 = env39018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env39017 == env39018) = true)

theorem identity39018 : scanCanonicalize (H12AffineFastState.compose env39018 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39018 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env39019 : List Nat := [2,4,8,16,17,16,8,21,512,5,2048,2065,24,2048,0,19,2064,2049,5,1,2048,17,17,3,24,17,2049,2065,2064,2048,20,17,21,17,2049,512]

theorem envBound39019 : H12AffineFastState.Bounded env39019 := by
  intro p hp
  have h : env39019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39018_39019 : H12AffineEnvironment.transform 5 16 env39018 = env39019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39018 == env39019) = true)

theorem identity39019 : scanCanonicalize (H12AffineFastState.compose env39019 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39019 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39020 : List Nat := [2,4,8,1,0,1,8,4,512,5,2048,2048,9,2048,0,2,2049,2049,5,1,2048,0,0,3,9,0,2049,2048,2049,2048,5,0,4,0,2049,512]

theorem envBound39020 : H12AffineFastState.Bounded env39020 := by
  intro p hp
  have h : env39020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39019_39020 : H12AffineEnvironment.transform 3 1 env39019 = env39020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39019 == env39020) = true)

theorem identity39020 : scanCanonicalize (H12AffineFastState.compose env39020 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound39020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39021 : List Nat := [2,4,8,1,0,1,8,4,4,5,2048,2048,9,2048,0,2,2049,2049,5,1,2048,0,0,3,9,0,2049,2048,2049,2048,5,0,4,0,2049,4]

theorem envBound39021 : H12AffineFastState.Bounded env39021 := by
  intro p hp
  have h : env39021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39020_39021 : H12AffineEnvironment.transform 8 4 env39020 = env39021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env39020 == env39021) = true)

theorem identity39021 : scanCanonicalize (H12AffineFastState.compose env39021 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound39021 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39022 : List Nat := [2,4,8,1,0,1,8,4,4,5,5,5,9,5,0,2,4,4,5,1,5,0,0,3,9,0,4,5,4,5,5,0,4,0,4,4]

theorem envBound39022 : H12AffineFastState.Bounded env39022 := by
  intro p hp
  have h : env39022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39021_39022 : H12AffineEnvironment.transform 10 5 env39021 = env39022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env39021 == env39022) = true)

theorem identity39022 : scanCanonicalize (H12AffineFastState.compose env39022 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39022 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env39023 : List Nat := [2,1,8,1,0,1,8,1,1,0,0,0,9,0,0,2,1,1,0,1,0,0,0,3,9,0,1,0,1,0,0,0,1,0,1,1]

theorem envBound39023 : H12AffineFastState.Bounded env39023 := by
  intro p hp
  have h : env39023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39022_39023 : H12AffineEnvironment.transform 1 1 env39022 = env39023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39022 == env39023) = true)

def env39024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21928,153,21762,8328,65,100694,115151,17800,35324,119179,95531,256,98678,90322,63068]

theorem envBound39024 : H12AffineFastState.Bounded env39024 := by
  intro p hp
  have h : env39024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39008_39024 : H12AffineEnvironment.transform 16 49169 env39008 = env39024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env39008 == env39024) = true)

def env39025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,16537,2556,1024,137,4161,21928,153,21762,8328,65,68062,82247,17800,2420,86275,95531,256,66046,90322,30420]

theorem envBound39025 : H12AffineFastState.Bounded env39025 := by
  intro p hp
  have h : env39025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39024_39025 : H12AffineEnvironment.transform 14 136 env39024 = env39025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env39024 == env39025) = true)

theorem identity39025 : scanCanonicalize (H12AffineFastState.compose env39025 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound39025 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,136,65536,13388,2556,1024,137,4161,8573,153,8663,8328,65,68062,79250,12637,2420,75222,66046,256,66046,70663,513]

theorem envBound39026 : H12AffineFastState.Bounded env39026 := by
  intro p hp
  have h : env39026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39025_39026 : H12AffineEnvironment.transform 13 13525 env39025 = env39026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env39025 == env39026) = true)

theorem identity39026 : scanCanonicalize (H12AffineFastState.compose env39026 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound39026 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env39027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,136,8323,13388,2556,1024,137,4161,8573,153,8663,8328,65,10589,5393,12637,2420,1365,8573,256,8573,13444,513]

theorem envBound39027 : H12AffineFastState.Bounded env39027 := by
  intro p hp
  have h : env39027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39026_39027 : H12AffineEnvironment.transform 15 8323 env39026 = env39027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env39026 == env39027) = true)

theorem identity39027 : scanCanonicalize (H12AffineFastState.compose env39027 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound39027 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,343,5528,2556,1024,137,4161,169,153,3,348,65,2185,5393,4233,2420,1365,169,256,169,5456,513]

theorem envBound39028 : H12AffineFastState.Bounded env39028 := by
  intro p hp
  have h : env39028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39027_39028 : H12AffineEnvironment.transform 12 468 env39027 = env39028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env39027 == env39028) = true)

theorem identity39028 : scanCanonicalize (H12AffineFastState.compose env39028 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39028 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5393,2421,1024,0,4161,32,16,3,348,65,2048,5393,4096,2420,1365,32,256,32,5456,513]

theorem envBound39029 : H12AffineFastState.Bounded env39029 := by
  intro p hp
  have h : env39029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39028_39029 : H12AffineEnvironment.transform 6 9 env39028 = env39029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39028 == env39029) = true)

theorem identity39029 : scanCanonicalize (H12AffineFastState.compose env39029 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound39029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,349,373,1,343,357,2421,1024,0,1077,32,16,3,348,65,2048,357,1140,2420,1365,32,256,32,292,513]

theorem envBound39030 : H12AffineFastState.Bounded env39030 := by
  intro p hp
  have h : env39030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39029_39030 : H12AffineEnvironment.transform 11 1140 env39029 = env39030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env39029 == env39030) = true)

theorem identity39030 : scanCanonicalize (H12AffineFastState.compose env39030 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound39030 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1140,349,373,1,343,357,0,1024,0,1077,32,16,3,348,65,373,357,1140,1,1365,32,256,32,292,513]

theorem envBound39031 : H12AffineFastState.Bounded env39031 := by
  intro p hp
  have h : env39031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39030_39031 : H12AffineEnvironment.transform 10 373 env39030 = env39031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env39030 == env39031) = true)

theorem identity39031 : scanCanonicalize (H12AffineFastState.compose env39031 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound39031 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39032 : List Nat := [2,4,8,16,32,64,9,256,16,1024,373,1140,349,373,1,343,357,0,1024,0,1077,32,16,3,348,65,373,357,1140,1,1365,32,256,32,292,17]

theorem envBound39032 : H12AffineFastState.Bounded env39032 := by
  intro p hp
  have h : env39032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39031_39032 : H12AffineEnvironment.transform 8 16 env39031 = env39032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env39031 == env39032) = true)

theorem identity39032 : scanCanonicalize (H12AffineFastState.compose env39032 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound39032 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39033 : List Nat := [2,4,8,16,32,64,9,53,16,1024,64,1140,104,64,1,98,80,0,1024,0,1077,32,16,3,105,65,64,80,1140,1,1120,32,53,32,17,17]

theorem envBound39033 : H12AffineFastState.Bounded env39033 := by
  intro p hp
  have h : env39033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39032_39033 : H12AffineEnvironment.transform 7 53 env39032 = env39033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env39032 == env39033) = true)

theorem identity39033 : scanCanonicalize (H12AffineFastState.compose env39033 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound39033 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39034 : List Nat := [2,4,8,16,32,32,9,53,16,1024,32,1044,8,32,1,2,48,0,1024,0,1077,32,16,3,9,33,32,48,1044,1,1024,32,53,32,17,17]

theorem envBound39034 : H12AffineFastState.Bounded env39034 := by
  intro p hp
  have h : env39034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39033_39034 : H12AffineEnvironment.transform 5 32 env39033 = env39034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env39033 == env39034) = true)

theorem identity39034 : scanCanonicalize (H12AffineFastState.compose env39034 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39034 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env39035 : List Nat := [2,4,8,16,0,0,9,21,16,1024,0,1044,8,0,1,2,16,0,1024,0,1045,0,16,3,9,1,0,16,1044,1,1024,0,21,0,17,17]

theorem envBound39035 : H12AffineFastState.Bounded env39035 := by
  intro p hp
  have h : env39035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39034_39035 : H12AffineEnvironment.transform 4 0 env39034 = env39035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39034 == env39035) = true)

theorem identity39035 : scanCanonicalize (H12AffineFastState.compose env39035 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39036 : List Nat := [2,4,8,16,0,0,9,21,16,4,0,16,8,0,1,2,16,0,4,0,17,0,16,3,9,1,0,16,16,1,4,0,21,0,17,17]

theorem envBound39036 : H12AffineFastState.Bounded env39036 := by
  intro p hp
  have h : env39036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39035_39036 : H12AffineEnvironment.transform 9 4 env39035 = env39036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39035 == env39036) = true)

theorem identity39036 : scanCanonicalize (H12AffineFastState.compose env39036 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39036 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39037 : List Nat := [2,4,8,1,0,0,9,4,1,4,0,1,8,0,1,2,1,0,4,0,0,0,1,3,9,1,0,1,1,1,4,0,4,0,0,0]

theorem envBound39037 : H12AffineFastState.Bounded env39037 := by
  intro p hp
  have h : env39037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39036_39037 : H12AffineEnvironment.transform 3 1 env39036 = env39037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39036 == env39037) = true)

def env39038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,16536,2557,1024,136,4161,21928,153,21762,8328,65,68063,82246,17800,2421,86274,95531,256,66047,90322,30421]

theorem envBound39038 : H12AffineFastState.Bounded env39038 := by
  intro p hp
  have h : env39038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39024_39038 : H12AffineEnvironment.transform 14 137 env39024 = env39038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env39024 == env39038) = true)

theorem identity39038 : scanCanonicalize (H12AffineFastState.compose env39038 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound39038 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env39039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,65536,16536,2557,1024,136,4161,21928,153,21762,349,65,68063,82246,17800,2421,86274,87294,256,66047,82183,22272]

theorem envBound39039 : H12AffineFastState.Bounded env39039 := by
  intro p hp
  have h : env39039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39038_39039 : H12AffineEnvironment.transform 12 469 env39038 = env39039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env39038 == env39039) = true)

theorem identity39039 : scanCanonicalize (H12AffineFastState.compose env39039 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound39039 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env39040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,21590,16536,2557,1024,136,4161,21928,153,21762,349,65,23945,5392,17800,2421,1364,168,256,21929,5457,22272]

theorem envBound39040 : H12AffineFastState.Bounded env39040 := by
  intro p hp
  have h : env39040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39039_39040 : H12AffineEnvironment.transform 15 21590 env39039 = env39040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env39039 == env39040) = true)

theorem identity39040 : scanCanonicalize (H12AffineFastState.compose env39040 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39040 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env39041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21590,16400,2421,1024,0,4161,21792,17,21762,349,65,23809,5392,17664,2421,1364,32,256,21793,5457,22272]

theorem envBound39041 : H12AffineFastState.Bounded env39041 := by
  intro p hp
  have h : env39041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39040_39041 : H12AffineEnvironment.transform 6 8 env39040 = env39041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39040 == env39041) = true)

theorem identity39041 : scanCanonicalize (H12AffineFastState.compose env39041 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39041 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5393,2421,1024,0,4161,33,17,3,349,65,2048,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound39042 : H12AffineFastState.Bounded env39042 := by
  intro p hp
  have h : env39042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39041_39042 : H12AffineEnvironment.transform 13 5377 env39041 = env39042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39041 == env39042) = true)

theorem identity39042 : scanCanonicalize (H12AffineFastState.compose env39042 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound39042 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39043 : List Nat := [2,4,8,16,32,64,8,256,512,612,2048,4096,349,4965,1,343,4981,2421,612,0,4161,33,17,3,349,65,2048,4980,4097,2421,816,32,256,32,4917,513]

theorem envBound39043 : H12AffineFastState.Bounded env39043 := by
  intro p hp
  have h : env39043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39042_39043 : H12AffineEnvironment.transform 9 612 env39042 = env39043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env39042 == env39043) = true)

theorem identity39043 : scanCanonicalize (H12AffineFastState.compose env39043 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39043 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39044 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,4096,269,4917,1,263,4901,2341,564,0,4113,33,17,3,269,17,2048,4900,4097,2341,816,32,256,32,4917,513]

theorem envBound39044 : H12AffineFastState.Bounded env39044 := by
  intro p hp
  have h : env39044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39043_39044 : H12AffineEnvironment.transform 5 16 env39043 = env39044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39043 == env39044) = true)

theorem identity39044 : scanCanonicalize (H12AffineFastState.compose env39044 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

end H12CloudChart0