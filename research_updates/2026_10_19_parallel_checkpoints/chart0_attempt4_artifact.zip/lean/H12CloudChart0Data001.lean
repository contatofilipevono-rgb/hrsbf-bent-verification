import H12CloudChart0Data000

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity249 : scanCanonicalize (H12AffineFastState.compose env249 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound249 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env250 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1092,1630,1132,634,1092,1127,571,1093,101,1092,635,33,1141,2,1133,1061,1092,1550,619,1093,1057,32,1041,33,635,513]

theorem envBound250 : H12AffineFastState.Bounded env250 := by
  intro p hp
  have h : env250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans249_250 : H12AffineEnvironment.transform 10 1092 env249 = env250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env249 == env250) = true)

def env251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,268435456,268570624,1073741824,67674549,1086893388,525568,1073743904,34359738368,98851]

theorem envBound251 : H12AffineFastState.Bounded env251 := by
  intro p hp
  have h : env251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9_251 : H12AffineEnvironment.transform 23 8988133 env9 = env251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988133 env9 == env251) = true)

theorem identity251 : scanCanonicalize (H12AffineFastState.compose env251 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13208934) := by decide +kernel

theorem selectedBound251 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,268435456,268570624,13208934,67674549,73770,525568,13206854,34359738368,98851]

theorem envBound252 : H12AffineFastState.Bounded env252 := by
  intro p hp
  have h : env252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans251_252 : H12AffineEnvironment.transform 29 13208934 env251 = env252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13208934 env251 == env252) = true)

def env253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,77615104,77742080,13208934,67674549,73770,525568,13206854,34359738368,98851]

theorem envBound253 : H12AffineFastState.Bounded env253 := by
  intro p hp
  have h : env253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans252_253 : H12AffineEnvironment.transform 27 77615104 env252 = env253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env252 == env253) = true)

theorem identity253 : scanCanonicalize (H12AffineFastState.compose env253 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566497) := by decide +kernel

theorem selectedBound253 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,566497,262280,11072737,11199713,13208934,1364,73770,525568,13206854,34359738368,98851]

theorem envBound254 : H12AffineFastState.Bounded env254 := by
  intro p hp
  have h : env254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans253_254 : H12AffineEnvironment.transform 25 566497 env253 = env254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566497 env253 == env254) = true)

def env255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988133,8328,525377,262280,11031617,11158593,13184454,1364,73770,525568,13182438,34359738368,74371]

theorem envBound255 : H12AffineFastState.Bounded env255 := by
  intro p hp
  have h : env255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans254_255 : H12AffineEnvironment.transform 14 8352 env254 = env255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env254 == env255) = true)

def env256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,8388608,8988133,8328,525377,262280,11031617,11158593,8990182,1364,73770,525568,8988102,34359738368,74371]

theorem envBound256 : H12AffineFastState.Bounded env256 := by
  intro p hp
  have h : env256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans255_256 : H12AffineEnvironment.transform 21 32 env255 = env256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env255 == env256) = true)

def env257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525328,74229,8328,525377,262280,2117713,2244689,76278,1364,73770,525568,74198,34359738368,74371]

theorem envBound257 : H12AffineFastState.Bounded env257 := by
  intro p hp
  have h : env257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans256_257 : H12AffineEnvironment.transform 22 525328 env256 = env257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env256 == env257) = true)

theorem identity257 : scanCanonicalize (H12AffineFastState.compose env257 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound257 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env258 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525328,73736,8328,525377,262280,2117713,2244689,75787,1193,73770,525565,73771,34359738368,74371]

theorem envBound258 : H12AffineFastState.Bounded env258 := by
  intro p hp
  have h : env258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans257_258 : H12AffineEnvironment.transform 7 253 env257 = env258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env257 == env258) = true)

theorem identity258 : scanCanonicalize (H12AffineFastState.compose env258 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 2894021) := by decide +kernel

theorem selectedBound258 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env259 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525328,73736,8328,525377,262280,2117713,2244689,75787,1193,73770,525565,73771,2894021,74371]

theorem envBound259 : H12AffineFastState.Bounded env259 := by
  intro p hp
  have h : env259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans258_259 : H12AffineEnvironment.transform 34 2894021 env258 = env259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2894021 env258 == env259) = true)

theorem identity259 : scanCanonicalize (H12AffineFastState.compose env259 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 203846) := by decide +kernel

theorem selectedBound259 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env260 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,203846,524288,8352,2097152,32,525328,73736,8328,525377,203982,2117713,2244689,75787,1193,73770,525565,73771,2831491,74371]

theorem envBound260 : H12AffineFastState.Bounded env260 := by
  intro p hp
  have h : env260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans259_260 : H12AffineEnvironment.transform 17 203846 env259 = env260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 203846 env259 == env260) = true)

theorem identity260 : scanCanonicalize (H12AffineFastState.compose env260 (packedSelected [1,4,8,10,11,14,15,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound260 : packedSelected [1,4,8,10,11,14,15,22] rootPS < 2^1333 := by decide +kernel

def env261 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,131072,146629,524288,8352,2097152,32,525328,139,8328,525377,146509,2117713,2244689,2184,1193,169,525565,168,2757632,512]

theorem envBound261 : H12AffineFastState.Bounded env261 := by
  intro p hp
  have h : env261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans260_261 : H12AffineEnvironment.transform 15 8323 env260 = env261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env260 == env261) = true)

theorem identity261 : scanCanonicalize (H12AffineFastState.compose env261 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound261 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env262 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,13388,2185,524288,8352,2097152,32,525328,139,8328,525377,2049,2117713,2126877,2184,1193,169,525565,168,2629708,512]

theorem envBound262 : H12AffineFastState.Bounded env262 := by
  intro p hp
  have h : env262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans261_262 : H12AffineEnvironment.transform 16 13388 env261 = env262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env261 == env262) = true)

theorem identity262 : scanCanonicalize (H12AffineFastState.compose env262 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound262 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env263 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8,16384,168,139,5188,2185,524288,168,2097152,32,525328,139,128,525377,2049,2117713,2118677,2184,1193,169,525565,168,2621508,512]

theorem envBound263 : H12AffineFastState.Bounded env263 := by
  intro p hp
  have h : env263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans262_263 : H12AffineEnvironment.transform 12 8 env262 = env263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env262 == env263) = true)

theorem identity263 : scanCanonicalize (H12AffineFastState.compose env263 (packedSelected [0,7] rootPS)) = affineNative (2^(20+1) ^^^ 16632) := by decide +kernel

theorem selectedBound263 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env264 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8,16384,168,139,5188,2185,524288,168,16632,32,525328,139,128,525377,2049,4265,5357,2184,1193,169,525565,168,540860,512]

theorem envBound264 : H12AffineFastState.Bounded env264 := by
  intro p hp
  have h : env264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans263_264 : H12AffineEnvironment.transform 20 16632 env263 = env264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16632 env263 == env264) = true)

theorem identity264 : scanCanonicalize (H12AffineFastState.compose env264 (packedSelected [1,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound264 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env265 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,1,34,5188,2080,524288,1,16465,32,525328,34,41,525377,2049,4096,5188,2081,1024,0,525396,1,540693,512]

theorem envBound265 : H12AffineFastState.Bounded env265 := by
  intro p hp
  have h : env265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans264_265 : H12AffineEnvironment.transform 6 41 env264 = env265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env264 == env265) = true)

theorem identity265 : scanCanonicalize (H12AffineFastState.compose env265 (packedSelected [2,11] rootPS)) = affineNative (2^(18+1) ^^^ 21) := by decide +kernel

theorem selectedBound265 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env266 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,1,34,5188,2080,21,1,16465,32,1029,34,41,1108,2049,4096,5188,2081,1024,0,1089,1,16384,512]

theorem envBound266 : H12AffineFastState.Bounded env266 := by
  intro p hp
  have h : env266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans265_266 : H12AffineEnvironment.transform 18 21 env265 = env266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21 env265 == env266) = true)

theorem identity266 : scanCanonicalize (H12AffineFastState.compose env266 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env267 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,1093,1,34,5188,2080,21,1,1044,32,1029,34,41,1108,2049,4096,5188,2081,1024,0,1089,1,1093,512]

theorem envBound267 : H12AffineFastState.Bounded env267 := by
  intro p hp
  have h : env267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans266_267 : H12AffineEnvironment.transform 13 1093 env266 = env267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env266 == env267) = true)

theorem identity267 : scanCanonicalize (H12AffineFastState.compose env267 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env268 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1566,4096,8,1093,1,34,5188,1598,21,1,1044,32,1029,34,41,1108,1567,4096,5188,1599,1024,0,1089,1,1093,512]

theorem envBound268 : H12AffineFastState.Bounded env268 := by
  intro p hp
  have h : env268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans267_268 : H12AffineEnvironment.transform 10 1566 env267 = env268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env267 == env268) = true)

theorem identity268 : scanCanonicalize (H12AffineFastState.compose env268 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1663) := by decide +kernel

theorem selectedBound268 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env269 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1566,1663,8,1093,1,34,571,1598,21,1,1044,32,1029,34,41,1108,1567,1663,571,1599,1024,0,1089,1,1093,512]

theorem envBound269 : H12AffineFastState.Bounded env269 := by
  intro p hp
  have h : env269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans268_269 : H12AffineEnvironment.transform 11 1663 env268 = env269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1663 env268 == env269) = true)

theorem identity269 : scanCanonicalize (H12AffineFastState.compose env269 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound269 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env270 : List Nat := [2,4,8,16,32,64,41,84,512,543,1,96,8,602,1,34,571,33,21,1,523,32,538,34,41,587,0,96,571,32,543,0,606,1,602,512]

theorem envBound270 : H12AffineFastState.Bounded env270 := by
  intro p hp
  have h : env270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans269_270 : H12AffineEnvironment.transform 9 543 env269 = env270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env269 == env270) = true)

theorem identity270 : scanCanonicalize (H12AffineFastState.compose env270 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 89) := by decide +kernel

theorem selectedBound270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env271 : List Nat := [2,4,8,16,32,64,41,84,89,70,1,96,8,3,1,34,98,33,21,1,82,32,67,34,41,18,0,96,98,32,70,0,7,1,3,89]

theorem envBound271 : H12AffineFastState.Bounded env271 := by
  intro p hp
  have h : env271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans270_271 : H12AffineEnvironment.transform 8 89 env270 = env271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 89 env270 == env271) = true)

def env272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525329,74228,8328,525377,262280,2117712,2244688,76279,1364,73770,525568,74199,34359738368,74371]

theorem envBound272 : H12AffineFastState.Bounded env272 := by
  intro p hp
  have h : env272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans256_272 : H12AffineEnvironment.transform 22 525329 env256 = env272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env256 == env272) = true)

theorem identity272 : scanCanonicalize (H12AffineFastState.compose env272 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound272 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,525329,74228,8328,525377,262280,2117712,2244688,76279,1364,73770,525568,74199,280712,74371]

theorem envBound273 : H12AffineFastState.Bounded env273 := by
  intro p hp
  have h : env273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans272_273 : H12AffineEnvironment.transform 34 280712 env272 = env273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env272 == env273) = true)

theorem identity273 : scanCanonicalize (H12AffineFastState.compose env273 (packedSelected [0,1,5,7,8,9,14,18,20,22,23,24] rootPS)) = affineNative (2^(20+1) ^^^ 676865) := by decide +kernel

theorem selectedBound273 : packedSelected [0,1,5,7,8,9,14,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,676865,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,280712,74371]

theorem envBound274 : H12AffineFastState.Bounded env274 := by
  intro p hp
  have h : env274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans273_274 : H12AffineEnvironment.transform 20 676865 env273 = env274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 676865 env273 == env274) = true)

def env275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8352,65536,131072,262144,524288,8352,656585,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,268352,74371]

theorem envBound275 : H12AffineFastState.Bounded env275 := by
  intro p hp
  have h : env275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans274_275 : H12AffineEnvironment.transform 13 4296 env274 = env275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env274 == env275) = true)

theorem identity275 : scanCanonicalize (H12AffineFastState.compose env275 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 272) := by decide +kernel

theorem selectedBound275 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8352,65536,131072,262144,272,8352,132569,32,1281,74228,8328,1361,262280,132417,5441,76279,1364,73770,1040,74199,268352,74371]

theorem envBound276 : H12AffineFastState.Bounded env276 := by
  intro p hp
  have h : env276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans275_276 : H12AffineEnvironment.transform 18 272 env275 = env276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env275 == env276) = true)

def env277 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4296,8352,65536,131072,262144,236,8352,132133,32,1277,73736,8328,1197,262280,132285,5309,75787,1192,73770,1040,73771,268352,74371]

theorem envBound277 : H12AffineFastState.Bounded env277 := by
  intro p hp
  have h : env277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans276_277 : H12AffineEnvironment.transform 7 252 env276 = env277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env276 == env277) = true)

theorem identity277 : scanCanonicalize (H12AffineFastState.compose env277 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound277 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env278 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4296,8352,65536,5221,262144,236,8352,4160,32,1277,73736,8328,1197,262280,4312,5309,75787,1192,73770,1040,73771,268352,74371]

theorem envBound278 : H12AffineFastState.Bounded env278 := by
  intro p hp
  have h : env278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans277_278 : H12AffineEnvironment.transform 16 5221 env277 = env278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env277 == env278) = true)

theorem identity278 : scanCanonicalize (H12AffineFastState.compose env278 (packedSelected [1,2,4,8,9,10,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound278 : packedSelected [1,2,4,8,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env279 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8233,65536,5221,262144,101,8233,4160,32,1140,73736,8193,1060,262145,4177,5172,75787,1057,73770,1040,73771,268352,74250]

theorem envBound279 : H12AffineFastState.Bounded env279 := by
  intro p hp
  have h : env279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans278_279 : H12AffineEnvironment.transform 6 9 env278 = env279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env278 == env279) = true)

theorem identity279 : scanCanonicalize (H12AffineFastState.compose env279 (packedSelected [4,6,9,11,12,20] rootPS)) = affineNative (2^(17+1) ^^^ 13324) := by decide +kernel

theorem selectedBound279 : packedSelected [4,6,9,11,12,20] rootPS < 2^1333 := by decide +kernel

def env280 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8233,65536,5221,13324,101,8233,4160,32,1140,73736,8193,1060,13325,4177,5172,75787,1057,73770,1040,73771,11340,74250]

theorem envBound280 : H12AffineFastState.Bounded env280 := by
  intro p hp
  have h : env280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans279_280 : H12AffineEnvironment.transform 17 13324 env279 = env280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13324 env279 == env280) = true)

theorem identity280 : scanCanonicalize (H12AffineFastState.compose env280 (packedSelected [3,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 6242) := by decide +kernel

theorem selectedBound280 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env281 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8233,6242,5221,13324,101,8233,4160,32,1140,14442,8193,1060,13325,4177,5172,12393,1057,14408,1040,14409,11340,14952]

theorem envBound281 : H12AffineFastState.Bounded env281 := by
  intro p hp
  have h : env281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans280_281 : H12AffineEnvironment.transform 15 6242 env280 = env281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6242 env280 == env281) = true)

theorem identity281 : scanCanonicalize (H12AffineFastState.compose env281 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound281 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env282 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,8192,4161,8233,6242,4096,12393,101,8233,4160,32,17,14442,8193,65,12392,4177,4177,12393,68,14408,117,14409,10281,14952]

theorem envBound282 : H12AffineFastState.Bounded env282 := by
  intro p hp
  have h : env282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans281_282 : H12AffineEnvironment.transform 9 101 env281 = env282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env281 == env282) = true)

theorem identity282 : scanCanonicalize (H12AffineFastState.compose env282 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound282 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env283 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,4096,8192,4161,8233,4194,4096,12393,101,8233,4160,32,17,12394,8193,65,12392,4177,4177,12393,68,12360,117,12361,8233,12904]

theorem envBound283 : H12AffineFastState.Bounded env283 := by
  intro p hp
  have h : env283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans282_283 : H12AffineEnvironment.transform 10 0 env282 = env283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env282 == env283) = true)

theorem identity283 : scanCanonicalize (H12AffineFastState.compose env283 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 91) := by decide +kernel

theorem selectedBound283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env284 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,4096,91,4161,114,4194,4096,4146,101,114,4160,32,17,4145,90,65,4147,4177,4177,4146,68,4115,117,4114,114,4659]

theorem envBound284 : H12AffineFastState.Bounded env284 := by
  intro p hp
  have h : env284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans283_284 : H12AffineEnvironment.transform 12 91 env283 = env284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 91 env283 == env284) = true)

theorem identity284 : scanCanonicalize (H12AffineFastState.compose env284 (packedSelected [1,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 51) := by decide +kernel

theorem selectedBound284 : packedSelected [1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env285 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,51,91,114,114,81,51,1,101,114,115,32,17,2,90,65,0,98,98,1,68,32,117,33,114,512]

theorem envBound285 : H12AffineFastState.Bounded env285 := by
  intro p hp
  have h : env285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans284_285 : H12AffineEnvironment.transform 11 51 env284 = env285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 51 env284 == env285) = true)

theorem identity285 : scanCanonicalize (H12AffineFastState.compose env285 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env286 : List Nat := [2,4,8,16,32,48,9,5,512,21,0,51,43,2,2,33,51,1,21,2,3,32,17,2,42,49,0,18,18,1,52,32,5,33,2,512]

theorem envBound286 : H12AffineFastState.Bounded env286 := by
  intro p hp
  have h : env286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans285_286 : H12AffineEnvironment.transform 5 48 env285 = env286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env285 == env286) = true)

theorem identity286 : scanCanonicalize (H12AffineFastState.compose env286 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound286 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env287 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,18,10,2,2,0,18,1,21,2,3,1,17,2,11,16,0,18,18,1,21,1,5,0,2,512]

theorem envBound287 : H12AffineFastState.Bounded env287 := by
  intro p hp
  have h : env287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans286_287 : H12AffineEnvironment.transform 4 1 env286 = env287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env286 == env287) = true)

theorem identity287 : scanCanonicalize (H12AffineFastState.compose env287 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound287 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env288 : List Nat := [2,4,8,16,1,17,9,5,29,21,0,18,10,2,2,0,18,1,21,2,3,1,17,2,11,16,0,18,18,1,21,1,5,0,2,29]

theorem envBound288 : H12AffineFastState.Bounded env288 := by
  intro p hp
  have h : env288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans287_288 : H12AffineEnvironment.transform 8 29 env287 = env288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env287 == env288) = true)

theorem identity288 : scanCanonicalize (H12AffineFastState.compose env288 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound288 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env289 : List Nat := [2,4,8,5,1,4,9,5,8,0,0,7,10,2,2,0,7,1,0,2,3,1,4,2,11,5,0,7,7,1,0,1,5,0,2,8]

theorem envBound289 : H12AffineFastState.Bounded env289 := by
  intro p hp
  have h : env289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans288_289 : H12AffineEnvironment.transform 3 5 env288 = env289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env288 == env289) = true)

theorem identity289 : scanCanonicalize (H12AffineFastState.compose env289 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound289 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env290 : List Nat := [0,4,8,5,1,4,9,5,8,0,0,5,8,0,0,0,5,1,0,0,1,1,4,0,9,5,0,5,5,1,0,1,5,0,0,8]

theorem envBound290 : H12AffineFastState.Bounded env290 := by
  intro p hp
  have h : env290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans289_290 : H12AffineEnvironment.transform 0 0 env289 = env290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env289 == env290) = true)

def env291 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,65536,131072,262144,237,8352,132132,32,1276,73737,8328,1196,262280,132284,5308,75786,1193,73770,1040,73770,268352,74371]

theorem envBound291 : H12AffineFastState.Bounded env291 := by
  intro p hp
  have h : env291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans276_291 : H12AffineEnvironment.transform 7 253 env276 = env291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env276 == env291) = true)

def env292 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,65536,131072,2184,237,8352,132132,32,1276,73737,8328,1196,2048,132284,5308,75786,1193,73770,1040,73770,4296,74371]

theorem envBound292 : H12AffineFastState.Bounded env292 := by
  intro p hp
  have h : env292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans291_292 : H12AffineEnvironment.transform 17 2184 env291 = env292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env291 == env292) = true)

theorem identity292 : scanCanonicalize (H12AffineFastState.compose env292 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound292 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env293 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,8323,131072,2184,237,8352,132132,32,1276,138,8328,1196,2048,132284,5308,2185,1193,169,1040,169,4296,512]

theorem envBound293 : H12AffineFastState.Bounded env293 := by
  intro p hp
  have h : env293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans292_293 : H12AffineEnvironment.transform 15 8323 env292 = env293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env292 == env293) = true)

theorem identity293 : scanCanonicalize (H12AffineFastState.compose env293 (packedSelected [2] rootPS)) = affineNative (2^(16+1) ^^^ 12360) := by decide +kernel

theorem selectedBound293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env294 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,8323,12360,2184,237,8352,13420,32,1276,138,8328,1196,2048,13556,5308,2185,1193,169,1040,169,4296,512]

theorem envBound294 : H12AffineFastState.Bounded env294 := by
  intro p hp
  have h : env294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans293_294 : H12AffineEnvironment.transform 16 12360 env293 = env294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12360 env293 == env294) = true)

theorem identity294 : scanCanonicalize (H12AffineFastState.compose env294 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound294 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env295 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,593,8192,665,8352,8323,8729,2184,237,8352,9789,32,1276,138,8328,1196,2048,9893,1773,2185,1193,169,1040,169,665,512]

theorem envBound295 : H12AffineFastState.Bounded env295 := by
  intro p hp
  have h : env295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans294_295 : H12AffineEnvironment.transform 11 593 env294 = env295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env294 == env295) = true)

theorem identity295 : scanCanonicalize (H12AffineFastState.compose env295 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 3703) := by decide +kernel

theorem selectedBound295 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env296 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,593,3703,665,3799,3828,3182,2184,237,3799,2122,32,1276,138,3839,1196,2048,2258,1773,2185,1193,169,1040,169,665,512]

theorem envBound296 : H12AffineFastState.Bounded env296 := by
  intro p hp
  have h : env296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans295_296 : H12AffineEnvironment.transform 12 3703 env295 = env296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3703 env295 == env296) = true)

theorem identity296 : scanCanonicalize (H12AffineFastState.compose env296 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 625) := by decide +kernel

theorem selectedBound296 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env297 : List Nat := [2,4,8,16,32,64,128,253,512,1024,625,593,1030,665,1190,1157,1567,761,237,1190,571,32,1276,138,1166,1196,625,675,1773,760,1193,169,1040,169,665,512]

theorem envBound297 : H12AffineFastState.Bounded env297 := by
  intro p hp
  have h : env297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans296_297 : H12AffineEnvironment.transform 10 625 env296 = env297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 625 env296 == env297) = true)

theorem identity297 : scanCanonicalize (H12AffineFastState.compose env297 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound297 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env298 : List Nat := [2,4,8,16,32,64,128,253,512,4,625,593,2,665,162,129,539,761,237,162,571,32,248,138,138,168,625,675,745,760,173,169,20,169,665,512]

theorem envBound298 : H12AffineFastState.Bounded env298 := by
  intro p hp
  have h : env298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans297_298 : H12AffineEnvironment.transform 9 4 env297 = env298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env297 == env298) = true)

theorem identity298 : scanCanonicalize (H12AffineFastState.compose env298 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound298 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env299 : List Nat := [2,4,8,16,32,32,128,157,512,4,529,561,2,665,162,129,539,665,141,162,571,32,152,138,138,168,529,675,649,664,173,169,20,169,665,512]

theorem envBound299 : H12AffineFastState.Bounded env299 := by
  intro p hp
  have h : env299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans298_299 : H12AffineEnvironment.transform 5 32 env298 = env299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env298 == env299) = true)

theorem identity299 : scanCanonicalize (H12AffineFastState.compose env299 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound299 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env300 : List Nat := [2,4,8,16,32,32,35,62,512,4,529,561,2,570,1,34,539,570,46,1,571,32,59,41,41,11,529,512,554,571,14,10,20,10,570,512]

theorem envBound300 : H12AffineFastState.Bounded env300 := by
  intro p hp
  have h : env300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans299_300 : H12AffineEnvironment.transform 6 35 env299 = env300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env299 == env300) = true)

theorem identity300 : scanCanonicalize (H12AffineFastState.compose env300 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound300 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env301 : List Nat := [2,4,8,11,32,32,35,37,512,4,522,554,2,545,1,34,512,545,46,1,544,32,32,41,41,11,522,512,554,544,14,10,15,10,545,512]

theorem envBound301 : H12AffineFastState.Bounded env301 := by
  intro p hp
  have h : env301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans300_301 : H12AffineEnvironment.transform 3 11 env300 = env301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env300 == env301) = true)

theorem identity301 : scanCanonicalize (H12AffineFastState.compose env301 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound301 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env302 : List Nat := [2,4,8,11,32,32,35,37,6,4,12,44,2,39,1,34,6,39,46,1,38,32,32,41,41,11,12,6,44,38,14,10,15,10,39,6]

theorem envBound302 : H12AffineFastState.Bounded env302 := by
  intro p hp
  have h : env302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans301_302 : H12AffineEnvironment.transform 8 6 env301 = env302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env301 == env302) = true)

def env303 : List Nat := [2,4,8,11,12,12,15,9,6,4,12,0,2,11,1,14,6,11,2,1,10,12,12,5,5,11,12,6,0,10,14,10,15,10,11,6]

theorem envBound303 : H12AffineFastState.Bounded env303 := by
  intro p hp
  have h : env303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans302_303 : H12AffineEnvironment.transform 4 12 env302 = env303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env302 == env303) = true)

theorem identity303 : scanCanonicalize (H12AffineFastState.compose env303 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound303 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env304 : List Nat := [2,1,8,11,9,9,10,9,3,1,9,0,2,11,1,11,3,11,2,1,10,9,9,0,0,11,9,3,0,10,11,10,10,10,11,3]

theorem envBound304 : H12AffineFastState.Bounded env304 := by
  intro p hp
  have h : env304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans303_304 : H12AffineEnvironment.transform 1 1 env303 = env304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env303 == env304) = true)

def leafEnv304 : List Nat := [2,1,8,11,9,9,10,9,3,1,9,0,2,11,1,11,3,11,2,1,10,9,9,0,8,0,1,11,9,3,0,10,11,10,10,10,2,9,11,3,1,11,0]

def active304 : List Nat := [0,2]

def tree304 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood304 : H12WitnessSearch.Good tree304 := H12GlobalWitnessIndex.good

theorem leafIdentity304 : H12AffineFastState.composeSystem env304 rootObs = leafEnv304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env304 rootObs == leafEnv304) = true)

theorem terminalChecked304 : H12PackedTerminal.terminalCheckFast leafEnv304 active304 tree304 = true := by decide +kernel

def env305 : List Nat := [2,4,8,11,13,13,14,8,6,4,12,1,2,10,1,15,6,10,3,1,11,13,13,4,4,11,12,6,1,11,14,10,15,10,10,6]

theorem envBound305 : H12AffineFastState.Bounded env305 := by
  intro p hp
  have h : env305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans302_305 : H12AffineEnvironment.transform 4 13 env302 = env305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env302 == env305) = true)

theorem identity305 : scanCanonicalize (H12AffineFastState.compose env305 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env306 : List Nat := [0,4,8,9,13,13,12,8,4,4,12,1,0,8,1,13,4,8,1,1,9,13,13,4,4,9,12,4,1,9,12,8,13,8,8,4]

theorem envBound306 : H12AffineFastState.Bounded env306 := by
  intro p hp
  have h : env306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans305_306 : H12AffineEnvironment.transform 0 0 env305 = env306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env305 == env306) = true)

def leafEnv306 : List Nat := [0,4,8,9,13,13,12,8,4,4,12,1,0,8,1,13,4,8,1,1,9,13,13,4,9,4,1,9,12,4,1,9,12,8,13,8,1,9,8,4,1,8,0]

def active306 : List Nat := [1,2]

def tree306 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood306 : H12WitnessSearch.Good tree306 := H12GlobalWitnessIndex.good

theorem leafIdentity306 : H12AffineFastState.composeSystem env306 rootObs = leafEnv306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env306 rootObs == leafEnv306) = true)

theorem terminalChecked306 : H12PackedTerminal.terminalCheckFast leafEnv306 active306 tree306 = true := by decide +kernel

def env307 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,65536,131072,2185,237,8352,132132,32,1276,73737,8328,1196,2049,132284,5308,75786,1193,73770,1040,73770,4297,74371]

theorem envBound307 : H12AffineFastState.Bounded env307 := by
  intro p hp
  have h : env307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans291_307 : H12AffineEnvironment.transform 17 2185 env291 = env307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env291 == env307) = true)

theorem identity307 : scanCanonicalize (H12AffineFastState.compose env307 (packedSelected [0,4,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 9871) := by decide +kernel

theorem selectedBound307 : packedSelected [0,4,11,12] rootPS < 2^1333 := by decide +kernel

def env308 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8352,65536,9871,2185,237,8352,8875,32,1276,73737,8328,1196,2049,8755,5308,75786,1193,73770,1040,73770,4297,74371]

theorem envBound308 : H12AffineFastState.Bounded env308 := by
  intro p hp
  have h : env308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans307_308 : H12AffineEnvironment.transform 16 9871 env307 = env308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 9871 env307 == env308) = true)

theorem identity308 : scanCanonicalize (H12AffineFastState.compose env308 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound308 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env309 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,4096,8192,4296,8352,65536,9871,1766,237,8352,8875,32,1276,73737,8328,1196,1646,8755,5308,75365,1193,73770,1040,73770,4297,74371]

theorem envBound309 : H12AffineFastState.Bounded env309 := by
  intro p hp
  have h : env309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans308_309 : H12AffineEnvironment.transform 10 1647 env308 = env309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env308 == env309) = true)

def env310 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,4096,1148,4296,1244,65536,755,1766,237,1244,1751,32,1276,66677,1268,1196,1646,1615,5308,66073,1193,66646,1040,66646,4297,67327]

theorem envBound310 : H12AffineFastState.Bounded env310 := by
  intro p hp
  have h : env310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans309_310 : H12AffineEnvironment.transform 12 1148 env309 = env310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1148 env309 == env310) = true)

theorem identity310 : scanCanonicalize (H12AffineFastState.compose env310 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1687) := by decide +kernel

theorem selectedBound310 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env311 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,1687,1148,1631,1244,65536,755,1766,237,1244,1751,32,1276,66677,1268,1196,1646,1615,555,66073,1193,66646,1040,66646,1630,67327]

theorem envBound311 : H12AffineFastState.Bounded env311 := by
  intro p hp
  have h : env311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans310_311 : H12AffineEnvironment.transform 11 1687 env310 = env311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1687 env310 == env311) = true)

def env312 : List Nat := [2,4,8,16,32,64,128,253,512,172,707,571,208,755,112,65536,755,586,237,112,635,32,80,65753,88,0,706,739,555,66073,5,65786,188,65786,754,66131]

theorem envBound312 : H12AffineFastState.Bounded env312 := by
  intro p hp
  have h : env312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans311_312 : H12AffineEnvironment.transform 9 172 env311 = env312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env311 == env312) = true)

theorem identity312 : scanCanonicalize (H12AffineFastState.compose env312 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound312 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env313 : List Nat := [2,4,8,16,32,64,128,253,512,172,707,571,208,755,112,83,755,586,237,112,635,32,80,138,88,0,706,739,555,586,5,169,188,169,754,512]

theorem envBound313 : H12AffineFastState.Bounded env313 := by
  intro p hp
  have h : env313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans312_313 : H12AffineEnvironment.transform 15 83 env312 = env313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env312 == env313) = true)

theorem identity313 : scanCanonicalize (H12AffineFastState.compose env313 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound313 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env314 : List Nat := [2,4,8,16,20,64,128,201,512,152,707,527,208,711,68,83,711,586,217,68,591,20,80,138,88,0,706,727,543,586,5,157,136,157,710,512]

theorem envBound314 : H12AffineFastState.Bounded env314 := by
  intro p hp
  have h : env314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans313_314 : H12AffineEnvironment.transform 4 20 env313 = env314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env313 == env314) = true)

theorem identity314 : scanCanonicalize (H12AffineFastState.compose env314 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound314 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env315 : List Nat := [2,4,8,16,20,64,6,79,512,30,581,527,86,577,68,83,577,586,95,68,591,20,80,12,88,0,580,593,543,586,5,27,14,27,576,512]

theorem envBound315 : H12AffineFastState.Bounded env315 := by
  intro p hp
  have h : env315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans314_315 : H12AffineEnvironment.transform 6 6 env314 = env315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env314 == env315) = true)

theorem identity315 : scanCanonicalize (H12AffineFastState.compose env315 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env316 : List Nat := [2,4,8,4,0,64,6,79,512,10,581,527,66,577,68,71,577,586,75,68,591,0,68,12,76,0,580,581,523,586,5,15,14,15,576,512]

theorem envBound316 : H12AffineFastState.Bounded env316 := by
  intro p hp
  have h : env316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans315_316 : H12AffineEnvironment.transform 3 4 env315 = env316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env315 == env316) = true)

theorem identity316 : scanCanonicalize (H12AffineFastState.compose env316 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound316 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env317 : List Nat := [2,4,8,4,0,10,6,5,512,10,527,527,8,523,14,13,523,512,1,14,517,0,14,12,6,0,526,527,523,512,5,15,14,15,522,512]

theorem envBound317 : H12AffineFastState.Bounded env317 := by
  intro p hp
  have h : env317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans316_317 : H12AffineEnvironment.transform 5 10 env316 = env317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env316 == env317) = true)

theorem identity317 : scanCanonicalize (H12AffineFastState.compose env317 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound317 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env318 : List Nat := [2,4,7,4,0,5,6,5,512,5,512,512,7,516,1,2,516,512,1,1,517,0,1,3,6,0,513,512,516,512,5,0,1,0,517,512]

theorem envBound318 : H12AffineFastState.Bounded env318 := by
  intro p hp
  have h : env318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans317_318 : H12AffineEnvironment.transform 2 7 env317 = env318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env317 == env318) = true)

theorem identity318 : scanCanonicalize (H12AffineFastState.compose env318 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env319 : List Nat := [2,4,7,4,0,5,6,5,3,5,3,3,7,7,1,2,7,3,1,1,6,0,1,3,6,0,2,3,7,3,5,0,1,0,6,3]

theorem envBound319 : H12AffineFastState.Bounded env319 := by
  intro p hp
  have h : env319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans318_319 : H12AffineEnvironment.transform 8 3 env318 = env319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env318 == env319) = true)

theorem identity319 : scanCanonicalize (H12AffineFastState.compose env319 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound319 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env320 : List Nat := [2,0,3,0,0,1,2,1,3,1,3,3,3,3,1,2,3,3,1,1,2,0,1,3,2,0,2,3,3,3,1,0,1,0,2,3]

theorem envBound320 : H12AffineFastState.Bounded env320 := by
  intro p hp
  have h : env320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans319_320 : H12AffineEnvironment.transform 1 0 env319 = env320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env319 == env320) = true)

def leafEnv320 : List Nat := [2,0,3,0,0,1,2,1,3,1,3,3,3,3,1,2,3,3,1,1,2,0,1,3,1,2,1,0,2,3,3,3,1,0,1,0,0,3,2,3,1,2,0]

def active320 : List Nat := [0]

def tree320 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood320 : H12WitnessSearch.Good tree320 := H12GlobalWitnessIndex.good

theorem leafIdentity320 : H12AffineFastState.composeSystem env320 rootObs = leafEnv320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env320 rootObs == leafEnv320) = true)

theorem terminalChecked320 : H12PackedTerminal.terminalCheckFast leafEnv320 active320 tree320 = true := by decide +kernel

def env321 : List Nat := [2,4,8,16,32,64,128,253,512,173,706,570,209,754,113,65536,755,587,237,113,634,32,81,65752,89,1,707,738,555,66073,4,65787,189,65787,755,66130]

theorem envBound321 : H12AffineFastState.Bounded env321 := by
  intro p hp
  have h : env321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans311_321 : H12AffineEnvironment.transform 9 173 env311 = env321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env311 == env321) = true)

def env322 : List Nat := [2,4,8,16,32,64,128,253,52,173,246,14,209,198,113,65536,199,127,237,113,78,32,81,65752,89,1,247,214,31,65581,4,65787,189,65787,199,65638]

theorem envBound322 : H12AffineFastState.Bounded env322 := by
  intro p hp
  have h : env322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans321_322 : H12AffineEnvironment.transform 8 52 env321 = env322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env321 == env322) = true)

theorem identity322 : scanCanonicalize (H12AffineFastState.compose env322 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 109) := by decide +kernel

theorem selectedBound322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env323 : List Nat := [2,4,8,16,32,64,109,16,52,64,27,14,60,43,113,65536,42,127,0,113,78,32,81,65589,89,1,26,59,31,65581,4,65558,80,65558,42,65638]

theorem envBound323 : H12AffineFastState.Bounded env323 := by
  intro p hp
  have h : env323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans322_323 : H12AffineEnvironment.transform 6 109 env322 = env323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 109 env322 == env323) = true)

def env324 : List Nat := [2,4,8,16,32,64,109,16,52,64,27,14,60,43,113,12,42,127,0,113,78,32,81,57,89,1,26,59,31,33,4,26,80,26,42,106]

theorem envBound324 : H12AffineFastState.Bounded env324 := by
  intro p hp
  have h : env324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans323_324 : H12AffineEnvironment.transform 15 12 env323 = env324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12 env323 == env324) = true)

def env325 : List Nat := [2,4,8,4,32,64,109,4,32,64,15,14,40,43,101,12,42,107,0,101,78,32,69,45,77,1,14,47,11,33,4,14,68,14,42,106]

theorem envBound325 : H12AffineFastState.Bounded env325 := by
  intro p hp
  have h : env325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans324_325 : H12AffineEnvironment.transform 3 4 env324 = env325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env324 == env325) = true)

def env326 : List Nat := [2,4,8,4,32,36,9,4,32,36,15,14,40,43,1,12,42,15,0,1,42,32,33,45,41,1,14,47,11,33,4,14,32,14,42,14]

theorem envBound326 : H12AffineFastState.Bounded env326 := by
  intro p hp
  have h : env326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans325_326 : H12AffineEnvironment.transform 5 36 env325 = env326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env325 == env326) = true)

theorem identity326 : scanCanonicalize (H12AffineFastState.compose env326 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound326 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env327 : List Nat := [2,4,8,4,6,2,9,4,6,2,15,14,14,13,1,12,12,15,0,1,12,6,7,11,15,1,14,9,11,7,4,14,6,14,12,14]

theorem envBound327 : H12AffineFastState.Bounded env327 := by
  intro p hp
  have h : env327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans326_327 : H12AffineEnvironment.transform 4 6 env326 = env327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env326 == env327) = true)

def env328 : List Nat := [2,4,0,4,6,2,1,4,6,2,7,6,6,5,1,4,4,7,0,1,4,6,7,3,7,1,6,1,3,7,4,6,6,6,4,6]

theorem envBound328 : H12AffineFastState.Bounded env328 := by
  intro p hp
  have h : env328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans327_328 : H12AffineEnvironment.transform 2 0 env327 = env328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env327 == env328) = true)

theorem identity328 : scanCanonicalize (H12AffineFastState.compose env328 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound328 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env329 : List Nat := [2,3,0,3,1,2,1,3,1,2,0,1,1,2,1,3,3,0,0,1,3,1,0,3,0,1,1,1,3,0,3,1,1,1,3,1]

theorem envBound329 : H12AffineFastState.Bounded env329 := by
  intro p hp
  have h : env329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans328_329 : H12AffineEnvironment.transform 1 3 env328 = env329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env328 == env329) = true)

theorem identity329 : scanCanonicalize (H12AffineFastState.compose env329 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound329 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env330 : List Nat := [0,1,0,1,1,0,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,1,0,1,0,1,1,1,1,0,1,1,1,1,1,1]

theorem envBound330 : H12AffineFastState.Bounded env330 := by
  intro p hp
  have h : env330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans329_330 : H12AffineEnvironment.transform 0 0 env329 = env330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env329 == env330) = true)

def leafEnv330 : List Nat := [0,1,0,1,1,0,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,0]

def active330 : List Nat := []

def tree330 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood330 : H12WitnessSearch.Good tree330 := H12GlobalWitnessIndex.good

theorem leafIdentity330 : H12AffineFastState.composeSystem env330 rootObs = leafEnv330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env330 rootObs == leafEnv330) = true)

theorem terminalChecked330 : H12PackedTerminal.terminalCheckFast leafEnv330 active330 tree330 = true := by decide +kernel

def env331 : List Nat := [2,4,1,4,6,2,0,4,6,2,6,7,7,4,1,5,5,6,0,1,5,6,7,2,6,1,7,0,2,7,4,7,6,7,5,7]

theorem envBound331 : H12AffineFastState.Bounded env331 := by
  intro p hp
  have h : env331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans327_331 : H12AffineEnvironment.transform 2 1 env327 = env331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env327 == env331) = true)

def leafEnv331 : List Nat := [2,4,1,4,6,2,0,4,6,2,6,7,7,4,1,5,5,6,0,1,5,6,7,2,6,6,1,1,7,0,2,7,4,7,6,7,6,5,5,7,1,4,0]

def active331 : List Nat := [0,1]

def tree331 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood331 : H12WitnessSearch.Good tree331 := H12GlobalWitnessIndex.good

theorem leafIdentity331 : H12AffineFastState.composeSystem env331 rootObs = leafEnv331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env331 rootObs == leafEnv331) = true)

theorem terminalChecked331 : H12PackedTerminal.terminalCheckFast leafEnv331 active331 tree331 = true := by decide +kernel

def env332 : List Nat := [2,4,8,4,32,37,8,4,32,37,15,14,40,43,0,12,42,14,0,0,43,32,32,45,40,1,14,47,11,33,4,14,33,14,42,15]

theorem envBound332 : H12AffineFastState.Bounded env332 := by
  intro p hp
  have h : env332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans325_332 : H12AffineEnvironment.transform 5 37 env325 = env332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 37 env325 == env332) = true)

theorem identity332 : scanCanonicalize (H12AffineFastState.compose env332 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound332 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env333 : List Nat := [2,4,4,4,32,37,4,4,32,37,3,2,36,39,0,0,38,2,0,0,39,32,32,33,36,1,2,35,7,33,4,2,33,2,38,3]

theorem envBound333 : H12AffineFastState.Bounded env333 := by
  intro p hp
  have h : env333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans332_333 : H12AffineEnvironment.transform 2 4 env332 = env333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env332 == env333) = true)

theorem identity333 : scanCanonicalize (H12AffineFastState.compose env333 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound333 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env334 : List Nat := [2,4,4,4,2,7,4,4,2,7,3,2,6,5,0,0,4,2,0,0,5,2,2,3,6,1,2,1,7,3,4,2,3,2,4,3]

theorem envBound334 : H12AffineFastState.Bounded env334 := by
  intro p hp
  have h : env334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans333_334 : H12AffineEnvironment.transform 4 2 env333 = env334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env333 == env334) = true)

def leafEnv334 : List Nat := [2,4,4,4,2,7,4,4,2,7,3,2,6,5,0,0,4,2,0,0,5,2,2,3,3,6,1,1,2,1,7,3,4,2,3,2,3,1,4,3,1,4,0]

def active334 : List Nat := [0,1]

def tree334 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood334 : H12WitnessSearch.Good tree334 := H12GlobalWitnessIndex.good

theorem leafIdentity334 : H12AffineFastState.composeSystem env334 rootObs = leafEnv334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env334 rootObs == leafEnv334) = true)

theorem terminalChecked334 : H12PackedTerminal.terminalCheckFast leafEnv334 active334 tree334 = true := by decide +kernel

def env335 : List Nat := [2,4,8,5,32,64,109,5,33,64,14,14,41,43,100,12,42,106,0,100,78,32,68,44,76,1,15,46,10,33,4,15,69,15,42,106]

theorem envBound335 : H12AffineFastState.Bounded env335 := by
  intro p hp
  have h : env335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans324_335 : H12AffineEnvironment.transform 3 5 env324 = env335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env324 == env335) = true)

theorem identity335 : scanCanonicalize (H12AffineFastState.compose env335 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound335 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env336 : List Nat := [2,4,8,5,32,10,39,5,33,10,14,14,41,43,46,12,42,32,0,46,4,32,14,44,6,1,15,46,10,33,4,15,15,15,42,32]

theorem envBound336 : H12AffineFastState.Bounded env336 := by
  intro p hp
  have h : env336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans335_336 : H12AffineEnvironment.transform 5 10 env335 = env336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env335 == env336) = true)

def env337 : List Nat := [2,0,8,1,32,10,35,1,33,10,10,10,41,43,42,8,42,32,0,42,0,32,10,40,2,1,11,42,10,33,0,11,11,11,42,32]

theorem envBound337 : H12AffineFastState.Bounded env337 := by
  intro p hp
  have h : env337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans336_337 : H12AffineEnvironment.transform 1 0 env336 = env337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env336 == env337) = true)

theorem identity337 : scanCanonicalize (H12AffineFastState.compose env337 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env338 : List Nat := [2,0,8,1,8,10,11,1,9,10,10,10,1,3,2,8,2,8,0,2,0,8,10,0,2,1,11,2,10,9,0,11,11,11,2,8]

theorem envBound338 : H12AffineFastState.Bounded env338 := by
  intro p hp
  have h : env338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans337_338 : H12AffineEnvironment.transform 4 8 env337 = env338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env337 == env338) = true)

def leafEnv338 : List Nat := [2,0,8,1,8,10,11,1,9,10,10,10,1,3,2,8,2,8,0,2,0,8,10,0,10,2,1,1,11,2,10,9,0,11,11,11,10,10,2,8,1,1,0]

def active338 : List Nat := [0,2]

def tree338 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood338 : H12WitnessSearch.Good tree338 := H12GlobalWitnessIndex.good

theorem leafIdentity338 : H12AffineFastState.composeSystem env338 rootObs = leafEnv338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env338 rootObs == leafEnv338) = true)

theorem terminalChecked338 : H12PackedTerminal.terminalCheckFast leafEnv338 active338 tree338 = true := by decide +kernel

def env339 : List Nat := [2,1,8,0,32,10,34,0,33,10,11,11,41,43,43,9,42,32,0,43,1,32,11,41,3,1,10,43,10,33,1,10,10,10,42,32]

theorem envBound339 : H12AffineFastState.Bounded env339 := by
  intro p hp
  have h : env339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans336_339 : H12AffineEnvironment.transform 1 1 env336 = env339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env336 == env339) = true)

theorem identity339 : scanCanonicalize (H12AffineFastState.compose env339 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env340 : List Nat := [0,1,8,0,32,8,32,0,33,8,9,9,41,41,41,9,40,32,0,41,1,32,9,41,1,1,8,41,8,33,1,8,8,8,40,32]

theorem envBound340 : H12AffineFastState.Bounded env340 := by
  intro p hp
  have h : env340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans339_340 : H12AffineEnvironment.transform 0 0 env339 = env340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env339 == env340) = true)

def leafEnv340 : List Nat := [0,1,8,0,32,8,32,0,33,8,9,9,41,41,41,9,40,32,0,41,1,32,9,41,9,1,1,1,8,41,8,33,1,8,8,8,9,32,40,32,1,0,0]

def active340 : List Nat := [2,4]

def tree340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood340 : H12WitnessSearch.Good tree340 := H12GlobalWitnessIndex.good

theorem leafIdentity340 : H12AffineFastState.composeSystem env340 rootObs = leafEnv340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env340 rootObs == leafEnv340) = true)

theorem terminalChecked340 : H12PackedTerminal.terminalCheckFast leafEnv340 active340 tree340 = true := by decide +kernel

def env341 : List Nat := [2,4,8,16,32,64,109,16,52,64,27,14,60,43,113,13,42,127,0,113,78,32,81,56,89,1,26,59,31,32,4,27,80,27,42,107]

theorem envBound341 : H12AffineFastState.Bounded env341 := by
  intro p hp
  have h : env341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans323_341 : H12AffineEnvironment.transform 15 13 env323 = env341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13 env323 == env341) = true)

theorem identity341 : scanCanonicalize (H12AffineFastState.compose env341 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 30) := by decide +kernel

theorem selectedBound341 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env342 : List Nat := [2,4,8,16,32,30,51,16,52,30,27,14,60,43,47,13,42,33,0,47,16,32,15,56,7,1,26,59,31,32,4,27,14,27,42,53]

theorem envBound342 : H12AffineFastState.Bounded env342 := by
  intro p hp
  have h : env342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans341_342 : H12AffineEnvironment.transform 5 30 env341 = env342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 30 env341 == env342) = true)

def env343 : List Nat := [2,4,8,0,32,14,35,0,36,14,11,14,44,43,47,13,42,33,0,47,0,32,15,40,7,1,10,43,15,32,4,11,14,11,42,37]

theorem envBound343 : H12AffineFastState.Bounded env343 := by
  intro p hp
  have h : env343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans342_343 : H12AffineEnvironment.transform 3 0 env342 = env343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env342 == env343) = true)

def env344 : List Nat := [2,4,8,0,0,14,3,0,4,14,11,14,12,11,15,13,10,1,0,15,0,0,15,8,7,1,10,11,15,0,4,11,14,11,10,5]

theorem envBound344 : H12AffineFastState.Bounded env344 := by
  intro p hp
  have h : env344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans343_344 : H12AffineEnvironment.transform 4 0 env343 = env344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env343 == env344) = true)

theorem identity344 : scanCanonicalize (H12AffineFastState.compose env344 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env345 : List Nat := [0,4,8,0,0,12,1,0,4,12,9,12,12,9,13,13,8,1,0,13,0,0,13,8,5,1,8,9,13,0,4,9,12,9,8,5]

theorem envBound345 : H12AffineFastState.Bounded env345 := by
  intro p hp
  have h : env345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans344_345 : H12AffineEnvironment.transform 0 0 env344 = env345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env344 == env345) = true)

def leafEnv345 : List Nat := [0,4,8,0,0,12,1,0,4,12,9,12,12,9,13,13,8,1,0,13,0,0,13,8,8,5,1,1,8,9,13,0,4,9,12,9,8,5,8,5,1,1,0]

def active345 : List Nat := [1,2]

def tree345 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood345 : H12WitnessSearch.Good tree345 := H12GlobalWitnessIndex.good

theorem leafIdentity345 : H12AffineFastState.composeSystem env345 rootObs = leafEnv345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env345 rootObs == leafEnv345) = true)

theorem terminalChecked345 : H12PackedTerminal.terminalCheckFast leafEnv345 active345 tree345 = true := by decide +kernel

def env346 : List Nat := [2,4,8,0,1,14,2,0,5,14,11,14,13,10,14,13,11,0,0,14,0,1,15,9,7,1,10,10,15,1,4,11,14,11,11,4]

theorem envBound346 : H12AffineFastState.Bounded env346 := by
  intro p hp
  have h : env346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans343_346 : H12AffineEnvironment.transform 4 1 env343 = env346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env343 == env346) = true)

theorem identity346 : scanCanonicalize (H12AffineFastState.compose env346 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env347 : List Nat := [2,3,8,0,1,9,2,0,2,9,11,9,10,10,9,10,11,0,0,9,0,1,8,9,0,1,10,10,8,1,3,11,9,11,11,3]

theorem envBound347 : H12AffineFastState.Bounded env347 := by
  intro p hp
  have h : env347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans346_347 : H12AffineEnvironment.transform 1 3 env346 = env347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env346 == env347) = true)

def leafEnv347 : List Nat := [2,3,8,0,1,9,2,0,2,9,11,9,10,10,9,10,11,0,0,9,0,1,8,9,10,0,1,1,10,10,8,1,3,11,9,11,10,1,11,3,1,1,0]

def active347 : List Nat := [0,2]

def tree347 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood347 : H12WitnessSearch.Good tree347 := H12GlobalWitnessIndex.good

theorem leafIdentity347 : H12AffineFastState.composeSystem env347 rootObs = leafEnv347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env347 rootObs == leafEnv347) = true)

theorem terminalChecked347 : H12PackedTerminal.terminalCheckFast leafEnv347 active347 tree347 = true := by decide +kernel

def env348 : List Nat := [2,4,8,1,32,15,34,1,37,15,10,14,45,43,47,13,42,33,0,47,1,32,15,41,7,1,11,42,14,32,4,10,14,10,42,36]

theorem envBound348 : H12AffineFastState.Bounded env348 := by
  intro p hp
  have h : env348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans342_348 : H12AffineEnvironment.transform 3 1 env342 = env348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env342 == env348) = true)

def env349 : List Nat := [2,4,8,1,0,15,2,1,5,15,10,14,13,11,15,13,10,1,0,15,1,0,15,9,7,1,11,10,14,0,4,10,14,10,10,4]

theorem envBound349 : H12AffineFastState.Bounded env349 := by
  intro p hp
  have h : env349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans348_349 : H12AffineEnvironment.transform 4 0 env348 = env349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env348 == env349) = true)

theorem identity349 : scanCanonicalize (H12AffineFastState.compose env349 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env350 : List Nat := [2,4,5,1,0,2,2,1,5,2,7,3,0,6,2,0,7,1,0,2,1,0,2,4,7,1,6,7,3,0,4,7,3,7,7,4]

theorem envBound350 : H12AffineFastState.Bounded env350 := by
  intro p hp
  have h : env350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans349_350 : H12AffineEnvironment.transform 2 5 env349 = env350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env349 == env350) = true)

def leafEnv350 : List Nat := [2,4,5,1,0,2,2,1,5,2,7,3,0,6,2,0,7,1,0,2,1,0,2,4,6,7,1,1,6,7,3,0,4,7,3,7,6,6,7,4,1,0,0]

def active350 : List Nat := [0,1]

def tree350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood350 : H12WitnessSearch.Good tree350 := H12GlobalWitnessIndex.good

theorem leafIdentity350 : H12AffineFastState.composeSystem env350 rootObs = leafEnv350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env350 rootObs == leafEnv350) = true)

theorem terminalChecked350 : H12PackedTerminal.terminalCheckFast leafEnv350 active350 tree350 = true := by decide +kernel

def env351 : List Nat := [2,4,8,1,1,15,3,1,4,15,10,14,12,10,14,13,11,0,0,14,1,1,15,8,7,1,11,11,14,1,4,10,14,10,11,5]

theorem envBound351 : H12AffineFastState.Bounded env351 := by
  intro p hp
  have h : env351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans348_351 : H12AffineEnvironment.transform 4 1 env348 = env351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env348 == env351) = true)

theorem identity351 : scanCanonicalize (H12AffineFastState.compose env351 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env352 : List Nat := [2,4,0,1,1,7,3,1,4,7,2,6,4,2,6,5,3,0,0,6,1,1,7,0,7,1,3,3,6,1,4,2,6,2,3,5]

theorem envBound352 : H12AffineFastState.Bounded env352 := by
  intro p hp
  have h : env352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans351_352 : H12AffineEnvironment.transform 2 0 env351 = env352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env351 == env352) = true)

def leafEnv352 : List Nat := [2,4,0,1,1,7,3,1,4,7,2,6,4,2,6,5,3,0,0,6,1,1,7,0,3,7,1,1,3,3,6,1,4,2,6,2,3,7,3,5,1,0,0]

def active352 : List Nat := [0,1]

def tree352 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood352 : H12WitnessSearch.Good tree352 := H12GlobalWitnessIndex.good

theorem leafIdentity352 : H12AffineFastState.composeSystem env352 rootObs = leafEnv352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env352 rootObs == leafEnv352) = true)

theorem terminalChecked352 : H12PackedTerminal.terminalCheckFast leafEnv352 active352 tree352 = true := by decide +kernel

def env353 : List Nat := [2,4,8,16,32,64,128,253,53,173,247,15,209,199,113,65536,198,126,237,113,79,32,81,65752,89,1,246,215,30,65580,4,65787,189,65787,198,65639]

theorem envBound353 : H12AffineFastState.Bounded env353 := by
  intro p hp
  have h : env353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans321_353 : H12AffineEnvironment.transform 8 53 env321 = env353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env321 == env353) = true)

theorem identity353 : scanCanonicalize (H12AffineFastState.compose env353 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 191) := by decide +kernel

theorem selectedBound353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env354 : List Nat := [2,4,8,16,32,64,128,253,53,173,247,15,209,199,113,191,198,126,237,113,79,32,81,103,89,1,246,215,30,147,4,68,189,68,198,216]

theorem envBound354 : H12AffineFastState.Bounded env354 := by
  intro p hp
  have h : env354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans353_354 : H12AffineEnvironment.transform 15 191 env353 = env354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 191 env353 == env354) = true)

def env355 : List Nat := [2,4,8,16,32,64,108,17,53,65,27,15,61,43,113,83,42,126,1,113,79,32,81,103,89,1,26,59,30,127,4,68,81,68,42,52]

theorem envBound355 : H12AffineFastState.Bounded env355 := by
  intro p hp
  have h : env355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans354_355 : H12AffineEnvironment.transform 6 108 env354 = env355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 108 env354 == env355) = true)

def env356 : List Nat := [2,4,8,16,0,64,76,17,21,65,27,15,29,11,81,83,10,94,1,81,79,0,81,71,89,1,26,27,30,95,4,68,81,68,10,20]

theorem envBound356 : H12AffineFastState.Bounded env356 := by
  intro p hp
  have h : env356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans355_356 : H12AffineEnvironment.transform 4 0 env355 = env356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env355 == env356) = true)

def env357 : List Nat := [2,4,8,16,0,0,12,17,21,1,27,15,29,11,17,19,10,30,1,17,15,0,17,7,25,1,26,27,30,31,4,4,17,4,10,20]

theorem envBound357 : H12AffineFastState.Bounded env357 := by
  intro p hp
  have h : env357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans356_357 : H12AffineEnvironment.transform 5 0 env356 = env357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env356 == env357) = true)

theorem identity357 : scanCanonicalize (H12AffineFastState.compose env357 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env358 : List Nat := [0,4,8,16,0,0,12,17,21,1,25,13,29,9,17,17,8,28,1,17,13,0,17,5,25,1,24,25,28,29,4,4,17,4,8,20]

theorem envBound358 : H12AffineFastState.Bounded env358 := by
  intro p hp
  have h : env358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans357_358 : H12AffineEnvironment.transform 0 0 env357 = env358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env357 == env358) = true)

def leafEnv358 : List Nat := [0,4,8,16,0,0,12,17,21,1,25,13,29,9,17,17,8,28,1,17,13,0,17,5,4,25,1,1,24,25,28,29,4,4,17,4,4,20,8,20,1,12,0]

def active358 : List Nat := [1,2,3]

def tree358 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood358 : H12WitnessSearch.Good tree358 := H12GlobalWitnessIndex.good

theorem leafIdentity358 : H12AffineFastState.composeSystem env358 rootObs = leafEnv358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env358 rootObs == leafEnv358) = true)

theorem terminalChecked358 : H12PackedTerminal.terminalCheckFast leafEnv358 active358 tree358 = true := by decide +kernel

def env359 : List Nat := [2,4,8,16,0,1,13,17,21,0,27,15,29,11,16,18,10,31,1,16,14,0,16,6,24,1,26,27,30,30,4,5,16,5,10,20]

theorem envBound359 : H12AffineFastState.Bounded env359 := by
  intro p hp
  have h : env359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans356_359 : H12AffineEnvironment.transform 5 1 env356 = env359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env356 == env359) = true)

theorem identity359 : scanCanonicalize (H12AffineFastState.compose env359 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound359 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env360 : List Nat := [2,4,8,2,0,1,13,3,7,0,9,15,15,11,2,0,10,13,1,2,14,0,2,6,10,1,8,9,12,12,4,5,2,5,10,6]

theorem envBound360 : H12AffineFastState.Bounded env360 := by
  intro p hp
  have h : env360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans359_360 : H12AffineEnvironment.transform 3 2 env359 = env360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env359 == env360) = true)

def leafEnv360 : List Nat := [2,4,8,2,0,1,13,3,7,0,9,15,15,11,2,0,10,13,1,2,14,0,2,6,5,10,1,1,8,9,12,12,4,5,2,5,5,4,10,6,1,15,0]

def active360 : List Nat := [0,1,2]

def tree360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood360 : H12WitnessSearch.Good tree360 := H12GlobalWitnessIndex.good

theorem leafIdentity360 : H12AffineFastState.composeSystem env360 rootObs = leafEnv360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env360 rootObs == leafEnv360) = true)

theorem terminalChecked360 : H12PackedTerminal.terminalCheckFast leafEnv360 active360 tree360 = true := by decide +kernel

def env361 : List Nat := [2,4,8,16,1,64,77,17,20,65,27,15,28,10,80,83,11,95,1,80,79,1,81,70,89,1,26,26,30,94,4,68,81,68,11,21]

theorem envBound361 : H12AffineFastState.Bounded env361 := by
  intro p hp
  have h : env361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans355_361 : H12AffineEnvironment.transform 4 1 env355 = env361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env355 == env361) = true)

def env362 : List Nat := [2,4,8,16,1,0,13,17,20,1,27,15,28,10,16,19,11,31,1,16,15,1,17,6,25,1,26,26,30,30,4,4,17,4,11,21]

theorem envBound362 : H12AffineFastState.Bounded env362 := by
  intro p hp
  have h : env362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans361_362 : H12AffineEnvironment.transform 5 0 env361 = env362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env361 == env362) = true)

theorem identity362 : scanCanonicalize (H12AffineFastState.compose env362 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound362 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env363 : List Nat := [2,2,8,16,1,0,11,17,18,1,27,9,26,10,16,19,11,25,1,16,9,1,17,0,25,1,26,26,24,24,2,2,17,2,11,19]

theorem envBound363 : H12AffineFastState.Bounded env363 := by
  intro p hp
  have h : env363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans362_363 : H12AffineEnvironment.transform 1 2 env362 = env363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env362 == env363) = true)

def leafEnv363 : List Nat := [2,2,8,16,1,0,11,17,18,1,27,9,26,10,16,19,11,25,1,16,9,1,17,0,2,25,1,1,26,26,24,24,2,2,17,2,2,17,11,19,1,8,0]

def active363 : List Nat := [0,2,3]

def tree363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood363 : H12WitnessSearch.Good tree363 := H12GlobalWitnessIndex.good

theorem leafIdentity363 : H12AffineFastState.composeSystem env363 rootObs = leafEnv363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env363 rootObs == leafEnv363) = true)

theorem terminalChecked363 : H12PackedTerminal.terminalCheckFast leafEnv363 active363 tree363 = true := by decide +kernel

def env364 : List Nat := [2,4,8,16,1,1,12,17,20,0,27,15,28,10,17,18,11,30,1,17,14,1,16,7,24,1,26,26,30,31,4,5,16,5,11,21]

theorem envBound364 : H12AffineFastState.Bounded env364 := by
  intro p hp
  have h : env364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans361_364 : H12AffineEnvironment.transform 5 1 env361 = env364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env361 == env364) = true)

theorem identity364 : scanCanonicalize (H12AffineFastState.compose env364 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env365 : List Nat := [2,4,8,6,1,1,12,7,2,0,13,15,10,10,7,4,11,8,1,7,14,1,6,7,14,1,12,12,8,9,4,5,6,5,11,3]

theorem envBound365 : H12AffineFastState.Bounded env365 := by
  intro p hp
  have h : env365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans364_365 : H12AffineEnvironment.transform 3 6 env364 = env365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env364 == env365) = true)

def leafEnv365 : List Nat := [2,4,8,6,1,1,12,7,2,0,13,15,10,10,7,4,11,8,1,7,14,1,6,7,5,14,1,1,12,12,8,9,4,5,6,5,5,1,11,3,1,15,0]

def active365 : List Nat := [0,1,2]

def tree365 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood365 : H12WitnessSearch.Good tree365 := H12GlobalWitnessIndex.good

theorem leafIdentity365 : H12AffineFastState.composeSystem env365 rootObs = leafEnv365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env365 rootObs == leafEnv365) = true)

theorem terminalChecked365 : H12PackedTerminal.terminalCheckFast leafEnv365 active365 tree365 = true := by decide +kernel

def env366 : List Nat := [2,4,8,16,32,64,109,16,53,64,26,15,60,42,113,82,43,126,0,113,79,32,81,103,89,1,27,58,30,126,4,68,80,68,43,53]

theorem envBound366 : H12AffineFastState.Bounded env366 := by
  intro p hp
  have h : env366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans354_366 : H12AffineEnvironment.transform 6 109 env354 = env366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 109 env354 == env366) = true)

theorem identity366 : scanCanonicalize (H12AffineFastState.compose env366 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 30) := by decide +kernel

theorem selectedBound366 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env367 : List Nat := [2,4,8,16,32,30,51,16,53,30,26,15,60,42,47,12,43,32,0,47,17,32,15,57,7,1,27,58,30,32,4,26,14,26,43,53]

theorem envBound367 : H12AffineFastState.Bounded env367 := by
  intro p hp
  have h : env367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans366_367 : H12AffineEnvironment.transform 5 30 env366 = env367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 30 env366 == env367) = true)

theorem identity367 : scanCanonicalize (H12AffineFastState.compose env367 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound367 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env368 : List Nat := [2,4,8,16,1,30,18,16,20,30,26,15,29,11,14,12,10,1,0,14,17,1,15,24,7,1,27,27,30,1,4,26,14,26,10,20]

theorem envBound368 : H12AffineFastState.Bounded env368 := by
  intro p hp
  have h : env368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans367_368 : H12AffineEnvironment.transform 4 1 env367 = env368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env367 == env368) = true)

theorem identity368 : scanCanonicalize (H12AffineFastState.compose env368 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound368 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env369 : List Nat := [2,4,8,4,1,10,6,4,0,10,14,15,9,11,14,12,10,1,0,14,5,1,15,12,7,1,15,15,10,1,4,14,14,14,10,0]

theorem envBound369 : H12AffineFastState.Bounded env369 := by
  intro p hp
  have h : env369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans368_369 : H12AffineEnvironment.transform 3 4 env368 = env369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env368 == env369) = true)

theorem identity369 : scanCanonicalize (H12AffineFastState.compose env369 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound369 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env370 : List Nat := [2,4,7,4,1,5,6,4,0,5,1,0,6,4,1,3,5,1,0,1,5,1,0,3,7,1,0,0,5,1,4,1,1,1,5,0]

theorem envBound370 : H12AffineFastState.Bounded env370 := by
  intro p hp
  have h : env370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans369_370 : H12AffineEnvironment.transform 2 7 env369 = env370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env369 == env370) = true)

theorem identity370 : scanCanonicalize (H12AffineFastState.compose env370 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env371 : List Nat := [2,2,1,2,1,3,0,2,0,3,1,0,0,2,1,3,3,1,0,1,3,1,0,3,1,1,0,0,3,1,2,1,1,1,3,0]

theorem envBound371 : H12AffineFastState.Bounded env371 := by
  intro p hp
  have h : env371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans370_371 : H12AffineEnvironment.transform 1 2 env370 = env371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env370 == env371) = true)

theorem identity371 : scanCanonicalize (H12AffineFastState.compose env371 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound371 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env372 : List Nat := [1,1,1,1,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,0,1,1,1,1,1,0,0]

theorem envBound372 : H12AffineFastState.Bounded env372 := by
  intro p hp
  have h : env372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans371_372 : H12AffineEnvironment.transform 0 1 env371 = env372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env371 == env372) = true)

def leafEnv372 : List Nat := [1,1,1,1,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,1,0,1,0,0,1,1,1,1,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0]

def active372 : List Nat := []

def tree372 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood372 : H12WitnessSearch.Good tree372 := H12GlobalWitnessIndex.good

theorem leafIdentity372 : H12AffineFastState.composeSystem env372 rootObs = leafEnv372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env372 rootObs == leafEnv372) = true)

theorem terminalChecked372 : H12PackedTerminal.terminalCheckFast leafEnv372 active372 tree372 = true := by decide +kernel

def env373 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,4096,1149,4296,1245,65536,754,1766,237,1245,1750,32,1276,66676,1269,1196,1646,1614,5308,66072,1193,66647,1040,66647,4297,67326]

theorem envBound373 : H12AffineFastState.Bounded env373 := by
  intro p hp
  have h : env373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans309_373 : H12AffineEnvironment.transform 12 1149 env309 = env373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1149 env309 == env373) = true)

theorem identity373 : scanCanonicalize (H12AffineFastState.compose env373 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4713) := by decide +kernel

theorem selectedBound373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env374 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,4096,1149,4296,1245,4713,754,1766,237,1245,1750,32,1276,5661,1269,1196,1646,1614,5308,4209,1193,5694,1040,5694,4297,5271]

theorem envBound374 : H12AffineFastState.Bounded env374 := by
  intro p hp
  have h : env374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans373_374 : H12AffineEnvironment.transform 15 4713 env373 = env374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4713 env373 == env374) = true)

def env375 : List Nat := [2,4,8,16,32,64,128,253,512,172,707,4096,209,4296,113,4713,754,586,237,113,634,32,80,4785,89,0,706,738,4112,4209,5,4754,188,4754,4297,4155]

theorem envBound375 : H12AffineFastState.Bounded env375 := by
  intro p hp
  have h : env375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans374_375 : H12AffineEnvironment.transform 9 172 env374 = env375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env374 == env375) = true)

def env376 : List Nat := [2,4,8,16,32,64,128,253,512,172,707,548,209,748,113,77,754,586,237,113,634,32,80,149,89,0,706,738,564,597,5,182,188,182,749,543]

theorem envBound376 : H12AffineFastState.Bounded env376 := by
  intro p hp
  have h : env376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans375_376 : H12AffineEnvironment.transform 11 548 env375 = env376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 548 env375 == env376) = true)

theorem identity376 : scanCanonicalize (H12AffineFastState.compose env376 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound376 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env377 : List Nat := [2,4,8,16,32,64,128,253,217,172,26,253,209,53,113,77,43,147,237,113,163,32,80,149,89,0,27,59,237,140,5,182,188,182,52,198]

theorem envBound377 : H12AffineFastState.Bounded env377 := by
  intro p hp
  have h : env377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans376_377 : H12AffineEnvironment.transform 8 217 env376 = env377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env376 == env377) = true)

def env378 : List Nat := [2,4,8,16,32,64,44,81,117,0,26,81,125,53,113,77,43,63,65,113,15,32,80,57,89,0,27,59,65,32,5,26,16,26,52,106]

theorem envBound378 : H12AffineFastState.Bounded env378 := by
  intro p hp
  have h : env378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans377_378 : H12AffineEnvironment.transform 6 44 env377 = env378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env377 == env378) = true)

def env379 : List Nat := [2,4,8,16,32,20,44,5,33,0,26,5,41,53,37,25,43,63,21,37,15,32,4,57,13,0,27,59,21,32,5,26,16,26,52,62]

theorem envBound379 : H12AffineFastState.Bounded env379 := by
  intro p hp
  have h : env379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans378_379 : H12AffineEnvironment.transform 5 20 env378 = env379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env378 == env379) = true)

def env380 : List Nat := [2,4,8,0,32,4,44,5,33,0,10,5,41,37,37,9,43,47,5,37,15,32,4,41,13,0,11,43,5,32,5,10,0,10,36,46]

theorem envBound380 : H12AffineFastState.Bounded env380 := by
  intro p hp
  have h : env380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans379_380 : H12AffineEnvironment.transform 3 0 env379 = env380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env379 == env380) = true)

theorem identity380 : scanCanonicalize (H12AffineFastState.compose env380 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound380 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env381 : List Nat := [2,4,8,0,9,4,5,5,8,0,10,5,0,12,12,9,2,6,5,12,15,9,4,0,13,0,11,2,5,9,5,10,0,10,13,7]

theorem envBound381 : H12AffineFastState.Bounded env381 := by
  intro p hp
  have h : env381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans380_381 : H12AffineEnvironment.transform 4 9 env380 = env381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env380 == env381) = true)

def env382 : List Nat := [2,4,0,0,1,4,5,5,0,0,2,5,0,4,4,1,2,6,5,4,7,1,4,0,5,0,3,2,5,1,5,2,0,2,5,7]

theorem envBound382 : H12AffineFastState.Bounded env382 := by
  intro p hp
  have h : env382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans381_382 : H12AffineEnvironment.transform 2 0 env381 = env382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env381 == env382) = true)

theorem identity382 : scanCanonicalize (H12AffineFastState.compose env382 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env383 : List Nat := [2,2,0,0,1,2,3,3,0,0,2,3,0,2,2,1,2,0,3,2,1,1,2,0,3,0,3,2,3,1,3,2,0,2,3,1]

theorem envBound383 : H12AffineFastState.Bounded env383 := by
  intro p hp
  have h : env383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans382_383 : H12AffineEnvironment.transform 1 2 env382 = env383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env382 == env383) = true)

def leafEnv383 : List Nat := [2,2,0,0,1,2,3,3,0,0,2,3,0,2,2,1,2,0,3,2,1,1,2,0,0,3,1,0,3,2,3,1,3,2,0,2,1,3,3,1,1,0,0]

def active383 : List Nat := [0]

def tree383 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood383 : H12WitnessSearch.Good tree383 := H12GlobalWitnessIndex.good

theorem leafIdentity383 : H12AffineFastState.composeSystem env383 rootObs = leafEnv383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env383 rootObs == leafEnv383) = true)

theorem terminalChecked383 : H12PackedTerminal.terminalCheckFast leafEnv383 active383 tree383 = true := by decide +kernel

def env384 : List Nat := [2,4,1,0,0,4,5,5,1,0,3,5,0,5,5,0,2,6,5,5,6,0,4,0,4,0,2,2,5,0,5,3,0,3,4,7]

theorem envBound384 : H12AffineFastState.Bounded env384 := by
  intro p hp
  have h : env384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans381_384 : H12AffineEnvironment.transform 2 1 env381 = env384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env381 == env384) = true)

def env385 : List Nat := [2,0,1,0,0,0,1,1,1,0,3,1,0,1,1,0,2,2,1,1,2,0,0,0,0,0,2,2,1,0,1,3,0,3,0,3]

theorem envBound385 : H12AffineFastState.Bounded env385 := by
  intro p hp
  have h : env385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans384_385 : H12AffineEnvironment.transform 1 0 env384 = env385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env384 == env385) = true)

def leafEnv385 : List Nat := [2,0,1,0,0,0,1,1,1,0,3,1,0,1,1,0,2,2,1,1,2,0,0,0,0,0,1,0,2,2,1,0,1,3,0,3,1,2,0,3,1,0,0]

def active385 : List Nat := [0]

def tree385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood385 : H12WitnessSearch.Good tree385 := H12GlobalWitnessIndex.good

theorem leafIdentity385 : H12AffineFastState.composeSystem env385 rootObs = leafEnv385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env385 rootObs == leafEnv385) = true)

theorem terminalChecked385 : H12PackedTerminal.terminalCheckFast leafEnv385 active385 tree385 = true := by decide +kernel

def env386 : List Nat := [2,1,1,0,0,1,0,0,1,0,3,0,0,0,0,0,2,3,0,0,3,0,1,0,1,0,2,2,0,0,0,3,0,3,1,2]

theorem envBound386 : H12AffineFastState.Bounded env386 := by
  intro p hp
  have h : env386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans384_386 : H12AffineEnvironment.transform 1 1 env384 = env386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env384 == env386) = true)

theorem identity386 : scanCanonicalize (H12AffineFastState.compose env386 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound386 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env387 : List Nat := [0,1,1,0,0,1,0,0,1,0,1,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,0,0,0,1,0,1,1,0]

theorem envBound387 : H12AffineFastState.Bounded env387 := by
  intro p hp
  have h : env387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans386_387 : H12AffineEnvironment.transform 0 0 env386 = env387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env386 == env387) = true)

def leafEnv387 : List Nat := [0,1,1,0,0,1,0,0,1,0,1,0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,1,0,0,0,0,0,0,1,0,1,1,0,1,0,1,0,0]

def active387 : List Nat := []

def tree387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood387 : H12WitnessSearch.Good tree387 := H12GlobalWitnessIndex.good

theorem leafIdentity387 : H12AffineFastState.composeSystem env387 rootObs = leafEnv387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env387 rootObs == leafEnv387) = true)

theorem terminalChecked387 : H12PackedTerminal.terminalCheckFast leafEnv387 active387 tree387 = true := by decide +kernel

def env388 : List Nat := [2,4,8,1,32,5,44,5,33,0,11,5,41,36,37,8,43,46,4,37,15,32,4,40,13,0,10,42,4,32,5,11,1,11,37,47]

theorem envBound388 : H12AffineFastState.Bounded env388 := by
  intro p hp
  have h : env388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans379_388 : H12AffineEnvironment.transform 3 1 env379 = env388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env379 == env388) = true)

theorem identity388 : scanCanonicalize (H12AffineFastState.compose env388 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound388 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env389 : List Nat := [0,4,8,1,32,5,44,5,33,0,9,5,41,36,37,8,41,44,4,37,13,32,4,40,13,0,8,40,4,32,5,9,1,9,37,45]

theorem envBound389 : H12AffineFastState.Bounded env389 := by
  intro p hp
  have h : env389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans388_389 : H12AffineEnvironment.transform 0 0 env388 = env389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env388 == env389) = true)

theorem identity389 : scanCanonicalize (H12AffineFastState.compose env389 (packedSelected [7,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound389 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env390 : List Nat := [0,4,5,1,32,5,33,5,33,0,4,5,36,36,37,5,36,33,4,37,0,32,4,37,0,0,5,37,4,32,5,4,1,4,37,32]

theorem envBound390 : H12AffineFastState.Bounded env390 := by
  intro p hp
  have h : env390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans389_390 : H12AffineEnvironment.transform 2 5 env389 = env390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env389 == env390) = true)

def leafEnv390 : List Nat := [0,4,5,1,32,5,33,5,33,0,4,5,36,36,37,5,36,33,4,37,0,32,4,37,1,0,1,0,5,37,4,32,5,4,1,4,0,32,37,32,1,1,0]

def active390 : List Nat := [1,4]

def tree390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood390 : H12WitnessSearch.Good tree390 := H12GlobalWitnessIndex.good

theorem leafIdentity390 : H12AffineFastState.composeSystem env390 rootObs = leafEnv390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env390 rootObs == leafEnv390) = true)

theorem terminalChecked390 : H12PackedTerminal.terminalCheckFast leafEnv390 active390 tree390 = true := by decide +kernel

def env391 : List Nat := [2,4,8,16,32,21,44,4,32,0,26,4,40,53,36,24,43,63,20,36,15,32,5,57,12,0,27,59,20,32,5,26,16,26,52,63]

theorem envBound391 : H12AffineFastState.Bounded env391 := by
  intro p hp
  have h : env391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans378_391 : H12AffineEnvironment.transform 5 21 env378 = env391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env378 == env391) = true)

theorem identity391 : scanCanonicalize (H12AffineFastState.compose env391 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound391 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env392 : List Nat := [2,4,8,14,32,11,44,4,32,0,4,4,40,43,36,6,43,33,10,36,15,32,5,39,12,0,5,37,10,32,5,4,14,4,42,33]

theorem envBound392 : H12AffineFastState.Bounded env392 := by
  intro p hp
  have h : env392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans391_392 : H12AffineEnvironment.transform 3 14 env391 = env392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env391 == env392) = true)

def env393 : List Nat := [2,4,8,14,4,11,8,4,4,0,4,4,12,15,0,6,15,5,10,0,15,4,5,3,12,0,5,1,10,4,5,4,14,4,14,5]

theorem envBound393 : H12AffineFastState.Bounded env393 := by
  intro p hp
  have h : env393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans392_393 : H12AffineEnvironment.transform 4 4 env392 = env393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env392 == env393) = true)

theorem identity393 : scanCanonicalize (H12AffineFastState.compose env393 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env394 : List Nat := [2,2,8,8,2,11,8,2,2,0,2,2,10,9,0,0,9,3,10,0,9,2,3,3,10,0,3,1,10,2,3,2,8,2,8,3]

theorem envBound394 : H12AffineFastState.Bounded env394 := by
  intro p hp
  have h : env394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans393_394 : H12AffineEnvironment.transform 1 2 env393 = env394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env393 == env394) = true)

def leafEnv394 : List Nat := [2,2,8,8,2,11,8,2,2,0,2,2,10,9,0,0,9,3,10,0,9,2,3,3,9,10,1,0,3,1,10,2,3,2,8,2,8,1,8,3,1,8,0]

def active394 : List Nat := [0,2]

def tree394 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood394 : H12WitnessSearch.Good tree394 := H12GlobalWitnessIndex.good

theorem leafIdentity394 : H12AffineFastState.composeSystem env394 rootObs = leafEnv394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env394 rootObs == leafEnv394) = true)

theorem terminalChecked394 : H12PackedTerminal.terminalCheckFast leafEnv394 active394 tree394 = true := by decide +kernel

def env395 : List Nat := [2,4,8,14,5,11,9,4,5,0,4,4,13,14,1,6,14,4,10,1,15,5,5,2,12,0,5,0,10,5,5,4,14,4,15,4]

theorem envBound395 : H12AffineFastState.Bounded env395 := by
  intro p hp
  have h : env395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans392_395 : H12AffineEnvironment.transform 4 5 env392 = env395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env392 == env395) = true)

theorem identity395 : scanCanonicalize (H12AffineFastState.compose env395 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env396 : List Nat := [2,4,0,6,5,3,1,4,5,0,4,4,5,6,1,6,6,4,2,1,7,5,5,2,4,0,5,0,2,5,5,4,6,4,7,4]

theorem envBound396 : H12AffineFastState.Bounded env396 := by
  intro p hp
  have h : env396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans395_396 : H12AffineEnvironment.transform 2 0 env395 = env396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env395 == env396) = true)

def leafEnv396 : List Nat := [2,4,0,6,5,3,1,4,5,0,4,4,5,6,1,6,6,4,2,1,7,5,5,2,7,4,1,0,5,0,2,5,5,4,6,4,6,6,7,4,1,6,0]

def active396 : List Nat := [0,1]

def tree396 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood396 : H12WitnessSearch.Good tree396 := H12GlobalWitnessIndex.good

theorem leafIdentity396 : H12AffineFastState.composeSystem env396 rootObs = leafEnv396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env396 rootObs == leafEnv396) = true)

theorem terminalChecked396 : H12PackedTerminal.terminalCheckFast leafEnv396 active396 tree396 = true := by decide +kernel

def env397 : List Nat := [2,4,8,16,32,64,45,80,116,1,26,80,124,53,113,77,43,62,64,113,14,32,80,56,89,0,27,59,64,33,5,27,17,27,52,107]

theorem envBound397 : H12AffineFastState.Bounded env397 := by
  intro p hp
  have h : env397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans377_397 : H12AffineEnvironment.transform 6 45 env377 = env397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 45 env377 == env397) = true)

theorem identity397 : scanCanonicalize (H12AffineFastState.compose env397 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound397 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env398 : List Nat := [2,4,8,14,32,64,45,78,106,1,4,78,98,43,111,77,43,32,64,111,14,32,78,38,71,0,5,37,64,33,5,5,15,5,42,107]

theorem envBound398 : H12AffineFastState.Bounded env398 := by
  intro p hp
  have h : env398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans397_398 : H12AffineEnvironment.transform 3 14 env397 = env398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env397 == env398) = true)

def env399 : List Nat := [2,4,8,14,32,0,45,14,42,1,4,14,34,43,47,13,43,32,0,47,14,32,14,38,7,0,5,37,0,33,5,5,15,5,42,43]

theorem envBound399 : H12AffineFastState.Bounded env399 := by
  intro p hp
  have h : env399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans398_399 : H12AffineEnvironment.transform 5 0 env398 = env399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env398 == env399) = true)

def env400 : List Nat := [2,4,8,14,0,0,13,14,10,1,4,14,2,11,15,13,11,0,0,15,14,0,14,6,7,0,5,5,0,1,5,5,15,5,10,11]

theorem envBound400 : H12AffineFastState.Bounded env400 := by
  intro p hp
  have h : env400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans399_400 : H12AffineEnvironment.transform 4 0 env399 = env400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env399 == env400) = true)

theorem identity400 : scanCanonicalize (H12AffineFastState.compose env400 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env401 : List Nat := [2,4,5,3,0,0,0,3,7,1,4,3,2,6,2,0,6,0,0,2,3,0,3,6,7,0,5,5,0,1,5,5,2,5,7,6]

theorem envBound401 : H12AffineFastState.Bounded env401 := by
  intro p hp
  have h : env401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans400_401 : H12AffineEnvironment.transform 2 5 env400 = env401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env400 == env401) = true)

def leafEnv401 : List Nat := [2,4,5,3,0,0,0,3,7,1,4,3,2,6,2,0,6,0,0,2,3,0,3,6,4,7,1,0,5,5,0,1,5,5,2,5,5,4,7,6,1,2,0]

def active401 : List Nat := [0,1]

def tree401 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood401 : H12WitnessSearch.Good tree401 := H12GlobalWitnessIndex.good

theorem leafIdentity401 : H12AffineFastState.composeSystem env401 rootObs = leafEnv401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env401 rootObs == leafEnv401) = true)

theorem terminalChecked401 : H12PackedTerminal.terminalCheckFast leafEnv401 active401 tree401 = true := by decide +kernel

def env402 : List Nat := [2,4,8,14,1,0,12,14,11,1,4,14,3,10,14,13,10,1,0,14,14,1,14,7,7,0,5,4,0,0,5,5,15,5,11,10]

theorem envBound402 : H12AffineFastState.Bounded env402 := by
  intro p hp
  have h : env402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans399_402 : H12AffineEnvironment.transform 4 1 env399 = env402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env399 == env402) = true)

theorem identity402 : scanCanonicalize (H12AffineFastState.compose env402 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env403 : List Nat := [2,4,1,7,1,0,5,7,2,1,4,7,3,3,7,4,3,1,0,7,7,1,7,7,7,0,5,4,0,0,5,5,6,5,2,3]

theorem envBound403 : H12AffineFastState.Bounded env403 := by
  intro p hp
  have h : env403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans402_403 : H12AffineEnvironment.transform 2 1 env402 = env403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env402 == env403) = true)

def leafEnv403 : List Nat := [2,4,1,7,1,0,5,7,2,1,4,7,3,3,7,4,3,1,0,7,7,1,7,7,4,7,1,0,5,4,0,0,5,5,6,5,5,1,2,3,1,6,0]

def active403 : List Nat := [0,1]

def tree403 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood403 : H12WitnessSearch.Good tree403 := H12GlobalWitnessIndex.good

theorem leafIdentity403 : H12AffineFastState.composeSystem env403 rootObs = leafEnv403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env403 rootObs == leafEnv403) = true)

theorem terminalChecked403 : H12PackedTerminal.terminalCheckFast leafEnv403 active403 tree403 = true := by decide +kernel

def env404 : List Nat := [2,4,8,14,32,1,45,15,43,1,4,15,35,43,46,12,43,32,1,46,14,32,15,38,6,0,5,37,1,33,5,5,15,5,42,42]

theorem envBound404 : H12AffineFastState.Bounded env404 := by
  intro p hp
  have h : env404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans398_404 : H12AffineEnvironment.transform 5 1 env398 = env404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env398 == env404) = true)

def env405 : List Nat := [2,4,8,14,0,1,13,15,11,1,4,15,3,11,14,12,11,0,1,14,14,0,15,6,6,0,5,5,1,1,5,5,15,5,10,10]

theorem envBound405 : H12AffineFastState.Bounded env405 := by
  intro p hp
  have h : env405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans404_405 : H12AffineEnvironment.transform 4 0 env404 = env405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env404 == env405) = true)

theorem identity405 : scanCanonicalize (H12AffineFastState.compose env405 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env406 : List Nat := [0,4,8,12,0,1,13,13,9,1,4,13,1,9,12,12,9,0,1,12,12,0,13,4,4,0,5,5,1,1,5,5,13,5,8,8]

theorem envBound406 : H12AffineFastState.Bounded env406 := by
  intro p hp
  have h : env406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans405_406 : H12AffineEnvironment.transform 0 0 env405 = env406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env405 == env406) = true)

def leafEnv406 : List Nat := [0,4,8,12,0,1,13,13,9,1,4,13,1,9,12,12,9,0,1,12,12,0,13,4,5,4,1,0,5,5,1,1,5,5,13,5,4,8,8,8,1,13,0]

def active406 : List Nat := [1,2]

def tree406 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood406 : H12WitnessSearch.Good tree406 := H12GlobalWitnessIndex.good

theorem leafIdentity406 : H12AffineFastState.composeSystem env406 rootObs = leafEnv406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env406 rootObs == leafEnv406) = true)

theorem terminalChecked406 : H12PackedTerminal.terminalCheckFast leafEnv406 active406 tree406 = true := by decide +kernel

def env407 : List Nat := [2,4,8,14,1,1,12,15,10,1,4,15,2,10,15,12,10,1,1,15,14,1,15,7,6,0,5,4,1,0,5,5,15,5,11,11]

theorem envBound407 : H12AffineFastState.Bounded env407 := by
  intro p hp
  have h : env407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans404_407 : H12AffineEnvironment.transform 4 1 env404 = env407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env404 == env407) = true)

theorem identity407 : scanCanonicalize (H12AffineFastState.compose env407 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env408 : List Nat := [2,3,8,9,1,1,11,8,10,1,3,8,2,10,8,11,10,1,1,8,9,1,8,0,1,0,2,3,1,0,2,2,8,2,11,11]

theorem envBound408 : H12AffineFastState.Bounded env408 := by
  intro p hp
  have h : env408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans407_408 : H12AffineEnvironment.transform 1 3 env407 = env408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env407 == env408) = true)

def leafEnv408 : List Nat := [2,3,8,9,1,1,11,8,10,1,3,8,2,10,8,11,10,1,1,8,9,1,8,0,2,1,1,0,2,3,1,0,2,2,8,2,3,9,11,11,1,8,0]

def active408 : List Nat := [0,2]

def tree408 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood408 : H12WitnessSearch.Good tree408 := H12GlobalWitnessIndex.good

theorem leafIdentity408 : H12AffineFastState.composeSystem env408 rootObs = leafEnv408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env408 rootObs == leafEnv408) = true)

theorem terminalChecked408 : H12PackedTerminal.terminalCheckFast leafEnv408 active408 tree408 = true := by decide +kernel

def env409 : List Nat := [2,4,8,16,32,64,128,253,512,172,707,549,209,749,113,76,754,586,237,113,634,32,80,148,89,0,706,738,565,596,5,183,188,183,748,542]

theorem envBound409 : H12AffineFastState.Bounded env409 := by
  intro p hp
  have h : env409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans375_409 : H12AffineEnvironment.transform 11 549 env375 = env409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 549 env375 == env409) = true)

theorem identity409 : scanCanonicalize (H12AffineFastState.compose env409 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 198) := by decide +kernel

theorem selectedBound409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env410 : List Nat := [2,4,8,16,32,64,128,253,198,172,5,227,209,43,113,76,52,140,237,113,188,32,80,148,89,0,4,36,243,146,5,183,188,183,42,216]

theorem envBound410 : H12AffineFastState.Bounded env410 := by
  intro p hp
  have h : env410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans409_410 : H12AffineEnvironment.transform 8 198 env409 = env410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 198 env409 == env410) = true)

def env411 : List Nat := [2,4,8,16,32,64,44,81,106,0,5,79,125,43,113,76,52,32,65,113,16,32,80,56,89,0,4,36,95,62,5,27,16,27,42,116]

theorem envBound411 : H12AffineFastState.Bounded env411 := by
  intro p hp
  have h : env411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans410_411 : H12AffineEnvironment.transform 6 44 env410 = env411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env410 == env411) = true)

theorem identity411 : scanCanonicalize (H12AffineFastState.compose env411 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound411 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env412 : List Nat := [2,4,8,15,32,64,44,78,106,0,5,79,98,43,110,76,43,32,65,110,15,32,79,39,70,0,4,36,64,33,5,4,15,4,42,107]

theorem envBound412 : H12AffineFastState.Bounded env412 := by
  intro p hp
  have h : env412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans411_412 : H12AffineEnvironment.transform 3 15 env411 = env412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env411 == env412) = true)

def env413 : List Nat := [2,4,8,15,32,0,44,14,42,0,5,15,34,43,46,12,43,32,1,46,15,32,15,39,6,0,4,36,0,33,5,4,15,4,42,43]

theorem envBound413 : H12AffineFastState.Bounded env413 := by
  intro p hp
  have h : env413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans412_413 : H12AffineEnvironment.transform 5 0 env412 = env413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env412 == env413) = true)

def env414 : List Nat := [2,4,8,15,0,0,12,14,10,0,5,15,2,11,14,12,11,0,1,14,15,0,15,7,6,0,4,4,0,1,5,4,15,4,10,11]

theorem envBound414 : H12AffineFastState.Bounded env414 := by
  intro p hp
  have h : env414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans413_414 : H12AffineEnvironment.transform 4 0 env413 = env414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env413 == env414) = true)

theorem identity414 : scanCanonicalize (H12AffineFastState.compose env414 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env415 : List Nat := [2,4,4,3,0,0,0,2,6,0,5,3,2,7,2,0,7,0,1,2,3,0,3,7,6,0,4,4,0,1,5,4,3,4,6,7]

theorem envBound415 : H12AffineFastState.Bounded env415 := by
  intro p hp
  have h : env415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans414_415 : H12AffineEnvironment.transform 2 4 env414 = env415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env414 == env415) = true)

def leafEnv415 : List Nat := [2,4,4,3,0,0,0,2,6,0,5,3,2,7,2,0,7,0,1,2,3,0,3,7,4,6,1,0,4,4,0,1,5,4,3,4,5,5,6,7,1,2,0]

def active415 : List Nat := [0,1]

def tree415 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood415 : H12WitnessSearch.Good tree415 := H12GlobalWitnessIndex.good

theorem leafIdentity415 : H12AffineFastState.composeSystem env415 rootObs = leafEnv415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env415 rootObs == leafEnv415) = true)

theorem terminalChecked415 : H12PackedTerminal.terminalCheckFast leafEnv415 active415 tree415 = true := by decide +kernel

def env416 : List Nat := [2,4,8,15,1,0,13,14,11,0,5,15,3,10,15,12,10,1,1,15,15,1,15,6,6,0,4,5,0,0,5,4,15,4,11,10]

theorem envBound416 : H12AffineFastState.Bounded env416 := by
  intro p hp
  have h : env416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans413_416 : H12AffineEnvironment.transform 4 1 env413 = env416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env413 == env416) = true)

theorem identity416 : scanCanonicalize (H12AffineFastState.compose env416 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env417 : List Nat := [2,4,1,6,1,0,4,7,2,0,5,6,3,3,6,5,3,1,1,6,6,1,6,6,6,0,4,5,0,0,5,4,6,4,2,3]

theorem envBound417 : H12AffineFastState.Bounded env417 := by
  intro p hp
  have h : env417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans416_417 : H12AffineEnvironment.transform 2 1 env416 = env417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env416 == env417) = true)

def leafEnv417 : List Nat := [2,4,1,6,1,0,4,7,2,0,5,6,3,3,6,5,3,1,1,6,6,1,6,6,4,6,1,0,4,5,0,0,5,4,6,4,5,1,2,3,1,7,0]

def active417 : List Nat := [0,1]

def tree417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood417 : H12WitnessSearch.Good tree417 := H12GlobalWitnessIndex.good

theorem leafIdentity417 : H12AffineFastState.composeSystem env417 rootObs = leafEnv417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env417 rootObs == leafEnv417) = true)

theorem terminalChecked417 : H12PackedTerminal.terminalCheckFast leafEnv417 active417 tree417 = true := by decide +kernel

def env418 : List Nat := [2,4,8,15,32,1,44,15,43,0,5,14,35,43,47,13,43,32,0,47,15,32,14,39,7,0,4,36,1,33,5,4,15,4,42,42]

theorem envBound418 : H12AffineFastState.Bounded env418 := by
  intro p hp
  have h : env418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans412_418 : H12AffineEnvironment.transform 5 1 env412 = env418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env412 == env418) = true)

def env419 : List Nat := [2,4,8,15,0,1,12,15,11,0,5,14,3,11,15,13,11,0,0,15,15,0,14,7,7,0,4,4,1,1,5,4,15,4,10,10]

theorem envBound419 : H12AffineFastState.Bounded env419 := by
  intro p hp
  have h : env419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans418_419 : H12AffineEnvironment.transform 4 0 env418 = env419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env418 == env419) = true)

theorem identity419 : scanCanonicalize (H12AffineFastState.compose env419 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env420 : List Nat := [0,4,8,13,0,1,12,13,9,0,5,12,1,9,13,13,9,0,0,13,13,0,12,5,5,0,4,4,1,1,5,4,13,4,8,8]

theorem envBound420 : H12AffineFastState.Bounded env420 := by
  intro p hp
  have h : env420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans419_420 : H12AffineEnvironment.transform 0 0 env419 = env420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env419 == env420) = true)

def leafEnv420 : List Nat := [0,4,8,13,0,1,12,13,9,0,5,12,1,9,13,13,9,0,0,13,13,0,12,5,5,5,1,0,4,4,1,1,5,4,13,4,4,8,8,8,1,12,0]

def active420 : List Nat := [1,2]

def tree420 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood420 : H12WitnessSearch.Good tree420 := H12GlobalWitnessIndex.good

theorem leafIdentity420 : H12AffineFastState.composeSystem env420 rootObs = leafEnv420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env420 rootObs == leafEnv420) = true)

theorem terminalChecked420 : H12PackedTerminal.terminalCheckFast leafEnv420 active420 tree420 = true := by decide +kernel

def env421 : List Nat := [2,4,8,15,1,1,13,15,10,0,5,14,2,10,14,13,10,1,0,14,15,1,14,6,7,0,4,5,1,0,5,4,15,4,11,11]

theorem envBound421 : H12AffineFastState.Bounded env421 := by
  intro p hp
  have h : env421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans418_421 : H12AffineEnvironment.transform 4 1 env418 = env421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env418 == env421) = true)

theorem identity421 : scanCanonicalize (H12AffineFastState.compose env421 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env422 : List Nat := [2,2,8,9,1,1,11,9,10,0,3,8,2,10,8,11,10,1,0,8,9,1,8,0,1,0,2,3,1,0,3,2,9,2,11,11]

theorem envBound422 : H12AffineFastState.Bounded env422 := by
  intro p hp
  have h : env422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans421_422 : H12AffineEnvironment.transform 1 2 env421 = env422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env421 == env422) = true)

def leafEnv422 : List Nat := [2,2,8,9,1,1,11,9,10,0,3,8,2,10,8,11,10,1,0,8,9,1,8,0,3,1,1,0,2,3,1,0,3,2,9,2,2,9,11,11,1,8,0]

def active422 : List Nat := [0,2]

def tree422 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood422 : H12WitnessSearch.Good tree422 := H12GlobalWitnessIndex.good

theorem leafIdentity422 : H12AffineFastState.composeSystem env422 rootObs = leafEnv422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env422 rootObs == leafEnv422) = true)

theorem terminalChecked422 : H12PackedTerminal.terminalCheckFast leafEnv422 active422 tree422 = true := by decide +kernel

def env423 : List Nat := [2,4,8,16,32,64,45,80,107,1,5,78,124,43,113,76,52,33,64,113,17,32,80,57,89,0,4,36,94,63,5,26,17,26,42,117]

theorem envBound423 : H12AffineFastState.Bounded env423 := by
  intro p hp
  have h : env423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans410_423 : H12AffineEnvironment.transform 6 45 env410 = env423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 45 env410 == env423) = true)

def env424 : List Nat := [2,4,8,16,32,20,45,4,63,1,5,26,40,43,37,24,52,33,20,37,17,32,4,57,13,0,4,36,10,63,5,26,17,26,42,33]

theorem envBound424 : H12AffineFastState.Bounded env424 := by
  intro p hp
  have h : env424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans423_424 : H12AffineEnvironment.transform 5 20 env423 = env424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env423 == env424) = true)

theorem identity424 : scanCanonicalize (H12AffineFastState.compose env424 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound424 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env425 : List Nat := [2,4,8,15,32,11,45,4,32,1,5,5,40,43,37,7,43,33,11,37,14,32,4,38,13,0,4,36,10,32,5,5,14,5,42,33]

theorem envBound425 : H12AffineFastState.Bounded env425 := by
  intro p hp
  have h : env425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans424_425 : H12AffineEnvironment.transform 3 15 env424 = env425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env424 == env425) = true)

def env426 : List Nat := [2,4,8,15,4,11,9,4,4,1,5,5,12,15,1,7,15,5,11,1,14,4,4,2,13,0,4,0,10,4,5,5,14,5,14,5]

theorem envBound426 : H12AffineFastState.Bounded env426 := by
  intro p hp
  have h : env426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans425_426 : H12AffineEnvironment.transform 4 4 env425 = env426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env425 == env426) = true)

theorem identity426 : scanCanonicalize (H12AffineFastState.compose env426 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env427 : List Nat := [2,4,0,7,4,3,1,4,4,1,5,5,4,7,1,7,7,5,3,1,6,4,4,2,5,0,4,0,2,4,5,5,6,5,6,5]

theorem envBound427 : H12AffineFastState.Bounded env427 := by
  intro p hp
  have h : env427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans426_427 : H12AffineEnvironment.transform 2 0 env426 = env427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env426 == env427) = true)

def leafEnv427 : List Nat := [2,4,0,7,4,3,1,4,4,1,5,5,4,7,1,7,7,5,3,1,6,4,4,2,7,5,1,0,4,0,2,4,5,5,6,5,6,7,6,5,1,7,0]

def active427 : List Nat := [0,1]

def tree427 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood427 : H12WitnessSearch.Good tree427 := H12GlobalWitnessIndex.good

theorem leafIdentity427 : H12AffineFastState.composeSystem env427 rootObs = leafEnv427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env427 rootObs == leafEnv427) = true)

theorem terminalChecked427 : H12PackedTerminal.terminalCheckFast leafEnv427 active427 tree427 = true := by decide +kernel

def env428 : List Nat := [2,4,8,15,5,11,8,4,5,1,5,5,13,14,0,7,14,4,11,0,14,5,4,3,13,0,4,1,10,5,5,5,14,5,15,4]

theorem envBound428 : H12AffineFastState.Bounded env428 := by
  intro p hp
  have h : env428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans425_428 : H12AffineEnvironment.transform 4 5 env425 = env428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env425 == env428) = true)

theorem identity428 : scanCanonicalize (H12AffineFastState.compose env428 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env429 : List Nat := [2,3,8,8,2,11,8,3,2,1,2,2,10,9,0,0,9,3,11,0,9,2,3,3,10,0,3,1,10,2,2,2,9,2,8,3]

theorem envBound429 : H12AffineFastState.Bounded env429 := by
  intro p hp
  have h : env429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans428_429 : H12AffineEnvironment.transform 1 3 env428 = env429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env428 == env429) = true)

def leafEnv429 : List Nat := [2,3,8,8,2,11,8,3,2,1,2,2,10,9,0,0,9,3,11,0,9,2,3,3,8,10,1,0,3,1,10,2,2,2,9,2,9,1,8,3,1,8,0]

def active429 : List Nat := [0,2]

def tree429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood429 : H12WitnessSearch.Good tree429 := H12GlobalWitnessIndex.good

theorem leafIdentity429 : H12AffineFastState.composeSystem env429 rootObs = leafEnv429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env429 rootObs == leafEnv429) = true)

theorem terminalChecked429 : H12PackedTerminal.terminalCheckFast leafEnv429 active429 tree429 = true := by decide +kernel

def env430 : List Nat := [2,4,8,16,32,21,45,5,62,1,5,27,41,43,36,25,52,33,21,36,17,32,5,57,12,0,4,36,11,63,5,26,17,26,42,32]

theorem envBound430 : H12AffineFastState.Bounded env430 := by
  intro p hp
  have h : env430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans423_430 : H12AffineEnvironment.transform 5 21 env423 = env430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env423 == env430) = true)

def env431 : List Nat := [2,4,8,0,32,5,45,5,46,1,5,11,41,43,36,9,36,33,5,36,1,32,5,41,12,0,4,36,11,47,5,10,1,10,42,32]

theorem envBound431 : H12AffineFastState.Bounded env431 := by
  intro p hp
  have h : env431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans430_431 : H12AffineEnvironment.transform 3 0 env430 = env431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env430 == env431) = true)

theorem identity431 : scanCanonicalize (H12AffineFastState.compose env431 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound431 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env432 : List Nat := [2,4,8,0,9,5,4,5,7,1,5,11,0,2,13,9,13,8,5,13,1,9,5,0,12,0,4,13,11,6,5,10,1,10,3,9]

theorem envBound432 : H12AffineFastState.Bounded env432 := by
  intro p hp
  have h : env432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans431_432 : H12AffineEnvironment.transform 4 9 env431 = env432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env431 == env432) = true)

def env433 : List Nat := [2,4,0,0,1,5,4,5,7,1,5,3,0,2,5,1,5,0,5,5,1,1,5,0,4,0,4,5,3,6,5,2,1,2,3,1]

theorem envBound433 : H12AffineFastState.Bounded env433 := by
  intro p hp
  have h : env433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans432_433 : H12AffineEnvironment.transform 2 0 env432 = env433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env432 == env433) = true)

theorem identity433 : scanCanonicalize (H12AffineFastState.compose env433 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env434 : List Nat := [2,3,0,0,1,2,3,2,0,1,2,3,0,2,2,1,2,0,2,2,1,1,2,0,3,0,3,2,3,1,2,2,1,2,3,1]

theorem envBound434 : H12AffineFastState.Bounded env434 := by
  intro p hp
  have h : env434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans433_434 : H12AffineEnvironment.transform 1 3 env433 = env434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env433 == env434) = true)

def leafEnv434 : List Nat := [2,3,0,0,1,2,3,2,0,1,2,3,0,2,2,1,2,0,2,2,1,1,2,0,1,3,1,0,3,2,3,1,2,2,1,2,0,3,3,1,1,0,0]

def active434 : List Nat := [0]

def tree434 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood434 : H12WitnessSearch.Good tree434 := H12GlobalWitnessIndex.good

theorem leafIdentity434 : H12AffineFastState.composeSystem env434 rootObs = leafEnv434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env434 rootObs == leafEnv434) = true)

theorem terminalChecked434 : H12PackedTerminal.terminalCheckFast leafEnv434 active434 tree434 = true := by decide +kernel

def env435 : List Nat := [2,4,1,0,0,5,4,5,7,1,5,2,0,2,4,0,4,1,5,4,1,0,5,0,5,0,4,4,2,6,5,3,1,3,3,0]

theorem envBound435 : H12AffineFastState.Bounded env435 := by
  intro p hp
  have h : env435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans432_435 : H12AffineEnvironment.transform 2 1 env432 = env435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env432 == env435) = true)

def env436 : List Nat := [2,0,1,0,0,1,0,1,3,1,1,2,0,2,0,0,0,1,1,0,1,0,1,0,1,0,0,0,2,2,1,3,1,3,3,0]

theorem envBound436 : H12AffineFastState.Bounded env436 := by
  intro p hp
  have h : env436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans435_436 : H12AffineEnvironment.transform 1 0 env435 = env436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env435 == env436) = true)

theorem identity436 : scanCanonicalize (H12AffineFastState.compose env436 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound436 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env437 : List Nat := [0,0,1,0,0,1,0,1,1,1,1,0,0,0,0,0,0,1,1,0,1,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0]

theorem envBound437 : H12AffineFastState.Bounded env437 := by
  intro p hp
  have h : env437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans436_437 : H12AffineEnvironment.transform 0 0 env436 = env437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env436 == env437) = true)

def leafEnv437 : List Nat := [0,0,1,0,0,1,0,1,1,1,1,0,0,0,0,0,0,1,1,0,1,0,1,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0,1,0,1,0,0]

def active437 : List Nat := []

def tree437 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood437 : H12WitnessSearch.Good tree437 := H12GlobalWitnessIndex.good

theorem leafIdentity437 : H12AffineFastState.composeSystem env437 rootObs = leafEnv437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env437 rootObs == leafEnv437) = true)

theorem terminalChecked437 : H12PackedTerminal.terminalCheckFast leafEnv437 active437 tree437 = true := by decide +kernel

def env438 : List Nat := [2,1,1,0,0,0,1,0,2,1,0,2,0,2,1,0,1,1,0,1,1,0,0,0,0,0,1,1,2,3,0,3,1,3,3,0]

theorem envBound438 : H12AffineFastState.Bounded env438 := by
  intro p hp
  have h : env438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans435_438 : H12AffineEnvironment.transform 1 1 env435 = env438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env435 == env438) = true)

def leafEnv438 : List Nat := [2,1,1,0,0,0,1,0,2,1,0,2,0,2,1,0,1,1,0,1,1,0,0,0,1,0,1,0,1,1,2,3,0,3,1,3,0,2,3,0,1,3,0]

def active438 : List Nat := [0]

def tree438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood438 : H12WitnessSearch.Good tree438 := H12GlobalWitnessIndex.good

theorem leafIdentity438 : H12AffineFastState.composeSystem env438 rootObs = leafEnv438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env438 rootObs == leafEnv438) = true)

theorem terminalChecked438 : H12PackedTerminal.terminalCheckFast leafEnv438 active438 tree438 = true := by decide +kernel

def env439 : List Nat := [2,4,8,1,32,4,45,5,47,1,5,10,41,43,36,8,37,33,4,36,0,32,5,40,12,0,4,36,11,46,5,11,0,11,42,32]

theorem envBound439 : H12AffineFastState.Bounded env439 := by
  intro p hp
  have h : env439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans430_439 : H12AffineEnvironment.transform 3 1 env430 = env439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env430 == env439) = true)

theorem identity439 : scanCanonicalize (H12AffineFastState.compose env439 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound439 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env440 : List Nat := [0,4,8,1,32,4,45,5,45,1,5,8,41,41,36,8,37,33,4,36,0,32,5,40,12,0,4,36,9,44,5,9,0,9,40,32]

theorem envBound440 : H12AffineFastState.Bounded env440 := by
  intro p hp
  have h : env440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans439_440 : H12AffineEnvironment.transform 0 0 env439 = env440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env439 == env440) = true)

theorem identity440 : scanCanonicalize (H12AffineFastState.compose env440 (packedSelected [7,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound440 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env441 : List Nat := [0,4,4,1,32,4,33,5,33,1,5,4,37,37,36,4,37,33,4,36,0,32,5,36,0,0,4,36,5,32,5,5,0,5,36,32]

theorem envBound441 : H12AffineFastState.Bounded env441 := by
  intro p hp
  have h : env441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans440_441 : H12AffineEnvironment.transform 2 4 env440 = env441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env440 == env441) = true)

def leafEnv441 : List Nat := [0,4,4,1,32,4,33,5,33,1,5,4,37,37,36,4,37,33,4,36,0,32,5,36,0,0,1,0,4,36,5,32,5,5,0,5,1,32,36,32,1,1,0]

def active441 : List Nat := [1,4]

def tree441 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood441 : H12WitnessSearch.Good tree441 := H12GlobalWitnessIndex.good

theorem leafIdentity441 : H12AffineFastState.composeSystem env441 rootObs = leafEnv441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env441 rootObs == leafEnv441) = true)

theorem terminalChecked441 : H12PackedTerminal.terminalCheckFast leafEnv441 active441 tree441 = true := by decide +kernel

def env442 : List Nat := [2,4,8,16,32,64,128,253,512,173,706,4096,208,4296,112,4713,754,587,237,112,635,32,81,4784,88,1,707,739,4113,4209,4,4755,189,4755,4297,4154]

theorem envBound442 : H12AffineFastState.Bounded env442 := by
  intro p hp
  have h : env442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans374_442 : H12AffineEnvironment.transform 9 173 env374 = env442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env374 == env442) = true)

theorem identity442 : scanCanonicalize (H12AffineFastState.compose env442 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env443 : List Nat := [2,4,8,16,32,64,128,253,512,173,706,570,208,754,112,83,754,587,237,112,635,32,81,138,88,1,707,739,555,587,4,169,189,169,755,512]

theorem envBound443 : H12AffineFastState.Bounded env443 := by
  intro p hp
  have h : env443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans442_443 : H12AffineEnvironment.transform 11 570 env442 = env443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env442 == env443) = true)

theorem identity443 : scanCanonicalize (H12AffineFastState.compose env443 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound443 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env444 : List Nat := [2,4,8,16,32,64,128,253,31,173,221,37,208,237,112,83,237,84,237,112,100,32,81,138,88,1,220,252,52,84,4,169,189,169,236,31]

theorem envBound444 : H12AffineFastState.Bounded env444 := by
  intro p hp
  have h : env444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans443_444 : H12AffineEnvironment.transform 8 31 env443 = env444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env443 == env444) = true)

theorem identity444 : scanCanonicalize (H12AffineFastState.compose env444 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound444 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env445 : List Nat := [2,4,8,16,32,64,50,79,31,31,111,37,98,95,112,83,95,84,95,112,100,32,81,56,88,1,110,78,52,84,4,27,15,27,94,31]

theorem envBound445 : H12AffineFastState.Bounded env445 := by
  intro p hp
  have h : env445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans444_445 : H12AffineEnvironment.transform 6 50 env444 = env445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env444 == env445) = true)

theorem identity445 : scanCanonicalize (H12AffineFastState.compose env445 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound445 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env446 : List Nat := [2,4,8,16,1,64,19,79,31,31,78,4,67,95,81,83,95,84,95,81,69,1,81,25,88,1,79,78,21,84,4,27,15,27,94,31]

theorem envBound446 : H12AffineFastState.Bounded env446 := by
  intro p hp
  have h : env446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans445_446 : H12AffineEnvironment.transform 4 1 env445 = env446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env445 == env446) = true)

theorem identity446 : scanCanonicalize (H12AffineFastState.compose env446 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound446 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env447 : List Nat := [2,4,8,16,1,11,19,4,31,31,5,4,8,20,26,24,20,31,20,26,14,1,26,25,19,1,4,5,21,31,4,27,15,27,21,31]

theorem envBound447 : H12AffineFastState.Bounded env447 := by
  intro p hp
  have h : env447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans446_447 : H12AffineEnvironment.transform 5 11 env446 = env447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env446 == env447) = true)

theorem identity447 : scanCanonicalize (H12AffineFastState.compose env447 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound447 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env448 : List Nat := [2,4,8,11,1,11,8,4,4,4,5,4,8,15,1,3,15,4,15,1,14,1,1,2,8,1,4,5,14,4,4,0,15,0,14,4]

theorem envBound448 : H12AffineFastState.Bounded env448 := by
  intro p hp
  have h : env448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans447_448 : H12AffineEnvironment.transform 3 11 env447 = env448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env447 == env448) = true)

theorem identity448 : scanCanonicalize (H12AffineFastState.compose env448 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env449 : List Nat := [2,4,0,3,1,3,0,4,4,4,5,4,0,7,1,3,7,4,7,1,6,1,1,2,0,1,4,5,6,4,4,0,7,0,6,4]

theorem envBound449 : H12AffineFastState.Bounded env449 := by
  intro p hp
  have h : env449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans448_449 : H12AffineEnvironment.transform 2 0 env448 = env449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env448 == env449) = true)

theorem identity449 : scanCanonicalize (H12AffineFastState.compose env449 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound449 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env450 : List Nat := [0,4,0,1,1,1,0,4,4,4,5,4,0,5,1,1,5,4,5,1,4,1,1,0,0,1,4,5,4,4,4,0,5,0,4,4]

theorem envBound450 : H12AffineFastState.Bounded env450 := by
  intro p hp
  have h : env450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans449_450 : H12AffineEnvironment.transform 0 0 env449 = env450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env449 == env450) = true)

def leafEnv450 : List Nat := [0,4,0,1,1,1,0,4,4,4,5,4,0,5,1,1,5,4,5,1,4,1,1,0,5,0,1,1,4,5,4,4,4,0,5,0,5,1,4,4,1,4,0]

def active450 : List Nat := [1]

def tree450 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood450 : H12WitnessSearch.Good tree450 := H12GlobalWitnessIndex.good

theorem leafIdentity450 : H12AffineFastState.composeSystem env450 rootObs = leafEnv450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env450 rootObs == leafEnv450) = true)

theorem terminalChecked450 : H12PackedTerminal.terminalCheckFast leafEnv450 active450 tree450 = true := by decide +kernel

def env451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,131072,262144,524288,8352,656584,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,268353,74371]

theorem envBound451 : H12AffineFastState.Bounded env451 := by
  intro p hp
  have h : env451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans274_451 : H12AffineEnvironment.transform 13 4297 env274 = env451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4297 env274 == env451) = true)

theorem identity451 : scanCanonicalize (H12AffineFastState.compose env451 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 236) := by decide +kernel

theorem selectedBound451 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,131072,262144,236,8352,132132,32,1277,74228,8328,1197,262280,132285,5309,76279,1364,73770,1516,74199,268353,74371]

theorem envBound452 : H12AffineFastState.Bounded env452 := by
  intro p hp
  have h : env452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans451_452 : H12AffineEnvironment.transform 18 236 env451 = env452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 236 env451 == env452) = true)

def env453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,131072,138512,236,8352,132132,32,1277,74228,8328,1197,138648,132285,5309,76279,1364,73770,1516,74199,132433,74371]

theorem envBound453 : H12AffineFastState.Bounded env453 := by
  intro p hp
  have h : env453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans452_453 : H12AffineEnvironment.transform 17 138512 env452 = env453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138512 env452 == env453) = true)

def env454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,5220,2420,236,8352,4160,32,1277,74228,8328,1197,2556,4313,5309,76279,1364,73770,1516,74199,4405,74371]

theorem envBound454 : H12AffineFastState.Bounded env454 := by
  intro p hp
  have h : env454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans453_454 : H12AffineEnvironment.transform 16 5220 env453 = env454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env453 == env454) = true)

theorem identity454 : scanCanonicalize (H12AffineFastState.compose env454 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound454 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env455 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8352,65536,5220,2185,236,8352,4160,32,1277,73737,8328,1197,2049,4313,5309,75786,1193,73770,1041,73770,4296,74371]

theorem envBound455 : H12AffineFastState.Bounded env455 := by
  intro p hp
  have h : env455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans454_455 : H12AffineEnvironment.transform 7 253 env454 = env455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env454 == env455) = true)

theorem identity455 : scanCanonicalize (H12AffineFastState.compose env455 (packedSelected [0,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound455 : packedSelected [0,6,7,10] rootPS < 2^1333 := by decide +kernel

def env456 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,7301,4297,7205,65536,5220,2185,236,7205,4160,32,1277,72844,7181,1197,2049,4313,5309,70799,1193,72879,1041,72879,4296,73222]

theorem envBound456 : H12AffineFastState.Bounded env456 := by
  intro p hp
  have h : env456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans455_456 : H12AffineEnvironment.transform 12 7301 env455 = env456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env455 == env456) = true)

theorem identity456 : scanCanonicalize (H12AffineFastState.compose env456 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 4712) := by decide +kernel

theorem selectedBound456 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env457 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,7301,4297,7205,4712,5220,2185,236,7205,4160,32,1277,3812,7181,1197,2049,4313,5309,1767,1193,3783,1041,3783,4296,3182]

theorem envBound457 : H12AffineFastState.Bounded env457 := by
  intro p hp
  have h : env457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans456_457 : H12AffineEnvironment.transform 15 4712 env456 = env457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4712 env456 == env457) = true)

theorem identity457 : scanCanonicalize (H12AffineFastState.compose env457 (packedSelected [0,3,5,6,7,15] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound457 : packedSelected [0,3,5,6,7,15] rootPS < 2^1333 := by decide +kernel

def env458 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,4096,4843,4297,4683,4712,5220,1767,236,4683,4160,32,1277,138,4707,1197,1647,4313,5309,1767,1193,169,1041,169,4296,512]

theorem envBound458 : H12AffineFastState.Bounded env458 := by
  intro p hp
  have h : env458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans457_458 : H12AffineEnvironment.transform 10 1646 env457 = env458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env457 == env458) = true)

theorem identity458 : scanCanonicalize (H12AffineFastState.compose env458 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1686) := by decide +kernel

theorem selectedBound458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env459 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,1686,1149,1631,1245,1278,754,1767,236,1245,1750,32,1277,138,1269,1197,1647,1615,555,1767,1193,169,1041,169,1630,512]

theorem envBound459 : H12AffineFastState.Bounded env459 := by
  intro p hp
  have h : env459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans458_459 : H12AffineEnvironment.transform 11 1686 env458 = env459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1686 env458 == env459) = true)

theorem identity459 : scanCanonicalize (H12AffineFastState.compose env459 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound459 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env460 : List Nat := [2,4,8,16,32,64,128,253,512,30,624,648,99,577,195,224,754,761,236,195,712,32,227,138,235,179,625,593,555,761,183,169,15,169,576,512]

theorem envBound460 : H12AffineFastState.Bounded env460 := by
  intro p hp
  have h : env460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans459_460 : H12AffineEnvironment.transform 9 30 env459 = env460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env459 == env460) = true)

theorem identity460 : scanCanonicalize (H12AffineFastState.compose env460 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound460 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env461 : List Nat := [2,4,8,16,32,64,19,110,512,30,624,539,99,577,80,115,609,618,127,80,603,32,112,25,120,32,625,593,555,618,36,58,15,58,576,512]

theorem envBound461 : H12AffineFastState.Bounded env461 := by
  intro p hp
  have h : env461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans460_461 : H12AffineEnvironment.transform 6 19 env460 = env461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env460 == env461) = true)

theorem identity461 : scanCanonicalize (H12AffineFastState.compose env461 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound461 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env462 : List Nat := [2,4,8,16,32,11,19,37,512,30,571,539,40,522,27,56,554,545,52,27,528,32,59,25,51,32,570,538,555,545,36,58,15,58,523,512]

theorem envBound462 : H12AffineFastState.Bounded env462 := by
  intro p hp
  have h : env462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans461_462 : H12AffineEnvironment.transform 5 11 env461 = env462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env461 == env462) = true)

theorem identity462 : scanCanonicalize (H12AffineFastState.compose env462 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env463 : List Nat := [2,4,8,16,32,11,19,37,37,30,30,62,40,47,27,56,15,4,52,27,53,32,59,25,51,32,31,63,14,4,36,58,15,58,46,37]

theorem envBound463 : H12AffineFastState.Bounded env463 := by
  intro p hp
  have h : env463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans462_463 : H12AffineEnvironment.transform 8 37 env462 = env463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env462 == env463) = true)

theorem identity463 : scanCanonicalize (H12AffineFastState.compose env463 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound463 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env464 : List Nat := [2,4,8,10,32,11,9,37,37,4,4,36,40,47,1,34,15,4,46,1,47,32,33,3,41,32,5,37,14,4,36,32,15,32,46,37]

theorem envBound464 : H12AffineFastState.Bounded env464 := by
  intro p hp
  have h : env464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans463_464 : H12AffineEnvironment.transform 3 10 env463 = env464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env463 == env464) = true)

theorem identity464 : scanCanonicalize (H12AffineFastState.compose env464 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound464 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env465 : List Nat := [2,4,8,10,10,11,9,15,15,4,4,14,2,5,1,8,15,4,4,1,5,10,11,3,3,10,5,15,14,4,14,10,15,10,4,15]

theorem envBound465 : H12AffineFastState.Bounded env465 := by
  intro p hp
  have h : env465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans464_465 : H12AffineEnvironment.transform 4 10 env464 = env465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env464 == env465) = true)

theorem identity465 : scanCanonicalize (H12AffineFastState.compose env465 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env466 : List Nat := [1,4,8,9,9,8,9,12,12,4,4,13,1,5,1,8,12,4,4,1,5,9,8,0,0,9,5,12,13,4,13,9,12,9,4,12]

theorem envBound466 : H12AffineFastState.Bounded env466 := by
  intro p hp
  have h : env466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans465_466 : H12AffineEnvironment.transform 0 1 env465 = env466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env465 == env466) = true)

def leafEnv466 : List Nat := [1,4,8,9,9,8,9,12,12,4,4,13,1,5,1,8,12,4,4,1,5,9,8,0,13,0,1,9,5,12,13,4,13,9,12,9,4,9,4,12,1,5,0]

def active466 : List Nat := [1,2]

def tree466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood466 : H12WitnessSearch.Good tree466 := H12GlobalWitnessIndex.good

theorem leafIdentity466 : H12AffineFastState.composeSystem env466 rootObs = leafEnv466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env466 rootObs == leafEnv466) = true)

theorem terminalChecked466 : H12PackedTerminal.terminalCheckFast leafEnv466 active466 tree466 = true := by decide +kernel

def env467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,65536,5221,2421,236,8352,4161,32,1277,74228,8328,1197,2557,4312,5309,76279,1364,73770,1516,74199,4404,74371]

theorem envBound467 : H12AffineFastState.Bounded env467 := by
  intro p hp
  have h : env467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans453_467 : H12AffineEnvironment.transform 16 5221 env453 = env467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env453 == env467) = true)

theorem identity467 : scanCanonicalize (H12AffineFastState.compose env467 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound467 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8352,8574,5221,2421,236,8352,4161,32,1277,138,8328,1197,2557,4312,5309,2185,1364,340,1516,169,4404,1021]

theorem envBound468 : H12AffineFastState.Bounded env468 := by
  intro p hp
  have h : env468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans467_468 : H12AffineEnvironment.transform 15 8574 env467 = env468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env467 == env468) = true)

theorem identity468 : scanCanonicalize (H12AffineFastState.compose env468 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 2980) := by decide +kernel

theorem selectedBound468 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2980,4297,2820,2778,5221,2421,236,2820,4161,32,1277,138,2860,1197,2557,4312,5309,2185,1364,340,1516,169,4404,1021]

theorem envBound469 : H12AffineFastState.Bounded env469 := by
  intro p hp
  have h : env469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans468_469 : H12AffineEnvironment.transform 12 2980 env468 = env469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2980 env468 == env469) = true)

theorem identity469 : scanCanonicalize (H12AffineFastState.compose env469 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound469 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env470 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,2980,4297,2820,2778,4605,2421,236,2820,4161,32,357,138,2860,309,2557,4312,4389,2185,204,340,116,169,4404,1021]

theorem envBound470 : H12AffineFastState.Bounded env470 := by
  intro p hp
  have h : env470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans469_470 : H12AffineEnvironment.transform 9 408 env469 = env470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env469 == env470) = true)

theorem identity470 : scanCanonicalize (H12AffineFastState.compose env470 (packedSelected [1,2,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound470 : packedSelected [1,2,5,6,10] rootPS < 2^1333 := by decide +kernel

def env471 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,2356,2980,2557,2820,2778,2249,2421,236,2820,2421,32,357,138,2860,309,2557,2540,2065,2185,204,340,116,169,2048,1021]

theorem envBound471 : H12AffineFastState.Bounded env471 := by
  intro p hp
  have h : env471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans470_471 : H12AffineEnvironment.transform 11 2356 env470 = env471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env470 == env471) = true)

theorem identity471 : scanCanonicalize (H12AffineFastState.compose env471 (packedSelected [2,3,5,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 853) := by decide +kernel

theorem selectedBound471 : packedSelected [2,3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env472 : List Nat := [2,4,8,16,32,64,128,256,512,408,853,609,241,680,81,399,924,544,236,81,544,32,357,138,121,309,680,697,836,988,204,340,116,169,853,1021]

theorem envBound472 : H12AffineFastState.Bounded env472 := by
  intro p hp
  have h : env472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans471_472 : H12AffineEnvironment.transform 10 853 env471 = env472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 853 env471 == env472) = true)

theorem identity472 : scanCanonicalize (H12AffineFastState.compose env472 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 388) := by decide +kernel

theorem selectedBound472 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env473 : List Nat := [2,4,8,16,32,64,128,256,388,408,209,485,241,300,81,399,24,420,236,81,420,32,357,138,121,309,300,317,192,88,204,340,116,169,209,121]

theorem envBound473 : H12AffineFastState.Bounded env473 := by
  intro p hp
  have h : env473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans472_473 : H12AffineEnvironment.transform 8 388 env472 = env473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 388 env472 == env473) = true)

theorem identity473 : scanCanonicalize (H12AffineFastState.compose env473 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound473 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env474 : List Nat := [2,4,8,16,32,64,18,256,278,266,67,375,99,300,81,285,24,310,126,81,310,32,357,24,121,309,300,317,82,88,94,340,116,59,67,121]

theorem envBound474 : H12AffineFastState.Bounded env474 := by
  intro p hp
  have h : env474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans473_474 : H12AffineEnvironment.transform 6 18 env473 = env474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env473 == env474) = true)

theorem identity474 : scanCanonicalize (H12AffineFastState.compose env474 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound474 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env475 : List Nat := [2,4,8,16,32,64,18,69,83,79,67,50,99,105,81,88,24,115,126,81,115,32,32,24,121,112,105,120,82,88,94,17,116,59,67,121]

theorem envBound475 : H12AffineFastState.Bounded env475 := by
  intro p hp
  have h : env475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans474_475 : H12AffineEnvironment.transform 7 69 env474 = env475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env474 == env475) = true)

theorem identity475 : scanCanonicalize (H12AffineFastState.compose env475 (packedSelected [0,14] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound475 : packedSelected [0,14] rootPS < 2^1333 := by decide +kernel

def env476 : List Nat := [2,4,8,16,32,32,18,37,51,47,35,50,3,9,49,56,24,19,30,49,19,32,32,24,25,16,9,24,50,56,62,17,20,59,35,25]

theorem envBound476 : H12AffineFastState.Bounded env476 := by
  intro p hp
  have h : env476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans475_476 : H12AffineEnvironment.transform 5 32 env475 = env476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env475 == env476) = true)

theorem identity476 : scanCanonicalize (H12AffineFastState.compose env476 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound476 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env477 : List Nat := [2,4,8,16,16,16,18,21,3,31,19,2,3,9,1,8,24,19,30,1,19,16,16,24,25,16,9,24,2,8,14,17,20,11,19,25]

theorem envBound477 : H12AffineFastState.Bounded env477 := by
  intro p hp
  have h : env477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans476_477 : H12AffineEnvironment.transform 4 16 env476 = env477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env476 == env477) = true)

end H12CloudChart0