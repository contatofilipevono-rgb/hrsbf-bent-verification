import H12CloudChart0Data201

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans51143_51144 : H12AffineEnvironment.transform 10 1076 env51143 = env51144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env51143 == env51144) = true)

theorem identity51144 : scanCanonicalize (H12AffineFastState.compose env51144 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound51144 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51145 : List Nat := [2,4,8,16,32,16,8,256,512,304,260,308,40,261,1,35,276,260,305,0,293,33,309,3,40,17,33,48,17,32,52,33,257,33,32,513]

theorem envBound51145 : H12AffineFastState.Bounded env51145 := by
  intro p hp
  have h : env51145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51144_51145 : H12AffineEnvironment.transform 9 304 env51144 = env51145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env51144 == env51145) = true)

theorem identity51145 : scanCanonicalize (H12AffineFastState.compose env51145 (packedSelected [0,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 62) := by decide +kernel

theorem selectedBound51145 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env51146 : List Nat := [2,4,8,16,32,16,8,256,62,304,260,308,40,261,1,35,276,260,305,0,293,33,309,3,40,17,33,48,17,32,52,33,257,33,32,63]

theorem envBound51146 : H12AffineFastState.Bounded env51146 := by
  intro p hp
  have h : env51146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51145_51146 : H12AffineEnvironment.transform 8 62 env51145 = env51146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 62 env51145 == env51146) = true)

theorem identity51146 : scanCanonicalize (H12AffineFastState.compose env51146 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51146 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env51147 : List Nat := [2,4,8,16,32,16,8,37,62,21,33,17,40,32,1,35,49,33,20,0,0,33,16,3,40,17,33,48,17,32,52,33,36,33,32,63]

theorem envBound51147 : H12AffineFastState.Bounded env51147 := by
  intro p hp
  have h : env51147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51146_51147 : H12AffineEnvironment.transform 7 37 env51146 = env51147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51146 == env51147) = true)

theorem identity51147 : scanCanonicalize (H12AffineFastState.compose env51147 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound51147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51148 : List Nat := [2,4,8,16,20,16,8,17,10,21,21,17,28,20,1,23,5,21,20,0,0,21,16,3,28,17,21,4,17,20,0,21,16,21,20,11]

theorem envBound51148 : H12AffineFastState.Bounded env51148 := by
  intro p hp
  have h : env51148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51147_51148 : H12AffineEnvironment.transform 4 20 env51147 = env51148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env51147 == env51148) = true)

theorem identity51148 : scanCanonicalize (H12AffineFastState.compose env51148 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound51148 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51149 : List Nat := [2,4,8,9,13,9,8,8,10,12,12,8,5,13,1,14,5,12,13,0,0,12,9,3,5,8,12,4,8,13,0,12,9,12,13,11]

theorem envBound51149 : H12AffineFastState.Bounded env51149 := by
  intro p hp
  have h : env51149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51148_51149 : H12AffineEnvironment.transform 3 9 env51148 = env51149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env51148 == env51149) = true)

def env51150 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77851,73770,62492,21762,8192,16,157981,57629,102662,138293,75022,73770,257,21792,46093,513]

theorem envBound51150 : H12AffineFastState.Bounded env51150 := by
  intro p hp
  have h : env51150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51136_51150 : H12AffineEnvironment.transform 5 17 env51136 = env51150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51136 == env51150) = true)

theorem identity51150 : scanCanonicalize (H12AffineFastState.compose env51150 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51150 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env51151 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,131072,10280,1025,1,77851,73770,29724,21762,8192,16,157981,24861,69894,138293,75022,73770,257,21792,13325,513]

theorem envBound51151 : H12AffineFastState.Bounded env51151 := by
  intro p hp
  have h : env51151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51150_51151 : H12AffineEnvironment.transform 14 0 env51150 = env51151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51150 == env51151) = true)

theorem identity51151 : scanCanonicalize (H12AffineFastState.compose env51151 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound51151 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env51152 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,10280,1025,1,77851,73770,29724,21762,8192,16,10509,24861,69894,23589,75022,73770,257,21792,13325,513]

theorem envBound51152 : H12AffineFastState.Bounded env51152 := by
  intro p hp
  have h : env51152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51151_51152 : H12AffineEnvironment.transform 16 16400 env51151 = env51152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51151 == env51152) = true)

theorem identity51152 : scanCanonicalize (H12AffineFastState.compose env51152 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51152 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51153 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1025,1,4112,33,29724,21762,8192,16,10509,24861,12557,23589,1285,33,257,21792,13325,513]

theorem envBound51153 : H12AffineFastState.Bounded env51153 := by
  intro p hp
  have h : env51153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51152_51153 : H12AffineEnvironment.transform 15 8203 env51152 = env51153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51152 == env51153) = true)

theorem identity51153 : scanCanonicalize (H12AffineFastState.compose env51153 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51153 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51154 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,0,8203,13341,10280,1025,1,4112,33,17,8463,8192,16,10509,5392,12557,10280,1285,33,257,8493,13325,513]

theorem envBound51154 : H12AffineFastState.Bounded env51154 := by
  intro p hp
  have h : env51154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51153_51154 : H12AffineEnvironment.transform 13 13325 env51153 = env51154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51153 == env51154) = true)

theorem identity51154 : scanCanonicalize (H12AffineFastState.compose env51154 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51154 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env51155 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5392,2341,1025,1,4112,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound51155 : H12AffineFastState.Bounded env51155 := by
  intro p hp
  have h : env51155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51154_51155 : H12AffineEnvironment.transform 12 269 env51154 = env51155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51154 == env51155) = true)

theorem identity51155 : scanCanonicalize (H12AffineFastState.compose env51155 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51155 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51156 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5173,2048,1025,1,4112,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound51156 : H12AffineFastState.Bounded env51156 := by
  intro p hp
  have h : env51156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51155_51156 : H12AffineEnvironment.transform 7 37 env51155 = env51156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51155 == env51156) = true)

def env51157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77898,73771,62540,21763,8192,65,158028,57677,102742,138340,75103,73770,257,21792,46093,513]

theorem envBound51157 : H12AffineFastState.Bounded env51157 := by
  intro p hp
  have h : env51157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51135_51157 : H12AffineEnvironment.transform 17 10281 env51135 = env51157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51135 == env51157) = true)

theorem identity51157 : scanCanonicalize (H12AffineFastState.compose env51157 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51157 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,4161,32,62540,21763,8192,65,158028,57677,45405,138340,1364,33,257,21792,46093,513]

theorem envBound51158 : H12AffineFastState.Bounded env51158 := by
  intro p hp
  have h : env51158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51157_51158 : H12AffineEnvironment.transform 15 8203 env51157 = env51158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51157 == env51158) = true)

theorem identity51158 : scanCanonicalize (H12AffineFastState.compose env51158 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 16693) := by decide +kernel

theorem selectedBound51158 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env51159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16693,10281,1025,32769,4161,32,62540,21763,8192,65,10361,57677,45405,23889,1364,33,257,21792,46093,513]

theorem envBound51159 : H12AffineFastState.Bounded env51159 := by
  intro p hp
  have h : env51159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51158_51159 : H12AffineEnvironment.transform 16 16693 env51158 = env51159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16693 env51158 == env51159) = true)

theorem identity51159 : scanCanonicalize (H12AffineFastState.compose env51159 (packedSelected [2,4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound51159 : packedSelected [2,4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env51160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,32768,2162,16693,80,1025,32769,4161,32,56373,21763,2169,65,0,51508,39204,23889,1364,33,257,21792,40052,513]

theorem envBound51160 : H12AffineFastState.Bounded env51160 := by
  intro p hp
  have h : env51160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51159_51160 : H12AffineEnvironment.transform 12 2169 env51159 = env51160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env51159 == env51160) = true)

theorem identity51160 : scanCanonicalize (H12AffineFastState.compose env51160 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 23588) := by decide +kernel

theorem selectedBound51160 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,23588,2162,16693,80,1025,23589,4161,32,17,21763,2169,65,0,5392,17664,23889,1364,33,257,21792,16464,513]

theorem envBound51161 : H12AffineFastState.Bounded env51161 := by
  intro p hp
  have h : env51161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51160_51161 : H12AffineEnvironment.transform 14 23588 env51160 = env51161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23588 env51160 == env51161) = true)

theorem identity51161 : scanCanonicalize (H12AffineFastState.compose env51161 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound51161 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env51162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,7285,81,2162,7488,80,1025,80,4161,32,17,2422,2169,65,0,5392,6517,292,1364,33,257,2389,7205,513]

theorem envBound51162 : H12AffineFastState.Bounded env51162 := by
  intro p hp
  have h : env51162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51161_51162 : H12AffineEnvironment.transform 13 7285 env51161 = env51162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env51161 == env51162) = true)

theorem identity51162 : scanCanonicalize (H12AffineFastState.compose env51162 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound51162 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1360,2169,2341,81,2162,2064,80,1025,80,1297,32,17,2422,2169,65,0,64,3109,292,1364,33,257,2389,2421,513]

theorem envBound51163 : H12AffineFastState.Bounded env51163 := by
  intro p hp
  have h : env51163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51162_51163 : H12AffineEnvironment.transform 11 1360 env51162 = env51163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env51162 == env51163) = true)

theorem identity51163 : scanCanonicalize (H12AffineFastState.compose env51163 (packedSelected [0,1,4,6,7,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51163 : packedSelected [0,1,4,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env51164 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,65,2169,2341,81,2162,2064,80,272,80,0,32,17,2422,2169,65,0,64,2356,292,69,33,257,2389,2421,513]

theorem envBound51164 : H12AffineFastState.Bounded env51164 := by
  intro p hp
  have h : env51164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51163_51164 : H12AffineEnvironment.transform 9 273 env51163 = env51164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51163 == env51164) = true)

def env51165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318565,2444640,8192,65,158029,313700,2394421,138340,2102549,2101345,257,21792,46093,2175563]

theorem envBound51165 : H12AffineFastState.Bounded env51165 := by
  intro p hp
  have h : env51165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51133_51165 : H12AffineEnvironment.transform 21 2373705 env51133 = env51165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env51133 == env51165) = true)

def env51166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318565,351520,8192,65,158029,313700,301429,138340,1365,33,257,21792,46093,74251]

theorem envBound51166 : H12AffineFastState.Bounded env51166 := by
  intro p hp
  have h : env51166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51165_51166 : H12AffineEnvironment.transform 20 4160 env51165 = env51166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51165 == env51166) = true)

theorem identity51166 : scanCanonicalize (H12AffineFastState.compose env51166 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound51166 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,4160,272393,318565,297334,8192,65,158029,313700,301429,138340,1365,33,257,21792,46093,63069]

theorem envBound51167 : H12AffineFastState.Bounded env51167 := by
  intro p hp
  have h : env51167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51166_51167 : H12AffineEnvironment.transform 15 54358 env51166 = env51167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env51166 == env51167) = true)

def env51168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1025,32769,4160,33,62541,41310,8192,65,158029,57676,45405,138340,1365,33,257,21792,46093,63069]

theorem envBound51168 : H12AffineFastState.Bounded env51168 := by
  intro p hp
  have h : env51168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51167_51168 : H12AffineEnvironment.transform 17 10280 env51167 = env51168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51167 == env51168) = true)

theorem identity51168 : scanCanonicalize (H12AffineFastState.compose env51168 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound51168 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,57676,10280,1025,32769,4160,33,62541,41310,8192,65,34817,57676,45405,64808,1365,33,257,21792,46093,63069]

theorem envBound51169 : H12AffineFastState.Bounded env51169 := by
  intro p hp
  have h : env51169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51168_51169 : H12AffineEnvironment.transform 16 57676 env51168 = env51169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env51168 == env51169) = true)

def env51170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,32,62540,41311,8192,65,158029,57677,45404,138340,1365,33,257,21792,46093,63069]

theorem envBound51170 : H12AffineFastState.Bounded env51170 := by
  intro p hp
  have h : env51170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51167_51170 : H12AffineEnvironment.transform 17 10281 env51167 = env51170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51167 == env51170) = true)

theorem identity51170 : scanCanonicalize (H12AffineFastState.compose env51170 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound51170 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,32,17,21762,8192,65,158029,5392,17665,138340,1365,33,257,21792,16464,512]

theorem envBound51171 : H12AffineFastState.Bounded env51171 := by
  intro p hp
  have h : env51171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51170_51171 : H12AffineEnvironment.transform 14 29789 env51170 = env51171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env51170 == env51171) = true)

theorem identity51171 : scanCanonicalize (H12AffineFastState.compose env51171 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 10265) := by decide +kernel

theorem selectedBound51171 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,10265,10281,1025,29788,4160,32,17,21762,8192,65,16724,5392,17665,13437,1365,33,257,21792,16464,512]

theorem envBound51172 : H12AffineFastState.Bounded env51172 := by
  intro p hp
  have h : env51172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51171_51172 : H12AffineEnvironment.transform 16 10265 env51171 = env51172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10265 env51171 == env51172) = true)

theorem identity51172 : scanCanonicalize (H12AffineFastState.compose env51172 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 3425) := by decide +kernel

theorem selectedBound51172 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,3425,14652,8203,10265,10281,1025,14653,4160,32,17,6243,8192,65,3125,5392,2144,13437,1365,33,257,6209,3377,512]

theorem envBound51173 : H12AffineFastState.Bounded env51173 := by
  intro p hp
  have h : env51173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51172_51173 : H12AffineEnvironment.transform 13 3425 env51172 = env51173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3425 env51172 == env51173) = true)

theorem identity51173 : scanCanonicalize (H12AffineFastState.compose env51173 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound51173 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env51174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,3425,261,6194,4128,4112,1025,260,4160,32,17,6243,6201,65,3125,5392,2144,3140,1365,33,257,6209,3377,512]

theorem envBound51174 : H12AffineFastState.Bounded env51174 := by
  intro p hp
  have h : env51174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51173_51174 : H12AffineEnvironment.transform 12 6201 env51173 = env51174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env51173 == env51174) = true)

theorem identity51174 : scanCanonicalize (H12AffineFastState.compose env51174 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound51174 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env51175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,3425,261,1047,3077,3125,1025,260,3173,32,17,1094,1052,65,3125,2357,2144,3140,1365,33,257,1124,3377,512]

theorem envBound51175 : H12AffineFastState.Bounded env51175 := by
  intro p hp
  have h : env51175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51174_51175 : H12AffineEnvironment.transform 11 3109 env51174 = env51175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env51174 == env51175) = true)

theorem identity51175 : scanCanonicalize (H12AffineFastState.compose env51175 (packedSelected [0,1,3,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51175 : packedSelected [0,1,3,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51176 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,3109,1052,3344,261,1047,3077,3125,1025,260,3092,32,17,1079,1052,48,3125,2357,2065,3125,1316,33,257,1045,3377,512]

theorem envBound51176 : H12AffineFastState.Bounded env51176 := by
  intro p hp
  have h : env51176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51175_51176 : H12AffineEnvironment.transform 5 49 env51175 = env51176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51175 == env51176) = true)

theorem identity51176 : scanCanonicalize (H12AffineFastState.compose env51176 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51176 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51177 : List Nat := [2,4,8,16,32,49,8,256,512,21,2048,2096,9,2309,261,2,2064,2080,20,260,2049,32,17,34,9,48,2080,2357,2065,2080,305,33,257,0,2340,512]

theorem envBound51177 : H12AffineFastState.Bounded env51177 := by
  intro p hp
  have h : env51177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51176_51177 : H12AffineEnvironment.transform 9 21 env51176 = env51177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51176 == env51177) = true)

theorem identity51177 : scanCanonicalize (H12AffineFastState.compose env51177 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51177 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env51178 : List Nat := [2,4,8,16,32,49,8,36,512,21,2048,2096,9,2081,33,2,2064,2080,20,32,2049,32,17,34,9,48,2080,2065,2065,2080,21,33,37,0,2048,512]

theorem envBound51178 : H12AffineFastState.Bounded env51178 := by
  intro p hp
  have h : env51178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51177_51178 : H12AffineEnvironment.transform 7 36 env51177 = env51178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51177 == env51178) = true)

theorem identity51178 : scanCanonicalize (H12AffineFastState.compose env51178 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51178 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51179 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,2065,9,2048,0,2,2064,2049,20,1,2049,1,17,3,9,17,2049,2065,2065,2049,21,0,4,0,2048,512]

theorem envBound51179 : H12AffineFastState.Bounded env51179 := by
  intro p hp
  have h : env51179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51178_51179 : H12AffineEnvironment.transform 4 1 env51178 = env51179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51178 == env51179) = true)

theorem identity51179 : scanCanonicalize (H12AffineFastState.compose env51179 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound51179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51180 : List Nat := [2,4,8,16,1,16,8,5,512,21,4,21,9,4,0,2,20,5,20,1,5,1,17,3,9,17,5,21,21,5,21,0,4,0,4,512]

theorem envBound51180 : H12AffineFastState.Bounded env51180 := by
  intro p hp
  have h : env51180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51179_51180 : H12AffineEnvironment.transform 10 4 env51179 = env51180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env51179 == env51180) = true)

theorem identity51180 : scanCanonicalize (H12AffineFastState.compose env51180 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51180 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51181 : List Nat := [2,4,8,7,1,7,8,5,512,2,4,2,9,4,0,2,3,5,3,1,5,1,6,3,9,6,5,2,2,5,2,0,4,0,4,512]

theorem envBound51181 : H12AffineFastState.Bounded env51181 := by
  intro p hp
  have h : env51181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51180_51181 : H12AffineEnvironment.transform 3 7 env51180 = env51181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51180 == env51181) = true)

theorem identity51181 : scanCanonicalize (H12AffineFastState.compose env51181 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51182 : List Nat := [1,4,8,4,1,4,8,5,512,1,4,1,9,4,0,1,0,5,0,1,5,1,5,0,9,5,5,1,1,5,1,0,4,0,4,512]

theorem envBound51182 : H12AffineFastState.Bounded env51182 := by
  intro p hp
  have h : env51182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51181_51182 : H12AffineEnvironment.transform 0 1 env51181 = env51182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51181 == env51182) = true)

theorem identity51182 : scanCanonicalize (H12AffineFastState.compose env51182 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound51182 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51183 : List Nat := [1,4,0,4,1,4,0,5,512,1,4,1,1,4,0,1,0,5,0,1,5,1,5,0,1,5,5,1,1,5,1,0,4,0,4,512]

theorem envBound51183 : H12AffineFastState.Bounded env51183 := by
  intro p hp
  have h : env51183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51182_51183 : H12AffineEnvironment.transform 2 0 env51182 = env51183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env51182 == env51183) = true)

theorem identity51183 : scanCanonicalize (H12AffineFastState.compose env51183 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51183 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51184 : List Nat := [1,1,0,1,1,1,0,0,512,1,1,1,1,1,0,1,0,0,0,1,0,1,0,0,1,0,0,1,1,0,1,0,1,0,1,512]

theorem envBound51184 : H12AffineFastState.Bounded env51184 := by
  intro p hp
  have h : env51184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51183_51184 : H12AffineEnvironment.transform 1 1 env51183 = env51184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51183 == env51184) = true)

def env51185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318565,351521,8192,65,158029,313700,301428,138340,1364,32,257,21792,46093,74250]

theorem envBound51185 : H12AffineFastState.Bounded env51185 := by
  intro p hp
  have h : env51185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51165_51185 : H12AffineEnvironment.transform 20 4161 env51165 = env51185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51165 == env51185) = true)

theorem identity51185 : scanCanonicalize (H12AffineFastState.compose env51185 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound51185 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130175,1025,32769,4161,119927,73754,41310,8192,65,158029,79131,91403,138340,1364,32,257,21792,46093,74250]

theorem envBound51186 : H12AffineFastState.Bounded env51186 := by
  intro p hp
  have h : env51186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51185_51186 : H12AffineEnvironment.transform 17 130175 env51185 = env51186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env51185 == env51186) = true)

def env51187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67619,1025,29789,4161,73771,73754,21762,8192,65,158029,79131,91403,138340,1364,32,257,21792,16465,74250]

theorem envBound51187 : H12AffineFastState.Bounded env51187 := by
  intro p hp
  have h : env51187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51186_51187 : H12AffineEnvironment.transform 14 29788 env51186 = env51187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51186 == env51187) = true)

theorem identity51187 : scanCanonicalize (H12AffineFastState.compose env51187 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51187 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10280,1025,29789,4161,32,17,21762,8192,65,158029,5392,17664,138340,1364,32,257,21792,16465,513]

theorem envBound51188 : H12AffineFastState.Bounded env51188 := by
  intro p hp
  have h : env51188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51187_51188 : H12AffineEnvironment.transform 15 8203 env51187 = env51188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51187 == env51188) = true)

theorem identity51188 : scanCanonicalize (H12AffineFastState.compose env51188 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51188 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8203,131072,10280,1025,80,4161,32,17,8463,8192,65,138560,5392,12557,138340,1364,32,257,8493,13404,513]

theorem envBound51189 : H12AffineFastState.Bounded env51189 := by
  intro p hp
  have h : env51189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51188_51189 : H12AffineEnvironment.transform 13 13325 env51188 = env51189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51188 == env51189) = true)

theorem identity51189 : scanCanonicalize (H12AffineFastState.compose env51189 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound51189 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8203,13388,10280,1025,80,4161,32,17,8463,8192,65,10508,5392,12557,10280,1364,32,257,8493,13404,513]

theorem envBound51190 : H12AffineFastState.Bounded env51190 := by
  intro p hp
  have h : env51190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51189_51190 : H12AffineEnvironment.transform 16 13388 env51189 = env51190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env51189 == env51190) = true)

theorem identity51190 : scanCanonicalize (H12AffineFastState.compose env51190 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51190 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,262,5441,2341,1025,80,4161,32,17,2,269,65,2049,5392,4096,2341,1364,32,257,32,5457,513]

theorem envBound51191 : H12AffineFastState.Bounded env51191 := by
  intro p hp
  have h : env51191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51190_51191 : H12AffineEnvironment.transform 12 269 env51190 = env51191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51190 == env51191) = true)

theorem identity51191 : scanCanonicalize (H12AffineFastState.compose env51191 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51191 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51192 : List Nat := [2,4,8,16,32,64,8,256,17,1024,2048,4096,269,5376,81,262,5441,2341,1025,80,4161,32,17,2,269,65,2049,5392,4096,2341,1364,32,257,32,5457,16]

theorem envBound51192 : H12AffineFastState.Bounded env51192 := by
  intro p hp
  have h : env51192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51191_51192 : H12AffineEnvironment.transform 8 17 env51191 = env51192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51191 == env51192) = true)

theorem identity51192 : scanCanonicalize (H12AffineFastState.compose env51192 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51192 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51193 : List Nat := [2,4,8,16,32,17,8,256,17,1024,2048,4096,269,5376,0,262,5392,2341,1025,1,4112,32,17,2,269,16,2049,5392,4096,2341,1285,32,257,32,5376,16]

theorem envBound51193 : H12AffineFastState.Bounded env51193 := by
  intro p hp
  have h : env51193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51192_51193 : H12AffineEnvironment.transform 5 17 env51192 = env51193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51192 == env51193) = true)

theorem identity51193 : scanCanonicalize (H12AffineFastState.compose env51193 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51194 : List Nat := [2,4,8,16,1,17,8,256,17,1024,2048,4096,269,5376,0,262,5392,2308,1025,1,4112,1,17,2,269,16,2049,5392,4096,2308,1285,1,257,1,5376,16]

theorem envBound51194 : H12AffineFastState.Bounded env51194 := by
  intro p hp
  have h : env51194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51193_51194 : H12AffineEnvironment.transform 4 1 env51193 = env51194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51193 == env51194) = true)

theorem identity51194 : scanCanonicalize (H12AffineFastState.compose env51194 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound51194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51195 : List Nat := [2,4,8,16,1,17,8,256,17,1024,2048,17,269,1297,0,262,1281,2308,1025,1,1,1,17,2,269,16,2049,1281,17,2308,1285,1,257,1,1297,16]

theorem envBound51195 : H12AffineFastState.Bounded env51195 := by
  intro p hp
  have h : env51195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51194_51195 : H12AffineEnvironment.transform 11 17 env51194 = env51195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51194 == env51195) = true)

theorem identity51195 : scanCanonicalize (H12AffineFastState.compose env51195 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51195 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51196 : List Nat := [2,4,8,1,1,0,8,256,0,1024,2048,0,269,1280,0,262,1281,2308,1025,1,1,1,0,2,269,1,2049,1281,0,2308,1285,1,257,1,1280,1]

theorem envBound51196 : H12AffineFastState.Bounded env51196 := by
  intro p hp
  have h : env51196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51195_51196 : H12AffineEnvironment.transform 3 1 env51195 = env51196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51195 == env51196) = true)

theorem identity51196 : scanCanonicalize (H12AffineFastState.compose env51196 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51196 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51197 : List Nat := [2,4,8,1,1,0,8,256,0,1024,1,0,269,1280,0,262,1281,261,1025,1,1,1,0,2,269,1,0,1281,0,261,1285,1,257,1,1280,1]

theorem envBound51197 : H12AffineFastState.Bounded env51197 := by
  intro p hp
  have h : env51197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51196_51197 : H12AffineEnvironment.transform 10 1 env51196 = env51197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51196 == env51197) = true)

def env51198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67618,1025,29788,4161,73770,73754,21763,8192,65,158029,79131,91403,138340,1364,32,257,21792,16464,74250]

theorem envBound51198 : H12AffineFastState.Bounded env51198 := by
  intro p hp
  have h : env51198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51186_51198 : H12AffineEnvironment.transform 14 29789 env51186 = env51198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env51186 == env51198) = true)

theorem identity51198 : scanCanonicalize (H12AffineFastState.compose env51198 (packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51198 : packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51199 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29789,65536,131072,67618,1025,29788,4161,73770,73754,21543,8192,65,157801,78911,91183,138340,1136,32,37,21508,16464,74250]

theorem envBound51199 : H12AffineFastState.Bounded env51199 := by
  intro p hp
  have h : env51199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51198_51199 : H12AffineEnvironment.transform 7 36 env51198 = env51199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51198 == env51199) = true)

theorem identity51199 : scanCanonicalize (H12AffineFastState.compose env51199 (packedSelected [0,3,4,5,6,7,9,11,12,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 31852) := by decide +kernel

theorem selectedBound51199 : packedSelected [0,3,4,5,6,7,9,11,12,14,19,20] rootPS < 2^1333 := by decide +kernel

def env51200 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29789,65536,31852,67618,1025,29788,4161,73770,73754,21543,8192,65,5125,78911,91183,24584,1136,32,37,21508,16464,74250]

theorem envBound51200 : H12AffineFastState.Bounded env51200 := by
  intro p hp
  have h : env51200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51199_51200 : H12AffineEnvironment.transform 16 31852 env51199 = env51200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 31852 env51199 == env51200) = true)

theorem identity51200 : scanCanonicalize (H12AffineFastState.compose env51200 (packedSelected [2,3,4,5,6,9,12,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 31839) := by decide +kernel

theorem selectedBound51200 : packedSelected [2,3,4,5,6,9,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env51201 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29789,31839,31852,29821,1025,29788,4161,23669,23621,21543,8192,65,5125,18528,6256,24584,1136,32,37,21508,16464,24149]

theorem envBound51201 : H12AffineFastState.Bounded env51201 := by
  intro p hp
  have h : env51201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51200_51201 : H12AffineEnvironment.transform 15 31839 env51200 = env51201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31839 env51200 == env51201) = true)

theorem identity51201 : scanCanonicalize (H12AffineFastState.compose env51201 (packedSelected [0,1,3,4,7,8,9,11,12,14,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 7213) := by decide +kernel

theorem selectedBound51201 : packedSelected [0,1,3,4,7,8,9,11,12,14,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51202 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,7213,16384,18544,16498,16449,18512,1025,18545,4161,23669,23621,21543,7213,65,5125,18528,6256,23589,1136,32,37,21508,16464,24149]

theorem envBound51202 : H12AffineFastState.Bounded env51202 := by
  intro p hp
  have h : env51202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51201_51202 : H12AffineEnvironment.transform 12 7213 env51201 = env51202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7213 env51201 == env51202) = true)

theorem identity51202 : scanCanonicalize (H12AffineFastState.compose env51202 (packedSelected [0,2,4,7,9,12,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 3092) := by decide +kernel

theorem selectedBound51202 : packedSelected [0,2,4,7,9,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env51203 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,7213,3092,1124,3174,3157,1092,1025,1125,4161,4193,4177,6195,7213,65,5125,1140,6256,4145,1136,32,37,6160,3140,4673]

theorem envBound51203 : H12AffineFastState.Bounded env51203 := by
  intro p hp
  have h : env51203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51202_51203 : H12AffineEnvironment.transform 13 3092 env51202 = env51203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3092 env51202 == env51203) = true)

theorem identity51203 : scanCanonicalize (H12AffineFastState.compose env51203 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound51203 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51204 : List Nat := [2,4,8,16,32,64,8,36,512,1024,112,4096,5213,1124,1124,1046,1061,1092,1025,1125,4161,4193,4177,4163,5213,65,5125,1140,4096,4145,1136,32,37,4192,1076,4673]

theorem envBound51204 : H12AffineFastState.Bounded env51204 := by
  intro p hp
  have h : env51204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51203_51204 : H12AffineEnvironment.transform 10 112 env51203 = env51204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env51203 == env51204) = true)

theorem identity51204 : scanCanonicalize (H12AffineFastState.compose env51204 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51204 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env51205 : List Nat := [2,4,8,16,32,64,8,36,512,53,112,4096,4200,81,81,35,16,113,52,80,4161,4193,4177,4163,4200,65,4144,65,4096,4145,69,32,37,4192,1,4673]

theorem envBound51205 : H12AffineFastState.Bounded env51205 := by
  intro p hp
  have h : env51205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51204_51205 : H12AffineEnvironment.transform 9 53 env51204 = env51205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51204 == env51205) = true)

theorem identity51205 : scanCanonicalize (H12AffineFastState.compose env51205 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound51205 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51206 : List Nat := [2,4,8,16,32,64,8,36,512,53,112,48,88,81,81,35,16,113,52,80,113,81,97,115,88,65,0,65,48,1,69,32,37,80,1,625]

theorem envBound51206 : H12AffineFastState.Bounded env51206 := by
  intro p hp
  have h : env51206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51205_51206 : H12AffineEnvironment.transform 11 48 env51205 = env51206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51205 == env51206) = true)

theorem identity51206 : scanCanonicalize (H12AffineFastState.compose env51206 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51206 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51207 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,8,1,1,35,16,33,52,0,33,1,49,35,8,17,0,17,48,1,21,32,37,0,1,545]

theorem envBound51207 : H12AffineFastState.Bounded env51207 := by
  intro p hp
  have h : env51207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51206_51207 : H12AffineEnvironment.transform 5 16 env51206 = env51207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51206 == env51207) = true)

theorem identity51207 : scanCanonicalize (H12AffineFastState.compose env51207 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51208 : List Nat := [2,4,8,1,32,1,8,36,512,36,32,33,8,1,1,35,1,33,37,0,33,1,32,35,8,0,0,0,33,1,4,32,37,0,1,545]

theorem envBound51208 : H12AffineFastState.Bounded env51208 := by
  intro p hp
  have h : env51208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51207_51208 : H12AffineEnvironment.transform 3 1 env51207 = env51208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51207 == env51208) = true)

theorem identity51208 : scanCanonicalize (H12AffineFastState.compose env51208 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51208 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51209 : List Nat := [2,4,8,1,10,1,8,14,512,14,10,11,8,1,1,9,1,11,15,0,11,1,10,9,8,0,0,0,11,1,4,10,15,0,1,523]

theorem envBound51209 : H12AffineFastState.Bounded env51209 := by
  intro p hp
  have h : env51209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51208_51209 : H12AffineEnvironment.transform 4 10 env51208 = env51209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51208 == env51209) = true)

theorem identity51209 : scanCanonicalize (H12AffineFastState.compose env51209 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51209 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51210 : List Nat := [2,4,7,1,5,1,7,1,512,1,5,4,7,1,1,6,1,4,0,0,4,1,5,6,7,0,0,0,4,1,4,5,0,0,1,516]

theorem envBound51210 : H12AffineFastState.Bounded env51210 := by
  intro p hp
  have h : env51210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51209_51210 : H12AffineEnvironment.transform 2 7 env51209 = env51210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51209 == env51210) = true)

theorem identity51210 : scanCanonicalize (H12AffineFastState.compose env51210 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound51210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51211 : List Nat := [2,4,7,1,5,1,7,1,3,1,5,4,7,1,1,6,1,4,0,0,4,1,5,6,7,0,0,0,4,1,4,5,0,0,1,7]

theorem envBound51211 : H12AffineFastState.Bounded env51211 := by
  intro p hp
  have h : env51211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51210_51211 : H12AffineEnvironment.transform 8 3 env51210 = env51211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env51210 == env51211) = true)

def env51212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444641,8193,65,6705413,313700,2394421,138340,2102548,4466728,257,21792,46092,2175563]

theorem envBound51212 : H12AffineFastState.Bounded env51212 := by
  intro p hp
  have h : env51212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51132_51212 : H12AffineEnvironment.transform 6 9 env51132 = env51212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51132 == env51212) = true)

theorem identity51212 : scanCanonicalize (H12AffineFastState.compose env51212 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51212 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env51213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,4194304,318565,294187,8193,65,4677967,313700,375167,138340,75102,4466728,257,21792,46092,513]

theorem envBound51213 : H12AffineFastState.Bounded env51213 := by
  intro p hp
  have h : env51213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51212_51213 : H12AffineEnvironment.transform 20 77898 env51212 = env51213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51212 == env51213) = true)

theorem identity51213 : scanCanonicalize (H12AffineFastState.compose env51213 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51213 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77898,4194304,318565,294187,8193,65,4456788,313700,375167,97407,75102,4466728,257,21792,46092,513]

theorem envBound51214 : H12AffineFastState.Bounded env51214 := by
  intro p hp
  have h : env51214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51213_51214 : H12AffineEnvironment.transform 16 90139 env51213 = env51214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51213 == env51214) = true)

def env51215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,62541,21763,8193,65,4204924,57676,102743,97407,75102,4194304,257,21792,46092,513]

theorem envBound51215 : H12AffineFastState.Bounded env51215 := by
  intro p hp
  have h : env51215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51214_51215 : H12AffineEnvironment.transform 17 10280 env51214 = env51215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51214 == env51215) = true)

theorem identity51215 : scanCanonicalize (H12AffineFastState.compose env51215 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound51215 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env51216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10280,1025,32769,58396,4194304,62541,21763,8193,65,4204924,57676,17665,43049,61704,4194304,257,21792,46092,513]

theorem envBound51216 : H12AffineFastState.Bounded env51216 := by
  intro p hp
  have h : env51216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51215_51216 : H12AffineEnvironment.transform 15 54358 env51215 = env51216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env51215 == env51216) = true)

theorem identity51216 : scanCanonicalize (H12AffineFastState.compose env51216 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51216 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env51217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46157,10280,1025,32769,45340,4194304,41293,3,8193,65,4204924,46156,4097,43049,41992,4194304,257,32,46092,513]

theorem envBound51217 : H12AffineFastState.Bounded env51217 := by
  intro p hp
  have h : env51217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51216_51217 : H12AffineEnvironment.transform 13 5376 env51216 = env51217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51216 == env51217) = true)

theorem identity51217 : scanCanonicalize (H12AffineFastState.compose env51217 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound51217 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46157,10280,1025,32769,45340,41341,41293,3,8193,65,34817,46156,4097,43049,41992,41341,257,32,46092,513]

theorem envBound51218 : H12AffineFastState.Bounded env51218 := by
  intro p hp
  have h : env51218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51217_51218 : H12AffineEnvironment.transform 21 41341 env51217 = env51218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env51217 == env51218) = true)

def env51219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1025,32769,77898,4194304,62540,21762,8193,65,4204925,57677,102742,97407,75102,4194305,257,21792,46092,513]

theorem envBound51219 : H12AffineFastState.Bounded env51219 := by
  intro p hp
  have h : env51219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51214_51219 : H12AffineEnvironment.transform 17 10281 env51214 = env51219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51214 == env51219) = true)

theorem identity51219 : scanCanonicalize (H12AffineFastState.compose env51219 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 53575) := by decide +kernel

theorem selectedBound51219 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env51220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53575,45404,10281,1025,32769,57613,4194304,62540,21762,8193,65,4204925,57677,16401,44344,62489,4194305,257,21792,46092,513]

theorem envBound51220 : H12AffineFastState.Bounded env51220 := by
  intro p hp
  have h : env51220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51219_51220 : H12AffineEnvironment.transform 15 53575 env51219 = env51220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53575 env51219 == env51220) = true)

theorem identity51220 : scanCanonicalize (H12AffineFastState.compose env51220 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51220 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env51221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10281,1025,8541,16465,4194304,21776,21762,8193,65,4204925,16401,16401,3172,21829,4194305,257,21792,5456,513]

theorem envBound51221 : H12AffineFastState.Bounded env51221 := by
  intro p hp
  have h : env51221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51220_51221 : H12AffineEnvironment.transform 14 8540 env51220 = env51221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51220 == env51221) = true)

theorem identity51221 : scanCanonicalize (H12AffineFastState.compose env51221 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51221 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env51222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,20758,4096,2340,1025,80,16465,4194304,21776,21762,268,65,4196464,16401,16401,3172,21829,4194305,257,21792,5456,513]

theorem envBound51222 : H12AffineFastState.Bounded env51222 := by
  intro p hp
  have h : env51222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51221_51222 : H12AffineEnvironment.transform 12 269 env51221 = env51222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51221 == env51222) = true)

theorem identity51222 : scanCanonicalize (H12AffineFastState.compose env51222 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound51222 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51223 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,81,20758,4096,2340,101,80,16465,4194304,20852,20838,268,65,4196464,16401,16401,2048,20769,4194305,257,20804,4404,513]

theorem envBound51223 : H12AffineFastState.Bounded env51223 := by
  intro p hp
  have h : env51223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51222_51223 : H12AffineEnvironment.transform 9 100 env51222 = env51223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env51222 == env51223) = true)

theorem identity51223 : scanCanonicalize (H12AffineFastState.compose env51223 (packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 18773) := by decide +kernel

theorem selectedBound51223 : packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env51224 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,81,20758,4096,2340,101,80,16465,18773,20852,20838,268,65,16677,16401,16401,2048,20769,18772,257,20804,4404,513]

theorem envBound51224 : H12AffineFastState.Bounded env51224 := by
  intro p hp
  have h : env51224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51223_51224 : H12AffineEnvironment.transform 21 18773 env51223 = env51224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 18773 env51223 == env51224) = true)

theorem identity51224 : scanCanonicalize (H12AffineFastState.compose env51224 (packedSelected [1,2,3,5,6,8,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound51224 : packedSelected [1,2,3,5,6,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env51225 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,2420,81,6242,4096,2340,101,80,2341,33,6144,6162,268,65,2129,2405,2405,2048,6229,32,257,6192,4404,513]

theorem envBound51225 : H12AffineFastState.Bounded env51225 := by
  intro p hp
  have h : env51225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51224_51225 : H12AffineEnvironment.transform 13 2420 env51224 = env51225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env51224 == env51225) = true)

theorem identity51225 : scanCanonicalize (H12AffineFastState.compose env51225 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51225 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env51226 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,2340,1,6194,4096,2340,53,0,2341,33,6144,6162,268,17,2049,2357,2357,2048,6149,32,257,6192,4404,513]

theorem envBound51226 : H12AffineFastState.Bounded env51226 := by
  intro p hp
  have h : env51226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51225_51226 : H12AffineEnvironment.transform 5 16 env51225 = env51226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51225 == env51226) = true)

theorem identity51226 : scanCanonicalize (H12AffineFastState.compose env51226 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51226 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51227 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,2049,1,6194,4096,2049,53,0,2048,33,6144,6162,41,17,2049,2064,2064,2048,6149,32,36,6192,4113,513]

theorem envBound51227 : H12AffineFastState.Bounded env51227 := by
  intro p hp
  have h : env51227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51226_51227 : H12AffineEnvironment.transform 7 37 env51226 = env51227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51226 == env51227) = true)

theorem identity51227 : scanCanonicalize (H12AffineFastState.compose env51227 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound51227 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51228 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,40,2049,1,35,2065,2049,53,0,2048,33,17,3,41,17,2049,2064,2064,2048,20,32,36,33,2048,513]

theorem envBound51228 : H12AffineFastState.Bounded env51228 := by
  intro p hp
  have h : env51228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51227_51228 : H12AffineEnvironment.transform 11 2065 env51227 = env51228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env51227 == env51228) = true)

theorem identity51228 : scanCanonicalize (H12AffineFastState.compose env51228 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound51228 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51229 : List Nat := [2,4,8,16,32,16,9,37,32,52,2048,2065,40,2049,1,35,2065,2049,53,0,2048,33,17,3,41,17,2049,2064,2064,2048,20,32,36,33,2048,33]

theorem envBound51229 : H12AffineFastState.Bounded env51229 := by
  intro p hp
  have h : env51229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51228_51229 : H12AffineEnvironment.transform 8 32 env51228 = env51229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env51228 == env51229) = true)

theorem identity51229 : scanCanonicalize (H12AffineFastState.compose env51229 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51229 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51230 : List Nat := [2,4,8,16,0,16,9,5,0,20,2048,2065,8,2049,1,3,2065,2049,21,0,2048,1,17,3,9,17,2049,2064,2064,2048,20,0,4,1,2048,1]

theorem envBound51230 : H12AffineFastState.Bounded env51230 := by
  intro p hp
  have h : env51230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51229_51230 : H12AffineEnvironment.transform 4 0 env51229 = env51230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51229 == env51230) = true)

def env51231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound51231 : H12AffineFastState.Bounded env51231 := by
  intro p hp
  have h : env51231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50836_51231 : H12AffineEnvironment.transform 26 30393345 env50836 = env51231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env50836 == env51231) = true)

def env51232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound51232 : H12AffineFastState.Bounded env51232 := by
  intro p hp
  have h : env51232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51231_51232 : H12AffineEnvironment.transform 18 1024 env51231 = env51232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env51231 == env51232) = true)

theorem identity51232 : scanCanonicalize (H12AffineFastState.compose env51232 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898729) := by decide +kernel

theorem selectedBound51232 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898729,8328,65,4196520,10898468,10507600,8830977,412857,15117672,256,2493444,2551201,486254]

theorem envBound51233 : H12AffineFastState.Bounded env51233 := by
  intro p hp
  have h : env51233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51232_51233 : H12AffineEnvironment.transform 23 8898729 env51232 = env51233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898729 env51232 == env51233) = true)

def env51234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,8388608,8898729,8328,65,4196520,8393984,8785012,8830977,412857,12645452,256,21792,46213,486254]

theorem envBound51234 : H12AffineFastState.Bounded env51234 := by
  intro p hp
  have h : env51234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51233_51234 : H12AffineEnvironment.transform 20 416036 env51233 = env51234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416036 env51233 == env51234) = true)

def env51235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441760,95497,8328,65,4196520,436384,45524,32161,412857,4606444,256,21792,46213,486254]

theorem envBound51235 : H12AffineFastState.Bounded env51235 := by
  intro p hp
  have h : env51235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51234_51235 : H12AffineEnvironment.transform 22 441760 env51234 = env51235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env51234 == env51235) = true)

def env51236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441760,95497,8328,65,270376,436384,45524,32161,412857,156012,256,21792,46213,486254]

theorem envBound51236 : H12AffineFastState.Bounded env51236 := by
  intro p hp
  have h : env51236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51235_51236 : H12AffineEnvironment.transform 21 272512 env51235 = env51236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51235 == env51236) = true)

theorem identity51236 : scanCanonicalize (H12AffineFastState.compose env51236 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound51236 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,58516,169264,16,95497,8328,65,171416,5392,45524,32161,61705,156012,256,21792,46213,120542]

theorem envBound51237 : H12AffineFastState.Bounded env51237 := by
  intro p hp
  have h : env51237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51236_51237 : H12AffineEnvironment.transform 17 179632 env51236 = env51237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env51236 == env51237) = true)

def env51238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169264,16,95497,8192,65,171280,5392,45404,32041,61705,156012,256,21792,46093,120406]

theorem envBound51238 : H12AffineFastState.Bounded env51238 := by
  intro p hp
  have h : env51238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51237_51238 : H12AffineEnvironment.transform 6 8 env51237 = env51238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51237 == env51238) = true)

theorem identity51238 : scanCanonicalize (H12AffineFastState.compose env51238 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound51238 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,58396,32,16,95497,8192,65,2048,5392,45404,32041,61705,62588,256,21792,46093,120406]

theorem envBound51239 : H12AffineFastState.Bounded env51239 := by
  intro p hp
  have h : env51239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51238_51239 : H12AffineEnvironment.transform 16 38160 env51238 = env51239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51238 == env51239) = true)

theorem identity51239 : scanCanonicalize (H12AffineFastState.compose env51239 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound51239 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,38160,10280,1024,32769,58396,32,16,8542,8192,65,2048,5392,45404,32041,61705,62588,256,21792,46093,33281]

theorem envBound51240 : H12AffineFastState.Bounded env51240 := by
  intro p hp
  have h : env51240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51239_51240 : H12AffineEnvironment.transform 15 21591 env51239 = env51240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env51239 == env51240) = true)

theorem identity51240 : scanCanonicalize (H12AffineFastState.compose env51240 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound51240 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21591,16400,10280,1024,21761,12572,32,16,8542,8192,65,2048,5392,25692,32041,9225,8572,256,21792,24845,22273]

theorem envBound51241 : H12AffineFastState.Bounded env51241 := by
  intro p hp
  have h : env51241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51240_51241 : H12AffineEnvironment.transform 14 21760 env51240 = env51241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env51240 == env51241) = true)

theorem identity51241 : scanCanonicalize (H12AffineFastState.compose env51241 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51241 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env51242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21591,16400,2420,1024,21761,4160,32,16,2,348,65,2048,5392,17664,23669,1365,32,256,21792,16465,22273]

theorem envBound51242 : H12AffineFastState.Bounded env51242 := by
  intro p hp
  have h : env51242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51241_51242 : H12AffineEnvironment.transform 12 348 env51241 = env51242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51241 == env51242) = true)

theorem identity51242 : scanCanonicalize (H12AffineFastState.compose env51242 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound51242 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5205,341,2,5189,2420,1024,340,4160,32,16,2,348,65,2048,5392,4437,2080,1365,32,256,373,5124,852]

theorem envBound51243 : H12AffineFastState.Bounded env51243 := by
  intro p hp
  have h : env51243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51242_51243 : H12AffineEnvironment.transform 13 5205 env51242 = env51243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env51242 == env51243) = true)

theorem identity51243 : scanCanonicalize (H12AffineFastState.compose env51243 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound51243 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env51244 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8,5205,1,2,5189,2080,1024,0,4160,32,16,2,8,65,2048,5188,4097,2080,1025,32,84,33,5124,512]

theorem envBound51244 : H12AffineFastState.Bounded env51244 := by
  intro p hp
  have h : env51244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51243_51244 : H12AffineEnvironment.transform 7 84 env51243 = env51244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env51243 == env51244) = true)

theorem identity51244 : scanCanonicalize (H12AffineFastState.compose env51244 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51244 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51245 : List Nat := [2,4,8,16,32,64,8,84,512,20,2048,4096,8,4161,1,2,4177,2080,20,0,4160,32,16,2,8,65,2048,4176,4097,2080,21,32,84,33,4112,512]

theorem envBound51245 : H12AffineFastState.Bounded env51245 := by
  intro p hp
  have h : env51245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51244_51245 : H12AffineEnvironment.transform 9 20 env51244 = env51245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51244 == env51245) = true)

theorem identity51245 : scanCanonicalize (H12AffineFastState.compose env51245 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound51245 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51246 : List Nat := [2,4,8,16,32,64,8,84,512,20,2048,49,8,112,1,2,96,2080,20,0,113,32,16,2,8,65,2048,97,48,2080,21,32,84,33,33,512]

theorem envBound51246 : H12AffineFastState.Bounded env51246 := by
  intro p hp
  have h : env51246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51245_51246 : H12AffineEnvironment.transform 11 49 env51245 = env51246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51245 == env51246) = true)

theorem identity51246 : scanCanonicalize (H12AffineFastState.compose env51246 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51246 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51247 : List Nat := [2,4,8,16,1,64,8,84,512,20,2048,16,8,81,1,2,65,2049,20,0,80,1,16,2,8,65,2048,64,17,2049,21,1,84,0,0,512]

theorem envBound51247 : H12AffineFastState.Bounded env51247 := by
  intro p hp
  have h : env51247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51246_51247 : H12AffineEnvironment.transform 4 1 env51246 = env51247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51246 == env51247) = true)

theorem identity51247 : scanCanonicalize (H12AffineFastState.compose env51247 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51248 : List Nat := [2,4,8,16,1,64,8,84,0,20,2048,16,8,81,1,2,65,2049,20,0,80,1,16,2,8,65,2048,64,17,2049,21,1,84,0,0,0]

theorem envBound51248 : H12AffineFastState.Bounded env51248 := by
  intro p hp
  have h : env51248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51247_51248 : H12AffineEnvironment.transform 8 0 env51247 = env51248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51247 == env51248) = true)

theorem identity51248 : scanCanonicalize (H12AffineFastState.compose env51248 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound51248 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51249 : List Nat := [2,4,8,16,1,64,8,84,0,20,81,16,8,81,1,2,65,80,20,0,80,1,16,2,8,65,81,64,17,80,21,1,84,0,0,0]

theorem envBound51249 : H12AffineFastState.Bounded env51249 := by
  intro p hp
  have h : env51249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51248_51249 : H12AffineEnvironment.transform 10 81 env51248 = env51249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env51248 == env51249) = true)

theorem identity51249 : scanCanonicalize (H12AffineFastState.compose env51249 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51249 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51250 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,16,8,1,1,2,17,0,20,0,0,1,16,2,8,17,1,16,17,0,21,1,4,0,0,0]

theorem envBound51250 : H12AffineFastState.Bounded env51250 := by
  intro p hp
  have h : env51250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51249_51250 : H12AffineEnvironment.transform 5 16 env51249 = env51250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51249 == env51250) = true)

theorem identity51250 : scanCanonicalize (H12AffineFastState.compose env51250 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound51250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51251 : List Nat := [2,4,6,16,1,16,6,4,0,20,1,16,6,1,1,2,17,0,20,0,0,1,16,2,6,17,1,16,17,0,21,1,4,0,0,0]

theorem envBound51251 : H12AffineFastState.Bounded env51251 := by
  intro p hp
  have h : env51251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51250_51251 : H12AffineEnvironment.transform 2 6 env51250 = env51251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env51250 == env51251) = true)

def env51252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169264,16,95497,8193,65,171281,5392,45405,32040,61705,156012,256,21792,46092,120407]

theorem envBound51252 : H12AffineFastState.Bounded env51252 := by
  intro p hp
  have h : env51252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51237_51252 : H12AffineEnvironment.transform 6 9 env51237 = env51252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51237 == env51252) = true)

theorem identity51252 : scanCanonicalize (H12AffineFastState.compose env51252 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound51252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35188,1024,32769,58397,41341,16,95497,8193,65,43356,5392,45405,32040,61705,21793,256,21792,46092,120407]

theorem envBound51253 : H12AffineFastState.Bounded env51253 := by
  intro p hp
  have h : env51253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51252_51253 : H12AffineEnvironment.transform 16 13389 env51252 = env51253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env51252 == env51253) = true)

def env51254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441760,95497,8328,65,270377,436384,45524,32161,412857,156013,256,21792,46213,486254]

theorem envBound51254 : H12AffineFastState.Bounded env51254 := by
  intro p hp
  have h : env51254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51235_51254 : H12AffineEnvironment.transform 21 272513 env51235 = env51254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51235 == env51254) = true)

def env51255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441640,95497,8192,65,270377,436264,45404,32041,412721,156013,256,21792,46093,486254]

theorem envBound51255 : H12AffineFastState.Bounded env51255 := by
  intro p hp
  have h : env51255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51254_51255 : H12AffineEnvironment.transform 6 8 env51254 = env51255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51254 == env51255) = true)

def env51256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272440,95497,8192,65,270377,277816,45404,32041,317729,62589,256,21792,46093,392830]

theorem envBound51256 : H12AffineFastState.Bounded env51256 := by
  intro p hp
  have h : env51256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51255_51256 : H12AffineEnvironment.transform 16 38160 env51255 = env51256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51255 == env51256) = true)

theorem identity51256 : scanCanonicalize (H12AffineFastState.compose env51256 (packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51256 : packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env51257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1024,32769,314420,272393,272440,21762,8192,65,270377,277816,45404,32041,317729,62589,256,21792,46093,319093]

theorem envBound51257 : H12AffineFastState.Bounded env51257 := by
  intro p hp
  have h : env51257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51256_51257 : H12AffineEnvironment.transform 15 8203 env51256 = env51257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51256 == env51257) = true)

theorem identity51257 : scanCanonicalize (H12AffineFastState.compose env51257 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound51257 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env51258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,43048,1024,32769,25628,32801,32784,21762,8192,65,34817,38160,45404,32041,28937,62589,256,21792,46093,30301]

theorem envBound51258 : H12AffineFastState.Bounded env51258 := by
  intro p hp
  have h : env51258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51257_51258 : H12AffineEnvironment.transform 17 43048 env51257 = env51258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env51257 == env51258) = true)

theorem identity51258 : scanCanonicalize (H12AffineFastState.compose env51258 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51258 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24908,23668,1024,29789,25628,29821,29772,21762,8192,65,31837,24908,17664,32041,28937,33,256,21792,16465,30301]

theorem envBound51259 : H12AffineFastState.Bounded env51259 := by
  intro p hp
  have h : env51259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51258_51259 : H12AffineEnvironment.transform 14 29788 env51258 = env51259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51258 == env51259) = true)

theorem identity51259 : scanCanonicalize (H12AffineFastState.compose env51259 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51259 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env51260 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,24860,23588,1024,29709,25628,29741,29724,21762,8192,17,31757,24860,17664,32041,28937,33,256,21792,16385,30221]

theorem envBound51260 : H12AffineFastState.Bounded env51260 := by
  intro p hp
  have h : env51260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51259_51260 : H12AffineEnvironment.transform 5 16 env51259 = env51260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51259 == env51260) = true)

theorem identity51260 : scanCanonicalize (H12AffineFastState.compose env51260 (packedSelected [0,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound51260 : packedSelected [0,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51261 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,12344,1076,8203,4388,11292,1024,1077,5156,1045,1060,9530,8192,17,3125,4388,13624,3345,305,33,256,9496,12345,1589]

theorem envBound51261 : H12AffineFastState.Bounded env51261 := by
  intro p hp
  have h : env51261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51260_51261 : H12AffineEnvironment.transform 13 12344 env51260 = env51261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env51260 == env51261) = true)

theorem identity51261 : scanCanonicalize (H12AffineFastState.compose env51261 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51261 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env51262 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,12344,1,8203,4388,10281,53,0,4113,32,17,8463,8192,17,2048,4388,12557,2340,305,33,256,8493,12345,512]

theorem envBound51262 : H12AffineFastState.Bounded env51262 := by
  intro p hp
  have h : env51262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51261_51262 : H12AffineEnvironment.transform 9 53 env51261 = env51262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51261 == env51262) = true)

theorem identity51262 : scanCanonicalize (H12AffineFastState.compose env51262 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound51262 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51263 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,301,4373,1,294,4388,2308,53,0,4113,32,17,34,301,17,2048,4388,4128,2340,305,33,256,0,4372,512]

theorem envBound51263 : H12AffineFastState.Bounded env51263 := by
  intro p hp
  have h : env51263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51262_51263 : H12AffineEnvironment.transform 12 301 env51262 = env51263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env51262 == env51263) = true)

theorem identity51263 : scanCanonicalize (H12AffineFastState.compose env51263 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51263 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51264 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,9,4145,1,2,4096,2080,53,0,4113,32,17,34,9,17,2048,4096,4128,2048,21,33,36,0,4144,512]

theorem envBound51264 : H12AffineFastState.Bounded env51264 := by
  intro p hp
  have h : env51264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51263_51264 : H12AffineEnvironment.transform 7 36 env51263 = env51264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51263 == env51264) = true)

theorem identity51264 : scanCanonicalize (H12AffineFastState.compose env51264 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound51264 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51265 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2096,9,2049,1,2,2096,2080,53,0,2081,32,17,34,9,17,2048,2096,2064,2048,21,33,36,0,2048,512]

theorem envBound51265 : H12AffineFastState.Bounded env51265 := by
  intro p hp
  have h : env51265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51264_51265 : H12AffineEnvironment.transform 11 2096 env51264 = env51265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env51264 == env51265) = true)

def env51266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272441,95497,8192,65,270377,277817,45404,32041,317728,62588,256,21792,46093,392831]

theorem envBound51266 : H12AffineFastState.Bounded env51266 := by
  intro p hp
  have h : env51266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51255_51266 : H12AffineEnvironment.transform 16 38161 env51255 = env51266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env51255 == env51266) = true)

theorem identity51266 : scanCanonicalize (H12AffineFastState.compose env51266 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,58397,33,17,95497,8192,65,2049,5393,45404,32041,61704,62588,256,21792,46093,120407]

theorem envBound51267 : H12AffineFastState.Bounded env51267 := by
  intro p hp
  have h : env51267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51266_51267 : H12AffineEnvironment.transform 17 10280 env51266 = env51267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51266 == env51267) = true)

theorem identity51267 : scanCanonicalize (H12AffineFastState.compose env51267 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51267 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10280,1024,32769,45341,33,17,73737,8192,65,2049,5393,45404,10281,41992,41340,256,32,46093,99159]

theorem envBound51268 : H12AffineFastState.Bounded env51268 := by
  intro p hp
  have h : env51268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51267_51268 : H12AffineEnvironment.transform 13 5376 env51267 = env51268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51267 == env51268) = true)

theorem identity51268 : scanCanonicalize (H12AffineFastState.compose env51268 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51268 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env51269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13388,10280,1024,8540,4160,33,17,73737,8192,65,2049,5393,4097,10281,1365,33,256,32,5456,74250]

theorem envBound51269 : H12AffineFastState.Bounded env51269 := by
  intro p hp
  have h : env51269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51268_51269 : H12AffineEnvironment.transform 14 8541 env51268 = env51269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51268 == env51269) = true)

theorem identity51269 : scanCanonicalize (H12AffineFastState.compose env51269 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound51269 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8282,13388,10280,1024,8540,4160,33,17,83,8192,65,2049,5393,4097,10281,1365,33,256,32,5456,592]

theorem envBound51270 : H12AffineFastState.Bounded env51270 := by
  intro p hp
  have h : env51270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51269_51270 : H12AffineEnvironment.transform 15 8282 env51269 = env51270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env51269 == env51270) = true)

theorem identity51270 : scanCanonicalize (H12AffineFastState.compose env51270 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51270 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51271 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10280,1024,8460,4112,33,17,3,8192,17,2049,5393,4097,10281,1285,33,256,32,5376,512]

theorem envBound51271 : H12AffineFastState.Bounded env51271 := by
  intro p hp
  have h : env51271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51270_51271 : H12AffineEnvironment.transform 5 16 env51270 = env51271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51270 == env51271) = true)

theorem identity51271 : scanCanonicalize (H12AffineFastState.compose env51271 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound51271 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51272 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,5376,32,295,5425,2309,1024,33,4112,33,17,3,301,17,2049,5393,4097,2308,1285,33,256,32,5376,512]

theorem envBound51272 : H12AffineFastState.Bounded env51272 := by
  intro p hp
  have h : env51272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51271_51272 : H12AffineEnvironment.transform 12 301 env51271 = env51272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env51271 == env51272) = true)

theorem identity51272 : scanCanonicalize (H12AffineFastState.compose env51272 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound51272 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51273 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,301,0,32,295,49,2309,1024,33,1296,33,17,3,301,17,2049,17,1281,2308,1285,33,256,32,0,512]

theorem envBound51273 : H12AffineFastState.Bounded env51273 := by
  intro p hp
  have h : env51273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51272_51273 : H12AffineEnvironment.transform 11 1280 env51272 = env51273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env51272 == env51273) = true)

theorem identity51273 : scanCanonicalize (H12AffineFastState.compose env51273 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound51273 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51274 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1328,1280,301,0,32,295,49,1077,1024,33,1296,33,17,3,301,17,1329,17,1281,1076,1285,33,256,32,0,512]

theorem envBound51274 : H12AffineFastState.Bounded env51274 := by
  intro p hp
  have h : env51274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51273_51274 : H12AffineEnvironment.transform 10 1328 env51273 = env51274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env51273 == env51274) = true)

theorem identity51274 : scanCanonicalize (H12AffineFastState.compose env51274 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51274 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env51275 : List Nat := [2,4,8,16,32,16,8,256,512,52,260,308,301,0,32,295,49,1,52,33,292,33,17,3,301,17,261,17,309,0,305,33,256,32,0,512]

theorem envBound51275 : H12AffineFastState.Bounded env51275 := by
  intro p hp
  have h : env51275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51274_51275 : H12AffineEnvironment.transform 9 52 env51274 = env51275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51274 == env51275) = true)

theorem identity51275 : scanCanonicalize (H12AffineFastState.compose env51275 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51275 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51276 : List Nat := [2,4,8,1,32,1,8,256,512,37,260,293,301,0,32,295,32,1,37,33,292,33,0,3,301,0,261,0,292,0,288,33,256,32,0,512]

theorem envBound51276 : H12AffineFastState.Bounded env51276 := by
  intro p hp
  have h : env51276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51275_51276 : H12AffineEnvironment.transform 3 1 env51275 = env51276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51275 == env51276) = true)

theorem identity51276 : scanCanonicalize (H12AffineFastState.compose env51276 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound51276 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env51277 : List Nat := [2,4,8,1,32,1,8,256,32,37,260,293,301,0,32,295,32,1,37,33,292,33,0,3,301,0,261,0,292,0,288,33,256,32,0,32]

theorem envBound51277 : H12AffineFastState.Bounded env51277 := by
  intro p hp
  have h : env51277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51276_51277 : H12AffineEnvironment.transform 8 32 env51276 = env51277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env51276 == env51277) = true)

theorem identity51277 : scanCanonicalize (H12AffineFastState.compose env51277 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51277 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env51278 : List Nat := [2,4,8,1,1,1,8,256,1,4,260,260,268,0,1,262,1,1,4,0,261,0,0,3,268,0,261,0,261,0,257,0,256,1,0,1]

theorem envBound51278 : H12AffineFastState.Bounded env51278 := by
  intro p hp
  have h : env51278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51277_51278 : H12AffineEnvironment.transform 4 1 env51277 = env51278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51277 == env51278) = true)

theorem identity51278 : scanCanonicalize (H12AffineFastState.compose env51278 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51279 : List Nat := [2,4,8,1,1,1,8,5,1,4,1,1,9,0,1,3,1,1,4,0,0,0,0,3,9,0,0,0,0,0,4,0,5,1,0,1]

theorem envBound51279 : H12AffineFastState.Bounded env51279 := by
  intro p hp
  have h : env51279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51278_51279 : H12AffineEnvironment.transform 7 5 env51278 = env51279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51278 == env51279) = true)

theorem identity51279 : scanCanonicalize (H12AffineFastState.compose env51279 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51280 : List Nat := [2,4,7,1,1,1,7,5,1,4,1,1,6,0,1,3,1,1,4,0,0,0,0,3,6,0,0,0,0,0,4,0,5,1,0,1]

theorem envBound51280 : H12AffineFastState.Bounded env51280 := by
  intro p hp
  have h : env51280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51279_51280 : H12AffineEnvironment.transform 2 7 env51279 = env51280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51279 == env51280) = true)

def env51281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272392,441641,95497,8193,65,270377,436265,45405,32040,412720,156013,256,21792,46092,486254]

theorem envBound51281 : H12AffineFastState.Bounded env51281 := by
  intro p hp
  have h : env51281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51254_51281 : H12AffineEnvironment.transform 6 9 env51254 = env51281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51254 == env51281) = true)

def env51282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272392,272441,95497,8193,65,270377,277817,45405,32040,317728,62589,256,21792,46092,392830]

theorem envBound51282 : H12AffineFastState.Bounded env51282 := by
  intro p hp
  have h : env51282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51281_51282 : H12AffineEnvironment.transform 16 38160 env51281 = env51282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51281 == env51282) = true)

theorem identity51282 : scanCanonicalize (H12AffineFastState.compose env51282 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51282 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,13389,262144,1024,8540,290153,272392,272441,95497,8193,65,270377,277817,4096,32040,292989,21792,256,21792,5457,352035]

theorem envBound51283 : H12AffineFastState.Bounded env51283 := by
  intro p hp
  have h : env51283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51282_51283 : H12AffineEnvironment.transform 14 8541 env51282 = env51283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51282 == env51283) = true)

theorem identity51283 : scanCanonicalize (H12AffineFastState.compose env51283 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51283 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env51284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,13389,262144,1024,8540,290153,272392,272441,21763,8193,65,270377,277817,4096,32040,292989,21792,256,21792,5457,294697]

theorem envBound51284 : H12AffineFastState.Bounded env51284 := by
  intro p hp
  have h : env51284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51283_51284 : H12AffineEnvironment.transform 15 8202 env51283 = env51284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51283 == env51284) = true)

theorem identity51284 : scanCanonicalize (H12AffineFastState.compose env51284 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 31869) := by decide +kernel

theorem selectedBound51284 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env51285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,13389,31869,1024,8540,4372,21621,21572,21763,8193,65,23636,16708,4096,32040,1024,21792,256,21792,5457,852]

theorem envBound51285 : H12AffineFastState.Bounded env51285 := by
  intro p hp
  have h : env51285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51284_51285 : H12AffineEnvironment.transform 17 31869 env51284 = env51285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31869 env51284 == env51285) = true)

theorem identity51285 : scanCanonicalize (H12AffineFastState.compose env51285 (packedSelected [0,3,5,7,9,10,12,14,15,16,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound51285 : packedSelected [0,3,5,7,9,10,12,14,15,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env51286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5408,8541,8202,13389,10589,1024,8540,4372,341,356,35,8193,65,2420,5220,4096,10248,1024,0,256,0,5457,852]

theorem envBound51286 : H12AffineFastState.Bounded env51286 := by
  intro p hp
  have h : env51286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51285_51286 : H12AffineEnvironment.transform 13 5408 env51285 = env51286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env51285 == env51286) = true)

theorem identity51286 : scanCanonicalize (H12AffineFastState.compose env51286 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51286 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51287 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5205,8232,8202,13389,10280,1024,8233,4193,32,17,35,8193,65,2049,5220,4096,10248,1024,0,117,0,5156,545]

theorem envBound51287 : H12AffineFastState.Bounded env51287 := by
  intro p hp
  have h : env51287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51286_51287 : H12AffineEnvironment.transform 7 117 env51286 = env51287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51286 == env51287) = true)

theorem identity51287 : scanCanonicalize (H12AffineFastState.compose env51287 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51288 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5124,8232,8202,13340,10280,1024,8233,4144,32,17,35,8193,16,2049,5173,4096,10248,1024,0,36,0,5156,545]

theorem envBound51288 : H12AffineFastState.Bounded env51288 := by
  intro p hp
  have h : env51288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51287_51288 : H12AffineEnvironment.transform 5 17 env51287 = env51288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51287 == env51288) = true)

theorem identity51288 : scanCanonicalize (H12AffineFastState.compose env51288 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound51288 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51289 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5124,1,35,5173,2049,1024,0,4144,32,17,35,40,16,2049,5173,4096,2081,1024,0,36,0,5156,545]

theorem envBound51289 : H12AffineFastState.Bounded env51289 := by
  intro p hp
  have h : env51289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51288_51289 : H12AffineEnvironment.transform 12 41 env51288 = env51289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env51288 == env51289) = true)

theorem identity51289 : scanCanonicalize (H12AffineFastState.compose env51289 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound51289 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env51290 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1045,41,17,1,35,32,2049,1024,0,1061,32,17,35,40,16,2049,32,1045,2081,1024,0,36,0,49,545]

theorem envBound51290 : H12AffineFastState.Bounded env51290 := by
  intro p hp
  have h : env51290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51289_51290 : H12AffineEnvironment.transform 11 1045 env51289 = env51290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env51289 == env51290) = true)

theorem identity51290 : scanCanonicalize (H12AffineFastState.compose env51290 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound51290 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env51291 : List Nat := [2,4,8,16,32,17,9,36,512,549,2048,560,41,17,1,35,32,2049,549,0,512,32,17,35,40,16,2049,32,560,2081,549,0,36,0,49,545]

theorem envBound51291 : H12AffineFastState.Bounded env51291 := by
  intro p hp
  have h : env51291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51290_51291 : H12AffineEnvironment.transform 9 549 env51290 = env51291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env51290 == env51291) = true)

theorem identity51291 : scanCanonicalize (H12AffineFastState.compose env51291 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound51291 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51292 : List Nat := [2,4,8,16,32,17,9,36,512,549,545,560,41,17,1,35,32,544,549,0,512,32,17,35,40,16,544,32,560,512,549,0,36,0,49,545]

theorem envBound51292 : H12AffineFastState.Bounded env51292 := by
  intro p hp
  have h : env51292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51291_51292 : H12AffineEnvironment.transform 10 545 env51291 = env51292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env51291 == env51292) = true)

theorem identity51292 : scanCanonicalize (H12AffineFastState.compose env51292 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound51292 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51293 : List Nat := [2,4,8,16,32,17,9,36,48,21,17,0,41,17,1,35,32,16,21,0,48,32,17,35,40,16,16,32,0,48,21,0,36,0,49,17]

theorem envBound51293 : H12AffineFastState.Bounded env51293 := by
  intro p hp
  have h : env51293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51292_51293 : H12AffineEnvironment.transform 8 48 env51292 = env51293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env51292 == env51293) = true)

theorem identity51293 : scanCanonicalize (H12AffineFastState.compose env51293 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51294 : List Nat := [2,4,8,1,32,0,9,36,33,4,0,0,41,0,1,35,32,1,4,0,33,32,0,35,40,1,1,32,0,33,4,0,36,0,32,0]

theorem envBound51294 : H12AffineFastState.Bounded env51294 := by
  intro p hp
  have h : env51294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51293_51294 : H12AffineEnvironment.transform 3 1 env51293 = env51294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51293 == env51294) = true)

def env51295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272392,272440,95497,8193,65,270377,277816,45405,32040,317729,62588,256,21792,46092,392831]

theorem envBound51295 : H12AffineFastState.Bounded env51295 := by
  intro p hp
  have h : env51295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51281_51295 : H12AffineEnvironment.transform 16 38161 env51281 = env51295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env51281 == env51295) = true)

theorem identity51295 : scanCanonicalize (H12AffineFastState.compose env51295 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound51295 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1024,32769,17729,41340,41292,95497,8193,65,43357,46156,45405,32040,20565,62588,256,21792,46092,96011]

theorem envBound51296 : H12AffineFastState.Bounded env51296 := by
  intro p hp
  have h : env51296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51295_51296 : H12AffineEnvironment.transform 17 35188 env51295 = env51296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env51295 == env51296) = true)

theorem identity51296 : scanCanonicalize (H12AffineFastState.compose env51296 (packedSelected [7,8,10,12,14,15,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound51296 : packedSelected [7,8,10,12,14,15,20,27,28] rootPS < 2^1333 := by decide +kernel

def env51297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,65536,38161,35188,1024,32769,12393,41340,41292,65569,8193,65,43357,46156,45405,2048,9597,33108,256,8200,46092,66083]

theorem envBound51297 : H12AffineFastState.Bounded env51297 := by
  intro p hp
  have h : env51297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51296_51297 : H12AffineEnvironment.transform 13 13608 env51296 = env51297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env51296 == env51297) = true)

theorem identity51297 : scanCanonicalize (H12AffineFastState.compose env51297 (packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51297 : packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,0,65536,5393,2420,1024,1,12393,8572,8524,65569,8193,65,10589,13388,12637,2048,9597,340,256,8200,13324,66083]

theorem envBound51298 : H12AffineFastState.Bounded env51298 := by
  intro p hp
  have h : env51298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51297_51298 : H12AffineEnvironment.transform 14 0 env51297 = env51298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51297 == env51298) = true)

theorem identity51298 : scanCanonicalize (H12AffineFastState.compose env51298 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51298 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,0,8203,5393,2420,1024,1,12393,8572,8524,8234,8193,65,10589,13388,12637,2048,9597,340,256,8200,13324,8744]

theorem envBound51299 : H12AffineFastState.Bounded env51299 := by
  intro p hp
  have h : env51299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51298_51299 : H12AffineEnvironment.transform 15 8203 env51298 = env51299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51298 == env51299) = true)

theorem identity51299 : scanCanonicalize (H12AffineFastState.compose env51299 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51299 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,0,262,5393,2420,1024,1,4452,113,65,295,268,65,2128,5441,4176,2048,1136,340,256,261,5377,805]

theorem envBound51300 : H12AffineFastState.Bounded env51300 := by
  intro p hp
  have h : env51300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51299_51300 : H12AffineEnvironment.transform 12 269 env51299 = env51300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51299 == env51300) = true)

theorem identity51300 : scanCanonicalize (H12AffineFastState.compose env51300 (packedSelected [4,6,7,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound51300 : packedSelected [4,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51301 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,269,4160,0,262,4468,2420,101,1,4452,113,65,295,268,65,2128,4388,4176,2048,21,340,256,261,4452,805]

theorem envBound51301 : H12AffineFastState.Bounded env51301 := by
  intro p hp
  have h : env51301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51300_51301 : H12AffineEnvironment.transform 9 101 env51300 = env51301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env51300 == env51301) = true)

theorem identity51301 : scanCanonicalize (H12AffineFastState.compose env51301 (packedSelected [3,4,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound51301 : packedSelected [3,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env51302 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2404,269,2340,0,262,2064,2420,101,1,2048,113,65,295,268,65,2128,2112,2356,2048,21,340,256,261,2048,805]

theorem envBound51302 : H12AffineFastState.Bounded env51302 := by
  intro p hp
  have h : env51302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51301_51302 : H12AffineEnvironment.transform 11 2404 env51301 = env51302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env51301 == env51302) = true)

theorem identity51302 : scanCanonicalize (H12AffineFastState.compose env51302 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51302 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env51303 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,121,2128,0,114,2064,2048,101,1,2048,113,65,83,120,65,2128,2112,2112,2048,21,32,116,113,2048,593]

theorem envBound51303 : H12AffineFastState.Bounded env51303 := by
  intro p hp
  have h : env51303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51302_51303 : H12AffineEnvironment.transform 7 116 env51302 = env51303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51302 == env51303) = true)

theorem identity51303 : scanCanonicalize (H12AffineFastState.compose env51303 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound51303 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env51304 : List Nat := [2,4,8,16,32,64,9,116,81,101,2048,2064,121,2128,0,114,2064,2048,101,1,2048,113,65,83,120,65,2128,2112,2112,2048,21,32,116,113,2048,0]

theorem envBound51304 : H12AffineFastState.Bounded env51304 := by
  intro p hp
  have h : env51304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51303_51304 : H12AffineEnvironment.transform 8 81 env51303 = env51304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env51303 == env51304) = true)

theorem identity51304 : scanCanonicalize (H12AffineFastState.compose env51304 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51304 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env51305 : List Nat := [2,4,8,16,32,16,9,36,1,53,2048,2064,41,2048,0,34,2064,2048,53,1,2048,33,17,3,40,17,2048,2064,2064,2048,21,32,36,33,2048,0]

theorem envBound51305 : H12AffineFastState.Bounded env51305 := by
  intro p hp
  have h : env51305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51304_51305 : H12AffineEnvironment.transform 5 16 env51304 = env51305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51304 == env51305) = true)

def env51306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441761,95496,8328,65,4196520,436385,45525,32160,412857,4606445,256,21792,46213,486254]

theorem envBound51306 : H12AffineFastState.Bounded env51306 := by
  intro p hp
  have h : env51306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51234_51306 : H12AffineEnvironment.transform 22 441761 env51234 = env51306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env51234 == env51306) = true)

def env51307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441761,95496,8328,65,270376,436385,45525,32160,412857,156013,256,21792,46213,486254]

theorem envBound51307 : H12AffineFastState.Bounded env51307 := by
  intro p hp
  have h : env51307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51306_51307 : H12AffineEnvironment.transform 21 272512 env51306 = env51307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51306 == env51307) = true)

theorem identity51307 : scanCanonicalize (H12AffineFastState.compose env51307 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound51307 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,156133,62660,95496,8328,65,158029,57796,45525,32160,1500,156013,256,21792,46213,74251]

theorem envBound51308 : H12AffineFastState.Bounded env51308 := by
  intro p hp
  have h : env51308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51307_51308 : H12AffineEnvironment.transform 17 149861 env51307 = env51308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env51307 == env51308) = true)

theorem identity51308 : scanCanonicalize (H12AffineFastState.compose env51308 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51308 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,156133,62660,21762,8328,65,158029,57796,45525,32160,1500,156013,256,21792,46213,513]

theorem envBound51309 : H12AffineFastState.Bounded env51309 := by
  intro p hp
  have h : env51309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51308_51309 : H12AffineEnvironment.transform 15 8202 env51308 = env51309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51308 == env51309) = true)

theorem identity51309 : scanCanonicalize (H12AffineFastState.compose env51309 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound51309 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env51310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5528,23805,1024,32769,4161,29821,62660,21762,8328,65,31957,57796,45525,32160,1500,29941,256,21792,46213,513]

theorem envBound51310 : H12AffineFastState.Bounded env51310 := by
  intro p hp
  have h : env51310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51309_51310 : H12AffineEnvironment.transform 16 5528 env51309 = env51310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env51309 == env51310) = true)

theorem identity51310 : scanCanonicalize (H12AffineFastState.compose env51310 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound51310 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env51311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8202,5528,23805,1024,21760,4161,29821,8645,21762,8328,65,31957,13509,25812,32160,1500,29941,256,21792,24964,513]

theorem envBound51311 : H12AffineFastState.Bounded env51311 := by
  intro p hp
  have h : env51311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51310_51311 : H12AffineEnvironment.transform 14 21761 env51310 = env51311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env51310 == env51311) = true)

theorem identity51311 : scanCanonicalize (H12AffineFastState.compose env51311 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound51311 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env51312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,479,5528,23805,1024,21760,4161,21928,16,21762,349,65,23808,5392,17665,23669,1500,21792,256,21792,16465,513]

theorem envBound51312 : H12AffineFastState.Bounded env51312 := by
  intro p hp
  have h : env51312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51311_51312 : H12AffineEnvironment.transform 12 469 env51311 = env51312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env51311 == env51312) = true)

theorem identity51312 : scanCanonicalize (H12AffineFastState.compose env51312 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound51312 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env51313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,508,479,5528,2048,1024,509,4161,341,16,511,349,65,2557,5392,4604,2184,1500,477,256,477,5292,513]

theorem envBound51313 : H12AffineFastState.Bounded env51313 := by
  intro p hp
  have h : env51313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51312_51313 : H12AffineEnvironment.transform 13 5373 env51312 = env51313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env51312 == env51313) = true)

theorem identity51313 : scanCanonicalize (H12AffineFastState.compose env51313 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51313 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,372,343,5392,2048,1024,373,4161,341,16,375,349,65,2421,5392,4468,2048,1364,341,256,341,5156,513]

theorem envBound51314 : H12AffineFastState.Bounded env51314 := by
  intro p hp
  have h : env51314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51313_51314 : H12AffineEnvironment.transform 6 8 env51313 = env51314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51313 == env51314) = true)

theorem identity51314 : scanCanonicalize (H12AffineFastState.compose env51314 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51314 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env51315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,349,5237,372,343,5392,1,1024,373,4161,341,16,375,349,65,372,5392,4468,1,1364,341,256,341,5156,513]

theorem envBound51315 : H12AffineFastState.Bounded env51315 := by
  intro p hp
  have h : env51315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51314_51315 : H12AffineEnvironment.transform 10 1 env51314 = env51315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51314 == env51315) = true)

theorem identity51315 : scanCanonicalize (H12AffineFastState.compose env51315 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51315 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env51316 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,41,5237,0,35,5220,1,1024,1,4161,33,16,3,41,65,0,5220,4096,1,1056,33,116,33,5156,513]

theorem envBound51316 : H12AffineFastState.Bounded env51316 := by
  intro p hp
  have h : env51316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51315_51316 : H12AffineEnvironment.transform 7 116 env51315 = env51316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51315 == env51316) = true)

theorem identity51316 : scanCanonicalize (H12AffineFastState.compose env51316 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound51316 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51317 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,1061,41,80,0,35,65,1,1024,1,1124,33,16,3,41,65,0,65,1061,1,1056,33,116,33,1,513]

theorem envBound51317 : H12AffineFastState.Bounded env51317 := by
  intro p hp
  have h : env51317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51316_51317 : H12AffineEnvironment.transform 11 1061 env51316 = env51317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env51316 == env51317) = true)

theorem identity51317 : scanCanonicalize (H12AffineFastState.compose env51317 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound51317 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51318 : List Nat := [2,4,8,16,32,64,8,116,512,101,1,64,41,80,0,35,65,1,101,1,1,33,16,3,41,65,0,65,64,1,69,33,116,33,1,513]

theorem envBound51318 : H12AffineFastState.Bounded env51318 := by
  intro p hp
  have h : env51318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51317_51318 : H12AffineEnvironment.transform 9 101 env51317 = env51318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env51317 == env51318) = true)

theorem identity51318 : scanCanonicalize (H12AffineFastState.compose env51318 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound51318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51319 : List Nat := [2,4,8,16,32,64,8,116,65,101,1,64,41,80,0,35,65,1,101,1,1,33,16,3,41,65,0,65,64,1,69,33,116,33,1,64]

theorem envBound51319 : H12AffineFastState.Bounded env51319 := by
  intro p hp
  have h : env51319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51318_51319 : H12AffineEnvironment.transform 8 65 env51318 = env51319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env51318 == env51319) = true)

theorem identity51319 : scanCanonicalize (H12AffineFastState.compose env51319 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51320 : List Nat := [2,4,2,16,32,64,2,116,65,101,1,64,35,80,0,35,65,1,101,1,1,33,16,3,35,65,0,65,64,1,69,33,116,33,1,64]

theorem envBound51320 : H12AffineFastState.Bounded env51320 := by
  intro p hp
  have h : env51320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51319_51320 : H12AffineEnvironment.transform 2 2 env51319 = env51320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51319 == env51320) = true)

def env51321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441761,95496,8328,65,270377,436385,45525,32160,412857,156012,256,21792,46213,486254]

theorem envBound51321 : H12AffineFastState.Bounded env51321 := by
  intro p hp
  have h : env51321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51306_51321 : H12AffineEnvironment.transform 21 272513 env51306 = env51321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51306 == env51321) = true)

theorem identity51321 : scanCanonicalize (H12AffineFastState.compose env51321 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound51321 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416036,272513,412021,95496,8328,65,270377,416885,17665,32160,412857,156012,256,21792,16465,486254]

theorem envBound51322 : H12AffineFastState.Bounded env51322 := by
  intro p hp
  have h : env51322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51321_51322 : H12AffineEnvironment.transform 14 29908 env51321 = env51322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env51321 == env51322) = true)

def env51323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,160132,33,156117,95496,8328,65,2185,160981,17665,32160,156697,156012,256,21792,16465,213966]

theorem envBound51323 : H12AffineFastState.Bounded env51323 := by
  intro p hp
  have h : env51323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51322_51323 : H12AffineEnvironment.transform 17 10400 env51322 = env51323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env51322 == env51323) = true)

theorem identity51323 : scanCanonicalize (H12AffineFastState.compose env51323 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound51323 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env51324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,131072,10400,1024,29909,160132,33,156117,29910,8328,65,2185,160981,17665,32160,156697,156012,256,21792,16465,147984]

theorem envBound51324 : H12AffineFastState.Bounded env51324 := by
  intro p hp
  have h : env51324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51323_51324 : H12AffineEnvironment.transform 15 478 env51323 = env51324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env51323 == env51324) = true)

theorem identity51324 : scanCanonicalize (H12AffineFastState.compose env51324 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51324 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,131072,10280,1024,29789,160012,33,155997,29790,8192,65,2049,160861,17665,32040,156697,156012,256,21792,16465,147984]

theorem envBound51325 : H12AffineFastState.Bounded env51325 := by
  intro p hp
  have h : env51325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51324_51325 : H12AffineEnvironment.transform 6 8 env51324 = env51325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51324 == env51325) = true)

theorem identity51325 : scanCanonicalize (H12AffineFastState.compose env51325 (packedSelected [1,2,5,6,8,9,11,12,14,15,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51325 : packedSelected [1,2,5,6,8,9,11,12,14,15,22,23,24] rootPS < 2^1333 := by decide +kernel

def env51326 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,263,131072,10280,1024,29708,160012,33,155916,29711,8192,16,2049,160780,17665,32040,156697,155965,256,21792,16384,147984]

theorem envBound51326 : H12AffineFastState.Bounded env51326 := by
  intro p hp
  have h : env51326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51325_51326 : H12AffineEnvironment.transform 5 17 env51325 = env51326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51325 == env51326) = true)

def env51327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,160133,32,156116,95496,8328,65,2184,160980,17665,32160,156696,156012,256,21792,16465,213967]

theorem envBound51327 : H12AffineFastState.Bounded env51327 := by
  intro p hp
  have h : env51327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51322_51327 : H12AffineEnvironment.transform 17 10401 env51322 = env51327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env51322 == env51327) = true)

theorem identity51327 : scanCanonicalize (H12AffineFastState.compose env51327 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound51327 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env51328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21795,131072,10401,1024,29909,160133,32,156116,8235,8328,65,2184,160980,17665,32160,156696,156012,256,21792,16465,136940]

theorem envBound51328 : H12AffineFastState.Bounded env51328 := by
  intro p hp
  have h : env51328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51327_51328 : H12AffineEnvironment.transform 15 21795 env51327 = env51328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env51327 == env51328) = true)

theorem identity51328 : scanCanonicalize (H12AffineFastState.compose env51328 (packedSelected [1,4,9,11,14,18,19,20,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound51328 : packedSelected [1,4,9,11,14,18,19,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21795,25028,10401,1024,29909,4161,32,16,8235,8328,65,2184,5392,17665,32160,1500,168,256,21792,16465,30504]

theorem envBound51329 : H12AffineFastState.Bounded env51329 := by
  intro p hp
  have h : env51329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51328_51329 : H12AffineEnvironment.transform 16 25028 env51328 = env51329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env51328 == env51329) = true)

theorem identity51329 : scanCanonicalize (H12AffineFastState.compose env51329 (packedSelected [0,1,3,6,7,8,9,10,11,12,15,16,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 208) := by decide +kernel

theorem selectedBound51329 : packedSelected [0,1,3,6,7,8,9,10,11,12,15,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env51330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,208,16384,21508,21795,16660,2161,1024,21509,4161,32,16,251,88,65,2184,5392,17665,23920,1500,168,256,21792,16465,22520]

theorem envBound51330 : H12AffineFastState.Bounded env51330 := by
  intro p hp
  have h : env51330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51329_51330 : H12AffineEnvironment.transform 12 208 env51329 = env51330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env51329 == env51330) = true)

theorem identity51330 : scanCanonicalize (H12AffineFastState.compose env51330 (packedSelected [1,3,4,5,6,8,10,14,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5341) := by decide +kernel

theorem selectedBound51330 : packedSelected [1,3,4,5,6,8,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,208,5341,217,510,5577,2161,1024,216,4161,32,16,251,88,65,2184,5392,4572,2477,1500,168,256,509,5260,805]

theorem envBound51331 : H12AffineFastState.Bounded env51331 := by
  intro p hp
  have h : env51331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51330_51331 : H12AffineEnvironment.transform 13 5341 env51330 = env51331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5341 env51330 == env51331) = true)

theorem identity51331 : scanCanonicalize (H12AffineFastState.compose env51331 (packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound51331 : packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env51332 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,5341,217,3,5172,2161,1024,216,4161,32,16,251,88,65,2184,5357,4129,2128,1057,168,253,0,5260,728]

theorem envBound51332 : H12AffineFastState.Bounded env51332 := by
  intro p hp
  have h : env51332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51331_51332 : H12AffineEnvironment.transform 7 253 env51331 = env51332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env51331 == env51332) = true)

theorem identity51332 : scanCanonicalize (H12AffineFastState.compose env51332 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound51332 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51333 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,9,5124,0,3,5172,2161,1024,1,4161,32,16,34,88,65,2129,5172,4129,2128,1057,113,36,0,5205,513]

theorem envBound51333 : H12AffineFastState.Bounded env51333 := by
  intro p hp
  have h : env51333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51332_51333 : H12AffineEnvironment.transform 6 89 env51332 = env51333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env51332 == env51333) = true)

theorem identity51333 : scanCanonicalize (H12AffineFastState.compose env51333 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51333 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51334 : List Nat := [2,4,8,16,1,64,89,5,512,1024,2048,4096,9,5124,0,3,5141,2128,1024,1,4161,1,16,3,88,65,2129,5141,4096,2128,1024,80,5,0,5205,513]

theorem envBound51334 : H12AffineFastState.Bounded env51334 := by
  intro p hp
  have h : env51334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51333_51334 : H12AffineEnvironment.transform 4 1 env51333 = env51334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51333 == env51334) = true)

theorem identity51334 : scanCanonicalize (H12AffineFastState.compose env51334 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51334 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51335 : List Nat := [2,4,8,16,1,64,89,5,512,1024,2048,1029,9,1,0,3,16,2128,1024,1,1092,1,16,3,88,65,2129,16,1029,2128,1024,80,5,0,80,513]

theorem envBound51335 : H12AffineFastState.Bounded env51335 := by
  intro p hp
  have h : env51335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51334_51335 : H12AffineEnvironment.transform 11 1029 env51334 = env51335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env51334 == env51335) = true)

theorem identity51335 : scanCanonicalize (H12AffineFastState.compose env51335 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound51335 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51336 : List Nat := [2,4,8,16,1,64,89,5,512,68,2048,65,9,1,0,3,16,2128,68,1,0,1,16,3,88,65,2129,16,65,2128,68,80,5,0,80,513]

theorem envBound51336 : H12AffineFastState.Bounded env51336 := by
  intro p hp
  have h : env51336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51335_51336 : H12AffineEnvironment.transform 9 68 env51335 = env51336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env51335 == env51336) = true)

theorem identity51336 : scanCanonicalize (H12AffineFastState.compose env51336 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound51336 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51337 : List Nat := [2,4,8,16,1,64,89,5,80,68,2048,65,9,1,0,3,16,2128,68,1,0,1,16,3,88,65,2129,16,65,2128,68,80,5,0,80,81]

theorem envBound51337 : H12AffineFastState.Bounded env51337 := by
  intro p hp
  have h : env51337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51336_51337 : H12AffineEnvironment.transform 8 80 env51336 = env51337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env51336 == env51337) = true)

theorem identity51337 : scanCanonicalize (H12AffineFastState.compose env51337 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51337 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env51338 : List Nat := [2,4,8,16,1,64,89,5,80,68,1,65,9,1,0,3,16,81,68,1,0,1,16,3,88,65,80,16,65,81,68,80,5,0,80,81]

theorem envBound51338 : H12AffineFastState.Bounded env51338 := by
  intro p hp
  have h : env51338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51337_51338 : H12AffineEnvironment.transform 10 1 env51337 = env51338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51337 == env51338) = true)

theorem identity51338 : scanCanonicalize (H12AffineFastState.compose env51338 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51339 : List Nat := [2,4,8,0,1,64,73,5,64,68,1,65,9,1,0,3,0,65,68,1,0,1,0,3,72,65,64,0,65,65,68,64,5,0,64,65]

theorem envBound51339 : H12AffineFastState.Bounded env51339 := by
  intro p hp
  have h : env51339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51338_51339 : H12AffineEnvironment.transform 3 0 env51338 = env51339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51338 == env51339) = true)

theorem identity51339 : scanCanonicalize (H12AffineFastState.compose env51339 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound51339 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51340 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,0,9,1,0,3,0,0,5,1,0,1,0,3,9,0,1,0,0,0,5,1,5,0,1,0]

theorem envBound51340 : H12AffineFastState.Bounded env51340 := by
  intro p hp
  have h : env51340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51339_51340 : H12AffineEnvironment.transform 5 1 env51339 = env51340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51339 == env51340) = true)

def env51341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,8388608,8898729,8328,65,4196520,8393985,8785013,8830977,412857,12645453,256,21793,46212,486254]

theorem envBound51341 : H12AffineFastState.Bounded env51341 := by
  intro p hp
  have h : env51341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51233_51341 : H12AffineEnvironment.transform 20 416037 env51233 = env51341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416037 env51233 == env51341) = true)

def env51342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441760,95497,8328,65,4196520,436385,45525,32161,412857,4606445,256,21793,46212,486254]

theorem envBound51342 : H12AffineFastState.Bounded env51342 := by
  intro p hp
  have h : env51342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51341_51342 : H12AffineEnvironment.transform 22 441760 env51341 = env51342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env51341 == env51342) = true)

def env51343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441760,95497,8328,65,270376,436385,45525,32161,412857,156013,256,21793,46212,486254]

theorem envBound51343 : H12AffineFastState.Bounded env51343 := by
  intro p hp
  have h : env51343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51342_51343 : H12AffineEnvironment.transform 21 272512 env51342 = env51343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51342 == env51343) = true)

theorem identity51343 : scanCanonicalize (H12AffineFastState.compose env51343 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51343 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272512,441760,21763,8328,65,270376,436385,45525,32161,412857,156013,256,21793,46212,412516]

theorem envBound51344 : H12AffineFastState.Bounded env51344 := by
  intro p hp
  have h : env51344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51343_51344 : H12AffineEnvironment.transform 15 8202 env51343 = env51344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51343 == env51344) = true)

def env51345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272392,441640,21763,8192,65,270376,436265,45405,32041,412721,156013,256,21793,46092,412516]

theorem envBound51345 : H12AffineFastState.Bounded env51345 := by
  intro p hp
  have h : env51345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51344_51345 : H12AffineEnvironment.transform 6 8 env51344 = env51345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51344 == env51345) = true)

theorem identity51345 : scanCanonicalize (H12AffineFastState.compose env51345 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound51345 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env51346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,171109,1024,32769,50496,177261,8525,21763,8192,65,179277,13388,45405,32041,53332,156013,256,21793,46092,55041]

theorem envBound51346 : H12AffineFastState.Bounded env51346 := by
  intro p hp
  have h : env51346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51345_51346 : H12AffineEnvironment.transform 17 171109 env51345 = env51346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env51345 == env51346) = true)

theorem identity51346 : scanCanonicalize (H12AffineFastState.compose env51346 (packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51346 : packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env51347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5393,35188,1024,32769,50496,41340,8525,21763,8192,65,43356,13388,45405,32041,53332,29820,256,21793,46092,55041]

theorem envBound51347 : H12AffineFastState.Bounded env51347 := by
  intro p hp
  have h : env51347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51346_51347 : H12AffineEnvironment.transform 16 5393 env51346 = env51347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51346 == env51347) = true)

theorem identity51347 : scanCanonicalize (H12AffineFastState.compose env51347 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound51347 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env51348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,5393,23668,1024,21761,4160,29820,8525,21763,8192,65,31836,13388,25693,32041,1364,29820,256,21793,24844,513]

theorem envBound51348 : H12AffineFastState.Bounded env51348 := by
  intro p hp
  have h : env51348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51347_51348 : H12AffineEnvironment.transform 14 21760 env51347 = env51348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env51347 == env51348) = true)

theorem identity51348 : scanCanonicalize (H12AffineFastState.compose env51348 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51348 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8202,5393,10281,1024,8540,4160,33,8525,8542,8192,65,2049,13388,4096,2420,1364,33,256,8572,5457,513]

theorem envBound51349 : H12AffineFastState.Bounded env51349 := by
  intro p hp
  have h : env51349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51348_51349 : H12AffineEnvironment.transform 13 13405 env51348 = env51349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51348 == env51349) = true)

theorem identity51349 : scanCanonicalize (H12AffineFastState.compose env51349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51350 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12620,8541,8202,4096,10281,273,8540,4160,33,8525,8542,8192,65,2049,12637,4096,2420,69,33,256,8572,4160,513]

theorem envBound51350 : H12AffineFastState.Bounded env51350 := by
  intro p hp
  have h : env51350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51349_51350 : H12AffineEnvironment.transform 9 273 env51349 = env51350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51349 == env51350) = true)

theorem identity51350 : scanCanonicalize (H12AffineFastState.compose env51350 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound51350 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51351 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,8192,8313,8541,8202,309,10281,273,8540,373,33,8525,8542,8192,65,2049,8296,309,2420,69,33,256,8572,373,513]

theorem envBound51351 : H12AffineFastState.Bounded env51351 := by
  intro p hp
  have h : env51351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51350_51351 : H12AffineEnvironment.transform 11 309 env51350 = env51351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env51350 == env51351) = true)

theorem identity51351 : scanCanonicalize (H12AffineFastState.compose env51351 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51351 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env51352 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,309,8192,8313,8541,8202,309,8233,273,8540,373,33,8525,8542,8192,65,1,8296,309,372,69,33,256,8572,373,513]

theorem envBound51352 : H12AffineFastState.Bounded env51352 := by
  intro p hp
  have h : env51352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51351_51352 : H12AffineEnvironment.transform 10 0 env51351 = env51352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51351 == env51352) = true)

def env51353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272393,441641,21763,8193,65,270376,436264,45404,32040,412720,156013,256,21793,46093,412516]

theorem envBound51353 : H12AffineFastState.Bounded env51353 := by
  intro p hp
  have h : env51353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51344_51353 : H12AffineEnvironment.transform 6 9 env51344 = env51353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51344 == env51353) = true)

theorem identity51353 : scanCanonicalize (H12AffineFastState.compose env51353 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound51353 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env51354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46393,262144,1024,32769,322588,272393,264208,21763,8193,65,270376,269585,45404,32040,325897,54356,256,21793,46093,327261]

theorem envBound51354 : H12AffineFastState.Bounded env51354 := by
  intro p hp
  have h : env51354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51353_51354 : H12AffineEnvironment.transform 16 46393 env51353 = env51354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env51353 == env51354) = true)

theorem identity51354 : scanCanonicalize (H12AffineFastState.compose env51354 (packedSelected [0,3,4,10,11,14,18,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound51354 : packedSelected [0,3,4,10,11,14,18,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env51355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46393,43357,1024,32769,17729,33108,41293,21763,8193,65,35189,46156,45404,32040,20564,54356,256,21793,46093,22272]

theorem envBound51355 : H12AffineFastState.Bounded env51355 := by
  intro p hp
  have h : env51355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51354_51355 : H12AffineEnvironment.transform 17 43357 env51354 = env51355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env51354 == env51355) = true)

theorem identity51355 : scanCanonicalize (H12AffineFastState.compose env51355 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51355 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env51356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16741,23809,1024,29789,17729,29960,21777,21763,8193,65,32041,16400,17664,32040,20564,8200,256,21793,16465,22272]

theorem envBound51356 : H12AffineFastState.Bounded env51356 := by
  intro p hp
  have h : env51356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51355_51356 : H12AffineEnvironment.transform 14 29788 env51355 = env51356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51355 == env51356) = true)

theorem identity51356 : scanCanonicalize (H12AffineFastState.compose env51356 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51356 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8202,13624,10588,1024,0,12572,341,8524,8542,8193,65,2420,13389,12637,2421,9225,8200,256,8572,13324,9053]

theorem envBound51357 : H12AffineFastState.Bounded env51357 := by
  intro p hp
  have h : env51357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51356_51357 : H12AffineEnvironment.transform 13 13405 env51356 = env51357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51356 == env51357) = true)

theorem identity51357 : scanCanonicalize (H12AffineFastState.compose env51357 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51357 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5220,2048,1024,0,4160,341,16,2,349,65,2420,5393,4097,2421,1365,340,256,32,5456,513]

theorem envBound51358 : H12AffineFastState.Bounded env51358 := by
  intro p hp
  have h : env51358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51357_51358 : H12AffineEnvironment.transform 12 348 env51357 = env51358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51357 == env51358) = true)

theorem identity51358 : scanCanonicalize (H12AffineFastState.compose env51358 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound51358 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env51359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3392,1,342,3109,2048,1024,0,2049,341,16,2,349,65,2420,3408,2112,2421,1365,340,256,32,3345,513]

theorem envBound51359 : H12AffineFastState.Bounded env51359 := by
  intro p hp
  have h : env51359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51358_51359 : H12AffineEnvironment.transform 11 2113 env51358 = env51359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env51358 == env51359) = true)

theorem identity51359 : scanCanonicalize (H12AffineFastState.compose env51359 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51359 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env51360 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,348,2421,1,342,2064,2048,53,0,2049,341,16,2,349,65,2420,2405,2112,2421,352,340,256,32,2340,513]

theorem envBound51360 : H12AffineFastState.Bounded env51360 := by
  intro p hp
  have h : env51360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51359_51360 : H12AffineEnvironment.transform 9 53 env51359 = env51360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51359 == env51360) = true)

theorem identity51360 : scanCanonicalize (H12AffineFastState.compose env51360 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51360 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51361 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2113,41,2048,1,35,2064,2048,53,0,2049,32,16,2,40,65,2049,2064,2112,2048,21,33,117,32,2129,513]

theorem envBound51361 : H12AffineFastState.Bounded env51361 := by
  intro p hp
  have h : env51361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51360_51361 : H12AffineEnvironment.transform 7 117 env51360 = env51361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51360 == env51361) = true)

theorem identity51361 : scanCanonicalize (H12AffineFastState.compose env51361 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51362 : List Nat := [2,4,8,1,32,64,9,100,512,36,2048,2113,41,2048,1,35,2049,2048,36,0,2049,32,1,2,40,65,2049,2049,2112,2048,4,33,100,32,2112,513]

theorem envBound51362 : H12AffineFastState.Bounded env51362 := by
  intro p hp
  have h : env51362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51361_51362 : H12AffineEnvironment.transform 3 1 env51361 = env51362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51361 == env51362) = true)

theorem identity51362 : scanCanonicalize (H12AffineFastState.compose env51362 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51362 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51363 : List Nat := [2,4,3,1,32,64,2,100,512,36,2048,2113,34,2048,1,35,2049,2048,36,0,2049,32,1,2,35,65,2049,2049,2112,2048,4,33,100,32,2112,513]

theorem envBound51363 : H12AffineFastState.Bounded env51363 := by
  intro p hp
  have h : env51363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51362_51363 : H12AffineEnvironment.transform 2 3 env51362 = env51363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51362 == env51363) = true)

def env51364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441760,95497,8328,65,270377,436385,45525,32161,412857,156012,256,21793,46212,486254]

theorem envBound51364 : H12AffineFastState.Bounded env51364 := by
  intro p hp
  have h : env51364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51342_51364 : H12AffineEnvironment.transform 21 272513 env51342 = env51364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51342 == env51364) = true)

theorem identity51364 : scanCanonicalize (H12AffineFastState.compose env51364 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound51364 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,115871,243003,73754,95497,8328,65,245139,79131,45525,32161,119043,156012,256,21793,46212,63188]

theorem envBound51365 : H12AffineFastState.Bounded env51365 := by
  intro p hp
  have h : env51365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51364_51365 : H12AffineEnvironment.transform 17 236986 env51364 = env51365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env51364 == env51365) = true)

def env51366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67754,1024,32769,115871,73771,73754,95497,8328,65,75907,79131,45525,32161,119043,62588,256,21793,46212,63188]

theorem envBound51366 : H12AffineFastState.Bounded env51366 := by
  intro p hp
  have h : env51366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51365_51366 : H12AffineEnvironment.transform 16 38160 env51365 = env51366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51365 == env51366) = true)

theorem identity51366 : scanCanonicalize (H12AffineFastState.compose env51366 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound51366 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env51367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38160,56437,1024,32769,4160,62708,62661,41430,8328,65,64604,57796,45525,32161,1500,62588,256,21793,46212,63188]

theorem envBound51367 : H12AffineFastState.Bounded env51367 := by
  intro p hp
  have h : env51367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51366_51367 : H12AffineEnvironment.transform 15 54495 env51366 = env51367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env51366 == env51367) = true)

theorem identity51367 : scanCanonicalize (H12AffineFastState.compose env51367 (packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound51367 : packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env51368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,40970,38160,43168,1024,32769,4160,32801,32784,41430,8328,65,34953,38161,45525,2420,1500,32937,256,8692,46212,33281]

theorem envBound51368 : H12AffineFastState.Bounded env51368 := by
  intro p hp
  have h : env51368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51367_51368 : H12AffineEnvironment.transform 13 13525 env51367 = env51368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env51367 == env51368) = true)

theorem identity51368 : scanCanonicalize (H12AffineFastState.compose env51368 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51368 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,8202,5392,10400,1024,1,4160,33,16,8662,8328,65,2185,5393,12757,2420,1500,169,256,8692,13444,513]

theorem envBound51369 : H12AffineFastState.Bounded env51369 := by
  intro p hp
  have h : env51369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51368_51369 : H12AffineEnvironment.transform 14 0 env51368 = env51369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51368 == env51369) = true)

theorem identity51369 : scanCanonicalize (H12AffineFastState.compose env51369 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound51369 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,0,399,5392,2341,1024,1,4160,33,16,83,269,65,2185,5393,4176,2420,1500,169,256,113,5377,513]

theorem envBound51370 : H12AffineFastState.Bounded env51370 := by
  intro p hp
  have h : env51370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51369_51370 : H12AffineEnvironment.transform 12 389 env51369 = env51370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env51369 == env51370) = true)

theorem identity51370 : scanCanonicalize (H12AffineFastState.compose env51370 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 729) := by decide +kernel

theorem selectedBound51370 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env51371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,729,389,1929,0,399,1993,2341,1024,1,665,33,16,83,269,65,2185,1992,649,2420,1500,169,256,113,2008,513]

theorem envBound51371 : H12AffineFastState.Bounded env51371 := by
  intro p hp
  have h : env51371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51370_51371 : H12AffineEnvironment.transform 11 729 env51370 = env51371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 729 env51370 == env51371) = true)

theorem identity51371 : scanCanonicalize (H12AffineFastState.compose env51371 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51371 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env51372 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,593,269,1793,0,263,1857,2341,1024,1,529,33,16,83,269,65,2049,1856,513,2420,1364,33,256,113,1872,513]

theorem envBound51372 : H12AffineFastState.Bounded env51372 := by
  intro p hp
  have h : env51372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51371_51372 : H12AffineEnvironment.transform 6 8 env51371 = env51372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51371 == env51372) = true)

theorem identity51372 : scanCanonicalize (H12AffineFastState.compose env51372 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51372 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env51373 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,512,269,1793,0,263,1808,2341,1024,1,529,33,16,2,269,16,2049,1809,513,2341,1285,33,256,32,1793,513]

theorem envBound51373 : H12AffineFastState.Bounded env51373 := by
  intro p hp
  have h : env51373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51372_51373 : H12AffineEnvironment.transform 5 17 env51372 = env51373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51372 == env51373) = true)

theorem identity51373 : scanCanonicalize (H12AffineFastState.compose env51373 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound51373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51374 : List Nat := [2,4,8,16,32,17,8,256,277,1024,2048,277,269,1044,0,263,1029,2341,1024,1,260,33,16,2,269,16,2049,1028,276,2341,1285,33,256,32,1044,276]

theorem envBound51374 : H12AffineFastState.Bounded env51374 := by
  intro p hp
  have h : env51374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51373_51374 : H12AffineEnvironment.transform 8 277 env51373 = env51374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env51373 == env51374) = true)

theorem identity51374 : scanCanonicalize (H12AffineFastState.compose env51374 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51375 : List Nat := [2,4,8,16,32,17,8,256,277,20,2048,277,269,0,0,263,17,2341,20,1,260,33,16,2,269,16,2049,16,276,2341,273,33,256,32,0,276]

theorem envBound51375 : H12AffineFastState.Bounded env51375 := by
  intro p hp
  have h : env51375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51374_51375 : H12AffineEnvironment.transform 9 20 env51374 = env51375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51374 == env51375) = true)

theorem identity51375 : scanCanonicalize (H12AffineFastState.compose env51375 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51376 : List Nat := [2,4,8,1,32,0,8,256,260,5,2048,260,269,0,0,263,0,2341,5,1,260,33,1,2,269,1,2049,1,261,2341,256,33,256,32,0,261]

theorem envBound51376 : H12AffineFastState.Bounded env51376 := by
  intro p hp
  have h : env51376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51375_51376 : H12AffineEnvironment.transform 3 1 env51375 = env51376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51375 == env51376) = true)

theorem identity51376 : scanCanonicalize (H12AffineFastState.compose env51376 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound51376 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51377 : List Nat := [2,4,8,1,32,0,8,256,260,5,33,260,269,0,0,263,0,260,5,1,260,33,1,2,269,1,32,1,261,260,256,33,256,32,0,261]

theorem envBound51377 : H12AffineFastState.Bounded env51377 := by
  intro p hp
  have h : env51377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51376_51377 : H12AffineEnvironment.transform 10 33 env51376 = env51377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env51376 == env51377) = true)

theorem identity51377 : scanCanonicalize (H12AffineFastState.compose env51377 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51378 : List Nat := [2,4,8,1,0,0,8,256,260,5,1,260,269,0,0,263,0,260,5,1,260,1,1,2,269,1,0,1,261,260,256,1,256,0,0,261]

theorem envBound51378 : H12AffineFastState.Bounded env51378 := by
  intro p hp
  have h : env51378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51377_51378 : H12AffineEnvironment.transform 4 0 env51377 = env51378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51377 == env51378) = true)

def env51379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67755,1024,32769,115871,73770,73754,95497,8328,65,75906,79131,45525,32161,119043,62589,256,21793,46212,63188]

theorem envBound51379 : H12AffineFastState.Bounded env51379 := by
  intro p hp
  have h : env51379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51365_51379 : H12AffineEnvironment.transform 16 38161 env51365 = env51379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env51365 == env51379) = true)

theorem identity51379 : scanCanonicalize (H12AffineFastState.compose env51379 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51379 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env51380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10401,1024,32769,58517,32,16,21763,8328,65,2184,5393,45525,32161,61705,62589,256,21793,46212,63188]

theorem envBound51380 : H12AffineFastState.Bounded env51380 := by
  intro p hp
  have h : env51380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51379_51380 : H12AffineEnvironment.transform 15 8202 env51379 = env51380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51379 == env51380) = true)

theorem identity51380 : scanCanonicalize (H12AffineFastState.compose env51380 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound51380 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env51381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,38161,10401,1024,32769,36929,32,16,8663,8328,65,2184,5393,45525,2421,34269,32937,256,8693,46212,33280]

theorem envBound51381 : H12AffineFastState.Bounded env51381 := by
  intro p hp
  have h : env51381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51380_51381 : H12AffineEnvironment.transform 13 13524 env51380 = env51381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env51380 == env51381) = true)

def env51382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441761,95496,8328,65,4196520,436384,45524,32160,412857,4606444,256,21793,46212,486254]

theorem envBound51382 : H12AffineFastState.Bounded env51382 := by
  intro p hp
  have h : env51382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51341_51382 : H12AffineEnvironment.transform 22 441761 env51341 = env51382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env51341 == env51382) = true)

def env51383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441761,95496,8328,65,270376,436384,45524,32160,412857,156012,256,21793,46212,486254]

theorem envBound51383 : H12AffineFastState.Bounded env51383 := by
  intro p hp
  have h : env51383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51382_51383 : H12AffineEnvironment.transform 21 272512 env51382 = env51383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51382 == env51383) = true)

theorem identity51383 : scanCanonicalize (H12AffineFastState.compose env51383 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound51383 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,416037,272512,441761,41430,8328,65,270376,436384,45524,32160,412857,156012,256,21793,46212,442288]

theorem envBound51384 : H12AffineFastState.Bounded env51384 := by
  intro p hp
  have h : env51384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51383_51384 : H12AffineEnvironment.transform 15 54494 env51383 = env51384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env51383 == env51384) = true)

def env51385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272392,441641,41310,8192,65,270376,436264,45404,32040,412721,156012,256,21793,46092,442168]

theorem envBound51385 : H12AffineFastState.Bounded env51385 := by
  intro p hp
  have h : env51385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51384_51385 : H12AffineEnvironment.transform 6 8 env51384 = env51385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51384 == env51385) = true)

theorem identity51385 : scanCanonicalize (H12AffineFastState.compose env51385 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound51385 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env51386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1024,32769,140301,21792,180225,41310,8192,65,23808,185600,45404,32040,143641,156012,256,21793,46092,180752]

theorem envBound51386 : H12AffineFastState.Bounded env51386 := by
  intro p hp
  have h : env51386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51385_51386 : H12AffineEnvironment.transform 17 32040 env51385 = env51386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env51385 == env51386) = true)

theorem identity51386 : scanCanonicalize (H12AffineFastState.compose env51386 (packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51386 : packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env51387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,131072,32040,1024,8541,140301,21792,155997,2,8192,65,23808,160860,4096,32040,143641,156012,256,21793,5456,156492]

theorem envBound51387 : H12AffineFastState.Bounded env51387 := by
  intro p hp
  have h : env51387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51386_51387 : H12AffineEnvironment.transform 14 8540 env51386 = env51387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51386 == env51387) = true)

theorem identity51387 : scanCanonicalize (H12AffineFastState.compose env51387 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51387 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21590,131072,23668,1024,1,132433,21792,147457,2,348,65,23808,152832,4096,23668,135237,147504,256,21793,5456,147984]

theorem envBound51388 : H12AffineFastState.Bounded env51388 := by
  intro p hp
  have h : env51388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51387_51388 : H12AffineEnvironment.transform 12 348 env51387 = env51388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51387 == env51388) = true)

theorem identity51388 : scanCanonicalize (H12AffineFastState.compose env51388 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51388 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21590,5393,23668,1024,1,4160,21792,21776,2,348,65,23808,16401,4096,23668,1364,21793,256,21793,5456,22273]

theorem envBound51389 : H12AffineFastState.Bounded env51389 := by
  intro p hp
  have h : env51389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51388_51389 : H12AffineEnvironment.transform 16 5393 env51388 = env51389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51388 == env51389) = true)

theorem identity51389 : scanCanonicalize (H12AffineFastState.compose env51389 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51389 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51390 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,0,21590,5221,23668,1024,1,4160,21588,21604,2,40,65,23668,16401,4096,23668,1056,21589,116,21589,5156,22133]

theorem envBound51390 : H12AffineFastState.Bounded env51390 := by
  intro p hp
  have h : env51390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51389_51390 : H12AffineEnvironment.transform 7 116 env51389 = env51390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51389 == env51390) = true)

theorem identity51390 : scanCanonicalize (H12AffineFastState.compose env51390 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 7205) := by decide +kernel

theorem selectedBound51390 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env51391 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,7205,0,2163,5221,81,1024,1,4160,2161,2113,2,40,65,81,7220,4096,81,1056,2160,116,2160,5156,2640]

theorem envBound51391 : H12AffineFastState.Bounded env51391 := by
  intro p hp
  have h : env51391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51390_51391 : H12AffineEnvironment.transform 13 7205 env51390 = env51391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7205 env51390 == env51391) = true)

theorem identity51391 : scanCanonicalize (H12AffineFastState.compose env51391 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51391 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env51392 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,40,6161,0,2163,4177,81,52,1,4160,2161,2113,2,40,65,81,6144,4096,81,20,2160,116,2160,4112,2640]

theorem envBound51392 : H12AffineFastState.Bounded env51392 := by
  intro p hp
  have h : env51392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51391_51392 : H12AffineEnvironment.transform 9 52 env51391 = env51392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51391 == env51392) = true)

def env51393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272393,441640,41311,8193,65,270376,436265,45405,32041,412720,156012,256,21793,46093,442169]

theorem envBound51393 : H12AffineFastState.Bounded env51393 := by
  intro p hp
  have h : env51393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51384_51393 : H12AffineEnvironment.transform 6 9 env51384 = env51393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51384 == env51393) = true)

theorem identity51393 : scanCanonicalize (H12AffineFastState.compose env51393 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound51393 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env51394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,2049,1024,32769,151844,8200,177449,41311,8193,65,10281,172072,45405,32041,148529,156012,256,21793,46093,177976]

theorem envBound51394 : H12AffineFastState.Bounded env51394 := by
  intro p hp
  have h : env51394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51393_51394 : H12AffineEnvironment.transform 17 2049 env51393 = env51394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env51393 == env51394) = true)

theorem identity51394 : scanCanonicalize (H12AffineFastState.compose env51394 (packedSelected [1,2,3,4,6,7,10,14,16,19,20,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound51394 : packedSelected [1,2,3,4,6,7,10,14,16,19,20,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,2049,1024,32769,37173,8200,30008,41311,8193,65,10281,24633,45405,32041,33824,41341,256,21793,46093,30505]

theorem envBound51395 : H12AffineFastState.Bounded env51395 := by
  intro p hp
  have h : env51395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51394_51395 : H12AffineEnvironment.transform 16 49169 env51394 = env51395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env51394 == env51395) = true)

theorem identity51395 : scanCanonicalize (H12AffineFastState.compose env51395 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound51395 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env51396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,32768,41263,46441,2049,1024,32769,37173,8200,64,41311,8193,65,10281,5441,45405,2129,33824,41341,256,8281,46093,593]

theorem envBound51396 : H12AffineFastState.Bounded env51396 := by
  intro p hp
  have h : env51396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51395_51396 : H12AffineEnvironment.transform 13 13688 env51395 = env51396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env51395 == env51396) = true)

theorem identity51396 : scanCanonicalize (H12AffineFastState.compose env51396 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51396 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8541,114,5172,2049,1024,8540,12392,8200,64,2,8193,65,10281,5441,4096,2129,9597,32,256,8281,5456,593]

theorem envBound51397 : H12AffineFastState.Bounded env51397 := by
  intro p hp
  have h : env51397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51396_51397 : H12AffineEnvironment.transform 14 8541 env51396 = env51397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51396 == env51397) = true)

theorem identity51397 : scanCanonicalize (H12AffineFastState.compose env51397 (packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound51397 : packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,8192,11292,8541,114,3408,2049,1024,8540,10508,8200,64,2,8193,65,10281,3109,2404,2129,9597,32,256,8281,3124,593]

theorem envBound51398 : H12AffineFastState.Bounded env51398 := by
  intro p hp
  have h : env51398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51397_51398 : H12AffineEnvironment.transform 11 2404 env51397 = env51398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env51397 == env51398) = true)

theorem identity51398 : scanCanonicalize (H12AffineFastState.compose env51398 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound51398 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51399 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2404,8192,10589,8541,114,2065,2049,321,8540,10508,8200,64,2,8193,65,10281,2404,2404,2129,8252,32,256,8281,2421,593]

theorem envBound51399 : H12AffineFastState.Bounded env51399 := by
  intro p hp
  have h : env51399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51398_51399 : H12AffineEnvironment.transform 9 321 env51398 = env51399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env51398 == env51399) = true)

theorem identity51399 : scanCanonicalize (H12AffineFastState.compose env51399 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51399 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env51400 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,8192,10509,8461,34,2065,2049,273,8460,10508,8200,16,2,8193,17,10281,2356,2356,2049,8252,32,256,8201,2341,513]

theorem envBound51400 : H12AffineFastState.Bounded env51400 := by
  intro p hp
  have h : env51400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51399_51400 : H12AffineEnvironment.transform 5 16 env51399 = env51400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51399 == env51400) = true)

theorem identity51400 : scanCanonicalize (H12AffineFastState.compose env51400 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51401 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,40,2341,293,34,2065,2049,273,292,2340,32,16,2,41,17,2049,2356,2356,2049,20,32,256,33,2341,513]

theorem envBound51401 : H12AffineFastState.Bounded env51401 := by
  intro p hp
  have h : env51401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51400_51401 : H12AffineEnvironment.transform 12 40 env51400 = env51401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51400 == env51401) = true)

end H12CloudChart0