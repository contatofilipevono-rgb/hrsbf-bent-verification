import H12CloudChart0Data070

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans17893_17894 : H12AffineEnvironment.transform 9 21 env17893 = env17894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17893 == env17894) = true)

theorem identity17894 : scanCanonicalize (H12AffineFastState.compose env17894 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound17894 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17895 : List Nat := [2,4,8,16,32,17,8,14,512,21,26,32,3,58,0,8,43,48,21,1,48,33,16,2,3,17,26,43,33,49,30,33,14,32,59,513]

theorem envBound17895 : H12AffineFastState.Bounded env17895 := by
  intro p hp
  have h : env17895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17894_17895 : H12AffineEnvironment.transform 10 26 env17894 = env17895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env17894 == env17895) = true)

theorem identity17895 : scanCanonicalize (H12AffineFastState.compose env17895 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound17895 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17896 : List Nat := [2,4,8,16,32,17,8,14,49,21,26,32,3,58,0,8,43,48,21,1,48,33,16,2,3,17,26,43,33,49,30,33,14,32,59,48]

theorem envBound17896 : H12AffineFastState.Bounded env17896 := by
  intro p hp
  have h : env17896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17895_17896 : H12AffineEnvironment.transform 8 49 env17895 = env17896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env17895 == env17896) = true)

theorem identity17896 : scanCanonicalize (H12AffineFastState.compose env17896 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound17896 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17897 : List Nat := [2,4,8,11,32,10,8,14,42,14,1,32,3,33,0,8,43,43,14,1,43,33,11,2,3,10,1,43,33,42,5,33,14,32,32,43]

theorem envBound17897 : H12AffineFastState.Bounded env17897 := by
  intro p hp
  have h : env17897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17896_17897 : H12AffineEnvironment.transform 3 11 env17896 = env17897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env17896 == env17897) = true)

theorem identity17897 : scanCanonicalize (H12AffineFastState.compose env17897 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound17897 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17898 : List Nat := [2,3,8,11,32,10,8,9,42,9,1,32,3,33,0,8,43,43,9,1,43,33,11,2,3,10,1,43,33,42,2,33,9,32,32,43]

theorem envBound17898 : H12AffineFastState.Bounded env17898 := by
  intro p hp
  have h : env17898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17897_17898 : H12AffineEnvironment.transform 1 3 env17897 = env17898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env17897 == env17898) = true)

theorem identity17898 : scanCanonicalize (H12AffineFastState.compose env17898 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17898 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env17899 : List Nat := [2,3,2,1,32,0,2,3,32,3,1,32,3,33,0,2,33,33,3,1,33,33,1,2,3,0,1,33,33,32,2,33,3,32,32,33]

theorem envBound17899 : H12AffineFastState.Bounded env17899 := by
  intro p hp
  have h : env17899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17898_17899 : H12AffineEnvironment.transform 2 2 env17898 = env17899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17898 == env17899) = true)

theorem identity17899 : scanCanonicalize (H12AffineFastState.compose env17899 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound17899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17900 : List Nat := [2,3,2,1,2,0,2,3,2,3,1,2,3,3,0,2,3,3,3,1,3,3,1,2,3,0,1,3,3,2,2,3,3,2,2,3]

theorem envBound17900 : H12AffineFastState.Bounded env17900 := by
  intro p hp
  have h : env17900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17899_17900 : H12AffineEnvironment.transform 4 2 env17899 = env17900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env17899 == env17900) = true)

theorem identity17900 : scanCanonicalize (H12AffineFastState.compose env17900 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound17900 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env17901 : List Nat := [1,0,1,1,1,0,1,0,1,0,1,1,0,0,0,1,0,0,0,1,0,0,1,1,0,0,1,0,0,1,1,0,0,1,1,0]

theorem envBound17901 : H12AffineFastState.Bounded env17901 := by
  intro p hp
  have h : env17901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17900_17901 : H12AffineEnvironment.transform 0 1 env17900 = env17901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env17900 == env17901) = true)

def env17902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,8388608,41310,8193,64,8787060,5392,8392721,8819968,8389956,41340,256,8388657,8434716,8389136]

theorem envBound17902 : H12AffineFastState.Bounded env17902 := by
  intro p hp
  have h : env17902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17884_17902 : H12AffineEnvironment.transform 6 9 env17884 = env17902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17884 == env17902) = true)

theorem identity17902 : scanCanonicalize (H12AffineFastState.compose env17902 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 136529) := by decide +kernel

theorem selectedBound17902 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,136529,41310,8193,64,262437,5392,132416,294993,135189,41340,256,136544,172365,137025]

theorem envBound17903 : H12AffineFastState.Bounded env17903 := by
  intro p hp
  have h : env17903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17902_17903 : H12AffineEnvironment.transform 22 136529 env17902 = env17903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136529 env17902 == env17903) = true)

theorem identity17903 : scanCanonicalize (H12AffineFastState.compose env17903 (packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound17903 : packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env17904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,171109,1024,32769,4160,33,136529,41310,8193,64,171328,5392,132416,138292,135189,41340,256,136544,172365,137025]

theorem envBound17904 : H12AffineFastState.Bounded env17904 := by
  intro p hp
  have h : env17904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17903_17904 : H12AffineEnvironment.transform 17 171109 env17903 = env17904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env17903 == env17904) = true)

theorem identity17904 : scanCanonicalize (H12AffineFastState.compose env17904 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound17904 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env17905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,35109,1024,32769,4160,33,17,41310,8193,64,34816,5392,4096,2420,1365,41340,256,32,46093,513]

theorem envBound17905 : H12AffineFastState.Bounded env17905 := by
  intro p hp
  have h : env17905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17904_17905 : H12AffineEnvironment.transform 16 5440 env17904 = env17905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env17904 == env17905) = true)

theorem identity17905 : scanCanonicalize (H12AffineFastState.compose env17905 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17905 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17906 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4453,32768,8203,4389,35109,101,32769,4160,33,17,41310,8193,64,34816,4469,4096,2420,304,41340,256,32,45160,513]

theorem envBound17906 : H12AffineFastState.Bounded env17906 := by
  intro p hp
  have h : env17906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17905_17906 : H12AffineEnvironment.transform 9 101 env17905 = env17906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17905 == env17906) = true)

theorem identity17906 : scanCanonicalize (H12AffineFastState.compose env17906 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17906 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17907 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,4405,32768,8203,4389,35109,53,32769,4112,33,17,41230,8193,16,34816,4389,4096,2340,304,41260,256,32,45112,513]

theorem envBound17907 : H12AffineFastState.Bounded env17907 := by
  intro p hp
  have h : env17907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17906_17907 : H12AffineEnvironment.transform 5 16 env17906 = env17907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17906 == env17907) = true)

theorem identity17907 : scanCanonicalize (H12AffineFastState.compose env17907 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17907 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17908 : List Nat := [2,4,8,16,32,16,9,256,0,53,2048,4096,8192,4405,32768,8203,4389,35109,53,32769,4112,33,17,41230,8193,16,34816,4389,4096,2340,304,41260,256,32,45112,1]

theorem envBound17908 : H12AffineFastState.Bounded env17908 := by
  intro p hp
  have h : env17908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17907_17908 : H12AffineEnvironment.transform 8 0 env17907 = env17908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17907 == env17908) = true)

theorem identity17908 : scanCanonicalize (H12AffineFastState.compose env17908 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 12328) := by decide +kernel

theorem selectedBound17908 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17909 : List Nat := [2,4,8,16,32,16,9,256,0,53,2048,4096,8192,4405,12328,8203,4389,14605,53,12329,4112,33,17,4390,8193,16,14376,4389,4096,2340,304,4356,256,32,16,1]

theorem envBound17909 : H12AffineFastState.Bounded env17909 := by
  intro p hp
  have h : env17909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17908_17909 : H12AffineEnvironment.transform 14 12328 env17908 = env17909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12328 env17908 == env17909) = true)

theorem identity17909 : scanCanonicalize (H12AffineFastState.compose env17909 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound17909 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env17910 : List Nat := [2,4,8,16,32,16,9,256,0,53,2048,4096,6429,4405,2357,6422,4389,16,53,2356,4112,33,17,4390,6428,16,309,4389,4096,2340,304,4356,256,32,16,1]

theorem envBound17910 : H12AffineFastState.Bounded env17910 := by
  intro p hp
  have h : env17910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17909_17910 : H12AffineEnvironment.transform 12 6429 env17909 = env17910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env17909 == env17910) = true)

theorem identity17910 : scanCanonicalize (H12AffineFastState.compose env17910 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound17910 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17911 : List Nat := [2,4,8,16,32,16,9,256,0,53,2048,2064,269,2341,2357,262,2357,16,53,2356,2048,33,17,2358,268,16,309,2357,2064,2340,304,2324,256,32,16,1]

theorem envBound17911 : H12AffineFastState.Bounded env17911 := by
  intro p hp
  have h : env17911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17910_17911 : H12AffineEnvironment.transform 11 2064 env17910 = env17911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env17910 == env17911) = true)

theorem identity17911 : scanCanonicalize (H12AffineFastState.compose env17911 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound17911 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17912 : List Nat := [2,4,8,16,32,16,9,256,0,53,17,1,269,308,292,262,292,16,53,293,17,33,17,295,268,16,309,292,1,309,304,261,256,32,16,1]

theorem envBound17912 : H12AffineFastState.Bounded env17912 := by
  intro p hp
  have h : env17912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17911_17912 : H12AffineEnvironment.transform 10 17 env17911 = env17912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env17911 == env17912) = true)

theorem identity17912 : scanCanonicalize (H12AffineFastState.compose env17912 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17912 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17913 : List Nat := [2,4,8,0,32,0,9,256,0,37,1,1,269,292,292,262,292,0,37,293,1,33,1,295,268,0,293,292,1,293,288,261,256,32,0,1]

theorem envBound17913 : H12AffineFastState.Bounded env17913 := by
  intro p hp
  have h : env17913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17912_17913 : H12AffineEnvironment.transform 3 0 env17912 = env17913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17912 == env17913) = true)

theorem identity17913 : scanCanonicalize (H12AffineFastState.compose env17913 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17913 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17914 : List Nat := [2,4,8,0,32,0,9,37,0,37,1,1,40,1,1,35,1,0,37,0,1,33,1,2,41,0,0,1,1,0,5,32,37,32,0,1]

theorem envBound17914 : H12AffineFastState.Bounded env17914 := by
  intro p hp
  have h : env17914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17913_17914 : H12AffineEnvironment.transform 7 37 env17913 = env17914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17913 == env17914) = true)

theorem identity17914 : scanCanonicalize (H12AffineFastState.compose env17914 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17915 : List Nat := [2,4,2,0,32,0,3,37,0,37,1,1,34,1,1,35,1,0,37,0,1,33,1,2,35,0,0,1,1,0,5,32,37,32,0,1]

theorem envBound17915 : H12AffineFastState.Bounded env17915 := by
  intro p hp
  have h : env17915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17914_17915 : H12AffineEnvironment.transform 2 2 env17914 = env17915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17914 == env17915) = true)

def env17916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120029,8328,64,12981469,79130,8466458,8830976,8409292,4314199,256,8484155,8492191,8484634]

theorem envBound17916 : H12AffineFastState.Bounded env17916 := by
  intro p hp
  have h : env17916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17800_17916 : H12AffineEnvironment.transform 23 120029 env17800 = env17916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120029 env17800 == env17916) = true)

def env17917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981469,79130,8466458,8820104,8389956,4293087,256,8462515,8492191,8462994]

theorem envBound17917 : H12AffineFastState.Bounded env17917 := by
  intro p hp
  have h : env17917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17916_17917 : H12AffineEnvironment.transform 13 5512 env17916 = env17917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env17916 == env17917) = true)

def env17918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787197,79130,8466458,8820104,8389956,98815,256,8462515,8492191,8462994]

theorem envBound17918 : H12AffineFastState.Bounded env17918 := by
  intro p hp
  have h : env17918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17917_17918 : H12AffineEnvironment.transform 21 32 env17917 = env17918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17917 == env17918) = true)

theorem identity17918 : scanCanonicalize (H12AffineFastState.compose env17918 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17918 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,8388608,98645,8192,64,8787061,79130,8466458,8819968,8389956,98679,256,8462395,8492055,8462874]

theorem envBound17919 : H12AffineFastState.Bounded env17919 := by
  intro p hp
  have h : env17919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17918_17919 : H12AffineEnvironment.transform 6 8 env17918 = env17919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17918 == env17919) = true)

def env17920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,16,98645,8192,64,398437,79130,77834,431376,1364,98679,256,73771,103431,74250]

theorem envBound17920 : H12AffineFastState.Bounded env17920 := by
  intro p hp
  have h : env17920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17919_17920 : H12AffineEnvironment.transform 22 16 env17919 = env17920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17919 == env17920) = true)

theorem identity17920 : scanCanonicalize (H12AffineFastState.compose env17920 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17920 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41310,8192,64,398437,5393,4097,431376,1364,41340,256,32,46092,513]

theorem envBound17921 : H12AffineFastState.Bounded env17921 := by
  intro p hp
  have h : env17921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17920_17921 : H12AffineEnvironment.transform 15 8203 env17920 = env17921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17920 == env17921) = true)

theorem identity17921 : scanCanonicalize (H12AffineFastState.compose env17921 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17921 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,32,16,2,8192,64,398437,5393,4097,406604,1364,32,256,32,5456,513]

theorem envBound17922 : H12AffineFastState.Bounded env17922 := by
  intro p hp
  have h : env17922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17921_17922 : H12AffineEnvironment.transform 14 8540 env17921 = env17922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17921 == env17922) = true)

theorem identity17922 : scanCanonicalize (H12AffineFastState.compose env17922 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound17922 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146793,1024,8541,4160,32,16,2,8192,64,10508,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound17923 : H12AffineFastState.Bounded env17923 := by
  intro p hp
  have h : env17923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17922_17923 : H12AffineEnvironment.transform 17 146793 env17922 = env17923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env17922 == env17923) = true)

theorem identity17923 : scanCanonicalize (H12AffineFastState.compose env17923 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17923 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10361,1024,8541,4160,32,16,2,8192,64,10508,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound17924 : H12AffineFastState.Bounded env17924 := by
  intro p hp
  have h : env17924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17923_17924 : H12AffineEnvironment.transform 16 5392 env17923 = env17924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17923 == env17924) = true)

theorem identity17924 : scanCanonicalize (H12AffineFastState.compose env17924 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17924 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env17925 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,8203,5221,10361,1024,8232,4160,32,16,2,8192,64,10361,5220,4097,2128,1057,32,117,32,5157,513]

theorem envBound17925 : H12AffineFastState.Bounded env17925 := by
  intro p hp
  have h : env17925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17924_17925 : H12AffineEnvironment.transform 7 117 env17924 = env17925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17924 == env17925) = true)

theorem identity17925 : scanCanonicalize (H12AffineFastState.compose env17925 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17925 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17926 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5156,8233,8203,5172,10280,1024,8232,4113,32,16,2,8192,17,10280,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound17926 : H12AffineFastState.Bounded env17926 := by
  intro p hp
  have h : env17926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17925_17926 : H12AffineEnvironment.transform 5 17 env17925 = env17926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17925 == env17926) = true)

theorem identity17926 : scanCanonicalize (H12AffineFastState.compose env17926 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17926 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17927 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8,5156,33,3,5172,2080,1024,32,4113,32,16,2,8,17,2080,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound17927 : H12AffineFastState.Bounded env17927 := by
  intro p hp
  have h : env17927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17926_17927 : H12AffineEnvironment.transform 12 8 env17926 = env17927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17926 == env17927) = true)

theorem identity17927 : scanCanonicalize (H12AffineFastState.compose env17927 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound17927 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17928 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1044,4096,8,5156,33,3,5172,1076,1024,32,4113,32,16,2,8,17,1076,5173,4097,1045,1057,32,36,32,5157,513]

theorem envBound17928 : H12AffineFastState.Bounded env17928 := by
  intro p hp
  have h : env17928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17927_17928 : H12AffineEnvironment.transform 10 1044 env17927 = env17928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env17927 == env17928) = true)

theorem identity17928 : scanCanonicalize (H12AffineFastState.compose env17928 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17928 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17929 : List Nat := [2,4,8,16,32,17,8,36,1,1024,1044,4096,8,5156,33,3,5172,1076,1024,32,4113,32,16,2,8,17,1076,5173,4097,1045,1057,32,36,32,5157,0]

theorem envBound17929 : H12AffineFastState.Bounded env17929 := by
  intro p hp
  have h : env17929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17928_17929 : H12AffineEnvironment.transform 8 1 env17928 = env17929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17928 == env17929) = true)

theorem identity17929 : scanCanonicalize (H12AffineFastState.compose env17929 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17929 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17930 : List Nat := [2,4,8,16,0,17,8,4,1,1024,1044,4096,8,5124,1,3,5140,1044,1024,0,4113,0,16,2,8,17,1044,5141,4097,1045,1025,0,4,0,5125,0]

theorem envBound17930 : H12AffineFastState.Bounded env17930 := by
  intro p hp
  have h : env17930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17929_17930 : H12AffineEnvironment.transform 4 0 env17929 = env17930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17929 == env17930) = true)

theorem identity17930 : scanCanonicalize (H12AffineFastState.compose env17930 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound17930 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17931 : List Nat := [2,4,8,16,0,17,8,4,1,1024,1044,1028,8,0,1,3,16,1044,1024,0,1045,0,16,2,8,17,1044,17,1029,1045,1025,0,4,0,1,0]

theorem envBound17931 : H12AffineFastState.Bounded env17931 := by
  intro p hp
  have h : env17931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17930_17931 : H12AffineEnvironment.transform 11 1028 env17930 = env17931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env17930 == env17931) = true)

theorem identity17931 : scanCanonicalize (H12AffineFastState.compose env17931 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17932 : List Nat := [2,4,8,1,0,0,8,4,1,1024,1029,1028,8,0,1,3,1,1029,1024,0,1028,0,1,2,8,0,1029,0,1029,1028,1025,0,4,0,1,0]

theorem envBound17932 : H12AffineFastState.Bounded env17932 := by
  intro p hp
  have h : env17932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17931_17932 : H12AffineEnvironment.transform 3 1 env17931 = env17932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17931 == env17932) = true)

theorem identity17932 : scanCanonicalize (H12AffineFastState.compose env17932 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound17932 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17933 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,8,0,1,3,1,1,4,0,0,0,1,2,8,0,1,0,1,0,5,0,4,0,1,0]

theorem envBound17933 : H12AffineFastState.Bounded env17933 := by
  intro p hp
  have h : env17933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17932_17933 : H12AffineEnvironment.transform 9 4 env17932 = env17933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env17932 == env17933) = true)

theorem identity17933 : scanCanonicalize (H12AffineFastState.compose env17933 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17934 : List Nat := [2,4,2,1,0,0,2,4,1,4,1,0,2,0,1,3,1,1,4,0,0,0,1,2,2,0,1,0,1,0,5,0,4,0,1,0]

theorem envBound17934 : H12AffineFastState.Bounded env17934 := by
  intro p hp
  have h : env17934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17933_17934 : H12AffineEnvironment.transform 2 2 env17933 = env17934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17933 == env17934) = true)

def env17935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,17,98645,8192,64,398436,79130,77835,431377,1365,98679,256,73770,103430,74251]

theorem envBound17935 : H12AffineFastState.Bounded env17935 := by
  intro p hp
  have h : env17935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17919_17935 : H12AffineEnvironment.transform 22 17 env17919 = env17935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17919 == env17935) = true)

theorem identity17935 : scanCanonicalize (H12AffineFastState.compose env17935 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound17935 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,77899,32,17,98645,8192,64,203846,79130,77835,236851,1365,98679,256,73770,103430,74251]

theorem envBound17936 : H12AffineFastState.Bounded env17936 := by
  intro p hp
  have h : env17936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17935_17936 : H12AffineEnvironment.transform 17 67618 env17935 = env17936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env17935 == env17936) = true)

theorem identity17936 : scanCanonicalize (H12AffineFastState.compose env17936 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound17936 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env17937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103494,67618,1024,32769,77899,32,17,98645,8192,64,34816,79130,77835,2421,1365,98679,256,73770,103430,74251]

theorem envBound17937 : H12AffineFastState.Bounded env17937 := by
  intro p hp
  have h : env17937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17936_17937 : H12AffineEnvironment.transform 16 103494 env17936 = env17937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env17936 == env17937) = true)

theorem identity17937 : scanCanonicalize (H12AffineFastState.compose env17937 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17937 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,35189,1024,32769,45340,32,17,2,8192,64,34816,46157,45404,2421,1365,32,256,41341,5457,41820]

theorem envBound17938 : H12AffineFastState.Bounded env17938 := by
  intro p hp
  have h : env17938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17937_17938 : H12AffineEnvironment.transform 15 33111 env17937 = env17938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17937 == env17938) = true)

theorem identity17938 : scanCanonicalize (H12AffineFastState.compose env17938 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound17938 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,292,115,5393,2129,1024,293,12344,32,17,2,8192,64,2340,13673,12408,2421,1365,32,256,8281,5457,8824]

theorem envBound17939 : H12AffineFastState.Bounded env17939 := by
  intro p hp
  have h : env17939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17938_17939 : H12AffineEnvironment.transform 14 292 env17938 = env17939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env17938 == env17939) = true)

theorem identity17939 : scanCanonicalize (H12AffineFastState.compose env17939 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17939 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,292,115,5393,2129,1024,293,4452,32,17,2,348,64,2340,5173,4388,2421,1365,32,256,261,5457,804]

theorem envBound17940 : H12AffineFastState.Bounded env17940 := by
  intro p hp
  have h : env17940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17939_17940 : H12AffineEnvironment.transform 12 348 env17939 = env17940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17939 == env17940) = true)

theorem identity17940 : scanCanonicalize (H12AffineFastState.compose env17940 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17940 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17941 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,292,34,5393,2048,1024,293,4405,32,17,2,269,17,2340,5173,4388,2340,1284,32,256,261,5376,804]

theorem envBound17941 : H12AffineFastState.Bounded env17941 := by
  intro p hp
  have h : env17941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17940_17941 : H12AffineEnvironment.transform 5 17 env17940 = env17941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17940 == env17941) = true)

theorem identity17941 : scanCanonicalize (H12AffineFastState.compose env17941 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound17941 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env17942 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3328,269,2048,292,34,2065,2048,1024,293,3125,32,17,2,269,17,2340,2357,3108,2340,1284,32,256,261,2048,804]

theorem envBound17942 : H12AffineFastState.Bounded env17942 := by
  intro p hp
  have h : env17942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17941_17942 : H12AffineEnvironment.transform 11 3328 env17941 = env17942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env17941 == env17942) = true)

def env17943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787196,79130,8466458,8820104,8389956,98814,256,8462515,8492191,8462994]

theorem envBound17943 : H12AffineFastState.Bounded env17943 := by
  intro p hp
  have h : env17943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17917_17943 : H12AffineEnvironment.transform 21 33 env17917 = env17943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env17917 == env17943) = true)

theorem identity17943 : scanCanonicalize (H12AffineFastState.compose env17943 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound17943 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,152,98645,8328,64,398436,79130,77954,431376,1500,98814,256,73771,103431,74250]

theorem envBound17944 : H12AffineFastState.Bounded env17944 := by
  intro p hp
  have h : env17944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17943_17944 : H12AffineEnvironment.transform 22 152 env17943 = env17944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env17943 == env17944) = true)

def env17945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,33,16,98645,8192,64,398436,79130,77834,431376,1364,98678,256,73771,103431,74250]

theorem envBound17945 : H12AffineFastState.Bounded env17945 := by
  intro p hp
  have h : env17945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17944_17945 : H12AffineEnvironment.transform 6 8 env17944 = env17945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17944 == env17945) = true)

theorem identity17945 : scanCanonicalize (H12AffineFastState.compose env17945 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17945 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41310,8192,64,398436,5393,4097,431376,1364,41341,256,32,46092,513]

theorem envBound17946 : H12AffineFastState.Bounded env17946 := by
  intro p hp
  have h : env17946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17945_17946 : H12AffineEnvironment.transform 15 8203 env17945 = env17946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17945 == env17946) = true)

theorem identity17946 : scanCanonicalize (H12AffineFastState.compose env17946 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17946 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,33,16,2,8192,64,398436,5393,4097,406604,1364,33,256,32,5456,513]

theorem envBound17947 : H12AffineFastState.Bounded env17947 := by
  intro p hp
  have h : env17947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17946_17947 : H12AffineEnvironment.transform 14 8540 env17946 = env17947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17946 == env17947) = true)

theorem identity17947 : scanCanonicalize (H12AffineFastState.compose env17947 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound17947 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146793,1024,8541,4160,33,16,2,8192,64,10509,5393,4097,2341,1364,33,256,32,5456,513]

theorem envBound17948 : H12AffineFastState.Bounded env17948 := by
  intro p hp
  have h : env17948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17947_17948 : H12AffineEnvironment.transform 17 146793 env17947 = env17948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env17947 == env17948) = true)

theorem identity17948 : scanCanonicalize (H12AffineFastState.compose env17948 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17948 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,131072,138292,1024,0,4160,33,16,2,349,64,2128,5393,4097,2341,1364,33,256,32,5456,513]

theorem envBound17949 : H12AffineFastState.Bounded env17949 := by
  intro p hp
  have h : env17949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17948_17949 : H12AffineEnvironment.transform 12 349 env17948 = env17949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17948 == env17949) = true)

def env17950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,17,98645,8193,64,398436,79130,77835,431376,1365,98679,256,73771,103431,74250]

theorem envBound17950 : H12AffineFastState.Bounded env17950 := by
  intro p hp
  have h : env17950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17944_17950 : H12AffineEnvironment.transform 6 9 env17944 = env17950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17944 == env17950) = true)

theorem identity17950 : scanCanonicalize (H12AffineFastState.compose env17950 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound17950 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,77898,33,17,98645,8193,64,245018,79130,77835,212078,1365,98679,256,73771,103431,74250]

theorem envBound17951 : H12AffineFastState.Bounded env17951 := by
  intro p hp
  have h : env17951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17950_17951 : H12AffineEnvironment.transform 17 108926 env17950 = env17951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env17950 == env17951) = true)

theorem identity17951 : scanCanonicalize (H12AffineFastState.compose env17951 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17951 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env17952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1024,32769,45340,33,17,3,8193,64,146508,46156,45405,179512,1365,33,256,41341,5457,41820]

theorem envBound17952 : H12AffineFastState.Bounded env17952 := by
  intro p hp
  have h : env17952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17951_17952 : H12AffineEnvironment.transform 15 33110 env17951 = env17952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17951 == env17952) = true)

theorem identity17952 : scanCanonicalize (H12AffineFastState.compose env17952 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound17952 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env17953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,113,295,131072,10280,1024,112,12653,33,17,3,8193,64,146508,13373,12588,146761,1365,33,256,8460,5457,9005]

theorem envBound17953 : H12AffineFastState.Bounded env17953 := by
  intro p hp
  have h : env17953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17952_17953 : H12AffineEnvironment.transform 14 113 env17952 = env17953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env17952 == env17953) = true)

theorem identity17953 : scanCanonicalize (H12AffineFastState.compose env17953 (packedSelected [0,4,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound17953 : packedSelected [0,4,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,113,295,13624,10280,1024,112,12653,33,17,3,8193,64,2420,13373,12588,2161,1365,33,256,8460,5457,9005]

theorem envBound17954 : H12AffineFastState.Bounded env17954 := by
  intro p hp
  have h : env17954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17953_17954 : H12AffineEnvironment.transform 16 13624 env17953 = env17954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env17953 == env17954) = true)

theorem identity17954 : scanCanonicalize (H12AffineFastState.compose env17954 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound17954 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env17955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,113,295,5140,2308,1024,112,4161,33,17,3,301,64,2420,5393,4096,2161,1365,33,256,32,5457,513]

theorem envBound17955 : H12AffineFastState.Bounded env17955 := by
  intro p hp
  have h : env17955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17954_17955 : H12AffineEnvironment.transform 12 300 env17954 = env17955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env17954 == env17955) = true)

theorem identity17955 : scanCanonicalize (H12AffineFastState.compose env17955 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17955 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17956 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,41,5124,113,34,5140,2049,1024,112,4161,33,17,3,40,64,2161,5140,4096,2161,1104,33,5,32,5204,513]

theorem envBound17956 : H12AffineFastState.Bounded env17956 := by
  intro p hp
  have h : env17956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17955_17956 : H12AffineEnvironment.transform 7 5 env17955 = env17956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17955 == env17956) = true)

theorem identity17956 : scanCanonicalize (H12AffineFastState.compose env17956 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3140) := by decide +kernel

theorem selectedBound17956 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17957 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,3140,41,2112,113,34,2128,2049,1024,112,3077,33,17,3,40,64,2161,2128,3140,2161,1104,33,5,32,2064,513]

theorem envBound17957 : H12AffineFastState.Bounded env17957 := by
  intro p hp
  have h : env17957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17956_17957 : H12AffineEnvironment.transform 11 3140 env17956 = env17957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3140 env17956 == env17957) = true)

def env17958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981469,79130,8466458,8820105,8389957,4293086,256,8462514,8492191,8462995]

theorem envBound17958 : H12AffineFastState.Bounded env17958 := by
  intro p hp
  have h : env17958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17916_17958 : H12AffineEnvironment.transform 13 5513 env17916 = env17958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17916 == env17958) = true)

def env17959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787197,79130,8466458,8820105,8389957,98814,256,8462514,8492191,8462995]

theorem envBound17959 : H12AffineFastState.Bounded env17959 := by
  intro p hp
  have h : env17959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17958_17959 : H12AffineEnvironment.transform 21 32 env17958 = env17959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17958 == env17959) = true)

theorem identity17959 : scanCanonicalize (H12AffineFastState.compose env17959 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,262144,1024,8541,78018,32,8388608,73736,8328,64,8787197,79130,8466458,8795349,8389957,73890,256,8462514,8467907,8462995]

theorem envBound17960 : H12AffineFastState.Bounded env17960 := by
  intro p hp
  have h : env17960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17959_17960 : H12AffineEnvironment.transform 14 8540 env17959 = env17960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17959 == env17960) = true)

def env17961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,78018,32,8388608,73736,8328,64,8535133,79130,8466458,8526965,8389957,73890,256,8462514,8467907,8462995]

theorem envBound17961 : H12AffineFastState.Bounded env17961 := by
  intro p hp
  have h : env17961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17960_17961 : H12AffineEnvironment.transform 17 10400 env17960 = env17961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17960 == env17961) = true)

theorem identity17961 : scanCanonicalize (H12AffineFastState.compose env17961 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound17961 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10400,1024,8541,78018,32,73874,73736,8328,64,203983,79130,4232,212199,75223,73890,256,32,5457,513]

theorem envBound17962 : H12AffineFastState.Bounded env17962 := by
  intro p hp
  have h : env17962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17961_17962 : H12AffineEnvironment.transform 22 73874 env17961 = env17962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env17961 == env17962) = true)

theorem identity17962 : scanCanonicalize (H12AffineFastState.compose env17962 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound17962 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env17963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,79131,10400,1024,8541,78018,32,73874,73736,8328,64,10708,79130,4232,2556,75223,73890,256,32,5457,513]

theorem envBound17963 : H12AffineFastState.Bounded env17963 := by
  intro p hp
  have h : env17963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17962_17963 : H12AffineEnvironment.transform 16 79131 env17962 = env17963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env17962 == env17963) = true)

theorem identity17963 : scanCanonicalize (H12AffineFastState.compose env17963 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17963 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env17964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8203,5392,10400,1024,8541,4297,32,153,3,8328,64,10708,5393,4232,2556,1500,169,256,32,5457,513]

theorem envBound17964 : H12AffineFastState.Bounded env17964 := by
  intro p hp
  have h : env17964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17963_17964 : H12AffineEnvironment.transform 15 8203 env17963 = env17964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17963 == env17964) = true)

theorem identity17964 : scanCanonicalize (H12AffineFastState.compose env17964 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17964 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10281,1024,8541,4160,32,16,3,8193,64,10589,5393,4097,2421,1365,32,256,32,5457,513]

theorem envBound17965 : H12AffineFastState.Bounded env17965 := by
  intro p hp
  have h : env17965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17964_17965 : H12AffineEnvironment.transform 6 9 env17964 = env17965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17964 == env17965) = true)

theorem identity17965 : scanCanonicalize (H12AffineFastState.compose env17965 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17965 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17966 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5392,10281,1024,8460,4113,32,16,3,8193,17,10508,5393,4097,2340,1284,32,256,32,5376,513]

theorem envBound17966 : H12AffineFastState.Bounded env17966 := by
  intro p hp
  have h : env17966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17965_17966 : H12AffineEnvironment.transform 5 17 env17965 = env17966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17965 == env17966) = true)

theorem identity17966 : scanCanonicalize (H12AffineFastState.compose env17966 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound17966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17967 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1304,5376,1045,1299,5392,3377,1024,1044,4113,32,16,3,1305,17,3092,5393,4097,2340,1284,32,256,32,5376,513]

theorem envBound17967 : H12AffineFastState.Bounded env17967 := by
  intro p hp
  have h : env17967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17966_17967 : H12AffineEnvironment.transform 12 1304 env17966 = env17967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env17966 == env17967) = true)

theorem identity17967 : scanCanonicalize (H12AffineFastState.compose env17967 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17967 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17968 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,300,4404,33,295,4388,2309,52,32,4113,32,16,3,301,17,2080,4389,4097,2340,304,32,256,32,4404,513]

theorem envBound17968 : H12AffineFastState.Bounded env17968 := by
  intro p hp
  have h : env17968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17967_17968 : H12AffineEnvironment.transform 9 52 env17967 = env17968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17967 == env17968) = true)

theorem identity17968 : scanCanonicalize (H12AffineFastState.compose env17968 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound17968 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17969 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2325,300,2081,33,295,2097,2309,52,32,2308,32,16,3,301,17,2080,2096,2324,2340,304,32,256,32,2081,513]

theorem envBound17969 : H12AffineFastState.Bounded env17969 := by
  intro p hp
  have h : env17969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17968_17969 : H12AffineEnvironment.transform 11 2325 env17968 = env17969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env17968 == env17969) = true)

theorem identity17969 : scanCanonicalize (H12AffineFastState.compose env17969 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17969 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env17970 : List Nat := [2,4,8,16,32,17,9,256,277,52,2048,2325,300,2081,33,295,2097,2309,52,32,2308,32,16,3,301,17,2080,2096,2324,2340,304,32,256,32,2081,276]

theorem envBound17970 : H12AffineFastState.Bounded env17970 := by
  intro p hp
  have h : env17970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17969_17970 : H12AffineEnvironment.transform 8 277 env17969 = env17970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17969 == env17970) = true)

theorem identity17970 : scanCanonicalize (H12AffineFastState.compose env17970 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17970 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env17971 : List Nat := [2,4,8,16,32,17,9,36,49,52,2048,2097,8,2081,33,3,2097,2081,52,32,2080,32,16,3,9,17,2080,2096,2096,2048,20,32,36,32,2081,48]

theorem envBound17971 : H12AffineFastState.Bounded env17971 := by
  intro p hp
  have h : env17971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17970_17971 : H12AffineEnvironment.transform 7 36 env17970 = env17971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17970 == env17971) = true)

theorem identity17971 : scanCanonicalize (H12AffineFastState.compose env17971 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound17971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17972 : List Nat := [2,4,8,16,32,17,9,36,49,52,49,0,8,16,33,3,0,16,52,32,17,32,16,3,9,17,17,1,1,49,20,32,36,32,16,48]

theorem envBound17972 : H12AffineFastState.Bounded env17972 := by
  intro p hp
  have h : env17972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17971_17972 : H12AffineEnvironment.transform 10 49 env17971 = env17972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env17971 == env17972) = true)

theorem identity17972 : scanCanonicalize (H12AffineFastState.compose env17972 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17972 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17973 : List Nat := [2,4,8,16,17,17,9,21,0,5,0,0,8,16,16,3,0,16,5,17,17,17,16,3,9,17,17,1,1,0,20,17,21,17,16,1]

theorem envBound17973 : H12AffineFastState.Bounded env17973 := by
  intro p hp
  have h : env17973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17972_17973 : H12AffineEnvironment.transform 4 17 env17972 = env17973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17972 == env17973) = true)

theorem identity17973 : scanCanonicalize (H12AffineFastState.compose env17973 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17973 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17974 : List Nat := [2,4,8,0,1,1,9,5,0,5,0,0,8,0,0,3,0,0,5,1,1,1,0,3,9,1,1,1,1,0,4,1,5,1,0,1]

theorem envBound17974 : H12AffineFastState.Bounded env17974 := by
  intro p hp
  have h : env17974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17973_17974 : H12AffineEnvironment.transform 3 0 env17973 = env17974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17973 == env17974) = true)

def env17975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,10401,1024,8541,78018,32,8388608,73736,8328,64,8535132,79130,8466458,8526964,8389957,73890,256,8462514,8467907,8462995]

theorem envBound17975 : H12AffineFastState.Bounded env17975 := by
  intro p hp
  have h : env17975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17960_17975 : H12AffineEnvironment.transform 17 10401 env17960 = env17975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17960 == env17975) = true)

theorem identity17975 : scanCanonicalize (H12AffineFastState.compose env17975 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17975 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,131072,10401,1024,8541,4160,32,8388608,138,8328,64,8535132,5528,8392856,8526964,8389957,32,256,8388656,8394049,8389137]

theorem envBound17976 : H12AffineFastState.Bounded env17976 := by
  intro p hp
  have h : env17976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17975_17976 : H12AffineEnvironment.transform 15 8322 env17975 = env17976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17975 == env17976) = true)

theorem identity17976 : scanCanonicalize (H12AffineFastState.compose env17976 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17976 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,5392,10401,1024,8541,4160,32,8388608,138,8328,64,8399180,5528,8392856,8391012,8389957,32,256,8388656,8394049,8389137]

theorem envBound17977 : H12AffineFastState.Bounded env17977 := by
  intro p hp
  have h : env17977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17976_17977 : H12AffineEnvironment.transform 16 5392 env17976 = env17977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17976 == env17977) = true)

theorem identity17977 : scanCanonicalize (H12AffineFastState.compose env17977 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 8597) := by decide +kernel

theorem selectedBound17977 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env17978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,5392,10401,1024,8541,4160,32,8597,138,8328,64,2265,5528,12557,10481,9424,32,256,8613,13524,9092]

theorem envBound17978 : H12AffineFastState.Bounded env17978 := by
  intro p hp
  have h : env17978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17977_17978 : H12AffineEnvironment.transform 22 8597 env17977 = env17978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8597 env17977 == env17978) = true)

theorem identity17978 : scanCanonicalize (H12AffineFastState.compose env17978 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17978 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env17979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,398,5392,2477,1024,81,4160,32,153,138,388,64,2265,5528,4097,2557,1500,32,256,169,5592,648]

theorem envBound17979 : H12AffineFastState.Bounded env17979 := by
  intro p hp
  have h : env17979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17978_17979 : H12AffineEnvironment.transform 12 268 env17978 = env17979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17978 == env17979) = true)

theorem identity17979 : scanCanonicalize (H12AffineFastState.compose env17979 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17979 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env17980 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,268,4540,80,398,4389,2477,53,81,4160,32,153,138,388,64,2265,4525,4097,2557,489,32,256,169,4589,648]

theorem envBound17980 : H12AffineFastState.Bounded env17980 := by
  intro p hp
  have h : env17980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17979_17980 : H12AffineEnvironment.transform 9 53 env17979 = env17980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17979 == env17980) = true)

theorem identity17980 : scanCanonicalize (H12AffineFastState.compose env17980 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound17980 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env17981 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,2356,268,2184,80,398,2065,2477,53,81,2420,32,153,138,388,64,2265,2201,2357,2557,489,32,256,169,2265,648]

theorem envBound17981 : H12AffineFastState.Bounded env17981 := by
  intro p hp
  have h : env17981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17980_17981 : H12AffineEnvironment.transform 11 2356 env17980 = env17981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env17980 == env17981) = true)

theorem identity17981 : scanCanonicalize (H12AffineFastState.compose env17981 (packedSelected [0,2,6,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17981 : packedSelected [0,2,6,7,14] rootPS < 2^1333 := by decide +kernel

def env17982 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,268,2049,80,263,2065,2340,53,81,2420,32,16,3,269,64,2128,2064,2357,2420,352,32,256,32,2128,513]

theorem envBound17982 : H12AffineFastState.Bounded env17982 := by
  intro p hp
  have h : env17982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17981_17982 : H12AffineEnvironment.transform 6 9 env17981 = env17982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17981 == env17982) = true)

def env17983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787196,79130,8466458,8820105,8389957,98815,256,8462514,8492191,8462995]

theorem envBound17983 : H12AffineFastState.Bounded env17983 := by
  intro p hp
  have h : env17983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17958_17983 : H12AffineEnvironment.transform 21 33 env17958 = env17983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env17958 == env17983) = true)

theorem identity17983 : scanCanonicalize (H12AffineFastState.compose env17983 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound17983 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,41292,98644,8328,64,439728,79130,102742,406725,41993,98815,256,98814,79315,99295]

theorem envBound17984 : H12AffineFastState.Bounded env17984 := by
  intro p hp
  have h : env17984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17983_17984 : H12AffineEnvironment.transform 22 41292 env17983 = env17984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env17983 == env17984) = true)

theorem identity17984 : scanCanonicalize (H12AffineFastState.compose env17984 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound17984 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env17985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,108926,1024,32769,78018,33,41292,98644,8328,64,203982,79130,102742,236987,41993,98815,256,98814,79315,99295]

theorem envBound17985 : H12AffineFastState.Bounded env17985 := by
  intro p hp
  have h : env17985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17984_17985 : H12AffineEnvironment.transform 17 108926 env17984 = env17985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env17984 == env17985) = true)

def env17986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,67618,1024,8541,78018,33,16,73736,8328,64,203982,79130,77834,212199,1365,73891,256,73890,79315,74371]

theorem envBound17986 : H12AffineFastState.Bounded env17986 := by
  intro p hp
  have h : env17986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17985_17986 : H12AffineEnvironment.transform 14 8540 env17985 = env17986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17985 == env17986) = true)

theorem identity17986 : scanCanonicalize (H12AffineFastState.compose env17986 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17986 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,131072,10400,1024,8541,4160,33,16,138,8328,64,146508,5528,4232,138341,1365,33,256,32,5457,513]

theorem envBound17987 : H12AffineFastState.Bounded env17987 := by
  intro p hp
  have h : env17987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17986_17987 : H12AffineEnvironment.transform 15 8322 env17986 = env17987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17986 == env17987) = true)

theorem identity17987 : scanCanonicalize (H12AffineFastState.compose env17987 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17987 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env17988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,8322,5393,10400,1024,8541,4160,33,16,138,8328,64,10589,5528,4232,2420,1365,33,256,32,5457,513]

theorem envBound17988 : H12AffineFastState.Bounded env17988 := by
  intro p hp
  have h : env17988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17987_17988 : H12AffineEnvironment.transform 16 5393 env17987 = env17988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17987 == env17988) = true)

theorem identity17988 : scanCanonicalize (H12AffineFastState.compose env17988 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound17988 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,342,5393,2420,1024,137,4160,33,16,138,348,64,2185,5528,4232,2420,1365,33,256,32,5457,513]

theorem envBound17989 : H12AffineFastState.Bounded env17989 := by
  intro p hp
  have h : env17989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17988_17989 : H12AffineEnvironment.transform 12 468 env17988 = env17989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env17988 == env17989) = true)

theorem identity17989 : scanCanonicalize (H12AffineFastState.compose env17989 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17989 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1024,0,4160,33,16,3,348,64,2048,5393,4097,2420,1365,33,256,32,5457,513]

theorem envBound17990 : H12AffineFastState.Bounded env17990 := by
  intro p hp
  have h : env17990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17989_17990 : H12AffineEnvironment.transform 6 9 env17989 = env17990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17989 == env17990) = true)

theorem identity17990 : scanCanonicalize (H12AffineFastState.compose env17990 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound17990 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5376,1,342,5393,1307,1024,0,4160,33,16,3,348,64,1135,5393,4097,1307,1365,33,256,32,5457,513]

theorem envBound17991 : H12AffineFastState.Bounded env17991 := by
  intro p hp
  have h : env17991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17990_17991 : H12AffineEnvironment.transform 10 1135 env17990 = env17991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env17990 == env17991) = true)

theorem identity17991 : scanCanonicalize (H12AffineFastState.compose env17991 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17991 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17992 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,4096,269,5376,1,262,5393,1307,1024,0,4112,33,16,3,268,16,1087,5393,4097,1307,1285,33,256,32,5377,513]

theorem envBound17992 : H12AffineFastState.Bounded env17992 := by
  intro p hp
  have h : env17992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17991_17992 : H12AffineEnvironment.transform 5 16 env17991 = env17992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17991 == env17992) = true)

theorem identity17992 : scanCanonicalize (H12AffineFastState.compose env17992 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound17992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17993 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,1,269,1281,1,262,1296,1307,1024,0,17,33,16,3,268,16,1087,1296,0,1307,1285,33,256,32,1280,513]

theorem envBound17993 : H12AffineFastState.Bounded env17993 := by
  intro p hp
  have h : env17993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17992_17993 : H12AffineEnvironment.transform 11 1 env17992 = env17993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env17992 == env17993) = true)

theorem identity17993 : scanCanonicalize (H12AffineFastState.compose env17993 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17994 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1087,1,8,1028,1,3,1045,1054,1024,0,17,33,16,3,9,16,1087,1045,0,1054,1024,33,5,32,1029,513]

theorem envBound17994 : H12AffineFastState.Bounded env17994 := by
  intro p hp
  have h : env17994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17993_17994 : H12AffineEnvironment.transform 7 5 env17993 = env17994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17993 == env17994) = true)

theorem identity17994 : scanCanonicalize (H12AffineFastState.compose env17994 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17994 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17995 : List Nat := [2,4,8,16,32,16,9,5,512,52,11,1,8,48,1,3,33,42,52,0,17,33,16,3,9,16,11,33,0,42,52,33,5,32,49,513]

theorem envBound17995 : H12AffineFastState.Bounded env17995 := by
  intro p hp
  have h : env17995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17994_17995 : H12AffineEnvironment.transform 9 52 env17994 = env17995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17994 == env17995) = true)

theorem identity17995 : scanCanonicalize (H12AffineFastState.compose env17995 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound17995 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17996 : List Nat := [2,4,8,16,7,16,9,5,512,19,11,1,8,23,1,3,6,13,19,0,17,6,16,3,9,16,11,6,0,13,19,6,5,7,22,513]

theorem envBound17996 : H12AffineFastState.Bounded env17996 := by
  intro p hp
  have h : env17996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17995_17996 : H12AffineEnvironment.transform 4 7 env17995 = env17996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env17995 == env17996) = true)

theorem identity17996 : scanCanonicalize (H12AffineFastState.compose env17996 (packedSelected [0,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound17996 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env17997 : List Nat := [2,2,8,16,1,16,9,3,512,19,11,1,8,17,1,3,0,11,19,0,17,0,16,3,9,16,11,0,0,11,19,0,3,1,16,513]

theorem envBound17997 : H12AffineFastState.Bounded env17997 := by
  intro p hp
  have h : env17997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17996_17997 : H12AffineEnvironment.transform 1 2 env17996 = env17997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env17996 == env17997) = true)

theorem identity17997 : scanCanonicalize (H12AffineFastState.compose env17997 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound17997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17998 : List Nat := [2,2,8,16,1,16,9,3,9,19,11,1,8,17,1,3,0,11,19,0,17,0,16,3,9,16,11,0,0,11,19,0,3,1,16,8]

theorem envBound17998 : H12AffineFastState.Bounded env17998 := by
  intro p hp
  have h : env17998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17997_17998 : H12AffineEnvironment.transform 8 9 env17997 = env17998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env17997 == env17998) = true)

def env17999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,67619,1024,8540,78018,33,17,73737,8328,64,203982,79130,77835,212198,1364,73890,256,73891,79315,74370]

theorem envBound17999 : H12AffineFastState.Bounded env17999 := by
  intro p hp
  have h : env17999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17985_17999 : H12AffineEnvironment.transform 14 8541 env17985 = env17999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17985 == env17999) = true)

theorem identity17999 : scanCanonicalize (H12AffineFastState.compose env17999 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17999 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,67619,1024,8540,77898,33,17,73737,8192,64,203846,79130,77835,212078,1364,73770,256,73771,79195,74250]

theorem envBound18000 : H12AffineFastState.Bounded env18000 := by
  intro p hp
  have h : env18000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17999_18000 : H12AffineEnvironment.transform 6 8 env17999 = env18000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17999 == env18000) = true)

theorem identity18000 : scanCanonicalize (H12AffineFastState.compose env18000 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound18000 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env18001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,262,131072,2341,1024,8540,12620,33,17,8463,8192,64,138560,13340,12557,146792,1364,8492,256,8493,13405,8972]

theorem envBound18001 : H12AffineFastState.Bounded env18001 := by
  intro p hp
  have h : env18001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18000_18001 : H12AffineEnvironment.transform 15 262 env18000 = env18001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env18000 == env18001) = true)

theorem identity18001 : scanCanonicalize (H12AffineFastState.compose env18001 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18001 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18002 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8541,262,131072,2341,273,8540,12620,33,17,8463,8192,64,137297,12557,12557,145529,69,8492,256,8493,12620,8972]

theorem envBound18002 : H12AffineFastState.Bounded env18002 := by
  intro p hp
  have h : env18002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18001_18002 : H12AffineEnvironment.transform 9 273 env18001 = env18002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18001 == env18002) = true)

theorem identity18002 : scanCanonicalize (H12AffineFastState.compose env18002 (packedSelected [0,1,2,8,9,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound18002 : packedSelected [0,1,2,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18003 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8541,262,4096,2341,273,8540,12620,33,17,8463,8192,64,2129,12557,12557,10361,69,8492,256,8493,12620,8972]

theorem envBound18003 : H12AffineFastState.Bounded env18003 := by
  intro p hp
  have h : env18003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18002_18003 : H12AffineEnvironment.transform 16 4096 env18002 = env18003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env18002 == env18003) = true)

theorem identity18003 : scanCanonicalize (H12AffineFastState.compose env18003 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18003 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env18004 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,81,262,4096,2341,273,80,4160,33,17,3,268,64,2129,4097,4097,2421,69,32,256,33,4160,512]

theorem envBound18004 : H12AffineFastState.Bounded env18004 := by
  intro p hp
  have h : env18004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18003_18004 : H12AffineEnvironment.transform 12 268 env18003 = env18004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18003 == env18004) = true)

theorem identity18004 : scanCanonicalize (H12AffineFastState.compose env18004 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound18004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18005 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,325,268,341,81,262,325,2341,273,80,261,33,17,3,268,64,2129,324,324,2421,69,32,256,33,261,512]

theorem envBound18005 : H12AffineFastState.Bounded env18005 := by
  intro p hp
  have h : env18005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18004_18005 : H12AffineEnvironment.transform 11 325 env18004 = env18005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env18004 == env18005) = true)

theorem identity18005 : scanCanonicalize (H12AffineFastState.compose env18005 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound18005 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env18006 : List Nat := [2,4,8,16,32,64,8,84,512,69,2048,17,88,1,81,82,17,2161,69,80,81,33,17,3,88,64,2129,16,16,2081,69,32,84,33,81,512]

theorem envBound18006 : H12AffineFastState.Bounded env18006 := by
  intro p hp
  have h : env18006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18005_18006 : H12AffineEnvironment.transform 7 84 env18005 = env18006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env18005 == env18006) = true)

theorem identity18006 : scanCanonicalize (H12AffineFastState.compose env18006 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18006 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18007 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,17,88,1,81,82,17,2129,69,80,81,1,17,3,88,64,2129,16,16,2049,69,0,84,1,81,512]

theorem envBound18007 : H12AffineFastState.Bounded env18007 := by
  intro p hp
  have h : env18007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18006_18007 : H12AffineEnvironment.transform 4 0 env18006 = env18007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18006 == env18007) = true)

theorem identity18007 : scanCanonicalize (H12AffineFastState.compose env18007 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18008 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,17,9,1,0,3,17,2048,20,1,0,1,17,3,9,17,2048,16,16,2049,20,0,5,1,0,512]

theorem envBound18008 : H12AffineFastState.Bounded env18008 := by
  intro p hp
  have h : env18008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18007_18008 : H12AffineEnvironment.transform 5 17 env18007 = env18008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18007 == env18008) = true)

theorem identity18008 : scanCanonicalize (H12AffineFastState.compose env18008 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 526) := by decide +kernel

theorem selectedBound18008 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18009 : List Nat := [2,4,8,16,0,17,8,5,512,20,526,17,9,1,0,3,17,526,20,1,0,1,17,3,9,17,526,16,16,527,20,0,5,1,0,512]

theorem envBound18009 : H12AffineFastState.Bounded env18009 := by
  intro p hp
  have h : env18009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18008_18009 : H12AffineEnvironment.transform 10 526 env18008 = env18009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 526 env18008 == env18009) = true)

theorem identity18009 : scanCanonicalize (H12AffineFastState.compose env18009 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound18009 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18010 : List Nat := [2,4,8,16,0,17,8,5,15,20,1,17,9,1,0,3,17,1,20,1,0,1,17,3,9,17,1,16,16,0,20,0,5,1,0,15]

theorem envBound18010 : H12AffineFastState.Bounded env18010 := by
  intro p hp
  have h : env18010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18009_18010 : H12AffineEnvironment.transform 8 15 env18009 = env18010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env18009 == env18010) = true)

def env18011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound18011 : H12AffineFastState.Bounded env18011 := by
  intro p hp
  have h : env18011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17798_18011 : H12AffineEnvironment.transform 18 1025 env17798 = env18011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17798 == env18011) = true)

theorem identity18011 : scanCanonicalize (H12AffineFastState.compose env18011 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10651082) := by decide +kernel

theorem selectedBound18011 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10651082,8328,64,6637003,8585543,10507601,8830977,2294235,12836875,257,213350,237763,2237964]

theorem envBound18012 : H12AffineFastState.Bounded env18012 := by
  intro p hp
  have h : env18012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18011_18012 : H12AffineEnvironment.transform 23 10651082 env18011 = env18012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10651082 env18011 == env18012) = true)

def env18013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180360,2114882,8328,64,6637003,115151,2266585,262281,2294235,4268163,257,213350,237763,2237964]

theorem envBound18013 : H12AffineFastState.Bounded env18013 := by
  intro p hp
  have h : env18013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18012_18013 : H12AffineEnvironment.transform 22 180360 env18012 = env18013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env18012 == env18013) = true)

def env18014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,169370,8328,64,4691219,115151,17665,262281,119043,4268163,257,213350,237763,63188]

theorem envBound18014 : H12AffineFastState.Bounded env18014 := by
  intro p hp
  have h : env18014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18013_18014 : H12AffineEnvironment.transform 20 184536 env18013 = env18014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env18013 == env18014) = true)

def env18015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,169370,8328,64,245139,115151,17665,262281,119043,329731,257,213350,237763,63188]

theorem envBound18015 : H12AffineFastState.Bounded env18015 := by
  intro p hp
  have h : env18015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18014_18015 : H12AffineEnvironment.transform 21 272512 env18014 = env18015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18014 == env18015) = true)

theorem identity18015 : scanCanonicalize (H12AffineFastState.compose env18015 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound18015 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,115871,272512,120015,98781,8328,64,43476,115151,17665,262281,119043,329731,257,21793,46212,63188]

theorem envBound18016 : H12AffineFastState.Bounded env18016 := by
  intro p hp
  have h : env18016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18015_18016 : H12AffineEnvironment.transform 16 70727 env18015 = env18016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env18015 == env18016) = true)

def env18017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10400,1025,32769,115871,32,120015,98781,8328,64,43476,115151,17665,10281,119043,73891,257,21793,46212,63188]

theorem envBound18017 : H12AffineFastState.Bounded env18017 := by
  intro p hp
  have h : env18017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18016_18017 : H12AffineEnvironment.transform 17 10400 env18016 = env18017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18016 == env18017) = true)

theorem identity18017 : scanCanonicalize (H12AffineFastState.compose env18017 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound18017 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env18018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,70727,2421,1025,32769,115871,32,120015,98781,349,64,34817,115151,17665,2556,119043,65910,257,21793,38225,55041]

theorem envBound18018 : H12AffineFastState.Bounded env18018 := by
  intro p hp
  have h : env18018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18017_18018 : H12AffineEnvironment.transform 12 469 env18017 = env18018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env18017 == env18018) = true)

theorem identity18018 : scanCanonicalize (H12AffineFastState.compose env18018 (packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound18018 : packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env18019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,65536,70727,2421,1025,137,82967,32,87111,65877,349,64,2185,82247,17665,2556,86411,65910,257,21793,5593,22409]

theorem envBound18019 : H12AffineFastState.Bounded env18019 := by
  intro p hp
  have h : env18019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18018_18019 : H12AffineEnvironment.transform 14 136 env18018 = env18019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18018 == env18019) = true)

theorem identity18019 : scanCanonicalize (H12AffineFastState.compose env18019 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound18019 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,479,5528,2421,1025,137,17864,32,21912,138,349,64,2185,16536,17665,2556,20564,169,257,21793,5593,22409]

theorem envBound18020 : H12AffineFastState.Bounded env18020 := by
  intro p hp
  have h : env18020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18019_18020 : H12AffineEnvironment.transform 15 479 env18019 = env18020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env18019 == env18020) = true)

theorem identity18020 : scanCanonicalize (H12AffineFastState.compose env18020 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound18020 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,136,479,5528,2421,1025,137,4405,32,357,138,349,64,2185,5221,4604,2556,1193,169,257,476,5593,884]

theorem envBound18021 : H12AffineFastState.Bounded env18021 := by
  intro p hp
  have h : env18021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18020_18021 : H12AffineEnvironment.transform 13 5373 env18020 = env18021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env18020 == env18021) = true)

theorem identity18021 : scanCanonicalize (H12AffineFastState.compose env18021 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18021 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18022 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5373,136,171,5356,2049,1025,137,4161,32,17,138,41,64,2185,5221,4232,2184,1193,169,117,168,5293,512]

theorem envBound18022 : H12AffineFastState.Bounded env18022 := by
  intro p hp
  have h : env18022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18021_18022 : H12AffineEnvironment.transform 7 116 env18021 = env18022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18021 == env18022) = true)

theorem identity18022 : scanCanonicalize (H12AffineFastState.compose env18022 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound18022 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18023 : List Nat := [2,4,8,16,32,64,120,116,512,1024,2048,4096,89,5125,112,83,5140,2049,1025,113,4161,32,17,114,41,64,2161,5221,4208,2160,1105,81,117,80,5205,512]

theorem envBound18023 : H12AffineFastState.Bounded env18023 := by
  intro p hp
  have h : env18023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18022_18023 : H12AffineEnvironment.transform 6 120 env18022 = env18023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env18022 == env18023) = true)

theorem identity18023 : scanCanonicalize (H12AffineFastState.compose env18023 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18023 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18024 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,40,5125,1,34,5140,2049,1025,0,4144,32,17,3,41,49,2048,5140,4097,2049,1056,32,4,33,5156,512]

theorem envBound18024 : H12AffineFastState.Bounded env18024 := by
  intro p hp
  have h : env18024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18023_18024 : H12AffineEnvironment.transform 5 49 env18023 = env18024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18023 == env18024) = true)

theorem identity18024 : scanCanonicalize (H12AffineFastState.compose env18024 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound18024 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18025 : List Nat := [2,4,8,16,32,49,9,5,512,1024,523,4096,40,5125,1,34,5140,522,1025,0,4144,32,17,3,41,49,523,5140,4097,522,1056,32,4,33,5156,512]

theorem envBound18025 : H12AffineFastState.Bounded env18025 := by
  intro p hp
  have h : env18025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18024_18025 : H12AffineEnvironment.transform 10 523 env18024 = env18025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env18024 == env18025) = true)

theorem identity18025 : scanCanonicalize (H12AffineFastState.compose env18025 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18025 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18026 : List Nat := [2,4,8,16,32,49,9,5,512,21,523,4096,40,4112,1,34,4097,522,20,0,4144,32,17,3,41,49,523,4097,4097,522,53,32,4,33,4145,512]

theorem envBound18026 : H12AffineFastState.Bounded env18026 := by
  intro p hp
  have h : env18026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18025_18026 : H12AffineEnvironment.transform 9 21 env18025 = env18026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18025 == env18026) = true)

theorem identity18026 : scanCanonicalize (H12AffineFastState.compose env18026 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18027 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,4096,9,4112,1,3,4097,522,20,0,4113,1,17,3,8,16,523,4097,4097,522,20,1,4,0,4112,512]

theorem envBound18027 : H12AffineFastState.Bounded env18027 := by
  intro p hp
  have h : env18027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18026_18027 : H12AffineEnvironment.transform 4 1 env18026 = env18027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18026 == env18027) = true)

theorem identity18027 : scanCanonicalize (H12AffineFastState.compose env18027 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 20) := by decide +kernel

theorem selectedBound18027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18028 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,20,9,4,1,3,21,522,20,0,5,1,17,3,8,16,523,21,21,522,20,1,4,0,4,512]

theorem envBound18028 : H12AffineFastState.Bounded env18028 := by
  intro p hp
  have h : env18028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18027_18028 : H12AffineEnvironment.transform 11 20 env18027 = env18028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 20 env18027 == env18028) = true)

theorem identity18028 : scanCanonicalize (H12AffineFastState.compose env18028 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound18028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18029 : List Nat := [1,4,8,16,1,16,9,5,512,21,520,20,9,4,1,0,21,521,20,0,5,1,17,0,8,16,520,21,21,521,20,1,4,0,4,512]

theorem envBound18029 : H12AffineFastState.Bounded env18029 := by
  intro p hp
  have h : env18029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18028_18029 : H12AffineEnvironment.transform 0 1 env18028 = env18029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env18028 == env18029) = true)

theorem identity18029 : scanCanonicalize (H12AffineFastState.compose env18029 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound18029 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18030 : List Nat := [1,4,8,16,1,16,9,5,13,21,5,20,9,4,1,0,21,4,20,0,5,1,17,0,8,16,5,21,21,4,20,1,4,0,4,13]

theorem envBound18030 : H12AffineFastState.Bounded env18030 := by
  intro p hp
  have h : env18030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18029_18030 : H12AffineEnvironment.transform 8 13 env18029 = env18030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env18029 == env18030) = true)

def env18031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10401,1025,32769,115871,33,120015,98781,8328,64,43476,115151,17665,10280,119043,73890,257,21793,46212,63188]

theorem envBound18031 : H12AffineFastState.Bounded env18031 := by
  intro p hp
  have h : env18031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18016_18031 : H12AffineEnvironment.transform 17 10401 env18016 = env18031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18016 == env18031) = true)

theorem identity18031 : scanCanonicalize (H12AffineFastState.compose env18031 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound18031 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env18032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,57676,10401,1025,32769,12692,33,8644,29910,8328,64,43476,13508,17665,10280,9224,54697,257,21793,46212,63188]

theorem envBound18032 : H12AffineFastState.Bounded env18032 := by
  intro p hp
  have h : env18032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18031_18032 : H12AffineEnvironment.transform 15 62731 env18031 = env18032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env18031 == env18032) = true)

theorem identity18032 : scanCanonicalize (H12AffineFastState.compose env18032 (packedSelected [0,1,3,9,10,16,17,18,20,22,23,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound18032 : packedSelected [0,1,3,9,10,16,17,18,20,22,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8202,13389,10401,1025,21760,12692,33,8644,29910,8328,64,31957,13508,17665,10280,9224,168,257,21793,24965,9173]

theorem envBound18033 : H12AffineFastState.Bounded env18033 := by
  intro p hp
  have h : env18033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18032_18033 : H12AffineEnvironment.transform 14 21761 env18032 = env18033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env18032 == env18033) = true)

theorem identity18033 : scanCanonicalize (H12AffineFastState.compose env18033 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18033 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env18034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8541,8202,13389,10401,1025,8540,12692,33,8644,138,8328,64,2185,13508,12637,10280,9224,168,257,8573,5593,9173]

theorem envBound18034 : H12AffineFastState.Bounded env18034 := by
  intro p hp
  have h : env18034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18033_18034 : H12AffineEnvironment.transform 13 13404 env18033 = env18034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18033 == env18034) = true)

theorem identity18034 : scanCanonicalize (H12AffineFastState.compose env18034 (packedSelected [0,2,3,5,7,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound18034 : packedSelected [0,2,3,5,7,10,14] rootPS < 2^1333 := by decide +kernel

def env18035 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,8192,12464,8541,8202,12449,10401,237,8540,12692,33,8644,138,8328,64,2185,12328,12637,10280,8420,168,257,8573,4405,9173]

theorem envBound18035 : H12AffineFastState.Bounded env18035 := by
  intro p hp
  have h : env18035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18034_18035 : H12AffineEnvironment.transform 9 236 env18034 = env18035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env18034 == env18035) = true)

def env18036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,169370,8328,64,245138,115151,17665,262281,119043,329730,257,213350,237763,63188]

theorem envBound18036 : H12AffineFastState.Bounded env18036 := by
  intro p hp
  have h : env18036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18014_18036 : H12AffineEnvironment.transform 21 272513 env18014 = env18036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18014 == env18036) = true)

theorem identity18036 : scanCanonicalize (H12AffineFastState.compose env18036 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound18036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184536,272513,180360,169370,8328,64,158028,5393,17665,262281,1501,318684,257,169400,160797,63188]

theorem envBound18037 : H12AffineFastState.Bounded env18037 := by
  intro p hp
  have h : env18037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18036_18037 : H12AffineEnvironment.transform 15 54494 env18036 = env18037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env18036 == env18037) = true)

theorem identity18037 : scanCanonicalize (H12AffineFastState.compose env18037 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18037 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,131072,262144,1025,29908,140301,272513,144477,155983,8328,64,158028,5393,17665,262281,1501,272393,257,156013,160797,513]

theorem envBound18038 : H12AffineFastState.Bounded env18038 := by
  intro p hp
  have h : env18038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18037_18038 : H12AffineEnvironment.transform 14 29909 env18037 = env18038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18037 == env18038) = true)

theorem identity18038 : scanCanonicalize (H12AffineFastState.compose env18038 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18038 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env18039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,131072,262144,1025,21760,132569,264533,136585,147611,348,64,149656,5393,17665,262281,1501,264669,257,147641,153033,513]

theorem envBound18039 : H12AffineFastState.Bounded env18039 := by
  intro p hp
  have h : env18039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18038_18039 : H12AffineEnvironment.transform 12 468 env18038 = env18039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18038 == env18039) = true)

theorem identity18039 : scanCanonicalize (H12AffineFastState.compose env18039 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound18039 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env18040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,131072,138476,1025,21760,132569,136633,136585,147611,348,64,149656,5393,17665,138341,1501,136497,257,147641,153033,513]

theorem envBound18040 : H12AffineFastState.Bounded env18040 := by
  intro p hp
  have h : env18040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18039_18040 : H12AffineEnvironment.transform 17 138476 env18039 = env18040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env18039 == env18040) = true)

theorem identity18040 : scanCanonicalize (H12AffineFastState.compose env18040 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound18040 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env18041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,16400,23804,1025,21760,17865,21929,21913,139,348,64,2184,5393,17665,23669,1501,21793,257,169,5593,513]

theorem envBound18041 : H12AffineFastState.Bounded env18041 := by
  intro p hp
  have h : env18041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18040_18041 : H12AffineEnvironment.transform 16 16400 env18040 = env18041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env18040 == env18041) = true)

theorem identity18041 : scanCanonicalize (H12AffineFastState.compose env18041 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18041 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env18042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,479,5529,2421,1025,137,4160,32,16,139,348,64,2184,5393,4232,2556,1501,168,257,169,5593,513]

theorem envBound18042 : H12AffineFastState.Bounded env18042 := by
  intro p hp
  have h : env18042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18041_18042 : H12AffineEnvironment.transform 13 5513 env18041 = env18042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18041 == env18042) = true)

theorem identity18042 : scanCanonicalize (H12AffineFastState.compose env18042 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18042 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18043 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,80,263,5441,2421,1025,81,4160,32,16,83,348,64,2128,5393,4176,2340,1285,112,257,113,5377,513]

theorem envBound18043 : H12AffineFastState.Bounded env18043 := by
  intro p hp
  have h : env18043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18042_18043 : H12AffineEnvironment.transform 6 88 env18042 = env18043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18042 == env18043) = true)

theorem identity18043 : scanCanonicalize (H12AffineFastState.compose env18043 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound18043 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18044 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,4096,105,5172,80,98,5156,2064,1025,81,4160,32,16,83,57,64,2128,5236,4176,2113,1120,112,100,113,5220,513]

theorem envBound18044 : H12AffineFastState.Bounded env18044 := by
  intro p hp
  have h : env18044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18043_18044 : H12AffineEnvironment.transform 7 101 env18043 = env18044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env18043 == env18044) = true)

theorem identity18044 : scanCanonicalize (H12AffineFastState.compose env18044 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound18044 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18045 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1572,4096,105,5172,80,98,5156,1588,1025,81,4160,32,16,83,57,64,1652,5236,4176,1637,1120,112,100,113,5220,513]

theorem envBound18045 : H12AffineFastState.Bounded env18045 := by
  intro p hp
  have h : env18045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18044_18045 : H12AffineEnvironment.transform 10 1572 env18044 = env18045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env18044 == env18045) = true)

theorem identity18045 : scanCanonicalize (H12AffineFastState.compose env18045 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound18045 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18046 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1572,593,105,1637,80,98,1653,1588,1025,81,529,32,16,83,57,64,1652,1573,513,1637,1120,112,100,113,1589,513]

theorem envBound18046 : H12AffineFastState.Bounded env18046 := by
  intro p hp
  have h : env18046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18045_18046 : H12AffineEnvironment.transform 11 593 env18045 = env18046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env18045 == env18046) = true)

theorem identity18046 : scanCanonicalize (H12AffineFastState.compose env18046 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound18046 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env18047 : List Nat := [2,4,8,16,32,64,88,101,512,613,65,593,105,0,80,98,16,81,612,81,529,32,16,83,57,64,17,64,513,0,517,112,100,113,80,513]

theorem envBound18047 : H12AffineFastState.Bounded env18047 := by
  intro p hp
  have h : env18047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18046_18047 : H12AffineEnvironment.transform 9 613 env18046 = env18047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env18046 == env18047) = true)

theorem identity18047 : scanCanonicalize (H12AffineFastState.compose env18047 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound18047 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env18048 : List Nat := [2,4,8,16,32,64,88,101,64,37,65,17,105,0,80,98,16,81,36,81,81,32,16,83,57,64,17,64,65,0,69,112,100,113,80,65]

theorem envBound18048 : H12AffineFastState.Bounded env18048 := by
  intro p hp
  have h : env18048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18047_18048 : H12AffineEnvironment.transform 8 64 env18047 = env18048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env18047 == env18048) = true)

theorem identity18048 : scanCanonicalize (H12AffineFastState.compose env18048 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18049 : List Nat := [2,4,8,16,17,64,88,84,64,20,65,17,88,0,80,83,16,81,21,81,81,17,16,83,8,64,17,64,65,0,69,65,85,64,80,65]

theorem envBound18049 : H12AffineFastState.Bounded env18049 := by
  intro p hp
  have h : env18049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18048_18049 : H12AffineEnvironment.transform 4 17 env18048 = env18049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18048 == env18049) = true)

theorem identity18049 : scanCanonicalize (H12AffineFastState.compose env18049 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18049 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env18050 : List Nat := [2,4,8,1,0,64,73,69,64,5,65,0,73,0,65,66,1,64,4,64,64,0,1,66,8,64,0,64,65,0,69,65,68,64,65,65]

theorem envBound18050 : H12AffineFastState.Bounded env18050 := by
  intro p hp
  have h : env18050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18049_18050 : H12AffineEnvironment.transform 3 1 env18049 = env18050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18049 == env18050) = true)

def env18051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,169371,8328,64,4691218,115151,17664,262281,119042,4268163,257,213350,237763,63189]

theorem envBound18051 : H12AffineFastState.Bounded env18051 := by
  intro p hp
  have h : env18051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18013_18051 : H12AffineEnvironment.transform 20 184537 env18013 = env18051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env18013 == env18051) = true)

def env18052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,169371,8328,64,245138,115151,17664,262281,119042,329731,257,213350,237763,63189]

theorem envBound18052 : H12AffineFastState.Bounded env18052 := by
  intro p hp
  have h : env18052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18051_18052 : H12AffineEnvironment.transform 21 272512 env18051 = env18052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18051 == env18052) = true)

theorem identity18052 : scanCanonicalize (H12AffineFastState.compose env18052 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound18052 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77899,272512,73754,95497,8328,64,23808,115151,17664,262281,119042,329731,257,41460,16465,63189]

theorem envBound18053 : H12AffineFastState.Bounded env18053 := by
  intro p hp
  have h : env18053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18052_18053 : H12AffineEnvironment.transform 16 123026 env18052 = env18053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env18052 == env18053) = true)

def env18054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,77899,32,73754,95497,8328,64,23808,115151,17664,10281,119042,73891,257,41460,16465,63189]

theorem envBound18054 : H12AffineFastState.Bounded env18054 := by
  intro p hp
  have h : env18054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18053_18054 : H12AffineEnvironment.transform 17 10400 env18053 = env18054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18053 == env18054) = true)

theorem identity18054 : scanCanonicalize (H12AffineFastState.compose env18054 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound18054 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env18055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,16400,10400,1025,32769,37065,32,32920,54667,8328,64,23808,24909,17664,10281,29056,32801,257,41460,16465,63189]

theorem envBound18055 : H12AffineFastState.Bounded env18055 := by
  intro p hp
  have h : env18055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18054_18055 : H12AffineEnvironment.transform 15 41090 env18054 = env18055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env18054 == env18055) = true)

theorem identity18055 : scanCanonicalize (H12AffineFastState.compose env18055 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18055 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env18056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,41090,13389,10400,1025,32769,37065,32,32920,41430,8328,64,10589,5392,12637,10281,1501,32801,257,41460,13324,33416]

theorem envBound18056 : H12AffineFastState.Bounded env18056 := by
  intro p hp
  have h : env18056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18055_18056 : H12AffineEnvironment.transform 13 13405 env18055 = env18056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18055 == env18056) = true)

theorem identity18056 : scanCanonicalize (H12AffineFastState.compose env18056 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18056 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env18057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,32768,33246,5393,2556,1025,32769,37065,32,32920,32906,468,64,2049,5392,4097,2421,1501,32801,257,32936,5456,33416]

theorem envBound18057 : H12AffineFastState.Bounded env18057 := by
  intro p hp
  have h : env18057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18056_18057 : H12AffineEnvironment.transform 12 348 env18056 = env18057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18056 == env18057) = true)

theorem identity18057 : scanCanonicalize (H12AffineFastState.compose env18057 (packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound18057 : packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env18058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,341,139,5393,2556,1025,340,4508,32,461,479,468,64,2049,5392,4097,2421,1501,372,257,509,5456,989]

theorem envBound18058 : H12AffineFastState.Bounded env18058 := by
  intro p hp
  have h : env18058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18057_18058 : H12AffineEnvironment.transform 14 341 env18057 = env18058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env18057 == env18058) = true)

theorem identity18058 : scanCanonicalize (H12AffineFastState.compose env18058 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound18058 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18059 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,128,5341,137,139,5325,2080,1025,136,4160,32,17,3,8,64,2049,5324,4097,2217,1025,168,221,33,5260,513]

theorem envBound18059 : H12AffineFastState.Bounded env18059 := by
  intro p hp
  have h : env18059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18058_18059 : H12AffineEnvironment.transform 7 220 env18058 = env18059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env18058 == env18059) = true)

theorem identity18059 : scanCanonicalize (H12AffineFastState.compose env18059 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18059 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18060 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,4096,128,5341,137,139,5325,2048,1025,136,4160,0,17,3,8,64,2049,5324,4097,2185,1025,136,221,1,5260,513]

theorem envBound18060 : H12AffineFastState.Bounded env18060 := by
  intro p hp
  have h : env18060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18059_18060 : H12AffineEnvironment.transform 4 0 env18059 = env18060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18059 == env18060) = true)

theorem identity18060 : scanCanonicalize (H12AffineFastState.compose env18060 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 200) := by decide +kernel

theorem selectedBound18060 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env18061 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,200,128,1045,137,139,1029,2048,1025,136,136,0,17,3,8,64,2049,1028,201,2185,1025,136,221,1,1092,513]

theorem envBound18061 : H12AffineFastState.Bounded env18061 := by
  intro p hp
  have h : env18061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18060_18061 : H12AffineEnvironment.transform 11 200 env18060 = env18061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 200 env18060 == env18061) = true)

theorem identity18061 : scanCanonicalize (H12AffineFastState.compose env18061 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound18061 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env18062 : List Nat := [2,4,8,16,0,64,128,220,512,1024,512,200,128,1045,137,139,1029,512,1025,136,136,0,17,3,8,64,513,1028,201,649,1025,136,221,1,1092,513]

theorem envBound18062 : H12AffineFastState.Bounded env18062 := by
  intro p hp
  have h : env18062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18061_18062 : H12AffineEnvironment.transform 10 512 env18061 = env18062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env18061 == env18062) = true)

theorem identity18062 : scanCanonicalize (H12AffineFastState.compose env18062 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18062 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18063 : List Nat := [2,4,8,16,0,64,128,220,136,1024,136,200,128,1045,137,139,1029,136,1025,136,136,0,17,3,8,64,137,1028,201,1,1025,136,221,1,1092,137]

theorem envBound18063 : H12AffineFastState.Bounded env18063 := by
  intro p hp
  have h : env18063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18062_18063 : H12AffineEnvironment.transform 8 136 env18062 = env18063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18062 == env18063) = true)

theorem identity18063 : scanCanonicalize (H12AffineFastState.compose env18063 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound18063 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18064 : List Nat := [2,4,8,16,0,64,128,220,136,69,136,200,128,80,137,139,64,136,68,136,136,0,17,3,8,64,137,65,201,1,68,136,221,1,1,137]

theorem envBound18064 : H12AffineFastState.Bounded env18064 := by
  intro p hp
  have h : env18064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18063_18064 : H12AffineEnvironment.transform 9 69 env18063 = env18064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env18063 == env18064) = true)

theorem identity18064 : scanCanonicalize (H12AffineFastState.compose env18064 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18064 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18065 : List Nat := [2,4,8,16,0,64,8,84,0,69,0,64,8,80,1,3,64,0,68,0,0,0,17,3,8,64,1,65,65,1,68,0,85,1,1,1]

theorem envBound18065 : H12AffineFastState.Bounded env18065 := by
  intro p hp
  have h : env18065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18064_18065 : H12AffineEnvironment.transform 6 8 env18064 = env18065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18064 == env18065) = true)

theorem identity18065 : scanCanonicalize (H12AffineFastState.compose env18065 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18065 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18066 : List Nat := [2,4,8,0,0,64,8,68,0,69,0,64,8,64,1,3,64,0,68,0,0,0,1,3,8,64,1,65,65,1,68,0,69,1,1,1]

theorem envBound18066 : H12AffineFastState.Bounded env18066 := by
  intro p hp
  have h : env18066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18065_18066 : H12AffineEnvironment.transform 3 0 env18065 = env18066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18065 == env18066) = true)

theorem identity18066 : scanCanonicalize (H12AffineFastState.compose env18066 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound18066 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18067 : List Nat := [2,4,8,0,0,1,8,5,0,4,0,1,8,1,1,3,1,0,5,0,0,0,1,3,8,1,1,0,0,1,5,0,4,1,1,1]

theorem envBound18067 : H12AffineFastState.Bounded env18067 := by
  intro p hp
  have h : env18067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18066_18067 : H12AffineEnvironment.transform 5 1 env18066 = env18067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env18066 == env18067) = true)

def env18068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,77899,33,73754,95497,8328,64,23808,115151,17664,10280,119042,73890,257,41460,16465,63189]

theorem envBound18068 : H12AffineFastState.Bounded env18068 := by
  intro p hp
  have h : env18068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18053_18068 : H12AffineEnvironment.transform 17 10401 env18053 = env18068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18053 == env18068) = true)

theorem identity18068 : scanCanonicalize (H12AffineFastState.compose env18068 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound18068 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env18069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57676,10401,1025,32769,12693,33,8644,29911,8328,64,23808,49169,17664,10280,53468,8572,257,41460,16465,63189]

theorem envBound18069 : H12AffineFastState.Bounded env18069 := by
  intro p hp
  have h : env18069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18068_18069 : H12AffineEnvironment.transform 15 478 env18068 = env18069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env18068 == env18069) = true)

theorem identity18069 : scanCanonicalize (H12AffineFastState.compose env18069 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound18069 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env18070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,478,13388,10401,1025,21761,12693,33,8644,29911,8328,64,23808,5393,17664,10280,1500,8572,257,29940,16465,9173]

theorem envBound18070 : H12AffineFastState.Bounded env18070 := by
  intro p hp
  have h : env18070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18069_18070 : H12AffineEnvironment.transform 14 21760 env18069 = env18070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env18069 == env18070) = true)

theorem identity18070 : scanCanonicalize (H12AffineFastState.compose env18070 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,18,24,26,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound18070 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env18071 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21760,263,13388,10360,1025,21761,12620,33,8477,29710,8273,64,23808,5393,17664,10280,1285,8572,257,29741,16465,8972]

theorem envBound18071 : H12AffineFastState.Bounded env18071 := by
  intro p hp
  have h : env18071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18070_18071 : H12AffineEnvironment.transform 6 89 env18070 = env18071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env18070 == env18071) = true)

theorem identity18071 : scanCanonicalize (H12AffineFastState.compose env18071 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18071 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env18072 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21760,263,5392,2340,1025,21761,4112,33,65,21842,269,64,23808,5393,17664,2420,1285,32,257,21873,16465,592]

theorem envBound18072 : H12AffineFastState.Bounded env18072 := by
  intro p hp
  have h : env18072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18071_18072 : H12AffineEnvironment.transform 12 348 env18071 = env18072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18071 == env18072) = true)

theorem identity18072 : scanCanonicalize (H12AffineFastState.compose env18072 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18072 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18073 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,16384,21540,35,5172,2048,1025,21541,4112,33,65,21622,41,64,23588,5173,17444,2128,1057,32,37,21589,16465,592]

theorem envBound18073 : H12AffineFastState.Bounded env18073 := by
  intro p hp
  have h : env18073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18072_18073 : H12AffineEnvironment.transform 7 36 env18072 = env18073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18072 == env18073) = true)

theorem identity18073 : scanCanonicalize (H12AffineFastState.compose env18073 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18073 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18074 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21540,35,5172,2048,1025,21541,4112,33,17,21542,41,16,23588,5173,17444,2048,1057,32,37,21509,16385,512]

theorem envBound18074 : H12AffineFastState.Bounded env18074 := by
  intro p hp
  have h : env18074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18073_18074 : H12AffineEnvironment.transform 5 16 env18073 = env18074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18073 == env18074) = true)

theorem identity18074 : scanCanonicalize (H12AffineFastState.compose env18074 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound18074 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18075 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5124,32,35,5172,2048,1025,33,4112,33,17,34,41,16,2080,5173,4128,2048,1057,32,37,1,5125,512]

theorem envBound18075 : H12AffineFastState.Bounded env18075 := by
  intro p hp
  have h : env18075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18074_18075 : H12AffineEnvironment.transform 13 5124 env18074 = env18075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env18074 == env18075) = true)

theorem identity18075 : scanCanonicalize (H12AffineFastState.compose env18075 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound18075 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env18076 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1077,40,49,32,35,1,2048,1025,33,1061,33,17,34,41,16,2080,0,1045,2048,1057,32,37,1,48,512]

theorem envBound18076 : H12AffineFastState.Bounded env18076 := by
  intro p hp
  have h : env18076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18075_18076 : H12AffineEnvironment.transform 11 1077 env18075 = env18076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env18075 == env18076) = true)

theorem identity18076 : scanCanonicalize (H12AffineFastState.compose env18076 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18076 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18077 : List Nat := [2,4,8,1,32,1,9,36,512,1024,2048,1060,40,32,32,35,1,2048,1025,33,1061,33,0,34,41,1,2080,0,1028,2048,1057,32,37,1,33,512]

theorem envBound18077 : H12AffineFastState.Bounded env18077 := by
  intro p hp
  have h : env18077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18076_18077 : H12AffineEnvironment.transform 3 1 env18076 = env18077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18076 == env18077) = true)

theorem identity18077 : scanCanonicalize (H12AffineFastState.compose env18077 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18077 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18078 : List Nat := [2,4,8,1,32,1,9,36,512,1024,1,1060,40,32,32,35,1,1,1025,33,1061,33,0,34,41,1,33,0,1028,1,1057,32,37,1,33,512]

theorem envBound18078 : H12AffineFastState.Bounded env18078 := by
  intro p hp
  have h : env18078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18077_18078 : H12AffineEnvironment.transform 10 1 env18077 = env18078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18077 == env18078) = true)

theorem identity18078 : scanCanonicalize (H12AffineFastState.compose env18078 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18078 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18079 : List Nat := [2,4,8,1,1,1,9,5,512,1024,1,1029,9,1,1,2,1,1,1025,0,1028,0,0,3,8,1,0,0,1028,1,1024,1,4,1,0,512]

theorem envBound18079 : H12AffineFastState.Bounded env18079 := by
  intro p hp
  have h : env18079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18078_18079 : H12AffineEnvironment.transform 4 1 env18078 = env18079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18078 == env18079) = true)

theorem identity18079 : scanCanonicalize (H12AffineFastState.compose env18079 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18079 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18080 : List Nat := [2,4,8,1,1,1,9,5,0,1024,1,1029,9,1,1,2,1,1,1025,0,1028,0,0,3,8,1,0,0,1028,1,1024,1,4,1,0,0]

theorem envBound18080 : H12AffineFastState.Bounded env18080 := by
  intro p hp
  have h : env18080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18079_18080 : H12AffineEnvironment.transform 8 0 env18079 = env18080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18079 == env18080) = true)

def env18081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,169371,8328,64,245139,115151,17664,262281,119042,329730,257,213350,237763,63189]

theorem envBound18081 : H12AffineFastState.Bounded env18081 := by
  intro p hp
  have h : env18081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18051_18081 : H12AffineEnvironment.transform 21 272513 env18051 = env18081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18051 == env18081) = true)

theorem identity18081 : scanCanonicalize (H12AffineFastState.compose env18081 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18081 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184537,272513,180360,169371,8328,64,171416,57796,17664,262281,61705,272393,257,156013,164040,63189]

theorem envBound18082 : H12AffineFastState.Bounded env18082 := by
  intro p hp
  have h : env18082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18081_18082 : H12AffineEnvironment.transform 15 8203 env18081 = env18082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18081 == env18082) = true)

def env18083 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184457,272513,180360,169371,8328,16,171416,57748,17664,262281,61705,272393,257,155965,163992,63109]

theorem envBound18083 : H12AffineFastState.Bounded env18083 := by
  intro p hp
  have h : env18083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18082_18083 : H12AffineEnvironment.transform 5 16 env18082 = env18083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18082 == env18083) = true)

theorem identity18083 : scanCanonicalize (H12AffineFastState.compose env18083 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound18083 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env18084 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,262144,1025,29708,140420,272513,144517,156054,8328,16,158101,5529,17664,262281,1284,272393,257,155965,160917,648]

theorem envBound18084 : H12AffineFastState.Bounded env18084 := by
  intro p hp
  have h : env18084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18083_18084 : H12AffineEnvironment.transform 14 29709 env18083 = env18084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env18083 == env18084) = true)

theorem identity18084 : scanCanonicalize (H12AffineFastState.compose env18084 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18084 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env18085 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,10280,1025,29708,140420,169,144517,156054,8328,16,158101,5529,17664,10401,1284,33,257,155965,160917,648]

theorem envBound18085 : H12AffineFastState.Bounded env18085 := by
  intro p hp
  have h : env18085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18084_18085 : H12AffineEnvironment.transform 17 10280 env18084 = env18085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18084 == env18085) = true)

theorem identity18085 : scanCanonicalize (H12AffineFastState.compose env18085 (packedSelected [1,8,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18085 : packedSelected [1,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env18086 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8460,8203,131072,10280,1025,8461,140420,169,144517,144535,8328,16,146580,5529,4097,10401,1284,33,257,144444,139668,648]

theorem envBound18086 : H12AffineFastState.Bounded env18086 := by
  intro p hp
  have h : env18086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18085_18086 : H12AffineEnvironment.transform 13 5377 env18085 = env18086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18085 == env18086) = true)

theorem identity18086 : scanCanonicalize (H12AffineFastState.compose env18086 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18086 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18087 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8203,131072,10280,1025,8461,140301,32,144396,144414,8193,16,146461,5392,4097,10280,1284,33,257,144444,139549,513]

theorem envBound18087 : H12AffineFastState.Bounded env18087 := by
  intro p hp
  have h : env18087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18086_18087 : H12AffineEnvironment.transform 6 9 env18086 = env18087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18086 == env18087) = true)

theorem identity18087 : scanCanonicalize (H12AffineFastState.compose env18087 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound18087 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18088 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8203,5392,10280,1025,8461,12573,32,8476,8462,8193,16,10509,5392,4097,10280,1284,33,257,8492,13325,513]

theorem envBound18088 : H12AffineFastState.Bounded env18088 := by
  intro p hp
  have h : env18088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18087_18088 : H12AffineEnvironment.transform 16 5392 env18087 = env18088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env18087 == env18088) = true)

theorem identity18088 : scanCanonicalize (H12AffineFastState.compose env18088 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound18088 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env18089 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,48,8192,1329,8460,8203,1312,10280,1025,8461,8493,32,8476,8462,8193,16,10509,1312,49,10280,1284,33,257,8492,9277,513]

theorem envBound18089 : H12AffineFastState.Bounded env18089 := by
  intro p hp
  have h : env18089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18088_18089 : H12AffineEnvironment.transform 11 48 env18088 = env18089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env18088 == env18089) = true)

theorem identity18089 : scanCanonicalize (H12AffineFastState.compose env18089 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18089 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18090 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,48,268,1329,0,263,1312,2340,1025,1,33,32,16,2,269,16,2049,1312,49,2340,1284,33,257,32,1329,513]

theorem envBound18090 : H12AffineFastState.Bounded env18090 := by
  intro p hp
  have h : env18090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18089_18090 : H12AffineEnvironment.transform 12 268 env18089 = env18090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18089 == env18090) = true)

theorem identity18090 : scanCanonicalize (H12AffineFastState.compose env18090 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18091 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,48,268,292,0,263,309,2340,20,1,33,32,16,2,269,16,2049,309,49,2340,273,33,257,32,292,513]

theorem envBound18091 : H12AffineFastState.Bounded env18091 := by
  intro p hp
  have h : env18091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18090_18091 : H12AffineEnvironment.transform 9 21 env18090 = env18091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18090 == env18091) = true)

theorem identity18091 : scanCanonicalize (H12AffineFastState.compose env18091 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound18091 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18092 : List Nat := [2,4,8,16,32,16,9,256,512,21,523,48,268,292,0,263,309,815,20,1,33,32,16,2,269,16,522,309,49,815,273,33,257,32,292,513]

theorem envBound18092 : H12AffineFastState.Bounded env18092 := by
  intro p hp
  have h : env18092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18091_18092 : H12AffineEnvironment.transform 10 523 env18091 = env18092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env18091 == env18092) = true)

theorem identity18092 : scanCanonicalize (H12AffineFastState.compose env18092 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18092 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18093 : List Nat := [2,4,8,16,32,16,9,37,512,21,523,48,41,1,0,34,16,522,20,1,33,32,16,2,40,16,522,16,49,522,52,33,36,32,1,513]

theorem envBound18093 : H12AffineFastState.Bounded env18093 := by
  intro p hp
  have h : env18093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18092_18093 : H12AffineEnvironment.transform 7 37 env18092 = env18093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18092 == env18093) = true)

theorem identity18093 : scanCanonicalize (H12AffineFastState.compose env18093 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound18093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18094 : List Nat := [2,4,8,16,32,16,9,37,52,21,63,48,41,1,0,34,16,62,20,1,33,32,16,2,40,16,62,16,49,62,52,33,36,32,1,53]

theorem envBound18094 : H12AffineFastState.Bounded env18094 := by
  intro p hp
  have h : env18094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18093_18094 : H12AffineEnvironment.transform 8 52 env18093 = env18094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env18093 == env18094) = true)

def env18095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184456,272513,180360,169371,8328,17,171416,57749,17664,262281,61705,272393,257,155964,163993,63108]

theorem envBound18095 : H12AffineFastState.Bounded env18095 := by
  intro p hp
  have h : env18095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18082_18095 : H12AffineEnvironment.transform 5 17 env18082 = env18095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18082 == env18095) = true)

theorem identity18095 : scanCanonicalize (H12AffineFastState.compose env18095 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound18095 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env18096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56356,1025,32769,184456,62629,180360,169371,8328,17,171416,57749,17664,56493,61705,62509,257,155964,163993,63108]

theorem envBound18096 : H12AffineFastState.Bounded env18096 := by
  intro p hp
  have h : env18096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18095_18096 : H12AffineEnvironment.transform 17 56356 env18095 = env18096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env18095 == env18096) = true)

theorem identity18096 : scanCanonicalize (H12AffineFastState.compose env18096 (packedSelected [1,3,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound18096 : packedSelected [1,3,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env18097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,57749,56356,1025,32769,12573,62629,8477,29710,8328,17,31757,57749,17664,56493,61705,62509,257,32937,24844,63108]

theorem envBound18097 : H12AffineFastState.Bounded env18097 := by
  intro p hp
  have h : env18097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18096_18097 : H12AffineEnvironment.transform 16 57749 env18096 = env18097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env18096 == env18097) = true)

theorem identity18097 : scanCanonicalize (H12AffineFastState.compose env18097 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18097 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env18098 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8203,57628,56356,1025,32769,12573,62508,8477,29710,8193,17,31757,57628,17664,56356,61705,62509,257,32800,24844,62989]

theorem envBound18098 : H12AffineFastState.Bounded env18098 := by
  intro p hp
  have h : env18098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18097_18098 : H12AffineEnvironment.transform 6 9 env18097 = env18098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18097 == env18098) = true)

theorem identity18098 : scanCanonicalize (H12AffineFastState.compose env18098 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18098 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env18099 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16401,32041,1025,8460,12573,21793,8477,29710,8193,17,31757,16401,17664,32041,20484,21792,257,8493,24844,22272]

theorem envBound18099 : H12AffineFastState.Bounded env18099 := by
  intro p hp
  have h : env18099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18098_18099 : H12AffineEnvironment.transform 14 8461 env18098 = env18099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env18098 == env18099) = true)

theorem identity18099 : scanCanonicalize (H12AffineFastState.compose env18099 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18099 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18100 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8461,8203,13341,2341,1025,8460,12573,8493,8477,2,8193,17,2049,13341,12556,2341,9224,8492,257,8493,5376,8972]

theorem envBound18100 : H12AffineFastState.Bounded env18100 := by
  intro p hp
  have h : env18100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18099_18100 : H12AffineEnvironment.transform 13 13324 env18099 = env18100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18099 == env18100) = true)

theorem identity18100 : scanCanonicalize (H12AffineFastState.compose env18100 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound18100 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env18101 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2356,8192,11576,8461,8203,11561,2341,1025,8460,10281,8493,8477,2,8193,17,2049,11561,10296,2341,9224,8492,257,8493,3124,8972]

theorem envBound18101 : H12AffineFastState.Bounded env18101 := by
  intro p hp
  have h : env18101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18100_18101 : H12AffineEnvironment.transform 11 2356 env18100 = env18101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env18100 == env18101) = true)

theorem identity18101 : scanCanonicalize (H12AffineFastState.compose env18101 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18101 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env18102 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2356,40,3344,293,35,3329,2341,1025,292,2049,261,309,2,41,17,2049,3329,2064,2341,1056,260,257,261,3124,804]

theorem envBound18102 : H12AffineFastState.Bounded env18102 := by
  intro p hp
  have h : env18102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18101_18102 : H12AffineEnvironment.transform 12 40 env18101 = env18102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18101 == env18102) = true)

theorem identity18102 : scanCanonicalize (H12AffineFastState.compose env18102 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound18102 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18103 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,1060,40,0,293,35,17,1077,1025,292,1297,261,309,2,41,17,1297,17,1280,1077,1056,260,257,261,292,804]

theorem envBound18103 : H12AffineFastState.Bounded env18103 := by
  intro p hp
  have h : env18103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18102_18103 : H12AffineEnvironment.transform 10 1296 env18102 = env18103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env18102 == env18103) = true)

theorem identity18103 : scanCanonicalize (H12AffineFastState.compose env18103 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18103 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env18104 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1296,1028,8,0,261,3,17,1045,1025,260,1297,261,277,2,9,17,1297,17,1280,1045,1024,260,257,261,260,772]

theorem envBound18104 : H12AffineFastState.Bounded env18104 := by
  intro p hp
  have h : env18104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18103_18104 : H12AffineEnvironment.transform 4 0 env18103 = env18104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18103 == env18104) = true)

theorem identity18104 : scanCanonicalize (H12AffineFastState.compose env18104 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18104 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18105 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1044,1028,8,0,1,3,17,1045,1025,0,1045,1,17,2,9,17,1045,17,1028,1045,1024,0,5,1,0,512]

theorem envBound18105 : H12AffineFastState.Bounded env18105 := by
  intro p hp
  have h : env18105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18104_18105 : H12AffineEnvironment.transform 7 4 env18104 = env18105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18104 == env18105) = true)

theorem identity18105 : scanCanonicalize (H12AffineFastState.compose env18105 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18106 : List Nat := [2,4,8,16,0,17,9,4,1,1024,1044,1028,8,0,1,3,17,1045,1025,0,1045,1,17,2,9,17,1045,17,1028,1045,1024,0,5,1,0,1]

theorem envBound18106 : H12AffineFastState.Bounded env18106 := by
  intro p hp
  have h : env18106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18105_18106 : H12AffineEnvironment.transform 8 1 env18105 = env18106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18105 == env18106) = true)

theorem identity18106 : scanCanonicalize (H12AffineFastState.compose env18106 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18106 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18107 : List Nat := [2,4,8,16,0,17,9,4,1,21,1,17,8,0,1,3,17,0,20,0,0,1,17,2,9,17,0,17,17,0,21,0,5,1,0,1]

theorem envBound18107 : H12AffineFastState.Bounded env18107 := by
  intro p hp
  have h : env18107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18106_18107 : H12AffineEnvironment.transform 9 21 env18106 = env18107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18106 == env18107) = true)

theorem identity18107 : scanCanonicalize (H12AffineFastState.compose env18107 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound18107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18108 : List Nat := [2,4,8,4,0,5,9,4,1,1,1,5,8,0,1,3,5,0,0,0,0,1,5,2,9,5,0,5,5,0,1,0,5,1,0,1]

theorem envBound18108 : H12AffineFastState.Bounded env18108 := by
  intro p hp
  have h : env18108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18107_18108 : H12AffineEnvironment.transform 3 4 env18107 = env18108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env18107 == env18108) = true)

def env18109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180361,2114883,8328,64,6637003,115150,2266584,262280,2294235,4268162,257,213350,237763,2237964]

theorem envBound18109 : H12AffineFastState.Bounded env18109 := by
  intro p hp
  have h : env18109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18012_18109 : H12AffineEnvironment.transform 22 180361 env18012 = env18109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env18012 == env18109) = true)

def env18110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,169371,8328,64,4691219,115150,17664,262280,119043,4268162,257,213350,237763,63188]

theorem envBound18110 : H12AffineFastState.Bounded env18110 := by
  intro p hp
  have h : env18110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18109_18110 : H12AffineEnvironment.transform 20 184536 env18109 = env18110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env18109 == env18110) = true)

def env18111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,169371,8328,64,245139,115150,17664,262280,119043,329730,257,213350,237763,63188]

theorem envBound18111 : H12AffineFastState.Bounded env18111 := by
  intro p hp
  have h : env18111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18110_18111 : H12AffineEnvironment.transform 21 272512 env18110 = env18111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18110 == env18111) = true)

theorem identity18111 : scanCanonicalize (H12AffineFastState.compose env18111 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18111 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140301,272512,144476,155982,8328,64,215366,79131,17664,262280,75222,329730,257,213350,218134,513]

theorem envBound18112 : H12AffineFastState.Bounded env18112 := by
  intro p hp
  have h : env18112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18111_18112 : H12AffineEnvironment.transform 14 29909 env18111 = env18112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18111 == env18112) = true)

def env18113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272392,144476,155982,8192,64,215366,79131,17664,262144,75102,329730,257,213350,218134,513]

theorem envBound18113 : H12AffineFastState.Bounded env18113 := by
  intro p hp
  have h : env18113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18112_18113 : H12AffineEnvironment.transform 6 8 env18112 = env18113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18112 == env18113) = true)

theorem identity18113 : scanCanonicalize (H12AffineFastState.compose env18113 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound18113 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,82966,272392,87111,65877,8192,64,10589,79131,17664,262144,75102,329730,257,8573,13325,513]

theorem envBound18114 : H12AffineFastState.Bounded env18114 := by
  intro p hp
  have h : env18114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18113_18114 : H12AffineEnvironment.transform 16 90139 env18113 = env18114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env18113 == env18114) = true)

theorem identity18114 : scanCanonicalize (H12AffineFastState.compose env18114 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound18114 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,97326,1025,29788,82966,87078,87111,65877,8192,64,10589,79131,17664,97326,75102,29740,257,8573,13325,513]

theorem envBound18115 : H12AffineFastState.Bounded env18115 := by
  intro p hp
  have h : env18115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18114_18115 : H12AffineEnvironment.transform 17 97326 env18114 = env18115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env18114 == env18115) = true)

theorem identity18115 : scanCanonicalize (H12AffineFastState.compose env18115 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18115 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env18116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,343,24908,32121,1025,29788,17729,21873,21776,2,8192,64,10589,13388,17664,32121,9225,29740,257,8573,13325,513]

theorem envBound18116 : H12AffineFastState.Bounded env18116 := by
  intro p hp
  have h : env18116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18115_18116 : H12AffineEnvironment.transform 15 343 env18115 = env18116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18115 == env18116) = true)

theorem identity18116 : scanCanonicalize (H12AffineFastState.compose env18116 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound18116 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4160,9245,343,12556,11577,1025,9244,5377,1329,1360,2,8192,64,10589,13388,5440,11577,9225,9324,257,8573,13325,513]

theorem envBound18117 : H12AffineFastState.Bounded env18117 := by
  intro p hp
  have h : env18117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18116_18117 : H12AffineEnvironment.transform 13 4160 env18116 = env18117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env18116 == env18117) = true)

theorem identity18117 : scanCanonicalize (H12AffineFastState.compose env18117 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound18117 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4160,293,343,5172,2049,1025,292,5377,1329,1360,2,1336,64,3173,4468,5440,2049,305,340,257,1093,4405,513]

theorem envBound18118 : H12AffineFastState.Bounded env18118 := by
  intro p hp
  have h : env18118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18117_18118 : H12AffineEnvironment.transform 12 1336 env18117 = env18118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env18117 == env18118) = true)

theorem identity18118 : scanCanonicalize (H12AffineFastState.compose env18118 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18118 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env18119 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1052,4160,1,115,5172,2049,1025,0,5157,1045,1140,2,1052,64,3173,4176,5220,2049,21,112,37,1093,4113,513]

theorem envBound18119 : H12AffineFastState.Bounded env18119 := by
  intro p hp
  have h : env18119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18118_18119 : H12AffineEnvironment.transform 7 36 env18118 = env18119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18118 == env18119) = true)

theorem identity18119 : scanCanonicalize (H12AffineFastState.compose env18119 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound18119 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18120 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,513,1052,577,1,115,1589,2049,1025,0,1572,1045,1140,2,1052,64,3173,593,1637,2049,21,112,37,1093,528,513]

theorem envBound18120 : H12AffineFastState.Bounded env18120 := by
  intro p hp
  have h : env18120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18119_18120 : H12AffineEnvironment.transform 11 513 env18119 = env18120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env18119 == env18120) = true)

theorem identity18120 : scanCanonicalize (H12AffineFastState.compose env18120 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound18120 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18121 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,513,120,577,1,115,593,2049,101,0,576,113,16,2,120,64,2049,593,513,2049,21,112,37,33,528,513]

theorem envBound18121 : H12AffineFastState.Bounded env18121 := by
  intro p hp
  have h : env18121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18120_18121 : H12AffineEnvironment.transform 9 100 env18120 = env18121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env18120 == env18121) = true)

theorem identity18121 : scanCanonicalize (H12AffineFastState.compose env18121 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound18121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18122 : List Nat := [2,4,8,16,32,32,8,36,512,4,2048,513,24,545,1,19,561,2049,5,0,544,17,16,2,24,32,2049,561,513,2049,21,16,37,33,528,513]

theorem envBound18122 : H12AffineFastState.Bounded env18122 := by
  intro p hp
  have h : env18122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18121_18122 : H12AffineEnvironment.transform 5 32 env18121 = env18122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env18121 == env18122) = true)

theorem identity18122 : scanCanonicalize (H12AffineFastState.compose env18122 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18122 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18123 : List Nat := [2,4,8,0,32,32,8,36,512,4,2048,513,8,545,1,3,545,2049,5,0,544,1,0,2,8,32,2049,545,513,2049,5,0,37,33,512,513]

theorem envBound18123 : H12AffineFastState.Bounded env18123 := by
  intro p hp
  have h : env18123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18122_18123 : H12AffineEnvironment.transform 3 0 env18122 = env18123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18122 == env18123) = true)

theorem identity18123 : scanCanonicalize (H12AffineFastState.compose env18123 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18123 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18124 : List Nat := [2,4,8,0,1,1,8,5,512,4,2048,513,8,512,1,3,512,2049,5,0,513,1,0,2,8,1,2049,512,513,2049,5,0,4,0,512,513]

theorem envBound18124 : H12AffineFastState.Bounded env18124 := by
  intro p hp
  have h : env18124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18123_18124 : H12AffineEnvironment.transform 4 1 env18123 = env18124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18123 == env18124) = true)

theorem identity18124 : scanCanonicalize (H12AffineFastState.compose env18124 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18125 : List Nat := [2,4,8,0,1,1,8,5,1,4,2048,0,8,1,1,3,1,2049,5,0,0,1,0,2,8,1,2049,1,0,2049,5,0,4,0,1,0]

theorem envBound18125 : H12AffineFastState.Bounded env18125 := by
  intro p hp
  have h : env18125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18124_18125 : H12AffineEnvironment.transform 8 1 env18124 = env18125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18124 == env18125) = true)

theorem identity18125 : scanCanonicalize (H12AffineFastState.compose env18125 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18125 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18126 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,0,8,1,1,3,1,0,5,0,0,1,0,2,8,1,0,1,0,0,5,0,4,0,1,0]

theorem envBound18126 : H12AffineFastState.Bounded env18126 := by
  intro p hp
  have h : env18126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18125_18126 : H12AffineEnvironment.transform 10 1 env18125 = env18126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18125 == env18126) = true)

def env18127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272393,144476,155982,8193,64,215366,79131,17664,262145,75103,329730,257,213350,218134,513]

theorem envBound18127 : H12AffineFastState.Bounded env18127 := by
  intro p hp
  have h : env18127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18112_18127 : H12AffineEnvironment.transform 6 9 env18112 = env18127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18112 == env18127) = true)

def env18128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,140301,33,144476,155982,8193,64,215366,79131,17664,10281,75103,73770,257,213350,218134,513]

theorem envBound18128 : H12AffineFastState.Bounded env18128 := by
  intro p hp
  have h : env18128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18127_18128 : H12AffineEnvironment.transform 17 10280 env18127 = env18128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18127 == env18128) = true)

theorem identity18128 : scanCanonicalize (H12AffineFastState.compose env18128 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18128 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env18129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1025,8541,140301,33,144476,144462,8193,64,203846,79131,4096,10281,75103,73770,257,201830,196886,513]

theorem envBound18129 : H12AffineFastState.Bounded env18129 := by
  intro p hp
  have h : env18129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18128_18129 : H12AffineEnvironment.transform 13 5376 env18128 = env18129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18128 == env18129) = true)

theorem identity18129 : scanCanonicalize (H12AffineFastState.compose env18129 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18129 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,5393,10280,1025,8541,12572,33,8525,8543,8193,64,67927,79131,4096,10281,75103,73770,257,65911,70663,513]

theorem envBound18130 : H12AffineFastState.Bounded env18130 := by
  intro p hp
  have h : env18130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18129_18130 : H12AffineEnvironment.transform 16 5393 env18129 = env18130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18129 == env18130) = true)

theorem identity18130 : scanCanonicalize (H12AffineFastState.compose env18130 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18130 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,5393,2420,1025,1,4160,33,17,3,349,64,67927,70727,4096,2421,66563,65910,257,65911,70663,513]

theorem envBound18131 : H12AffineFastState.Bounded env18131 := by
  intro p hp
  have h : env18131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18130_18131 : H12AffineEnvironment.transform 12 348 env18130 = env18131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18130 == env18131) = true)

theorem identity18131 : scanCanonicalize (H12AffineFastState.compose env18131 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18131 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env18132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2420,1025,1,4160,33,17,3,349,64,2049,5393,4096,2421,1365,32,257,33,5457,513]

theorem envBound18132 : H12AffineFastState.Bounded env18132 := by
  intro p hp
  have h : env18132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18131_18132 : H12AffineEnvironment.transform 15 342 env18131 = env18132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18131 == env18132) = true)

theorem identity18132 : scanCanonicalize (H12AffineFastState.compose env18132 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound18132 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18133 : List Nat := [2,4,8,16,32,64,9,256,512,565,2048,4096,348,4917,0,342,4900,2420,564,1,4160,33,17,3,349,64,2049,4900,4096,2421,864,32,257,33,4964,513]

theorem envBound18133 : H12AffineFastState.Bounded env18133 := by
  intro p hp
  have h : env18133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18132_18133 : H12AffineEnvironment.transform 9 565 env18132 = env18133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env18132 == env18133) = true)

theorem identity18133 : scanCanonicalize (H12AffineFastState.compose env18133 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18134 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,4096,268,4917,0,262,4900,2340,564,1,4112,33,17,3,269,16,2049,4900,4096,2341,816,32,257,33,4916,513]

theorem envBound18134 : H12AffineFastState.Bounded env18134 := by
  intro p hp
  have h : env18134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18133_18134 : H12AffineEnvironment.transform 5 16 env18133 = env18134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18133 == env18134) = true)

theorem identity18134 : scanCanonicalize (H12AffineFastState.compose env18134 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound18134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18135 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,512,268,309,0,262,292,2340,564,1,528,33,17,3,269,16,2049,292,512,2341,816,32,257,33,308,513]

theorem envBound18135 : H12AffineFastState.Bounded env18135 := by
  intro p hp
  have h : env18135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18134_18135 : H12AffineEnvironment.transform 11 512 env18134 = env18135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env18134 == env18135) = true)

theorem identity18135 : scanCanonicalize (H12AffineFastState.compose env18135 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound18135 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18136 : List Nat := [2,4,8,16,32,16,9,256,512,565,820,512,268,309,0,262,292,528,564,1,528,33,17,3,269,16,821,292,512,529,816,32,257,33,308,513]

theorem envBound18136 : H12AffineFastState.Bounded env18136 := by
  intro p hp
  have h : env18136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18135_18136 : H12AffineEnvironment.transform 10 820 env18135 = env18136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env18135 == env18136) = true)

theorem identity18136 : scanCanonicalize (H12AffineFastState.compose env18136 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound18136 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18137 : List Nat := [2,4,8,16,32,16,9,256,292,273,16,292,268,309,0,262,292,308,272,1,308,33,17,3,269,16,17,292,292,309,20,32,257,33,308,293]

theorem envBound18137 : H12AffineFastState.Bounded env18137 := by
  intro p hp
  have h : env18137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18136_18137 : H12AffineEnvironment.transform 8 292 env18136 = env18137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env18136 == env18137) = true)

theorem identity18137 : scanCanonicalize (H12AffineFastState.compose env18137 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18137 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18138 : List Nat := [2,4,8,16,16,16,9,256,276,273,16,276,268,261,0,262,276,260,272,1,260,17,17,3,269,16,17,276,276,261,20,16,257,17,260,277]

theorem envBound18138 : H12AffineFastState.Bounded env18138 := by
  intro p hp
  have h : env18138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18137_18138 : H12AffineEnvironment.transform 4 16 env18137 = env18138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18137 == env18138) = true)

theorem identity18138 : scanCanonicalize (H12AffineFastState.compose env18138 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18138 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18139 : List Nat := [2,4,8,16,16,16,9,20,0,5,16,0,24,17,0,18,0,16,4,1,16,17,17,3,25,16,17,0,0,17,20,16,21,17,16,1]

theorem envBound18139 : H12AffineFastState.Bounded env18139 := by
  intro p hp
  have h : env18139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18138_18139 : H12AffineEnvironment.transform 7 20 env18138 = env18139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18138 == env18139) = true)

theorem identity18139 : scanCanonicalize (H12AffineFastState.compose env18139 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18140 : List Nat := [2,4,8,0,0,0,9,4,0,5,0,0,8,1,0,2,0,0,4,1,0,1,1,3,9,0,1,0,0,1,4,0,5,1,0,1]

theorem envBound18140 : H12AffineFastState.Bounded env18140 := by
  intro p hp
  have h : env18140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18139_18140 : H12AffineEnvironment.transform 3 0 env18139 = env18140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18139 == env18140) = true)

def env18141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,140301,32,144476,155982,8193,64,215366,79131,17664,10280,75103,73771,257,213350,218134,513]

theorem envBound18141 : H12AffineFastState.Bounded env18141 := by
  intro p hp
  have h : env18141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18127_18141 : H12AffineEnvironment.transform 17 10281 env18127 = env18141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18127 == env18141) = true)

theorem identity18141 : scanCanonicalize (H12AffineFastState.compose env18141 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound18141 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1025,29789,4161,32,16,21762,8193,64,97546,79131,17664,10280,75103,73771,257,95530,90202,513]

theorem envBound18142 : H12AffineFastState.Bounded env18142 := by
  intro p hp
  have h : env18142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18141_18142 : H12AffineEnvironment.transform 16 13388 env18141 = env18142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env18141 == env18142) = true)

theorem identity18142 : scanCanonicalize (H12AffineFastState.compose env18142 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15373) := by decide +kernel

theorem selectedBound18142 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env18143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15373,2129,65536,13388,10281,1025,2128,4161,32,16,10511,8193,64,65799,79131,14605,10280,75103,73771,257,67879,72791,513]

theorem envBound18143 : H12AffineFastState.Bounded env18143 := by
  intro p hp
  have h : env18143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18142_18143 : H12AffineEnvironment.transform 13 15373 env18142 = env18143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15373 env18142 == env18143) = true)

theorem identity18143 : scanCanonicalize (H12AffineFastState.compose env18143 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 10330) := by decide +kernel

theorem selectedBound18143 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15373,2129,10330,13388,10281,1025,2128,4161,32,16,10511,8193,64,10589,7489,14605,10280,3333,2161,257,8573,13325,513]

theorem envBound18144 : H12AffineFastState.Bounded env18144 := by
  intro p hp
  have h : env18144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18143_18144 : H12AffineEnvironment.transform 15 10330 env18143 = env18144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10330 env18143 == env18144) = true)

theorem identity18144 : scanCanonicalize (H12AffineFastState.compose env18144 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound18144 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env18145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4429,3392,2129,6423,1281,6500,1025,2128,4161,32,16,6210,4428,64,6160,7489,2112,6501,3333,2161,257,4144,1344,513]

theorem envBound18145 : H12AffineFastState.Bounded env18145 := by
  intro p hp
  have h : env18145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18144_18145 : H12AffineEnvironment.transform 12 4429 env18144 = env18145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env18144 == env18145) = true)

theorem identity18145 : scanCanonicalize (H12AffineFastState.compose env18145 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound18145 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,4429,1,1296,5206,1281,5157,1025,1297,4161,32,16,5379,4428,64,5457,4096,1281,5156,68,1328,257,4144,1344,513]

theorem envBound18146 : H12AffineFastState.Bounded env18146 := by
  intro p hp
  have h : env18146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18145_18146 : H12AffineEnvironment.transform 10 1345 env18145 = env18146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env18145 == env18146) = true)

theorem identity18146 : scanCanonicalize (H12AffineFastState.compose env18146 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound18146 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,1140,1337,1,1296,34,1281,81,1025,1297,1077,32,16,375,1336,64,293,1140,1281,80,68,1328,257,1092,1344,513]

theorem envBound18147 : H12AffineFastState.Bounded env18147 := by
  intro p hp
  have h : env18147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18146_18147 : H12AffineEnvironment.transform 11 1140 env18146 = env18147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env18146 == env18147) = true)

theorem identity18147 : scanCanonicalize (H12AffineFastState.compose env18147 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18147 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env18148 : List Nat := [2,4,8,16,32,64,9,256,512,273,80,357,40,1,1,34,16,81,272,0,292,32,16,375,41,64,293,357,16,80,68,33,257,341,81,513]

theorem envBound18148 : H12AffineFastState.Bounded env18148 := by
  intro p hp
  have h : env18148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18147_18148 : H12AffineEnvironment.transform 9 273 env18147 = env18148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18147 == env18148) = true)

theorem identity18148 : scanCanonicalize (H12AffineFastState.compose env18148 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18148 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18149 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,308,40,1,1,34,16,0,272,0,292,32,16,294,41,17,293,308,16,1,21,33,257,260,0,513]

end H12CloudChart0