import H12CloudChart0Data009

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound2439 : H12AffineFastState.Bounded env2439 := by
  intro p hp
  have h : env2439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2438_2439 : H12AffineEnvironment.transform 15 8574 env2438 = env2439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2438 == env2439) = true)

theorem identity2439 : scanCanonicalize (H12AffineFastState.compose env2439 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound2439 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2440 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,8574,16633,2081,256,8693,2097152,33,185,138,8328,232,2048,16384,4344,2081,256,0,256,1,16633,512]

theorem envBound2440 : H12AffineFastState.Bounded env2440 := by
  intro p hp
  have h : env2440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2439_2440 : H12AffineEnvironment.transform 17 2081 env2439 = env2440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env2439 == env2440) = true)

theorem identity2440 : scanCanonicalize (H12AffineFastState.compose env2440 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2440 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2441 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8201,8322,16633,2081,252,8201,2097152,33,185,138,8328,232,2048,16384,4344,2081,252,0,252,1,16633,512]

theorem envBound2441 : H12AffineFastState.Bounded env2441 := by
  intro p hp
  have h : env2441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2440_2441 : H12AffineEnvironment.transform 7 252 env2440 = env2441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2440 == env2441) = true)

theorem identity2441 : scanCanonicalize (H12AffineFastState.compose env2441 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound2441 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env2442 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8201,8322,16633,2081,252,8201,26674,33,185,138,8328,232,2048,16384,4344,2081,252,0,252,1,16633,512]

theorem envBound2442 : H12AffineFastState.Bounded env2442 := by
  intro p hp
  have h : env2442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2441_2442 : H12AffineEnvironment.transform 20 26674 env2441 = env2442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env2441 == env2442) = true)

theorem identity2442 : scanCanonicalize (H12AffineFastState.compose env2442 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound2442 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2443 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,12497,8201,8322,12328,2081,252,8201,6371,33,185,138,8328,232,2048,12497,4344,2081,252,0,252,1,12328,512]

theorem envBound2443 : H12AffineFastState.Bounded env2443 := by
  intro p hp
  have h : env2443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2442_2443 : H12AffineEnvironment.transform 13 12497 env2442 = env2443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env2442 == env2443) = true)

theorem identity2443 : scanCanonicalize (H12AffineFastState.compose env2443 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound2443 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env2444 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,2282,6203,2275,2152,6338,2081,252,2275,6371,33,185,138,2146,232,2048,6203,4344,2081,252,0,252,1,6338,512]

theorem envBound2444 : H12AffineFastState.Bounded env2444 := by
  intro p hp
  have h : env2444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2443_2444 : H12AffineEnvironment.transform 12 2282 env2443 = env2444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env2443 == env2444) = true)

theorem identity2444 : scanCanonicalize (H12AffineFastState.compose env2444 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound2444 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env2445 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,2128,2282,107,2275,2152,146,2081,252,2275,179,33,185,138,2146,232,2048,107,2216,2081,252,0,252,1,146,512]

theorem envBound2445 : H12AffineFastState.Bounded env2445 := by
  intro p hp
  have h : env2445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2444_2445 : H12AffineEnvironment.transform 11 2128 env2444 = env2445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env2444 == env2445) = true)

theorem identity2445 : scanCanonicalize (H12AffineFastState.compose env2445 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound2445 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2446 : List Nat := [2,4,8,16,32,64,128,252,512,252,194,146,40,107,33,170,146,227,252,33,179,33,185,138,160,232,194,107,106,227,252,0,252,1,146,512]

theorem envBound2446 : H12AffineFastState.Bounded env2446 := by
  intro p hp
  have h : env2446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2445_2446 : H12AffineEnvironment.transform 10 194 env2445 = env2446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env2445 == env2446) = true)

theorem identity2446 : scanCanonicalize (H12AffineFastState.compose env2446 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound2446 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env2447 : List Nat := [2,4,8,16,32,64,19,111,512,111,81,1,40,107,33,57,1,112,111,33,32,33,42,25,51,123,81,107,106,112,111,0,111,1,1,512]

theorem envBound2447 : H12AffineFastState.Bounded env2447 := by
  intro p hp
  have h : env2447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2446_2447 : H12AffineEnvironment.transform 6 19 env2446 = env2447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env2446 == env2447) = true)

theorem identity2447 : scanCanonicalize (H12AffineFastState.compose env2447 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound2447 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2448 : List Nat := [2,4,8,16,32,42,19,5,512,5,59,1,40,1,33,57,1,26,5,33,32,33,42,25,51,17,59,1,0,26,5,0,5,1,1,512]

theorem envBound2448 : H12AffineFastState.Bounded env2448 := by
  intro p hp
  have h : env2448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2447_2448 : H12AffineEnvironment.transform 5 42 env2447 = env2448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env2447 == env2448) = true)

theorem identity2448 : scanCanonicalize (H12AffineFastState.compose env2448 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound2448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2449 : List Nat := [2,4,8,16,0,10,19,5,512,5,27,1,8,1,1,25,1,26,5,1,0,1,10,25,19,17,27,1,0,26,5,0,5,1,1,512]

theorem envBound2449 : H12AffineFastState.Bounded env2449 := by
  intro p hp
  have h : env2449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2448_2449 : H12AffineEnvironment.transform 4 0 env2448 = env2449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env2448 == env2449) = true)

theorem identity2449 : scanCanonicalize (H12AffineFastState.compose env2449 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2450 : List Nat := [2,4,5,16,0,7,19,5,512,5,22,1,5,1,1,20,1,23,5,1,0,1,7,20,19,17,22,1,0,23,5,0,5,1,1,512]

theorem envBound2450 : H12AffineFastState.Bounded env2450 := by
  intro p hp
  have h : env2450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2449_2450 : H12AffineEnvironment.transform 2 5 env2449 = env2450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2449 == env2450) = true)

theorem identity2450 : scanCanonicalize (H12AffineFastState.compose env2450 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2450 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2451 : List Nat := [2,4,5,1,0,7,2,5,512,5,7,1,5,1,1,5,1,6,5,1,0,1,7,5,2,0,7,1,0,6,5,0,5,1,1,512]

theorem envBound2451 : H12AffineFastState.Bounded env2451 := by
  intro p hp
  have h : env2451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2450_2451 : H12AffineEnvironment.transform 3 1 env2450 = env2451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2450 == env2451) = true)

theorem identity2451 : scanCanonicalize (H12AffineFastState.compose env2451 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2451 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2452 : List Nat := [2,2,3,1,0,1,2,3,512,3,1,1,3,1,1,3,1,0,3,1,0,1,1,3,2,0,1,1,0,0,3,0,3,1,1,512]

theorem envBound2452 : H12AffineFastState.Bounded env2452 := by
  intro p hp
  have h : env2452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2451_2452 : H12AffineEnvironment.transform 1 2 env2451 = env2452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2451 == env2452) = true)

def env2453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,131073,16925299]

theorem envBound2453 : H12AffineFastState.Bounded env2453 := by
  intro p hp
  have h : env2453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2433_2453 : H12AffineEnvironment.transform 34 131073 env2433 = env2453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2433 == env2453) = true)

theorem identity2453 : scanCanonicalize (H12AffineFastState.compose env2453 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2250099) := by decide +kernel

theorem selectedBound2453 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,2250099,8328,147473,409816,16384,151553,2081,2322567,4341976,256,1,131073,2103040]

theorem envBound2454 : H12AffineFastState.Bounded env2454 := by
  intro p hp
  have h : env2454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2453_2454 : H12AffineEnvironment.transform 23 2250099 env2453 = env2454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2250099 env2453 == env2454) = true)

theorem identity2454 : scanCanonicalize (H12AffineFastState.compose env2454 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 153080) := by decide +kernel

theorem selectedBound2454 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,153080,4194304,147520,139,8328,147473,409816,16384,151553,2081,75135,4341976,256,1,131073,148216]

theorem envBound2455 : H12AffineFastState.Bounded env2455 := by
  intro p hp
  have h : env2455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2454_2455 : H12AffineEnvironment.transform 20 153080 env2454 = env2455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 153080 env2454 == env2455) = true)

def env2456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,153080,32,147520,139,8328,147473,409816,16384,151553,2081,75135,147704,256,1,131073,148216]

theorem envBound2456 : H12AffineFastState.Bounded env2456 := by
  intro p hp
  have h : env2456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2455_2456 : H12AffineEnvironment.transform 21 32 env2455 = env2456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env2455 == env2456) = true)

theorem identity2456 : scanCanonicalize (H12AffineFastState.compose env2456 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound2456 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,90502,262144,1024,8693,78974,32,74182,139,8328,74135,336222,16384,78215,2081,75135,74110,256,1,90503,74622]

theorem envBound2457 : H12AffineFastState.Bounded env2457 := by
  intro p hp
  have h : env2457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2456_2457 : H12AffineEnvironment.transform 16 90502 env2456 = env2457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env2456 == env2457) = true)

theorem identity2457 : scanCanonicalize (H12AffineFastState.compose env2457 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound2457 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env2458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8662,16464,262144,1024,8693,5544,32,16,139,8328,65,262280,16384,4177,2081,1193,168,256,1,16465,680]

theorem envBound2458 : H12AffineFastState.Bounded env2458 := by
  intro p hp
  have h : env2458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2457_2458 : H12AffineEnvironment.transform 15 8662 env2457 = env2458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env2457 == env2458) = true)

theorem identity2458 : scanCanonicalize (H12AffineFastState.compose env2458 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound2458 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env2459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12312,8693,8662,12360,262144,1024,8693,5544,32,16,139,8328,65,262280,12312,4177,2081,1193,168,256,1,12361,680]

theorem envBound2459 : H12AffineFastState.Bounded env2459 := by
  intro p hp
  have h : env2459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2458_2459 : H12AffineEnvironment.transform 13 12312 env2458 = env2459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env2458 == env2459) = true)

theorem identity2459 : scanCanonicalize (H12AffineFastState.compose env2459 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2459 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2460 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,12312,8541,8574,12360,262144,1024,8541,5376,32,16,35,8224,65,262176,12312,4177,2081,1025,0,256,1,12361,512]

theorem envBound2460 : H12AffineFastState.Bounded env2460 := by
  intro p hp
  have h : env2460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2459_2460 : H12AffineEnvironment.transform 6 40 env2459 = env2460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2459 == env2460) = true)

theorem identity2460 : scanCanonicalize (H12AffineFastState.compose env2460 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2460 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2461 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,12312,8460,8495,12313,262144,1024,8460,5376,32,16,35,8224,16,262176,12312,4096,2081,1025,0,256,1,12312,512]

theorem envBound2461 : H12AffineFastState.Bounded env2461 := by
  intro p hp
  have h : env2461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2460_2461 : H12AffineEnvironment.transform 5 17 env2460 = env2461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2460 == env2461) = true)

theorem identity2461 : scanCanonicalize (H12AffineFastState.compose env2461 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8983) := by decide +kernel

theorem selectedBound2461 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2462 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,12312,8460,8495,12313,8983,1024,8460,5376,32,16,35,8224,16,9015,12312,4096,2081,1025,0,256,1,12312,512]

theorem envBound2462 : H12AffineFastState.Bounded env2462 := by
  intro p hp
  have h : env2462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2461_2462 : H12AffineEnvironment.transform 17 8983 env2461 = env2462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8983 env2461 == env2462) = true)

theorem identity2462 : scanCanonicalize (H12AffineFastState.compose env2462 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2870) := by decide +kernel

theorem selectedBound2462 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env2463 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,2870,6958,2618,2585,6959,2081,1024,2618,5376,32,16,35,2838,16,2049,6958,4096,2081,1025,0,256,1,6958,512]

theorem envBound2463 : H12AffineFastState.Bounded env2463 := by
  intro p hp
  have h : env2463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2462_2463 : H12AffineEnvironment.transform 12 2870 env2462 = env2463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2870 env2462 == env2463) = true)

theorem identity2463 : scanCanonicalize (H12AffineFastState.compose env2463 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound2463 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env2464 : List Nat := [2,4,8,16,32,17,40,256,512,1024,529,4096,295,4415,43,8,4414,560,1024,43,5376,32,16,35,263,16,528,4415,4096,560,1025,0,256,1,4415,512]

theorem envBound2464 : H12AffineFastState.Bounded env2464 := by
  intro p hp
  have h : env2464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2463_2464 : H12AffineEnvironment.transform 10 529 env2463 = env2464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env2463 == env2464) = true)

theorem identity2464 : scanCanonicalize (H12AffineFastState.compose env2464 (packedSelected [1,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound2464 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env2465 : List Nat := [2,4,8,16,32,17,40,256,48,1024,33,4096,295,4415,43,8,4414,0,1024,43,5376,32,16,35,263,16,32,4415,4096,0,1025,0,256,1,4415,48]

theorem envBound2465 : H12AffineFastState.Bounded env2465 := by
  intro p hp
  have h : env2465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2464_2465 : H12AffineEnvironment.transform 8 48 env2464 = env2465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env2464 == env2465) = true)

theorem identity2465 : scanCanonicalize (H12AffineFastState.compose env2465 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound2465 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env2466 : List Nat := [2,4,8,16,32,17,40,256,48,1024,33,1280,295,1087,43,8,1086,0,1024,43,0,32,16,35,263,16,32,1087,1280,0,1025,0,256,1,1087,48]

theorem envBound2466 : H12AffineFastState.Bounded env2466 := by
  intro p hp
  have h : env2466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2465_2466 : H12AffineEnvironment.transform 11 1280 env2465 = env2466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env2465 == env2466) = true)

theorem identity2466 : scanCanonicalize (H12AffineFastState.compose env2466 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound2466 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env2467 : List Nat := [2,4,8,16,32,17,40,256,48,37,33,293,295,26,43,8,27,0,37,43,0,32,16,35,263,16,32,26,293,0,36,0,256,1,26,48]

theorem envBound2467 : H12AffineFastState.Bounded env2467 := by
  intro p hp
  have h : env2467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2466_2467 : H12AffineEnvironment.transform 9 37 env2466 = env2467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env2466 == env2467) = true)

theorem identity2467 : scanCanonicalize (H12AffineFastState.compose env2467 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound2467 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env2468 : List Nat := [2,4,8,16,16,17,24,256,0,21,17,277,279,26,27,8,27,0,21,27,0,16,16,19,263,16,16,26,277,0,20,0,256,1,26,0]

theorem envBound2468 : H12AffineFastState.Bounded env2468 := by
  intro p hp
  have h : env2468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2467_2468 : H12AffineEnvironment.transform 4 16 env2467 = env2468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2467 == env2468) = true)

theorem identity2468 : scanCanonicalize (H12AffineFastState.compose env2468 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound2468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2469 : List Nat := [2,4,8,16,16,17,24,2,0,21,17,23,21,26,27,8,27,0,21,27,0,16,16,19,5,16,16,26,23,0,20,0,2,1,26,0]

theorem envBound2469 : H12AffineFastState.Bounded env2469 := by
  intro p hp
  have h : env2469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2468_2469 : H12AffineEnvironment.transform 7 2 env2468 = env2469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env2468 == env2469) = true)

theorem identity2469 : scanCanonicalize (H12AffineFastState.compose env2469 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound2469 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env2470 : List Nat := [2,4,8,11,11,10,3,2,0,14,10,12,14,1,0,8,0,0,14,0,0,11,11,8,5,11,11,1,12,0,15,0,2,1,1,0]

theorem envBound2470 : H12AffineFastState.Bounded env2470 := by
  intro p hp
  have h : env2470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2469_2470 : H12AffineEnvironment.transform 3 11 env2469 = env2470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env2469 == env2470) = true)

theorem identity2470 : scanCanonicalize (H12AffineFastState.compose env2470 (packedSelected [1,11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2470 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env2471 : List Nat := [2,2,8,11,11,10,3,2,0,8,10,10,8,1,0,8,0,0,8,0,0,11,11,8,3,11,11,1,10,0,9,0,2,1,1,0]

theorem envBound2471 : H12AffineFastState.Bounded env2471 := by
  intro p hp
  have h : env2471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2470_2471 : H12AffineEnvironment.transform 1 2 env2470 = env2471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2470 == env2471) = true)

theorem identity2471 : scanCanonicalize (H12AffineFastState.compose env2471 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound2471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2472 : List Nat := [2,2,2,1,1,0,3,2,0,2,0,0,2,1,0,2,0,0,2,0,0,1,1,2,3,1,1,1,0,0,3,0,2,1,1,0]

theorem envBound2472 : H12AffineFastState.Bounded env2472 := by
  intro p hp
  have h : env2472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2471_2472 : H12AffineEnvironment.transform 2 2 env2471 = env2472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env2471 == env2472) = true)

def env2473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,153080,33,147520,139,8328,147473,409816,16384,151553,2081,75135,147705,256,1,131073,148216]

theorem envBound2473 : H12AffineFastState.Bounded env2473 := by
  intro p hp
  have h : env2473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2455_2473 : H12AffineEnvironment.transform 21 33 env2455 = env2473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env2455 == env2473) = true)

theorem identity2473 : scanCanonicalize (H12AffineFastState.compose env2473 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2473 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,153080,33,147520,139,8328,147473,409816,16384,151553,2081,1025,147705,256,1,131073,148216]

theorem envBound2474 : H12AffineFastState.Bounded env2474 := by
  intro p hp
  have h : env2474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2473_2474 : H12AffineEnvironment.transform 15 8574 env2473 = env2474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2473 == env2474) = true)

theorem identity2474 : scanCanonicalize (H12AffineFastState.compose env2474 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound2474 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1024,8693,5376,33,184,139,8328,233,262176,16384,4345,2081,1025,1,256,1,16633,512]

theorem envBound2475 : H12AffineFastState.Bounded env2475 := by
  intro p hp
  have h : env2475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2474_2475 : H12AffineEnvironment.transform 16 16632 env2474 = env2475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2474 == env2475) = true)

def env2476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,34359738368,16925298]

theorem envBound2476 : H12AffineFastState.Bounded env2476 := by
  intro p hp
  have h : env2476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2432_2476 : H12AffineEnvironment.transform 18 1025 env2432 = env2476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2432 == env2476) = true)

def env2477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,131072,16925298]

theorem envBound2477 : H12AffineFastState.Bounded env2477 := by
  intro p hp
  have h : env2477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2476_2477 : H12AffineEnvironment.transform 34 131072 env2476 = env2477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2476 == env2477) = true)

theorem identity2477 : scanCanonicalize (H12AffineFastState.compose env2477 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 16435) := by decide +kernel

theorem selectedBound2477 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16435,8328,147472,409817,16384,151553,2081,91590,4341977,257,1,131072,131649]

theorem envBound2478 : H12AffineFastState.Bounded env2478 := by
  intro p hp
  have h : env2478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2477_2478 : H12AffineEnvironment.transform 23 16435 env2477 = env2478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 16435 env2477 == env2478) = true)

theorem identity2478 : scanCanonicalize (H12AffineFastState.compose env2478 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound2478 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,293,147520,16435,8328,147472,409817,16384,151553,2081,91590,147964,257,1,131072,131649]

theorem envBound2479 : H12AffineFastState.Bounded env2479 := by
  intro p hp
  have h : env2479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2478_2479 : H12AffineEnvironment.transform 21 293 env2478 = env2479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env2478 == env2479) = true)

def env2480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,64,262144,1025,8693,2097152,293,16384,16435,8328,16464,278681,16384,20545,2081,91590,16828,257,1,64,513]

theorem envBound2480 : H12AffineFastState.Bounded env2480 := by
  intro p hp
  have h : env2480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2479_2480 : H12AffineEnvironment.transform 16 64 env2479 = env2480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 64 env2479 == env2480) = true)

theorem identity2480 : scanCanonicalize (H12AffineFastState.compose env2480 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4436) := by decide +kernel

theorem selectedBound2480 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,64,262144,1025,8693,4436,293,16384,16435,8328,16464,278681,16384,20545,2081,91590,16828,257,1,64,513]

theorem envBound2481 : H12AffineFastState.Bounded env2481 := by
  intro p hp
  have h : env2481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2480_2481 : H12AffineEnvironment.transform 20 4436 env2480 = env2481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4436 env2480 == env2481) = true)

theorem identity2481 : scanCanonicalize (H12AffineFastState.compose env2481 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound2481 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,64,262144,1025,8693,4436,293,16384,16435,8328,16464,278681,16384,20545,2081,1285,16828,257,1,64,513]

theorem envBound2482 : H12AffineFastState.Bounded env2482 := by
  intro p hp
  have h : env2482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2481_2482 : H12AffineEnvironment.transform 15 24771 env2481 = env2482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env2481 == env2482) = true)

theorem identity2482 : scanCanonicalize (H12AffineFastState.compose env2482 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2482 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2483 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,24771,64,262144,1025,8201,4264,217,16384,16435,8328,16464,278681,16384,20545,2081,1273,16448,253,1,64,513]

theorem envBound2483 : H12AffineFastState.Bounded env2483 := by
  intro p hp
  have h : env2483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2482_2483 : H12AffineEnvironment.transform 7 252 env2482 = env2483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2482 == env2483) = true)

theorem identity2483 : scanCanonicalize (H12AffineFastState.compose env2483 (packedSelected [1,3,4,9,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 65) := by decide +kernel

theorem selectedBound2483 : packedSelected [1,3,4,9,20,24,28] rootPS < 2^1333 := by decide +kernel

def env2484 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,65,8201,8322,64,262144,1025,8201,4264,217,65,114,8328,17,262360,65,4096,2081,1273,1,253,1,64,513]

theorem envBound2484 : H12AffineFastState.Bounded env2484 := by
  intro p hp
  have h : env2484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2483_2484 : H12AffineEnvironment.transform 13 65 env2483 = env2484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 65 env2483 == env2484) = true)

theorem identity2484 : scanCanonicalize (H12AffineFastState.compose env2484 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 248) := by decide +kernel

theorem selectedBound2484 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2485 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,248,8192,65,8201,8322,64,262144,1025,8201,80,217,65,114,8328,17,262360,65,248,2081,1273,1,253,1,64,513]

theorem envBound2485 : H12AffineFastState.Bounded env2485 := by
  intro p hp
  have h : env2485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2484_2485 : H12AffineEnvironment.transform 11 248 env2484 = env2485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 248 env2484 == env2485) = true)

theorem identity2485 : scanCanonicalize (H12AffineFastState.compose env2485 (packedSelected [0,1,4,7,8,9,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound2485 : packedSelected [0,1,4,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2486 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,248,1069,65,1060,1199,64,262144,1025,1060,80,217,65,114,1189,17,262360,65,248,2081,1273,1,253,1,64,513]

theorem envBound2486 : H12AffineFastState.Bounded env2486 := by
  intro p hp
  have h : env2486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2485_2486 : H12AffineEnvironment.transform 12 1069 env2485 = env2486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env2485 == env2486) = true)

theorem identity2486 : scanCanonicalize (H12AffineFastState.compose env2486 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound2486 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2487 : List Nat := [2,4,8,16,32,64,128,252,512,140,2048,248,161,65,168,35,64,262144,141,168,80,217,65,114,41,17,262360,65,248,2081,117,1,253,1,64,513]

theorem envBound2487 : H12AffineFastState.Bounded env2487 := by
  intro p hp
  have h : env2487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2486_2487 : H12AffineEnvironment.transform 9 140 env2486 = env2487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env2486 == env2487) = true)

theorem identity2487 : scanCanonicalize (H12AffineFastState.compose env2487 (packedSelected [0,7,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound2487 : packedSelected [0,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env2488 : List Nat := [2,4,8,16,32,64,89,37,512,85,2048,33,120,65,113,35,64,262144,84,113,80,0,65,114,41,17,262145,65,33,2081,117,1,36,1,64,513]

theorem envBound2488 : H12AffineFastState.Bounded env2488 := by
  intro p hp
  have h : env2488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2487_2488 : H12AffineEnvironment.transform 6 89 env2487 = env2488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env2487 == env2488) = true)

theorem identity2488 : scanCanonicalize (H12AffineFastState.compose env2488 (packedSelected [0,1,3,5,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound2488 : packedSelected [0,1,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2489 : List Nat := [2,4,8,16,32,64,89,37,512,85,48,33,120,65,113,35,64,262144,84,113,80,0,65,114,41,17,262145,65,33,17,117,1,36,1,64,513]

theorem envBound2489 : H12AffineFastState.Bounded env2489 := by
  intro p hp
  have h : env2489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2488_2489 : H12AffineEnvironment.transform 10 48 env2488 = env2489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env2488 == env2489) = true)

theorem identity2489 : scanCanonicalize (H12AffineFastState.compose env2489 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 618) := by decide +kernel

theorem selectedBound2489 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env2490 : List Nat := [2,4,8,16,32,64,89,37,512,85,48,33,120,65,113,35,64,618,84,113,80,0,65,114,41,17,619,65,33,17,117,1,36,1,64,513]

theorem envBound2490 : H12AffineFastState.Bounded env2490 := by
  intro p hp
  have h : env2490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2489_2490 : H12AffineEnvironment.transform 17 618 env2489 = env2490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 618 env2489 == env2490) = true)

theorem identity2490 : scanCanonicalize (H12AffineFastState.compose env2490 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2490 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env2491 : List Nat := [2,4,8,16,32,17,8,37,512,4,48,33,41,16,32,35,17,571,5,32,1,0,16,35,41,17,570,16,33,17,36,1,36,1,17,513]

theorem envBound2491 : H12AffineFastState.Bounded env2491 := by
  intro p hp
  have h : env2491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2490_2491 : H12AffineEnvironment.transform 5 17 env2490 = env2491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2490 == env2491) = true)

theorem identity2491 : scanCanonicalize (H12AffineFastState.compose env2491 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound2491 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env2492 : List Nat := [2,4,8,16,32,17,8,37,54,4,48,33,41,16,32,35,17,13,5,32,1,0,16,35,41,17,12,16,33,17,36,1,36,1,17,55]

theorem envBound2492 : H12AffineFastState.Bounded env2492 := by
  intro p hp
  have h : env2492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2491_2492 : H12AffineEnvironment.transform 8 54 env2491 = env2492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env2491 == env2492) = true)

theorem identity2492 : scanCanonicalize (H12AffineFastState.compose env2492 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2492 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env2493 : List Nat := [2,4,8,16,1,17,8,4,23,4,17,0,8,16,1,2,17,13,5,1,1,0,16,2,8,17,12,16,0,17,5,1,5,1,17,22]

theorem envBound2493 : H12AffineFastState.Bounded env2493 := by
  intro p hp
  have h : env2493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2492_2493 : H12AffineEnvironment.transform 4 1 env2492 = env2493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2492 == env2493) = true)

theorem identity2493 : scanCanonicalize (H12AffineFastState.compose env2493 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2494 : List Nat := [2,4,8,0,1,1,8,4,7,4,1,0,8,0,1,2,1,13,5,1,1,0,0,2,8,1,12,0,0,1,5,1,5,1,1,6]

theorem envBound2494 : H12AffineFastState.Bounded env2494 := by
  intro p hp
  have h : env2494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2493_2494 : H12AffineEnvironment.transform 3 0 env2493 = env2494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2493 == env2494) = true)

theorem identity2494 : scanCanonicalize (H12AffineFastState.compose env2494 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound2494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2495 : List Nat := [2,4,7,0,1,1,7,4,7,4,1,0,7,0,1,2,1,2,5,1,1,0,0,2,7,1,3,0,0,1,5,1,5,1,1,6]

theorem envBound2495 : H12AffineFastState.Bounded env2495 := by
  intro p hp
  have h : env2495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2494_2495 : H12AffineEnvironment.transform 2 7 env2494 = env2495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env2494 == env2495) = true)

theorem identity2495 : scanCanonicalize (H12AffineFastState.compose env2495 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2495 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2496 : List Nat := [2,2,1,0,1,1,1,2,1,2,1,0,1,0,1,2,1,2,3,1,1,0,0,2,1,1,3,0,0,1,3,1,3,1,1,0]

theorem envBound2496 : H12AffineFastState.Bounded env2496 := by
  intro p hp
  have h : env2496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2495_2496 : H12AffineEnvironment.transform 1 2 env2495 = env2496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2495 == env2496) = true)

def env2497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,65,262144,1025,8693,2097152,293,16385,16435,8328,16465,278680,16384,20544,2081,91590,16829,257,1,65,512]

theorem envBound2497 : H12AffineFastState.Bounded env2497 := by
  intro p hp
  have h : env2497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2479_2497 : H12AffineEnvironment.transform 16 65 env2479 = env2497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 65 env2479 == env2497) = true)

theorem identity2497 : scanCanonicalize (H12AffineFastState.compose env2497 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2497 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2498 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,65536,65,262144,1025,8432,2097152,32,16385,16435,8328,16465,278680,16384,20544,2081,91331,16568,4,1,65,512]

theorem envBound2498 : H12AffineFastState.Bounded env2498 := by
  intro p hp
  have h : env2498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2497_2498 : H12AffineEnvironment.transform 7 5 env2497 = env2498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2497 == env2498) = true)

theorem identity2498 : scanCanonicalize (H12AffineFastState.compose env2498 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2498 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2499 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,65,262144,1025,8432,2097152,32,16385,16435,8328,16465,278680,16384,20544,2081,17593,16568,4,1,65,512]

theorem envBound2499 : H12AffineFastState.Bounded env2499 := by
  intro p hp
  have h : env2499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2498_2499 : H12AffineEnvironment.transform 15 8314 env2498 = env2499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2498 == env2499) = true)

theorem identity2499 : scanCanonicalize (H12AffineFastState.compose env2499 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound2499 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2500 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8432,8314,65,262144,1025,8432,2097152,32,184,138,8328,232,262177,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2500 : H12AffineFastState.Bounded env2500 := by
  intro p hp
  have h : env2500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2499_2500 : H12AffineEnvironment.transform 13 185 env2499 = env2500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env2499 == env2500) = true)

theorem identity2500 : scanCanonicalize (H12AffineFastState.compose env2500 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 11438) := by decide +kernel

theorem selectedBound2500 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2501 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8432,8314,65,262144,1025,8432,11438,32,184,138,8328,232,262177,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2501 : H12AffineFastState.Bounded env2501 := by
  intro p hp
  have h : env2501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2500_2501 : H12AffineEnvironment.transform 20 11438 env2500 = env2501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11438 env2500 == env2501) = true)

theorem identity2501 : scanCanonicalize (H12AffineFastState.compose env2501 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2501 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2502 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8432,8314,65,2265,1025,8432,11438,32,184,138,8328,232,2296,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2502 : H12AffineFastState.Bounded env2502 := by
  intro p hp
  have h : env2502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2501_2502 : H12AffineEnvironment.transform 17 2265 env2501 = env2502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2501 == env2502) = true)

theorem identity2502 : scanCanonicalize (H12AffineFastState.compose env2502 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2502 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2503 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,65,8200,8314,65,2081,1025,8200,11350,32,64,114,8304,16,2048,65,4097,2081,1024,1,4,1,65,512]

theorem envBound2503 : H12AffineFastState.Bounded env2503 := by
  intro p hp
  have h : env2503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2502_2503 : H12AffineEnvironment.transform 6 120 env2502 = env2503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2502 == env2503) = true)

theorem identity2503 : scanCanonicalize (H12AffineFastState.compose env2503 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2504 : List Nat := [2,4,8,16,32,1,57,5,512,1024,2048,4096,8192,0,8200,8251,0,2081,1025,8200,11287,32,1,51,8241,16,2048,0,4097,2081,1024,1,4,1,0,512]

theorem envBound2504 : H12AffineFastState.Bounded env2504 := by
  intro p hp
  have h : env2504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2503_2504 : H12AffineEnvironment.transform 5 1 env2503 = env2504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2503 == env2504) = true)

theorem identity2504 : scanCanonicalize (H12AffineFastState.compose env2504 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound2504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2505 : List Nat := [2,4,8,16,32,1,57,5,512,1024,42,4096,8192,0,8200,8251,0,11,1025,8200,9277,32,1,51,8241,16,42,0,4097,11,1024,1,4,1,0,512]

theorem envBound2505 : H12AffineFastState.Bounded env2505 := by
  intro p hp
  have h : env2505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2504_2505 : H12AffineEnvironment.transform 10 42 env2504 = env2505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env2504 == env2505) = true)

theorem identity2505 : scanCanonicalize (H12AffineFastState.compose env2505 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2505 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2506 : List Nat := [2,4,8,16,32,1,57,5,512,1024,42,4096,1030,0,1038,1085,0,11,1025,1038,59,32,1,51,1079,16,42,0,4097,11,1024,1,4,1,0,512]

theorem envBound2506 : H12AffineFastState.Bounded env2506 := by
  intro p hp
  have h : env2506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2505_2506 : H12AffineEnvironment.transform 12 1030 env2505 = env2506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2505 == env2506) = true)

theorem identity2506 : scanCanonicalize (H12AffineFastState.compose env2506 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound2506 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2507 : List Nat := [2,4,8,16,16,1,9,5,512,1024,26,4096,1030,0,1038,1037,0,11,1025,1038,11,16,1,3,1031,16,26,0,4097,11,1024,1,4,1,0,512]

theorem envBound2507 : H12AffineFastState.Bounded env2507 := by
  intro p hp
  have h : env2507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2506_2507 : H12AffineEnvironment.transform 4 16 env2506 = env2507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2506 == env2507) = true)

theorem identity2507 : scanCanonicalize (H12AffineFastState.compose env2507 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2507 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2508 : List Nat := [2,4,8,0,0,1,9,5,512,1024,10,4096,1030,0,1038,1037,0,11,1025,1038,11,0,1,3,1031,0,10,0,4097,11,1024,1,4,1,0,512]

theorem envBound2508 : H12AffineFastState.Bounded env2508 := by
  intro p hp
  have h : env2508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2507_2508 : H12AffineEnvironment.transform 3 0 env2507 = env2508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2507 == env2508) = true)

def env2509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,131073,16925298]

theorem envBound2509 : H12AffineFastState.Bounded env2509 := by
  intro p hp
  have h : env2509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2476_2509 : H12AffineEnvironment.transform 34 131073 env2476 = env2509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2476 == env2509) = true)

theorem identity2509 : scanCanonicalize (H12AffineFastState.compose env2509 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2117683) := by decide +kernel

theorem selectedBound2509 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,2117683,8328,147472,409817,16384,151553,2081,2192838,4341977,257,1,131073,2232897]

theorem envBound2510 : H12AffineFastState.Bounded env2510 := by
  intro p hp
  have h : env2510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2509_2510 : H12AffineEnvironment.transform 23 2117683 env2509 = env2510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2117683 env2509 == env2510) = true)

theorem identity2510 : scanCanonicalize (H12AffineFastState.compose env2510 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2510 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,4194304,147520,2117683,8328,147472,409817,16384,151553,2081,2119100,4341977,257,1,131073,2232897]

theorem envBound2511 : H12AffineFastState.Bounded env2511 := by
  intro p hp
  have h : env2511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2510_2511 : H12AffineEnvironment.transform 15 8314 env2510 = env2511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2510 == env2511) = true)

def env2512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,135232,4194304,147520,147571,8328,147472,409817,16384,151553,2081,148988,4341977,257,1,131073,513]

theorem envBound2512 : H12AffineFastState.Bounded env2512 := by
  intro p hp
  have h : env2512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2511_2512 : H12AffineEnvironment.transform 20 135232 env2511 = env2512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135232 env2511 == env2512) = true)

theorem identity2512 : scanCanonicalize (H12AffineFastState.compose env2512 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 131121) := by decide +kernel

theorem selectedBound2512 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,135232,131121,147520,147571,8328,147472,409817,16384,151553,2081,148988,16616,257,1,131073,513]

theorem envBound2513 : H12AffineFastState.Bounded env2513 := by
  intro p hp
  have h : env2513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2512_2513 : H12AffineEnvironment.transform 21 131121 env2512 = env2513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 131121 env2512 == env2513) = true)

theorem identity2513 : scanCanonicalize (H12AffineFastState.compose env2513 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound2513 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8693,8314,131072,262144,1025,8693,135232,131121,131501,131486,8328,131581,393524,493,135660,2081,132113,261,257,1,131073,513]

theorem envBound2514 : H12AffineFastState.Bounded env2514 := by
  intro p hp
  have h : env2514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2513_2514 : H12AffineEnvironment.transform 13 493 env2513 = env2514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env2513 == env2514) = true)

theorem identity2514 : scanCanonicalize (H12AffineFastState.compose env2514 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 233) := by decide +kernel

theorem selectedBound2514 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8693,8314,233,262144,1025,8693,4265,216,324,375,8328,276,262621,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2515 : H12AffineFastState.Bounded env2515 := by
  intro p hp
  have h : env2515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2514_2515 : H12AffineEnvironment.transform 16 233 env2514 = env2515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 233 env2514 == env2515) = true)

theorem identity2515 : scanCanonicalize (H12AffineFastState.compose env2515 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1520) := by decide +kernel

theorem selectedBound2515 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1520,493,1029,1418,233,262144,1025,1029,4265,216,324,375,1400,276,262621,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2516 : H12AffineFastState.Bounded env2516 := by
  intro p hp
  have h : env2516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2515_2516 : H12AffineEnvironment.transform 12 1520 env2515 = env2516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1520 env2515 == env2516) = true)

theorem identity2516 : scanCanonicalize (H12AffineFastState.compose env2516 (packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2516 : packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env2517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1520,493,1029,1418,233,2265,1025,1029,4265,216,324,375,1400,276,2308,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2517 : H12AffineFastState.Bounded env2517 := by
  intro p hp
  have h : env2517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2516_2517 : H12AffineEnvironment.transform 17 2265 env2516 = env2517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2516 == env2517) = true)

theorem identity2517 : scanCanonicalize (H12AffineFastState.compose env2517 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound2517 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env2518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,169,4096,1520,493,1029,1418,233,112,1025,1029,4265,216,324,375,1400,276,429,493,4357,136,1272,261,257,1,232,513]

theorem envBound2518 : H12AffineFastState.Bounded env2518 := by
  intro p hp
  have h : env2518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2517_2518 : H12AffineEnvironment.transform 10 169 env2517 = env2518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env2517 == env2518) = true)

theorem identity2518 : scanCanonicalize (H12AffineFastState.compose env2518 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound2518 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env2519 : List Nat := [2,4,8,16,32,64,128,256,512,288,169,4096,208,493,293,170,233,112,289,293,4265,216,324,375,88,276,429,493,4357,136,472,261,257,1,232,513]

theorem envBound2519 : H12AffineFastState.Bounded env2519 := by
  intro p hp
  have h : env2519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2518_2519 : H12AffineEnvironment.transform 9 288 env2518 = env2519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env2518 == env2519) = true)

theorem identity2519 : scanCanonicalize (H12AffineFastState.compose env2519 (packedSelected [1,2,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound2519 : packedSelected [1,2,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env2520 : List Nat := [2,4,8,16,32,64,128,256,43,288,169,4096,208,493,293,170,233,112,289,293,4265,216,324,375,88,276,429,493,4357,136,472,261,257,1,232,42]

theorem envBound2520 : H12AffineFastState.Bounded env2520 := by
  intro p hp
  have h : env2520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2519_2520 : H12AffineEnvironment.transform 8 43 env2519 = env2520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env2519 == env2520) = true)

theorem identity2520 : scanCanonicalize (H12AffineFastState.compose env2520 (packedSelected [0,1,2,3,5,7,8,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound2520 : packedSelected [0,1,2,3,5,7,8,13,17] rootPS < 2^1333 := by decide +kernel

def env2521 : List Nat := [2,4,8,16,32,64,128,256,43,288,169,1,208,493,293,170,233,112,289,293,168,216,324,375,88,276,429,493,260,136,472,261,257,1,232,42]

theorem envBound2521 : H12AffineFastState.Bounded env2521 := by
  intro p hp
  have h : env2521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2520_2521 : H12AffineEnvironment.transform 11 1 env2520 = env2521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env2520 == env2521) = true)

theorem identity2521 : scanCanonicalize (H12AffineFastState.compose env2521 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound2521 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env2522 : List Nat := [2,4,8,16,32,64,128,117,43,85,169,1,208,152,80,170,233,112,84,80,168,216,49,2,88,97,216,152,113,136,173,112,116,1,232,42]

theorem envBound2522 : H12AffineFastState.Bounded env2522 := by
  intro p hp
  have h : env2522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2521_2522 : H12AffineEnvironment.transform 7 117 env2521 = env2522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env2521 == env2522) = true)

theorem identity2522 : scanCanonicalize (H12AffineFastState.compose env2522 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound2522 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2523 : List Nat := [2,4,8,16,32,49,128,4,43,36,169,1,161,152,33,170,152,1,37,33,168,169,49,2,41,16,169,152,0,136,173,1,5,1,153,42]

theorem envBound2523 : H12AffineFastState.Bounded env2523 := by
  intro p hp
  have h : env2523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2522_2523 : H12AffineEnvironment.transform 5 49 env2522 = env2523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env2522 == env2523) = true)

theorem identity2523 : scanCanonicalize (H12AffineFastState.compose env2523 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2523 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2524 : List Nat := [2,4,8,16,1,16,128,4,10,5,136,1,128,152,0,139,152,1,4,0,137,136,16,2,8,16,136,152,0,136,140,1,5,1,153,11]

theorem envBound2524 : H12AffineFastState.Bounded env2524 := by
  intro p hp
  have h : env2524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2523_2524 : H12AffineEnvironment.transform 4 1 env2523 = env2524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2523 == env2524) = true)

theorem identity2524 : scanCanonicalize (H12AffineFastState.compose env2524 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 23) := by decide +kernel

theorem selectedBound2524 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2525 : List Nat := [2,4,8,16,1,16,23,4,10,5,31,1,23,15,0,28,15,1,4,0,30,31,16,2,8,16,31,15,0,31,27,1,5,1,14,11]

theorem envBound2525 : H12AffineFastState.Bounded env2525 := by
  intro p hp
  have h : env2525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2524_2525 : H12AffineEnvironment.transform 6 23 env2524 = env2525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 23 env2524 == env2525) = true)

theorem identity2525 : scanCanonicalize (H12AffineFastState.compose env2525 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2525 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env2526 : List Nat := [2,4,8,13,1,13,10,4,10,5,2,1,10,15,0,1,15,1,4,0,3,2,13,2,8,13,2,15,0,2,6,1,5,1,14,11]

theorem envBound2526 : H12AffineFastState.Bounded env2526 := by
  intro p hp
  have h : env2526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2525_2526 : H12AffineEnvironment.transform 3 13 env2525 = env2526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2525 == env2526) = true)

theorem identity2526 : scanCanonicalize (H12AffineFastState.compose env2526 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2526 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env2527 : List Nat := [0,4,8,13,1,13,8,4,8,5,0,1,8,13,0,1,13,1,4,0,1,0,13,0,8,13,0,13,0,0,4,1,5,1,12,9]

theorem envBound2527 : H12AffineFastState.Bounded env2527 := by
  intro p hp
  have h : env2527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2526_2527 : H12AffineEnvironment.transform 0 0 env2526 = env2527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2526 == env2527) = true)

theorem identity2527 : scanCanonicalize (H12AffineFastState.compose env2527 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2528 : List Nat := [0,4,5,0,1,0,5,4,5,5,0,1,5,0,0,1,0,1,4,0,1,0,0,0,5,0,0,0,0,0,4,1,5,1,1,4]

theorem envBound2528 : H12AffineFastState.Bounded env2528 := by
  intro p hp
  have h : env2528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2527_2528 : H12AffineEnvironment.transform 2 5 env2527 = env2528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2527 == env2528) = true)

theorem identity2528 : scanCanonicalize (H12AffineFastState.compose env2528 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound2528 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2529 : List Nat := [0,0,1,0,1,0,1,0,1,1,0,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,1,1,1,1,0]

theorem envBound2529 : H12AffineFastState.Bounded env2529 := by
  intro p hp
  have h : env2529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2528_2529 : H12AffineEnvironment.transform 1 0 env2528 = env2529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env2528 == env2529) = true)

def env2530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,135233,4194304,147520,147570,8328,147472,409817,16384,151553,2081,148989,4341977,257,1,131073,512]

theorem envBound2530 : H12AffineFastState.Bounded env2530 := by
  intro p hp
  have h : env2530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2511_2530 : H12AffineEnvironment.transform 20 135233 env2511 = env2530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135233 env2511 == env2530) = true)

theorem identity2530 : scanCanonicalize (H12AffineFastState.compose env2530 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound2530 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,135233,32,147520,147570,8328,147472,409817,16384,151553,2081,148989,147705,257,1,131073,512]

theorem envBound2531 : H12AffineFastState.Bounded env2531 := by
  intro p hp
  have h : env2531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2530_2531 : H12AffineEnvironment.transform 21 32 env2530 = env2531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env2530 == env2531) = true)

theorem identity2531 : scanCanonicalize (H12AffineFastState.compose env2531 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2531 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2532 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1025,8432,135233,32,147520,147570,8328,147472,409817,16384,151553,2081,148728,147705,4,1,131073,512]

theorem envBound2532 : H12AffineFastState.Bounded env2532 := by
  intro p hp
  have h : env2532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2531_2532 : H12AffineEnvironment.transform 7 5 env2531 = env2532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2531 == env2532) = true)

theorem identity2532 : scanCanonicalize (H12AffineFastState.compose env2532 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound2532 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2533 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,16633,262144,1025,8432,20664,32,185,139,8328,233,262176,16384,4344,2081,1025,0,4,1,16632,512]

theorem envBound2533 : H12AffineFastState.Bounded env2533 := by
  intro p hp
  have h : env2533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2532_2533 : H12AffineEnvironment.transform 16 16633 env2532 = env2533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2532 == env2533) = true)

theorem identity2533 : scanCanonicalize (H12AffineFastState.compose env2533 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 25822) := by decide +kernel

theorem selectedBound2533 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2534 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,16633,25822,1025,8432,20664,32,185,139,8328,233,25854,16384,4344,2081,1025,0,4,1,16632,512]

theorem envBound2534 : H12AffineFastState.Bounded env2534 := by
  intro p hp
  have h : env2534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2533_2534 : H12AffineEnvironment.transform 17 25822 env2533 = env2534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25822 env2533 == env2534) = true)

theorem identity2534 : scanCanonicalize (H12AffineFastState.compose env2534 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2534 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2535 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,16384,8200,8314,16385,25638,1025,8200,20544,32,65,115,8304,17,25606,16384,4096,2081,1025,0,4,1,16384,512]

theorem envBound2535 : H12AffineFastState.Bounded env2535 := by
  intro p hp
  have h : env2535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2534_2535 : H12AffineEnvironment.transform 6 120 env2534 = env2535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2534 == env2535) = true)

theorem identity2535 : scanCanonicalize (H12AffineFastState.compose env2535 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound2535 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2536 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,72,16384,64,50,16385,17518,1025,64,20544,32,65,115,56,17,17486,16384,4096,2081,1025,0,4,1,16384,512]

theorem envBound2536 : H12AffineFastState.Bounded env2536 := by
  intro p hp
  have h : env2536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2535_2536 : H12AffineEnvironment.transform 12 72 env2535 = env2536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env2535 == env2536) = true)

theorem identity2536 : scanCanonicalize (H12AffineFastState.compose env2536 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2536 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2537 : List Nat := [2,4,8,16,32,0,56,5,512,1024,2048,4096,8,16384,0,50,16385,17454,1025,0,20480,32,1,51,56,17,17422,16384,4096,2081,1025,0,4,1,16384,512]

theorem envBound2537 : H12AffineFastState.Bounded env2537 := by
  intro p hp
  have h : env2537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2536_2537 : H12AffineEnvironment.transform 5 0 env2536 = env2537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2536 == env2537) = true)

theorem identity2537 : scanCanonicalize (H12AffineFastState.compose env2537 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1039) := by decide +kernel

theorem selectedBound2537 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env2538 : List Nat := [2,4,8,16,32,0,56,5,512,1024,2048,1039,8,16384,0,50,16385,17454,1025,0,17423,32,1,51,56,17,17422,16384,1039,2081,1025,0,4,1,16384,512]

theorem envBound2538 : H12AffineFastState.Bounded env2538 := by
  intro p hp
  have h : env2538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2537_2538 : H12AffineEnvironment.transform 11 1039 env2537 = env2538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1039 env2537 == env2538) = true)

theorem identity2538 : scanCanonicalize (H12AffineFastState.compose env2538 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound2538 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env2539 : List Nat := [2,4,8,10,32,0,34,5,512,1024,2048,1039,8,16384,0,40,16385,17454,1025,0,17423,32,1,41,34,11,17422,16384,1039,2081,1025,0,4,1,16384,512]

theorem envBound2539 : H12AffineFastState.Bounded env2539 := by
  intro p hp
  have h : env2539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2538_2539 : H12AffineEnvironment.transform 3 10 env2538 = env2539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env2538 == env2539) = true)

def env2540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147521,16777216,8328,672784,935129,16384,151553,2081,17375732,4867289,525568,1,34359738368,17450610]

theorem envBound2540 : H12AffineFastState.Bounded env2540 := by
  intro p hp
  have h : env2540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2431_2540 : H12AffineEnvironment.transform 22 147521 env2431 = env2540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env2431 == env2540) = true)

def env2541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2081,16852468,4341977,256,1,34359738368,16925298]

theorem envBound2541 : H12AffineFastState.Bounded env2541 := by
  intro p hp
  have h : env2541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2540_2541 : H12AffineEnvironment.transform 18 1024 env2540 = env2541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2540 == env2541) = true)

def env2542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2081,16852468,4341977,256,1,131072,16925298]

theorem envBound2542 : H12AffineFastState.Bounded env2542 := by
  intro p hp
  have h : env2542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2541_2542 : H12AffineEnvironment.transform 34 131072 env2541 = env2542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2541 == env2542) = true)

theorem identity2542 : scanCanonicalize (H12AffineFastState.compose env2542 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 136483) := by decide +kernel

theorem selectedBound2542 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,136483,8328,147472,409817,16384,151553,2081,209111,4341977,256,1,131072,22353]

theorem envBound2543 : H12AffineFastState.Bounded env2543 := by
  intro p hp
  have h : env2543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2542_2543 : H12AffineEnvironment.transform 23 136483 env2542 = env2543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136483 env2542 == env2543) = true)

theorem identity2543 : scanCanonicalize (H12AffineFastState.compose env2543 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 210167) := by decide +kernel

theorem selectedBound2543 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,210167,147521,136483,8328,147472,409817,16384,151553,2081,209111,95278,256,1,131072,22353]

theorem envBound2544 : H12AffineFastState.Bounded env2544 := by
  intro p hp
  have h : env2544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2543_2544 : H12AffineEnvironment.transform 21 210167 env2543 = env2544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210167 env2543 == env2544) = true)

theorem identity2544 : scanCanonicalize (H12AffineFastState.compose env2544 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2544 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,2097152,136585,147521,136483,8328,147472,409817,16384,151553,2081,135593,21840,256,1,131072,22353]

theorem envBound2545 : H12AffineFastState.Bounded env2545 := by
  intro p hp
  have h : env2545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2544_2545 : H12AffineEnvironment.transform 15 8574 env2544 = env2545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2544 == env2545) = true)

def env2546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8693,8574,131072,262144,1024,8693,2097152,136585,136465,136483,8328,136512,398729,5456,132433,2081,135593,0,256,1,131072,513]

theorem envBound2546 : H12AffineFastState.Bounded env2546 := by
  intro p hp
  have h : env2546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2545_2546 : H12AffineEnvironment.transform 13 5456 env2545 = env2546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env2545 == env2546) = true)

theorem identity2546 : scanCanonicalize (H12AffineFastState.compose env2546 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 132600) := by decide +kernel

theorem selectedBound2546 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8693,8574,131072,262144,1024,8693,132600,136585,136465,136483,8328,136512,398729,5456,132433,2081,135593,0,256,1,131072,513]

theorem envBound2547 : H12AffineFastState.Bounded env2547 := by
  intro p hp
  have h : env2547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2546_2547 : H12AffineEnvironment.transform 20 132600 env2546 = env2547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132600 env2546 == env2547) = true)

theorem identity2547 : scanCanonicalize (H12AffineFastState.compose env2547 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound2547 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env2548 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,8192,5308,8217,8338,131072,262144,1024,8217,132116,136293,136445,136399,8328,136364,398437,5308,132285,2081,135237,0,236,1,131072,513]

theorem envBound2548 : H12AffineFastState.Bounded env2548 := by
  intro p hp
  have h : env2548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2547_2548 : H12AffineEnvironment.transform 7 236 env2547 = env2548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env2547 == env2548) = true)

theorem identity2548 : scanCanonicalize (H12AffineFastState.compose env2548 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound2548 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2549 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,8192,5308,8217,8338,5309,262144,1024,8217,4265,216,64,114,8328,17,262360,5308,4096,2081,1272,0,236,1,5309,513]

theorem envBound2549 : H12AffineFastState.Bounded env2549 := by
  intro p hp
  have h : env2549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2548_2549 : H12AffineEnvironment.transform 16 5309 env2548 = env2549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env2548 == env2549) = true)

theorem identity2549 : scanCanonicalize (H12AffineFastState.compose env2549 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound2549 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2550 : List Nat := [2,4,8,16,32,64,105,5,512,1024,2048,4096,8192,5205,8217,8315,5204,262144,1024,8217,4160,49,64,114,8289,17,262193,5205,4096,2081,1041,0,5,1,5204,513]

theorem envBound2550 : H12AffineFastState.Bounded env2550 := by
  intro p hp
  have h : env2550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2549_2550 : H12AffineEnvironment.transform 6 105 env2549 = env2550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env2549 == env2550) = true)

theorem identity2550 : scanCanonicalize (H12AffineFastState.compose env2550 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound2550 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2551 : List Nat := [2,4,8,16,32,64,105,5,512,1024,2048,4096,25,5205,0,98,5204,262144,1024,0,4160,49,64,114,120,17,262193,5205,4096,2081,1041,0,5,1,5204,513]

theorem envBound2551 : H12AffineFastState.Bounded env2551 := by
  intro p hp
  have h : env2551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2550_2551 : H12AffineEnvironment.transform 12 25 env2550 = env2551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env2550 == env2551) = true)

def env2552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,131072,262144,1024,8693,2097152,136585,136464,136483,8328,136513,398728,5457,132432,2081,135593,1,256,1,131072,512]

theorem envBound2552 : H12AffineFastState.Bounded env2552 := by
  intro p hp
  have h : env2552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2545_2552 : H12AffineEnvironment.transform 13 5457 env2545 = env2552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env2545 == env2552) = true)

theorem identity2552 : scanCanonicalize (H12AffineFastState.compose env2552 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5544) := by decide +kernel

theorem selectedBound2552 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,5544,262144,1024,8693,2097152,33,184,139,8328,233,262176,5457,4344,2081,1025,1,256,1,5544,512]

theorem envBound2553 : H12AffineFastState.Bounded env2553 := by
  intro p hp
  have h : env2553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2552_2553 : H12AffineEnvironment.transform 16 5544 env2552 = env2553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5544 env2552 == env2553) = true)

def env2554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16384,151553,2081,16852468,4341977,256,1,131073,16925298]

theorem envBound2554 : H12AffineFastState.Bounded env2554 := by
  intro p hp
  have h : env2554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2541_2554 : H12AffineEnvironment.transform 34 131073 env2541 = env2554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2541 == env2554) = true)

theorem identity2554 : scanCanonicalize (H12AffineFastState.compose env2554 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2229539) := by decide +kernel

theorem selectedBound2554 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,2229539,8328,147472,409817,16384,151553,2081,2302167,4341977,256,1,131073,2115409]

theorem envBound2555 : H12AffineFastState.Bounded env2555 := by
  intro p hp
  have h : env2555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2554_2555 : H12AffineEnvironment.transform 23 2229539 env2554 = env2555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2229539 env2554 == env2555) = true)

theorem identity2555 : scanCanonicalize (H12AffineFastState.compose env2555 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 132521) := by decide +kernel

theorem selectedBound2555 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,132521,4194304,147521,138,8328,147472,409817,16384,151553,2081,75134,4341977,256,1,131073,148216]

theorem envBound2556 : H12AffineFastState.Bounded env2556 := by
  intro p hp
  have h : env2556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2555_2556 : H12AffineEnvironment.transform 20 132521 env2555 = env2556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132521 env2555 == env2556) = true)

theorem identity2556 : scanCanonicalize (H12AffineFastState.compose env2556 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 147748) := by decide +kernel

theorem selectedBound2556 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env2557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,132521,147748,147521,138,8328,147472,409817,16384,151553,2081,75134,509,256,1,131073,148216]

theorem envBound2557 : H12AffineFastState.Bounded env2557 := by
  intro p hp
  have h : env2557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2556_2557 : H12AffineEnvironment.transform 21 147748 env2556 = env2557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147748 env2556 == env2557) = true)

theorem identity2557 : scanCanonicalize (H12AffineFastState.compose env2557 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2557 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,132521,147748,147521,138,8328,147472,409817,16384,151553,2081,1024,509,256,1,131073,148216]

theorem envBound2558 : H12AffineFastState.Bounded env2558 := by
  intro p hp
  have h : env2558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2557_2558 : H12AffineEnvironment.transform 15 8574 env2557 = env2558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2557 == env2558) = true)

def env2559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1024,8693,17745,476,185,138,8328,232,262177,16384,4345,2081,1024,509,256,1,16633,512]

theorem envBound2559 : H12AffineFastState.Bounded env2559 := by
  intro p hp
  have h : env2559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2558_2559 : H12AffineEnvironment.transform 16 16632 env2558 = env2559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2558 == env2559) = true)

theorem identity2559 : scanCanonicalize (H12AffineFastState.compose env2559 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound2559 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,10281,1024,8693,17745,476,185,138,8328,232,10248,16384,4345,2081,1024,509,256,1,16633,512]

theorem envBound2560 : H12AffineFastState.Bounded env2560 := by
  intro p hp
  have h : env2560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2559_2560 : H12AffineEnvironment.transform 17 10281 env2559 = env2560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env2559 == env2560) = true)

theorem identity2560 : scanCanonicalize (H12AffineFastState.compose env2560 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound2560 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,81,218,16632,2445,1024,81,17745,476,185,138,300,232,2476,16384,4345,2081,1024,509,256,1,16633,512]

theorem envBound2561 : H12AffineFastState.Bounded env2561 := by
  intro p hp
  have h : env2561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2560_2561 : H12AffineEnvironment.transform 12 420 env2560 = env2561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env2560 == env2561) = true)

theorem identity2561 : scanCanonicalize (H12AffineFastState.compose env2561 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound2561 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2562 : List Nat := [2,4,8,16,32,64,128,188,512,1024,2048,4096,24,16384,81,218,16632,2097,1024,81,17645,96,185,138,144,232,2064,16384,4345,2081,1024,65,188,1,16633,512]

theorem envBound2562 : H12AffineFastState.Bounded env2562 := by
  intro p hp
  have h : env2562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2561_2562 : H12AffineEnvironment.transform 7 188 env2561 = env2562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env2561 == env2562) = true)

def env2563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1024,8693,17744,477,184,138,8328,233,262176,16384,4344,2081,1024,509,256,1,16632,513]

theorem envBound2563 : H12AffineFastState.Bounded env2563 := by
  intro p hp
  have h : env2563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2558_2563 : H12AffineEnvironment.transform 16 16633 env2558 = env2563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2558 == env2563) = true)

theorem identity2563 : scanCanonicalize (H12AffineFastState.compose env2563 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13557) := by decide +kernel

theorem selectedBound2563 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13557,8693,8574,13324,262144,1024,8693,12709,477,184,138,8328,233,262176,13557,4344,2081,1024,509,256,1,13325,513]

theorem envBound2564 : H12AffineFastState.Bounded env2564 := by
  intro p hp
  have h : env2564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2563_2564 : H12AffineEnvironment.transform 13 13557 env2563 = env2564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13557 env2563 == env2564) = true)

theorem identity2564 : scanCanonicalize (H12AffineFastState.compose env2564 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound2564 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,9,5372,508,375,5125,262144,1024,508,4524,477,184,138,129,233,262176,5372,4344,2081,1024,509,256,1,5124,513]

theorem envBound2565 : H12AffineFastState.Bounded env2565 := by
  intro p hp
  have h : env2565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2564_2565 : H12AffineEnvironment.transform 12 9 env2564 = env2565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env2564 == env2565) = true)

theorem identity2565 : scanCanonicalize (H12AffineFastState.compose env2565 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound2565 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2566 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,9,5372,232,99,5125,262144,1024,232,4280,201,184,138,129,233,262176,5372,4344,2081,1024,233,20,1,5124,513]

theorem envBound2566 : H12AffineFastState.Bounded env2566 := by
  intro p hp
  have h : env2566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2565_2566 : H12AffineEnvironment.transform 7 20 env2565 = env2566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env2565 == env2566) = true)

theorem identity2566 : scanCanonicalize (H12AffineFastState.compose env2566 (packedSelected [0,1,2,3,5,7,8,11,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound2566 : packedSelected [0,1,2,3,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env2567 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,9,5372,232,99,5125,2185,1024,232,4280,201,184,138,129,233,2217,5372,4344,2081,1024,233,20,1,5124,513]

theorem envBound2567 : H12AffineFastState.Bounded env2567 := by
  intro p hp
  have h : env2567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2566_2567 : H12AffineEnvironment.transform 17 2185 env2566 = env2567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env2566 == env2567) = true)

theorem identity2567 : scanCanonicalize (H12AffineFastState.compose env2567 (packedSelected [2,3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2567 : packedSelected [2,3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env2568 : List Nat := [2,4,8,16,32,64,40,20,512,1024,2048,4096,9,5204,64,99,5125,2081,1024,64,4112,97,16,34,41,65,2049,5204,4176,2081,1024,65,20,1,5124,513]

theorem envBound2568 : H12AffineFastState.Bounded env2568 := by
  intro p hp
  have h : env2568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2567_2568 : H12AffineEnvironment.transform 6 40 env2567 = env2568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2567 == env2568) = true)

theorem identity2568 : scanCanonicalize (H12AffineFastState.compose env2568 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound2568 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env2569 : List Nat := [2,4,8,16,32,16,40,20,512,1024,2048,4096,9,5124,16,51,5125,2081,1024,16,4112,49,16,34,41,17,2049,5124,4096,2081,1024,17,20,1,5124,513]

theorem envBound2569 : H12AffineFastState.Bounded env2569 := by
  intro p hp
  have h : env2569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2568_2569 : H12AffineEnvironment.transform 5 16 env2568 = env2569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2568 == env2569) = true)

theorem identity2569 : scanCanonicalize (H12AffineFastState.compose env2569 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2569 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2570 : List Nat := [2,4,8,0,32,0,40,4,512,1024,2048,4096,9,5124,0,35,5125,2081,1024,0,4096,33,0,34,41,1,2049,5124,4096,2081,1024,1,4,1,5124,513]

theorem envBound2570 : H12AffineFastState.Bounded env2570 := by
  intro p hp
  have h : env2570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2569_2570 : H12AffineEnvironment.transform 3 0 env2569 = env2570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2569 == env2570) = true)

theorem identity2570 : scanCanonicalize (H12AffineFastState.compose env2570 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound2570 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2571 : List Nat := [2,4,8,0,32,0,40,4,512,1024,2048,2090,9,3118,0,35,3119,2081,1024,0,2090,33,0,34,41,1,2049,3118,2090,2081,1024,1,4,1,3118,513]

theorem envBound2571 : H12AffineFastState.Bounded env2571 := by
  intro p hp
  have h : env2571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2570_2571 : H12AffineEnvironment.transform 11 2090 env2570 = env2571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env2570 == env2571) = true)

theorem identity2571 : scanCanonicalize (H12AffineFastState.compose env2571 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound2571 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2572 : List Nat := [2,4,8,0,32,0,40,4,0,1024,2048,2090,9,3118,0,35,3119,2081,1024,0,2090,33,0,34,41,1,2049,3118,2090,2081,1024,1,4,1,3118,1]

theorem envBound2572 : H12AffineFastState.Bounded env2572 := by
  intro p hp
  have h : env2572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2571_2572 : H12AffineEnvironment.transform 8 0 env2571 = env2572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env2571 == env2572) = true)

theorem identity2572 : scanCanonicalize (H12AffineFastState.compose env2572 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound2572 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2573 : List Nat := [2,4,8,0,32,0,40,4,0,1024,1038,1060,9,32,0,35,33,1071,1024,0,1060,33,0,34,41,1,1039,32,1060,1071,1024,1,4,1,32,1]

theorem envBound2573 : H12AffineFastState.Bounded env2573 := by
  intro p hp
  have h : env2573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2572_2573 : H12AffineEnvironment.transform 10 1038 env2572 = env2573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env2572 == env2573) = true)

theorem identity2573 : scanCanonicalize (H12AffineFastState.compose env2573 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound2573 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2574 : List Nat := [2,4,2,0,32,0,34,4,0,1024,1028,1060,3,32,0,35,33,1061,1024,0,1060,33,0,34,35,1,1029,32,1060,1061,1024,1,4,1,32,1]

theorem envBound2574 : H12AffineFastState.Bounded env2574 := by
  intro p hp
  have h : env2574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2573_2574 : H12AffineEnvironment.transform 2 2 env2573 = env2574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env2573 == env2574) = true)

theorem identity2574 : scanCanonicalize (H12AffineFastState.compose env2574 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound2574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2575 : List Nat := [2,4,2,0,32,0,34,4,0,34,38,6,3,32,0,35,33,7,34,0,6,33,0,34,35,1,39,32,6,7,34,1,4,1,32,1]

theorem envBound2575 : H12AffineFastState.Bounded env2575 := by
  intro p hp
  have h : env2575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2574_2575 : H12AffineEnvironment.transform 9 34 env2574 = env2575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env2574 == env2575) = true)

theorem identity2575 : scanCanonicalize (H12AffineFastState.compose env2575 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound2575 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env2576 : List Nat := [2,4,2,0,6,0,4,4,0,4,0,6,3,6,0,5,7,7,4,0,6,7,0,4,5,1,1,6,6,7,4,1,4,1,6,1]

theorem envBound2576 : H12AffineFastState.Bounded env2576 := by
  intro p hp
  have h : env2576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2575_2576 : H12AffineEnvironment.transform 4 6 env2575 = env2576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env2575 == env2576) = true)

theorem identity2576 : scanCanonicalize (H12AffineFastState.compose env2576 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound2576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2577 : List Nat := [2,0,2,0,2,0,0,0,0,0,0,2,3,2,0,1,3,3,0,0,2,3,0,0,1,1,1,2,2,3,0,1,0,1,2,1]

theorem envBound2577 : H12AffineFastState.Bounded env2577 := by
  intro p hp
  have h : env2577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2576_2577 : H12AffineEnvironment.transform 1 0 env2576 = env2577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env2576 == env2577) = true)

def env2578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2081,16852469,4341976,257,1,34359738368,16925299]

theorem envBound2578 : H12AffineFastState.Bounded env2578 := by
  intro p hp
  have h : env2578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2540_2578 : H12AffineEnvironment.transform 18 1025 env2540 = env2578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2540 == env2578) = true)

def env2579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2081,16852469,4341976,257,1,131072,16925299]

theorem envBound2579 : H12AffineFastState.Bounded env2579 := by
  intro p hp
  have h : env2579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2578_2579 : H12AffineEnvironment.transform 34 131072 env2578 = env2579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2578 == env2579) = true)

theorem identity2579 : scanCanonicalize (H12AffineFastState.compose env2579 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4195) := by decide +kernel

theorem selectedBound2579 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,4195,8328,147473,409816,16384,151553,2081,79254,4341976,257,1,131072,152080]

theorem envBound2580 : H12AffineFastState.Bounded env2580 := by
  intro p hp
  have h : env2580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2579_2580 : H12AffineEnvironment.transform 23 4195 env2579 = env2580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195 env2579 == env2580) = true)

theorem identity2580 : scanCanonicalize (H12AffineFastState.compose env2580 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound2580 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,293,147521,4195,8328,147473,409816,16384,151553,2081,79254,147965,257,1,131072,152080]

theorem envBound2581 : H12AffineFastState.Bounded env2581 := by
  intro p hp
  have h : env2581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2580_2581 : H12AffineEnvironment.transform 21 293 env2580 = env2581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env2580 == env2581) = true)

def env2582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,20496,262144,1025,8693,2097152,293,4177,4195,8328,4097,266440,16384,17,2081,79254,4589,257,1,20496,512]

theorem envBound2582 : H12AffineFastState.Bounded env2582 := by
  intro p hp
  have h : env2582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2581_2582 : H12AffineEnvironment.transform 16 20496 env2581 = env2582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 20496 env2581 == env2582) = true)

theorem identity2582 : scanCanonicalize (H12AffineFastState.compose env2582 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2582 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2583 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,65536,20496,262144,1025,8432,2097152,32,4177,4195,8328,4097,266440,16384,17,2081,78995,4328,4,1,20496,512]

theorem envBound2583 : H12AffineFastState.Bounded env2583 := by
  intro p hp
  have h : env2583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2582_2583 : H12AffineEnvironment.transform 7 5 env2582 = env2583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2582 == env2583) = true)

theorem identity2583 : scanCanonicalize (H12AffineFastState.compose env2583 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2583 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2584 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,20496,262144,1025,8432,2097152,32,4177,4195,8328,4097,266440,16384,17,2081,5353,4328,4,1,20496,512]

theorem envBound2584 : H12AffineFastState.Bounded env2584 := by
  intro p hp
  have h : env2584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2583_2584 : H12AffineEnvironment.transform 15 8314 env2583 = env2584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2583 == env2584) = true)

theorem identity2584 : scanCanonicalize (H12AffineFastState.compose env2584 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound2584 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2585 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8432,8314,16632,262144,1025,8432,2097152,32,185,139,8328,233,262176,16384,17,2081,1025,0,4,1,16632,512]

theorem envBound2585 : H12AffineFastState.Bounded env2585 := by
  intro p hp
  have h : env2585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2584_2585 : H12AffineEnvironment.transform 11 232 env2584 = env2585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env2584 == env2585) = true)

theorem identity2585 : scanCanonicalize (H12AffineFastState.compose env2585 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 271478) := by decide +kernel

theorem selectedBound2585 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2586 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8432,8314,16632,262144,1025,8432,271478,32,185,139,8328,233,262176,16384,17,2081,1025,0,4,1,16632,512]

theorem envBound2586 : H12AffineFastState.Bounded env2586 := by
  intro p hp
  have h : env2586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2585_2586 : H12AffineEnvironment.transform 20 271478 env2585 = env2586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 271478 env2585 == env2586) = true)

theorem identity2586 : scanCanonicalize (H12AffineFastState.compose env2586 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2586 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2587 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,16,8192,16384,8200,8314,16384,262144,1025,8200,271478,32,65,115,8304,17,262176,16384,17,2081,1025,0,4,1,16384,512]

theorem envBound2587 : H12AffineFastState.Bounded env2587 := by
  intro p hp
  have h : env2587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2586_2587 : H12AffineEnvironment.transform 6 120 env2586 = env2587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2586 == env2587) = true)

theorem identity2587 : scanCanonicalize (H12AffineFastState.compose env2587 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 1150) := by decide +kernel

theorem selectedBound2587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2588 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,16,8192,16384,8200,8314,16384,1150,1025,8200,8200,32,65,115,8304,17,1118,16384,17,2081,1025,0,4,1,16384,512]

theorem envBound2588 : H12AffineFastState.Bounded env2588 := by
  intro p hp
  have h : env2588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2587_2588 : H12AffineEnvironment.transform 17 1150 env2587 = env2588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1150 env2587 == env2588) = true)

theorem identity2588 : scanCanonicalize (H12AffineFastState.compose env2588 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound2588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2589 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,16,8,16384,0,114,16384,1150,1025,0,0,32,65,115,120,17,1118,16384,17,2081,1025,0,4,1,16384,512]

theorem envBound2589 : H12AffineFastState.Bounded env2589 := by
  intro p hp
  have h : env2589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2588_2589 : H12AffineEnvironment.transform 12 8 env2588 = env2589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env2588 == env2589) = true)

theorem identity2589 : scanCanonicalize (H12AffineFastState.compose env2589 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound2589 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2590 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,16,8,1093,0,114,1093,1150,1025,0,0,32,65,115,120,17,1118,1093,17,2081,1025,0,4,1,1093,512]

theorem envBound2590 : H12AffineFastState.Bounded env2590 := by
  intro p hp
  have h : env2590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2589_2590 : H12AffineEnvironment.transform 13 1093 env2589 = env2590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env2589 == env2590) = true)

theorem identity2590 : scanCanonicalize (H12AffineFastState.compose env2590 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2590 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env2591 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,16,8,1044,0,35,1044,1071,1025,0,0,32,16,34,41,17,1039,1044,17,2081,1025,0,4,1,1044,512]

theorem envBound2591 : H12AffineFastState.Bounded env2591 := by
  intro p hp
  have h : env2591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2590_2591 : H12AffineEnvironment.transform 5 17 env2590 = env2591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2590 == env2591) = true)

theorem identity2591 : scanCanonicalize (H12AffineFastState.compose env2591 (packedSelected [1,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound2591 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env2592 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1039,16,8,1044,0,35,1044,1071,1025,0,0,32,16,34,41,17,1039,1044,17,1070,1025,0,4,1,1044,512]

theorem envBound2592 : H12AffineFastState.Bounded env2592 := by
  intro p hp
  have h : env2592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2591_2592 : H12AffineEnvironment.transform 10 1039 env2591 = env2592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env2591 == env2592) = true)

theorem identity2592 : scanCanonicalize (H12AffineFastState.compose env2592 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2592 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2593 : List Nat := [2,4,8,16,17,17,24,5,512,1024,1039,16,8,1044,0,18,1044,1054,1025,0,0,17,16,19,24,17,1039,1044,17,1055,1025,0,4,1,1044,512]

theorem envBound2593 : H12AffineFastState.Bounded env2593 := by
  intro p hp
  have h : env2593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2592_2593 : H12AffineEnvironment.transform 4 17 env2592 = env2593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2592 == env2593) = true)

def env2594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,20497,262144,1025,8693,2097152,293,4176,4195,8328,4096,266441,16384,16,2081,79254,4588,257,1,20497,513]

theorem envBound2594 : H12AffineFastState.Bounded env2594 := by
  intro p hp
  have h : env2594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2581_2594 : H12AffineEnvironment.transform 16 20497 env2581 = env2594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 20497 env2581 == env2594) = true)

theorem identity2594 : scanCanonicalize (H12AffineFastState.compose env2594 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4436) := by decide +kernel

theorem selectedBound2594 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,20497,262144,1025,8693,4436,293,4176,4195,8328,4096,266441,16384,16,2081,79254,4588,257,1,20497,513]

theorem envBound2595 : H12AffineFastState.Bounded env2595 := by
  intro p hp
  have h : env2595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2594_2595 : H12AffineEnvironment.transform 20 4436 env2594 = env2595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4436 env2594 == env2595) = true)

theorem identity2595 : scanCanonicalize (H12AffineFastState.compose env2595 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 12435) := by decide +kernel

theorem selectedBound2595 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,12435,20497,262144,1025,8693,4436,293,4176,4195,8328,4096,266441,16384,16,2081,1285,4588,257,1,20497,513]

theorem envBound2596 : H12AffineFastState.Bounded env2596 := by
  intro p hp
  have h : env2596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2595_2596 : H12AffineEnvironment.transform 15 12435 env2595 = env2596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12435 env2595 == env2596) = true)

theorem identity2596 : scanCanonicalize (H12AffineFastState.compose env2596 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2596 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2597 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,12435,20497,262144,1025,8201,4264,217,4176,4195,8328,4096,266441,16384,16,2081,1273,4112,253,1,20497,513]

theorem envBound2597 : H12AffineFastState.Bounded env2597 := by
  intro p hp
  have h : env2597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2596_2597 : H12AffineEnvironment.transform 7 252 env2596 = env2597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2596 == env2597) = true)

theorem identity2597 : scanCanonicalize (H12AffineFastState.compose env2597 (packedSelected [17,18,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound2597 : packedSelected [17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env2598 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,8192,16384,8201,8322,16384,262144,1025,8201,185,217,65,114,8328,17,262360,16384,16,2081,1273,1,253,1,16384,513]

theorem envBound2598 : H12AffineFastState.Bounded env2598 := by
  intro p hp
  have h : env2598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2597_2598 : H12AffineEnvironment.transform 11 17 env2597 = env2598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env2597 == env2598) = true)

theorem identity2598 : scanCanonicalize (H12AffineFastState.compose env2598 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 169) := by decide +kernel

theorem selectedBound2598 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2599 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,8192,169,8201,8322,169,262144,1025,8201,185,217,65,114,8328,17,262360,169,16,2081,1273,1,253,1,169,513]

theorem envBound2599 : H12AffineFastState.Bounded env2599 := by
  intro p hp
  have h : env2599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2598_2599 : H12AffineEnvironment.transform 13 169 env2598 = env2599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 169 env2598 == env2599) = true)

theorem identity2599 : scanCanonicalize (H12AffineFastState.compose env2599 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 1268) := by decide +kernel

theorem selectedBound2599 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2600 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,1268,169,1277,1142,169,262144,1025,1277,185,217,65,114,1148,17,262360,169,16,2081,1273,1,253,1,169,513]

theorem envBound2600 : H12AffineFastState.Bounded env2600 := by
  intro p hp
  have h : env2600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2599_2600 : H12AffineEnvironment.transform 12 1268 env2599 = env2600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1268 env2599 == env2600) = true)

theorem identity2600 : scanCanonicalize (H12AffineFastState.compose env2600 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 80) := by decide +kernel

theorem selectedBound2600 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2601 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,1268,169,1277,1142,169,80,1025,1277,185,217,65,114,1148,17,136,169,16,2081,1273,1,253,1,169,513]

theorem envBound2601 : H12AffineFastState.Bounded env2601 := by
  intro p hp
  have h : env2601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2600_2601 : H12AffineEnvironment.transform 17 80 env2600 = env2601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80 env2600 == env2601) = true)

theorem identity2601 : scanCanonicalize (H12AffineFastState.compose env2601 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound2601 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env2602 : List Nat := [2,4,8,16,32,64,128,252,512,84,2048,17,160,169,169,34,169,80,85,169,185,217,65,114,40,17,136,169,16,2081,173,1,253,1,169,513]

theorem envBound2602 : H12AffineFastState.Bounded env2602 := by
  intro p hp
  have h : env2602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2601_2602 : H12AffineEnvironment.transform 9 84 env2601 = env2602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env2601 == env2602) = true)

theorem identity2602 : scanCanonicalize (H12AffineFastState.compose env2602 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2602 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2603 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,17,9,0,0,34,0,80,85,0,16,112,65,114,40,17,33,0,16,2081,4,1,84,1,0,513]

theorem envBound2603 : H12AffineFastState.Bounded env2603 := by
  intro p hp
  have h : env2603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2602_2603 : H12AffineEnvironment.transform 6 41 env2602 = env2603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2602 == env2603) = true)

theorem identity2603 : scanCanonicalize (H12AffineFastState.compose env2603 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound2603 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env2604 : List Nat := [2,4,8,16,32,64,41,85,11,84,2048,17,9,0,0,34,0,80,85,0,16,112,65,114,40,17,33,0,16,2081,4,1,84,1,0,10]

theorem envBound2604 : H12AffineFastState.Bounded env2604 := by
  intro p hp
  have h : env2604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2603_2604 : H12AffineEnvironment.transform 8 11 env2603 = env2604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env2603 == env2604) = true)

theorem identity2604 : scanCanonicalize (H12AffineFastState.compose env2604 (packedSelected [3,4,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound2604 : packedSelected [3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env2605 : List Nat := [2,4,8,16,23,64,30,85,11,84,2048,17,9,0,0,21,0,80,85,0,16,71,65,69,31,17,22,0,16,2070,4,1,84,1,0,10]

theorem envBound2605 : H12AffineFastState.Bounded env2605 := by
  intro p hp
  have h : env2605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2604_2605 : H12AffineEnvironment.transform 4 23 env2604 = env2605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env2604 == env2605) = true)

theorem identity2605 : scanCanonicalize (H12AffineFastState.compose env2605 (packedSelected [3,4,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound2605 : packedSelected [3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env2606 : List Nat := [2,4,8,16,23,64,30,85,11,84,17,17,9,0,0,21,0,80,85,0,16,71,65,69,31,17,22,0,16,7,4,1,84,1,0,10]

theorem envBound2606 : H12AffineFastState.Bounded env2606 := by
  intro p hp
  have h : env2606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2605_2606 : H12AffineEnvironment.transform 10 17 env2605 = env2606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env2605 == env2606) = true)

theorem identity2606 : scanCanonicalize (H12AffineFastState.compose env2606 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2606 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env2607 : List Nat := [2,4,8,16,23,17,30,4,11,5,17,17,9,0,0,21,0,1,4,0,16,22,16,20,31,17,22,0,16,7,4,1,5,1,0,10]

theorem envBound2607 : H12AffineFastState.Bounded env2607 := by
  intro p hp
  have h : env2607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2606_2607 : H12AffineEnvironment.transform 5 17 env2606 = env2607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2606 == env2607) = true)

theorem identity2607 : scanCanonicalize (H12AffineFastState.compose env2607 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound2607 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2608 : List Nat := [2,4,6,16,23,17,16,4,5,5,17,17,7,0,0,21,0,1,4,0,16,22,16,20,17,17,22,0,16,7,4,1,5,1,0,4]

theorem envBound2608 : H12AffineFastState.Bounded env2608 := by
  intro p hp
  have h : env2608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2607_2608 : H12AffineEnvironment.transform 2 6 env2607 = env2608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env2607 == env2608) = true)

theorem identity2608 : scanCanonicalize (H12AffineFastState.compose env2608 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound2608 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env2609 : List Nat := [2,1,3,16,18,17,16,1,0,0,17,17,2,0,0,16,0,1,1,0,16,19,16,17,17,17,19,0,16,2,1,1,0,1,0,1]

theorem envBound2609 : H12AffineFastState.Bounded env2609 := by
  intro p hp
  have h : env2609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2608_2609 : H12AffineEnvironment.transform 1 1 env2608 = env2609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env2608 == env2609) = true)

theorem identity2609 : scanCanonicalize (H12AffineFastState.compose env2609 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2609 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env2610 : List Nat := [2,1,3,1,3,0,1,1,0,0,0,0,2,0,0,1,0,1,1,0,1,2,1,0,0,0,2,0,1,2,1,1,0,1,0,1]

theorem envBound2610 : H12AffineFastState.Bounded env2610 := by
  intro p hp
  have h : env2610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2609_2610 : H12AffineEnvironment.transform 3 1 env2609 = env2610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2609 == env2610) = true)

theorem identity2610 : scanCanonicalize (H12AffineFastState.compose env2610 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2611 : List Nat := [1,1,0,1,0,0,1,1,0,0,0,0,1,0,0,1,0,1,1,0,1,1,1,0,0,0,1,0,1,1,1,1,0,1,0,1]

theorem envBound2611 : H12AffineFastState.Bounded env2611 := by
  intro p hp
  have h : env2611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2610_2611 : H12AffineEnvironment.transform 0 1 env2610 = env2611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2610 == env2611) = true)

def env2612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2081,16852469,4341976,257,1,131073,16925299]

theorem envBound2612 : H12AffineFastState.Bounded env2612 := by
  intro p hp
  have h : env2612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2578_2612 : H12AffineEnvironment.transform 34 131073 env2578 = env2612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2578 == env2612) = true)

theorem identity2612 : scanCanonicalize (H12AffineFastState.compose env2612 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2097251) := by decide +kernel

theorem selectedBound2612 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,2097251,8328,147473,409816,16384,151553,2081,2172310,4341976,257,1,131073,2245136]

theorem envBound2613 : H12AffineFastState.Bounded env2613 := by
  intro p hp
  have h : env2613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2612_2613 : H12AffineEnvironment.transform 23 2097251 env2612 = env2613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2097251 env2612 == env2613) = true)

theorem identity2613 : scanCanonicalize (H12AffineFastState.compose env2613 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2613 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,4194304,147521,2097251,8328,147473,409816,16384,151553,2081,2098668,4341976,257,1,131073,2245136]

theorem envBound2614 : H12AffineFastState.Bounded env2614 := by
  intro p hp
  have h : env2614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2613_2614 : H12AffineEnvironment.transform 15 8314 env2613 = env2614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2613 == env2614) = true)

def env2615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,147472,4194304,147521,147571,8328,147473,409816,16384,151553,2081,148988,4341976,257,1,131073,512]

theorem envBound2615 : H12AffineFastState.Bounded env2615 := by
  intro p hp
  have h : env2615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2614_2615 : H12AffineEnvironment.transform 20 147472 env2614 = env2615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147472 env2614 == env2615) = true)

theorem identity2615 : scanCanonicalize (H12AffineFastState.compose env2615 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound2615 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,147472,32,147521,147571,8328,147473,409816,16384,151553,2081,148988,147704,257,1,131073,512]

theorem envBound2616 : H12AffineFastState.Bounded env2616 := by
  intro p hp
  have h : env2616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2615_2616 : H12AffineEnvironment.transform 21 32 env2615 = env2616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env2615 == env2616) = true)

theorem identity2616 : scanCanonicalize (H12AffineFastState.compose env2616 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2616 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2617 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1025,8432,147472,32,147521,147571,8328,147473,409816,16384,151553,2081,148729,147704,4,1,131073,512]

theorem envBound2617 : H12AffineFastState.Bounded env2617 := by
  intro p hp
  have h : env2617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2616_2617 : H12AffineEnvironment.transform 7 5 env2616 = env2617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2616 == env2617) = true)

theorem identity2617 : scanCanonicalize (H12AffineFastState.compose env2617 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound2617 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2618 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,16633,262144,1025,8432,233,32,184,138,8328,232,262177,16384,4344,2081,1024,1,4,1,16632,512]

theorem envBound2618 : H12AffineFastState.Bounded env2618 := by
  intro p hp
  have h : env2618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2617_2618 : H12AffineEnvironment.transform 16 16633 env2617 = env2618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2617 == env2618) = true)

theorem identity2618 : scanCanonicalize (H12AffineFastState.compose env2618 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 11270) := by decide +kernel

theorem selectedBound2618 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2619 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,11270,8432,8314,11519,262144,1025,8432,233,32,184,138,8328,232,262177,11270,4344,2081,1024,1,4,1,11518,512]

theorem envBound2619 : H12AffineFastState.Bounded env2619 := by
  intro p hp
  have h : env2619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2618_2619 : H12AffineEnvironment.transform 13 11270 env2618 = env2619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11270 env2618 == env2619) = true)

theorem identity2619 : scanCanonicalize (H12AffineFastState.compose env2619 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2619 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2620 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,11270,8432,8314,11519,2265,1025,8432,233,32,184,138,8328,232,2296,11270,4344,2081,1024,1,4,1,11518,512]

theorem envBound2620 : H12AffineFastState.Bounded env2620 := by
  intro p hp
  have h : env2620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2619_2620 : H12AffineEnvironment.transform 17 2265 env2619 = env2620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2619 == env2620) = true)

theorem identity2620 : scanCanonicalize (H12AffineFastState.compose env2620 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2620 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2621 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,11270,8200,8314,11271,2081,1025,8200,17,32,64,114,8304,16,2048,11270,4096,2081,1024,1,4,1,11270,512]

theorem envBound2621 : H12AffineFastState.Bounded env2621 := by
  intro p hp
  have h : env2621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2620_2621 : H12AffineEnvironment.transform 6 120 env2620 = env2621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2620 == env2621) = true)

theorem identity2621 : scanCanonicalize (H12AffineFastState.compose env2621 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound2621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2622 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,0,8192,11270,8200,8314,11271,2081,1025,8200,17,32,64,114,8304,16,2048,11270,0,2081,1024,1,4,1,11270,512]

theorem envBound2622 : H12AffineFastState.Bounded env2622 := by
  intro p hp
  have h : env2622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2621_2622 : H12AffineEnvironment.transform 11 0 env2621 = env2622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env2621 == env2622) = true)

theorem identity2622 : scanCanonicalize (H12AffineFastState.compose env2622 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound2622 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2623 : List Nat := [2,4,8,16,32,64,120,5,512,1024,123,0,8192,9341,8200,8314,9340,90,1025,8200,17,32,64,114,8304,16,123,9341,0,90,1024,1,4,1,9341,512]

theorem envBound2623 : H12AffineFastState.Bounded env2623 := by
  intro p hp
  have h : env2623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2622_2623 : H12AffineEnvironment.transform 10 123 env2622 = env2623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env2622 == env2623) = true)

theorem identity2623 : scanCanonicalize (H12AffineFastState.compose env2623 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2623 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2624 : List Nat := [2,4,8,16,32,64,120,5,512,1024,123,0,1030,123,1038,1148,122,90,1025,1038,17,32,64,114,1142,16,123,123,0,90,1024,1,4,1,123,512]

theorem envBound2624 : H12AffineFastState.Bounded env2624 := by
  intro p hp
  have h : env2624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2623_2624 : H12AffineEnvironment.transform 12 1030 env2623 = env2624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2623 == env2624) = true)

theorem identity2624 : scanCanonicalize (H12AffineFastState.compose env2624 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound2624 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2625 : List Nat := [2,4,8,16,32,49,9,5,512,1024,10,0,1030,10,1038,1037,11,43,1025,1038,17,32,49,3,1031,16,10,10,0,43,1024,1,4,1,10,512]

theorem envBound2625 : H12AffineFastState.Bounded env2625 := by
  intro p hp
  have h : env2625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2624_2625 : H12AffineEnvironment.transform 5 49 env2624 = env2625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env2624 == env2625) = true)

theorem identity2625 : scanCanonicalize (H12AffineFastState.compose env2625 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound2625 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env2626 : List Nat := [2,4,8,16,0,17,9,5,512,1024,10,0,1030,10,1038,1037,11,11,1025,1038,17,0,17,3,1031,16,10,10,0,11,1024,1,4,1,10,512]

theorem envBound2626 : H12AffineFastState.Bounded env2626 := by
  intro p hp
  have h : env2626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2625_2626 : H12AffineEnvironment.transform 4 0 env2625 = env2626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env2625 == env2626) = true)

def env2627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,147473,4194304,147521,147570,8328,147473,409816,16384,151553,2081,148989,4341976,257,1,131073,513]

theorem envBound2627 : H12AffineFastState.Bounded env2627 := by
  intro p hp
  have h : env2627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2614_2627 : H12AffineEnvironment.transform 20 147473 env2614 = env2627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147473 env2614 == env2627) = true)

theorem identity2627 : scanCanonicalize (H12AffineFastState.compose env2627 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 151648) := by decide +kernel

theorem selectedBound2627 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,147473,151648,147521,147570,8328,147473,409816,16384,151553,2081,148989,4280,257,1,131073,513]

theorem envBound2628 : H12AffineFastState.Bounded env2628 := by
  intro p hp
  have h : env2628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2627_2628 : H12AffineEnvironment.transform 21 151648 env2627 = env2628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 151648 env2627 == env2628) = true)

theorem identity2628 : scanCanonicalize (H12AffineFastState.compose env2628 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound2628 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,8192,16384,8693,8314,131072,262144,1025,8693,147473,147933,147521,147570,8328,147473,409816,16384,147900,2081,148989,261,257,1,131073,513]

theorem envBound2629 : H12AffineFastState.Bounded env2629 := by
  intro p hp
  have h : env2629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2628_2629 : H12AffineEnvironment.transform 11 445 env2628 = env2629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env2628 == env2629) = true)

theorem identity2629 : scanCanonicalize (H12AffineFastState.compose env2629 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16645) := by decide +kernel

theorem selectedBound2629 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,8192,16384,8693,8314,16645,262144,1025,8693,276,216,324,375,8328,276,262621,16384,185,2081,1272,261,257,1,16644,513]

theorem envBound2630 : H12AffineFastState.Bounded env2630 := by
  intro p hp
  have h : env2630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2629_2630 : H12AffineEnvironment.transform 16 16645 env2629 = env2630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16645 env2629 == env2630) = true)

theorem identity2630 : scanCanonicalize (H12AffineFastState.compose env2630 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1189) := by decide +kernel

theorem selectedBound2630 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,1189,16384,1360,1247,16645,262144,1025,1360,276,216,324,375,1069,276,262621,16384,185,2081,1272,261,257,1,16644,513]

theorem envBound2631 : H12AffineFastState.Bounded env2631 := by
  intro p hp
  have h : env2631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2630_2631 : H12AffineEnvironment.transform 12 1189 env2630 = env2631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1189 env2630 == env2631) = true)

theorem identity2631 : scanCanonicalize (H12AffineFastState.compose env2631 (packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound2631 : packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env2632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,1189,16384,1360,1247,16645,2525,1025,1360,276,216,324,375,1069,276,2048,16384,185,2081,1272,261,257,1,16644,513]

theorem envBound2632 : H12AffineFastState.Bounded env2632 := by
  intro p hp
  have h : env2632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2631_2632 : H12AffineEnvironment.transform 17 2525 env2631 = env2632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env2631 == env2632) = true)

theorem identity2632 : scanCanonicalize (H12AffineFastState.compose env2632 (packedSelected [2,3,5,6,7,9,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 2755) := by decide +kernel

theorem selectedBound2632 : packedSelected [2,3,5,6,7,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env2633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,1189,2755,1360,1247,3014,2525,1025,1360,276,216,324,375,1069,276,2048,2755,185,2081,1272,261,257,1,3015,513]

theorem envBound2633 : H12AffineFastState.Bounded env2633 := by
  intro p hp
  have h : env2633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2632_2633 : H12AffineEnvironment.transform 13 2755 env2632 = env2633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2755 env2632 == env2633) = true)

theorem identity2633 : scanCanonicalize (H12AffineFastState.compose env2633 (packedSelected [2,6,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound2633 : packedSelected [2,6,12,15,17] rootPS < 2^1333 := by decide +kernel

def env2634 : List Nat := [2,4,8,16,32,64,128,256,512,117,2048,445,208,2755,293,170,3014,2525,116,293,276,216,324,375,88,276,2048,2755,185,2081,141,261,257,1,3015,513]

theorem envBound2634 : H12AffineFastState.Bounded env2634 := by
  intro p hp
  have h : env2634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2633_2634 : H12AffineEnvironment.transform 9 117 env2633 = env2634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env2633 == env2634) = true)

theorem identity2634 : scanCanonicalize (H12AffineFastState.compose env2634 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 201) := by decide +kernel

theorem selectedBound2634 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env2635 : List Nat := [2,4,8,16,32,64,128,256,512,117,201,445,208,522,293,170,783,276,116,293,276,216,324,375,88,276,201,522,185,232,141,261,257,1,782,513]

theorem envBound2635 : H12AffineFastState.Bounded env2635 := by
  intro p hp
  have h : env2635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2634_2635 : H12AffineEnvironment.transform 10 201 env2634 = env2635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env2634 == env2635) = true)

theorem identity2635 : scanCanonicalize (H12AffineFastState.compose env2635 (packedSelected [4,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2635 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env2636 : List Nat := [2,4,8,16,32,17,128,256,512,36,152,445,129,522,293,170,783,276,37,293,276,137,277,294,9,276,152,522,185,185,141,261,257,1,782,513]

theorem envBound2636 : H12AffineFastState.Bounded env2636 := by
  intro p hp
  have h : env2636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2635_2636 : H12AffineEnvironment.transform 5 17 env2635 = env2636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2635 == env2636) = true)

theorem identity2636 : scanCanonicalize (H12AffineFastState.compose env2636 (packedSelected [0,1,4,6,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2636 : packedSelected [0,1,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env2637 : List Nat := [2,4,8,16,32,17,40,256,512,36,48,277,41,522,293,2,783,276,37,293,276,33,277,294,9,276,48,522,17,17,37,261,257,1,782,513]

theorem envBound2637 : H12AffineFastState.Bounded env2637 := by
  intro p hp
  have h : env2637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2636_2637 : H12AffineEnvironment.transform 6 40 env2636 = env2637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2636 == env2637) = true)

theorem identity2637 : scanCanonicalize (H12AffineFastState.compose env2637 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound2637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2638 : List Nat := [2,4,8,16,32,17,40,21,512,36,48,0,41,522,48,2,538,1,37,48,1,33,0,51,9,1,48,522,17,17,37,16,20,1,539,513]

theorem envBound2638 : H12AffineFastState.Bounded env2638 := by
  intro p hp
  have h : env2638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2637_2638 : H12AffineEnvironment.transform 7 21 env2637 = env2638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env2637 == env2638) = true)

theorem identity2638 : scanCanonicalize (H12AffineFastState.compose env2638 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound2638 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env2639 : List Nat := [2,4,8,16,32,17,40,21,53,36,48,0,41,63,48,2,47,1,37,48,1,33,0,51,9,1,48,63,17,17,37,16,20,1,46,52]

theorem envBound2639 : H12AffineFastState.Bounded env2639 := by
  intro p hp
  have h : env2639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2638_2639 : H12AffineEnvironment.transform 8 53 env2638 = env2639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env2638 == env2639) = true)

theorem identity2639 : scanCanonicalize (H12AffineFastState.compose env2639 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound2639 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env2640 : List Nat := [2,4,8,16,0,17,8,21,21,4,16,0,9,31,16,2,15,1,5,16,1,1,0,19,9,1,16,31,17,17,5,16,20,1,14,20]

theorem envBound2640 : H12AffineFastState.Bounded env2640 := by
  intro p hp
  have h : env2640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2639_2640 : H12AffineEnvironment.transform 4 0 env2639 = env2640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env2639 == env2640) = true)

theorem identity2640 : scanCanonicalize (H12AffineFastState.compose env2640 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound2640 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2641 : List Nat := [2,4,8,2,0,3,8,7,7,4,2,0,9,13,2,2,15,1,5,2,1,1,0,1,9,1,2,13,3,3,5,2,6,1,14,6]

theorem envBound2641 : H12AffineFastState.Bounded env2641 := by
  intro p hp
  have h : env2641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2640_2641 : H12AffineEnvironment.transform 3 2 env2640 = env2641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env2640 == env2641) = true)

def env2642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2080,17399809,13149548,525568,0,34359738368,25733062]

theorem envBound2642 : H12AffineFastState.Bounded env2642 := by
  intro p hp
  have h : env2642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2346_2642 : H12AffineEnvironment.transform 27 16385 env2346 = env2642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env2346 == env2642) = true)

def env2643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2080,17375733,13108376,525568,0,34359738368,25691698]

theorem envBound2643 : H12AffineFastState.Bounded env2643 := by
  intro p hp
  have h : env2643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2642_2643 : H12AffineEnvironment.transform 14 8692 env2642 = env2643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env2642 == env2643) = true)

def env2644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147520,16777216,8328,672785,935128,16385,151552,2080,17375733,4867288,525568,0,34359738368,17450610]

theorem envBound2644 : H12AffineFastState.Bounded env2644 := by
  intro p hp
  have h : env2644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2643_2644 : H12AffineEnvironment.transform 22 147520 env2643 = env2644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env2643 == env2644) = true)

def env2645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,34359738368,16925298]

theorem envBound2645 : H12AffineFastState.Bounded env2645 := by
  intro p hp
  have h : env2645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2644_2645 : H12AffineEnvironment.transform 18 1024 env2644 = env2645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2644 == env2645) = true)

def env2646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,131072,16925298]

theorem envBound2646 : H12AffineFastState.Bounded env2646 := by
  intro p hp
  have h : env2646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2645_2646 : H12AffineEnvironment.transform 34 131072 env2645 = env2646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2645 == env2646) = true)

theorem identity2646 : scanCanonicalize (H12AffineFastState.compose env2646 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2188303) := by decide +kernel

theorem selectedBound2646 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,2188303,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,2303191,256,0,131072,16925298]

theorem envBound2647 : H12AffineFastState.Bounded env2647 := by
  intro p hp
  have h : env2647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2646_2647 : H12AffineEnvironment.transform 21 2188303 env2646 = env2647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2188303 env2646 == env2647) = true)

theorem identity2647 : scanCanonicalize (H12AffineFastState.compose env2647 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound2647 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,2188303,147520,138,8328,147473,409816,16385,151552,2080,75135,2303191,256,0,131072,148216]

theorem envBound2648 : H12AffineFastState.Bounded env2648 := by
  intro p hp
  have h : env2648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2647_2648 : H12AffineEnvironment.transform 23 138 env2647 = env2648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env2647 == env2648) = true)

theorem identity2648 : scanCanonicalize (H12AffineFastState.compose env2648 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 206123) := by decide +kernel

theorem selectedBound2648 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env2649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,206123,147748,147520,138,8328,147473,409816,16385,151552,2080,75135,508,256,0,131072,148216]

theorem envBound2649 : H12AffineFastState.Bounded env2649 := by
  intro p hp
  have h : env2649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2648_2649 : H12AffineEnvironment.transform 20 206123 env2648 = env2649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206123 env2648 == env2649) = true)

theorem identity2649 : scanCanonicalize (H12AffineFastState.compose env2649 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2649 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1024,8692,132181,147748,147520,138,8328,147473,409816,16385,151552,2080,1025,508,256,0,131072,148216]

theorem envBound2650 : H12AffineFastState.Bounded env2650 := by
  intro p hp
  have h : env2650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2649_2650 : H12AffineEnvironment.transform 15 8574 env2649 = env2650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2649 == env2650) = true)

def env2651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1024,8692,17581,476,184,138,8328,233,262176,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2651 : H12AffineFastState.Bounded env2651 := by
  intro p hp
  have h : env2651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2650_2651 : H12AffineEnvironment.transform 16 16632 env2650 = env2651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2650 == env2651) = true)

theorem identity2651 : scanCanonicalize (H12AffineFastState.compose env2651 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound2651 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,10281,1024,8692,17581,476,184,138,8328,233,10249,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2652 : H12AffineFastState.Bounded env2652 := by
  intro p hp
  have h : env2652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2651_2652 : H12AffineEnvironment.transform 17 10281 env2651 = env2652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env2651 == env2652) = true)

theorem identity2652 : scanCanonicalize (H12AffineFastState.compose env2652 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound2652 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,16384,81,219,16632,2444,1024,81,17581,476,184,138,301,233,2476,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2653 : H12AffineFastState.Bounded env2653 := by
  intro p hp
  have h : env2653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2652_2653 : H12AffineEnvironment.transform 12 421 env2652 = env2653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env2652 == env2653) = true)

theorem identity2653 : scanCanonicalize (H12AffineFastState.compose env2653 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2653 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2654 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,4096,421,16384,17,155,16568,2444,1024,17,17581,412,184,138,301,169,2476,16385,4280,2080,1025,444,256,0,16568,512]

theorem envBound2654 : H12AffineFastState.Bounded env2654 := by
  intro p hp
  have h : env2654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2653_2654 : H12AffineEnvironment.transform 5 0 env2653 = env2654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2653 == env2654) = true)

def env2655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1024,8692,17580,477,185,138,8328,232,262177,16385,4345,2080,1025,508,256,0,16633,513]

theorem envBound2655 : H12AffineFastState.Bounded env2655 := by
  intro p hp
  have h : env2655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2650_2655 : H12AffineEnvironment.transform 16 16633 env2650 = env2655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2650 == env2655) = true)

theorem identity2655 : scanCanonicalize (H12AffineFastState.compose env2655 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13577) := by decide +kernel

theorem selectedBound2655 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13577,8692,8574,13808,262144,1024,8692,12709,477,185,138,8328,232,262177,13576,4345,2080,1025,508,256,0,13808,513]

theorem envBound2656 : H12AffineFastState.Bounded env2656 := by
  intro p hp
  have h : env2656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2655_2656 : H12AffineEnvironment.transform 13 13577 env2655 = env2656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13577 env2655 == env2656) = true)

theorem identity2656 : scanCanonicalize (H12AffineFastState.compose env2656 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound2656 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,508,374,5624,262144,1024,508,4525,477,185,138,128,232,262177,5376,4345,2080,1025,508,256,0,5624,513]

theorem envBound2657 : H12AffineFastState.Bounded env2657 := by
  intro p hp
  have h : env2657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2656_2657 : H12AffineEnvironment.transform 12 8 env2656 = env2657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env2656 == env2657) = true)

theorem identity2657 : scanCanonicalize (H12AffineFastState.compose env2657 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound2657 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2658 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,8,5140,233,99,5357,262144,1024,233,4280,200,185,138,128,232,262177,5141,4345,2080,1025,233,21,0,5357,513]

theorem envBound2658 : H12AffineFastState.Bounded env2658 := by
  intro p hp
  have h : env2658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2657_2658 : H12AffineEnvironment.transform 7 21 env2657 = env2658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env2657 == env2658) = true)

theorem identity2658 : scanCanonicalize (H12AffineFastState.compose env2658 (packedSelected [1,2,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2144) := by decide +kernel

theorem selectedBound2658 : packedSelected [1,2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env2659 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,8,5140,233,99,5357,2144,1024,233,4280,200,185,138,128,232,2113,5141,4345,2080,1025,233,21,0,5357,513]

theorem envBound2659 : H12AffineFastState.Bounded env2659 := by
  intro p hp
  have h : env2659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2658_2659 : H12AffineEnvironment.transform 17 2144 env2658 = env2659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2144 env2658 == env2659) = true)

theorem identity2659 : scanCanonicalize (H12AffineFastState.compose env2659 (packedSelected [4,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2659 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env2660 : List Nat := [2,4,8,16,32,64,40,21,512,1024,2048,4096,8,5140,65,99,5189,2144,1024,65,4112,96,17,34,40,64,2113,5141,4177,2080,1025,65,21,0,5189,513]

theorem envBound2660 : H12AffineFastState.Bounded env2660 := by
  intro p hp
  have h : env2660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2659_2660 : H12AffineEnvironment.transform 6 40 env2659 = env2660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2659 == env2660) = true)

theorem identity2660 : scanCanonicalize (H12AffineFastState.compose env2660 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2660 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2661 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,8,5140,1,35,5125,2080,1024,1,4112,32,17,34,40,0,2049,5141,4113,2080,1025,1,21,0,5125,513]

theorem envBound2661 : H12AffineFastState.Bounded env2661 := by
  intro p hp
  have h : env2661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2660_2661 : H12AffineEnvironment.transform 5 0 env2660 = env2661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2660 == env2661) = true)

theorem identity2661 : scanCanonicalize (H12AffineFastState.compose env2661 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2662 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,4096,8,5125,1,35,5125,2080,1024,1,4097,32,0,34,40,0,2049,5124,4096,2080,1025,1,4,0,5125,513]

theorem envBound2662 : H12AffineFastState.Bounded env2662 := by
  intro p hp
  have h : env2662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2661_2662 : H12AffineEnvironment.transform 3 1 env2661 = env2662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2661 == env2662) = true)

theorem identity2662 : scanCanonicalize (H12AffineFastState.compose env2662 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3599) := by decide +kernel

theorem selectedBound2662 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2663 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,3599,8,2570,1,35,2570,2080,1024,1,3598,32,0,34,40,0,2049,2571,3599,2080,1025,1,4,0,2570,513]

theorem envBound2663 : H12AffineFastState.Bounded env2663 := by
  intro p hp
  have h : env2663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2662_2663 : H12AffineEnvironment.transform 11 3599 env2662 = env2663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3599 env2662 == env2663) = true)

theorem identity2663 : scanCanonicalize (H12AffineFastState.compose env2663 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound2663 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2664 : List Nat := [2,4,8,1,32,0,40,4,512,37,2048,2602,8,2570,1,35,2570,2080,37,1,2603,32,0,34,40,0,2049,2571,2602,2080,36,1,4,0,2570,513]

theorem envBound2664 : H12AffineFastState.Bounded env2664 := by
  intro p hp
  have h : env2664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2663_2664 : H12AffineEnvironment.transform 9 37 env2663 = env2664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env2663 == env2664) = true)

theorem identity2664 : scanCanonicalize (H12AffineFastState.compose env2664 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound2664 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2665 : List Nat := [2,4,8,1,32,0,40,4,42,37,2048,2048,8,2080,1,35,2080,2080,37,1,2049,32,0,34,40,0,2049,2081,2048,2080,36,1,4,0,2080,43]

theorem envBound2665 : H12AffineFastState.Bounded env2665 := by
  intro p hp
  have h : env2665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2664_2665 : H12AffineEnvironment.transform 8 42 env2664 = env2665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env2664 == env2665) = true)

theorem identity2665 : scanCanonicalize (H12AffineFastState.compose env2665 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound2665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2666 : List Nat := [2,4,8,1,32,0,40,4,42,37,45,45,8,13,1,35,13,13,37,1,44,32,0,34,40,0,44,12,45,13,36,1,4,0,13,43]

theorem envBound2666 : H12AffineFastState.Bounded env2666 := by
  intro p hp
  have h : env2666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2665_2666 : H12AffineEnvironment.transform 10 45 env2665 = env2666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env2665 == env2666) = true)

theorem identity2666 : scanCanonicalize (H12AffineFastState.compose env2666 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound2666 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env2667 : List Nat := [2,4,8,1,12,0,4,4,6,9,1,1,8,13,1,15,13,13,9,1,0,12,0,14,4,0,0,12,1,13,8,1,4,0,13,7]

theorem envBound2667 : H12AffineFastState.Bounded env2667 := by
  intro p hp
  have h : env2667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2666_2667 : H12AffineEnvironment.transform 4 12 env2666 = env2667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env2666 == env2667) = true)

theorem identity2667 : scanCanonicalize (H12AffineFastState.compose env2667 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound2667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2668 : List Nat := [2,4,1,1,5,0,4,4,6,0,1,1,1,4,1,6,4,4,0,1,0,5,0,7,4,0,0,5,1,4,1,1,4,0,4,7]

theorem envBound2668 : H12AffineFastState.Bounded env2668 := by
  intro p hp
  have h : env2668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2667_2668 : H12AffineEnvironment.transform 2 1 env2667 = env2668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env2667 == env2668) = true)

def env2669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound2669 : H12AffineFastState.Bounded env2669 := by
  intro p hp
  have h : env2669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2645_2669 : H12AffineEnvironment.transform 34 131073 env2645 = env2669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2645 == env2669) = true)

theorem identity2669 : scanCanonicalize (H12AffineFastState.compose env2669 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 95246) := by decide +kernel

theorem selectedBound2669 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,95246,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,210134,256,0,131073,16925298]

theorem envBound2670 : H12AffineFastState.Bounded env2670 := by
  intro p hp
  have h : env2670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2669_2670 : H12AffineEnvironment.transform 21 95246 env2669 = env2670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95246 env2669 == env2670) = true)

theorem identity2670 : scanCanonicalize (H12AffineFastState.compose env2670 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 21978) := by decide +kernel

theorem selectedBound2670 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,95246,147520,21978,8328,147473,409816,16385,151552,2080,94255,210134,256,0,131073,137128]

theorem envBound2671 : H12AffineFastState.Bounded env2671 := by
  intro p hp
  have h : env2671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2670_2671 : H12AffineEnvironment.transform 23 21978 env2670 = env2671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 21978 env2670 == env2671) = true)

theorem identity2671 : scanCanonicalize (H12AffineFastState.compose env2671 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2671 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1024,8692,2097152,21872,147520,21978,8328,147473,409816,16385,151552,2080,20817,136616,256,0,131073,137128]

theorem envBound2672 : H12AffineFastState.Bounded env2672 := by
  intro p hp
  have h : env2672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2671_2672 : H12AffineEnvironment.transform 15 8574 env2671 = env2672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2671 == env2672) = true)

def env2673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16464,262144,1024,8692,2097152,21872,16,21978,8328,65,262280,16385,4176,2080,20817,22008,256,0,16465,22520]

theorem envBound2673 : H12AffineFastState.Bounded env2673 := by
  intro p hp
  have h : env2673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2672_2673 : H12AffineEnvironment.transform 16 16464 env2672 = env2673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env2672 == env2673) = true)

theorem identity2673 : scanCanonicalize (H12AffineFastState.compose env2673 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound2673 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8692,8574,5376,262144,1024,8692,2097152,32,16,138,8328,65,262280,5457,4176,2080,1025,168,256,0,5377,680]

theorem envBound2674 : H12AffineFastState.Bounded env2674 := by
  intro p hp
  have h : env2674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2673_2674 : H12AffineEnvironment.transform 13 5456 env2673 = env2674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env2673 == env2674) = true)

theorem identity2674 : scanCanonicalize (H12AffineFastState.compose env2674 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound2674 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env2675 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8352,8234,5204,262144,1024,8352,2097152,32,16,138,8328,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2675 : H12AffineFastState.Bounded env2675 := by
  intro p hp
  have h : env2675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2674_2675 : H12AffineEnvironment.transform 7 84 env2674 = env2675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env2674 == env2675) = true)

theorem identity2675 : scanCanonicalize (H12AffineFastState.compose env2675 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound2675 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env2676 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8352,8234,5204,262144,1024,8352,4161,32,16,138,8328,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2676 : H12AffineFastState.Bounded env2676 := by
  intro p hp
  have h : env2676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2675_2676 : H12AffineEnvironment.transform 20 4161 env2675 = env2676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env2675 == env2676) = true)

theorem identity2676 : scanCanonicalize (H12AffineFastState.compose env2676 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound2676 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2677 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,89,5124,249,115,5204,262144,1024,249,4161,32,16,138,209,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2677 : H12AffineFastState.Bounded env2677 := by
  intro p hp
  have h : env2677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2676_2677 : H12AffineEnvironment.transform 12 89 env2676 = env2677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env2676 == env2677) = true)

theorem identity2677 : scanCanonicalize (H12AffineFastState.compose env2677 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound2677 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env2678 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,9,5124,169,35,5124,262144,1024,169,4113,32,16,138,129,17,262280,5125,4096,2080,1025,168,4,0,5125,680]

theorem envBound2678 : H12AffineFastState.Bounded env2678 := by
  intro p hp
  have h : env2678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2677_2678 : H12AffineEnvironment.transform 5 16 env2677 = env2678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2677 == env2678) = true)

theorem identity2678 : scanCanonicalize (H12AffineFastState.compose env2678 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2678 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env2679 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,0,35,5124,262144,1024,0,4113,32,16,35,40,17,262177,5125,4096,2080,1025,1,4,0,5125,513]

theorem envBound2679 : H12AffineFastState.Bounded env2679 := by
  intro p hp
  have h : env2679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2678_2679 : H12AffineEnvironment.transform 6 41 env2678 = env2679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2678 == env2679) = true)

theorem identity2679 : scanCanonicalize (H12AffineFastState.compose env2679 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 570) := by decide +kernel

theorem selectedBound2679 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2680 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,0,35,5124,570,1024,0,4113,32,16,35,40,17,539,5125,4096,2080,1025,1,4,0,5125,513]

theorem envBound2680 : H12AffineFastState.Bounded env2680 := by
  intro p hp
  have h : env2680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2679_2680 : H12AffineEnvironment.transform 17 570 env2679 = env2680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 570 env2679 == env2680) = true)

def env2681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16465,262144,1024,8692,2097152,21872,17,21978,8328,64,262281,16385,4177,2080,20817,22009,256,0,16464,22521]

theorem envBound2681 : H12AffineFastState.Bounded env2681 := by
  intro p hp
  have h : env2681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2672_2681 : H12AffineEnvironment.transform 16 16465 env2672 = env2681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env2672 == env2681) = true)

theorem identity2681 : scanCanonicalize (H12AffineFastState.compose env2681 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5624) := by decide +kernel

theorem selectedBound2681 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5624,8692,8574,5545,262144,1024,8692,2097152,136,17,34,8328,64,262281,5625,4177,2080,1193,1,256,0,5544,513]

theorem envBound2682 : H12AffineFastState.Bounded env2682 := by
  intro p hp
  have h : env2682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2681_2682 : H12AffineEnvironment.transform 13 5624 env2681 = env2682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5624 env2681 == env2682) = true)

theorem identity2682 : scanCanonicalize (H12AffineFastState.compose env2682 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4344) := by decide +kernel

theorem selectedBound2682 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5624,8692,8574,5545,262144,1024,8692,4344,136,17,34,8328,64,262281,5625,4177,2080,1193,1,256,0,5544,513]

theorem envBound2683 : H12AffineFastState.Bounded env2683 := by
  intro p hp
  have h : env2683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2682_2683 : H12AffineEnvironment.transform 20 4344 env2682 = env2683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4344 env2682 == env2683) = true)

theorem identity2683 : scanCanonicalize (H12AffineFastState.compose env2683 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound2683 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2684 : List Nat := [2,4,8,16,32,64,128,189,512,1024,2048,4096,8192,5189,8265,8387,5140,262144,1024,8265,4344,136,17,34,8328,64,262281,5188,4177,2080,1193,1,189,0,5141,513]

theorem envBound2684 : H12AffineFastState.Bounded env2684 := by
  intro p hp
  have h : env2684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2683_2684 : H12AffineEnvironment.transform 7 189 env2683 = env2684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env2683 == env2684) = true)

theorem identity2684 : scanCanonicalize (H12AffineFastState.compose env2684 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2684 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2685 : List Nat := [2,4,8,16,32,0,128,189,512,1024,2048,4096,8192,5125,8201,8323,5140,262144,1024,8201,4280,136,17,34,8328,0,262281,5124,4113,2080,1193,1,189,0,5141,513]

theorem envBound2685 : H12AffineFastState.Bounded env2685 := by
  intro p hp
  have h : env2685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2684_2685 : H12AffineEnvironment.transform 5 0 env2684 = env2685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2684 == env2685) = true)

theorem identity2685 : scanCanonicalize (H12AffineFastState.compose env2685 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2685 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env2686 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,8192,5125,8201,8235,5140,262144,1024,8201,4112,32,17,34,8224,0,262177,5124,4113,2080,1025,1,21,0,5141,513]

theorem envBound2686 : H12AffineFastState.Bounded env2686 := by
  intro p hp
  have h : env2686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2685_2686 : H12AffineEnvironment.transform 6 40 env2685 = env2686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2685 == env2686) = true)

theorem identity2686 : scanCanonicalize (H12AffineFastState.compose env2686 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound2686 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2687 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,24,5125,17,51,5140,262144,1024,17,4112,32,17,34,56,0,262177,5124,4113,2080,1025,1,21,0,5141,513]

theorem envBound2687 : H12AffineFastState.Bounded env2687 := by
  intro p hp
  have h : env2687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2686_2687 : H12AffineEnvironment.transform 12 24 env2686 = env2687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env2686 == env2687) = true)

theorem identity2687 : scanCanonicalize (H12AffineFastState.compose env2687 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2687 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2688 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,4096,8,5125,1,35,5124,262144,1024,1,4096,32,1,34,40,0,262177,5124,4097,2080,1025,1,5,0,5125,513]

theorem envBound2688 : H12AffineFastState.Bounded env2688 := by
  intro p hp
  have h : env2688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2687_2688 : H12AffineEnvironment.transform 3 0 env2687 = env2688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2687 == env2688) = true)

theorem identity2688 : scanCanonicalize (H12AffineFastState.compose env2688 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 522) := by decide +kernel

theorem selectedBound2688 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2689 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,4096,8,5125,1,35,5124,522,1024,1,4096,32,1,34,40,0,555,5124,4097,2080,1025,1,5,0,5125,513]

theorem envBound2689 : H12AffineFastState.Bounded env2689 := by
  intro p hp
  have h : env2689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2688_2689 : H12AffineEnvironment.transform 17 522 env2688 = env2689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 522 env2688 == env2689) = true)

theorem identity2689 : scanCanonicalize (H12AffineFastState.compose env2689 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound2689 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env2690 : List Nat := [2,4,8,0,32,0,40,5,512,1024,555,4096,8,5125,1,35,5124,522,1024,1,4096,32,1,34,40,0,555,5124,4097,523,1025,1,5,0,5125,513]

theorem envBound2690 : H12AffineFastState.Bounded env2690 := by
  intro p hp
  have h : env2690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2689_2690 : H12AffineEnvironment.transform 10 555 env2689 = env2690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env2689 == env2690) = true)

theorem identity2690 : scanCanonicalize (H12AffineFastState.compose env2690 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound2690 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2691 : List Nat := [2,4,8,0,32,0,40,5,512,1024,555,32,8,1061,1,35,1060,522,1024,1,32,32,1,34,40,0,555,1060,33,523,1025,1,5,0,1061,513]

theorem envBound2691 : H12AffineFastState.Bounded env2691 := by
  intro p hp
  have h : env2691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2690_2691 : H12AffineEnvironment.transform 11 32 env2690 = env2691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env2690 == env2691) = true)

theorem identity2691 : scanCanonicalize (H12AffineFastState.compose env2691 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound2691 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2692 : List Nat := [2,4,8,0,32,0,40,5,11,1024,32,32,8,1061,1,35,1060,1,1024,1,32,32,1,34,40,0,32,1060,33,0,1025,1,5,0,1061,10]

theorem envBound2692 : H12AffineFastState.Bounded env2692 := by
  intro p hp
  have h : env2692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2691_2692 : H12AffineEnvironment.transform 8 11 env2691 = env2692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env2691 == env2692) = true)

theorem identity2692 : scanCanonicalize (H12AffineFastState.compose env2692 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound2692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2693 : List Nat := [2,4,8,0,9,0,1,5,11,1024,9,9,8,1036,1,10,1037,1,1024,1,9,9,1,11,1,0,9,1037,8,0,1025,1,5,0,1036,10]

end H12CloudChart0