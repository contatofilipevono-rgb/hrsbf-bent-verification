import H12CloudChart0Data067

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound17130 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67619,1024,32769,4160,4194304,16,98644,8192,65,4295031,5392,17664,67618,1364,4256860,256,21792,46093,74251]

theorem envBound17131 : H12AffineFastState.Bounded env17131 := by
  intro p hp
  have h : env17131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17130_17131 : H12AffineEnvironment.transform 16 49168 env17130 = env17131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env17130 == env17131) = true)

theorem identity17131 : scanCanonicalize (H12AffineFastState.compose env17131 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17131 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,67619,1024,1,4160,4194304,16,65876,8192,65,4262263,5392,17664,67618,1364,4224092,256,21792,13325,74251]

theorem envBound17132 : H12AffineFastState.Bounded env17132 := by
  intro p hp
  have h : env17132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17131_17132 : H12AffineEnvironment.transform 14 0 env17131 = env17132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17131 == env17132) = true)

theorem identity17132 : scanCanonicalize (H12AffineFastState.compose env17132 (packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound17132 : packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS < 2^1333 := by decide +kernel

def env17133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,67619,1024,1,4160,65830,16,65876,8192,65,2129,5392,17664,67618,1364,95610,256,21792,13325,74251]

theorem envBound17133 : H12AffineFastState.Bounded env17133 := by
  intro p hp
  have h : env17133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17132_17133 : H12AffineEnvironment.transform 21 65830 env17132 = env17133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env17132 == env17133) = true)

theorem identity17133 : scanCanonicalize (H12AffineFastState.compose env17133 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound17133 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,13388,67619,1024,1,4160,65830,16,65876,8192,65,2129,5392,12636,67618,1364,65830,256,8572,13325,74251]

theorem envBound17134 : H12AffineFastState.Bounded env17134 := by
  intro p hp
  have h : env17134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17133_17134 : H12AffineEnvironment.transform 13 13404 env17133 = env17134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env17133 == env17134) = true)

theorem identity17134 : scanCanonicalize (H12AffineFastState.compose env17134 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound17134 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env17135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8283,13388,10360,1024,1,4160,8573,16,8463,8192,65,2129,5392,12636,10361,1364,8573,256,8572,13325,592]

theorem envBound17135 : H12AffineFastState.Bounded env17135 := by
  intro p hp
  have h : env17135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17134_17135 : H12AffineEnvironment.transform 15 8283 env17134 = env17135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env17134 == env17135) = true)

theorem identity17135 : scanCanonicalize (H12AffineFastState.compose env17135 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound17135 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env17136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6476,3344,0,6423,3328,4404,1024,1,4160,6193,16,6211,6476,65,2129,5392,2064,4405,1364,6193,256,6192,3393,592]

theorem envBound17136 : H12AffineFastState.Bounded env17136 := by
  intro p hp
  have h : env17136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17135_17136 : H12AffineEnvironment.transform 12 6476 env17135 = env17136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env17135 == env17136) = true)

theorem identity17136 : scanCanonicalize (H12AffineFastState.compose env17136 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound17136 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3344,0,263,3328,2340,1024,1,2128,33,16,83,348,65,2129,3328,2064,2341,1364,33,256,32,3393,592]

theorem envBound17137 : H12AffineFastState.Bounded env17137 := by
  intro p hp
  have h : env17137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17136_17137 : H12AffineEnvironment.transform 11 2064 env17136 = env17137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env17136 == env17137) = true)

theorem identity17137 : scanCanonicalize (H12AffineFastState.compose env17137 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound17137 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,576,592,348,1872,0,263,1856,868,1024,1,528,33,16,83,348,65,529,1856,592,869,1364,33,256,32,1793,592]

theorem envBound17138 : H12AffineFastState.Bounded env17138 := by
  intro p hp
  have h : env17138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17137_17138 : H12AffineEnvironment.transform 10 576 env17137 = env17138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env17137 == env17138) = true)

theorem identity17138 : scanCanonicalize (H12AffineFastState.compose env17138 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound17138 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env17139 : List Nat := [2,4,8,16,32,64,8,256,512,257,576,592,348,593,0,263,577,868,257,1,528,33,16,83,348,65,529,577,592,869,85,33,256,32,512,592]

theorem envBound17139 : H12AffineFastState.Bounded env17139 := by
  intro p hp
  have h : env17139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17138_17139 : H12AffineEnvironment.transform 9 257 env17138 = env17139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env17138 == env17139) = true)

theorem identity17139 : scanCanonicalize (H12AffineFastState.compose env17139 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound17139 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env17140 : List Nat := [2,4,8,16,32,64,8,256,325,257,261,277,348,276,0,263,260,33,257,1,341,33,16,83,348,65,340,260,277,32,85,33,256,32,325,277]

theorem envBound17140 : H12AffineFastState.Bounded env17140 := by
  intro p hp
  have h : env17140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17139_17140 : H12AffineEnvironment.transform 8 325 env17139 = env17140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env17139 == env17140) = true)

theorem identity17140 : scanCanonicalize (H12AffineFastState.compose env17140 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17140 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env17141 : List Nat := [2,4,8,16,17,64,8,256,325,257,261,277,348,276,0,263,260,16,257,1,341,16,16,83,348,65,340,260,277,17,85,16,256,17,325,277]

theorem envBound17141 : H12AffineFastState.Bounded env17141 := by
  intro p hp
  have h : env17141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17140_17141 : H12AffineEnvironment.transform 4 17 env17140 = env17141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17140 == env17141) = true)

theorem identity17141 : scanCanonicalize (H12AffineFastState.compose env17141 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17142 : List Nat := [2,4,8,16,17,0,8,256,261,257,261,277,284,276,0,263,260,16,257,1,277,16,16,19,284,1,276,260,277,17,21,16,256,17,261,277]

theorem envBound17142 : H12AffineFastState.Bounded env17142 := by
  intro p hp
  have h : env17142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17141_17142 : H12AffineEnvironment.transform 5 0 env17141 = env17142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17141 == env17142) = true)

theorem identity17142 : scanCanonicalize (H12AffineFastState.compose env17142 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17143 : List Nat := [2,4,8,1,0,0,8,256,261,257,261,260,269,261,0,263,260,1,257,1,260,1,1,2,269,1,261,260,260,0,4,1,256,0,261,260]

theorem envBound17143 : H12AffineFastState.Bounded env17143 := by
  intro p hp
  have h : env17143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17142_17143 : H12AffineEnvironment.transform 3 1 env17142 = env17143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17142 == env17143) = true)

theorem identity17143 : scanCanonicalize (H12AffineFastState.compose env17143 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17144 : List Nat := [2,4,8,1,0,0,8,5,0,4,0,1,8,0,0,2,1,1,4,1,1,1,1,2,8,1,0,1,1,0,4,1,5,0,0,1]

theorem envBound17144 : H12AffineFastState.Bounded env17144 := by
  intro p hp
  have h : env17144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17143_17144 : H12AffineEnvironment.transform 7 5 env17143 = env17144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17143 == env17144) = true)

def env17145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98645,8193,65,4295030,5392,17664,67618,1365,4256860,256,21792,46092,74251]

theorem envBound17145 : H12AffineFastState.Bounded env17145 := by
  intro p hp
  have h : env17145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17129_17145 : H12AffineEnvironment.transform 6 9 env17129 = env17145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17129 == env17145) = true)

theorem identity17145 : scanCanonicalize (H12AffineFastState.compose env17145 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound17145 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,108927,1024,32769,4160,4194304,16,98645,8193,65,4295030,5392,17664,67618,1365,4256860,256,21792,46092,74251]

theorem envBound17146 : H12AffineFastState.Bounded env17146 := by
  intro p hp
  have h : env17146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17145_17146 : H12AffineEnvironment.transform 16 24908 env17145 = env17146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env17145 == env17146) = true)

theorem identity17146 : scanCanonicalize (H12AffineFastState.compose env17146 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound17146 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env17147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,24908,56357,1024,32769,4160,4194304,16,62479,8193,65,4258860,5392,17664,32120,1365,4256860,256,21792,46092,22353]

theorem envBound17147 : H12AffineFastState.Bounded env17147 := by
  intro p hp
  have h : env17147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17146_17147 : H12AffineEnvironment.transform 15 30042 env17146 = env17147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env17146 == env17147) = true)

theorem identity17147 : scanCanonicalize (H12AffineFastState.compose env17147 (packedSelected [1,3,7,8,10,12,14,15,19,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound17147 : packedSelected [1,3,7,8,10,12,14,15,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,32768,21795,16693,56357,1024,32769,4160,4194304,16,54390,120,65,4250709,5392,17664,23809,1365,4248613,256,21792,38005,22353]

theorem envBound17148 : H12AffineFastState.Bounded env17148 := by
  intro p hp
  have h : env17148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17147_17148 : H12AffineEnvironment.transform 12 121 env17147 = env17148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env17147 == env17148) = true)

theorem identity17148 : scanCanonicalize (H12AffineFastState.compose env17148 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound17148 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,32768,115,5221,35189,1024,32769,4160,4194304,16,33062,120,65,4229381,5392,4176,2129,1365,4227445,256,112,38005,513]

theorem envBound17149 : H12AffineFastState.Bounded env17149 := by
  intro p hp
  have h : env17149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17148_17149 : H12AffineEnvironment.transform 13 5456 env17148 = env17149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env17148 == env17149) = true)

theorem identity17149 : scanCanonicalize (H12AffineFastState.compose env17149 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound17149 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env17150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,32768,115,5221,35189,1024,32769,4160,32800,16,33062,120,65,2341,5392,4176,2129,1365,341,256,112,38005,513]

theorem envBound17150 : H12AffineFastState.Bounded env17150 := by
  intro p hp
  have h : env17150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17149_17150 : H12AffineEnvironment.transform 21 32800 env17149 = env17150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env17149 == env17150) = true)

theorem identity17150 : scanCanonicalize (H12AffineFastState.compose env17150 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17150 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,0,115,5221,2421,1024,1,4160,32,16,294,120,65,2341,5392,4176,2129,1365,341,256,112,5237,513]

theorem envBound17151 : H12AffineFastState.Bounded env17151 := by
  intro p hp
  have h : env17151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17150_17151 : H12AffineEnvironment.transform 14 0 env17150 = env17151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17150 == env17151) = true)

theorem identity17151 : scanCanonicalize (H12AffineFastState.compose env17151 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound17151 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env17152 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,121,4112,0,115,4389,2421,320,1,4160,32,16,294,120,65,2341,4176,4176,2129,21,341,256,112,4405,513]

theorem envBound17152 : H12AffineFastState.Bounded env17152 := by
  intro p hp
  have h : env17152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17151_17152 : H12AffineEnvironment.transform 9 320 env17151 = env17152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env17151 == env17152) = true)

theorem identity17152 : scanCanonicalize (H12AffineFastState.compose env17152 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound17152 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env17153 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2065,121,2049,0,115,2356,2421,320,1,2129,32,16,294,120,65,2341,2113,2113,2129,21,341,256,112,2340,513]

theorem envBound17153 : H12AffineFastState.Bounded env17153 := by
  intro p hp
  have h : env17153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17152_17153 : H12AffineEnvironment.transform 11 2065 env17152 = env17153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env17152 == env17153) = true)

theorem identity17153 : scanCanonicalize (H12AffineFastState.compose env17153 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound17153 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env17154 : List Nat := [2,4,8,16,32,64,9,69,512,5,2048,2065,121,2049,0,115,2161,2096,5,1,2129,32,16,99,120,65,2144,2113,2113,2129,21,16,69,112,2145,513]

theorem envBound17154 : H12AffineFastState.Bounded env17154 := by
  intro p hp
  have h : env17154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17153_17154 : H12AffineEnvironment.transform 7 69 env17153 = env17154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env17153 == env17154) = true)

theorem identity17154 : scanCanonicalize (H12AffineFastState.compose env17154 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17154 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17155 : List Nat := [2,4,8,16,32,0,9,5,512,5,2048,2065,57,2049,0,51,2097,2096,5,1,2065,32,16,35,56,1,2080,2049,2049,2065,21,16,5,48,2081,513]

theorem envBound17155 : H12AffineFastState.Bounded env17155 := by
  intro p hp
  have h : env17155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17154_17155 : H12AffineEnvironment.transform 5 0 env17154 = env17155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17154 == env17155) = true)

theorem identity17155 : scanCanonicalize (H12AffineFastState.compose env17155 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17155 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env17156 : List Nat := [2,4,8,16,16,0,9,5,512,5,2048,2065,9,2049,0,3,2049,2048,5,1,2065,16,16,19,8,1,2064,2049,2049,2065,21,16,5,0,2065,513]

theorem envBound17156 : H12AffineFastState.Bounded env17156 := by
  intro p hp
  have h : env17156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17155_17156 : H12AffineEnvironment.transform 4 16 env17155 = env17156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17155 == env17156) = true)

theorem identity17156 : scanCanonicalize (H12AffineFastState.compose env17156 (packedSelected [2,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17156 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env17157 : List Nat := [2,4,8,0,0,0,9,5,512,5,2048,2049,9,2049,0,3,2049,2048,5,1,2049,0,0,3,8,1,2048,2049,2049,2049,5,0,5,0,2049,513]

theorem envBound17157 : H12AffineFastState.Bounded env17157 := by
  intro p hp
  have h : env17157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17156_17157 : H12AffineEnvironment.transform 3 0 env17156 = env17157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17156 == env17157) = true)

theorem identity17157 : scanCanonicalize (H12AffineFastState.compose env17157 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17158 : List Nat := [2,4,8,0,0,0,9,5,0,5,2048,2049,9,2049,0,3,2049,2048,5,1,2049,0,0,3,8,1,2048,2049,2049,2049,5,0,5,0,2049,1]

theorem envBound17158 : H12AffineFastState.Bounded env17158 := by
  intro p hp
  have h : env17158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17157_17158 : H12AffineEnvironment.transform 8 0 env17157 = env17158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17157 == env17158) = true)

theorem identity17158 : scanCanonicalize (H12AffineFastState.compose env17158 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17159 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,0,9,0,0,3,0,1,5,1,0,0,0,3,8,1,1,0,0,0,5,0,5,0,0,1]

theorem envBound17159 : H12AffineFastState.Bounded env17159 := by
  intro p hp
  have h : env17159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17158_17159 : H12AffineEnvironment.transform 10 1 env17158 = env17159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17158 == env17159) = true)

def env17160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,17,98780,8328,65,4295166,5392,17665,67619,1501,4256860,256,21793,46212,74250]

theorem envBound17160 : H12AffineFastState.Bounded env17160 := by
  intro p hp
  have h : env17160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17128_17160 : H12AffineEnvironment.transform 22 17 env17128 = env17160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17128 == env17160) = true)

theorem identity17160 : scanCanonicalize (H12AffineFastState.compose env17160 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound17160 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180408,17,98780,8328,65,215366,5392,17665,67619,1501,144612,256,21793,46212,74250]

theorem envBound17161 : H12AffineFastState.Bounded env17161 := by
  intro p hp
  have h : env17161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17160_17161 : H12AffineEnvironment.transform 21 180408 env17160 = env17161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env17160 == env17161) = true)

def env17162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180272,17,98644,8192,65,215366,5392,17665,67619,1365,144492,256,21793,46092,74250]

theorem envBound17162 : H12AffineFastState.Bounded env17162 := by
  intro p hp
  have h : env17162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17161_17162 : H12AffineEnvironment.transform 6 8 env17161 = env17162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17161 == env17162) = true)

theorem identity17162 : scanCanonicalize (H12AffineFastState.compose env17162 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17162 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4160,180272,17,41311,8192,65,158029,5392,17665,10280,1365,144492,256,21793,46092,513]

theorem envBound17163 : H12AffineFastState.Bounded env17163 := by
  intro p hp
  have h : env17163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17162_17163 : H12AffineEnvironment.transform 15 8203 env17162 = env17163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17162 == env17163) = true)

theorem identity17163 : scanCanonicalize (H12AffineFastState.compose env17163 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17163 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43049,1024,32769,4160,32801,17,41311,8192,65,10588,5392,17665,10280,1365,29821,256,21793,46092,513]

theorem envBound17164 : H12AffineFastState.Bounded env17164 := by
  intro p hp
  have h : env17164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17163_17164 : H12AffineEnvironment.transform 16 16401 env17163 = env17164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17163 == env17164) = true)

theorem identity17164 : scanCanonicalize (H12AffineFastState.compose env17164 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17164 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,2420,1024,8540,4160,8572,17,2,8192,65,10588,5392,17665,10280,1365,29821,256,21793,5457,513]

theorem envBound17165 : H12AffineFastState.Bounded env17165 := by
  intro p hp
  have h : env17165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17164_17165 : H12AffineEnvironment.transform 14 8541 env17164 = env17165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17164 == env17165) = true)

theorem identity17165 : scanCanonicalize (H12AffineFastState.compose env17165 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17165 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8203,13340,2420,1024,8540,4160,8572,17,2,8192,65,10588,5392,12556,10280,1365,112,256,8492,5457,513]

theorem envBound17166 : H12AffineFastState.Bounded env17166 := by
  intro p hp
  have h : env17166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17165_17166 : H12AffineEnvironment.transform 13 13325 env17165 = env17166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env17165 == env17166) = true)

theorem identity17166 : scanCanonicalize (H12AffineFastState.compose env17166 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound17166 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env17167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4404,1124,1330,4389,2420,1024,1125,4160,1093,17,2,1337,65,3173,5392,5173,3345,1365,112,256,1045,5457,513]

theorem envBound17167 : H12AffineFastState.Bounded env17167 := by
  intro p hp
  have h : env17167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17166_17167 : H12AffineEnvironment.transform 12 1337 env17166 = env17167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env17166 == env17167) = true)

theorem identity17167 : scanCanonicalize (H12AffineFastState.compose env17167 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17167 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17168 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4404,1,343,4389,2420,101,0,4160,32,17,2,348,65,2048,4469,4176,2420,304,112,256,112,4404,513]

theorem envBound17168 : H12AffineFastState.Bounded env17168 := by
  intro p hp
  have h : env17168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17167_17168 : H12AffineEnvironment.transform 9 101 env17167 = env17168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17167 == env17168) = true)

theorem identity17168 : scanCanonicalize (H12AffineFastState.compose env17168 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17169 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4404,1,263,4389,2340,53,0,4112,32,17,2,268,17,2048,4389,4096,2340,304,32,256,32,4404,513]

theorem envBound17169 : H12AffineFastState.Bounded env17169 := by
  intro p hp
  have h : env17169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17168_17169 : H12AffineEnvironment.transform 5 16 env17168 = env17169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17168 == env17169) = true)

theorem identity17169 : scanCanonicalize (H12AffineFastState.compose env17169 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17169 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17170 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4112,1,35,4097,2048,53,0,4112,32,17,2,40,17,2048,4097,4096,2048,20,32,36,32,4112,513]

theorem envBound17170 : H12AffineFastState.Bounded env17170 := by
  intro p hp
  have h : env17170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17169_17170 : H12AffineEnvironment.transform 7 36 env17169 = env17170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17169 == env17170) = true)

theorem identity17170 : scanCanonicalize (H12AffineFastState.compose env17170 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound17170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17171 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2081,40,2097,1,35,2080,2048,53,0,2097,32,17,2,40,17,2048,2080,2081,2048,20,32,36,32,2097,513]

theorem envBound17171 : H12AffineFastState.Bounded env17171 := by
  intro p hp
  have h : env17171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17170_17171 : H12AffineEnvironment.transform 11 2081 env17170 = env17171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env17170 == env17171) = true)

theorem identity17171 : scanCanonicalize (H12AffineFastState.compose env17171 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17172 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,33,40,49,1,35,32,0,53,0,49,32,17,2,40,17,0,32,33,0,20,32,36,32,49,513]

theorem envBound17172 : H12AffineFastState.Bounded env17172 := by
  intro p hp
  have h : env17172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17171_17172 : H12AffineEnvironment.transform 10 0 env17171 = env17172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17171 == env17172) = true)

def env17173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180273,17,98645,8193,65,215366,5392,17665,67619,1364,144493,256,21793,46093,74250]

theorem envBound17173 : H12AffineFastState.Bounded env17173 := by
  intro p hp
  have h : env17173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17161_17173 : H12AffineEnvironment.transform 6 9 env17161 = env17173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17161 == env17173) = true)

theorem identity17173 : scanCanonicalize (H12AffineFastState.compose env17173 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17173 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,149861,1024,32769,4160,180273,17,3,8193,65,182288,5392,17665,35189,1364,144493,256,21793,46093,41820]

theorem envBound17174 : H12AffineFastState.Bounded env17174 := by
  intro p hp
  have h : env17174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17173_17174 : H12AffineEnvironment.transform 15 33110 env17173 = env17174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17173 == env17174) = true)

def env17175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,8388608,98781,8328,65,12683758,5392,8406289,8456242,8390093,4256860,256,8410416,8434837,8462874]

theorem envBound17175 : H12AffineFastState.Bounded env17175 := by
  intro p hp
  have h : env17175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17127_17175 : H12AffineEnvironment.transform 20 4161 env17127 = env17175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17127 == env17175) = true)

def env17176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98781,8328,65,4295166,5392,17665,67618,1501,4256860,256,21792,46213,74250]

theorem envBound17176 : H12AffineFastState.Bounded env17176 := by
  intro p hp
  have h : env17176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17175_17176 : H12AffineEnvironment.transform 22 16 env17175 = env17176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17175 == env17176) = true)

theorem identity17176 : scanCanonicalize (H12AffineFastState.compose env17176 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17176 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212199,1024,29909,4161,4194304,16,95497,8328,65,4291882,5392,17665,67618,1501,4194440,256,21792,16465,74250]

theorem envBound17177 : H12AffineFastState.Bounded env17177 := by
  intro p hp
  have h : env17177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17176_17177 : H12AffineEnvironment.transform 14 29908 env17176 = env17177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17176 == env17177) = true)

def env17178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212199,1024,8661,4161,4194304,16,73737,8328,65,4270122,5392,4097,67618,1501,4194440,256,32,5457,74250]

theorem envBound17178 : H12AffineFastState.Bounded env17178 := by
  intro p hp
  have h : env17178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17177_17178 : H12AffineEnvironment.transform 13 5376 env17177 = env17178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17177 == env17178) = true)

theorem identity17178 : scanCanonicalize (H12AffineFastState.compose env17178 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound17178 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,67754,1024,8661,4161,4194304,16,73737,8328,65,4270122,5392,4097,67618,1501,4194440,256,32,5457,74250]

theorem envBound17179 : H12AffineFastState.Bounded env17179 := by
  intro p hp
  have h : env17179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17178_17179 : H12AffineEnvironment.transform 16 13389 env17178 = env17179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env17178 == env17179) = true)

theorem identity17179 : scanCanonicalize (H12AffineFastState.compose env17179 (packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 73851) := by decide +kernel

theorem selectedBound17179 : packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS < 2^1333 := by decide +kernel

def env17180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,67754,1024,8661,4161,73851,16,73737,8328,65,2129,5392,4097,67618,1501,73971,256,32,5457,74250]

theorem envBound17180 : H12AffineFastState.Bounded env17180 := by
  intro p hp
  have h : env17180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17179_17180 : H12AffineEnvironment.transform 21 73851 env17179 = env17180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73851 env17179 == env17180) = true)

theorem identity17180 : scanCanonicalize (H12AffineFastState.compose env17180 (packedSelected [2,3,4,5,6,10,16,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound17180 : packedSelected [2,3,4,5,6,10,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env17181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8282,13389,10480,1024,8661,4161,33,16,83,8328,65,2129,5392,4097,10360,1501,169,256,32,5457,592]

theorem envBound17181 : H12AffineFastState.Bounded env17181 := by
  intro p hp
  have h : env17181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17180_17181 : H12AffineEnvironment.transform 15 8282 env17180 = env17181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env17180 == env17181) = true)

theorem identity17181 : scanCanonicalize (H12AffineFastState.compose env17181 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17181 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env17182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,263,5392,2477,1024,136,4161,33,16,83,469,65,2129,5392,4097,2341,1501,169,256,32,5457,592]

theorem envBound17182 : H12AffineFastState.Bounded env17182 := by
  intro p hp
  have h : env17182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17181_17182 : H12AffineEnvironment.transform 12 349 env17181 = env17182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17181 == env17182) = true)

theorem identity17182 : scanCanonicalize (H12AffineFastState.compose env17182 (packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3324) := by decide +kernel

theorem selectedBound17182 : packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,349,2556,137,263,2540,2477,1024,136,3261,33,16,83,469,65,2129,2540,3325,2341,1501,169,256,32,2477,592]

theorem envBound17183 : H12AffineFastState.Bounded env17183 := by
  intro p hp
  have h : env17183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17182_17183 : H12AffineEnvironment.transform 11 3324 env17182 = env17183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3324 env17182 == env17183) = true)

theorem identity17183 : scanCanonicalize (H12AffineFastState.compose env17183 (packedSelected [0,1,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound17183 : packedSelected [0,1,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1092,184,349,1464,137,263,1448,1513,1024,136,249,33,16,83,469,65,1045,1448,185,1377,1501,169,256,32,1513,592]

theorem envBound17184 : H12AffineFastState.Bounded env17184 := by
  intro p hp
  have h : env17184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17183_17184 : H12AffineEnvironment.transform 10 1092 env17183 = env17184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env17183 == env17184) = true)

theorem identity17184 : scanCanonicalize (H12AffineFastState.compose env17184 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17184 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env17185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1092,48,349,1328,1,263,1312,1377,1024,0,113,33,16,83,349,65,1045,1312,49,1377,1365,33,256,32,1377,592]

theorem envBound17185 : H12AffineFastState.Bounded env17185 := by
  intro p hp
  have h : env17185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17184_17185 : H12AffineEnvironment.transform 6 8 env17184 = env17185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17184 == env17185) = true)

theorem identity17185 : scanCanonicalize (H12AffineFastState.compose env17185 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17185 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env17186 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1045,48,268,1328,1,263,1312,1328,1024,0,32,33,16,2,268,16,1045,1312,49,1328,1284,33,256,32,1328,513]

theorem envBound17186 : H12AffineFastState.Bounded env17186 := by
  intro p hp
  have h : env17186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17185_17186 : H12AffineEnvironment.transform 5 17 env17185 = env17186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17185 == env17186) = true)

theorem identity17186 : scanCanonicalize (H12AffineFastState.compose env17186 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17187 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1045,48,40,1044,1,35,1028,1044,1024,0,32,33,16,2,40,16,1045,1028,49,1044,1056,33,36,32,1044,513]

theorem envBound17187 : H12AffineFastState.Bounded env17187 := by
  intro p hp
  have h : env17187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17186_17187 : H12AffineEnvironment.transform 7 36 env17186 = env17187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17186 == env17187) = true)

theorem identity17187 : scanCanonicalize (H12AffineFastState.compose env17187 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 512) := by decide +kernel

theorem selectedBound17187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17188 : List Nat := [2,4,8,16,32,17,8,36,512,512,533,48,40,532,1,35,516,532,512,0,32,33,16,2,40,16,533,516,49,532,544,33,36,32,532,513]

theorem envBound17188 : H12AffineFastState.Bounded env17188 := by
  intro p hp
  have h : env17188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17187_17188 : H12AffineEnvironment.transform 9 512 env17187 = env17188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 512 env17187 == env17188) = true)

theorem identity17188 : scanCanonicalize (H12AffineFastState.compose env17188 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound17188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17189 : List Nat := [2,4,8,15,32,14,8,36,512,512,522,47,40,523,1,35,516,523,512,0,32,33,15,2,40,15,522,516,46,523,544,33,36,32,523,513]

theorem envBound17189 : H12AffineFastState.Bounded env17189 := by
  intro p hp
  have h : env17189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17188_17189 : H12AffineEnvironment.transform 3 15 env17188 = env17189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env17188 == env17189) = true)

theorem identity17189 : scanCanonicalize (H12AffineFastState.compose env17189 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound17189 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17190 : List Nat := [2,4,8,15,32,14,8,36,12,12,6,47,40,7,1,35,8,7,12,0,32,33,15,2,40,15,6,8,46,7,44,33,36,32,7,13]

theorem envBound17190 : H12AffineFastState.Bounded env17190 := by
  intro p hp
  have h : env17190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17189_17190 : H12AffineEnvironment.transform 8 12 env17189 = env17190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env17189 == env17190) = true)

def env17191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212199,1024,8660,4161,4194304,16,73736,8328,65,4270123,5392,4096,67618,1501,4194440,256,33,5456,74250]

theorem envBound17191 : H12AffineFastState.Bounded env17191 := by
  intro p hp
  have h : env17191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17177_17191 : H12AffineEnvironment.transform 13 5377 env17177 = env17191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17177 == env17191) = true)

theorem identity17191 : scanCanonicalize (H12AffineFastState.compose env17191 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound17191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,67618,1024,8660,4161,4194304,16,73736,8328,65,4270123,5392,4096,67618,1501,4194440,256,33,5456,74250]

theorem envBound17192 : H12AffineFastState.Bounded env17192 := by
  intro p hp
  have h : env17192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17191_17192 : H12AffineEnvironment.transform 16 13509 env17191 = env17192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env17191 == env17192) = true)

theorem identity17192 : scanCanonicalize (H12AffineFastState.compose env17192 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17192 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13509,10281,1024,8660,4161,4194304,16,3,8328,65,4196384,5392,4096,10281,1501,4194440,256,33,5456,513]

theorem envBound17193 : H12AffineFastState.Bounded env17193 := by
  intro p hp
  have h : env17193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17192_17193 : H12AffineEnvironment.transform 15 8203 env17192 = env17193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17192 == env17193) = true)

theorem identity17193 : scanCanonicalize (H12AffineFastState.compose env17193 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound17193 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13509,10281,1024,8660,4161,248,16,3,8328,65,2264,5392,4096,10281,1501,112,256,33,5456,513]

theorem envBound17194 : H12AffineFastState.Bounded env17194 := by
  intro p hp
  have h : env17194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17193_17194 : H12AffineEnvironment.transform 21 248 env17193 = env17194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env17193 == env17194) = true)

theorem identity17194 : scanCanonicalize (H12AffineFastState.compose env17194 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound17194 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,478,5392,2556,1024,1,4161,248,16,3,349,65,2264,5392,4096,2556,1501,112,256,33,5456,513]

theorem envBound17195 : H12AffineFastState.Bounded env17195 := by
  intro p hp
  have h : env17195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17194_17195 : H12AffineEnvironment.transform 12 469 env17194 = env17195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env17194 == env17195) = true)

theorem identity17195 : scanCanonicalize (H12AffineFastState.compose env17195 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17195 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env17196 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,0,398,5392,2476,1024,1,4113,168,16,3,269,17,2184,5392,4096,2476,1421,32,256,33,5376,513]

theorem envBound17196 : H12AffineFastState.Bounded env17196 := by
  intro p hp
  have h : env17196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17195_17196 : H12AffineEnvironment.transform 5 16 env17195 = env17196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17195 == env17196) = true)

theorem identity17196 : scanCanonicalize (H12AffineFastState.compose env17196 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound17196 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17197 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2097,389,3376,0,398,3361,2476,1024,1,2080,168,16,3,269,17,2184,3361,2097,2476,1421,32,256,33,3377,513]

theorem envBound17197 : H12AffineFastState.Bounded env17197 := by
  intro p hp
  have h : env17197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17196_17197 : H12AffineEnvironment.transform 11 2097 env17196 = env17197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env17196 == env17197) = true)

theorem identity17197 : scanCanonicalize (H12AffineFastState.compose env17197 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound17197 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env17198 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,2097,389,2729,0,398,2744,2476,921,1,2080,168,16,3,269,17,2184,2744,2097,2476,532,32,256,33,2728,513]

theorem envBound17198 : H12AffineFastState.Bounded env17198 := by
  intro p hp
  have h : env17198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17197_17198 : H12AffineEnvironment.transform 9 921 env17197 = env17198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env17197 == env17198) = true)

theorem identity17198 : scanCanonicalize (H12AffineFastState.compose env17198 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17198 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17199 : List Nat := [2,4,8,16,32,16,41,256,512,816,2048,2097,300,2560,0,295,2577,2309,816,1,2080,1,16,3,269,17,2081,2577,2097,2309,532,32,256,33,2561,513]

theorem envBound17199 : H12AffineFastState.Bounded env17199 := by
  intro p hp
  have h : env17199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17198_17199 : H12AffineEnvironment.transform 6 41 env17198 = env17199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17198 == env17199) = true)

theorem identity17199 : scanCanonicalize (H12AffineFastState.compose env17199 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17199 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env17200 : List Nat := [2,4,8,16,32,16,41,256,277,37,2048,2097,300,2325,0,295,2308,2309,37,1,2080,1,16,3,269,17,2081,2308,2097,2309,257,32,256,33,2324,276]

theorem envBound17200 : H12AffineFastState.Bounded env17200 := by
  intro p hp
  have h : env17200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17199_17200 : H12AffineEnvironment.transform 8 277 env17199 = env17200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17199 == env17200) = true)

theorem identity17200 : scanCanonicalize (H12AffineFastState.compose env17200 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17200 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env17201 : List Nat := [2,4,8,16,16,16,25,256,277,21,2048,2049,284,2325,0,279,2308,2309,21,1,2064,1,16,3,269,17,2065,2308,2049,2309,257,16,256,17,2324,276]

theorem envBound17201 : H12AffineFastState.Bounded env17201 := by
  intro p hp
  have h : env17201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17200_17201 : H12AffineEnvironment.transform 4 16 env17200 = env17201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17200 == env17201) = true)

theorem identity17201 : scanCanonicalize (H12AffineFastState.compose env17201 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17201 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env17202 : List Nat := [2,4,8,1,1,1,8,256,260,4,2048,2049,269,2308,0,262,2308,2309,4,1,2049,1,1,3,269,0,2048,2308,2049,2309,257,1,256,0,2309,261]

theorem envBound17202 : H12AffineFastState.Bounded env17202 := by
  intro p hp
  have h : env17202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17201_17202 : H12AffineEnvironment.transform 3 1 env17201 = env17202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17201 == env17202) = true)

theorem identity17202 : scanCanonicalize (H12AffineFastState.compose env17202 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound17202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17203 : List Nat := [2,4,8,1,1,1,8,256,260,4,260,261,269,0,0,262,0,1,4,1,261,1,1,3,269,0,260,0,261,1,257,1,256,0,1,261]

theorem envBound17203 : H12AffineFastState.Bounded env17203 := by
  intro p hp
  have h : env17203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17202_17203 : H12AffineEnvironment.transform 10 260 env17202 = env17203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17202 == env17203) = true)

def env17204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,17,98781,8328,65,4295167,5392,17664,67619,1500,4256860,256,21793,46212,74251]

theorem envBound17204 : H12AffineFastState.Bounded env17204 := by
  intro p hp
  have h : env17204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17175_17204 : H12AffineEnvironment.transform 22 17 env17175 = env17204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17175 == env17204) = true)

theorem identity17204 : scanCanonicalize (H12AffineFastState.compose env17204 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound17204 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,144492,17,98781,8328,65,245139,5392,17664,67619,1500,180272,256,21793,46212,74251]

theorem envBound17205 : H12AffineFastState.Bounded env17205 := by
  intro p hp
  have h : env17205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17204_17205 : H12AffineEnvironment.transform 21 144492 env17204 = env17205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env17204 == env17205) = true)

def env17206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,144492,17,98645,8192,65,245019,5392,17664,67619,1364,180272,256,21793,46092,74251]

theorem envBound17206 : H12AffineFastState.Bounded env17206 := by
  intro p hp
  have h : env17206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17205_17206 : H12AffineEnvironment.transform 6 8 env17205 = env17206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17205 == env17206) = true)

theorem identity17206 : scanCanonicalize (H12AffineFastState.compose env17206 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17206 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,144492,17,41311,8192,65,171281,5392,17664,10281,1364,180272,256,21793,46092,513]

theorem envBound17207 : H12AffineFastState.Bounded env17207 := by
  intro p hp
  have h : env17207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17206_17207 : H12AffineEnvironment.transform 15 8202 env17206 = env17207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17206 == env17207) = true)

theorem identity17207 : scanCanonicalize (H12AffineFastState.compose env17207 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound17207 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24861,35108,1024,32769,4161,21873,17,41311,8192,65,64524,5392,17664,10281,1364,41261,256,21793,46092,513]

theorem envBound17208 : H12AffineFastState.Bounded env17208 := by
  intro p hp
  have h : env17208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17207_17208 : H12AffineEnvironment.transform 16 24861 env17207 = env17208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env17207 == env17208) = true)

theorem identity17208 : scanCanonicalize (H12AffineFastState.compose env17208 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17208 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,16400,35108,1024,32769,4161,21873,17,32850,269,65,56577,5392,17664,2340,1364,32800,256,21793,38145,513]

theorem envBound17209 : H12AffineFastState.Bounded env17209 := by
  intro p hp
  have h : env17209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17208_17209 : H12AffineEnvironment.transform 12 269 env17208 = env17209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17208 == env17209) = true)

theorem identity17209 : scanCanonicalize (H12AffineFastState.compose env17209 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound17209 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,263,16400,2421,1024,80,4161,21873,17,3,269,65,23888,5392,17664,2340,1364,113,256,21793,5456,513]

theorem envBound17210 : H12AffineFastState.Bounded env17210 := by
  intro p hp
  have h : env17210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17209_17210 : H12AffineEnvironment.transform 14 81 env17209 = env17210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env17209 == env17210) = true)

theorem identity17210 : scanCanonicalize (H12AffineFastState.compose env17210 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17210 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17211 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1024,0,4113,21793,17,3,269,17,23808,5392,17664,2340,1284,33,256,21793,5376,513]

theorem envBound17211 : H12AffineFastState.Bounded env17211 := by
  intro p hp
  have h : env17211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17210_17211 : H12AffineEnvironment.transform 5 16 env17210 = env17211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17210 == env17211) = true)

theorem identity17211 : scanCanonicalize (H12AffineFastState.compose env17211 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 7936) := by decide +kernel

theorem selectedBound17211 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17212 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7936,1,263,7952,2341,1024,0,4113,2593,17,3,269,17,512,5392,6656,2340,1284,33,256,2593,5376,513]

theorem envBound17212 : H12AffineFastState.Bounded env17212 := by
  intro p hp
  have h : env17212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17211_17212 : H12AffineEnvironment.transform 13 7936 env17211 = env17212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7936 env17211 == env17212) = true)

theorem identity17212 : scanCanonicalize (H12AffineFastState.compose env17212 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound17212 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17213 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,6672,1,263,6656,2341,272,0,4113,2593,17,3,269,17,512,4096,6656,2340,20,33,256,2593,4112,513]

theorem envBound17213 : H12AffineFastState.Bounded env17213 := by
  intro p hp
  have h : env17213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17212_17213 : H12AffineEnvironment.transform 9 272 env17212 = env17213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17212 == env17213) = true)

theorem identity17213 : scanCanonicalize (H12AffineFastState.compose env17213 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound17213 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env17214 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2064,269,512,1,263,528,2341,272,0,2049,2593,17,3,269,17,512,2064,528,2340,20,33,256,2593,2048,513]

theorem envBound17214 : H12AffineFastState.Bounded env17214 := by
  intro p hp
  have h : env17214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17213_17214 : H12AffineEnvironment.transform 11 2064 env17213 = env17214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env17213 == env17214) = true)

theorem identity17214 : scanCanonicalize (H12AffineFastState.compose env17214 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound17214 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17215 : List Nat := [2,4,8,16,32,16,8,52,512,36,2048,2064,57,512,1,51,528,2065,36,0,2049,2593,17,3,57,17,512,2064,528,2064,20,33,52,2593,2048,513]

theorem envBound17215 : H12AffineFastState.Bounded env17215 := by
  intro p hp
  have h : env17215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17214_17215 : H12AffineEnvironment.transform 7 52 env17214 = env17215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env17214 == env17215) = true)

def env17216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,144492,17,98644,8193,65,245018,5392,17664,67619,1365,180272,256,21793,46093,74251]

theorem envBound17216 : H12AffineFastState.Bounded env17216 := by
  intro p hp
  have h : env17216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17205_17216 : H12AffineEnvironment.transform 6 9 env17205 = env17216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17205 == env17216) = true)

theorem identity17216 : scanCanonicalize (H12AffineFastState.compose env17216 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17216 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,149860,1024,32769,4161,144492,17,3,8193,65,146509,5392,17664,35188,1365,180272,256,21793,46093,41820]

theorem envBound17217 : H12AffineFastState.Bounded env17217 := by
  intro p hp
  have h : env17217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17216_17217 : H12AffineEnvironment.transform 15 33111 env17216 = env17217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17216 == env17217) = true)

theorem identity17217 : scanCanonicalize (H12AffineFastState.compose env17217 (packedSelected [0,3,7,8,9,12,14,15,16,22,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound17217 : packedSelected [0,3,7,8,9,12,14,15,16,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env17218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33111,131072,138512,1024,32769,4161,144492,17,3,8193,65,146509,5392,4468,35188,1365,169028,256,341,46093,41820]

theorem envBound17218 : H12AffineFastState.Bounded env17218 := by
  intro p hp
  have h : env17218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17217_17218 : H12AffineEnvironment.transform 13 5236 env17217 = env17218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env17217 == env17218) = true)

theorem identity17218 : scanCanonicalize (H12AffineFastState.compose env17218 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound17218 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env17219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33111,13625,10281,1024,32769,4161,341,17,3,8193,65,2420,5392,4468,35188,1365,41341,256,341,46093,41820]

theorem envBound17219 : H12AffineFastState.Bounded env17219 := by
  intro p hp
  have h : env17219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17218_17219 : H12AffineEnvironment.transform 16 13625 env17218 = env17219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env17218 == env17219) = true)

theorem identity17219 : scanCanonicalize (H12AffineFastState.compose env17219 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17219 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,8203,13625,10281,1024,8541,4161,341,17,3,8193,65,2420,5392,4468,10280,1365,33,256,341,5457,512]

theorem envBound17220 : H12AffineFastState.Bounded env17220 := by
  intro p hp
  have h : env17220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17219_17220 : H12AffineEnvironment.transform 14 8540 env17219 = env17220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17219 == env17220) = true)

theorem identity17220 : scanCanonicalize (H12AffineFastState.compose env17220 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound17220 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5236,261,82,5472,2160,1024,260,4161,341,17,3,88,65,2420,5392,4468,2161,1365,33,256,341,5457,512]

theorem envBound17221 : H12AffineFastState.Bounded env17221 := by
  intro p hp
  have h : env17221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17220_17221 : H12AffineEnvironment.transform 12 89 env17220 = env17221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env17220 == env17221) = true)

theorem identity17221 : scanCanonicalize (H12AffineFastState.compose env17221 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17221 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env17222 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,40,5125,261,35,5393,2049,1024,260,4144,292,17,3,41,48,2309,5392,4357,2048,1316,33,256,292,5408,512]

theorem envBound17222 : H12AffineFastState.Bounded env17222 := by
  intro p hp
  have h : env17222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17221_17222 : H12AffineEnvironment.transform 5 49 env17221 = env17222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17221 == env17222) = true)

theorem identity17222 : scanCanonicalize (H12AffineFastState.compose env17222 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17222 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17223 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,40,5125,32,35,5172,2049,1024,33,4144,1,17,3,41,48,2080,5173,4128,2048,1025,33,37,1,5125,512]

theorem envBound17223 : H12AffineFastState.Bounded env17223 := by
  intro p hp
  have h : env17223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17222_17223 : H12AffineEnvironment.transform 7 37 env17222 = env17223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17222 == env17223) = true)

def env17224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784942,5393,10507600,8456242,10491277,4256861,256,8410417,8434836,10564186]

theorem envBound17224 : H12AffineFastState.Bounded env17224 := by
  intro p hp
  have h : env17224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17126_17224 : H12AffineEnvironment.transform 23 2199965 env17126 = env17224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env17126 == env17224) = true)

def env17225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,8388608,98781,8328,65,12683758,5393,8406288,8456242,8390093,4256861,256,8410417,8434836,8462874]

theorem envBound17225 : H12AffineFastState.Bounded env17225 := by
  intro p hp
  have h : env17225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17224_17225 : H12AffineEnvironment.transform 20 4160 env17224 = env17225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17224 == env17225) = true)

def env17226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98781,8328,65,4295166,5393,17664,67618,1501,4256861,256,21793,46212,74250]

theorem envBound17226 : H12AffineFastState.Bounded env17226 := by
  intro p hp
  have h : env17226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17225_17226 : H12AffineEnvironment.transform 22 16 env17225 = env17226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17225 == env17226) = true)

theorem identity17226 : scanCanonicalize (H12AffineFastState.compose env17226 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound17226 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138477,1024,32769,4160,4194304,16,21763,8328,65,4218144,5393,17664,56572,1501,4256861,256,21793,46212,63188]

theorem envBound17227 : H12AffineFastState.Bounded env17227 := by
  intro p hp
  have h : env17227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17226_17227 : H12AffineEnvironment.transform 15 54494 env17226 = env17227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env17226 == env17227) = true)

def env17228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138341,1024,32769,4160,4194304,16,21763,8192,65,4218144,5393,17664,56436,1365,4256861,256,21793,46092,63068]

theorem envBound17228 : H12AffineFastState.Bounded env17228 := by
  intro p hp
  have h : env17228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17227_17228 : H12AffineEnvironment.transform 6 8 env17227 = env17228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17227 == env17228) = true)

theorem identity17228 : scanCanonicalize (H12AffineFastState.compose env17228 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound17228 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,56436,1024,32769,4160,4194304,16,21763,8192,65,4218144,5393,17664,56436,1365,4256861,256,21793,46092,63068]

theorem envBound17229 : H12AffineFastState.Bounded env17229 := by
  intro p hp
  have h : env17229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17228_17229 : H12AffineEnvironment.transform 16 49169 env17228 = env17229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env17228 == env17229) = true)

theorem identity17229 : scanCanonicalize (H12AffineFastState.compose env17229 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 54641) := by decide +kernel

theorem selectedBound17229 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,56436,1024,32769,4160,54641,16,21763,8192,65,34897,5393,17664,56436,1365,8492,256,21793,46092,63068]

theorem envBound17230 : H12AffineFastState.Bounded env17230 := by
  intro p hp
  have h : env17230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17229_17230 : H12AffineEnvironment.transform 21 54641 env17229 = env17230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54641 env17229 == env17230) = true)

theorem identity17230 : scanCanonicalize (H12AffineFastState.compose env17230 (packedSelected [0,7,10,11,12,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound17230 : packedSelected [0,7,10,11,12,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env17231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30042,24861,32120,1024,8461,4160,29821,16,21763,8192,65,10589,5393,17664,32120,1365,8492,256,21793,5376,22352]

theorem envBound17231 : H12AffineFastState.Bounded env17231 := by
  intro p hp
  have h : env17231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17230_17231 : H12AffineEnvironment.transform 14 8460 env17230 = env17231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env17230 == env17231) = true)

theorem identity17231 : scanCanonicalize (H12AffineFastState.compose env17231 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17231 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8460,263,5440,2341,1024,8461,4160,32,16,8542,8192,65,10589,5393,12637,2341,1365,8492,256,8572,5376,8973]

theorem envBound17232 : H12AffineFastState.Bounded env17232 := by
  intro p hp
  have h : env17232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17231_17232 : H12AffineEnvironment.transform 13 13405 env17231 = env17232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17231 == env17232) = true)

theorem identity17232 : scanCanonicalize (H12AffineFastState.compose env17232 (packedSelected [1,2,4,7,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound17232 : packedSelected [1,2,4,7,8,15] rootPS < 2^1333 := by decide +kernel

def env17233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,625,8192,9772,8460,263,1841,2341,1024,8461,561,32,16,8542,8192,65,10589,1888,9004,2341,1365,8492,256,8572,1905,8973]

theorem envBound17233 : H12AffineFastState.Bounded env17233 := by
  intro p hp
  have h : env17233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17232_17233 : H12AffineEnvironment.transform 11 625 env17232 = env17233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env17232 == env17233) = true)

theorem identity17233 : scanCanonicalize (H12AffineFastState.compose env17233 (packedSelected [0,2,9,10,11,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17233 : packedSelected [0,2,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env17234 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,544,8192,9772,8460,263,1841,2341,1024,8461,561,32,16,8463,8192,16,10508,1841,9004,2341,1284,8492,256,8493,1824,8973]

theorem envBound17234 : H12AffineFastState.Bounded env17234 := by
  intro p hp
  have h : env17234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17233_17234 : H12AffineEnvironment.transform 5 17 env17233 = env17234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17233 == env17234) = true)

theorem identity17234 : scanCanonicalize (H12AffineFastState.compose env17234 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17234 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env17235 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,512,8192,9740,8460,263,1809,2309,1024,8461,529,0,16,8463,8192,16,10508,1809,8972,2309,1284,8460,256,8461,1792,8973]

theorem envBound17235 : H12AffineFastState.Bounded env17235 := by
  intro p hp
  have h : env17235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17234_17235 : H12AffineEnvironment.transform 4 0 env17234 = env17235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17234 == env17235) = true)

def env17236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138340,1024,32769,4160,4194304,16,21763,8193,65,4218144,5393,17664,56437,1364,4256861,256,21793,46093,63069]

theorem envBound17236 : H12AffineFastState.Bounded env17236 := by
  intro p hp
  have h : env17236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17227_17236 : H12AffineEnvironment.transform 6 9 env17227 = env17236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17227 == env17236) = true)

theorem identity17236 : scanCanonicalize (H12AffineFastState.compose env17236 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound17236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,32041,1024,32769,4160,4194304,16,21763,8193,65,4218144,5393,17664,56437,1364,4256861,256,21793,46093,63069]

theorem envBound17237 : H12AffineFastState.Bounded env17237 := by
  intro p hp
  have h : env17237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17236_17237 : H12AffineEnvironment.transform 16 24909 env17236 = env17237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env17236 == env17237) = true)

theorem identity17237 : scanCanonicalize (H12AffineFastState.compose env17237 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17237 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,32041,1024,32769,4160,32,16,21763,8193,65,23808,5393,17664,56437,1364,62589,256,21793,46093,63069]

theorem envBound17238 : H12AffineFastState.Bounded env17238 := by
  intro p hp
  have h : env17238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17237_17238 : H12AffineEnvironment.transform 21 32 env17237 = env17238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17237 == env17238) = true)

theorem identity17238 : scanCanonicalize (H12AffineFastState.compose env17238 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound17238 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,343,24909,32041,1024,21761,4160,32,16,21763,8193,65,23808,5393,17664,2421,1364,8573,256,21793,24845,9053]

theorem envBound17239 : H12AffineFastState.Bounded env17239 := by
  intro p hp
  have h : env17239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17238_17239 : H12AffineEnvironment.transform 14 21760 env17238 = env17239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env17238 == env17239) = true)

theorem identity17239 : scanCanonicalize (H12AffineFastState.compose env17239 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17239 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,343,16401,23669,1024,21761,4160,32,16,21763,349,65,23808,5393,17664,2421,1364,33,256,21793,16465,513]

theorem envBound17240 : H12AffineFastState.Bounded env17240 := by
  intro p hp
  have h : env17240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17239_17240 : H12AffineEnvironment.transform 12 348 env17239 = env17240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17239 == env17240) = true)

theorem identity17240 : scanCanonicalize (H12AffineFastState.compose env17240 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17241 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,262,16401,23588,1024,21761,4113,32,16,21763,268,16,23808,5393,17664,2340,1285,33,256,21793,16384,513]

theorem envBound17241 : H12AffineFastState.Bounded env17241 := by
  intro p hp
  have h : env17241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17240_17241 : H12AffineEnvironment.transform 5 17 env17240 = env17241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17240 == env17241) = true)

theorem identity17241 : scanCanonicalize (H12AffineFastState.compose env17241 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound17241 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17242 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,269,16384,18177,262,16401,20005,1024,18176,528,32,16,18178,268,16,20225,1808,17664,2340,1285,33,256,18208,16384,513]

theorem envBound17242 : H12AffineFastState.Bounded env17242 := by
  intro p hp
  have h : env17242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17241_17242 : H12AffineEnvironment.transform 11 513 env17241 = env17242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env17241 == env17242) = true)

def env17243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,17,98781,8328,65,4295167,5393,17665,67619,1500,4256861,256,21792,46213,74251]

theorem envBound17243 : H12AffineFastState.Bounded env17243 := by
  intro p hp
  have h : env17243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17225_17243 : H12AffineEnvironment.transform 22 17 env17225 = env17243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17225 == env17243) = true)

theorem identity17243 : scanCanonicalize (H12AffineFastState.compose env17243 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound17243 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,201831,17,98781,8328,65,171416,5393,17665,67619,1500,254010,256,21792,46213,74251]

theorem envBound17244 : H12AffineFastState.Bounded env17244 := by
  intro p hp
  have h : env17244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17243_17244 : H12AffineEnvironment.transform 21 201831 env17243 = env17244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env17243 == env17244) = true)

def env17245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,201831,17,98645,8192,65,171280,5393,17665,67619,1364,254010,256,21792,46093,74251]

theorem envBound17245 : H12AffineFastState.Bounded env17245 := by
  intro p hp
  have h : env17245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17244_17245 : H12AffineEnvironment.transform 6 8 env17244 = env17245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17244 == env17245) = true)

theorem identity17245 : scanCanonicalize (H12AffineFastState.compose env17245 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,144493,17,41311,8192,65,171280,5393,17665,10281,1364,180272,256,21792,46093,513]

theorem envBound17246 : H12AffineFastState.Bounded env17246 := by
  intro p hp
  have h : env17246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17245_17246 : H12AffineEnvironment.transform 15 8202 env17245 = env17246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17245 == env17246) = true)

theorem identity17246 : scanCanonicalize (H12AffineFastState.compose env17246 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound17246 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24861,35108,1024,32769,4160,21872,17,41311,8192,65,64525,5393,17665,10281,1364,41261,256,21792,46093,513]

theorem envBound17247 : H12AffineFastState.Bounded env17247 := by
  intro p hp
  have h : env17247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17246_17247 : H12AffineEnvironment.transform 16 24861 env17246 = env17247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env17246 == env17247) = true)

theorem identity17247 : scanCanonicalize (H12AffineFastState.compose env17247 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17247 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,16400,35108,1024,32769,4160,21872,17,32850,269,65,56576,5393,17665,2340,1364,32800,256,21792,38144,513]

theorem envBound17248 : H12AffineFastState.Bounded env17248 := by
  intro p hp
  have h : env17248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17247_17248 : H12AffineEnvironment.transform 12 269 env17247 = env17248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17247 == env17248) = true)

theorem identity17248 : scanCanonicalize (H12AffineFastState.compose env17248 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound17248 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,263,16400,2421,1024,80,4160,21872,17,3,269,65,23889,5393,17665,2340,1364,113,256,21792,5457,513]

theorem envBound17249 : H12AffineFastState.Bounded env17249 := by
  intro p hp
  have h : env17249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17248_17249 : H12AffineEnvironment.transform 14 81 env17248 = env17249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env17248 == env17249) = true)

def env17250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,201831,17,98644,8193,65,171281,5393,17665,67619,1365,254010,256,21792,46092,74251]

theorem envBound17250 : H12AffineFastState.Bounded env17250 := by
  intro p hp
  have h : env17250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17244_17250 : H12AffineEnvironment.transform 6 9 env17244 = env17250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17244 == env17250) = true)

theorem identity17250 : scanCanonicalize (H12AffineFastState.compose env17250 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17250 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,149860,1024,32769,4160,169264,17,3,8193,65,171281,5393,17665,35188,1365,156013,256,21792,46092,41820]

theorem envBound17251 : H12AffineFastState.Bounded env17251 := by
  intro p hp
  have h : env17251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17250_17251 : H12AffineEnvironment.transform 15 33111 env17250 = env17251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17250 == env17251) = true)

theorem identity17251 : scanCanonicalize (H12AffineFastState.compose env17251 (packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound17251 : packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS < 2^1333 := by decide +kernel

def env17252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,33111,131072,146508,1024,32769,4160,169264,17,3,8193,65,171281,5393,12329,35188,1365,136261,256,8200,46092,41820]

theorem envBound17252 : H12AffineFastState.Bounded env17252 := by
  intro p hp
  have h : env17252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17251_17252 : H12AffineEnvironment.transform 13 13608 env17251 = env17252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env17251 == env17252) = true)

theorem identity17252 : scanCanonicalize (H12AffineFastState.compose env17252 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound17252 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,33111,13624,2420,1024,32769,4160,40968,17,3,8193,65,43049,5393,12329,35188,1365,8573,256,8200,46092,41820]

theorem envBound17253 : H12AffineFastState.Bounded env17253 := by
  intro p hp
  have h : env17253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17252_17253 : H12AffineEnvironment.transform 16 13624 env17252 = env17253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env17252 == env17253) = true)

theorem identity17253 : scanCanonicalize (H12AffineFastState.compose env17253 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound17253 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env17254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,292,115,13624,2420,1024,293,4160,8492,17,3,8193,65,10509,5393,12329,2128,1365,8573,256,8200,13608,8824]

theorem envBound17254 : H12AffineFastState.Bounded env17254 := by
  intro p hp
  have h : env17254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17253_17254 : H12AffineEnvironment.transform 14 292 env17253 = env17254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env17253 == env17254) = true)

theorem identity17254 : scanCanonicalize (H12AffineFastState.compose env17254 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17254 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env17255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,292,115,5221,2420,1024,293,4160,113,17,3,348,65,2128,5393,4468,2128,1365,32,256,341,5237,805]

theorem envBound17255 : H12AffineFastState.Bounded env17255 := by
  intro p hp
  have h : env17255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17254_17255 : H12AffineEnvironment.transform 12 349 env17254 = env17255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17254 == env17255) = true)

theorem identity17255 : scanCanonicalize (H12AffineFastState.compose env17255 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17255 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17256 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5237,1,115,5221,2129,1024,0,4160,113,17,3,121,65,2128,5172,4177,2128,1136,32,37,112,5237,512]

theorem envBound17256 : H12AffineFastState.Bounded env17256 := by
  intro p hp
  have h : env17256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17255_17256 : H12AffineEnvironment.transform 7 37 env17255 = env17256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17255 == env17256) = true)

theorem identity17256 : scanCanonicalize (H12AffineFastState.compose env17256 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17257 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,4096,89,5204,1,82,5188,2129,1024,0,4160,80,17,3,88,65,2128,5141,4177,2128,1105,1,4,81,5204,512]

theorem envBound17257 : H12AffineFastState.Bounded env17257 := by
  intro p hp
  have h : env17257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17256_17257 : H12AffineEnvironment.transform 4 1 env17256 = env17257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17256 == env17257) = true)

def env17258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,8388608,98780,8328,65,12683759,5393,8406289,8456242,8390092,4256861,256,8410417,8434836,8462875]

theorem envBound17258 : H12AffineFastState.Bounded env17258 := by
  intro p hp
  have h : env17258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17224_17258 : H12AffineEnvironment.transform 20 4161 env17224 = env17258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17224 == env17258) = true)

def env17259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98780,8328,65,4295167,5393,17665,67618,1500,4256861,256,21793,46212,74251]

theorem envBound17259 : H12AffineFastState.Bounded env17259 := by
  intro p hp
  have h : env17259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17258_17259 : H12AffineEnvironment.transform 22 16 env17258 = env17259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17258 == env17259) = true)

theorem identity17259 : scanCanonicalize (H12AffineFastState.compose env17259 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17259 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,4194304,16,41430,8328,65,4237813,5393,17665,10280,1500,4256861,256,21793,46212,513]

theorem envBound17260 : H12AffineFastState.Bounded env17260 := by
  intro p hp
  have h : env17260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17259_17260 : H12AffineEnvironment.transform 15 8202 env17259 = env17260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17259 == env17260) = true)

theorem identity17260 : scanCanonicalize (H12AffineFastState.compose env17260 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound17260 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,32937,16,41430,8328,65,10588,5393,17665,10280,1500,29940,256,21793,46212,513]

theorem envBound17261 : H12AffineFastState.Bounded env17261 := by
  intro p hp
  have h : env17261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17260_17261 : H12AffineEnvironment.transform 21 32937 env17260 = env17261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env17260 == env17261) = true)

theorem identity17261 : scanCanonicalize (H12AffineFastState.compose env17261 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17261 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4161,32937,16,41430,8328,65,10588,5393,17665,10280,1500,29940,256,21793,46212,513]

theorem envBound17262 : H12AffineFastState.Bounded env17262 := by
  intro p hp
  have h : env17262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17261_17262 : H12AffineEnvironment.transform 16 16400 env17261 = env17262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17261 == env17262) = true)

theorem identity17262 : scanCanonicalize (H12AffineFastState.compose env17262 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17262 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env17263 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4112,32937,16,41351,8328,16,10509,5393,17665,10280,1421,29861,256,21793,46212,513]

theorem envBound17263 : H12AffineFastState.Bounded env17263 := by
  intro p hp
  have h : env17263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17262_17263 : H12AffineEnvironment.transform 5 17 env17262 = env17263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17262 == env17263) = true)

theorem identity17263 : scanCanonicalize (H12AffineFastState.compose env17263 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17263 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env17264 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4112,32801,16,41231,8192,16,10509,5393,17665,10280,1285,29741,256,21793,46092,513]

theorem envBound17264 : H12AffineFastState.Bounded env17264 := by
  intro p hp
  have h : env17264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17263_17264 : H12AffineEnvironment.transform 6 8 env17263 = env17264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17263 == env17264) = true)

theorem identity17264 : scanCanonicalize (H12AffineFastState.compose env17264 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17264 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17265 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,8202,16400,10281,1024,1,4112,33,16,8463,8192,16,10509,5393,17665,10280,1285,29741,256,21793,13324,513]

theorem envBound17265 : H12AffineFastState.Bounded env17265 := by
  intro p hp
  have h : env17265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17264_17265 : H12AffineEnvironment.transform 14 0 env17264 = env17265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17264 == env17265) = true)

theorem identity17265 : scanCanonicalize (H12AffineFastState.compose env17265 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17265 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env17266 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,0,8202,5393,10281,1024,1,4112,33,16,8463,8192,16,10509,5393,4096,10280,1285,8492,256,32,13324,513]

theorem envBound17266 : H12AffineFastState.Bounded env17266 := by
  intro p hp
  have h : env17266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17265_17266 : H12AffineEnvironment.transform 13 5377 env17265 = env17266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17265 == env17266) = true)

theorem identity17266 : scanCanonicalize (H12AffineFastState.compose env17266 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 3644) := by decide +kernel

theorem selectedBound17266 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env17267 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3644,5377,0,3638,5393,1557,1024,1,4112,33,16,3891,3644,16,1841,5393,4096,1556,1285,3856,256,32,6704,513]

theorem envBound17267 : H12AffineFastState.Bounded env17267 := by
  intro p hp
  have h : env17267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17266_17267 : H12AffineEnvironment.transform 12 3644 env17266 = env17267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3644 env17266 == env17267) = true)

theorem identity17267 : scanCanonicalize (H12AffineFastState.compose env17267 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1841) := by decide +kernel

theorem selectedBound17267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17268 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1841,4096,269,5377,0,263,5393,1557,1024,1,4112,33,16,2,269,16,1841,5393,4096,1556,1285,33,256,32,5377,513]

theorem envBound17268 : H12AffineFastState.Bounded env17268 := by
  intro p hp
  have h : env17268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17267_17268 : H12AffineEnvironment.transform 10 1841 env17267 = env17268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1841 env17267 == env17268) = true)

theorem identity17268 : scanCanonicalize (H12AffineFastState.compose env17268 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound17268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17269 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1841,1028,269,261,0,263,277,1557,1024,1,1044,33,16,2,269,16,1841,277,1028,1556,1285,33,256,32,261,513]

theorem envBound17269 : H12AffineFastState.Bounded env17269 := by
  intro p hp
  have h : env17269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17268_17269 : H12AffineEnvironment.transform 11 1028 env17268 = env17269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env17268 == env17269) = true)

theorem identity17269 : scanCanonicalize (H12AffineFastState.compose env17269 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound17269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17270 : List Nat := [2,4,8,16,32,17,8,256,512,305,512,309,269,261,0,263,277,804,305,1,293,33,16,2,269,16,512,277,309,805,52,33,256,32,261,513]

theorem envBound17270 : H12AffineFastState.Bounded env17270 := by
  intro p hp
  have h : env17270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17269_17270 : H12AffineEnvironment.transform 9 305 env17269 = env17270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env17269 == env17270) = true)

theorem identity17270 : scanCanonicalize (H12AffineFastState.compose env17270 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17271 : List Nat := [2,4,8,16,0,17,8,256,512,273,512,277,269,261,0,263,277,772,273,1,261,1,16,2,269,16,512,277,277,773,20,1,256,0,261,513]

theorem envBound17271 : H12AffineFastState.Bounded env17271 := by
  intro p hp
  have h : env17271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17270_17271 : H12AffineEnvironment.transform 4 0 env17270 = env17271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17270 == env17271) = true)

theorem identity17271 : scanCanonicalize (H12AffineFastState.compose env17271 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound17271 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17272 : List Nat := [2,4,8,16,0,17,8,256,276,273,276,277,269,261,0,263,277,16,273,1,261,1,16,2,269,16,276,277,277,17,20,1,256,0,261,277]

theorem envBound17272 : H12AffineFastState.Bounded env17272 := by
  intro p hp
  have h : env17272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17271_17272 : H12AffineEnvironment.transform 8 276 env17271 = env17272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env17271 == env17272) = true)

theorem identity17272 : scanCanonicalize (H12AffineFastState.compose env17272 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17272 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17273 : List Nat := [2,4,8,1,0,0,8,256,261,256,261,260,269,261,0,263,260,1,256,1,261,1,1,2,269,1,261,260,260,0,5,1,256,0,261,260]

theorem envBound17273 : H12AffineFastState.Bounded env17273 := by
  intro p hp
  have h : env17273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17272_17273 : H12AffineEnvironment.transform 3 1 env17272 = env17273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17272 == env17273) = true)

theorem identity17273 : scanCanonicalize (H12AffineFastState.compose env17273 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17274 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,9,1,0,3,0,1,4,1,1,1,1,2,9,1,1,0,0,0,5,1,4,0,1,0]

theorem envBound17274 : H12AffineFastState.Bounded env17274 := by
  intro p hp
  have h : env17274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17273_17274 : H12AffineEnvironment.transform 7 4 env17273 = env17274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17273 == env17274) = true)

def env17275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,17,98780,8328,65,4295166,5393,17664,67619,1501,4256861,256,21792,46213,74250]

theorem envBound17275 : H12AffineFastState.Bounded env17275 := by
  intro p hp
  have h : env17275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17258_17275 : H12AffineEnvironment.transform 22 17 env17258 = env17275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17258 == env17275) = true)

theorem identity17275 : scanCanonicalize (H12AffineFastState.compose env17275 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound17275 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,254131,17,98780,8328,65,158029,5393,17664,67619,1501,201966,256,21792,46213,74250]

theorem envBound17276 : H12AffineFastState.Bounded env17276 := by
  intro p hp
  have h : env17276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17275_17276 : H12AffineEnvironment.transform 21 254131 env17275 = env17276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env17275 == env17276) = true)

theorem identity17276 : scanCanonicalize (H12AffineFastState.compose env17276 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17276 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4161,180408,17,41431,8328,65,158029,5393,17664,10280,1501,144613,256,21792,46213,513]

theorem envBound17277 : H12AffineFastState.Bounded env17277 := by
  intro p hp
  have h : env17277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17276_17277 : H12AffineEnvironment.transform 15 8203 env17276 = env17277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17276 == env17277) = true)

theorem identity17277 : scanCanonicalize (H12AffineFastState.compose env17277 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17277 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43049,1024,32769,4161,32937,17,41431,8328,65,10588,5393,17664,10280,1501,29940,256,21792,46213,513]

theorem envBound17278 : H12AffineFastState.Bounded env17278 := by
  intro p hp
  have h : env17278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17277_17278 : H12AffineEnvironment.transform 16 16401 env17277 = env17278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17277 == env17278) = true)

theorem identity17278 : scanCanonicalize (H12AffineFastState.compose env17278 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound17278 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env17279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16401,23588,1024,29708,4161,29860,17,21978,8328,65,10588,5393,17664,10280,1501,29940,256,21792,16520,513]

theorem envBound17279 : H12AffineFastState.Bounded env17279 := by
  intro p hp
  have h : env17279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17278_17279 : H12AffineEnvironment.transform 14 29709 env17278 = env17279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env17278 == env17279) = true)

theorem identity17279 : scanCanonicalize (H12AffineFastState.compose env17279 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17279 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env17280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,0,8203,13340,10281,1024,1,4161,169,17,8663,8328,65,10588,5393,12557,10280,1501,249,256,8493,13445,513]

theorem envBound17280 : H12AffineFastState.Bounded env17280 := by
  intro p hp
  have h : env17280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17279_17280 : H12AffineEnvironment.transform 13 13325 env17279 = env17280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env17279 == env17280) = true)

theorem identity17280 : scanCanonicalize (H12AffineFastState.compose env17280 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound17280 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env17281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3188,8192,10361,0,8203,10344,10281,1024,1,3125,169,17,8663,8328,65,10588,2405,11641,10280,1501,249,256,8493,10481,513]

theorem envBound17281 : H12AffineFastState.Bounded env17281 := by
  intro p hp
  have h : env17281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17280_17281 : H12AffineEnvironment.transform 11 3188 env17280 = env17281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env17280 == env17281) = true)

theorem identity17281 : scanCanonicalize (H12AffineFastState.compose env17281 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound17281 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17282 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3188,8192,10361,0,8203,10344,10281,1024,1,3125,113,17,8463,8272,65,10588,2405,11641,10280,1285,33,256,8493,10281,513]

theorem envBound17282 : H12AffineFastState.Bounded env17282 := by
  intro p hp
  have h : env17282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17281_17282 : H12AffineEnvironment.transform 6 88 env17281 = env17282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env17281 == env17282) = true)

theorem identity17282 : scanCanonicalize (H12AffineFastState.compose env17282 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound17282 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env17283 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3188,1384,3345,0,1379,3328,3393,1024,1,3125,113,17,1127,1336,65,3124,2405,2065,3392,1285,33,256,1093,3393,513]

theorem envBound17283 : H12AffineFastState.Bounded env17283 := by
  intro p hp
  have h : env17283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17282_17283 : H12AffineEnvironment.transform 12 1384 env17282 = env17283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env17282 == env17283) = true)

theorem identity17283 : scanCanonicalize (H12AffineFastState.compose env17283 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17284 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,1337,3345,0,1330,3328,3344,1024,1,3125,32,17,1078,1336,16,3124,2356,2065,3345,1285,33,256,1044,3344,513]

theorem envBound17284 : H12AffineFastState.Bounded env17284 := by
  intro p hp
  have h : env17284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17283_17284 : H12AffineEnvironment.transform 5 17 env17283 = env17284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17283 == env17284) = true)

theorem identity17284 : scanCanonicalize (H12AffineFastState.compose env17284 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17284 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17285 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2065,269,2341,0,262,2356,2340,52,1,2049,32,17,2,268,16,2048,2356,2065,2341,305,33,256,32,2340,513]

theorem envBound17285 : H12AffineFastState.Bounded env17285 := by
  intro p hp
  have h : env17285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17284_17285 : H12AffineEnvironment.transform 9 52 env17284 = env17285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17284 == env17285) = true)

theorem identity17285 : scanCanonicalize (H12AffineFastState.compose env17285 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17286 : List Nat := [2,4,8,16,32,17,9,256,512,52,1,16,269,292,0,262,309,293,52,1,0,32,17,2,268,16,1,309,16,292,305,33,256,32,293,513]

theorem envBound17286 : H12AffineFastState.Bounded env17286 := by
  intro p hp
  have h : env17286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17285_17286 : H12AffineEnvironment.transform 10 1 env17285 = env17286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17285 == env17286) = true)

def env17287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound17287 : H12AffineFastState.Bounded env17287 := by
  intro p hp
  have h : env17287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17124_17287 : H12AffineEnvironment.transform 18 1025 env17124 = env17287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17124 == env17287) = true)

theorem identity17287 : scanCanonicalize (H12AffineFastState.compose env17287 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661170) := by decide +kernel

theorem selectedBound17287 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661170,8328,65,4450483,10857535,10507600,8830976,371874,15027570,257,2485279,2428347,297844]

theorem envBound17288 : H12AffineFastState.Bounded env17288 := by
  intro p hp
  have h : env17288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17287_17288 : H12AffineEnvironment.transform 23 8661170 env17287 = env17288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661170 env17287 == env17288) = true)

def env17289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450363,10857535,10507600,8830976,371754,15027570,257,2485279,2428211,297844]

theorem envBound17289 : H12AffineFastState.Bounded env17289 := by
  intro p hp
  have h : env17289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17288_17289 : H12AffineEnvironment.transform 6 8 env17288 = env17289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17288 == env17289) = true)

theorem identity17289 : scanCanonicalize (H12AffineFastState.compose env17289 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 256367) := by decide +kernel

theorem selectedBound17289 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env17290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,256367,1025,32769,2097152,4194304,8388608,8634709,8192,65,4450363,10634576,10507600,8464751,148805,14853149,257,2229616,2286684,221723]

theorem envBound17290 : H12AffineFastState.Bounded env17290 := by
  intro p hp
  have h : env17290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17289_17290 : H12AffineEnvironment.transform 17 256367 env17289 = env17290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 256367 env17289 == env17290) = true)

def env17291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108927,1025,32769,2097152,4194304,8388608,8487237,8192,65,4302891,10487104,10507600,8464751,1365,14738445,257,2114912,2139212,74251]

theorem envBound17291 : H12AffineFastState.Bounded env17291 := by
  intro p hp
  have h : env17291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17290_17291 : H12AffineEnvironment.transform 16 16400 env17290 = env17291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17290 == env17291) = true)

theorem identity17291 : scanCanonicalize (H12AffineFastState.compose env17291 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound17291 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env17292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108927,1025,32769,2097152,4194304,4194353,4292980,8192,65,4302891,6292849,6313313,4270430,1365,2155580,257,2114912,2139212,74251]

theorem envBound17292 : H12AffineFastState.Bounded env17292 := by
  intro p hp
  have h : env17292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17291_17292 : H12AffineEnvironment.transform 22 4194353 env17291 = env17292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env17291 == env17292) = true)

theorem identity17292 : scanCanonicalize (H12AffineFastState.compose env17292 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17292 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,2097152,4194304,4194353,4235646,8192,65,4229153,6292849,6313313,4196692,1365,2155580,257,2114912,2139212,513]

theorem envBound17293 : H12AffineFastState.Bounded env17293 := by
  intro p hp
  have h : env17293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17292_17293 : H12AffineEnvironment.transform 15 8202 env17292 = env17293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17292 == env17293) = true)

theorem identity17293 : scanCanonicalize (H12AffineFastState.compose env17293 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17293 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,13325,4194304,4194353,4235646,8192,65,4229153,4206972,4219244,4196692,1365,53297,257,29037,36929,513]

theorem envBound17294 : H12AffineFastState.Bounded env17294 := by
  intro p hp
  have h : env17294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17293_17294 : H12AffineEnvironment.transform 20 13325 env17293 = env17294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13325 env17293 == env17294) = true)

theorem identity17294 : scanCanonicalize (H12AffineFastState.compose env17294 (packedSelected [0,7,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17294 : packedSelected [0,7,20,21] rootPS < 2^1333 := by decide +kernel

def env17295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,16400,2420,1025,0,13325,4194304,4194353,4202879,8192,65,4196384,4206972,4219244,4196692,1365,20528,257,29037,4160,513]

theorem envBound17295 : H12AffineFastState.Bounded env17295 := by
  intro p hp
  have h : env17295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17294_17295 : H12AffineEnvironment.transform 14 1 env17294 = env17295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17294 == env17295) = true)

theorem identity17295 : scanCanonicalize (H12AffineFastState.compose env17295 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound17295 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env17296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,1,8202,12637,2420,1025,0,13325,4194304,4194353,4202879,8192,65,4196384,4206972,4198433,4196692,1365,8573,257,32,4160,513]

theorem envBound17296 : H12AffineFastState.Bounded env17296 := by
  intro p hp
  have h : env17296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17295_17296 : H12AffineEnvironment.transform 13 12621 env17295 = env17296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env17295 == env17296) = true)

theorem identity17296 : scanCanonicalize (H12AffineFastState.compose env17296 (packedSelected [3,5,10,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17296 : packedSelected [3,5,10,18,23] rootPS < 2^1333 := by decide +kernel

def env17297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1,343,4096,2420,1025,0,5456,4194304,4194353,4194338,349,65,4196384,4198433,4198433,4196692,1365,32,257,32,4160,513]

theorem envBound17297 : H12AffineFastState.Bounded env17297 := by
  intro p hp
  have h : env17297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17296_17297 : H12AffineEnvironment.transform 12 349 env17296 = env17297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17296 == env17297) = true)

theorem identity17297 : scanCanonicalize (H12AffineFastState.compose env17297 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17297 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1,343,4096,2420,1025,0,5456,32,17,2,349,65,2048,4097,4097,2420,1365,32,257,32,4160,513]

theorem envBound17298 : H12AffineFastState.Bounded env17298 := by
  intro p hp
  have h : env17298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17297_17298 : H12AffineEnvironment.transform 21 32 env17297 = env17298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17297 == env17298) = true)

theorem identity17298 : scanCanonicalize (H12AffineFastState.compose env17298 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17298 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17299 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,349,4112,1,343,4096,2420,100,0,4405,32,17,2,349,65,2048,4097,4097,2420,304,32,257,32,4160,513]

theorem envBound17299 : H12AffineFastState.Bounded env17299 := by
  intro p hp
  have h : env17299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17298_17299 : H12AffineEnvironment.transform 9 101 env17298 = env17299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17298 == env17299) = true)

theorem identity17299 : scanCanonicalize (H12AffineFastState.compose env17299 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17299 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env17300 : List Nat := [2,4,8,16,17,64,8,256,512,84,2048,4096,349,4112,1,343,4096,2373,85,0,4356,17,17,2,349,65,2048,4097,4097,2373,257,17,257,17,4160,513]

theorem envBound17300 : H12AffineFastState.Bounded env17300 := by
  intro p hp
  have h : env17300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17299_17300 : H12AffineEnvironment.transform 4 17 env17299 = env17300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17299 == env17300) = true)

theorem identity17300 : scanCanonicalize (H12AffineFastState.compose env17300 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17300 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17301 : List Nat := [2,4,8,16,17,16,8,256,512,4,2048,4096,269,4112,1,263,4096,2325,5,0,4356,17,17,2,269,17,2048,4097,4097,2325,257,17,257,17,4112,513]

theorem envBound17301 : H12AffineFastState.Bounded env17301 := by
  intro p hp
  have h : env17301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17300_17301 : H12AffineEnvironment.transform 5 16 env17300 = env17301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17300 == env17301) = true)

def env17302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,4194304,8388608,8487236,8192,65,4302890,10487105,10507600,8464751,1364,14738444,257,2114913,2139213,74250]

theorem envBound17302 : H12AffineFastState.Bounded env17302 := by
  intro p hp
  have h : env17302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17290_17302 : H12AffineEnvironment.transform 16 16401 env17290 = env17302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17290 == env17302) = true)

theorem identity17302 : scanCanonicalize (H12AffineFastState.compose env17302 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4235628) := by decide +kernel

theorem selectedBound17302 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env17303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,4194304,4235628,4268072,8192,65,4302890,6333485,6353980,4294659,1364,2114912,257,2114913,2139213,74250]

theorem envBound17303 : H12AffineFastState.Bounded env17303 := by
  intro p hp
  have h : env17303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17302_17303 : H12AffineEnvironment.transform 22 4235628 env17302 = env17303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235628 env17302 == env17303) = true)

theorem identity17303 : scanCanonicalize (H12AffineFastState.compose env17303 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound17303 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,2122860,2147584,2180164,8192,65,2214982,49217,36944,2223215,1364,2114912,257,2114913,2139213,74250]

theorem envBound17304 : H12AffineFastState.Bounded env17304 := by
  intro p hp
  have h : env17304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17303_17304 : H12AffineEnvironment.transform 21 2122860 env17303 = env17304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env17303 == env17304) = true)

theorem identity17304 : scanCanonicalize (H12AffineFastState.compose env17304 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17304 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env17305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,67619,1025,8540,2097152,2122860,2122845,2180164,8192,65,2190619,24860,12557,2182450,1364,2114912,257,2114913,2098448,74250]

theorem envBound17305 : H12AffineFastState.Bounded env17305 := by
  intro p hp
  have h : env17305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17304_17305 : H12AffineEnvironment.transform 14 8541 env17304 = env17305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17304 == env17305) = true)

theorem identity17305 : scanCanonicalize (H12AffineFastState.compose env17305 (packedSelected [3,4,5,9,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17305 : packedSelected [3,4,5,9,19] rootPS < 2^1333 := by decide +kernel

def env17306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1025,8540,2097152,2122860,2122845,2122830,8192,65,2116881,24860,12557,2125112,1364,2114912,257,2114913,2098448,512]

theorem envBound17306 : H12AffineFastState.Bounded env17306 := by
  intro p hp
  have h : env17306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17305_17306 : H12AffineEnvironment.transform 15 8202 env17305 = env17306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17305 == env17306) = true)

theorem identity17306 : scanCanonicalize (H12AffineFastState.compose env17306 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17306 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17307 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,8492,8202,16401,10281,1025,8493,2097152,2122781,2122796,2122815,8192,48,2116881,24860,12557,2125112,1317,2114833,257,2114832,2098448,512]

theorem envBound17307 : H12AffineFastState.Bounded env17307 := by
  intro p hp
  have h : env17307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17306_17307 : H12AffineEnvironment.transform 5 49 env17306 = env17307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17306 == env17307) = true)

theorem identity17307 : scanCanonicalize (H12AffineFastState.compose env17307 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(20+1) ^^^ 17712) := by decide +kernel

theorem selectedBound17307 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env17308 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,8492,8202,16401,10281,1025,8493,17712,8493,8476,8463,8192,48,2081,24860,12557,10248,1317,33,257,32,16416,512]

theorem envBound17308 : H12AffineFastState.Bounded env17308 := by
  intro p hp
  have h : env17308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17307_17308 : H12AffineEnvironment.transform 20 17712 env17307 = env17308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17712 env17307 == env17308) = true)

theorem identity17308 : scanCanonicalize (H12AffineFastState.compose env17308 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17308 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17309 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,5376,8492,8202,5393,10281,1025,8493,4144,8493,8476,8463,8192,48,2081,13340,12557,10248,1317,33,257,32,5408,512]

theorem envBound17309 : H12AffineFastState.Bounded env17309 := by
  intro p hp
  have h : env17309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17308_17309 : H12AffineEnvironment.transform 13 5376 env17308 = env17309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17308 == env17309) = true)

theorem identity17309 : scanCanonicalize (H12AffineFastState.compose env17309 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17309 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17310 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,269,5376,33,263,5393,2340,1025,32,4144,32,17,2,269,48,2081,5393,4096,2309,1317,33,257,32,5408,512]

theorem envBound17310 : H12AffineFastState.Bounded env17310 := by
  intro p hp
  have h : env17310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17309_17310 : H12AffineEnvironment.transform 12 269 env17309 = env17310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17309 == env17310) = true)

theorem identity17310 : scanCanonicalize (H12AffineFastState.compose env17310 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17310 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17311 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,4096,8,5125,33,2,5140,2081,1025,32,4144,32,17,2,8,48,2081,5140,4096,2048,1056,33,4,32,5157,512]

theorem envBound17311 : H12AffineFastState.Bounded env17311 := by
  intro p hp
  have h : env17311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17310_17311 : H12AffineEnvironment.transform 7 5 env17310 = env17311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17310 == env17311) = true)

theorem identity17311 : scanCanonicalize (H12AffineFastState.compose env17311 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17311 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17312 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,1,2,5140,2049,1025,0,4112,0,17,2,8,16,2049,5140,4096,2048,1024,1,4,0,5125,512]

theorem envBound17312 : H12AffineFastState.Bounded env17312 := by
  intro p hp
  have h : env17312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17311_17312 : H12AffineEnvironment.transform 4 0 env17311 = env17312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17311 == env17312) = true)

def env17313 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1045,1,2,1028,2049,1025,0,0,0,17,2,8,16,2049,1028,16,2048,1024,1,4,0,1045,512]

theorem envBound17313 : H12AffineFastState.Bounded env17313 := by
  intro p hp
  have h : env17313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17312_17313 : H12AffineEnvironment.transform 11 16 env17312 = env17313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17312 == env17313) = true)

theorem identity17313 : scanCanonicalize (H12AffineFastState.compose env17313 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound17313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17314 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,16,8,1045,1,2,1028,1045,1025,0,0,0,17,2,8,16,1045,1028,16,1044,1024,1,4,0,1045,512]

theorem envBound17314 : H12AffineFastState.Bounded env17314 := by
  intro p hp
  have h : env17314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17313_17314 : H12AffineEnvironment.transform 10 1044 env17313 = env17314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env17313 == env17314) = true)

def env17315 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,1,2,16,1,21,0,0,0,17,2,8,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound17315 : H12AffineFastState.Bounded env17315 := by
  intro p hp
  have h : env17315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17314_17315 : H12AffineEnvironment.transform 9 20 env17314 = env17315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17314 == env17315) = true)

theorem identity17315 : scanCanonicalize (H12AffineFastState.compose env17315 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17316 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,4,8,1,1,2,4,1,1,0,0,0,5,2,8,4,1,4,4,0,0,1,4,0,1,512]

theorem envBound17316 : H12AffineFastState.Bounded env17316 := by
  intro p hp
  have h : env17316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17315_17316 : H12AffineEnvironment.transform 3 4 env17315 = env17316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17315 == env17316) = true)

def leafEnv17316 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,4,8,1,1,2,4,1,1,0,0,0,5,2,1,8,1,4,1,4,4,0,0,1,4,0,5,2,1,512,1,0,0]

def active17316 : List Nat := [0,1,2,8]

def tree17316 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17316 : H12WitnessSearch.Good tree17316 := H12GlobalWitnessIndex.good

theorem leafIdentity17316 : H12AffineFastState.composeSystem env17316 rootObs = leafEnv17316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17316 rootObs == leafEnv17316) = true)

theorem terminalChecked17316 : H12PackedTerminal.terminalCheckFast leafEnv17316 active17316 tree17316 = true := by decide +kernel

def env17317 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,16,8,0,1,2,17,0,20,0,0,0,17,2,8,16,0,17,16,1,21,1,4,0,0,512]

theorem envBound17317 : H12AffineFastState.Bounded env17317 := by
  intro p hp
  have h : env17317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17314_17317 : H12AffineEnvironment.transform 9 21 env17314 = env17317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17314 == env17317) = true)

theorem identity17317 : scanCanonicalize (H12AffineFastState.compose env17317 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound17317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17318 : List Nat := [2,4,8,16,0,17,8,5,30,21,1,16,8,0,1,2,17,0,20,0,0,0,17,2,8,16,0,17,16,1,21,1,4,0,0,30]

theorem envBound17318 : H12AffineFastState.Bounded env17318 := by
  intro p hp
  have h : env17318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17317_17318 : H12AffineEnvironment.transform 8 30 env17317 = env17318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env17317 == env17318) = true)

def leafEnv17318 : List Nat := [2,4,8,16,0,17,8,5,30,21,1,16,8,0,1,2,17,0,20,0,0,0,17,2,20,8,1,16,0,17,16,1,21,1,4,0,5,2,0,30,1,0,0]

def active17318 : List Nat := [0,1,2,3]

def tree17318 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17318 : H12WitnessSearch.Good tree17318 := H12GlobalWitnessIndex.good

theorem leafIdentity17318 : H12AffineFastState.composeSystem env17318 rootObs = leafEnv17318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17318 rootObs == leafEnv17318) = true)

theorem terminalChecked17318 : H12PackedTerminal.terminalCheckFast leafEnv17318 active17318 tree17318 = true := by decide +kernel

def env17319 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1044,1,2,1029,2049,1025,0,1,0,17,2,8,16,2049,1029,17,2048,1024,1,4,0,1044,512]

theorem envBound17319 : H12AffineFastState.Bounded env17319 := by
  intro p hp
  have h : env17319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17312_17319 : H12AffineEnvironment.transform 11 17 env17312 = env17319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17312 == env17319) = true)

theorem identity17319 : scanCanonicalize (H12AffineFastState.compose env17319 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17320 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,8,1044,1,2,1029,1,1025,0,1,0,17,2,8,16,1,1029,17,0,1024,1,4,0,1044,512]

theorem envBound17320 : H12AffineFastState.Bounded env17320 := by
  intro p hp
  have h : env17320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17319_17320 : H12AffineEnvironment.transform 10 0 env17319 = env17320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17319 == env17320) = true)

def env17321 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,1,2,17,1,21,0,1,0,17,2,8,16,1,17,17,0,20,1,4,0,0,512]

theorem envBound17321 : H12AffineFastState.Bounded env17321 := by
  intro p hp
  have h : env17321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17320_17321 : H12AffineEnvironment.transform 9 20 env17320 = env17321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17320 == env17321) = true)

theorem identity17321 : scanCanonicalize (H12AffineFastState.compose env17321 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17322 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,1,2,5,1,1,0,1,0,5,2,8,4,1,5,5,0,0,1,4,0,0,512]

theorem envBound17322 : H12AffineFastState.Bounded env17322 := by
  intro p hp
  have h : env17322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17321_17322 : H12AffineEnvironment.transform 3 4 env17321 = env17322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17321 == env17322) = true)

def leafEnv17322 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,1,2,5,1,1,0,1,0,5,2,1,8,1,4,1,5,5,0,0,1,4,0,5,2,0,512,1,1,0]

def active17322 : List Nat := [0,1,2,8]

def tree17322 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17322 : H12WitnessSearch.Good tree17322 := H12GlobalWitnessIndex.good

theorem leafIdentity17322 : H12AffineFastState.composeSystem env17322 rootObs = leafEnv17322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17322 rootObs == leafEnv17322) = true)

theorem terminalChecked17322 : H12PackedTerminal.terminalCheckFast leafEnv17322 active17322 tree17322 = true := by decide +kernel

def env17323 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,1,1,2,16,1,20,0,1,0,17,2,8,16,1,16,17,0,21,1,4,0,1,512]

theorem envBound17323 : H12AffineFastState.Bounded env17323 := by
  intro p hp
  have h : env17323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17320_17323 : H12AffineEnvironment.transform 9 21 env17320 = env17323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17320 == env17323) = true)

theorem identity17323 : scanCanonicalize (H12AffineFastState.compose env17323 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound17323 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17324 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,8,1,1,2,16,1,20,0,1,0,17,2,8,16,1,16,17,0,21,1,4,0,1,31]

theorem envBound17324 : H12AffineFastState.Bounded env17324 := by
  intro p hp
  have h : env17324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17323_17324 : H12AffineEnvironment.transform 8 31 env17323 = env17324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env17323 == env17324) = true)

def leafEnv17324 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,8,1,1,2,16,1,20,0,1,0,17,2,20,8,1,16,1,16,17,0,21,1,4,0,5,2,1,31,1,1,0]

def active17324 : List Nat := [0,1,2,3]

def tree17324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17324 : H12WitnessSearch.Good tree17324 := H12GlobalWitnessIndex.good

theorem leafIdentity17324 : H12AffineFastState.composeSystem env17324 rootObs = leafEnv17324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17324 rootObs == leafEnv17324) = true)

theorem terminalChecked17324 : H12PackedTerminal.terminalCheckFast leafEnv17324 active17324 tree17324 = true := by decide +kernel

def env17325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661051,8193,65,4450362,10857535,10507600,8830976,371755,15027570,257,2485279,2428210,297844]

theorem envBound17325 : H12AffineFastState.Bounded env17325 := by
  intro p hp
  have h : env17325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17288_17325 : H12AffineEnvironment.transform 6 9 env17288 = env17325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17288 == env17325) = true)

theorem identity17325 : scanCanonicalize (H12AffineFastState.compose env17325 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound17325 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env17326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8429902,8193,65,4450362,10560842,10507600,8538485,75102,14795783,257,2188650,2196551,513]

theorem envBound17326 : H12AffineFastState.Bounded env17326 := by
  intro p hp
  have h : env17326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17325_17326 : H12AffineEnvironment.transform 17 35189 env17325 = env17326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env17325 == env17326) = true)

def env17327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,16,41310,8193,65,4450362,2172250,2118976,149861,75102,6407191,257,2188650,2196551,513]

theorem envBound17327 : H12AffineFastState.Bounded env17327 := by
  intro p hp
  have h : env17327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17326_17327 : H12AffineEnvironment.transform 22 16 env17326 = env17327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17326 == env17327) = true)

theorem identity17327 : scanCanonicalize (H12AffineFastState.compose env17327 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17327 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2172250,2118976,76159,75102,6407191,257,2188650,2196551,513]

theorem envBound17328 : H12AffineFastState.Bounded env17328 := by
  intro p hp
  have h : env17328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17327_17328 : H12AffineEnvironment.transform 16 90138 env17327 = env17328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17327 == env17328) = true)

theorem identity17328 : scanCanonicalize (H12AffineFastState.compose env17328 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17328 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2139149,2118976,43048,41993,6309184,257,2155581,2098448,513]

theorem envBound17329 : H12AffineFastState.Bounded env17329 := by
  intro p hp
  have h : env17329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17328_17329 : H12AffineEnvironment.transform 15 33111 env17328 = env17329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17328 == env17329) = true)

theorem identity17329 : scanCanonicalize (H12AffineFastState.compose env17329 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17329 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,2097152,4194304,16,2,8193,65,4204924,2098513,2118976,2420,1365,6309184,257,2114913,2098448,513]

theorem envBound17330 : H12AffineFastState.Bounded env17330 := by
  intro p hp
  have h : env17330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17329_17330 : H12AffineEnvironment.transform 14 8540 env17329 = env17330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17329 == env17330) = true)

theorem identity17330 : scanCanonicalize (H12AffineFastState.compose env17330 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound17330 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,2097152,2114912,16,2,8193,65,2124828,2098513,2118976,2420,1365,32,257,2114913,2098448,513]

theorem envBound17331 : H12AffineFastState.Bounded env17331 := by
  intro p hp
  have h : env17331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17330_17331 : H12AffineEnvironment.transform 21 2114912 env17330 = env17331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env17330 == env17331) = true)

theorem identity17331 : scanCanonicalize (H12AffineFastState.compose env17331 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound17331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,25677,8493,16,2,8193,65,2129,24860,12557,2420,1365,32,257,8492,24925,513]

theorem envBound17332 : H12AffineFastState.Bounded env17332 := by
  intro p hp
  have h : env17332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17331_17332 : H12AffineEnvironment.transform 20 25677 env17331 = env17332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env17331 == env17332) = true)

theorem identity17332 : scanCanonicalize (H12AffineFastState.compose env17332 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17332 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,80,263,16401,2341,1025,81,17729,33,16,2,269,65,2129,16400,4097,2420,1365,32,257,32,16465,513]

theorem envBound17333 : H12AffineFastState.Bounded env17333 := by
  intro p hp
  have h : env17333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17332_17333 : H12AffineEnvironment.transform 12 268 env17332 = env17333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17332 == env17333) = true)

theorem identity17333 : scanCanonicalize (H12AffineFastState.compose env17333 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1393) := by decide +kernel

theorem selectedBound17333 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1393,268,16384,80,263,16401,2341,1025,81,17729,33,16,2,269,65,2129,16400,1392,2420,1365,32,257,32,16465,513]

theorem envBound17334 : H12AffineFastState.Bounded env17334 := by
  intro p hp
  have h : env17334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17333_17334 : H12AffineEnvironment.transform 11 1393 env17333 = env17334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1393 env17333 == env17334) = true)

theorem identity17334 : scanCanonicalize (H12AffineFastState.compose env17334 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2624) := by decide +kernel

theorem selectedBound17334 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1393,268,2624,80,263,2641,2341,1025,81,3841,33,16,2,269,65,2129,2640,1392,2420,1365,32,257,32,2577,513]

theorem envBound17335 : H12AffineFastState.Bounded env17335 := by
  intro p hp
  have h : env17335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17334_17335 : H12AffineEnvironment.transform 13 2624 env17334 = env17335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2624 env17334 == env17335) = true)

theorem identity17335 : scanCanonicalize (H12AffineFastState.compose env17335 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17335 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env17336 : List Nat := [2,4,8,16,32,64,9,256,277,1024,2048,1393,268,2389,80,263,2372,2341,1025,81,3092,33,16,2,269,65,2129,2373,1392,2420,1365,32,257,32,2308,276]

theorem envBound17336 : H12AffineFastState.Bounded env17336 := by
  intro p hp
  have h : env17336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17335_17336 : H12AffineEnvironment.transform 8 277 env17335 = env17336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17335 == env17336) = true)

theorem identity17336 : scanCanonicalize (H12AffineFastState.compose env17336 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound17336 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17337 : List Nat := [2,4,8,16,32,64,9,85,64,1024,2048,1060,89,2048,80,82,2065,2160,1025,81,3092,33,16,2,88,65,2129,2064,1061,2081,1024,32,84,32,2129,65]

theorem envBound17337 : H12AffineFastState.Bounded env17337 := by
  intro p hp
  have h : env17337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17336_17337 : H12AffineEnvironment.transform 7 85 env17336 = env17337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env17336 == env17337) = true)

def env17338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,17,41311,8193,65,4450362,2172251,2118977,149860,75102,6407190,257,2188650,2196551,513]

theorem envBound17338 : H12AffineFastState.Bounded env17338 := by
  intro p hp
  have h : env17338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17326_17338 : H12AffineEnvironment.transform 22 17 env17326 = env17338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17326 == env17338) = true)

theorem identity17338 : scanCanonicalize (H12AffineFastState.compose env17338 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound17338 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,115735,4194304,17,41311,8193,65,4450362,57676,102742,149860,75102,4194305,257,41341,16464,513]

theorem envBound17339 : H12AffineFastState.Bounded env17339 := by
  intro p hp
  have h : env17339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17338_17339 : H12AffineEnvironment.transform 20 115735 env17338 = env17339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env17338 == env17339) = true)

def env17340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9293,1025,11577,92463,4194304,17,3175,8193,65,4408578,19572,81006,149860,75102,4194305,257,3141,16464,513]

theorem envBound17340 : H12AffineFastState.Bounded env17340 := by
  intro p hp
  have h : env17340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17339_17340 : H12AffineEnvironment.transform 14 11576 env17339 = env17340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env17339 == env17340) = true)

theorem identity17340 : scanCanonicalize (H12AffineFastState.compose env17340 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85283) := by decide +kernel

theorem selectedBound17340 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env17341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,85283,9293,1025,11577,92463,4194304,17,3175,8193,65,4196385,19572,81006,66631,75102,4194305,257,3141,16464,513]

theorem envBound17341 : H12AffineFastState.Bounded env17341 := by
  intro p hp
  have h : env17341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17340_17341 : H12AffineEnvironment.transform 16 85283 env17340 = env17341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85283 env17340 == env17341) = true)

theorem identity17341 : scanCanonicalize (H12AffineFastState.compose env17341 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound17341 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env17342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,65536,82247,9293,1025,8541,91467,4194304,17,3,8193,65,4195397,16400,77834,66631,75102,4194305,257,33,16464,513]

theorem envBound17342 : H12AffineFastState.Bounded env17342 := by
  intro p hp
  have h : env17342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17341_17342 : H12AffineEnvironment.transform 10 1124 env17341 = env17342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env17341 == env17342) = true)

def env17343 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8460,65536,82199,9245,1025,8461,91419,4194304,17,3,8193,17,4195349,16400,77834,66583,75022,4194305,257,33,16384,513]

theorem envBound17343 : H12AffineFastState.Bounded env17343 := by
  intro p hp
  have h : env17343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17342_17343 : H12AffineEnvironment.transform 5 16 env17342 = env17343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17342 == env17343) = true)

theorem identity17343 : scanCanonicalize (H12AffineFastState.compose env17343 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17343 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17344 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,0,65536,82199,1297,1025,1,82967,4194304,17,3,269,17,4195349,16400,69894,66583,66562,4194305,257,33,16384,513]

theorem envBound17344 : H12AffineFastState.Bounded env17344 := by
  intro p hp
  have h : env17344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17343_17344 : H12AffineEnvironment.transform 12 268 env17343 = env17344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17343 == env17344) = true)

theorem identity17344 : scanCanonicalize (H12AffineFastState.compose env17344 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17344 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17345 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,0,65536,82199,1297,1025,1,82967,32,17,3,269,17,1077,16400,69894,66583,66562,33,257,33,16384,513]

theorem envBound17345 : H12AffineFastState.Bounded env17345 := by
  intro p hp
  have h : env17345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17344_17345 : H12AffineEnvironment.transform 21 32 env17344 = env17345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17344 == env17345) = true)

theorem identity17345 : scanCanonicalize (H12AffineFastState.compose env17345 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17346 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,0,263,16400,1297,1025,1,17680,32,17,3,269,17,1077,16400,4097,1296,1285,33,257,33,16384,513]

theorem envBound17346 : H12AffineFastState.Bounded env17346 := by
  intro p hp
  have h : env17346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17345_17346 : H12AffineEnvironment.transform 15 263 env17345 = env17346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17345 == env17346) = true)

theorem identity17346 : scanCanonicalize (H12AffineFastState.compose env17346 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17347 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,1297,0,263,1281,1297,1025,1,1,32,17,3,269,17,1077,1281,4097,1296,1285,33,257,33,1297,513]

theorem envBound17347 : H12AffineFastState.Bounded env17347 := by
  intro p hp
  have h : env17347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17346_17347 : H12AffineEnvironment.transform 13 1297 env17346 = env17347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env17346 == env17347) = true)

theorem identity17347 : scanCanonicalize (H12AffineFastState.compose env17347 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound17347 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17348 : List Nat := [2,4,8,16,32,16,9,256,512,794,814,4096,268,523,0,263,539,523,795,1,1,32,17,3,269,17,815,539,4097,522,543,33,257,33,523,513]

theorem envBound17348 : H12AffineFastState.Bounded env17348 := by
  intro p hp
  have h : env17348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17347_17348 : H12AffineEnvironment.transform 9 794 env17347 = env17348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env17347 == env17348) = true)

theorem identity17348 : scanCanonicalize (H12AffineFastState.compose env17348 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17348 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17349 : List Nat := [2,4,8,16,32,16,9,5,512,543,555,4096,9,523,0,2,539,523,542,1,1,32,17,3,8,17,554,539,4097,522,543,33,4,33,523,513]

theorem envBound17349 : H12AffineFastState.Bounded env17349 := by
  intro p hp
  have h : env17349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17348_17349 : H12AffineEnvironment.transform 7 5 env17348 = env17349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17348 == env17349) = true)

theorem identity17349 : scanCanonicalize (H12AffineFastState.compose env17349 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound17349 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17350 : List Nat := [2,4,8,16,32,16,9,5,512,543,555,17,9,523,0,2,539,523,542,1,1,32,17,3,8,17,554,539,16,522,543,33,4,33,523,513]

theorem envBound17350 : H12AffineFastState.Bounded env17350 := by
  intro p hp
  have h : env17350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17349_17350 : H12AffineEnvironment.transform 11 17 env17349 = env17350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17349 == env17350) = true)

theorem identity17350 : scanCanonicalize (H12AffineFastState.compose env17350 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound17350 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17351 : List Nat := [2,4,8,16,32,16,9,5,10,21,33,17,9,1,0,2,17,1,20,1,1,32,17,3,8,17,32,17,16,0,21,33,4,33,1,11]

theorem envBound17351 : H12AffineFastState.Bounded env17351 := by
  intro p hp
  have h : env17351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17350_17351 : H12AffineEnvironment.transform 8 10 env17350 = env17351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env17350 == env17351) = true)

theorem identity17351 : scanCanonicalize (H12AffineFastState.compose env17351 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17351 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17352 : List Nat := [2,4,8,16,1,16,9,5,10,21,0,17,9,1,0,2,17,1,20,1,1,1,17,3,8,17,1,17,16,0,21,0,4,0,1,11]

theorem envBound17352 : H12AffineFastState.Bounded env17352 := by
  intro p hp
  have h : env17352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17351_17352 : H12AffineEnvironment.transform 4 1 env17351 = env17352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17351 == env17352) = true)

theorem identity17352 : scanCanonicalize (H12AffineFastState.compose env17352 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound17352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17353 : List Nat := [2,4,8,14,1,14,9,5,10,11,0,15,9,1,0,2,15,1,10,1,1,1,15,3,8,15,1,15,14,0,11,0,4,0,1,11]

theorem envBound17353 : H12AffineFastState.Bounded env17353 := by
  intro p hp
  have h : env17353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17352_17353 : H12AffineEnvironment.transform 3 14 env17352 = env17353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env17352 == env17353) = true)

theorem identity17353 : scanCanonicalize (H12AffineFastState.compose env17353 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound17353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17354 : List Nat := [2,4,1,7,1,7,0,5,3,2,0,6,0,1,0,2,6,1,3,1,1,1,6,3,1,6,1,6,7,0,2,0,4,0,1,2]

theorem envBound17354 : H12AffineFastState.Bounded env17354 := by
  intro p hp
  have h : env17354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17353_17354 : H12AffineEnvironment.transform 2 1 env17353 = env17354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env17353 == env17354) = true)

def env17355 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8461,65536,82198,9244,1025,8460,91418,4194304,17,3,8193,16,4195348,16400,77834,66582,75023,4194305,257,33,16385,513]

theorem envBound17355 : H12AffineFastState.Bounded env17355 := by
  intro p hp
  have h : env17355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17342_17355 : H12AffineEnvironment.transform 5 17 env17342 = env17355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17342 == env17355) = true)

theorem identity17355 : scanCanonicalize (H12AffineFastState.compose env17355 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17355 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17356 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8461,262,16400,9244,1025,8460,25628,4194304,17,3,8193,16,4195348,16400,12556,1296,9225,4194305,257,33,16385,513]

theorem envBound17356 : H12AffineFastState.Bounded env17356 := by
  intro p hp
  have h : env17356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17355_17356 : H12AffineEnvironment.transform 15 262 env17355 = env17356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17355 == env17356) = true)

theorem identity17356 : scanCanonicalize (H12AffineFastState.compose env17356 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17356 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8461,262,16400,9244,1025,8460,25628,32,17,3,8193,16,1076,16400,12556,1296,9225,33,257,33,16385,513]

theorem envBound17357 : H12AffineFastState.Bounded env17357 := by
  intro p hp
  have h : env17357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17356_17357 : H12AffineEnvironment.transform 21 32 env17356 = env17357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17356 == env17357) = true)

theorem identity17357 : scanCanonicalize (H12AffineFastState.compose env17357 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 9528) := by decide +kernel

theorem selectedBound17357 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env17358 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,9528,8461,262,9512,9244,1025,8460,292,32,17,3,8193,16,1076,9512,12556,1296,9225,33,257,33,9529,513]

theorem envBound17358 : H12AffineFastState.Bounded env17358 := by
  intro p hp
  have h : env17358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17357_17358 : H12AffineEnvironment.transform 13 9528 env17357 = env17358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9528 env17357 == env17358) = true)

def env17359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9292,1025,11576,92462,4194304,17,3174,8193,65,4408579,19573,81007,149860,75102,4194305,257,3140,16464,513]

theorem envBound17359 : H12AffineFastState.Bounded env17359 := by
  intro p hp
  have h : env17359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17339_17359 : H12AffineEnvironment.transform 14 11577 env17339 = env17359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env17339 == env17359) = true)

theorem identity17359 : scanCanonicalize (H12AffineFastState.compose env17359 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound17359 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env17360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,82247,9292,1025,11576,92462,4194304,17,3174,8193,65,4195396,19573,81007,67619,75102,4194305,257,3140,16464,513]

theorem envBound17360 : H12AffineFastState.Bounded env17360 := by
  intro p hp
  have h : env17360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17359_17360 : H12AffineEnvironment.transform 16 82247 env17359 = env17360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env17359 == env17360) = true)

def env17361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,65536,82247,9292,1025,8540,91466,4194304,17,2,8193,65,4195396,16401,77835,66631,75102,4194305,257,32,16464,513]

theorem envBound17361 : H12AffineFastState.Bounded env17361 := by
  intro p hp
  have h : env17361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17360_17361 : H12AffineEnvironment.transform 10 1124 env17360 = env17361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env17360 == env17361) = true)

theorem identity17361 : scanCanonicalize (H12AffineFastState.compose env17361 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound17361 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,28698,12637,9292,1025,8540,5456,4194304,17,2,8193,65,4195396,16401,16401,29789,21828,4194305,257,32,16464,513]

theorem envBound17362 : H12AffineFastState.Bounded env17362 := by
  intro p hp
  have h : env17362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17361_17362 : H12AffineEnvironment.transform 15 28698 env17361 = env17362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env17361 == env17362) = true)

theorem identity17362 : scanCanonicalize (H12AffineFastState.compose env17362 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound17362 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env17363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,41,16384,372,20531,4468,1125,1025,373,5456,4194304,17,2,40,65,4195396,16401,16401,21620,21828,4194305,257,32,16464,513]

theorem envBound17363 : H12AffineFastState.Bounded env17363 := by
  intro p hp
  have h : env17363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17362_17363 : H12AffineEnvironment.transform 12 41 env17362 = env17363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env17362 == env17363) = true)

theorem identity17363 : scanCanonicalize (H12AffineFastState.compose env17363 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17363 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env17364 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,0,20531,4096,1125,1025,1,5156,4194304,17,2,40,65,4195396,16401,16401,21620,21552,4194305,117,32,16464,513]

theorem envBound17364 : H12AffineFastState.Bounded env17364 := by
  intro p hp
  have h : env17364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17363_17364 : H12AffineEnvironment.transform 7 116 env17363 = env17364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17363 == env17364) = true)

theorem identity17364 : scanCanonicalize (H12AffineFastState.compose env17364 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1045) := by decide +kernel

theorem selectedBound17364 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17365 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,0,20531,4096,1125,1025,1,5156,1045,17,2,40,65,81,16401,16401,21620,21552,1044,117,32,16464,513]

theorem envBound17365 : H12AffineFastState.Bounded env17365 := by
  intro p hp
  have h : env17365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17364_17365 : H12AffineEnvironment.transform 21 1045 env17364 = env17365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1045 env17364 == env17365) = true)

theorem identity17365 : scanCanonicalize (H12AffineFastState.compose env17365 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound17365 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env17366 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,1,0,4146,4096,1125,1025,1,5156,1045,17,2,40,65,81,16,16,5237,5169,1044,117,32,81,513]

theorem envBound17366 : H12AffineFastState.Bounded env17366 := by
  intro p hp
  have h : env17366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17365_17366 : H12AffineEnvironment.transform 13 1 env17365 = env17366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env17365 == env17366) = true)

theorem identity17366 : scanCanonicalize (H12AffineFastState.compose env17366 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound17366 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env17367 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,16,41,1,0,34,16,1125,1025,1,1076,1045,17,2,40,65,81,16,16,1125,1057,1044,117,32,81,513]

theorem envBound17367 : H12AffineFastState.Bounded env17367 := by
  intro p hp
  have h : env17367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17366_17367 : H12AffineEnvironment.transform 11 16 env17366 = env17367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17366 == env17367) = true)

theorem identity17367 : scanCanonicalize (H12AffineFastState.compose env17367 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound17367 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17368 : List Nat := [2,4,8,16,32,64,9,116,80,1024,1124,16,41,1,0,34,16,1125,1025,1,1076,1045,17,2,40,65,81,16,16,1125,1057,1044,117,32,81,81]

theorem envBound17368 : H12AffineFastState.Bounded env17368 := by
  intro p hp
  have h : env17368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17367_17368 : H12AffineEnvironment.transform 8 80 env17367 = env17368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env17367 == env17368) = true)

theorem identity17368 : scanCanonicalize (H12AffineFastState.compose env17368 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound17368 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17369 : List Nat := [2,4,8,16,32,64,9,116,80,100,0,16,41,1,0,34,16,1,101,1,80,113,17,2,40,65,81,16,16,1,69,112,117,32,81,81]

theorem envBound17369 : H12AffineFastState.Bounded env17369 := by
  intro p hp
  have h : env17369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17368_17369 : H12AffineEnvironment.transform 9 100 env17368 = env17369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env17368 == env17369) = true)

theorem identity17369 : scanCanonicalize (H12AffineFastState.compose env17369 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17369 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17370 : List Nat := [2,4,8,16,16,64,9,68,80,84,0,16,25,1,0,18,16,1,85,1,80,65,17,2,24,65,81,16,16,1,69,64,69,16,81,81]

theorem envBound17370 : H12AffineFastState.Bounded env17370 := by
  intro p hp
  have h : env17370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17369_17370 : H12AffineEnvironment.transform 4 16 env17369 = env17370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17369 == env17370) = true)

theorem identity17370 : scanCanonicalize (H12AffineFastState.compose env17370 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17370 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17371 : List Nat := [2,4,8,16,16,16,9,20,0,4,0,16,25,1,0,18,16,1,5,1,0,17,17,2,24,17,1,16,16,1,21,16,21,16,1,1]

theorem envBound17371 : H12AffineFastState.Bounded env17371 := by
  intro p hp
  have h : env17371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17370_17371 : H12AffineEnvironment.transform 5 16 env17370 = env17371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17370 == env17371) = true)

theorem identity17371 : scanCanonicalize (H12AffineFastState.compose env17371 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17372 : List Nat := [2,4,8,1,1,1,9,5,0,4,0,1,8,1,0,3,1,1,5,1,0,0,0,2,9,0,1,1,1,1,4,1,4,1,1,1]

theorem envBound17372 : H12AffineFastState.Bounded env17372 := by
  intro p hp
  have h : env17372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17371_17372 : H12AffineEnvironment.transform 3 1 env17371 = env17372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17371 == env17372) = true)

def env17373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,16384,8540,65536,82247,9292,1025,8541,91467,4194304,17,3,8193,65,4195396,16400,77834,66630,75102,4194305,257,33,16464,513]

theorem envBound17373 : H12AffineFastState.Bounded env17373 := by
  intro p hp
  have h : env17373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17360_17373 : H12AffineEnvironment.transform 10 1125 env17360 = env17373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env17360 == env17373) = true)

def env17374 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8460,65536,82199,9244,1025,8461,91419,4194304,17,3,8193,17,4195348,16400,77834,66582,75022,4194305,257,33,16384,513]

theorem envBound17374 : H12AffineFastState.Bounded env17374 := by
  intro p hp
  have h : env17374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17373_17374 : H12AffineEnvironment.transform 5 16 env17373 = env17374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17373 == env17374) = true)

theorem identity17374 : scanCanonicalize (H12AffineFastState.compose env17374 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17374 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17375 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,0,65536,82199,1296,1025,1,82967,4194304,17,3,269,17,4195348,16400,69894,66582,66562,4194305,257,33,16384,513]

theorem envBound17375 : H12AffineFastState.Bounded env17375 := by
  intro p hp
  have h : env17375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17374_17375 : H12AffineEnvironment.transform 12 268 env17374 = env17375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17374 == env17375) = true)

theorem identity17375 : scanCanonicalize (H12AffineFastState.compose env17375 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17375 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env17376 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,0,65536,82199,1296,1025,1,82967,32,17,3,269,17,1076,16400,69894,66582,66562,33,257,33,16384,513]

theorem envBound17376 : H12AffineFastState.Bounded env17376 := by
  intro p hp
  have h : env17376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17375_17376 : H12AffineEnvironment.transform 21 32 env17375 = env17376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17375 == env17376) = true)

theorem identity17376 : scanCanonicalize (H12AffineFastState.compose env17376 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17376 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17377 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,0,263,16400,1296,1025,1,17680,32,17,3,269,17,1076,16400,4097,1297,1285,33,257,33,16384,513]

theorem envBound17377 : H12AffineFastState.Bounded env17377 := by
  intro p hp
  have h : env17377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17376_17377 : H12AffineEnvironment.transform 15 263 env17376 = env17377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17376 == env17377) = true)

theorem identity17377 : scanCanonicalize (H12AffineFastState.compose env17377 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17378 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,1297,0,263,1281,1296,1025,1,1,32,17,3,269,17,1076,1281,4097,1297,1285,33,257,33,1297,513]

theorem envBound17378 : H12AffineFastState.Bounded env17378 := by
  intro p hp
  have h : env17378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17377_17378 : H12AffineEnvironment.transform 13 1297 env17377 = env17378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env17377 == env17378) = true)

theorem identity17378 : scanCanonicalize (H12AffineFastState.compose env17378 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound17378 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17379 : List Nat := [2,4,8,16,32,16,9,256,512,795,814,4096,268,522,0,263,538,523,794,1,1,32,17,3,269,17,815,538,4097,522,542,33,257,33,522,513]

theorem envBound17379 : H12AffineFastState.Bounded env17379 := by
  intro p hp
  have h : env17379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17378_17379 : H12AffineEnvironment.transform 9 795 env17378 = env17379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env17378 == env17379) = true)

theorem identity17379 : scanCanonicalize (H12AffineFastState.compose env17379 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17379 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17380 : List Nat := [2,4,8,16,32,16,9,4,512,543,554,4096,8,522,0,3,538,523,542,1,1,32,17,3,9,17,555,538,4097,522,542,33,5,33,522,513]

theorem envBound17380 : H12AffineFastState.Bounded env17380 := by
  intro p hp
  have h : env17380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17379_17380 : H12AffineEnvironment.transform 7 4 env17379 = env17380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17379 == env17380) = true)

theorem identity17380 : scanCanonicalize (H12AffineFastState.compose env17380 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound17380 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17381 : List Nat := [2,4,8,16,32,16,9,4,512,543,554,16,8,522,0,3,538,523,542,1,1,32,17,3,9,17,555,538,17,522,542,33,5,33,522,513]

theorem envBound17381 : H12AffineFastState.Bounded env17381 := by
  intro p hp
  have h : env17381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17380_17381 : H12AffineEnvironment.transform 11 16 env17380 = env17381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17380 == env17381) = true)

theorem identity17381 : scanCanonicalize (H12AffineFastState.compose env17381 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound17381 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17382 : List Nat := [2,4,8,16,32,16,9,4,10,21,32,16,8,0,0,3,16,1,20,1,1,32,17,3,9,17,33,16,17,0,20,33,5,33,0,11]

theorem envBound17382 : H12AffineFastState.Bounded env17382 := by
  intro p hp
  have h : env17382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17381_17382 : H12AffineEnvironment.transform 8 10 env17381 = env17382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env17381 == env17382) = true)

theorem identity17382 : scanCanonicalize (H12AffineFastState.compose env17382 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

end H12CloudChart0