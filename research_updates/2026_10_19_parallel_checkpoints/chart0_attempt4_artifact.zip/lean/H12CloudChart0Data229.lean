import H12CloudChart0Data228

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env58058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,118882,87425,1024,32768,116002,46481,124202,83181,26057,111915,103453,16384,118835,93514,49389,45541,257,69730,118882,18240]

theorem envBound58058 : H12AffineFastState.Bounded env58058 := by
  intro p hp
  have h : env58058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58057_58058 : H12AffineEnvironment.transform 16 118882 env58057 = env58058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 118882 env58057 == env58058) = true)

def env58059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103714,69825,1024,32768,98402,46481,106602,65965,8329,111915,103453,1344,103795,75786,34221,45541,257,69730,103714,512]

theorem envBound58059 : H12AffineFastState.Bounded env58059 := by
  intro p hp
  have h : env58059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58058_58059 : H12AffineEnvironment.transform 13 1344 env58058 = env58059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58058 == env58059) = true)

theorem identity58059 : scanCanonicalize (H12AffineFastState.compose env58059 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58059 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98354,67025,1024,32768,98402,41089,106602,65965,8329,106555,98573,1344,98403,75786,34221,42229,257,66930,98354,512]

theorem envBound58060 : H12AffineFastState.Bounded env58060 := by
  intro p hp
  have h : env58060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58059_58060 : H12AffineEnvironment.transform 11 1296 env58059 = env58060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58059 == env58060) = true)

def env58061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103715,69824,1024,32768,98403,46481,106603,65964,8328,111915,103453,1345,103794,75787,34220,45541,257,69730,103715,513]

theorem envBound58061 : H12AffineFastState.Bounded env58061 := by
  intro p hp
  have h : env58061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58058_58061 : H12AffineEnvironment.transform 13 1345 env58058 = env58061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58058 == env58061) = true)

theorem identity58061 : scanCanonicalize (H12AffineFastState.compose env58061 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58061 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,445,33886,1024,32768,5373,46481,13557,38194,8328,8629,131,1345,492,48277,34220,45541,257,34044,445,513]

theorem envBound58062 : H12AffineFastState.Bounded env58062 := by
  intro p hp
  have h : env58062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58061_58062 : H12AffineEnvironment.transform 15 38046 env58061 = env58062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58061 == env58062) = true)

theorem identity58062 : scanCanonicalize (H12AffineFastState.compose env58062 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound58062 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,32768,38046,445,33886,1024,32768,5373,37940,5456,38194,301,16,131,1345,492,40240,34220,36928,257,34044,445,513]

theorem envBound58063 : H12AffineFastState.Bounded env58063 := by
  intro p hp
  have h : env58063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58062_58063 : H12AffineEnvironment.transform 12 421 env58062 = env58063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env58062 == env58063) = true)

theorem identity58063 : scanCanonicalize (H12AffineFastState.compose env58063 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58063 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1108,4298,445,10,1024,1108,5373,4192,5456,4454,301,16,131,1345,492,6500,504,5140,257,168,445,513]

theorem envBound58064 : H12AffineFastState.Bounded env58064 := by
  intro p hp
  have h : env58064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58063_58064 : H12AffineEnvironment.transform 14 1108 env58063 = env58064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58063 == env58064) = true)

theorem identity58064 : scanCanonicalize (H12AffineFastState.compose env58064 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1882) := by decide +kernel

theorem selectedBound58064 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,4096,421,1345,1108,4298,445,10,1024,1108,5373,4192,5456,4454,301,16,131,1345,492,5694,504,5140,257,168,445,513]

theorem envBound58065 : H12AffineFastState.Bounded env58065 := by
  intro p hp
  have h : env58065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58064_58065 : H12AffineEnvironment.transform 10 1882 env58064 = env58065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1882 env58064 == env58065) = true)

theorem identity58065 : scanCanonicalize (H12AffineFastState.compose env58065 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound58065 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58066 : List Nat := [2,4,8,16,32,64,128,256,512,172,1014,4096,421,493,248,4298,445,10,172,248,4177,4192,4604,4454,301,16,131,493,492,4754,504,4280,257,168,445,513]

theorem envBound58066 : H12AffineFastState.Bounded env58066 := by
  intro p hp
  have h : env58066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58065_58066 : H12AffineEnvironment.transform 9 172 env58065 = env58066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env58065 == env58066) = true)

theorem identity58066 : scanCanonicalize (H12AffineFastState.compose env58066 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound58066 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58067 : List Nat := [2,4,8,16,32,64,128,256,512,172,1014,17,421,493,248,219,445,10,172,248,64,113,493,375,301,16,131,493,492,643,504,169,257,168,445,513]

theorem envBound58067 : H12AffineFastState.Bounded env58067 := by
  intro p hp
  have h : env58067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58066_58067 : H12AffineEnvironment.transform 11 17 env58066 = env58067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env58066 == env58067) = true)

theorem identity58067 : scanCanonicalize (H12AffineFastState.compose env58067 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58067 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58068 : List Nat := [2,4,8,16,32,64,128,256,216,172,302,17,421,493,248,219,445,10,172,248,64,113,493,375,301,16,131,493,492,91,504,169,257,168,445,217]

theorem envBound58068 : H12AffineFastState.Bounded env58068 := by
  intro p hp
  have h : env58068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58067_58068 : H12AffineEnvironment.transform 8 216 env58067 = env58068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58067 == env58068) = true)

theorem identity58068 : scanCanonicalize (H12AffineFastState.compose env58068 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58068 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env58069 : List Nat := [2,4,8,16,32,64,128,172,216,172,130,17,9,65,248,219,17,10,172,248,64,113,65,219,129,16,131,65,64,91,84,169,173,168,17,217]

theorem envBound58069 : H12AffineFastState.Bounded env58069 := by
  intro p hp
  have h : env58069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58068_58069 : H12AffineEnvironment.transform 7 172 env58068 = env58069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58068 == env58069) = true)

theorem identity58069 : scanCanonicalize (H12AffineFastState.compose env58069 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound58069 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env58070 : List Nat := [2,4,8,16,26,64,128,150,216,150,130,17,9,65,194,219,17,10,150,194,64,75,65,219,129,16,131,65,64,91,84,147,151,146,17,217]

theorem envBound58070 : H12AffineFastState.Bounded env58070 := by
  intro p hp
  have h : env58070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58069_58070 : H12AffineEnvironment.transform 4 26 env58069 = env58070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env58069 == env58070) = true)

theorem identity58070 : scanCanonicalize (H12AffineFastState.compose env58070 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound58070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58071 : List Nat := [2,4,8,16,26,64,73,95,17,95,75,17,9,65,11,18,17,10,95,11,64,75,65,18,72,16,74,65,64,91,84,90,94,91,17,16]

theorem envBound58071 : H12AffineFastState.Bounded env58071 := by
  intro p hp
  have h : env58071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58070_58071 : H12AffineEnvironment.transform 6 73 env58070 = env58071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env58070 == env58071) = true)

theorem identity58071 : scanCanonicalize (H12AffineFastState.compose env58071 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound58071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58072 : List Nat := [2,4,8,3,9,64,73,76,2,76,75,2,9,65,11,1,2,10,76,11,64,75,65,1,72,3,74,65,64,72,71,73,77,72,2,3]

theorem envBound58072 : H12AffineFastState.Bounded env58072 := by
  intro p hp
  have h : env58072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58071_58072 : H12AffineEnvironment.transform 3 3 env58071 = env58072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env58071 == env58072) = true)

def env58073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144712,169103,26056,157001,311709,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58073 : H12AffineFastState.Bounded env58073 := by
  intro p hp
  have h : env58073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58043_58073 : H12AffineEnvironment.transform 20 136513 env58043 = env58073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58043 == env58073) = true)

def env58074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144712,169103,26056,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58074 : H12AffineFastState.Bounded env58074 := by
  intro p hp
  have h : env58074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58073_58074 : H12AffineEnvironment.transform 17 87424 env58073 = env58074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58073 == env58074) = true)

theorem identity58074 : scanCanonicalize (H12AffineFastState.compose env58074 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 116082) := by decide +kernel

theorem selectedBound58074 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,116082,87424,1024,32768,118835,46480,127034,86525,26056,106555,103453,16384,116003,93515,54781,42229,257,69731,116082,18241]

theorem envBound58075 : H12AffineFastState.Bounded env58075 := by
  intro p hp
  have h : env58075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58074_58075 : H12AffineEnvironment.transform 16 116082 env58074 = env58075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 116082 env58074 == env58075) = true)

def env58076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98354,69824,1024,32768,103795,46480,111994,70845,8328,106555,103453,1344,98403,75787,37053,42229,257,69731,98354,513]

theorem envBound58076 : H12AffineFastState.Bounded env58076 := by
  intro p hp
  have h : env58076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58075_58076 : H12AffineEnvironment.transform 13 1344 env58075 = env58076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58075 == env58076) = true)

theorem identity58076 : scanCanonicalize (H12AffineFastState.compose env58076 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58076 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,5293,33887,1024,32768,492,46480,8677,32802,8328,13476,130,1344,5372,48276,37053,42229,257,34044,5293,513]

theorem envBound58077 : H12AffineFastState.Bounded env58077 := by
  intro p hp
  have h : env58077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58076_58077 : H12AffineEnvironment.transform 15 38047 env58076 = env58077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58076 == env58077) = true)

theorem identity58077 : scanCanonicalize (H12AffineFastState.compose env58077 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound58077 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,32768,38047,5293,33887,1024,32768,492,33060,5457,32802,5180,16,130,1344,5372,34848,37053,36929,257,34044,5293,513]

theorem envBound58078 : H12AffineFastState.Bounded env58078 := by
  intro p hp
  have h : env58078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58077_58078 : H12AffineEnvironment.transform 12 5300 env58077 = env58078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env58077 == env58078) = true)

theorem identity58078 : scanCanonicalize (H12AffineFastState.compose env58078 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58078 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1108,4299,5293,11,1024,1108,492,1392,5457,1142,5180,16,130,1344,5372,3188,5353,5141,257,168,5293,513]

theorem envBound58079 : H12AffineFastState.Bounded env58079 := by
  intro p hp
  have h : env58079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58078_58079 : H12AffineEnvironment.transform 14 1108 env58078 = env58079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58078 == env58079) = true)

theorem identity58079 : scanCanonicalize (H12AffineFastState.compose env58079 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1882) := by decide +kernel

theorem selectedBound58079 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,4096,5300,1344,1108,4299,5293,11,1024,1108,492,1392,5457,1142,5180,16,130,1344,5372,814,5353,5141,257,168,5293,513]

theorem envBound58080 : H12AffineFastState.Bounded env58080 := by
  intro p hp
  have h : env58080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58079_58080 : H12AffineEnvironment.transform 10 1882 env58079 = env58080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1882 env58079 == env58080) = true)

theorem identity58080 : scanCanonicalize (H12AffineFastState.compose env58080 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound58080 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,1344,500,1344,1108,1419,493,11,1024,1108,492,1392,17,1142,380,16,130,1344,444,814,425,341,257,168,493,513]

theorem envBound58081 : H12AffineFastState.Bounded env58081 := by
  intro p hp
  have h : env58081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58080_58081 : H12AffineEnvironment.transform 11 1344 env58080 = env58081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env58080 == env58081) = true)

theorem identity58081 : scanCanonicalize (H12AffineFastState.compose env58081 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound58081 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env58082 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1703,1213,9,1213,1108,1142,16,11,1024,1108,17,1165,17,1142,129,16,130,1213,65,723,84,168,252,168,16,513]

theorem envBound58082 : H12AffineFastState.Bounded env58082 := by
  intro p hp
  have h : env58082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58081_58082 : H12AffineEnvironment.transform 7 253 env58081 = env58082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env58081 == env58082) = true)

theorem identity58082 : scanCanonicalize (H12AffineFastState.compose env58082 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58082 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58083 : List Nat := [2,4,8,16,32,64,128,253,512,548,131,665,9,665,624,594,16,11,548,624,17,681,17,594,129,16,130,665,65,723,84,168,252,168,16,513]

theorem envBound58083 : H12AffineFastState.Bounded env58083 := by
  intro p hp
  have h : env58083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58082_58083 : H12AffineEnvironment.transform 9 548 env58082 = env58083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58082 == env58083) = true)

theorem identity58083 : scanCanonicalize (H12AffineFastState.compose env58083 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58083 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58084 : List Nat := [2,4,8,16,32,32,128,157,512,548,131,665,9,665,528,562,16,11,548,528,17,681,17,562,129,16,130,665,33,691,52,168,156,168,16,513]

theorem envBound58084 : H12AffineFastState.Bounded env58084 := by
  intro p hp
  have h : env58084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58083_58084 : H12AffineEnvironment.transform 5 32 env58083 = env58084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58083 == env58084) = true)

theorem identity58084 : scanCanonicalize (H12AffineFastState.compose env58084 (packedSelected [3,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound58084 : packedSelected [3,8,11] rootPS < 2^1333 := by decide +kernel

def env58085 : List Nat := [2,4,8,16,32,32,57,36,512,548,58,544,9,544,528,562,16,11,548,528,17,528,17,562,56,16,59,544,33,522,52,17,37,17,16,513]

theorem envBound58085 : H12AffineFastState.Bounded env58085 := by
  intro p hp
  have h : env58085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58084_58085 : H12AffineEnvironment.transform 6 57 env58084 = env58085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58084 == env58085) = true)

theorem identity58085 : scanCanonicalize (H12AffineFastState.compose env58085 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound58085 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58086 : List Nat := [2,4,8,16,32,32,57,36,2,38,58,34,9,34,18,48,16,11,38,18,17,18,17,48,56,16,59,34,33,8,52,17,37,17,16,3]

theorem envBound58086 : H12AffineFastState.Bounded env58086 := by
  intro p hp
  have h : env58086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58085_58086 : H12AffineEnvironment.transform 8 2 env58085 = env58086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env58085 == env58086) = true)

theorem identity58086 : scanCanonicalize (H12AffineFastState.compose env58086 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58086 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env58087 : List Nat := [2,4,8,16,10,10,19,14,2,12,16,8,9,8,18,26,16,11,12,18,17,18,17,26,18,16,17,8,11,8,30,17,15,17,16,3]

theorem envBound58087 : H12AffineFastState.Bounded env58087 := by
  intro p hp
  have h : env58087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58086_58087 : H12AffineEnvironment.transform 4 10 env58086 = env58087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58086 == env58087) = true)

theorem identity58087 : scanCanonicalize (H12AffineFastState.compose env58087 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58087 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58088 : List Nat := [0,4,8,16,8,8,17,12,0,12,16,8,9,8,16,24,16,9,12,16,17,16,17,24,16,16,17,8,9,8,28,17,13,17,16,1]

theorem envBound58088 : H12AffineFastState.Bounded env58088 := by
  intro p hp
  have h : env58088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58087_58088 : H12AffineEnvironment.transform 0 0 env58087 = env58088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58087 == env58088) = true)

def env58089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98355,69825,1024,32768,103794,46480,111995,70844,8329,106555,103453,1345,98402,75786,37052,42229,257,69731,98355,512]

theorem envBound58089 : H12AffineFastState.Bounded env58089 := by
  intro p hp
  have h : env58089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58075_58089 : H12AffineEnvironment.transform 13 1345 env58075 = env58089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58075 == env58089) = true)

theorem identity58089 : scanCanonicalize (H12AffineFastState.compose env58089 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58089 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98355,67024,1024,32768,98403,41089,106602,65965,8329,106555,98572,1345,98402,75786,34221,42229,257,66930,98355,512]

theorem envBound58090 : H12AffineFastState.Bounded env58090 := by
  intro p hp
  have h : env58090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58089_58090 : H12AffineEnvironment.transform 11 1297 env58089 = env58090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58089 == env58090) = true)

def env58091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144712,169103,26056,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58091 : H12AffineFastState.Bounded env58091 := by
  intro p hp
  have h : env58091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58073_58091 : H12AffineEnvironment.transform 17 87425 env58073 = env58091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58073 == env58091) = true)

theorem identity58091 : scanCanonicalize (H12AffineFastState.compose env58091 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 98354) := by decide +kernel

theorem selectedBound58091 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,98354,87425,1024,32768,103795,46480,111994,70845,26056,124283,103452,16384,98403,93515,37053,57781,257,69731,98354,18241]

theorem envBound58092 : H12AffineFastState.Bounded env58092 := by
  intro p hp
  have h : env58092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58091_58092 : H12AffineEnvironment.transform 16 98354 env58091 = env58092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 98354 env58091 == env58092) = true)

def env58093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98354,69825,1024,32768,103795,46480,111994,70845,8328,106555,103452,1344,98403,75787,37053,42229,257,69731,98354,513]

theorem envBound58093 : H12AffineFastState.Bounded env58093 := by
  intro p hp
  have h : env58093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58092_58093 : H12AffineEnvironment.transform 13 1344 env58092 = env58093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58092 == env58093) = true)

theorem identity58093 : scanCanonicalize (H12AffineFastState.compose env58093 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58093 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,5293,33886,1024,32768,492,46480,8677,32802,8328,13476,131,1344,5372,48276,37053,42229,257,34044,5293,513]

theorem envBound58094 : H12AffineFastState.Bounded env58094 := by
  intro p hp
  have h : env58094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58093_58094 : H12AffineEnvironment.transform 15 38047 env58093 = env58094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58093 == env58094) = true)

theorem identity58094 : scanCanonicalize (H12AffineFastState.compose env58094 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound58094 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,32768,38047,5293,33886,1024,32768,492,33060,5457,32802,5180,16,131,1344,5372,34848,37053,36929,257,34044,5293,513]

theorem envBound58095 : H12AffineFastState.Bounded env58095 := by
  intro p hp
  have h : env58095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58094_58095 : H12AffineEnvironment.transform 12 5300 env58094 = env58095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env58094 == env58095) = true)

theorem identity58095 : scanCanonicalize (H12AffineFastState.compose env58095 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58095 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1108,4299,5293,10,1024,1108,492,1392,5457,1142,5180,16,131,1344,5372,3188,5353,5141,257,168,5293,513]

theorem envBound58096 : H12AffineFastState.Bounded env58096 := by
  intro p hp
  have h : env58096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58095_58096 : H12AffineEnvironment.transform 14 1108 env58095 = env58096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58095 == env58096) = true)

theorem identity58096 : scanCanonicalize (H12AffineFastState.compose env58096 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1882) := by decide +kernel

theorem selectedBound58096 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,4096,5300,1344,1108,4299,5293,10,1024,1108,492,1392,5457,1142,5180,16,131,1344,5372,814,5353,5141,257,168,5293,513]

theorem envBound58097 : H12AffineFastState.Bounded env58097 := by
  intro p hp
  have h : env58097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58096_58097 : H12AffineEnvironment.transform 10 1882 env58096 = env58097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1882 env58096 == env58097) = true)

theorem identity58097 : scanCanonicalize (H12AffineFastState.compose env58097 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58097 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1803,4096,5300,1297,1029,4250,5293,10,1024,1029,445,1313,5376,1063,5180,16,131,1297,5293,814,5304,5141,257,168,5293,513]

theorem envBound58098 : H12AffineFastState.Bounded env58098 := by
  intro p hp
  have h : env58098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58097_58098 : H12AffineEnvironment.transform 5 17 env58097 = env58098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58097 == env58098) = true)

theorem identity58098 : scanCanonicalize (H12AffineFastState.compose env58098 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58098 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env58099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1803,1213,9,1297,1029,1063,16,10,1024,1029,445,1313,445,1063,129,16,131,1297,16,814,5,168,257,168,16,513]

theorem envBound58099 : H12AffineFastState.Bounded env58099 := by
  intro p hp
  have h : env58099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58098_58099 : H12AffineEnvironment.transform 11 1213 env58098 = env58099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env58098 == env58099) = true)

theorem identity58099 : scanCanonicalize (H12AffineFastState.compose env58099 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58099 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58100 : List Nat := [2,4,8,16,32,17,128,256,512,548,303,665,9,821,545,515,16,10,548,545,445,773,445,515,129,16,131,821,16,814,5,168,257,168,16,513]

theorem envBound58100 : H12AffineFastState.Bounded env58100 := by
  intro p hp
  have h : env58100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58099_58100 : H12AffineEnvironment.transform 9 548 env58099 = env58100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58099 == env58100) = true)

theorem identity58100 : scanCanonicalize (H12AffineFastState.compose env58100 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58100 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58101 : List Nat := [2,4,8,16,32,17,128,172,512,548,131,665,9,665,545,515,16,10,548,545,17,681,17,515,129,16,131,665,16,642,5,168,173,168,16,513]

theorem envBound58101 : H12AffineFastState.Bounded env58101 := by
  intro p hp
  have h : env58101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58100_58101 : H12AffineEnvironment.transform 7 172 env58100 = env58101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58100 == env58101) = true)

theorem identity58101 : scanCanonicalize (H12AffineFastState.compose env58101 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound58101 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env58102 : List Nat := [2,4,8,16,32,17,128,172,162,134,131,59,9,59,131,161,16,10,134,131,17,11,17,161,129,16,131,59,16,32,5,168,173,168,16,163]

theorem envBound58102 : H12AffineFastState.Bounded env58102 := by
  intro p hp
  have h : env58102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58101_58102 : H12AffineEnvironment.transform 8 162 env58101 = env58102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env58101 == env58102) = true)

theorem identity58102 : scanCanonicalize (H12AffineFastState.compose env58102 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound58102 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58103 : List Nat := [2,4,8,3,32,2,128,172,162,134,131,40,9,40,131,161,3,10,134,131,2,11,2,161,129,3,131,40,3,32,5,168,173,168,3,163]

theorem envBound58103 : H12AffineFastState.Bounded env58103 := by
  intro p hp
  have h : env58103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58102_58103 : H12AffineEnvironment.transform 3 3 env58102 = env58103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env58102 == env58103) = true)

theorem identity58103 : scanCanonicalize (H12AffineFastState.compose env58103 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound58103 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58104 : List Nat := [2,4,8,3,32,2,40,4,10,46,43,40,9,40,43,9,3,10,46,43,2,11,2,9,41,3,43,40,3,32,5,0,5,0,3,11]

theorem envBound58104 : H12AffineFastState.Bounded env58104 := by
  intro p hp
  have h : env58104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58103_58104 : H12AffineEnvironment.transform 6 40 env58103 = env58104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env58103 == env58104) = true)

def env58105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98354,69824,1024,32768,103795,46480,111994,70845,8329,106554,103452,1345,98403,75786,37053,42228,257,69731,98354,512]

theorem envBound58105 : H12AffineFastState.Bounded env58105 := by
  intro p hp
  have h : env58105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58092_58105 : H12AffineEnvironment.transform 13 1345 env58092 = env58105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58092 == env58105) = true)

theorem identity58105 : scanCanonicalize (H12AffineFastState.compose env58105 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58105 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98354,67025,1024,32768,98402,41089,106603,65964,8329,106554,98573,1345,98403,75786,34220,42228,257,66930,98354,512]

theorem envBound58106 : H12AffineFastState.Bounded env58106 := by
  intro p hp
  have h : env58106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58105_58106 : H12AffineEnvironment.transform 11 1297 env58105 = env58106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58105 == env58106) = true)

def env58107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,4247641,6342040,2544860,16384,131153,4315355,6402142,221575,257,2295074,131072,4256464]

theorem envBound58107 : H12AffineFastState.Bounded env58107 := by
  intro p hp
  have h : env58107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57978_58107 : H12AffineEnvironment.transform 24 4247641 env57978 = env58107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env57978 == env58107) = true)

def env58108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144713,169102,2257033,157000,2544860,16384,131153,2324491,200846,221575,257,2295074,131072,2249216]

theorem envBound58108 : H12AffineFastState.Bounded env58108 := by
  intro p hp
  have h : env58108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58107_58108 : H12AffineEnvironment.transform 21 2269392 env58107 = env58108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env58107 == env58108) = true)

def env58109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144713,169102,26057,157000,311708,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58109 : H12AffineFastState.Bounded env58109 := by
  intro p hp
  have h : env58109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58108_58109 : H12AffineEnvironment.transform 20 136512 env58108 = env58109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58108 == env58109) = true)

def env58110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144713,169102,26057,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58110 : H12AffineFastState.Bounded env58110 := by
  intro p hp
  have h : env58110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58109_58110 : H12AffineEnvironment.transform 17 87424 env58109 = env58110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58109 == env58110) = true)

theorem identity58110 : scanCanonicalize (H12AffineFastState.compose env58110 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 87095) := by decide +kernel

theorem selectedBound58110 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,87095,87424,1024,32768,82295,46480,90494,114873,26057,78207,103452,16384,87142,93515,17593,13744,257,69730,87095,18240]

theorem envBound58111 : H12AffineFastState.Bounded env58111 := by
  intro p hp
  have h : env58111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58110_58111 : H12AffineEnvironment.transform 16 87095 env58110 = env58111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 87095 env58110 == env58111) = true)

def env58112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70007,69824,1024,32768,66615,46480,74814,99833,8329,78207,103452,1344,69926,75787,505,13744,257,69730,70007,512]

theorem envBound58112 : H12AffineFastState.Bounded env58112 := by
  intro p hp
  have h : env58112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58111_58112 : H12AffineEnvironment.transform 13 1344 env58111 = env58112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58111 == env58112) = true)

theorem identity58112 : scanCanonicalize (H12AffineFastState.compose env58112 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58112 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66663,67024,1024,32768,66615,41088,74814,99833,8329,74863,98572,1344,66614,75787,505,8352,257,66930,66663,512]

theorem envBound58113 : H12AffineFastState.Bounded env58113 := by
  intro p hp
  have h : env58113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58112_58113 : H12AffineEnvironment.transform 11 1296 env58112 = env58113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58112 == env58113) = true)

def env58114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70006,69825,1024,32768,66614,46480,74815,99832,8328,78207,103452,1345,69927,75786,504,13744,257,69730,70006,513]

theorem envBound58114 : H12AffineFastState.Bounded env58114 := by
  intro p hp
  have h : env58114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58111_58114 : H12AffineEnvironment.transform 13 1345 env58111 = env58114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58111 == env58114) = true)

theorem identity58114 : scanCanonicalize (H12AffineFastState.compose env58114 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58114 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,34281,33886,1024,32768,37033,46480,45216,4455,8328,42464,131,1345,34232,48277,504,13744,257,34045,34281,513]

theorem envBound58115 : H12AffineFastState.Bounded env58115 := by
  intro p hp
  have h : env58115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58114_58115 : H12AffineEnvironment.transform 15 38047 env58114 = env58115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58114 == env58115) = true)

theorem identity58115 : scanCanonicalize (H12AffineFastState.compose env58115 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound58115 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,8216,8623,1024,9713,13656,4193,5457,4455,8328,17,131,1345,8265,6500,504,13744,257,8460,8216,513]

theorem envBound58116 : H12AffineFastState.Bounded env58116 := by
  intro p hp
  have h : env58116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58115_58116 : H12AffineEnvironment.transform 14 9713 env58115 = env58116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env58115 == env58116) = true)

theorem identity58116 : scanCanonicalize (H12AffineFastState.compose env58116 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58116 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1109,4298,444,11,1024,1109,5372,4193,5457,4455,300,17,131,1345,493,6500,504,5140,257,168,444,513]

theorem envBound58117 : H12AffineFastState.Bounded env58117 := by
  intro p hp
  have h : env58117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58116_58117 : H12AffineEnvironment.transform 12 420 env58116 = env58117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58116 == env58117) = true)

theorem identity58117 : scanCanonicalize (H12AffineFastState.compose env58117 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound58117 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,420,1345,1109,3708,444,11,1024,1109,2634,3799,3047,4049,300,17,131,1345,493,2002,504,2722,257,168,444,513]

theorem envBound58118 : H12AffineFastState.Bounded env58118 := by
  intro p hp
  have h : env58118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58117_58118 : H12AffineEnvironment.transform 11 3766 env58117 = env58118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env58117 == env58118) = true)

theorem identity58118 : scanCanonicalize (H12AffineFastState.compose env58118 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58118 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58119 : List Nat := [2,4,8,16,32,64,128,256,512,548,2048,2194,420,869,625,2136,444,11,548,625,2634,2291,3047,2549,300,17,131,869,493,502,504,2722,257,168,444,513]

theorem envBound58119 : H12AffineFastState.Bounded env58119 := by
  intro p hp
  have h : env58119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58118_58119 : H12AffineEnvironment.transform 9 548 env58118 = env58119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58118 == env58119) = true)

theorem identity58119 : scanCanonicalize (H12AffineFastState.compose env58119 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound58119 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env58120 : List Nat := [2,4,8,16,32,64,128,256,292,256,2048,2194,420,65,341,2136,444,11,256,341,2414,2291,2243,2549,300,17,131,65,493,502,504,2438,257,168,444,293]

theorem envBound58120 : H12AffineFastState.Bounded env58120 := by
  intro p hp
  have h : env58120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58119_58120 : H12AffineEnvironment.transform 8 292 env58119 = env58120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env58119 == env58120) = true)

theorem identity58120 : scanCanonicalize (H12AffineFastState.compose env58120 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58120 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58121 : List Nat := [2,4,8,16,32,17,128,256,292,256,2048,2194,420,16,260,2057,444,11,256,260,2367,2210,2194,2468,300,17,131,16,444,423,425,2438,257,168,444,293]

theorem envBound58121 : H12AffineFastState.Bounded env58121 := by
  intro p hp
  have h : env58121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58120_58121 : H12AffineEnvironment.transform 5 17 env58120 = env58121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58120 == env58121) = true)

theorem identity58121 : scanCanonicalize (H12AffineFastState.compose env58121 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound58121 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58122 : List Nat := [2,4,8,16,32,17,128,256,292,256,131,17,420,16,260,138,444,11,256,260,444,33,17,295,300,17,131,16,444,423,425,261,257,168,444,293]

theorem envBound58122 : H12AffineFastState.Bounded env58122 := by
  intro p hp
  have h : env58122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58121_58122 : H12AffineEnvironment.transform 10 131 env58121 = env58122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env58121 == env58122) = true)

theorem identity58122 : scanCanonicalize (H12AffineFastState.compose env58122 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58122 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58123 : List Nat := [2,4,8,1,32,0,128,256,292,256,131,0,420,1,260,138,429,11,256,260,429,33,0,295,300,0,131,1,429,423,425,261,257,168,429,293]

theorem envBound58123 : H12AffineFastState.Bounded env58123 := by
  intro p hp
  have h : env58123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58122_58123 : H12AffineEnvironment.transform 3 1 env58122 = env58123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58122 == env58123) = true)

theorem identity58123 : scanCanonicalize (H12AffineFastState.compose env58123 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58123 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58124 : List Nat := [2,4,8,1,32,0,9,256,292,256,10,0,301,1,260,3,292,11,256,260,292,33,0,295,300,0,10,1,292,302,288,261,257,33,292,293]

theorem envBound58124 : H12AffineFastState.Bounded env58124 := by
  intro p hp
  have h : env58124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58123_58124 : H12AffineEnvironment.transform 6 9 env58123 = env58124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58123 == env58124) = true)

theorem identity58124 : scanCanonicalize (H12AffineFastState.compose env58124 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58124 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58125 : List Nat := [2,4,8,1,3,0,9,256,263,256,10,0,270,1,260,3,263,11,256,260,263,2,0,260,271,0,10,1,263,269,259,261,257,2,263,262]

theorem envBound58125 : H12AffineFastState.Bounded env58125 := by
  intro p hp
  have h : env58125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58124_58125 : H12AffineEnvironment.transform 4 3 env58124 = env58125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58124 == env58125) = true)

theorem identity58125 : scanCanonicalize (H12AffineFastState.compose env58125 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58125 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58126 : List Nat := [2,4,8,1,3,0,9,15,8,15,10,0,1,1,11,3,8,11,15,11,8,2,0,11,0,0,10,1,8,2,12,10,14,2,8,9]

theorem envBound58126 : H12AffineFastState.Bounded env58126 := by
  intro p hp
  have h : env58126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58125_58126 : H12AffineEnvironment.transform 7 15 env58125 = env58126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58125 == env58126) = true)

theorem identity58126 : scanCanonicalize (H12AffineFastState.compose env58126 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58127 : List Nat := [2,4,1,1,3,0,0,6,1,6,3,0,1,1,2,3,1,2,6,2,1,2,0,2,0,0,3,1,1,2,5,3,7,2,1,0]

theorem envBound58127 : H12AffineFastState.Bounded env58127 := by
  intro p hp
  have h : env58127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58126_58127 : H12AffineEnvironment.transform 2 1 env58126 = env58127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58126 == env58127) = true)

theorem identity58127 : scanCanonicalize (H12AffineFastState.compose env58127 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58128 : List Nat := [1,4,1,1,0,0,0,5,1,5,0,0,1,1,1,0,1,1,5,1,1,1,0,1,0,0,0,1,1,1,5,0,4,1,1,0]

theorem envBound58128 : H12AffineFastState.Bounded env58128 := by
  intro p hp
  have h : env58128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58127_58128 : H12AffineEnvironment.transform 0 1 env58127 = env58128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58127 == env58128) = true)

def env58129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144713,169102,26057,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58129 : H12AffineFastState.Bounded env58129 := by
  intro p hp
  have h : env58129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58109_58129 : H12AffineEnvironment.transform 17 87425 env58109 = env58129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58109 == env58129) = true)

theorem identity58129 : scanCanonicalize (H12AffineFastState.compose env58129 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 70006) := by decide +kernel

theorem selectedBound58129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70006,87425,1024,32768,66614,46480,74815,99832,26057,95294,103453,16384,69927,93515,504,28913,257,69730,70006,18240]

theorem envBound58130 : H12AffineFastState.Bounded env58130 := by
  intro p hp
  have h : env58130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58129_58130 : H12AffineEnvironment.transform 16 70006 env58129 = env58130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70006 env58129 == env58130) = true)

def env58131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70006,69825,1024,32768,66614,46480,74815,99832,8329,78206,103453,1344,69927,75787,504,13745,257,69730,70006,512]

theorem envBound58131 : H12AffineFastState.Bounded env58131 := by
  intro p hp
  have h : env58131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58130_58131 : H12AffineEnvironment.transform 13 1344 env58130 = env58131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58130 == env58131) = true)

theorem identity58131 : scanCanonicalize (H12AffineFastState.compose env58131 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58131 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66662,67025,1024,32768,66614,41088,74815,99832,8329,74862,98573,1344,66615,75787,504,8353,257,66930,66662,512]

theorem envBound58132 : H12AffineFastState.Bounded env58132 := by
  intro p hp
  have h : env58132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58131_58132 : H12AffineEnvironment.transform 11 1296 env58131 = env58132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58131 == env58132) = true)

def env58133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70006,69824,1024,32768,66614,46480,74815,99832,8328,78207,103453,1345,69927,75786,504,13744,257,69730,70006,513]

theorem envBound58133 : H12AffineFastState.Bounded env58133 := by
  intro p hp
  have h : env58133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58130_58133 : H12AffineEnvironment.transform 13 1345 env58130 = env58133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58130 == env58133) = true)

theorem identity58133 : scanCanonicalize (H12AffineFastState.compose env58133 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58133 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,34281,33887,1024,32768,37033,46480,45216,4455,8328,42464,130,1345,34232,48277,504,13744,257,34045,34281,513]

theorem envBound58134 : H12AffineFastState.Bounded env58134 := by
  intro p hp
  have h : env58134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58133_58134 : H12AffineEnvironment.transform 15 38047 env58133 = env58134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58133 == env58134) = true)

theorem identity58134 : scanCanonicalize (H12AffineFastState.compose env58134 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound58134 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,8216,8622,1024,9713,13656,4193,5457,4455,8328,17,130,1345,8265,6500,504,13744,257,8460,8216,513]

theorem envBound58135 : H12AffineFastState.Bounded env58135 := by
  intro p hp
  have h : env58135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58134_58135 : H12AffineEnvironment.transform 14 9713 env58134 = env58135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env58134 == env58135) = true)

theorem identity58135 : scanCanonicalize (H12AffineFastState.compose env58135 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58135 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1109,4298,444,10,1024,1109,5372,4193,5457,4455,300,17,130,1345,493,6500,504,5140,257,168,444,513]

theorem envBound58136 : H12AffineFastState.Bounded env58136 := by
  intro p hp
  have h : env58136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58135_58136 : H12AffineEnvironment.transform 12 420 env58135 = env58136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58135 == env58136) = true)

theorem identity58136 : scanCanonicalize (H12AffineFastState.compose env58136 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound58136 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,420,1345,1109,3708,444,10,1024,1109,2634,3799,3047,4049,300,17,130,1345,493,2002,504,2722,257,168,444,513]

theorem envBound58137 : H12AffineFastState.Bounded env58137 := by
  intro p hp
  have h : env58137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58136_58137 : H12AffineEnvironment.transform 11 3766 env58136 = env58137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env58136 == env58137) = true)

theorem identity58137 : scanCanonicalize (H12AffineFastState.compose env58137 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1411) := by decide +kernel

theorem selectedBound58137 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1411,821,420,1345,1109,1023,444,10,1024,1109,1993,852,1636,594,300,17,130,1345,493,2002,504,1825,257,168,444,513]

theorem envBound58138 : H12AffineFastState.Bounded env58138 := by
  intro p hp
  have h : env58138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58137_58138 : H12AffineEnvironment.transform 10 1411 env58137 = env58138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1411 env58137 == env58138) = true)

theorem identity58138 : scanCanonicalize (H12AffineFastState.compose env58138 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58138 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env58139 : List Nat := [2,4,8,16,32,64,128,256,293,1024,1411,16,420,1345,1109,218,444,10,1024,1109,1260,113,1345,375,300,17,130,1345,493,1271,504,1028,257,168,444,292]

theorem envBound58139 : H12AffineFastState.Bounded env58139 := by
  intro p hp
  have h : env58139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58138_58139 : H12AffineEnvironment.transform 8 293 env58138 = env58139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58138 == env58139) = true)

theorem identity58139 : scanCanonicalize (H12AffineFastState.compose env58139 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound58139 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58140 : List Nat := [2,4,8,16,32,64,128,256,293,337,210,16,420,16,260,218,444,10,337,260,445,113,16,375,300,17,130,16,493,422,504,341,257,168,444,292]

theorem envBound58140 : H12AffineFastState.Bounded env58140 := by
  intro p hp
  have h : env58140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58139_58140 : H12AffineEnvironment.transform 9 337 env58139 = env58140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env58139 == env58140) = true)

theorem identity58140 : scanCanonicalize (H12AffineFastState.compose env58140 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound58140 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env58141 : List Nat := [2,4,8,16,32,64,3,256,293,337,81,16,295,16,260,89,319,10,337,260,318,113,16,375,300,17,1,16,366,293,379,341,257,43,319,292]

theorem envBound58141 : H12AffineFastState.Bounded env58141 := by
  intro p hp
  have h : env58141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58140_58141 : H12AffineEnvironment.transform 6 3 env58140 = env58141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env58140 == env58141) = true)

def env58142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144713,169102,26056,157000,311709,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58142 : H12AffineFastState.Bounded env58142 := by
  intro p hp
  have h : env58142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58108_58142 : H12AffineEnvironment.transform 20 136513 env58108 = env58142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58108 == env58142) = true)

def env58143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144713,169102,26056,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58143 : H12AffineFastState.Bounded env58143 := by
  intro p hp
  have h : env58143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58142_58143 : H12AffineEnvironment.transform 17 87424 env58142 = env58143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58142 == env58143) = true)

theorem identity58143 : scanCanonicalize (H12AffineFastState.compose env58143 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 66663) := by decide +kernel

theorem selectedBound58143 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,66663,87424,1024,32768,69926,46481,78126,102633,26056,90415,103453,16384,66614,93514,5353,26080,257,69731,66663,18241]

theorem envBound58144 : H12AffineFastState.Bounded env58144 := by
  intro p hp
  have h : env58144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58143_58144 : H12AffineEnvironment.transform 16 66663 env58143 = env58144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 66663 env58143 == env58144) = true)

def env58145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66663,69824,1024,32768,69926,46481,78126,102633,8328,74863,103453,1344,66614,75786,5353,8352,257,69731,66663,513]

theorem envBound58145 : H12AffineFastState.Bounded env58145 := by
  intro p hp
  have h : env58145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58144_58145 : H12AffineEnvironment.transform 13 1344 env58144 = env58145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58144 == env58145) = true)

theorem identity58145 : scanCanonicalize (H12AffineFastState.compose env58145 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58145 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,37113,33886,1024,32768,34232,46481,42416,1143,8328,45297,131,1344,37032,48276,5353,8352,257,34045,37113,513]

theorem envBound58146 : H12AffineFastState.Bounded env58146 := by
  intro p hp
  have h : env58146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58145_58146 : H12AffineEnvironment.transform 15 38046 env58145 = env58146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58145 == env58146) = true)

theorem identity58146 : scanCanonicalize (H12AffineFastState.compose env58146 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound58146 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,8217,13502,1024,12512,13656,1393,5456,1143,8328,17,131,1344,8264,3188,5353,8352,257,13341,8217,513]

theorem envBound58147 : H12AffineFastState.Bounded env58147 := by
  intro p hp
  have h : env58147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58146_58147 : H12AffineEnvironment.transform 14 12512 env58146 = env58147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env58146 == env58147) = true)

theorem identity58147 : scanCanonicalize (H12AffineFastState.compose env58147 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound58147 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1109,4299,5292,11,1024,1109,493,1393,5456,1143,5181,17,131,1344,5373,3188,5353,5141,257,168,5292,513]

theorem envBound58148 : H12AffineFastState.Bounded env58148 := by
  intro p hp
  have h : env58148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58147_58148 : H12AffineEnvironment.transform 12 5301 env58147 = env58148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env58147 == env58148) = true)

theorem identity58148 : scanCanonicalize (H12AffineFastState.compose env58148 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound58148 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,5301,1344,1109,4299,5292,11,1024,1109,493,1393,5456,1143,5181,17,131,1344,5373,2002,5353,5141,257,168,5292,513]

theorem envBound58149 : H12AffineFastState.Bounded env58149 := by
  intro p hp
  have h : env58149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58148_58149 : H12AffineEnvironment.transform 10 934 env58148 = env58149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env58148 == env58149) = true)

theorem identity58149 : scanCanonicalize (H12AffineFastState.compose env58149 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1993) := by decide +kernel

theorem selectedBound58149 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,1993,892,1344,1109,1794,869,11,1024,1109,493,1393,665,1143,1012,17,131,1344,820,2002,800,988,257,168,869,513]

theorem envBound58150 : H12AffineFastState.Bounded env58150 := by
  intro p hp
  have h : env58150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58149_58150 : H12AffineEnvironment.transform 11 1993 env58149 = env58150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1993 env58149 == env58150) = true)

theorem identity58150 : scanCanonicalize (H12AffineFastState.compose env58150 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58150 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env58151 : List Nat := [2,4,8,16,32,64,128,256,293,1024,131,1260,89,1344,1109,1063,64,11,1024,1109,493,1393,444,1143,209,17,131,1344,17,1271,5,249,257,168,64,292]

theorem envBound58151 : H12AffineFastState.Bounded env58151 := by
  intro p hp
  have h : env58151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58150_58151 : H12AffineEnvironment.transform 8 293 env58150 = env58151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58150 == env58151) = true)

theorem identity58151 : scanCanonicalize (H12AffineFastState.compose env58151 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound58151 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58152 : List Nat := [2,4,8,16,32,64,128,256,293,172,131,64,89,492,249,139,64,11,172,249,493,477,444,219,209,17,131,492,17,91,5,249,257,168,64,292]

theorem envBound58152 : H12AffineFastState.Bounded env58152 := by
  intro p hp
  have h : env58152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58151_58152 : H12AffineEnvironment.transform 9 172 env58151 = env58152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env58151 == env58152) = true)

theorem identity58152 : scanCanonicalize (H12AffineFastState.compose env58152 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58152 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58153 : List Nat := [2,4,8,16,32,64,128,252,217,172,131,64,89,16,249,139,64,11,172,249,17,33,64,219,209,17,131,16,17,91,5,249,253,168,64,216]

theorem envBound58153 : H12AffineFastState.Bounded env58153 := by
  intro p hp
  have h : env58153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58152_58153 : H12AffineEnvironment.transform 7 252 env58152 = env58153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58152 == env58153) = true)

theorem identity58153 : scanCanonicalize (H12AffineFastState.compose env58153 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound58153 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58154 : List Nat := [2,4,8,16,32,64,25,101,64,53,26,64,89,16,96,18,64,11,53,96,17,33,64,66,72,17,26,16,17,91,5,96,100,49,64,65]

theorem envBound58154 : H12AffineFastState.Bounded env58154 := by
  intro p hp
  have h : env58154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58153_58154 : H12AffineEnvironment.transform 6 25 env58153 = env58154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env58153 == env58154) = true)

theorem identity58154 : scanCanonicalize (H12AffineFastState.compose env58154 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound58154 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58155 : List Nat := [2,4,8,16,32,43,25,14,43,53,26,43,50,16,11,18,43,11,53,11,17,33,43,41,35,17,26,16,17,48,5,11,15,49,43,42]

theorem envBound58155 : H12AffineFastState.Bounded env58155 := by
  intro p hp
  have h : env58155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58154_58155 : H12AffineEnvironment.transform 5 43 env58154 = env58155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env58154 == env58155) = true)

theorem identity58155 : scanCanonicalize (H12AffineFastState.compose env58155 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound58155 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58156 : List Nat := [2,4,8,16,18,25,25,14,25,7,26,25,0,16,11,18,25,11,7,11,17,19,25,27,17,17,26,16,17,2,5,11,15,3,25,24]

theorem envBound58156 : H12AffineFastState.Bounded env58156 := by
  intro p hp
  have h : env58156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58155_58156 : H12AffineEnvironment.transform 4 18 env58155 = env58156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env58155 == env58156) = true)

theorem identity58156 : scanCanonicalize (H12AffineFastState.compose env58156 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58156 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58157 : List Nat := [2,4,8,0,2,9,9,14,9,7,10,9,0,0,11,2,9,11,7,11,1,3,9,11,1,1,10,0,1,2,5,11,15,3,9,8]

theorem envBound58157 : H12AffineFastState.Bounded env58157 := by
  intro p hp
  have h : env58157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58156_58157 : H12AffineEnvironment.transform 3 0 env58156 = env58157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58156 == env58157) = true)

def env58158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66663,69825,1024,32768,69926,46481,78126,102633,8329,74862,103453,1345,66614,75787,5353,8353,257,69731,66663,512]

theorem envBound58158 : H12AffineFastState.Bounded env58158 := by
  intro p hp
  have h : env58158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58144_58158 : H12AffineEnvironment.transform 13 1345 env58144 = env58158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58144 == env58158) = true)

theorem identity58158 : scanCanonicalize (H12AffineFastState.compose env58158 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58158 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66663,67024,1024,32768,66615,41088,74815,99832,8329,74862,98572,1345,66614,75787,504,8353,257,66930,66663,512]

theorem envBound58159 : H12AffineFastState.Bounded env58159 := by
  intro p hp
  have h : env58159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58158_58159 : H12AffineEnvironment.transform 11 1297 env58158 = env58159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58158 == env58159) = true)

def env58160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144713,169102,26056,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58160 : H12AffineFastState.Bounded env58160 := by
  intro p hp
  have h : env58160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58142_58160 : H12AffineEnvironment.transform 17 87425 env58142 = env58160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58142 == env58160) = true)

theorem identity58160 : scanCanonicalize (H12AffineFastState.compose env58160 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 82215) := by decide +kernel

theorem selectedBound58160 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82215,87425,1024,32768,87142,46481,95342,120233,26056,74863,103452,16384,82294,93514,20905,8352,257,69731,82215,18241]

theorem envBound58161 : H12AffineFastState.Bounded env58161 := by
  intro p hp
  have h : env58161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58160_58161 : H12AffineEnvironment.transform 16 82215 env58160 = env58161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82215 env58160 == env58161) = true)

def env58162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66663,69825,1024,32768,69926,46481,78126,102633,8328,74863,103452,1344,66614,75786,5353,8352,257,69731,66663,513]

theorem envBound58162 : H12AffineFastState.Bounded env58162 := by
  intro p hp
  have h : env58162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58161_58162 : H12AffineEnvironment.transform 13 1344 env58161 = env58162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58161 == env58162) = true)

theorem identity58162 : scanCanonicalize (H12AffineFastState.compose env58162 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58162 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,37113,33887,1024,32768,34232,46481,42416,1143,8328,45297,130,1344,37032,48276,5353,8352,257,34045,37113,513]

theorem envBound58163 : H12AffineFastState.Bounded env58163 := by
  intro p hp
  have h : env58163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58162_58163 : H12AffineEnvironment.transform 15 38046 env58162 = env58163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58162 == env58163) = true)

theorem identity58163 : scanCanonicalize (H12AffineFastState.compose env58163 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound58163 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,8217,13503,1024,12512,13656,1393,5456,1143,8328,17,130,1344,8264,3188,5353,8352,257,13341,8217,513]

theorem envBound58164 : H12AffineFastState.Bounded env58164 := by
  intro p hp
  have h : env58164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58163_58164 : H12AffineEnvironment.transform 14 12512 env58163 = env58164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env58163 == env58164) = true)

theorem identity58164 : scanCanonicalize (H12AffineFastState.compose env58164 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound58164 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1109,4299,5292,10,1024,1109,493,1393,5456,1143,5181,17,130,1344,5373,3188,5353,5141,257,168,5292,513]

theorem envBound58165 : H12AffineFastState.Bounded env58165 := by
  intro p hp
  have h : env58165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58164_58165 : H12AffineEnvironment.transform 12 5301 env58164 = env58165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env58164 == env58165) = true)

theorem identity58165 : scanCanonicalize (H12AffineFastState.compose env58165 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound58165 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,5301,1344,1109,4299,5292,10,1024,1109,493,1393,5456,1143,5181,17,130,1344,5373,2002,5353,5141,257,168,5292,513]

theorem envBound58166 : H12AffineFastState.Bounded env58166 := by
  intro p hp
  have h : env58166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58165_58166 : H12AffineEnvironment.transform 10 934 env58165 = env58166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env58165 == env58166) = true)

theorem identity58166 : scanCanonicalize (H12AffineFastState.compose env58166 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound58166 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58167 : List Nat := [2,4,8,16,32,64,128,256,217,1024,383,4096,5301,1344,1109,4299,5292,10,1024,1109,493,1393,5456,1143,5181,17,130,1344,5373,1291,5353,5141,257,168,5292,216]

theorem envBound58167 : H12AffineFastState.Bounded env58167 := by
  intro p hp
  have h : env58167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58166_58167 : H12AffineEnvironment.transform 8 217 env58166 = env58167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env58166 == env58167) = true)

theorem identity58167 : scanCanonicalize (H12AffineFastState.compose env58167 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound58167 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env58168 : List Nat := [2,4,8,16,32,64,128,253,217,1024,130,4096,5301,1213,1109,4299,5292,10,1024,1109,16,1164,5293,1143,5181,17,130,1213,5373,1270,5353,5141,252,168,5292,216]

theorem envBound58168 : H12AffineFastState.Bounded env58168 := by
  intro p hp
  have h : env58168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58167_58168 : H12AffineEnvironment.transform 7 253 env58167 = env58168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env58167 == env58168) = true)

theorem identity58168 : scanCanonicalize (H12AffineFastState.compose env58168 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound58168 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58169 : List Nat := [2,4,8,16,32,64,128,253,217,1024,130,64,1269,1213,1109,139,1260,10,1024,1109,16,1164,1261,1143,1149,17,130,1213,1213,1270,1193,1109,252,168,1260,216]

theorem envBound58169 : H12AffineFastState.Bounded env58169 := by
  intro p hp
  have h : env58169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58168_58169 : H12AffineEnvironment.transform 11 64 env58168 = env58169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env58168 == env58169) = true)

theorem identity58169 : scanCanonicalize (H12AffineFastState.compose env58169 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound58169 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58170 : List Nat := [2,4,8,16,32,64,128,253,217,173,130,64,88,16,248,139,65,10,173,248,16,33,64,218,208,17,130,16,16,91,4,248,252,168,65,216]

theorem envBound58170 : H12AffineFastState.Bounded env58170 := by
  intro p hp
  have h : env58170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58169_58170 : H12AffineEnvironment.transform 9 173 env58169 = env58170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env58169 == env58170) = true)

theorem identity58170 : scanCanonicalize (H12AffineFastState.compose env58170 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound58170 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58171 : List Nat := [2,4,8,16,32,64,25,100,64,52,27,64,88,16,97,18,65,10,52,97,16,33,64,67,73,17,27,16,16,91,4,97,101,49,65,65]

theorem envBound58171 : H12AffineFastState.Bounded env58171 := by
  intro p hp
  have h : env58171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58170_58171 : H12AffineEnvironment.transform 6 25 env58170 = env58171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env58170 == env58171) = true)

theorem identity58171 : scanCanonicalize (H12AffineFastState.compose env58171 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound58171 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58172 : List Nat := [2,4,8,16,26,64,25,94,64,14,27,64,88,16,91,18,65,10,14,91,16,27,64,67,73,17,27,16,16,91,4,91,95,11,65,65]

theorem envBound58172 : H12AffineFastState.Bounded env58172 := by
  intro p hp
  have h : env58172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58171_58172 : H12AffineEnvironment.transform 4 26 env58171 = env58172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env58171 == env58172) = true)

theorem identity58172 : scanCanonicalize (H12AffineFastState.compose env58172 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58172 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58173 : List Nat := [2,4,1,16,19,64,16,87,64,7,18,64,81,16,82,18,65,3,7,82,16,18,64,67,64,17,18,16,16,82,4,82,86,2,65,65]

theorem envBound58173 : H12AffineFastState.Bounded env58173 := by
  intro p hp
  have h : env58173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58172_58173 : H12AffineEnvironment.transform 2 1 env58172 = env58173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58172 == env58173) = true)

theorem identity58173 : scanCanonicalize (H12AffineFastState.compose env58173 (packedSelected [0,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound58173 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58174 : List Nat := [2,4,1,16,19,0,16,23,0,7,18,0,17,16,18,18,1,3,7,18,16,18,0,3,0,17,18,16,16,18,4,18,22,2,1,1]

theorem envBound58174 : H12AffineFastState.Bounded env58174 := by
  intro p hp
  have h : env58174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58173_58174 : H12AffineEnvironment.transform 5 0 env58173 = env58174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env58173 == env58174) = true)

theorem identity58174 : scanCanonicalize (H12AffineFastState.compose env58174 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58175 : List Nat := [2,4,1,0,3,0,0,7,0,7,2,0,1,0,2,2,1,3,7,2,0,2,0,3,0,1,2,0,0,2,4,2,6,2,1,1]

theorem envBound58175 : H12AffineFastState.Bounded env58175 := by
  intro p hp
  have h : env58175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58174_58175 : H12AffineEnvironment.transform 3 0 env58174 = env58175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58174 == env58175) = true)

theorem identity58175 : scanCanonicalize (H12AffineFastState.compose env58175 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58175 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58176 : List Nat := [1,4,1,0,0,0,0,4,0,4,1,0,1,0,1,1,1,0,4,1,0,1,0,0,0,1,1,0,0,1,4,1,5,1,1,1]

theorem envBound58176 : H12AffineFastState.Bounded env58176 := by
  intro p hp
  have h : env58176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58175_58176 : H12AffineEnvironment.transform 0 1 env58175 = env58176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58175 == env58176) = true)

def env58177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66662,69824,1024,32768,69927,46481,78127,102632,8329,74863,103452,1345,66615,75787,5352,8352,257,69731,66662,512]

theorem envBound58177 : H12AffineFastState.Bounded env58177 := by
  intro p hp
  have h : env58177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58161_58177 : H12AffineEnvironment.transform 13 1345 env58161 = env58177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58161 == env58177) = true)

theorem identity58177 : scanCanonicalize (H12AffineFastState.compose env58177 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58177 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66662,67025,1024,32768,66614,41088,74814,99833,8329,74863,98573,1345,66615,75787,505,8352,257,66930,66662,512]

theorem envBound58178 : H12AffineFastState.Bounded env58178 := by
  intro p hp
  have h : env58178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58177_58178 : H12AffineEnvironment.transform 11 1297 env58177 = env58178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58177 == env58178) = true)

def env58179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144712,169103,2257032,157001,2544860,16384,131153,2324490,200847,221575,257,2295074,131072,2249217]

theorem envBound58179 : H12AffineFastState.Bounded env58179 := by
  intro p hp
  have h : env58179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58107_58179 : H12AffineEnvironment.transform 21 2269393 env58107 = env58179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env58107 == env58179) = true)

def env58180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144712,169103,26056,157001,311708,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58180 : H12AffineFastState.Bounded env58180 := by
  intro p hp
  have h : env58180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58179_58180 : H12AffineEnvironment.transform 20 136512 env58179 = env58180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58179 == env58180) = true)

def env58181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144712,169103,26056,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58181 : H12AffineFastState.Bounded env58181 := by
  intro p hp
  have h : env58181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58180_58181 : H12AffineEnvironment.transform 17 87424 env58180 = env58181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58180 == env58181) = true)

theorem identity58181 : scanCanonicalize (H12AffineFastState.compose env58181 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 91263) := by decide +kernel

theorem selectedBound58181 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,91263,87424,1024,32768,94527,46481,86327,127216,26056,65846,103452,16384,91182,93514,29936,1528,257,69730,91263,18241]

theorem envBound58182 : H12AffineFastState.Bounded env58182 := by
  intro p hp
  have h : env58182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58181_58182 : H12AffineEnvironment.transform 16 91263 env58181 = env58182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91263 env58181 == env58182) = true)

def env58183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74047,69824,1024,32768,78975,46481,70775,112048,8328,65846,103452,1344,74094,75786,12720,1528,257,69730,74047,513]

theorem envBound58183 : H12AffineFastState.Bounded env58183 := by
  intro p hp
  have h : env58183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58182_58183 : H12AffineEnvironment.transform 13 1344 env58182 = env58183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58182 == env58183) = true)

theorem identity58183 : scanCanonicalize (H12AffineFastState.compose env58183 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58183 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,46496,33887,1024,32768,41184,46481,33000,8495,8328,38313,131,1344,46577,48277,12720,1528,257,34045,46496,513]

theorem envBound58184 : H12AffineFastState.Bounded env58184 := by
  intro p hp
  have h : env58184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58183_58184 : H12AffineEnvironment.transform 15 38047 env58183 = env58184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58183 == env58184) = true)

theorem identity58184 : scanCanonicalize (H12AffineFastState.compose env58184 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5561) := by decide +kernel

theorem selectedBound58184 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,294,8217,4582,1024,5561,13657,8232,5457,8495,8328,16,131,1344,8264,10540,12720,1528,257,4420,8217,513]

theorem envBound58185 : H12AffineFastState.Bounded env58185 := by
  intro p hp
  have h : env58185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58184_58185 : H12AffineEnvironment.transform 14 5561 env58184 = env58185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5561 env58184 == env58185) = true)

theorem identity58185 : scanCanonicalize (H12AffineFastState.compose env58185 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound58185 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1108,294,8217,11,1024,1108,9396,8232,1212,8495,8328,16,131,1344,8264,10540,8285,1528,257,169,8217,513]

theorem envBound58186 : H12AffineFastState.Bounded env58186 := by
  intro p hp
  have h : env58186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58185_58186 : H12AffineEnvironment.transform 11 493 env58185 = env58186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58185 == env58186) = true)

theorem identity58186 : scanCanonicalize (H12AffineFastState.compose env58186 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 3923) := by decide +kernel

theorem selectedBound58186 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,3923,1344,1108,294,3914,11,1024,1108,3047,3963,1212,3708,4059,16,131,1344,3867,1663,3854,1528,257,169,3914,513]

theorem envBound58187 : H12AffineFastState.Bounded env58187 := by
  intro p hp
  have h : env58187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58186_58187 : H12AffineEnvironment.transform 12 3923 env58186 = env58187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3923 env58186 == env58187) = true)

theorem identity58187 : scanCanonicalize (H12AffineFastState.compose env58187 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound58187 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,420,1344,1108,294,445,11,1024,1108,1296,396,1212,139,300,16,131,1344,492,1663,505,1528,257,169,445,513]

theorem envBound58188 : H12AffineFastState.Bounded env58188 := by
  intro p hp
  have h : env58188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58187_58188 : H12AffineEnvironment.transform 10 1783 env58187 = env58188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env58187 == env58188) = true)

theorem identity58188 : scanCanonicalize (H12AffineFastState.compose env58188 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58188 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58189 : List Nat := [2,4,8,16,32,64,128,256,512,548,211,493,420,868,624,294,445,11,548,624,820,396,664,139,300,16,131,868,492,91,505,988,257,169,445,513]

theorem envBound58189 : H12AffineFastState.Bounded env58189 := by
  intro p hp
  have h : env58189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58188_58189 : H12AffineEnvironment.transform 9 548 env58188 = env58189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58188 == env58189) = true)

theorem identity58189 : scanCanonicalize (H12AffineFastState.compose env58189 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58189 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58190 : List Nat := [2,4,8,16,32,64,128,256,372,336,211,493,420,16,260,294,445,11,336,260,64,396,492,139,300,16,131,16,492,91,505,168,257,169,445,373]

theorem envBound58190 : H12AffineFastState.Bounded env58190 := by
  intro p hp
  have h : env58190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58189_58190 : H12AffineEnvironment.transform 8 372 env58189 = env58190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58189 == env58190) = true)

theorem identity58190 : scanCanonicalize (H12AffineFastState.compose env58190 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58190 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58191 : List Nat := [2,4,8,16,32,64,128,15,123,95,211,226,171,16,11,41,178,11,95,11,64,131,227,139,35,16,131,16,227,91,246,168,14,169,178,122]

theorem envBound58191 : H12AffineFastState.Bounded env58191 := by
  intro p hp
  have h : env58191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58190_58191 : H12AffineEnvironment.transform 7 15 env58190 = env58191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58190 == env58191) = true)

theorem identity58191 : scanCanonicalize (H12AffineFastState.compose env58191 (packedSelected [2,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound58191 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env58192 : List Nat := [2,4,8,16,32,8,128,15,51,23,155,170,171,16,11,41,178,11,23,11,8,131,171,139,35,16,131,16,171,19,190,168,14,169,178,50]

theorem envBound58192 : H12AffineFastState.Bounded env58192 := by
  intro p hp
  have h : env58192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58191_58192 : H12AffineEnvironment.transform 5 8 env58191 = env58192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env58191 == env58192) = true)

theorem identity58192 : scanCanonicalize (H12AffineFastState.compose env58192 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound58192 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env58193 : List Nat := [2,4,8,16,32,8,35,15,51,23,56,9,8,16,11,41,17,11,23,11,8,32,8,40,35,16,32,16,8,19,29,11,14,10,17,50]

theorem envBound58193 : H12AffineFastState.Bounded env58193 := by
  intro p hp
  have h : env58193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58192_58193 : H12AffineEnvironment.transform 6 35 env58192 = env58193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env58192 == env58193) = true)

theorem identity58193 : scanCanonicalize (H12AffineFastState.compose env58193 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound58193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58194 : List Nat := [2,4,8,16,18,8,17,15,1,23,10,9,8,16,11,27,17,11,23,11,8,18,8,26,17,16,18,16,8,19,29,11,14,10,17,0]

theorem envBound58194 : H12AffineFastState.Bounded env58194 := by
  intro p hp
  have h : env58194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58193_58194 : H12AffineEnvironment.transform 4 18 env58193 = env58194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env58193 == env58194) = true)

theorem identity58194 : scanCanonicalize (H12AffineFastState.compose env58194 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58194 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58195 : List Nat := [0,4,8,16,16,8,17,13,1,21,8,9,8,16,9,25,17,9,21,9,8,16,8,24,17,16,16,16,8,17,29,9,12,8,17,0]

theorem envBound58195 : H12AffineFastState.Bounded env58195 := by
  intro p hp
  have h : env58195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58194_58195 : H12AffineEnvironment.transform 0 0 env58194 = env58195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58194 == env58195) = true)

theorem identity58195 : scanCanonicalize (H12AffineFastState.compose env58195 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58195 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58196 : List Nat := [0,4,8,8,8,8,9,13,1,13,8,9,8,8,9,1,9,9,13,9,8,8,8,0,9,8,8,8,8,9,5,9,12,8,9,0]

theorem envBound58196 : H12AffineFastState.Bounded env58196 := by
  intro p hp
  have h : env58196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58195_58196 : H12AffineEnvironment.transform 3 8 env58195 = env58196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58195 == env58196) = true)

def leafEnv58196 : List Nat := [0,4,8,8,8,8,9,13,1,13,8,9,8,8,9,1,9,9,13,9,8,8,8,0,5,9,1,8,8,8,8,9,5,9,12,8,5,1,9,0,1,9,0]

def active58196 : List Nat := [1,2]

def tree58196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58196 : H12WitnessSearch.Good tree58196 := H12GlobalWitnessIndex.good

theorem leafIdentity58196 : H12AffineFastState.composeSystem env58196 rootObs = leafEnv58196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58196 rootObs == leafEnv58196) = true)

theorem terminalChecked58196 : H12PackedTerminal.terminalCheckFast leafEnv58196 active58196 tree58196 = true := by decide +kernel

def env58197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74046,69825,1024,32768,78974,46481,70774,112049,8329,65846,103452,1345,74095,75787,12721,1528,257,69730,74046,512]

theorem envBound58197 : H12AffineFastState.Bounded env58197 := by
  intro p hp
  have h : env58197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58182_58197 : H12AffineEnvironment.transform 13 1345 env58182 = env58197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58182 == env58197) = true)

theorem identity58197 : scanCanonicalize (H12AffineFastState.compose env58197 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58197 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74046,67024,1024,32768,74095,41088,65895,106656,8329,65846,98573,1345,74095,75787,9376,1528,257,66931,74046,512]

theorem envBound58198 : H12AffineFastState.Bounded env58198 := by
  intro p hp
  have h : env58198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58197_58198 : H12AffineEnvironment.transform 11 1297 env58197 = env58198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58197 == env58198) = true)

def env58199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144712,169103,26056,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58199 : H12AffineFastState.Bounded env58199 := by
  intro p hp
  have h : env58199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58180_58199 : H12AffineEnvironment.transform 17 87425 env58180 = env58199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58180 == env58199) = true)

theorem identity58199 : scanCanonicalize (H12AffineFastState.compose env58199 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 74047) := by decide +kernel

theorem selectedBound58199 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74047,87425,1024,32768,78975,46481,70775,112048,26056,83062,103453,16384,74094,93514,12720,16568,257,69730,74047,18241]

theorem envBound58200 : H12AffineFastState.Bounded env58200 := by
  intro p hp
  have h : env58200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58199_58200 : H12AffineEnvironment.transform 16 74047 env58199 = env58200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74047 env58199 == env58200) = true)

def env58201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74047,69825,1024,32768,78975,46481,70775,112048,8328,65846,103453,1344,74094,75786,12720,1528,257,69730,74047,513]

theorem envBound58201 : H12AffineFastState.Bounded env58201 := by
  intro p hp
  have h : env58201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58200_58201 : H12AffineEnvironment.transform 13 1344 env58200 = env58201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58200 == env58201) = true)

theorem identity58201 : scanCanonicalize (H12AffineFastState.compose env58201 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58201 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,46496,33886,1024,32768,41184,46481,33000,8495,8328,38313,130,1344,46577,48277,12720,1528,257,34045,46496,513]

theorem envBound58202 : H12AffineFastState.Bounded env58202 := by
  intro p hp
  have h : env58202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58201_58202 : H12AffineEnvironment.transform 15 38047 env58201 = env58202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58201 == env58202) = true)

theorem identity58202 : scanCanonicalize (H12AffineFastState.compose env58202 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5561) := by decide +kernel

theorem selectedBound58202 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,294,8217,4583,1024,5561,13657,8232,5457,8495,8328,16,130,1344,8264,10540,12720,1528,257,4420,8217,513]

theorem envBound58203 : H12AffineFastState.Bounded env58203 := by
  intro p hp
  have h : env58203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58202_58203 : H12AffineEnvironment.transform 14 5561 env58202 = env58203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5561 env58202 == env58203) = true)

theorem identity58203 : scanCanonicalize (H12AffineFastState.compose env58203 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound58203 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1108,294,8217,10,1024,1108,9396,8232,1212,8495,8328,16,130,1344,8264,10540,8285,1528,257,169,8217,513]

theorem envBound58204 : H12AffineFastState.Bounded env58204 := by
  intro p hp
  have h : env58204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58203_58204 : H12AffineEnvironment.transform 11 493 env58203 = env58204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58203 == env58204) = true)

theorem identity58204 : scanCanonicalize (H12AffineFastState.compose env58204 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 3923) := by decide +kernel

theorem selectedBound58204 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,3923,1344,1108,294,3914,10,1024,1108,3047,3963,1212,3708,4059,16,130,1344,3867,1663,3854,1528,257,169,3914,513]

theorem envBound58205 : H12AffineFastState.Bounded env58205 := by
  intro p hp
  have h : env58205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58204_58205 : H12AffineEnvironment.transform 12 3923 env58204 = env58205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3923 env58204 == env58205) = true)

theorem identity58205 : scanCanonicalize (H12AffineFastState.compose env58205 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound58205 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,420,1344,1108,294,445,10,1024,1108,1296,396,1212,139,300,16,130,1344,492,1663,505,1528,257,169,445,513]

theorem envBound58206 : H12AffineFastState.Bounded env58206 := by
  intro p hp
  have h : env58206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58205_58206 : H12AffineEnvironment.transform 10 1783 env58205 = env58206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env58205 == env58206) = true)

theorem identity58206 : scanCanonicalize (H12AffineFastState.compose env58206 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58206 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58207 : List Nat := [2,4,8,16,32,64,128,256,512,548,211,493,420,868,624,294,445,10,548,624,820,396,664,139,300,16,130,868,492,91,505,988,257,169,445,513]

theorem envBound58207 : H12AffineFastState.Bounded env58207 := by
  intro p hp
  have h : env58207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58206_58207 : H12AffineEnvironment.transform 9 548 env58206 = env58207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58206 == env58207) = true)

theorem identity58207 : scanCanonicalize (H12AffineFastState.compose env58207 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58207 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58208 : List Nat := [2,4,8,16,32,64,128,256,372,336,211,493,420,16,260,294,445,10,336,260,64,396,492,139,300,16,130,16,492,91,505,168,257,169,445,373]

theorem envBound58208 : H12AffineFastState.Bounded env58208 := by
  intro p hp
  have h : env58208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58207_58208 : H12AffineEnvironment.transform 8 372 env58207 = env58208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58207 == env58208) = true)

theorem identity58208 : scanCanonicalize (H12AffineFastState.compose env58208 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound58208 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58209 : List Nat := [2,4,8,16,32,64,115,256,372,336,32,286,343,16,260,294,334,10,336,260,64,383,287,120,300,16,113,16,287,91,266,91,257,90,334,373]

theorem envBound58209 : H12AffineFastState.Bounded env58209 := by
  intro p hp
  have h : env58209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58208_58209 : H12AffineEnvironment.transform 6 115 env58208 = env58209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env58208 == env58209) = true)

theorem identity58209 : scanCanonicalize (H12AffineFastState.compose env58209 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound58209 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env58210 : List Nat := [2,4,8,16,18,64,65,256,326,336,18,286,343,16,260,276,334,10,336,260,64,333,287,74,286,16,67,16,287,91,266,91,257,90,334,327]

theorem envBound58210 : H12AffineFastState.Bounded env58210 := by
  intro p hp
  have h : env58210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58209_58210 : H12AffineEnvironment.transform 4 18 env58209 = env58210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env58209 == env58210) = true)

theorem identity58210 : scanCanonicalize (H12AffineFastState.compose env58210 (packedSelected [0,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58210 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env58211 : List Nat := [2,4,8,16,18,16,17,256,278,256,18,286,263,16,260,276,286,10,256,260,16,285,287,26,286,16,19,16,287,11,266,11,257,10,286,279]

theorem envBound58211 : H12AffineFastState.Bounded env58211 := by
  intro p hp
  have h : env58211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58210_58211 : H12AffineEnvironment.transform 5 16 env58210 = env58211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58210 == env58211) = true)

theorem identity58211 : scanCanonicalize (H12AffineFastState.compose env58211 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound58211 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58212 : List Nat := [2,4,8,2,0,2,3,256,260,256,0,268,263,2,260,262,268,10,256,260,2,271,269,8,268,2,1,2,269,11,266,11,257,10,268,261]

theorem envBound58212 : H12AffineFastState.Bounded env58212 := by
  intro p hp
  have h : env58212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58211_58212 : H12AffineEnvironment.transform 3 2 env58211 = env58212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env58211 == env58212) = true)

theorem identity58212 : scanCanonicalize (H12AffineFastState.compose env58212 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58212 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env58213 : List Nat := [0,4,8,0,0,0,1,256,260,256,0,268,261,0,260,260,268,8,256,260,0,269,269,8,268,0,1,0,269,9,264,9,257,8,268,261]

theorem envBound58213 : H12AffineFastState.Bounded env58213 := by
  intro p hp
  have h : env58213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58212_58213 : H12AffineEnvironment.transform 0 0 env58212 = env58213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58212 == env58213) = true)

theorem identity58213 : scanCanonicalize (H12AffineFastState.compose env58213 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58214 : List Nat := [0,4,0,0,0,0,1,256,260,256,0,260,261,0,260,260,260,0,256,260,0,261,261,0,260,0,1,0,261,1,256,1,257,0,260,261]

theorem envBound58214 : H12AffineFastState.Bounded env58214 := by
  intro p hp
  have h : env58214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58213_58214 : H12AffineEnvironment.transform 2 0 env58213 = env58214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58213 == env58214) = true)

theorem identity58214 : scanCanonicalize (H12AffineFastState.compose env58214 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound58214 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58215 : List Nat := [0,4,0,0,0,0,1,5,1,5,0,1,0,0,1,1,1,0,5,1,0,0,0,0,1,0,1,0,0,1,5,1,4,0,1,0]

theorem envBound58215 : H12AffineFastState.Bounded env58215 := by
  intro p hp
  have h : env58215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58214_58215 : H12AffineEnvironment.transform 7 5 env58214 = env58215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env58214 == env58215) = true)

def env58216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74047,69824,1024,32768,78975,46481,70775,112048,8329,65847,103453,1345,74094,75787,12720,1529,257,69730,74047,512]

theorem envBound58216 : H12AffineFastState.Bounded env58216 := by
  intro p hp
  have h : env58216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58200_58216 : H12AffineEnvironment.transform 13 1345 env58200 = env58216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58200 == env58216) = true)

theorem identity58216 : scanCanonicalize (H12AffineFastState.compose env58216 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58216 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74047,67025,1024,32768,74094,41088,65894,106657,8329,65847,98572,1345,74094,75787,9377,1529,257,66931,74047,512]

theorem envBound58217 : H12AffineFastState.Bounded env58217 := by
  intro p hp
  have h : env58217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58216_58217 : H12AffineEnvironment.transform 11 1297 env58216 = env58217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58216 == env58217) = true)

def env58218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144712,169103,26057,157001,311709,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58218 : H12AffineFastState.Bounded env58218 := by
  intro p hp
  have h : env58218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58179_58218 : H12AffineEnvironment.transform 20 136513 env58179 = env58218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58179 == env58218) = true)

def env58219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144712,169103,26057,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58219 : H12AffineFastState.Bounded env58219 := by
  intro p hp
  have h : env58219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58218_58219 : H12AffineEnvironment.transform 17 87424 env58218 = env58219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58218 == env58219) = true)

theorem identity58219 : scanCanonicalize (H12AffineFastState.compose env58219 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 78894) := by decide +kernel

theorem selectedBound58219 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78894,87424,1024,32768,74095,46480,65894,106657,26057,86375,103453,16384,78975,93515,9377,21929,257,69731,78894,18240]

theorem envBound58220 : H12AffineFastState.Bounded env58220 := by
  intro p hp
  have h : env58220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58219_58220 : H12AffineEnvironment.transform 16 78894 env58219 = env58220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78894 env58219 == env58220) = true)

def env58221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78894,69824,1024,32768,74095,46480,65894,106657,8329,70695,103453,1344,78975,75787,9377,4329,257,69731,78894,512]

theorem envBound58221 : H12AffineFastState.Bounded env58221 := by
  intro p hp
  have h : env58221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58220_58221 : H12AffineEnvironment.transform 13 1344 env58220 = env58221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58220 == env58221) = true)

theorem identity58221 : scanCanonicalize (H12AffineFastState.compose env58221 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58221 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74046,67024,1024,32768,74095,41088,65894,106657,8329,65847,98573,1344,74095,75787,9377,1529,257,66931,74046,512]

theorem envBound58222 : H12AffineFastState.Bounded env58222 := by
  intro p hp
  have h : env58222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58221_58222 : H12AffineEnvironment.transform 11 1296 env58221 = env58222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58221 == env58222) = true)

def env58223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78894,69825,1024,32768,74095,46480,65894,106657,8328,70694,103453,1345,78975,75786,9377,4328,257,69731,78894,513]

theorem envBound58223 : H12AffineFastState.Bounded env58223 := by
  intro p hp
  have h : env58223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58220_58223 : H12AffineEnvironment.transform 13 1345 env58220 = env58223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58220 == env58223) = true)

theorem identity58223 : scanCanonicalize (H12AffineFastState.compose env58223 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58223 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,41136,33887,1024,32768,46577,46480,38392,13375,8328,32952,131,1345,41185,48276,9377,4328,257,34045,41136,513]

theorem envBound58224 : H12AffineFastState.Bounded env58224 := by
  intro p hp
  have h : env58224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58223_58224 : H12AffineEnvironment.transform 15 38046 env58223 = env58224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58223 == env58224) = true)

theorem identity58224 : scanCanonicalize (H12AffineFastState.compose env58224 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound58224 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,168,5174,8216,1271,1024,168,13657,13624,5456,13375,8328,16,131,1345,8265,15420,9377,4328,257,1109,8216,513]

theorem envBound58225 : H12AffineFastState.Bounded env58225 := by
  intro p hp
  have h : env58225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58224_58225 : H12AffineEnvironment.transform 14 168 env58224 = env58225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env58224 == env58225) = true)

theorem identity58225 : scanCanonicalize (H12AffineFastState.compose env58225 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58225 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58226 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,168,4298,8216,11,252,168,12709,12740,4524,12483,8328,16,131,445,8265,14528,8285,4328,257,169,8216,513]

theorem envBound58226 : H12AffineFastState.Bounded env58226 := by
  intro p hp
  have h : env58226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58225_58226 : H12AffineEnvironment.transform 9 252 env58225 = env58226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58225 == env58226) = true)

theorem identity58226 : scanCanonicalize (H12AffineFastState.compose env58226 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6723) := by decide +kernel

theorem selectedBound58226 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58227 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,6723,445,168,4298,6747,11,252,168,3046,2951,4524,2688,6859,16,131,445,6666,643,6686,4328,257,169,6747,513]

theorem envBound58227 : H12AffineFastState.Bounded env58227 := by
  intro p hp
  have h : env58227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58226_58227 : H12AffineEnvironment.transform 12 6723 env58226 = env58227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6723 env58226 == env58227) = true)

theorem identity58227 : scanCanonicalize (H12AffineFastState.compose env58227 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58227 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58228 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,4168,445,168,4298,4176,11,252,168,493,396,4524,139,4288,16,131,445,4097,643,4117,4328,257,169,4176,513]

theorem envBound58228 : H12AffineFastState.Bounded env58228 := by
  intro p hp
  have h : env58228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58227_58228 : H12AffineEnvironment.transform 10 523 env58227 = env58228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58227 == env58228) = true)

theorem identity58228 : scanCanonicalize (H12AffineFastState.compose env58228 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound58228 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58229 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,821,893,445,168,1023,869,11,252,168,493,396,665,139,1013,16,131,445,820,643,800,989,257,169,869,513]

theorem envBound58229 : H12AffineFastState.Bounded env58229 := by
  intro p hp
  have h : env58229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58228_58229 : H12AffineEnvironment.transform 11 821 env58228 = env58229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env58228 == env58229) = true)

theorem identity58229 : scanCanonicalize (H12AffineFastState.compose env58229 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58229 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58230 : List Nat := [2,4,8,16,32,64,128,172,512,252,523,665,721,17,168,595,713,11,252,168,65,32,665,139,601,16,131,17,664,643,652,625,173,169,713,513]

theorem envBound58230 : H12AffineFastState.Bounded env58230 := by
  intro p hp
  have h : env58230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58229_58230 : H12AffineEnvironment.transform 7 172 env58229 = env58230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58229 == env58230) = true)

theorem identity58230 : scanCanonicalize (H12AffineFastState.compose env58230 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound58230 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58231 : List Nat := [2,4,8,16,32,64,128,172,122,252,113,227,171,17,168,41,179,11,252,168,65,32,227,139,35,16,131,17,226,249,246,11,173,169,179,123]

theorem envBound58231 : H12AffineFastState.Bounded env58231 := by
  intro p hp
  have h : env58231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58230_58231 : H12AffineEnvironment.transform 8 122 env58230 = env58231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env58230 == env58231) = true)

theorem identity58231 : scanCanonicalize (H12AffineFastState.compose env58231 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound58231 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env58232 : List Nat := [2,4,8,16,32,64,16,60,122,108,113,115,59,17,56,41,35,11,108,56,65,32,115,27,35,16,19,17,114,105,102,11,61,57,35,123]

theorem envBound58232 : H12AffineFastState.Bounded env58232 := by
  intro p hp
  have h : env58232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58231_58232 : H12AffineEnvironment.transform 6 16 env58231 = env58232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env58231 == env58232) = true)

theorem identity58232 : scanCanonicalize (H12AffineFastState.compose env58232 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58232 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env58233 : List Nat := [2,4,8,16,32,17,16,60,43,61,32,34,59,17,56,41,35,11,61,56,16,32,34,27,35,16,19,17,35,56,55,11,61,57,35,42]

theorem envBound58233 : H12AffineFastState.Bounded env58233 := by
  intro p hp
  have h : env58233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58232_58233 : H12AffineEnvironment.transform 5 17 env58232 = env58233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58232 == env58233) = true)

theorem identity58233 : scanCanonicalize (H12AffineFastState.compose env58233 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58233 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58234 : List Nat := [0,4,8,16,32,17,16,60,41,61,32,32,57,17,56,41,33,9,61,56,16,32,32,25,33,16,17,17,33,56,53,9,61,57,33,40]

theorem envBound58234 : H12AffineFastState.Bounded env58234 := by
  intro p hp
  have h : env58234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58233_58234 : H12AffineEnvironment.transform 0 0 env58233 = env58234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58233 == env58234) = true)

theorem identity58234 : scanCanonicalize (H12AffineFastState.compose env58234 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58234 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env58235 : List Nat := [0,4,8,16,16,17,16,12,25,13,16,16,9,17,8,25,17,9,13,8,16,16,16,25,17,16,17,17,17,8,5,9,13,9,17,24]

theorem envBound58235 : H12AffineFastState.Bounded env58235 := by
  intro p hp
  have h : env58235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58234_58235 : H12AffineEnvironment.transform 4 16 env58234 = env58235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58234 == env58235) = true)

theorem identity58235 : scanCanonicalize (H12AffineFastState.compose env58235 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58236 : List Nat := [0,4,8,0,0,1,0,12,9,13,0,0,9,1,8,9,1,9,13,8,0,0,0,9,1,0,1,1,1,8,5,9,13,9,1,8]

theorem envBound58236 : H12AffineFastState.Bounded env58236 := by
  intro p hp
  have h : env58236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58235_58236 : H12AffineEnvironment.transform 3 0 env58235 = env58236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58235 == env58236) = true)

def env58237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144712,169103,26057,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58237 : H12AffineFastState.Bounded env58237 := by
  intro p hp
  have h : env58237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58218_58237 : H12AffineEnvironment.transform 17 87425 env58218 = env58237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58218 == env58237) = true)

theorem identity58237 : scanCanonicalize (H12AffineFastState.compose env58237 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 94575) := by decide +kernel

theorem selectedBound58237 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94575,87425,1024,32768,91182,46480,82983,124384,26057,70694,103452,16384,94526,93515,25056,4328,257,69731,94575,18240]

theorem envBound58238 : H12AffineFastState.Bounded env58238 := by
  intro p hp
  have h : env58238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58237_58238 : H12AffineEnvironment.transform 16 94575 env58237 = env58238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94575 env58237 == env58238) = true)

def env58239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78895,69825,1024,32768,74094,46480,65895,106656,8329,70694,103452,1344,78974,75787,9376,4328,257,69731,78895,512]

theorem envBound58239 : H12AffineFastState.Bounded env58239 := by
  intro p hp
  have h : env58239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58238_58239 : H12AffineEnvironment.transform 13 1344 env58238 = env58239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58238 == env58239) = true)

theorem identity58239 : scanCanonicalize (H12AffineFastState.compose env58239 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58239 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74047,67025,1024,32768,74094,41088,65895,106656,8329,65846,98572,1344,74094,75787,9376,1528,257,66931,74047,512]

theorem envBound58240 : H12AffineFastState.Bounded env58240 := by
  intro p hp
  have h : env58240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58239_58240 : H12AffineEnvironment.transform 11 1296 env58239 = env58240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58239 == env58240) = true)

def env58241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78894,69824,1024,32768,74095,46480,65894,106657,8328,70694,103452,1345,78975,75786,9377,4328,257,69731,78894,513]

theorem envBound58241 : H12AffineFastState.Bounded env58241 := by
  intro p hp
  have h : env58241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58238_58241 : H12AffineEnvironment.transform 13 1345 env58238 = env58241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58238 == env58241) = true)

theorem identity58241 : scanCanonicalize (H12AffineFastState.compose env58241 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58241 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,41136,33886,1024,32768,46577,46480,38392,13375,8328,32952,130,1345,41185,48276,9377,4328,257,34045,41136,513]

theorem envBound58242 : H12AffineFastState.Bounded env58242 := by
  intro p hp
  have h : env58242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58241_58242 : H12AffineEnvironment.transform 15 38046 env58241 = env58242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58241 == env58242) = true)

theorem identity58242 : scanCanonicalize (H12AffineFastState.compose env58242 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound58242 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,168,5174,8216,1270,1024,168,13657,13624,5456,13375,8328,16,130,1345,8265,15420,9377,4328,257,1109,8216,513]

theorem envBound58243 : H12AffineFastState.Bounded env58243 := by
  intro p hp
  have h : env58243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58242_58243 : H12AffineEnvironment.transform 14 168 env58242 = env58243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env58242 == env58243) = true)

theorem identity58243 : scanCanonicalize (H12AffineFastState.compose env58243 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58243 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58244 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,168,4298,8216,10,252,168,12709,12740,4524,12483,8328,16,130,445,8265,14528,8285,4328,257,169,8216,513]

theorem envBound58244 : H12AffineFastState.Bounded env58244 := by
  intro p hp
  have h : env58244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58243_58244 : H12AffineEnvironment.transform 9 252 env58243 = env58244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58243 == env58244) = true)

theorem identity58244 : scanCanonicalize (H12AffineFastState.compose env58244 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6723) := by decide +kernel

theorem selectedBound58244 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58245 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,6723,445,168,4298,6747,10,252,168,3046,2951,4524,2688,6859,16,130,445,6666,643,6686,4328,257,169,6747,513]

theorem envBound58245 : H12AffineFastState.Bounded env58245 := by
  intro p hp
  have h : env58245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58244_58245 : H12AffineEnvironment.transform 12 6723 env58244 = env58245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6723 env58244 == env58245) = true)

theorem identity58245 : scanCanonicalize (H12AffineFastState.compose env58245 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58245 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58246 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,4168,445,168,4298,4176,10,252,168,493,396,4524,139,4288,16,130,445,4097,643,4117,4328,257,169,4176,513]

theorem envBound58246 : H12AffineFastState.Bounded env58246 := by
  intro p hp
  have h : env58246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58245_58246 : H12AffineEnvironment.transform 10 523 env58245 = env58246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58245 == env58246) = true)

theorem identity58246 : scanCanonicalize (H12AffineFastState.compose env58246 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound58246 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58247 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,821,893,445,168,1023,869,10,252,168,493,396,665,139,1013,16,130,445,820,643,800,989,257,169,869,513]

theorem envBound58247 : H12AffineFastState.Bounded env58247 := by
  intro p hp
  have h : env58247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58246_58247 : H12AffineEnvironment.transform 11 821 env58246 = env58247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env58246 == env58247) = true)

theorem identity58247 : scanCanonicalize (H12AffineFastState.compose env58247 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58247 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58248 : List Nat := [2,4,8,16,32,64,128,172,512,252,523,665,721,17,168,595,713,10,252,168,65,32,665,139,601,16,130,17,664,643,652,625,173,169,713,513]

theorem envBound58248 : H12AffineFastState.Bounded env58248 := by
  intro p hp
  have h : env58248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58247_58248 : H12AffineEnvironment.transform 7 172 env58247 = env58248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58247 == env58248) = true)

theorem identity58248 : scanCanonicalize (H12AffineFastState.compose env58248 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound58248 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58249 : List Nat := [2,4,8,16,32,64,114,94,512,14,523,619,547,17,90,595,571,10,14,90,65,32,619,121,601,16,112,17,618,625,638,625,95,91,571,513]

theorem envBound58249 : H12AffineFastState.Bounded env58249 := by
  intro p hp
  have h : env58249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58248_58249 : H12AffineEnvironment.transform 6 114 env58248 = env58249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env58248 == env58249) = true)

theorem identity58249 : scanCanonicalize (H12AffineFastState.compose env58249 (packedSelected [0,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 72) := by decide +kernel

theorem selectedBound58249 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env58250 : List Nat := [2,4,8,16,32,64,114,94,72,14,67,35,107,17,90,27,115,10,14,90,65,32,35,121,17,16,112,17,34,57,54,57,95,91,115,73]

theorem envBound58250 : H12AffineFastState.Bounded env58250 := by
  intro p hp
  have h : env58250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58249_58250 : H12AffineEnvironment.transform 8 72 env58249 = env58250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 72 env58249 == env58250) = true)

theorem identity58250 : scanCanonicalize (H12AffineFastState.compose env58250 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound58250 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env58251 : List Nat := [2,4,8,16,32,35,17,61,43,14,32,35,8,17,57,27,16,10,14,57,34,32,35,26,17,16,19,17,34,57,54,57,60,56,16,42]

theorem envBound58251 : H12AffineFastState.Bounded env58251 := by
  intro p hp
  have h : env58251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58250_58251 : H12AffineEnvironment.transform 5 35 env58250 = env58251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env58250 == env58251) = true)

theorem identity58251 : scanCanonicalize (H12AffineFastState.compose env58251 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound58251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58252 : List Nat := [2,4,8,16,8,11,17,21,3,14,8,11,8,17,17,27,16,10,14,17,10,8,11,26,17,16,19,17,10,17,30,17,20,16,16,2]

theorem envBound58252 : H12AffineFastState.Bounded env58252 := by
  intro p hp
  have h : env58252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58251_58252 : H12AffineEnvironment.transform 4 8 env58251 = env58252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env58251 == env58252) = true)

theorem identity58252 : scanCanonicalize (H12AffineFastState.compose env58252 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58253 : List Nat := [1,4,8,16,8,8,17,21,0,13,8,8,8,17,17,24,16,9,13,17,9,8,8,25,17,16,16,17,9,17,29,17,20,16,16,1]

theorem envBound58253 : H12AffineFastState.Bounded env58253 := by
  intro p hp
  have h : env58253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58252_58253 : H12AffineEnvironment.transform 0 1 env58252 = env58253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58252 == env58253) = true)

theorem identity58253 : scanCanonicalize (H12AffineFastState.compose env58253 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58253 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58254 : List Nat := [1,4,8,8,8,8,9,13,0,13,8,8,8,9,9,0,8,9,13,9,9,8,8,1,9,8,8,9,9,9,5,9,12,8,8,1]

theorem envBound58254 : H12AffineFastState.Bounded env58254 := by
  intro p hp
  have h : env58254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58253_58254 : H12AffineEnvironment.transform 3 8 env58253 = env58254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58253 == env58254) = true)

def leafEnv58254 : List Nat := [1,4,8,8,8,8,9,13,0,13,8,8,8,9,9,0,8,9,13,9,9,8,8,1,5,9,1,8,8,9,9,9,5,9,12,8,5,0,8,1,1,8,0]

def active58254 : List Nat := [1,2]

def tree58254 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58254 : H12WitnessSearch.Good tree58254 := H12GlobalWitnessIndex.good

theorem leafIdentity58254 : H12AffineFastState.composeSystem env58254 rootObs = leafEnv58254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58254 rootObs == leafEnv58254) = true)

theorem terminalChecked58254 : H12PackedTerminal.terminalCheckFast leafEnv58254 active58254 tree58254 = true := by decide +kernel

def env58255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131153,4315355,8463815,4294967296,257,4307611964,131073,33563273]

theorem envBound58255 : H12AffineFastState.Bounded env58255 := by
  intro p hp
  have h : env58255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57669_58255 : H12AffineEnvironment.transform 34 131073 env57669 = env58255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env57669 == env58255) = true)

theorem identity58255 : scanCanonicalize (H12AffineFastState.compose env58255 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 2322823) := by decide +kernel

theorem selectedBound58255 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131153,4315355,8463815,2322823,257,14909627,131073,33563273]

theorem envBound58256 : H12AffineFastState.Bounded env58256 := by
  intro p hp
  have h : env58256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58255_58256 : H12AffineEnvironment.transform 31 2322823 env58255 = env58256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2322823 env58255 == env58256) = true)

theorem identity58256 : scanCanonicalize (H12AffineFastState.compose env58256 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58256 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,77954,4315355,8463815,2113876,257,14725224,78034,33563273]

theorem envBound58257 : H12AffineFastState.Bounded env58257 := by
  intro p hp
  have h : env58257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58256_58257 : H12AffineEnvironment.transform 16 78035 env58256 = env58257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58256 == env58257) = true)

def env58258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4176,77954,4294795,8463815,2101508,257,14725224,78034,33563273]

theorem envBound58258 : H12AffineFastState.Bounded env58258 := by
  intro p hp
  have h : env58258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58257_58258 : H12AffineEnvironment.transform 13 4176 env58257 = env58258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58257 == env58258) = true)

def env58259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,10785996,4176,77954,4294795,8463815,2101508,257,14725224,78034,33563273]

theorem envBound58259 : H12AffineFastState.Bounded env58259 := by
  intro p hp
  have h : env58259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58258_58259 : H12AffineEnvironment.transform 26 10785996 env58258 = env58259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10785996 env58258 == env58259) = true)

def env58260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,4227080,8388689,10785996,4176,77954,4294795,8463815,2101508,257,14725224,78034,4235905]

theorem envBound58260 : H12AffineFastState.Bounded env58260 := by
  intro p hp
  have h : env58260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58259_58260 : H12AffineEnvironment.transform 24 4227080 env58259 = env58260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env58259 == env58260) = true)

theorem identity58260 : scanCanonicalize (H12AffineFastState.compose env58260 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 2209035) := by decide +kernel

theorem selectedBound58260 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,2209035,8388608,8430023,2176259,8388689,10785996,4176,77954,2112896,8463815,2101508,257,8455523,78034,2168714]

theorem envBound58261 : H12AffineFastState.Bounded env58261 := by
  intro p hp
  have h : env58261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58260_58261 : H12AffineEnvironment.transform 21 2209035 env58260 = env58261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2209035 env58260 == env58261) = true)

theorem identity58261 : scanCanonicalize (H12AffineFastState.compose env58261 (packedSelected [15,17,19,21,26,38] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound58261 : packedSelected [15,17,19,21,26,38] rootPS < 2^1333 := by decide +kernel

def env58262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71050,41089,8388608,8430023,8329,8388689,8749382,4176,77954,75786,8463815,66702,257,8455523,78034,512]

theorem envBound58262 : H12AffineFastState.Bounded env58262 := by
  intro p hp
  have h : env58262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58261_58262 : H12AffineEnvironment.transform 20 71050 env58261 = env58262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env58261 == env58262) = true)

theorem identity58262 : scanCanonicalize (H12AffineFastState.compose env58262 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound58262 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37892,41089,8388608,8430023,8329,8388689,8650952,4176,45324,43396,8430665,34048,257,8422637,45404,512]

theorem envBound58263 : H12AffineFastState.Bounded env58263 := by
  intro p hp
  have h : env58263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58262_58263 : H12AffineEnvironment.transform 15 33166 env58262 = env58263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env58262 == env58263) = true)

theorem identity58263 : scanCanonicalize (H12AffineFastState.compose env58263 (packedSelected [5,8] rootPS)) = affineNative (2^(22+1) ^^^ 311201) := by decide +kernel

theorem selectedBound58263 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37892,41089,311201,269926,8329,311280,49001,4176,45324,43396,269288,34048,257,277324,45404,512]

theorem envBound58264 : H12AffineFastState.Bounded env58264 := by
  intro p hp
  have h : env58264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58263_58264 : H12AffineEnvironment.transform 22 311201 env58263 = env58264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 311201 env58263 == env58264) = true)

theorem identity58264 : scanCanonicalize (H12AffineFastState.compose env58264 (packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound58264 : packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS < 2^1333 := by decide +kernel

def env58265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8353,8495,4604,262144,1024,8353,13477,32,270080,269926,8329,270161,8136,4176,4525,2341,269288,9633,257,277324,4605,512]

theorem envBound58265 : H12AffineFastState.Bounded env58265 := by
  intro p hp
  have h : env58265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58264_58265 : H12AffineEnvironment.transform 14 8353 env58264 = env58265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env58264 == env58265) = true)

def env58266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1449,1063,4604,262144,1024,1449,4525,32,270080,269926,1409,270161,8136,4176,4525,2341,269288,169,257,269892,4605,512]

theorem envBound58266 : H12AffineFastState.Bounded env58266 := by
  intro p hp
  have h : env58266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58265_58266 : H12AffineEnvironment.transform 12 1288 env58265 = env58266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env58265 == env58266) = true)

theorem identity58266 : scanCanonicalize (H12AffineFastState.compose env58266 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4171) := by decide +kernel

theorem selectedBound58266 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1449,1063,4604,4171,1024,1449,4525,32,3915,3629,1409,3866,8136,4176,4525,2341,2979,169,257,3599,4605,512]

theorem envBound58267 : H12AffineFastState.Bounded env58267 := by
  intro p hp
  have h : env58267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58266_58267 : H12AffineEnvironment.transform 17 4171 env58266 = env58267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4171 env58266 == env58267) = true)

def env58268 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,348,4176,509,115,4604,4171,84,509,4525,32,2847,2681,469,2894,7068,4176,4525,2341,2979,169,257,2651,4605,512]

theorem envBound58268 : H12AffineFastState.Bounded env58268 := by
  intro p hp
  have h : env58268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58267_58268 : H12AffineEnvironment.transform 9 84 env58267 = env58268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58267 == env58268) = true)

def env58269 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,4096,348,4176,293,115,4388,4171,84,293,4469,32,2847,2681,269,2894,6980,4176,4469,2341,2939,113,257,2651,4389,512]

theorem envBound58269 : H12AffineFastState.Bounded env58269 := by
  intro p hp
  have h : env58269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58268_58269 : H12AffineEnvironment.transform 6 88 env58268 = env58269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58268 == env58269) = true)

theorem identity58269 : scanCanonicalize (H12AffineFastState.compose env58269 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 863) := by decide +kernel

theorem selectedBound58269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58270 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,863,348,783,293,115,635,788,84,293,554,32,2847,2681,269,2894,2075,783,554,2341,2939,113,257,2651,634,512]

theorem envBound58270 : H12AffineFastState.Bounded env58270 := by
  intro p hp
  have h : env58270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58269_58270 : H12AffineEnvironment.transform 11 863 env58269 = env58270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 863 env58269 == env58270) = true)

theorem identity58270 : scanCanonicalize (H12AffineFastState.compose env58270 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound58270 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58271 : List Nat := [2,4,8,16,32,64,88,256,512,84,539,863,348,783,293,115,635,788,84,293,554,32,260,98,269,341,512,783,554,830,352,113,257,64,634,512]

theorem envBound58271 : H12AffineFastState.Bounded env58271 := by
  intro p hp
  have h : env58271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58270_58271 : H12AffineEnvironment.transform 10 539 env58270 = env58271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env58270 == env58271) = true)

theorem identity58271 : scanCanonicalize (H12AffineFastState.compose env58271 (packedSelected [1,3,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound58271 : packedSelected [1,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env58272 : List Nat := [2,4,8,16,32,64,88,62,512,84,539,609,98,561,27,115,635,554,84,27,554,32,58,98,51,107,512,561,554,512,94,113,63,64,634,512]

theorem envBound58272 : H12AffineFastState.Bounded env58272 := by
  intro p hp
  have h : env58272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58271_58272 : H12AffineEnvironment.transform 7 62 env58271 = env58272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env58271 == env58272) = true)

theorem identity58272 : scanCanonicalize (H12AffineFastState.compose env58272 (packedSelected [0,3,9] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58272 : packedSelected [0,3,9] rootPS < 2^1333 := by decide +kernel

def env58273 : List Nat := [2,4,8,16,32,33,57,62,512,53,539,512,3,561,27,18,538,554,53,27,554,32,58,3,51,10,512,561,554,512,63,16,63,33,539,512]

theorem envBound58273 : H12AffineFastState.Bounded env58273 := by
  intro p hp
  have h : env58273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58272_58273 : H12AffineEnvironment.transform 5 33 env58272 = env58273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58272 == env58273) = true)

theorem identity58273 : scanCanonicalize (H12AffineFastState.compose env58273 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58274 : List Nat := [2,4,8,16,32,33,57,62,42,53,49,42,3,27,27,18,48,0,53,27,0,32,58,3,51,10,42,27,0,42,63,16,63,33,49,42]

theorem envBound58274 : H12AffineFastState.Bounded env58274 := by
  intro p hp
  have h : env58274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58273_58274 : H12AffineEnvironment.transform 8 42 env58273 = env58274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58273 == env58274) = true)

theorem identity58274 : scanCanonicalize (H12AffineFastState.compose env58274 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58274 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58275 : List Nat := [2,4,8,11,32,33,34,37,42,46,42,42,3,0,0,9,43,0,46,0,0,32,33,3,40,10,42,0,0,42,36,11,36,33,42,42]

theorem envBound58275 : H12AffineFastState.Bounded env58275 := by
  intro p hp
  have h : env58275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58274_58275 : H12AffineEnvironment.transform 3 11 env58274 = env58275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58274 == env58275) = true)

def env58276 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,4096,348,4176,292,115,4389,4171,84,292,4468,32,2847,2681,268,2894,6981,4176,4468,2341,2938,112,257,2651,4388,512]

theorem envBound58276 : H12AffineFastState.Bounded env58276 := by
  intro p hp
  have h : env58276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58268_58276 : H12AffineEnvironment.transform 6 89 env58268 = env58276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58268 == env58276) = true)

theorem identity58276 : scanCanonicalize (H12AffineFastState.compose env58276 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound58276 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58277 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,554,348,634,292,115,783,609,84,292,862,32,2847,2681,268,2894,2415,634,862,2341,2938,112,257,2651,782,512]

theorem envBound58277 : H12AffineFastState.Bounded env58277 := by
  intro p hp
  have h : env58277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58276_58277 : H12AffineEnvironment.transform 11 554 env58276 = env58277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env58276 == env58277) = true)

theorem identity58277 : scanCanonicalize (H12AffineFastState.compose env58277 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58277 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58278 : List Nat := [2,4,8,16,32,64,89,256,512,84,1,554,348,634,292,115,783,609,84,292,862,32,798,632,268,847,366,634,862,292,891,112,257,602,782,512]

theorem envBound58278 : H12AffineFastState.Bounded env58278 := by
  intro p hp
  have h : env58278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58277_58278 : H12AffineEnvironment.transform 10 1 env58277 = env58278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58277 == env58278) = true)

theorem identity58278 : scanCanonicalize (H12AffineFastState.compose env58278 (packedSelected [0,1,5,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound58278 : packedSelected [0,1,5,9,12,15] rootPS < 2^1333 := by decide +kernel

def env58279 : List Nat := [2,4,8,16,32,64,89,256,48,84,1,26,348,74,292,115,319,81,84,292,366,32,302,72,268,383,366,74,366,292,331,112,257,106,318,48]

theorem envBound58279 : H12AffineFastState.Bounded env58279 := by
  intro p hp
  have h : env58279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58278_58279 : H12AffineEnvironment.transform 8 48 env58278 = env58279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58278 == env58279) = true)

theorem identity58279 : scanCanonicalize (H12AffineFastState.compose env58279 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58279 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58280 : List Nat := [2,4,8,11,32,64,66,256,43,79,1,1,327,74,292,104,292,74,79,292,366,32,302,72,268,356,366,74,366,292,331,107,257,106,293,43]

theorem envBound58280 : H12AffineFastState.Bounded env58280 := by
  intro p hp
  have h : env58280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58279_58280 : H12AffineEnvironment.transform 3 11 env58279 = env58280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58279 == env58280) = true)

def env58281 : List Nat := [2,4,8,11,32,32,34,256,43,47,1,1,295,42,292,8,292,42,47,292,270,32,302,40,268,260,270,42,270,292,299,11,257,10,293,43]

theorem envBound58281 : H12AffineFastState.Bounded env58281 := by
  intro p hp
  have h : env58281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58280_58281 : H12AffineEnvironment.transform 5 32 env58280 = env58281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58280 == env58281) = true)

theorem identity58281 : scanCanonicalize (H12AffineFastState.compose env58281 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58282 : List Nat := [2,4,8,11,32,32,34,36,43,47,1,1,3,42,0,8,0,42,47,0,42,32,10,40,40,32,42,42,42,0,15,11,37,10,1,43]

theorem envBound58282 : H12AffineFastState.Bounded env58282 := by
  intro p hp
  have h : env58282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58281_58282 : H12AffineEnvironment.transform 7 36 env58281 = env58282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58281 == env58282) = true)

def env58283 : List Nat := [2,4,8,11,32,33,35,256,43,46,1,1,294,43,292,9,292,43,46,292,271,32,302,41,268,261,271,43,271,292,298,10,257,11,293,43]

theorem envBound58283 : H12AffineFastState.Bounded env58283 := by
  intro p hp
  have h : env58283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58280_58283 : H12AffineEnvironment.transform 5 33 env58280 = env58283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58280 == env58283) = true)

def env58284 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,349,4176,508,114,4604,4171,85,508,4525,32,2846,2680,468,2895,7069,4176,4525,2341,2979,169,257,2650,4605,512]

theorem envBound58284 : H12AffineFastState.Bounded env58284 := by
  intro p hp
  have h : env58284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58267_58284 : H12AffineEnvironment.transform 9 85 env58267 = env58284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58267 == env58284) = true)

def env58285 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,4096,349,4176,292,114,4388,4171,85,292,4469,32,2846,2680,268,2895,6981,4176,4469,2341,2939,113,257,2650,4389,512]

theorem envBound58285 : H12AffineFastState.Bounded env58285 := by
  intro p hp
  have h : env58285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58284_58285 : H12AffineEnvironment.transform 6 88 env58284 = env58285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58284 == env58285) = true)

theorem identity58285 : scanCanonicalize (H12AffineFastState.compose env58285 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound58285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58286 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,2420,349,2340,292,114,2128,2367,85,292,2049,32,2846,2680,268,2895,561,2340,2049,2341,2939,113,257,2650,2129,512]

theorem envBound58286 : H12AffineFastState.Bounded env58286 := by
  intro p hp
  have h : env58286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58285_58286 : H12AffineEnvironment.transform 11 2420 env58285 = env58286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env58285 == env58286) = true)

theorem identity58286 : scanCanonicalize (H12AffineFastState.compose env58286 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58286 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58287 : List Nat := [2,4,8,16,17,64,88,256,512,85,2048,2373,349,2325,277,67,2128,2318,85,277,2049,17,2846,2633,268,2895,512,2325,2049,2324,2890,64,257,2650,2129,512]

theorem envBound58287 : H12AffineFastState.Bounded env58287 := by
  intro p hp
  have h : env58287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58286_58287 : H12AffineEnvironment.transform 4 17 env58286 = env58287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58286 == env58287) = true)

theorem identity58287 : scanCanonicalize (H12AffineFastState.compose env58287 (packedSelected [0,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58287 : packedSelected [0,9,10] rootPS < 2^1333 := by decide +kernel

def env58288 : List Nat := [2,4,8,16,17,64,88,95,512,85,2048,2074,2,2122,74,67,2128,2129,85,74,2049,17,2625,2633,83,2576,512,2122,2049,2123,2581,64,94,2650,2129,512]

theorem envBound58288 : H12AffineFastState.Bounded env58288 := by
  intro p hp
  have h : env58288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58287_58288 : H12AffineEnvironment.transform 7 95 env58287 = env58288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58287 == env58288) = true)

def env58289 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,4096,349,4176,293,114,4389,4171,85,293,4468,32,2846,2680,269,2895,6980,4176,4468,2341,2938,112,257,2650,4388,512]

theorem envBound58289 : H12AffineFastState.Bounded env58289 := by
  intro p hp
  have h : env58289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58284_58289 : H12AffineEnvironment.transform 6 89 env58284 = env58289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58284 == env58289) = true)

theorem identity58289 : scanCanonicalize (H12AffineFastState.compose env58289 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound58289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58290 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,2048,349,2128,293,114,2341,2123,85,293,2420,32,2846,2680,269,2895,836,2128,2420,2341,2938,112,257,2650,2340,512]

theorem envBound58290 : H12AffineFastState.Bounded env58290 := by
  intro p hp
  have h : env58290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58289_58290 : H12AffineEnvironment.transform 11 2048 env58289 = env58290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env58289 == env58290) = true)

theorem identity58290 : scanCanonicalize (H12AffineFastState.compose env58290 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58290 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58291 : List Nat := [2,4,8,16,32,64,89,256,512,85,1,1,349,81,293,114,292,74,85,293,373,32,799,633,269,846,836,81,373,292,891,112,257,603,293,512]

theorem envBound58291 : H12AffineFastState.Bounded env58291 := by
  intro p hp
  have h : env58291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58290_58291 : H12AffineEnvironment.transform 10 1 env58290 = env58291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58290 == env58291) = true)

theorem identity58291 : scanCanonicalize (H12AffineFastState.compose env58291 (packedSelected [1,3,4,5,9,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58291 : packedSelected [1,3,4,5,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58292 : List Nat := [2,4,8,11,32,64,66,256,512,78,1,1,326,74,293,105,292,74,78,293,366,32,772,610,269,846,836,74,366,292,864,107,257,576,293,512]

theorem envBound58292 : H12AffineFastState.Bounded env58292 := by
  intro p hp
  have h : env58292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58291_58292 : H12AffineEnvironment.transform 3 11 env58291 = env58292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58291 == env58292) = true)

theorem identity58292 : scanCanonicalize (H12AffineFastState.compose env58292 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58292 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58293 : List Nat := [2,4,8,11,32,64,66,256,42,78,1,1,326,74,293,105,292,74,78,293,366,32,302,72,269,356,366,74,366,292,330,107,257,106,293,42]

theorem envBound58293 : H12AffineFastState.Bounded env58293 := by
  intro p hp
  have h : env58293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58292_58293 : H12AffineEnvironment.transform 8 42 env58292 = env58293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58292 == env58293) = true)

def env58294 : List Nat := [2,4,8,11,32,32,34,256,42,46,1,1,294,42,293,9,292,42,46,293,270,32,302,40,269,260,270,42,270,292,298,11,257,10,293,42]

theorem envBound58294 : H12AffineFastState.Bounded env58294 := by
  intro p hp
  have h : env58294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58293_58294 : H12AffineEnvironment.transform 5 32 env58293 = env58294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58293 == env58294) = true)

theorem identity58294 : scanCanonicalize (H12AffineFastState.compose env58294 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58295 : List Nat := [2,4,8,11,32,32,34,36,42,46,1,1,2,42,1,9,0,42,46,1,42,32,10,40,41,32,42,42,42,0,14,11,37,10,1,42]

theorem envBound58295 : H12AffineFastState.Bounded env58295 := by
  intro p hp
  have h : env58295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58294_58295 : H12AffineEnvironment.transform 7 36 env58294 = env58295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58294 == env58295) = true)

def env58296 : List Nat := [2,4,8,11,32,33,35,256,42,47,1,1,295,43,293,8,292,43,47,293,271,32,302,41,269,261,271,43,271,292,299,10,257,11,293,42]

theorem envBound58296 : H12AffineFastState.Bounded env58296 := by
  intro p hp
  have h : env58296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58293_58296 : H12AffineEnvironment.transform 5 33 env58293 = env58296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58293 == env58296) = true)

def env58297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1448,1062,4604,262144,1024,1448,4524,32,270080,269926,1408,270161,8136,4176,4525,2341,269288,168,257,269893,4605,512]

theorem envBound58297 : H12AffineFastState.Bounded env58297 := by
  intro p hp
  have h : env58297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58265_58297 : H12AffineEnvironment.transform 12 1289 env58265 = env58297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env58265 == env58297) = true)

theorem identity58297 : scanCanonicalize (H12AffineFastState.compose env58297 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound58297 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,1289,4176,1448,1062,4604,262144,1024,1448,4524,32,266662,266432,1408,266743,4462,4176,4525,1923,267598,168,257,266467,4605,512]

theorem envBound58298 : H12AffineFastState.Bounded env58298 := by
  intro p hp
  have h : env58298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58297_58298 : H12AffineEnvironment.transform 10 1702 env58297 = env58298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env58297 == env58298) = true)

def env58299 : List Nat := [2,4,8,16,32,64,128,256,512,84,754,4096,349,4176,508,114,4604,262144,84,508,4524,32,266662,266432,468,266743,4462,4176,4525,983,266522,168,257,266467,4605,512]

theorem envBound58299 : H12AffineFastState.Bounded env58299 := by
  intro p hp
  have h : env58299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58298_58299 : H12AffineEnvironment.transform 9 84 env58298 = env58299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58298 == env58299) = true)

def env58300 : List Nat := [2,4,8,16,32,64,88,256,512,84,554,4096,349,4176,292,114,4388,262144,84,292,4468,32,266622,266264,268,266543,4462,4176,4469,783,266522,112,257,266299,4389,512]

theorem envBound58300 : H12AffineFastState.Bounded env58300 := by
  intro p hp
  have h : env58300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58299_58300 : H12AffineEnvironment.transform 6 88 env58299 = env58300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58299 == env58300) = true)

theorem identity58300 : scanCanonicalize (H12AffineFastState.compose env58300 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 863) := by decide +kernel

theorem selectedBound58300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58301 : List Nat := [2,4,8,16,32,64,88,256,512,84,554,863,349,783,292,114,635,262144,84,292,555,32,262689,262983,268,262768,561,783,554,783,262725,112,257,263012,634,512]

theorem envBound58301 : H12AffineFastState.Bounded env58301 := by
  intro p hp
  have h : env58301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58300_58301 : H12AffineEnvironment.transform 11 863 env58300 = env58301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 863 env58300 == env58301) = true)

theorem identity58301 : scanCanonicalize (H12AffineFastState.compose env58301 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(17+1) ^^^ 862) := by decide +kernel

theorem selectedBound58301 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58302 : List Nat := [2,4,8,16,32,64,88,256,512,84,554,863,349,783,292,114,635,862,84,292,555,32,383,25,268,302,561,783,554,783,283,112,257,58,634,512]

theorem envBound58302 : H12AffineFastState.Bounded env58302 := by
  intro p hp
  have h : env58302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58301_58302 : H12AffineEnvironment.transform 17 862 env58301 = env58302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 862 env58301 == env58302) = true)

theorem identity58302 : scanCanonicalize (H12AffineFastState.compose env58302 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58302 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env58303 : List Nat := [2,4,8,16,32,11,19,256,512,31,554,788,278,783,292,57,560,789,31,292,555,32,308,25,268,302,561,783,554,783,283,59,257,58,561,512]

theorem envBound58303 : H12AffineFastState.Bounded env58303 := by
  intro p hp
  have h : env58303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58302_58303 : H12AffineEnvironment.transform 5 11 env58302 = env58303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58302 == env58303) = true)

theorem identity58303 : scanCanonicalize (H12AffineFastState.compose env58303 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58303 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58304 : List Nat := [2,4,8,16,32,11,19,37,512,31,554,561,51,554,1,57,560,560,31,1,555,32,17,25,41,11,561,554,554,554,62,59,36,58,561,512]

theorem envBound58304 : H12AffineFastState.Bounded env58304 := by
  intro p hp
  have h : env58304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58303_58304 : H12AffineEnvironment.transform 7 37 env58303 = env58304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58303 == env58304) = true)

theorem identity58304 : scanCanonicalize (H12AffineFastState.compose env58304 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58304 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58305 : List Nat := [2,4,8,16,17,11,19,20,512,31,539,512,2,539,1,8,513,513,31,1,538,17,17,25,24,11,512,539,539,539,15,10,21,11,512,512]

theorem envBound58305 : H12AffineFastState.Bounded env58305 := by
  intro p hp
  have h : env58305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58304_58305 : H12AffineEnvironment.transform 4 17 env58304 = env58305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58304 == env58305) = true)

def env58306 : List Nat := [2,4,8,16,32,64,89,256,512,84,555,4096,349,4176,293,114,4389,262144,84,293,4469,32,266623,266265,269,266542,4462,4176,4468,782,266522,113,257,266298,4388,512]

theorem envBound58306 : H12AffineFastState.Bounded env58306 := by
  intro p hp
  have h : env58306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58299_58306 : H12AffineEnvironment.transform 6 89 env58299 = env58306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58299 == env58306) = true)

theorem identity58306 : scanCanonicalize (H12AffineFastState.compose env58306 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound58306 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58307 : List Nat := [2,4,8,16,32,64,89,256,512,84,555,554,349,634,293,114,783,262144,84,293,863,32,262997,262707,269,262916,836,634,862,782,262960,113,257,262672,782,512]

theorem envBound58307 : H12AffineFastState.Bounded env58307 := by
  intro p hp
  have h : env58307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58306_58307 : H12AffineEnvironment.transform 11 554 env58306 = env58307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env58306 == env58307) = true)

theorem identity58307 : scanCanonicalize (H12AffineFastState.compose env58307 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 49) := by decide +kernel

theorem selectedBound58307 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58308 : List Nat := [2,4,8,16,32,64,89,256,512,84,555,554,349,634,293,114,783,49,84,293,863,32,868,514,269,821,836,634,862,782,769,113,257,545,782,512]

theorem envBound58308 : H12AffineFastState.Bounded env58308 := by
  intro p hp
  have h : env58308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58307_58308 : H12AffineEnvironment.transform 17 49 env58307 = env58308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49 env58307 == env58308) = true)

theorem identity58308 : scanCanonicalize (H12AffineFastState.compose env58308 (packedSelected [0,1,4,5,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound58308 : packedSelected [0,1,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env58309 : List Nat := [2,4,8,16,32,64,89,256,81,84,122,123,349,43,293,114,350,49,84,293,270,32,309,83,269,356,277,43,271,351,336,113,257,112,351,81]

theorem envBound58309 : H12AffineFastState.Bounded env58309 := by
  intro p hp
  have h : env58309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58308_58309 : H12AffineEnvironment.transform 8 81 env58308 = env58309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env58308 == env58309) = true)

theorem identity58309 : scanCanonicalize (H12AffineFastState.compose env58309 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58309 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env58310 : List Nat := [2,4,8,11,32,64,66,256,74,79,97,96,326,43,293,105,325,42,79,293,270,32,302,72,269,356,270,43,271,324,331,106,257,107,324,74]

theorem envBound58310 : H12AffineFastState.Bounded env58310 := by
  intro p hp
  have h : env58310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58309_58310 : H12AffineEnvironment.transform 3 11 env58309 = env58310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58309 == env58310) = true)

def env58311 : List Nat := [2,4,8,11,32,32,34,256,42,47,1,0,294,43,293,9,293,42,47,293,270,32,302,40,269,260,270,43,271,292,299,10,257,11,292,42]

theorem envBound58311 : H12AffineFastState.Bounded env58311 := by
  intro p hp
  have h : env58311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58310_58311 : H12AffineEnvironment.transform 5 32 env58310 = env58311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58310 == env58311) = true)

def env58312 : List Nat := [2,4,8,11,32,33,35,256,43,46,0,1,295,43,293,8,292,42,46,293,270,32,302,41,269,261,270,43,271,293,298,11,257,10,293,43]

theorem envBound58312 : H12AffineFastState.Bounded env58312 := by
  intro p hp
  have h : env58312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58310_58312 : H12AffineEnvironment.transform 5 33 env58310 = env58312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58310 == env58312) = true)

theorem identity58312 : scanCanonicalize (H12AffineFastState.compose env58312 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58313 : List Nat := [2,4,8,11,32,33,35,37,43,46,0,1,2,43,0,8,1,42,46,0,43,32,11,41,40,32,43,43,42,0,15,11,36,10,0,43]

theorem envBound58313 : H12AffineFastState.Bounded env58313 := by
  intro p hp
  have h : env58313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58312_58313 : H12AffineEnvironment.transform 7 37 env58312 = env58313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58312 == env58313) = true)

def env58314 : List Nat := [2,4,8,16,32,64,128,256,512,85,755,4096,348,4176,509,115,4604,262144,85,509,4524,32,266662,266432,469,266743,4462,4176,4525,982,266523,168,257,266467,4605,512]

theorem envBound58314 : H12AffineFastState.Bounded env58314 := by
  intro p hp
  have h : env58314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58298_58314 : H12AffineEnvironment.transform 9 85 env58298 = env58314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58298 == env58314) = true)

def env58315 : List Nat := [2,4,8,16,32,64,88,256,512,85,555,4096,348,4176,293,115,4388,262144,85,293,4468,32,266622,266264,269,266543,4462,4176,4469,782,266523,112,257,266299,4389,512]

theorem envBound58315 : H12AffineFastState.Bounded env58315 := by
  intro p hp
  have h : env58315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58314_58315 : H12AffineEnvironment.transform 6 88 env58314 = env58315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58314 == env58315) = true)

theorem identity58315 : scanCanonicalize (H12AffineFastState.compose env58315 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 788) := by decide +kernel

theorem selectedBound58315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58316 : List Nat := [2,4,8,16,32,64,88,256,512,85,555,4096,348,4176,293,115,4388,788,85,293,4468,32,4714,4876,269,4667,4462,4176,4469,782,4623,112,257,4911,4389,512]

theorem envBound58316 : H12AffineFastState.Bounded env58316 := by
  intro p hp
  have h : env58316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58315_58316 : H12AffineEnvironment.transform 17 788 env58315 = env58316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 788 env58315 == env58316) = true)

theorem identity58316 : scanCanonicalize (H12AffineFastState.compose env58316 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58316 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58317 : List Nat := [2,4,8,16,32,10,18,256,512,31,555,4096,278,4122,293,57,4388,788,31,293,4414,32,4640,4876,269,4667,4388,4122,4415,782,4623,58,257,4911,4389,512]

theorem envBound58317 : H12AffineFastState.Bounded env58317 := by
  intro p hp
  have h : env58317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58316_58317 : H12AffineEnvironment.transform 5 10 env58316 = env58317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58316 == env58317) = true)

theorem identity58317 : scanCanonicalize (H12AffineFastState.compose env58317 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 788) := by decide +kernel

theorem selectedBound58317 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env58318 : List Nat := [2,4,8,16,32,10,18,256,512,31,555,788,278,782,293,57,560,788,31,293,554,32,308,24,269,303,560,782,555,782,283,58,257,59,561,512]

theorem envBound58318 : H12AffineFastState.Bounded env58318 := by
  intro p hp
  have h : env58318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58317_58318 : H12AffineEnvironment.transform 11 788 env58317 = env58318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 788 env58317 == env58318) = true)

theorem identity58318 : scanCanonicalize (H12AffineFastState.compose env58318 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58318 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58319 : List Nat := [2,4,8,16,32,10,18,36,512,31,555,560,50,554,1,57,560,560,31,1,554,32,16,24,41,11,560,554,555,554,63,58,37,59,561,512]

theorem envBound58319 : H12AffineFastState.Bounded env58319 := by
  intro p hp
  have h : env58319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58318_58319 : H12AffineEnvironment.transform 7 36 env58318 = env58319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58318 == env58319) = true)

def env58320 : List Nat := [2,4,8,16,32,64,89,256,512,85,554,4096,348,4176,292,115,4389,262144,85,292,4469,32,266623,266265,268,266542,4462,4176,4468,783,266523,113,257,266298,4388,512]

theorem envBound58320 : H12AffineFastState.Bounded env58320 := by
  intro p hp
  have h : env58320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58314_58320 : H12AffineEnvironment.transform 6 89 env58314 = env58320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58314 == env58320) = true)

theorem identity58320 : scanCanonicalize (H12AffineFastState.compose env58320 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 609) := by decide +kernel

theorem selectedBound58320 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58321 : List Nat := [2,4,8,16,32,64,89,256,512,85,554,4096,348,4176,292,115,4389,609,85,292,4469,32,4894,4728,268,4943,4462,4176,4468,783,4986,113,257,4699,4388,512]

end H12CloudChart0