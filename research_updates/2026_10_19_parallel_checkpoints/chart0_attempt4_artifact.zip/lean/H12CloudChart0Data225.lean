import H12CloudChart0Data224

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans56995_56996 : H12AffineEnvironment.transform 15 374 env56995 = env56996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env56995 == env56996) = true)

theorem identity56996 : scanCanonicalize (H12AffineFastState.compose env56996 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound56996 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,248,374,8027,4582,1024,248,5373,3718,1212,2940,3702,1261,5522,4177,7947,1923,3826,3599,257,2910,8026,512]

theorem envBound56997 : H12AffineFastState.Bounded env56997 := by
  intro p hp
  have h : env56997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56996_56997 : H12AffineEnvironment.transform 12 3839 env56996 = env56997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env56996 == env56997) = true)

theorem identity56997 : scanCanonicalize (H12AffineFastState.compose env56997 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound56997 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,89,4177,248,374,4605,4582,1024,248,5373,32,1212,1498,208,1261,5522,4177,4525,1923,84,169,257,1528,4604,512]

theorem envBound56998 : H12AffineFastState.Bounded env56998 := by
  intro p hp
  have h : env56998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56997_56998 : H12AffineEnvironment.transform 10 1702 env56997 = env56998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env56997 == env56998) = true)

def env56999 : List Nat := [2,4,8,16,32,64,128,256,512,392,814,4096,89,4177,248,374,4605,4582,392,248,4469,32,308,82,208,357,4122,4177,4525,523,84,169,257,112,4604,512]

theorem envBound56999 : H12AffineFastState.Bounded env56999 := by
  intro p hp
  have h : env56999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56998_56999 : H12AffineEnvironment.transform 9 392 env56998 = env56999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env56998 == env56999) = true)

def env57000 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,4096,41,4129,136,262,4493,4502,392,136,4357,32,308,34,160,277,4122,4129,4525,523,36,169,257,0,4492,512]

theorem envBound57000 : H12AffineFastState.Bounded env57000 := by
  intro p hp
  have h : env57000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56999_57000 : H12AffineEnvironment.transform 5 48 env56999 = env57000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56999 == env57000) = true)

theorem identity57000 : scanCanonicalize (H12AffineFastState.compose env57000 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 814) := by decide +kernel

theorem selectedBound57000 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57001 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,814,41,783,136,262,675,696,392,136,555,32,308,34,160,277,820,783,643,523,36,169,257,0,674,512]

theorem envBound57001 : H12AffineFastState.Bounded env57001 := by
  intro p hp
  have h : env57001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57000_57001 : H12AffineEnvironment.transform 11 814 env57000 = env57001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 814 env57000 == env57001) = true)

theorem identity57001 : scanCanonicalize (H12AffineFastState.compose env57001 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57001 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57002 : List Nat := [2,4,8,16,32,48,128,256,10,392,292,292,41,261,136,262,169,178,392,136,33,32,308,34,160,277,318,261,137,1,36,169,257,0,168,10]

theorem envBound57002 : H12AffineFastState.Bounded env57002 := by
  intro p hp
  have h : env57002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57001_57002 : H12AffineEnvironment.transform 8 10 env57001 = env57002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57001 == env57002) = true)

theorem identity57002 : scanCanonicalize (H12AffineFastState.compose env57002 (packedSelected [0,4,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57002 : packedSelected [0,4,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57003 : List Nat := [2,4,8,16,32,48,128,31,10,151,59,59,41,26,136,25,169,178,151,136,33,32,43,34,160,10,33,26,137,1,36,169,30,0,168,10]

theorem envBound57003 : H12AffineFastState.Bounded env57003 := by
  intro p hp
  have h : env57003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57002_57003 : H12AffineEnvironment.transform 7 31 env57002 = env57003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57002 == env57003) = true)

theorem identity57003 : scanCanonicalize (H12AffineFastState.compose env57003 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57003 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57004 : List Nat := [2,4,8,16,32,48,40,31,10,63,59,59,41,26,32,25,1,26,63,32,33,32,43,34,8,10,33,26,33,1,36,1,30,0,0,10]

theorem envBound57004 : H12AffineFastState.Bounded env57004 := by
  intro p hp
  have h : env57004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57003_57004 : H12AffineEnvironment.transform 6 40 env57003 = env57004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57003 == env57004) = true)

def env57005 : List Nat := [2,4,8,0,32,32,40,15,10,47,43,43,41,10,32,9,1,10,47,32,33,32,43,34,8,10,33,10,33,1,36,1,14,0,0,10]

theorem envBound57005 : H12AffineFastState.Bounded env57005 := by
  intro p hp
  have h : env57005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57004_57005 : H12AffineEnvironment.transform 3 0 env57004 = env57005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57004 == env57005) = true)

def env57006 : List Nat := [2,4,8,1,32,33,40,14,10,46,42,42,41,11,32,8,1,11,46,32,33,32,43,34,8,10,33,11,33,1,36,1,15,0,0,10]

theorem envBound57006 : H12AffineFastState.Bounded env57006 := by
  intro p hp
  have h : env57006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57004_57006 : H12AffineEnvironment.transform 3 1 env57004 = env57006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57004 == env57006) = true)

theorem identity57006 : scanCanonicalize (H12AffineFastState.compose env57006 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57006 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57007 : List Nat := [2,4,8,1,11,10,3,14,10,5,1,1,2,11,11,8,1,11,5,11,10,11,0,9,8,10,10,11,10,1,15,1,15,0,0,10]

theorem envBound57007 : H12AffineFastState.Bounded env57007 := by
  intro p hp
  have h : env57007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57006_57007 : H12AffineEnvironment.transform 4 11 env57006 = env57007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57006 == env57007) = true)

def env57008 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,4096,40,4128,137,263,4492,4503,392,137,4356,32,308,35,161,276,4122,4128,4525,523,37,169,257,1,4493,512]

theorem envBound57008 : H12AffineFastState.Bounded env57008 := by
  intro p hp
  have h : env57008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56999_57008 : H12AffineEnvironment.transform 5 49 env56999 = env57008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56999 == env57008) = true)

theorem identity57008 : scanCanonicalize (H12AffineFastState.compose env57008 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 903) := by decide +kernel

theorem selectedBound57008 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57009 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,903,40,935,137,263,523,528,392,137,643,32,308,35,161,276,925,935,554,523,37,169,257,1,522,512]

theorem envBound57009 : H12AffineFastState.Bounded env57009 := by
  intro p hp
  have h : env57009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57008_57009 : H12AffineEnvironment.transform 11 903 env57008 = env57009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 903 env57008 == env57009) = true)

theorem identity57009 : scanCanonicalize (H12AffineFastState.compose env57009 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound57009 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57010 : List Nat := [2,4,8,16,32,49,128,256,276,392,58,147,40,179,137,263,287,260,392,137,407,32,308,35,161,276,137,179,318,287,37,169,257,1,286,276]

theorem envBound57010 : H12AffineFastState.Bounded env57010 := by
  intro p hp
  have h : env57010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57009_57010 : H12AffineEnvironment.transform 8 276 env57009 = env57010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env57009 == env57010) = true)

theorem identity57010 : scanCanonicalize (H12AffineFastState.compose env57010 (packedSelected [0,1,4,7,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57010 : packedSelected [0,1,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57011 : List Nat := [2,4,8,16,32,49,128,30,10,150,58,147,40,179,137,25,1,26,150,137,137,32,42,35,161,10,137,179,32,1,37,169,31,1,0,10]

theorem envBound57011 : H12AffineFastState.Bounded env57011 := by
  intro p hp
  have h : env57011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57010_57011 : H12AffineEnvironment.transform 7 30 env57010 = env57011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57010 == env57011) = true)

theorem identity57011 : scanCanonicalize (H12AffineFastState.compose env57011 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57011 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57012 : List Nat := [2,4,8,16,32,49,41,30,10,63,58,58,40,26,32,25,1,26,63,32,32,32,42,35,8,10,32,26,32,1,37,0,31,1,0,10]

theorem envBound57012 : H12AffineFastState.Bounded env57012 := by
  intro p hp
  have h : env57012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57011_57012 : H12AffineEnvironment.transform 6 41 env57011 = env57012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57011 == env57012) = true)

def env57013 : List Nat := [2,4,8,0,32,33,41,14,10,47,42,42,40,10,32,9,1,10,47,32,32,32,42,35,8,10,32,10,32,1,37,0,15,1,0,10]

theorem envBound57013 : H12AffineFastState.Bounded env57013 := by
  intro p hp
  have h : env57013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57012_57013 : H12AffineEnvironment.transform 3 0 env57012 = env57013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57012 == env57013) = true)

theorem identity57013 : scanCanonicalize (H12AffineFastState.compose env57013 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57014 : List Nat := [2,4,8,0,11,10,2,14,10,4,1,1,3,10,11,9,1,10,4,11,11,11,1,8,8,10,11,10,11,1,14,0,15,1,0,10]

theorem envBound57014 : H12AffineFastState.Bounded env57014 := by
  intro p hp
  have h : env57014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57013_57014 : H12AffineEnvironment.transform 4 11 env57013 = env57014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57013 == env57014) = true)

def env57015 : List Nat := [2,4,8,1,32,32,41,15,10,46,43,43,40,11,32,8,1,11,46,32,32,32,42,35,8,10,32,11,32,1,37,0,14,1,0,10]

theorem envBound57015 : H12AffineFastState.Bounded env57015 := by
  intro p hp
  have h : env57015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57012_57015 : H12AffineEnvironment.transform 3 1 env57012 = env57015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57012 == env57015) = true)

def env57016 : List Nat := [2,4,8,16,32,64,128,256,512,393,815,4096,89,4177,248,374,4605,4582,393,248,4468,32,309,83,208,356,4123,4177,4525,522,84,169,257,113,4604,512]

theorem envBound57016 : H12AffineFastState.Bounded env57016 := by
  intro p hp
  have h : env57016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56998_57016 : H12AffineEnvironment.transform 9 393 env56998 = env57016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env56998 == env57016) = true)

def env57017 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,4096,41,4129,136,262,4493,4502,393,136,4356,32,309,35,160,276,4123,4129,4525,522,36,169,257,1,4492,512]

theorem envBound57017 : H12AffineFastState.Bounded env57017 := by
  intro p hp
  have h : env57017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57016_57017 : H12AffineEnvironment.transform 5 48 env57016 = env57017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57016 == env57017) = true)

theorem identity57017 : scanCanonicalize (H12AffineFastState.compose env57017 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound57017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57018 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,554,41,523,136,262,935,956,393,136,814,32,309,35,160,276,561,523,903,522,36,169,257,1,934,512]

theorem envBound57018 : H12AffineFastState.Bounded env57018 := by
  intro p hp
  have h : env57018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57017_57018 : H12AffineEnvironment.transform 11 554 env57017 = env57018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env57017 == env57018) = true)

theorem identity57018 : scanCanonicalize (H12AffineFastState.compose env57018 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57018 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57019 : List Nat := [2,4,8,16,32,48,128,15,512,134,544,554,41,523,136,9,680,691,134,136,545,32,58,35,160,27,561,523,648,522,36,169,14,1,681,512]

theorem envBound57019 : H12AffineFastState.Bounded env57019 := by
  intro p hp
  have h : env57019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57018_57019 : H12AffineEnvironment.transform 7 15 env57018 = env57019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57018 == env57019) = true)

theorem identity57019 : scanCanonicalize (H12AffineFastState.compose env57019 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57019 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57020 : List Nat := [2,4,8,16,32,48,51,15,512,53,544,554,41,523,59,9,539,512,53,59,545,32,58,35,19,27,561,523,571,522,36,26,14,1,538,512]

theorem envBound57020 : H12AffineFastState.Bounded env57020 := by
  intro p hp
  have h : env57020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57019_57020 : H12AffineEnvironment.transform 6 51 env57019 = env57020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57019 == env57020) = true)

theorem identity57020 : scanCanonicalize (H12AffineFastState.compose env57020 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57020 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env57021 : List Nat := [2,4,8,16,10,26,25,15,512,31,522,512,3,523,17,9,539,512,31,17,523,10,16,9,19,27,539,523,529,522,14,26,14,1,538,512]

theorem envBound57021 : H12AffineFastState.Bounded env57021 := by
  intro p hp
  have h : env57021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57020_57021 : H12AffineEnvironment.transform 4 10 env57020 = env57021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57020 == env57021) = true)

theorem identity57021 : scanCanonicalize (H12AffineFastState.compose env57021 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57022 : List Nat := [2,4,8,10,10,0,3,15,512,5,522,512,3,523,11,9,513,512,5,11,523,10,10,9,9,1,513,523,523,522,14,0,14,1,512,512]

theorem envBound57022 : H12AffineFastState.Bounded env57022 := by
  intro p hp
  have h : env57022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57021_57022 : H12AffineEnvironment.transform 3 10 env57021 = env57022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57021 == env57022) = true)

def env57023 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,4096,40,4128,137,263,4492,4503,393,137,4357,32,309,34,161,277,4123,4128,4525,522,37,169,257,0,4493,512]

theorem envBound57023 : H12AffineFastState.Bounded env57023 := by
  intro p hp
  have h : env57023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57016_57023 : H12AffineEnvironment.transform 5 49 env57016 = env57023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57016 == env57023) = true)

theorem identity57023 : scanCanonicalize (H12AffineFastState.compose env57023 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57024 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,643,40,675,137,263,783,788,393,137,902,32,309,34,161,277,664,675,814,522,37,169,257,0,782,512]

theorem envBound57024 : H12AffineFastState.Bounded env57024 := by
  intro p hp
  have h : env57024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57023_57024 : H12AffineEnvironment.transform 11 643 env57023 = env57024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57023 == env57024) = true)

theorem identity57024 : scanCanonicalize (H12AffineFastState.compose env57024 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57024 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57025 : List Nat := [2,4,8,16,32,49,128,20,512,157,571,643,40,675,137,19,539,512,157,137,658,32,33,34,161,1,664,675,570,522,37,169,21,0,538,512]

theorem envBound57025 : H12AffineFastState.Bounded env57025 := by
  intro p hp
  have h : env57025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57024_57025 : H12AffineEnvironment.transform 7 20 env57024 = env57025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57024 == env57025) = true)

theorem identity57025 : scanCanonicalize (H12AffineFastState.compose env57025 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57025 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57026 : List Nat := [2,4,8,16,32,49,50,20,512,47,571,561,40,529,59,19,539,512,47,59,544,32,33,34,19,1,554,529,570,522,37,27,21,0,538,512]

theorem envBound57026 : H12AffineFastState.Bounded env57026 := by
  intro p hp
  have h : env57026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57025_57026 : H12AffineEnvironment.transform 6 50 env57025 = env57026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57025 == env57026) = true)

theorem identity57026 : scanCanonicalize (H12AffineFastState.compose env57026 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57026 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57027 : List Nat := [2,4,8,16,0,17,18,20,512,15,539,529,8,529,27,19,539,512,15,27,512,0,1,2,19,1,522,529,538,522,5,27,21,0,538,512]

theorem envBound57027 : H12AffineFastState.Bounded env57027 := by
  intro p hp
  have h : env57027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57026_57027 : H12AffineEnvironment.transform 4 0 env57026 = env57027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57026 == env57027) = true)

def env57028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4486237,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57028 : H12AffineFastState.Bounded env57028 := by
  intro p hp
  have h : env57028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56927_57028 : H12AffineEnvironment.transform 22 6336705 env56927 = env57028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env56927 == env57028) = true)

def env57029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4273309,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57029 : H12AffineFastState.Bounded env57029 := by
  intro p hp
  have h : env57029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57028_57029 : H12AffineEnvironment.transform 17 82112 env57028 = env57029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57028 == env57029) = true)

def env57030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142598,28889,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57030 : H12AffineFastState.Bounded env57030 := by
  intro p hp
  have h : env57030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57029_57030 : H12AffineEnvironment.transform 21 41088 env57029 = env57030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57029 == env57030) = true)

theorem identity57030 : scanCanonicalize (H12AffineFastState.compose env57030 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound57030 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12512,65536,78034,82112,1024,12512,2097152,4192,2101313,2097510,28889,2113601,75005,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57031 : H12AffineFastState.Bounded env57031 := by
  intro p hp
  have h : env57031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57030_57031 : H12AffineEnvironment.transform 14 12512 env57030 = env57031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env57030 == env57031) = true)

theorem identity57031 : scanCanonicalize (H12AffineFastState.compose env57031 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57031 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12512,65536,78034,79256,1024,12512,2097152,4192,2101313,2097510,1409,2110745,75005,13656,77954,68866,2176390,74118,257,2168098,78035,9992]

theorem envBound57032 : H12AffineFastState.Bounded env57032 := by
  intro p hp
  have h : env57032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57031_57032 : H12AffineEnvironment.transform 13 13656 env57031 = env57032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57031 == env57032) = true)

theorem identity57032 : scanCanonicalize (H12AffineFastState.compose env57032 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57032 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12512,65536,78034,79256,1024,12512,71050,4192,67019,70892,1409,73875,75005,13656,77954,68866,8204,74118,257,168,78035,9992]

theorem envBound57033 : H12AffineFastState.Bounded env57033 := by
  intro p hp
  have h : env57033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57032_57033 : H12AffineEnvironment.transform 20 71050 env57032 = env57033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57032 == env57033) = true)

theorem identity57033 : scanCanonicalize (H12AffineFastState.compose env57033 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1419) := by decide +kernel

theorem selectedBound57033 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12512,1419,13657,12307,1024,12512,4097,4192,64,4455,1409,9496,8566,13656,13577,2185,8204,9229,257,168,13656,9992]

theorem envBound57034 : H12AffineFastState.Bounded env57034 := by
  intro p hp
  have h : env57034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57033_57034 : H12AffineEnvironment.transform 15 1419 env57033 = env57034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1419 env57033 == env57034) = true)

theorem identity57034 : scanCanonicalize (H12AffineFastState.compose env57034 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57034 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,1419,4176,5402,1024,5609,4097,4192,64,4455,1409,17,1151,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57035 : H12AffineFastState.Bounded env57035 := by
  intro p hp
  have h : env57035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57034_57035 : H12AffineEnvironment.transform 12 1289 env57034 = env57035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57034 == env57035) = true)

theorem identity57035 : scanCanonicalize (H12AffineFastState.compose env57035 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3814) := by decide +kernel

theorem selectedBound57035 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,1289,3767,2831,1419,3766,3068,1024,2831,3815,3718,64,3969,1409,17,1151,3767,3814,2185,1285,260,257,168,3767,513]

theorem envBound57036 : H12AffineFastState.Bounded env57036 := by
  intro p hp
  have h : env57036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57035_57036 : H12AffineEnvironment.transform 11 3814 env57035 = env57036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3814 env57035 == env57036) = true)

theorem identity57036 : scanCanonicalize (H12AffineFastState.compose env57036 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57036 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57037 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,2414,641,2367,2831,515,2366,3068,904,2831,2415,2318,64,2057,521,17,1015,2367,2414,2185,653,260,257,168,2367,513]

theorem envBound57037 : H12AffineFastState.Bounded env57037 := by
  intro p hp
  have h : env57037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57036_57037 : H12AffineEnvironment.transform 9 904 env57036 = env57037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57036 == env57037) = true)

theorem identity57037 : scanCanonicalize (H12AffineFastState.compose env57037 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1015) := by decide +kernel

theorem selectedBound57037 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57038 : List Nat := [2,4,8,16,32,64,128,256,512,904,1015,665,641,712,248,515,713,11,904,248,664,761,64,1022,521,17,1015,712,665,894,653,260,257,168,712,513]

theorem envBound57038 : H12AffineFastState.Bounded env57038 := by
  intro p hp
  have h : env57038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57037_57038 : H12AffineEnvironment.transform 10 1015 env57037 = env57038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1015 env57037 == env57038) = true)

theorem identity57038 : scanCanonicalize (H12AffineFastState.compose env57038 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57038 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57039 : List Nat := [2,4,8,16,32,64,128,256,373,253,130,492,500,445,248,374,444,11,253,248,493,396,64,139,380,17,130,445,492,11,504,260,257,168,445,372]

theorem envBound57039 : H12AffineFastState.Bounded env57039 := by
  intro p hp
  have h : env57039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57038_57039 : H12AffineEnvironment.transform 8 373 env57038 = env57039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57038 == env57039) = true)

theorem identity57039 : scanCanonicalize (H12AffineFastState.compose env57039 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57039 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57040 : List Nat := [2,4,8,16,32,64,128,79,58,253,130,163,187,242,248,57,243,11,253,248,162,195,64,139,51,17,130,242,163,11,183,75,78,168,242,59]

theorem envBound57040 : H12AffineFastState.Bounded env57040 := by
  intro p hp
  have h : env57040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57039_57040 : H12AffineEnvironment.transform 7 79 env57039 = env57040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57039 == env57040) = true)

theorem identity57040 : scanCanonicalize (H12AffineFastState.compose env57040 (packedSelected [0,2,3,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57040 : packedSelected [0,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env57041 : List Nat := [2,4,8,16,11,64,128,79,17,214,130,136,144,217,211,18,216,11,214,211,137,195,64,139,24,17,130,217,136,11,156,75,78,131,217,16]

theorem envBound57041 : H12AffineFastState.Bounded env57041 := by
  intro p hp
  have h : env57041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57040_57041 : H12AffineEnvironment.transform 4 11 env57040 = env57041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57040 == env57041) = true)

theorem identity57041 : scanCanonicalize (H12AffineFastState.compose env57041 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57041 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57042 : List Nat := [2,4,8,16,11,11,128,4,17,157,130,136,144,146,152,18,147,11,157,152,137,136,11,139,24,17,130,146,136,11,156,0,5,131,146,16]

theorem envBound57042 : H12AffineFastState.Bounded env57042 := by
  intro p hp
  have h : env57042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57041_57042 : H12AffineEnvironment.transform 5 11 env57041 = env57042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57041 == env57042) = true)

theorem identity57042 : scanCanonicalize (H12AffineFastState.compose env57042 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57042 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57043 : List Nat := [2,4,8,16,11,11,2,4,17,31,0,10,18,16,26,18,17,11,31,26,11,10,11,9,24,17,0,16,10,11,30,0,5,1,16,16]

theorem envBound57043 : H12AffineFastState.Bounded env57043 := by
  intro p hp
  have h : env57043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57042_57043 : H12AffineEnvironment.transform 6 2 env57042 = env57043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57042 == env57043) = true)

theorem identity57043 : scanCanonicalize (H12AffineFastState.compose env57043 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57043 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57044 : List Nat := [2,4,8,0,11,11,2,4,1,15,0,10,2,0,10,2,1,11,15,10,11,10,11,9,8,1,0,0,10,11,14,0,5,1,0,0]

theorem envBound57044 : H12AffineFastState.Bounded env57044 := by
  intro p hp
  have h : env57044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57043_57044 : H12AffineEnvironment.transform 3 0 env57043 = env57044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57043 == env57044) = true)

theorem identity57044 : scanCanonicalize (H12AffineFastState.compose env57044 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57045 : List Nat := [2,4,1,0,2,2,2,4,1,6,0,3,2,0,3,2,1,2,6,3,2,3,2,0,1,1,0,0,3,2,7,0,5,1,0,0]

theorem envBound57045 : H12AffineFastState.Bounded env57045 := by
  intro p hp
  have h : env57045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57044_57045 : H12AffineEnvironment.transform 2 1 env57044 = env57045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57044 == env57045) = true)

def env57046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142599,28888,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57046 : H12AffineFastState.Bounded env57046 := by
  intro p hp
  have h : env57046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57029_57046 : H12AffineEnvironment.transform 21 41089 env57029 = env57046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57029 == env57046) = true)

theorem identity57046 : scanCanonicalize (H12AffineFastState.compose env57046 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound57046 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,78034,82112,1024,30113,2097152,21792,2101312,2114598,28888,2113600,90557,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57047 : H12AffineFastState.Bounded env57047 := by
  intro p hp
  have h : env57047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57046_57047 : H12AffineEnvironment.transform 14 30113 env57046 = env57047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env57046 == env57047) = true)

theorem identity57047 : scanCanonicalize (H12AffineFastState.compose env57047 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57047 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,78034,82112,1024,30113,83418,21792,87450,66044,28888,66970,90557,16384,77954,96347,28765,74119,257,9633,78035,21073]

theorem envBound57048 : H12AffineFastState.Bounded env57048 := by
  intro p hp
  have h : env57048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57047_57048 : H12AffineEnvironment.transform 20 83418 env57047 = env57048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57047 == env57048) = true)

theorem identity57048 : scanCanonicalize (H12AffineFastState.compose env57048 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57048 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,65536,78034,69777,1024,9712,71051,1393,67019,66044,8329,66970,78316,4177,77954,75786,8204,74119,257,9633,78035,512]

theorem envBound57049 : H12AffineFastState.Bounded env57049 := by
  intro p hp
  have h : env57049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57048_57049 : H12AffineEnvironment.transform 13 4177 env57048 = env57049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57048 == env57049) = true)

theorem identity57049 : scanCanonicalize (H12AffineFastState.compose env57049 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound57049 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,9342,5292,13551,1024,9712,12789,1393,8629,9602,8329,8676,5522,4177,5372,3188,8204,1529,257,9633,5293,512]

theorem envBound57050 : H12AffineFastState.Bounded env57050 := by
  intro p hp
  have h : env57050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57049_57050 : H12AffineEnvironment.transform 15 9342 env57049 = env57050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env57049 == env57050) = true)

theorem identity57050 : scanCanonicalize (H12AffineFastState.compose env57050 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57050 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,2830,2688,5292,6673,1024,2830,7947,1393,3915,2940,3703,3866,5522,4177,5372,3188,3826,1529,257,2911,5293,512]

theorem envBound57051 : H12AffineFastState.Bounded env57051 := by
  intro p hp
  have h : env57051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57050_57051 : H12AffineEnvironment.transform 12 3838 env57050 = env57051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57050 == env57051) = true)

theorem identity57051 : scanCanonicalize (H12AffineFastState.compose env57051 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound57051 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57052 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,4096,2991,4177,2830,2688,4605,6673,337,2830,6746,32,2586,2940,2854,2635,4291,4177,4525,2341,2979,168,257,2911,4604,512]

theorem envBound57052 : H12AffineFastState.Bounded env57052 := by
  intro p hp
  have h : env57052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57051_57052 : H12AffineEnvironment.transform 9 337 env57051 = env57052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57051 == env57052) = true)

def env57053 : List Nat := [2,4,8,16,32,64,128,4,512,85,2048,4096,2731,4177,2570,2688,4345,6673,85,2570,6746,32,2586,2680,2594,2635,4291,4177,4265,2081,2727,168,5,2651,4344,512]

theorem envBound57053 : H12AffineFastState.Bounded env57053 := by
  intro p hp
  have h : env57053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57052_57053 : H12AffineEnvironment.transform 7 4 env57052 = env57053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57052 == env57053) = true)

def env57054 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,4096,2731,4129,2570,2688,4233,6673,37,2570,6698,32,2586,2568,2594,2619,4275,4129,4265,2081,2727,168,5,2603,4232,512]

theorem envBound57054 : H12AffineFastState.Bounded env57054 := by
  intro p hp
  have h : env57054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57053_57054 : H12AffineEnvironment.transform 5 48 env57053 = env57054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57053 == env57054) = true)

theorem identity57054 : scanCanonicalize (H12AffineFastState.compose env57054 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound57054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57055 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,2217,2731,2184,2570,2688,2080,696,37,2570,643,32,2586,2568,2594,2619,2074,2184,2048,2081,2727,168,5,2603,2081,512]

theorem envBound57055 : H12AffineFastState.Bounded env57055 := by
  intro p hp
  have h : env57055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57054_57055 : H12AffineEnvironment.transform 11 2217 env57054 = env57055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env57054 == env57055) = true)

def env57056 : List Nat := [2,4,8,16,32,48,128,4,512,37,648,545,35,512,130,8,680,696,37,130,643,32,146,128,170,179,658,512,648,681,47,168,5,163,681,512]

theorem envBound57056 : H12AffineFastState.Bounded env57056 := by
  intro p hp
  have h : env57056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57055_57056 : H12AffineEnvironment.transform 10 648 env57055 = env57056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57055 == env57056) = true)

theorem identity57056 : scanCanonicalize (H12AffineFastState.compose env57056 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57056 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57057 : List Nat := [2,4,8,16,32,48,51,4,512,37,571,545,35,512,49,8,539,523,37,49,560,32,33,51,25,0,545,512,571,538,47,27,5,16,538,512]

theorem envBound57057 : H12AffineFastState.Bounded env57057 := by
  intro p hp
  have h : env57057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57056_57057 : H12AffineEnvironment.transform 6 51 env57056 = env57057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57056 == env57057) = true)

theorem identity57057 : scanCanonicalize (H12AffineFastState.compose env57057 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57057 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57058 : List Nat := [2,4,2,16,32,48,51,4,512,37,561,545,35,512,49,2,529,513,37,49,560,32,33,51,19,0,545,512,561,528,37,17,5,16,528,512]

theorem envBound57058 : H12AffineFastState.Bounded env57058 := by
  intro p hp
  have h : env57058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57057_57058 : H12AffineEnvironment.transform 2 2 env57057 = env57058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57057 == env57058) = true)

def env57059 : List Nat := [2,4,8,16,32,48,128,4,512,37,649,544,34,513,131,9,681,696,37,131,643,32,147,129,171,178,659,513,649,680,46,168,5,162,680,512]

theorem envBound57059 : H12AffineFastState.Bounded env57059 := by
  intro p hp
  have h : env57059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57055_57059 : H12AffineEnvironment.transform 10 649 env57055 = env57059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57055 == env57059) = true)

theorem identity57059 : scanCanonicalize (H12AffineFastState.compose env57059 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57059 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57060 : List Nat := [2,4,8,16,32,48,56,4,512,37,561,544,34,513,59,9,529,512,37,59,571,32,43,57,19,10,555,513,561,528,46,16,5,26,528,512]

theorem envBound57060 : H12AffineFastState.Bounded env57060 := by
  intro p hp
  have h : env57060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57059_57060 : H12AffineEnvironment.transform 6 56 env57059 = env57060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57059 == env57060) = true)

def env57061 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,4096,2731,4128,2570,2688,4232,6673,36,2570,6699,32,2586,2569,2594,2618,4274,4128,4265,2081,2727,168,5,2602,4233,512]

theorem envBound57061 : H12AffineFastState.Bounded env57061 := by
  intro p hp
  have h : env57061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57053_57061 : H12AffineEnvironment.transform 5 49 env57053 = env57061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57053 == env57061) = true)

theorem identity57061 : scanCanonicalize (H12AffineFastState.compose env57061 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound57061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57062 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,2049,2731,2081,2570,2688,2185,528,36,2570,554,32,2586,2569,2594,2618,2227,2081,2216,2081,2727,168,5,2602,2184,512]

theorem envBound57062 : H12AffineFastState.Bounded env57062 := by
  intro p hp
  have h : env57062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57061_57062 : H12AffineEnvironment.transform 11 2049 env57061 = env57062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env57061 == env57062) = true)

def env57063 : List Nat := [2,4,8,16,0,17,128,4,512,4,2048,2049,2699,2049,2570,2688,2185,528,4,2570,522,0,2586,2569,2562,2586,2195,2049,2184,2049,2695,136,5,2570,2184,512]

theorem envBound57063 : H12AffineFastState.Bounded env57063 := by
  intro p hp
  have h : env57063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57062_57063 : H12AffineEnvironment.transform 4 0 env57062 = env57063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57062 == env57063) = true)

theorem identity57063 : scanCanonicalize (H12AffineFastState.compose env57063 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57063 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57064 : List Nat := [2,4,8,11,0,10,128,4,512,4,2048,2049,2699,2049,2570,2688,2185,523,4,2570,522,0,2561,2569,2562,2561,2184,2049,2184,2049,2695,136,5,2570,2184,512]

theorem envBound57064 : H12AffineFastState.Bounded env57064 := by
  intro p hp
  have h : env57064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57063_57064 : H12AffineEnvironment.transform 3 11 env57063 = env57064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57063 == env57064) = true)

theorem identity57064 : scanCanonicalize (H12AffineFastState.compose env57064 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57064 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57065 : List Nat := [2,4,8,11,0,10,128,4,512,4,1,0,650,0,523,641,136,523,4,523,522,0,512,520,515,512,137,0,137,0,646,136,5,523,137,512]

theorem envBound57065 : H12AffineFastState.Bounded env57065 := by
  intro p hp
  have h : env57065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57064_57065 : H12AffineEnvironment.transform 10 1 env57064 = env57065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57064 == env57065) = true)

theorem identity57065 : scanCanonicalize (H12AffineFastState.compose env57065 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57065 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57066 : List Nat := [2,4,8,11,0,10,128,4,136,4,1,0,2,0,131,9,136,131,4,131,130,0,136,128,139,136,137,0,137,0,14,136,5,131,137,136]

theorem envBound57066 : H12AffineFastState.Bounded env57066 := by
  intro p hp
  have h : env57066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57065_57066 : H12AffineEnvironment.transform 8 136 env57065 = env57066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57065 == env57066) = true)

theorem identity57066 : scanCanonicalize (H12AffineFastState.compose env57066 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57066 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57067 : List Nat := [2,4,3,0,0,1,128,4,131,4,1,0,2,0,131,2,131,131,4,131,130,0,131,128,128,131,130,0,130,0,5,131,5,131,130,131]

theorem envBound57067 : H12AffineFastState.Bounded env57067 := by
  intro p hp
  have h : env57067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57066_57067 : H12AffineEnvironment.transform 2 3 env57066 = env57067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57066 == env57067) = true)

theorem identity57067 : scanCanonicalize (H12AffineFastState.compose env57067 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57067 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57068 : List Nat := [2,4,3,0,0,1,3,4,0,4,1,0,2,0,0,2,0,0,4,0,1,0,0,3,3,0,1,0,1,0,5,0,5,0,1,0]

theorem envBound57068 : H12AffineFastState.Bounded env57068 := by
  intro p hp
  have h : env57068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57067_57068 : H12AffineEnvironment.transform 6 3 env57067 = env57068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57067 == env57068) = true)

def env57069 : List Nat := [2,4,8,16,1,16,128,4,512,5,2048,2049,2698,2048,2570,2688,2185,528,5,2570,523,1,2586,2569,2563,2587,2194,2048,2185,2048,2694,137,5,2571,2184,512]

theorem envBound57069 : H12AffineFastState.Bounded env57069 := by
  intro p hp
  have h : env57069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57062_57069 : H12AffineEnvironment.transform 4 1 env57062 = env57069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57062 == env57069) = true)

theorem identity57069 : scanCanonicalize (H12AffineFastState.compose env57069 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57069 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57070 : List Nat := [2,4,8,0,1,0,128,4,512,5,2048,2049,2698,2048,2570,2688,2185,512,5,2570,523,1,2570,2569,2563,2571,2178,2048,2185,2048,2694,137,5,2571,2184,512]

theorem envBound57070 : H12AffineFastState.Bounded env57070 := by
  intro p hp
  have h : env57070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57069_57070 : H12AffineEnvironment.transform 3 0 env57069 = env57070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57069 == env57070) = true)

theorem identity57070 : scanCanonicalize (H12AffineFastState.compose env57070 (packedSelected [4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound57070 : packedSelected [4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57071 : List Nat := [2,4,8,0,1,0,128,4,512,5,648,649,2,648,130,8,513,512,5,130,523,1,130,129,139,131,522,648,513,648,14,137,5,131,512,512]

theorem envBound57071 : H12AffineFastState.Bounded env57071 := by
  intro p hp
  have h : env57071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57070_57071 : H12AffineEnvironment.transform 10 648 env57070 = env57071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57070 == env57071) = true)

theorem identity57071 : scanCanonicalize (H12AffineFastState.compose env57071 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57071 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57072 : List Nat := [2,4,8,0,1,0,128,4,136,5,0,1,2,0,130,8,137,136,5,130,131,1,130,129,139,131,130,0,137,0,14,137,5,131,136,136]

theorem envBound57072 : H12AffineFastState.Bounded env57072 := by
  intro p hp
  have h : env57072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57071_57072 : H12AffineEnvironment.transform 8 136 env57071 = env57072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57071 == env57072) = true)

theorem identity57072 : scanCanonicalize (H12AffineFastState.compose env57072 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57073 : List Nat := [2,4,2,0,1,0,128,4,130,5,0,1,2,0,130,2,131,130,5,130,131,1,130,129,129,131,130,0,131,0,4,131,5,131,130,130]

theorem envBound57073 : H12AffineFastState.Bounded env57073 := by
  intro p hp
  have h : env57073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57072_57073 : H12AffineEnvironment.transform 2 2 env57072 = env57073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57072 == env57073) = true)

def env57074 : List Nat := [2,4,8,16,32,64,128,5,512,84,2048,4096,2730,4177,2571,2688,4344,6673,84,2571,6746,32,2586,2681,2595,2635,4291,4177,4264,2080,2726,168,4,2650,4345,512]

theorem envBound57074 : H12AffineFastState.Bounded env57074 := by
  intro p hp
  have h : env57074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57052_57074 : H12AffineEnvironment.transform 7 5 env57052 = env57074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57052 == env57074) = true)

def env57075 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,4096,2730,4129,2571,2688,4232,6673,36,2571,6698,32,2586,2569,2595,2619,4275,4129,4264,2080,2726,168,4,2602,4233,512]

theorem envBound57075 : H12AffineFastState.Bounded env57075 := by
  intro p hp
  have h : env57075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57074_57075 : H12AffineEnvironment.transform 5 48 env57074 = env57075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57074 == env57075) = true)

theorem identity57075 : scanCanonicalize (H12AffineFastState.compose env57075 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57076 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,642,2730,675,2571,2688,522,2195,36,2571,2216,32,2586,2569,2595,2619,561,675,554,2080,2726,168,4,2602,523,512]

theorem envBound57076 : H12AffineFastState.Bounded env57076 := by
  intro p hp
  have h : env57076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57075_57076 : H12AffineEnvironment.transform 11 642 env57075 = env57076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57075 == env57076) = true)

def env57077 : List Nat := [2,4,8,0,32,32,128,5,512,36,2048,642,2730,675,2571,2688,522,2179,36,2571,2216,32,2570,2569,2595,2603,545,675,554,2080,2726,168,4,2602,523,512]

theorem envBound57077 : H12AffineFastState.Bounded env57077 := by
  intro p hp
  have h : env57077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57076_57077 : H12AffineEnvironment.transform 3 0 env57076 = env57077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57076 == env57077) = true)

theorem identity57077 : scanCanonicalize (H12AffineFastState.compose env57077 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound57077 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57078 : List Nat := [2,4,8,0,32,32,128,5,512,36,513,642,171,675,10,129,522,642,36,10,681,32,11,8,34,42,545,675,554,545,167,168,4,43,523,512]

theorem envBound57078 : H12AffineFastState.Bounded env57078 := by
  intro p hp
  have h : env57078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57077_57078 : H12AffineEnvironment.transform 10 513 env57077 = env57078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env57077 == env57078) = true)

theorem identity57078 : scanCanonicalize (H12AffineFastState.compose env57078 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57078 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57079 : List Nat := [2,4,8,0,32,32,8,5,512,36,513,522,35,555,10,9,522,522,36,10,545,32,11,8,34,42,545,555,554,545,47,32,4,43,523,512]

theorem envBound57079 : H12AffineFastState.Bounded env57079 := by
  intro p hp
  have h : env57079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57078_57079 : H12AffineEnvironment.transform 6 8 env57078 = env57079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57078 == env57079) = true)

theorem identity57079 : scanCanonicalize (H12AffineFastState.compose env57079 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57079 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57080 : List Nat := [2,4,3,0,32,32,3,5,512,36,513,513,35,544,1,2,513,513,36,1,545,32,0,3,34,33,545,544,545,545,36,32,4,32,512,512]

theorem envBound57080 : H12AffineFastState.Bounded env57080 := by
  intro p hp
  have h : env57080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57079_57080 : H12AffineEnvironment.transform 2 3 env57079 = env57080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57079 == env57080) = true)

theorem identity57080 : scanCanonicalize (H12AffineFastState.compose env57080 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57080 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57081 : List Nat := [2,4,3,0,32,32,3,5,1,36,0,0,35,33,1,2,0,0,36,1,32,32,0,3,34,33,32,33,32,32,36,32,4,32,1,1]

theorem envBound57081 : H12AffineFastState.Bounded env57081 := by
  intro p hp
  have h : env57081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57080_57081 : H12AffineEnvironment.transform 8 1 env57080 = env57081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57080 == env57081) = true)

theorem identity57081 : scanCanonicalize (H12AffineFastState.compose env57081 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57082 : List Nat := [2,4,3,0,0,0,3,5,1,4,0,0,3,1,1,2,0,0,4,1,0,0,0,3,2,1,0,1,0,0,4,0,4,0,1,1]

theorem envBound57082 : H12AffineFastState.Bounded env57082 := by
  intro p hp
  have h : env57082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57081_57082 : H12AffineEnvironment.transform 4 0 env57081 = env57082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57081 == env57082) = true)

def env57083 : List Nat := [2,4,8,1,32,33,128,5,512,36,2048,642,2730,675,2571,2688,522,2178,36,2571,2216,32,2571,2569,2595,2602,544,675,554,2080,2726,168,4,2602,523,512]

theorem envBound57083 : H12AffineFastState.Bounded env57083 := by
  intro p hp
  have h : env57083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57076_57083 : H12AffineEnvironment.transform 3 1 env57076 = env57083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57076 == env57083) = true)

theorem identity57083 : scanCanonicalize (H12AffineFastState.compose env57083 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57083 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57084 : List Nat := [2,4,2,1,32,33,128,5,512,36,2048,642,2720,675,2561,2688,512,2178,36,2561,2210,32,2561,2563,2595,2592,544,675,544,2080,2726,162,4,2592,513,512]

theorem envBound57084 : H12AffineFastState.Bounded env57084 := by
  intro p hp
  have h : env57084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57083_57084 : H12AffineEnvironment.transform 2 2 env57083 = env57084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57083 == env57084) = true)

def env57085 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,4096,2730,4128,2571,2688,4233,6673,37,2571,6699,32,2586,2568,2595,2618,4274,4128,4264,2080,2726,168,4,2603,4232,512]

theorem envBound57085 : H12AffineFastState.Bounded env57085 := by
  intro p hp
  have h : env57085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57074_57085 : H12AffineEnvironment.transform 5 49 env57074 = env57085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57074 == env57085) = true)

theorem identity57085 : scanCanonicalize (H12AffineFastState.compose env57085 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound57085 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57086 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,554,2730,522,2571,2688,675,2107,37,2571,2049,32,2586,2568,2595,2618,664,522,642,2080,2726,168,4,2603,674,512]

theorem envBound57086 : H12AffineFastState.Bounded env57086 := by
  intro p hp
  have h : env57086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57085_57086 : H12AffineEnvironment.transform 11 554 env57085 = env57086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env57085 == env57086) = true)

def env57087 : List Nat := [2,4,8,16,16,1,128,5,512,21,2048,538,2714,522,2571,2688,659,2059,21,2571,2049,16,2586,2568,2579,2570,664,522,642,2064,2710,152,4,2587,658,512]

theorem envBound57087 : H12AffineFastState.Bounded env57087 := by
  intro p hp
  have h : env57087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57086_57087 : H12AffineEnvironment.transform 4 16 env57086 = env57087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57086 == env57087) = true)

def env57088 : List Nat := [2,4,8,16,17,0,128,5,512,20,2048,539,2715,522,2571,2688,658,2058,20,2571,2049,17,2586,2568,2578,2571,664,522,642,2065,2711,153,4,2586,659,512]

theorem envBound57088 : H12AffineFastState.Bounded env57088 := by
  intro p hp
  have h : env57088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57086_57088 : H12AffineEnvironment.transform 4 17 env57086 = env57088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57086 == env57088) = true)

theorem identity57088 : scanCanonicalize (H12AffineFastState.compose env57088 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57088 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57089 : List Nat := [2,4,8,16,17,0,128,5,512,20,522,539,145,522,1,138,658,512,20,1,523,17,16,2,24,1,664,522,642,539,157,153,4,16,659,512]

theorem envBound57089 : H12AffineFastState.Bounded env57089 := by
  intro p hp
  have h : env57089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57088_57089 : H12AffineEnvironment.transform 10 522 env57088 = env57089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57088 == env57089) = true)

theorem identity57089 : scanCanonicalize (H12AffineFastState.compose env57089 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57089 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57090 : List Nat := [2,4,8,16,17,0,3,5,512,20,522,539,18,522,1,9,529,512,20,1,523,17,16,2,24,1,539,522,513,539,30,26,4,16,528,512]

theorem envBound57090 : H12AffineFastState.Bounded env57090 := by
  intro p hp
  have h : env57090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57089_57090 : H12AffineEnvironment.transform 6 3 env57089 = env57090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57089 == env57090) = true)

theorem identity57090 : scanCanonicalize (H12AffineFastState.compose env57090 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57090 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57091 : List Nat := [2,4,2,16,17,0,3,5,512,20,512,529,18,512,1,3,529,512,20,1,513,17,16,2,18,1,529,512,513,529,20,16,4,16,528,512]

theorem envBound57091 : H12AffineFastState.Bounded env57091 := by
  intro p hp
  have h : env57091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57090_57091 : H12AffineEnvironment.transform 2 2 env57090 = env57091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57090 == env57091) = true)

theorem identity57091 : scanCanonicalize (H12AffineFastState.compose env57091 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57091 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57092 : List Nat := [2,4,2,16,17,0,3,5,1,20,1,16,18,1,1,3,16,1,20,1,0,17,16,2,18,1,16,1,0,16,20,16,4,16,17,1]

theorem envBound57092 : H12AffineFastState.Bounded env57092 := by
  intro p hp
  have h : env57092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57091_57092 : H12AffineEnvironment.transform 8 1 env57091 = env57092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57091 == env57092) = true)

theorem identity57092 : scanCanonicalize (H12AffineFastState.compose env57092 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57093 : List Nat := [2,4,2,1,0,0,3,5,1,5,1,1,3,1,1,3,1,1,5,1,0,0,1,2,3,1,1,1,0,1,5,1,4,1,0,1]

theorem envBound57093 : H12AffineFastState.Bounded env57093 := by
  intro p hp
  have h : env57093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57092_57093 : H12AffineEnvironment.transform 3 1 env57092 = env57093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57092 == env57093) = true)

def env57094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295814,4247641,6348993,4273308,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256464]

theorem envBound57094 : H12AffineFastState.Bounded env57094 := by
  intro p hp
  have h : env57094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57028_57094 : H12AffineEnvironment.transform 17 82113 env57028 = env57094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57028 == env57094) = true)

def env57095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142598,28889,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57095 : H12AffineFastState.Bounded env57095 := by
  intro p hp
  have h : env57095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57094_57095 : H12AffineEnvironment.transform 21 41088 env57094 = env57095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57094 == env57095) = true)

theorem identity57095 : scanCanonicalize (H12AffineFastState.compose env57095 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24753) := by decide +kernel

theorem selectedBound57095 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24753,65536,78034,82113,1024,24753,2097152,16433,2101313,2117943,28889,2113601,95405,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57096 : H12AffineFastState.Bounded env57096 := by
  intro p hp
  have h : env57096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57095_57096 : H12AffineEnvironment.transform 14 24753 env57095 = env57096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24753 env57095 == env57096) = true)

theorem identity57096 : scanCanonicalize (H12AffineFastState.compose env57096 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57096 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5609,65536,78034,79257,1024,5609,2097152,13673,2101313,2106479,1409,2110745,66037,13656,77954,68866,2176390,74118,257,2168098,78035,9992]

theorem envBound57097 : H12AffineFastState.Bounded env57097 := by
  intro p hp
  have h : env57097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57096_57097 : H12AffineEnvironment.transform 13 13656 env57096 = env57097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57096 == env57097) = true)

theorem identity57097 : scanCanonicalize (H12AffineFastState.compose env57097 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57097 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5609,65536,78034,79257,1024,5609,71050,13673,67019,78309,1409,73875,66037,13656,77954,68866,8204,74118,257,168,78035,9992]

theorem envBound57098 : H12AffineFastState.Bounded env57098 := by
  intro p hp
  have h : env57098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57097_57098 : H12AffineEnvironment.transform 20 71050 env57097 = env57098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57097 == env57098) = true)

theorem identity57098 : scanCanonicalize (H12AffineFastState.compose env57098 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1419) := by decide +kernel

theorem selectedBound57098 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5609,1419,13657,12306,1024,5609,4097,13673,64,13422,1409,9496,1150,13656,13577,2185,8204,9229,257,168,13656,9992]

theorem envBound57099 : H12AffineFastState.Bounded env57099 := by
  intro p hp
  have h : env57099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57098_57099 : H12AffineEnvironment.transform 15 1419 env57098 = env57099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1419 env57098 == env57099) = true)

theorem identity57099 : scanCanonicalize (H12AffineFastState.compose env57099 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57099 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,1419,4176,5403,1024,5609,4097,4192,64,4455,1409,17,1150,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57100 : H12AffineFastState.Bounded env57100 := by
  intro p hp
  have h : env57100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57099_57100 : H12AffineEnvironment.transform 12 1289 env57099 = env57100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57099 == env57100) = true)

theorem identity57100 : scanCanonicalize (H12AffineFastState.compose env57100 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3815) := by decide +kernel

theorem selectedBound57100 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3815,1289,3766,2830,1419,3767,3068,1024,2830,3814,3719,64,3968,1409,17,1150,3766,3815,2185,1285,260,257,168,3766,513]

theorem envBound57101 : H12AffineFastState.Bounded env57101 := by
  intro p hp
  have h : env57101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57100_57101 : H12AffineEnvironment.transform 11 3815 env57100 = env57101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3815 env57100 == env57101) = true)

theorem identity57101 : scanCanonicalize (H12AffineFastState.compose env57101 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57101 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57102 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,2415,641,2366,2830,515,2367,3068,904,2830,2414,2319,64,2056,521,17,1014,2366,2415,2185,653,260,257,168,2366,513]

theorem envBound57102 : H12AffineFastState.Bounded env57102 := by
  intro p hp
  have h : env57102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57101_57102 : H12AffineEnvironment.transform 9 904 env57101 = env57102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57101 == env57102) = true)

theorem identity57102 : scanCanonicalize (H12AffineFastState.compose env57102 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1014) := by decide +kernel

theorem selectedBound57102 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57103 : List Nat := [2,4,8,16,32,64,128,256,512,904,1014,665,641,712,248,515,713,10,904,248,664,761,64,1022,521,17,1014,712,665,895,653,260,257,168,712,513]

theorem envBound57103 : H12AffineFastState.Bounded env57103 := by
  intro p hp
  have h : env57103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57102_57103 : H12AffineEnvironment.transform 10 1014 env57102 = env57103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1014 env57102 == env57103) = true)

theorem identity57103 : scanCanonicalize (H12AffineFastState.compose env57103 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57103 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57104 : List Nat := [2,4,8,16,32,64,128,256,373,253,131,492,500,445,248,374,444,10,253,248,493,396,64,139,380,17,131,445,492,10,504,260,257,168,445,372]

theorem envBound57104 : H12AffineFastState.Bounded env57104 := by
  intro p hp
  have h : env57104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57103_57104 : H12AffineEnvironment.transform 8 373 env57103 = env57104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57103 == env57104) = true)

theorem identity57104 : scanCanonicalize (H12AffineFastState.compose env57104 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57104 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57105 : List Nat := [2,4,8,16,32,64,128,78,59,253,131,162,186,243,248,56,242,10,253,248,163,194,64,139,50,17,131,243,162,10,182,74,79,168,243,58]

theorem envBound57105 : H12AffineFastState.Bounded env57105 := by
  intro p hp
  have h : env57105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57104_57105 : H12AffineEnvironment.transform 7 78 env57104 = env57105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57104 == env57105) = true)

theorem identity57105 : scanCanonicalize (H12AffineFastState.compose env57105 (packedSelected [0,2,3,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57105 : packedSelected [0,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env57106 : List Nat := [2,4,8,16,10,64,128,78,17,215,131,136,144,217,210,18,216,10,215,210,137,194,64,139,24,17,131,217,136,10,156,74,79,130,217,16]

theorem envBound57106 : H12AffineFastState.Bounded env57106 := by
  intro p hp
  have h : env57106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57105_57106 : H12AffineEnvironment.transform 4 10 env57105 = env57106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57105 == env57106) = true)

theorem identity57106 : scanCanonicalize (H12AffineFastState.compose env57106 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57106 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57107 : List Nat := [2,4,8,16,10,11,128,5,17,156,131,136,144,146,153,18,147,10,156,153,137,137,11,139,24,17,131,146,136,10,156,1,4,130,146,16]

theorem envBound57107 : H12AffineFastState.Bounded env57107 := by
  intro p hp
  have h : env57107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57106_57107 : H12AffineEnvironment.transform 5 11 env57106 = env57107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57106 == env57107) = true)

theorem identity57107 : scanCanonicalize (H12AffineFastState.compose env57107 (packedSelected [1,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57107 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env57108 : List Nat := [2,4,8,11,10,11,128,5,10,135,131,136,139,137,130,9,136,10,135,130,137,137,11,139,3,10,131,137,136,10,135,1,4,130,137,11]

theorem envBound57108 : H12AffineFastState.Bounded env57108 := by
  intro p hp
  have h : env57108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57107_57108 : H12AffineEnvironment.transform 3 11 env57107 = env57108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57107 == env57108) = true)

theorem identity57108 : scanCanonicalize (H12AffineFastState.compose env57108 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound57108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57109 : List Nat := [2,4,8,11,10,11,1,5,10,6,2,9,10,8,3,9,9,10,6,3,8,8,11,10,3,10,2,8,9,10,6,1,4,3,8,11]

theorem envBound57109 : H12AffineFastState.Bounded env57109 := by
  intro p hp
  have h : env57109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57108_57109 : H12AffineEnvironment.transform 6 1 env57108 = env57109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env57108 == env57109) = true)

theorem identity57109 : scanCanonicalize (H12AffineFastState.compose env57109 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57109 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57110 : List Nat := [2,4,1,2,3,2,1,5,3,6,2,0,3,1,3,0,0,3,6,3,1,1,2,3,3,3,2,1,0,3,6,1,4,3,1,2]

theorem envBound57110 : H12AffineFastState.Bounded env57110 := by
  intro p hp
  have h : env57110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57109_57110 : H12AffineEnvironment.transform 2 1 env57109 = env57110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57109 == env57110) = true)

theorem identity57110 : scanCanonicalize (H12AffineFastState.compose env57110 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57111 : List Nat := [1,4,1,1,0,1,1,5,0,5,1,0,0,1,0,0,0,0,5,0,1,1,1,0,0,0,1,1,0,0,5,1,4,0,1,1]

theorem envBound57111 : H12AffineFastState.Bounded env57111 := by
  intro p hp
  have h : env57111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57110_57111 : H12AffineEnvironment.transform 0 1 env57110 = env57111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57110 == env57111) = true)

def env57112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142599,28888,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57112 : H12AffineFastState.Bounded env57112 := by
  intro p hp
  have h : env57112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57094_57112 : H12AffineEnvironment.transform 21 41089 env57094 = env57112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57094 == env57112) = true)

theorem identity57112 : scanCanonicalize (H12AffineFastState.compose env57112 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound57112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9713,65536,78034,82113,1024,9713,2097152,1392,2101312,2102390,28888,2113600,78316,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57113 : H12AffineFastState.Bounded env57113 := by
  intro p hp
  have h : env57113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57112_57113 : H12AffineEnvironment.transform 14 9713 env57112 = env57113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env57112 == env57113) = true)

theorem identity57113 : scanCanonicalize (H12AffineFastState.compose env57113 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57113 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9713,65536,78034,82113,1024,9713,83418,1392,87450,86444,28888,66970,78316,16384,77954,96347,28765,74119,257,9633,78035,21073]

theorem envBound57114 : H12AffineFastState.Bounded env57114 := by
  intro p hp
  have h : env57114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57113_57114 : H12AffineEnvironment.transform 20 83418 env57113 = env57114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57113 == env57114) = true)

theorem identity57114 : scanCanonicalize (H12AffineFastState.compose env57114 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57114 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,65536,78034,69776,1024,9713,71051,1392,67019,66045,8329,66970,78316,4177,77954,75786,8204,74119,257,9633,78035,512]

theorem envBound57115 : H12AffineFastState.Bounded env57115 := by
  intro p hp
  have h : env57115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57114_57115 : H12AffineEnvironment.transform 13 4177 env57114 = env57115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57114 == env57115) = true)

theorem identity57115 : scanCanonicalize (H12AffineFastState.compose env57115 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9343) := by decide +kernel

theorem selectedBound57115 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,9343,5293,13551,1024,9713,12788,1392,8628,9602,8329,8677,5523,4177,5373,3189,8204,1528,257,9633,5292,512]

theorem envBound57116 : H12AffineFastState.Bounded env57116 := by
  intro p hp
  have h : env57116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57115_57116 : H12AffineEnvironment.transform 15 9343 env57115 = env57116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9343 env57115 == env57116) = true)

theorem identity57116 : scanCanonicalize (H12AffineFastState.compose env57116 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound57116 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,2830,2688,5293,6672,1024,2830,7947,1392,3915,2941,3702,3866,5523,4177,5373,3189,3827,1528,257,2910,5292,512]

theorem envBound57117 : H12AffineFastState.Bounded env57117 := by
  intro p hp
  have h : env57117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57116_57117 : H12AffineEnvironment.transform 12 3839 env57116 = env57117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env57116 == env57117) = true)

theorem identity57117 : scanCanonicalize (H12AffineFastState.compose env57117 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound57117 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57118 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,4096,2991,4177,2830,2688,4605,6672,336,2830,6747,32,2587,2941,2854,2634,4291,4177,4525,2341,2979,168,257,2910,4604,512]

theorem envBound57118 : H12AffineFastState.Bounded env57118 := by
  intro p hp
  have h : env57118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57117_57118 : H12AffineEnvironment.transform 9 336 env57117 = env57118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env57117 == env57118) = true)

def env57119 : List Nat := [2,4,8,16,32,64,128,4,512,84,2048,4096,2731,4177,2570,2688,4345,6672,84,2570,6747,32,2587,2681,2594,2634,4291,4177,4265,2081,2727,168,5,2650,4344,512]

theorem envBound57119 : H12AffineFastState.Bounded env57119 := by
  intro p hp
  have h : env57119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57118_57119 : H12AffineEnvironment.transform 7 4 env57118 = env57119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57118 == env57119) = true)

def env57120 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,4096,2731,4129,2570,2688,4233,6672,36,2570,6699,32,2587,2569,2594,2618,4275,4129,4265,2081,2727,168,5,2602,4232,512]

theorem envBound57120 : H12AffineFastState.Bounded env57120 := by
  intro p hp
  have h : env57120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57119_57120 : H12AffineEnvironment.transform 5 48 env57119 = env57120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57119 == env57120) = true)

theorem identity57120 : scanCanonicalize (H12AffineFastState.compose env57120 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound57120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57121 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,554,2731,523,2570,2688,675,2106,36,2570,2049,32,2587,2569,2594,2618,665,523,643,2081,2727,168,5,2602,674,512]

theorem envBound57121 : H12AffineFastState.Bounded env57121 := by
  intro p hp
  have h : env57121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57120_57121 : H12AffineEnvironment.transform 11 554 env57120 = env57121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env57120 == env57121) = true)

def env57122 : List Nat := [2,4,8,16,16,0,128,4,512,20,2048,538,2715,523,2570,2688,659,2058,20,2570,2049,16,2587,2569,2578,2570,665,523,643,2065,2711,152,5,2586,658,512]

theorem envBound57122 : H12AffineFastState.Bounded env57122 := by
  intro p hp
  have h : env57122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57121_57122 : H12AffineEnvironment.transform 4 16 env57121 = env57122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57121 == env57122) = true)

def env57123 : List Nat := [2,4,8,16,17,1,128,4,512,21,2048,539,2714,523,2570,2688,658,2059,21,2570,2049,17,2587,2569,2579,2571,665,523,643,2064,2710,153,5,2587,659,512]

theorem envBound57123 : H12AffineFastState.Bounded env57123 := by
  intro p hp
  have h : env57123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57121_57123 : H12AffineEnvironment.transform 4 17 env57121 = env57123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57121 == env57123) = true)

theorem identity57123 : scanCanonicalize (H12AffineFastState.compose env57123 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound57123 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57124 : List Nat := [2,4,8,16,17,1,128,4,512,21,523,539,145,523,1,139,658,512,21,1,522,17,16,2,24,0,665,523,643,539,157,153,5,16,659,512]

theorem envBound57124 : H12AffineFastState.Bounded env57124 := by
  intro p hp
  have h : env57124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57123_57124 : H12AffineEnvironment.transform 10 523 env57123 = env57124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env57123 == env57124) = true)

theorem identity57124 : scanCanonicalize (H12AffineFastState.compose env57124 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57124 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57125 : List Nat := [2,4,8,16,17,1,2,4,512,21,523,539,19,523,1,9,528,512,21,1,522,17,16,2,24,0,539,523,513,539,31,27,5,16,529,512]

theorem envBound57125 : H12AffineFastState.Bounded env57125 := by
  intro p hp
  have h : env57125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57124_57125 : H12AffineEnvironment.transform 6 2 env57124 = env57125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57124 == env57125) = true)

theorem identity57125 : scanCanonicalize (H12AffineFastState.compose env57125 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57125 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57126 : List Nat := [2,4,3,16,17,1,2,4,512,21,512,528,19,512,1,2,528,512,21,1,513,17,16,2,19,0,528,512,513,528,20,16,5,16,529,512]

theorem envBound57126 : H12AffineFastState.Bounded env57126 := by
  intro p hp
  have h : env57126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57125_57126 : H12AffineEnvironment.transform 2 3 env57125 = env57126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57125 == env57126) = true)

theorem identity57126 : scanCanonicalize (H12AffineFastState.compose env57126 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57126 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57127 : List Nat := [2,4,3,16,17,1,2,4,1,21,1,17,19,1,1,2,17,1,21,1,0,17,16,2,19,0,17,1,0,17,20,16,5,16,16,1]

theorem envBound57127 : H12AffineFastState.Bounded env57127 := by
  intro p hp
  have h : env57127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57126_57127 : H12AffineEnvironment.transform 8 1 env57126 = env57127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57126 == env57127) = true)

theorem identity57127 : scanCanonicalize (H12AffineFastState.compose env57127 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57128 : List Nat := [2,4,3,0,1,1,2,4,1,5,1,1,3,1,1,2,1,1,5,1,0,1,0,2,3,0,1,1,0,1,4,0,5,0,0,1]

theorem envBound57128 : H12AffineFastState.Bounded env57128 := by
  intro p hp
  have h : env57128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57127_57128 : H12AffineEnvironment.transform 3 0 env57127 = env57128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57127 == env57128) = true)

def env57129 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,4096,2731,4128,2570,2688,4232,6672,37,2570,6698,32,2587,2568,2594,2619,4274,4128,4265,2081,2727,168,5,2603,4233,512]

theorem envBound57129 : H12AffineFastState.Bounded env57129 := by
  intro p hp
  have h : env57129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57119_57129 : H12AffineEnvironment.transform 5 49 env57119 = env57129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57119 == env57129) = true)

theorem identity57129 : scanCanonicalize (H12AffineFastState.compose env57129 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57129 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57130 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,643,2731,675,2570,2688,523,2195,37,2570,2217,32,2587,2568,2594,2619,561,675,554,2081,2727,168,5,2603,522,512]

theorem envBound57130 : H12AffineFastState.Bounded env57130 := by
  intro p hp
  have h : env57130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57129_57130 : H12AffineEnvironment.transform 11 643 env57129 = env57130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57129 == env57130) = true)

def env57131 : List Nat := [2,4,8,0,32,33,128,4,512,37,2048,643,2731,675,2570,2688,523,2179,37,2570,2217,32,2571,2568,2594,2603,545,675,554,2081,2727,168,5,2603,522,512]

theorem envBound57131 : H12AffineFastState.Bounded env57131 := by
  intro p hp
  have h : env57131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57130_57131 : H12AffineEnvironment.transform 3 0 env57130 = env57131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57130 == env57131) = true)

theorem identity57131 : scanCanonicalize (H12AffineFastState.compose env57131 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57131 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57132 : List Nat := [2,4,3,0,32,33,128,4,512,37,2048,643,2720,675,2561,2688,512,2179,37,2561,2210,32,2560,2563,2594,2592,545,675,545,2081,2727,163,5,2592,513,512]

theorem envBound57132 : H12AffineFastState.Bounded env57132 := by
  intro p hp
  have h : env57132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57131_57132 : H12AffineEnvironment.transform 2 3 env57131 = env57132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57131 == env57132) = true)

def env57133 : List Nat := [2,4,8,1,32,32,128,4,512,37,2048,643,2731,675,2570,2688,523,2178,37,2570,2217,32,2570,2568,2594,2602,544,675,554,2081,2727,168,5,2603,522,512]

theorem envBound57133 : H12AffineFastState.Bounded env57133 := by
  intro p hp
  have h : env57133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57130_57133 : H12AffineEnvironment.transform 3 1 env57130 = env57133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57130 == env57133) = true)

theorem identity57133 : scanCanonicalize (H12AffineFastState.compose env57133 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound57133 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57134 : List Nat := [2,4,8,1,32,32,128,4,512,37,513,643,170,675,11,129,523,643,37,11,680,32,11,9,35,43,544,675,554,544,166,168,5,42,522,512]

theorem envBound57134 : H12AffineFastState.Bounded env57134 := by
  intro p hp
  have h : env57134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57133_57134 : H12AffineEnvironment.transform 10 513 env57133 = env57134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env57133 == env57134) = true)

theorem identity57134 : scanCanonicalize (H12AffineFastState.compose env57134 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57134 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57135 : List Nat := [2,4,8,1,32,32,8,4,512,37,513,523,34,555,11,9,523,523,37,11,544,32,11,9,35,43,544,555,554,544,46,32,5,42,522,512]

theorem envBound57135 : H12AffineFastState.Bounded env57135 := by
  intro p hp
  have h : env57135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57134_57135 : H12AffineEnvironment.transform 6 8 env57134 = env57135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57134 == env57135) = true)

theorem identity57135 : scanCanonicalize (H12AffineFastState.compose env57135 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57135 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57136 : List Nat := [2,4,2,1,32,32,2,4,512,37,513,513,34,545,1,3,513,513,37,1,544,32,1,3,35,33,544,545,544,544,36,32,5,32,512,512]

theorem envBound57136 : H12AffineFastState.Bounded env57136 := by
  intro p hp
  have h : env57136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57135_57136 : H12AffineEnvironment.transform 2 2 env57135 = env57136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57135 == env57136) = true)

theorem identity57136 : scanCanonicalize (H12AffineFastState.compose env57136 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57136 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57137 : List Nat := [2,4,2,1,32,32,2,4,1,37,0,0,34,32,1,3,0,0,37,1,33,32,1,3,35,33,33,32,33,33,36,32,5,32,1,1]

theorem envBound57137 : H12AffineFastState.Bounded env57137 := by
  intro p hp
  have h : env57137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57136_57137 : H12AffineEnvironment.transform 8 1 env57136 = env57137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57136 == env57137) = true)

theorem identity57137 : scanCanonicalize (H12AffineFastState.compose env57137 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57138 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,0,3,1,1,3,0,0,4,1,0,1,1,3,2,0,0,1,0,0,5,1,5,1,1,1]

theorem envBound57138 : H12AffineFastState.Bounded env57138 := by
  intro p hp
  have h : env57138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57137_57138 : H12AffineEnvironment.transform 4 1 env57137 = env57138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57137 == env57138) = true)

def env57139 : List Nat := [2,4,8,16,32,64,128,5,512,85,2048,4096,2730,4177,2571,2688,4344,6672,85,2571,6747,32,2587,2680,2595,2634,4291,4177,4264,2080,2726,168,4,2651,4345,512]

theorem envBound57139 : H12AffineFastState.Bounded env57139 := by
  intro p hp
  have h : env57139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57118_57139 : H12AffineEnvironment.transform 7 5 env57118 = env57139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57118 == env57139) = true)

def env57140 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,4096,2730,4129,2571,2688,4232,6672,37,2571,6699,32,2587,2568,2595,2618,4275,4129,4264,2080,2726,168,4,2603,4233,512]

theorem envBound57140 : H12AffineFastState.Bounded env57140 := by
  intro p hp
  have h : env57140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57139_57140 : H12AffineEnvironment.transform 5 48 env57139 = env57140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57139 == env57140) = true)

theorem identity57140 : scanCanonicalize (H12AffineFastState.compose env57140 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound57140 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57141 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,2049,2730,2080,2571,2688,2185,529,37,2571,554,32,2587,2568,2595,2618,2226,2080,2217,2080,2726,168,4,2603,2184,512]

theorem envBound57141 : H12AffineFastState.Bounded env57141 := by
  intro p hp
  have h : env57141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57140_57141 : H12AffineEnvironment.transform 11 2049 env57140 = env57141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env57140 == env57141) = true)

def env57142 : List Nat := [2,4,8,16,0,16,128,5,512,5,2048,2049,2698,2048,2571,2688,2185,529,5,2571,522,0,2587,2568,2563,2586,2194,2048,2185,2048,2694,136,4,2571,2184,512]

theorem envBound57142 : H12AffineFastState.Bounded env57142 := by
  intro p hp
  have h : env57142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57141_57142 : H12AffineEnvironment.transform 4 0 env57141 = env57142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57141 == env57142) = true)

theorem identity57142 : scanCanonicalize (H12AffineFastState.compose env57142 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57142 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57143 : List Nat := [2,4,8,1,0,1,128,5,512,5,2048,2049,2698,2048,2571,2688,2185,512,5,2571,522,0,2570,2568,2563,2571,2179,2048,2185,2048,2694,136,4,2571,2184,512]

theorem envBound57143 : H12AffineFastState.Bounded env57143 := by
  intro p hp
  have h : env57143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57142_57143 : H12AffineEnvironment.transform 3 1 env57142 = env57143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57142 == env57143) = true)

theorem identity57143 : scanCanonicalize (H12AffineFastState.compose env57143 (packedSelected [4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound57143 : packedSelected [4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57144 : List Nat := [2,4,8,1,0,1,128,5,512,5,648,649,2,648,131,8,513,512,5,131,522,0,130,128,139,131,523,648,513,648,14,136,4,131,512,512]

theorem envBound57144 : H12AffineFastState.Bounded env57144 := by
  intro p hp
  have h : env57144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57143_57144 : H12AffineEnvironment.transform 10 648 env57143 = env57144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57143 == env57144) = true)

theorem identity57144 : scanCanonicalize (H12AffineFastState.compose env57144 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57144 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57145 : List Nat := [2,4,8,1,0,1,128,5,136,5,0,1,2,0,131,8,137,136,5,131,130,0,130,128,139,131,131,0,137,0,14,136,4,131,136,136]

theorem envBound57145 : H12AffineFastState.Bounded env57145 := by
  intro p hp
  have h : env57145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57144_57145 : H12AffineEnvironment.transform 8 136 env57144 = env57145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57144 == env57145) = true)

theorem identity57145 : scanCanonicalize (H12AffineFastState.compose env57145 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57146 : List Nat := [2,4,3,1,0,1,128,5,131,5,0,1,2,0,131,3,130,131,5,131,130,0,130,128,128,131,131,0,130,0,5,131,4,131,131,131]

theorem envBound57146 : H12AffineFastState.Bounded env57146 := by
  intro p hp
  have h : env57146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57145_57146 : H12AffineEnvironment.transform 2 3 env57145 = env57146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57145 == env57146) = true)

def env57147 : List Nat := [2,4,8,16,1,17,128,5,512,4,2048,2049,2699,2049,2571,2688,2185,529,4,2571,523,1,2587,2568,2562,2587,2195,2049,2184,2049,2695,137,4,2570,2184,512]

theorem envBound57147 : H12AffineFastState.Bounded env57147 := by
  intro p hp
  have h : env57147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57141_57147 : H12AffineEnvironment.transform 4 1 env57141 = env57147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57141 == env57147) = true)

theorem identity57147 : scanCanonicalize (H12AffineFastState.compose env57147 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57147 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57148 : List Nat := [2,4,8,11,1,10,128,5,512,4,2048,2049,2699,2049,2571,2688,2185,522,4,2571,523,1,2560,2568,2562,2560,2184,2049,2184,2049,2695,137,4,2570,2184,512]

theorem envBound57148 : H12AffineFastState.Bounded env57148 := by
  intro p hp
  have h : env57148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57147_57148 : H12AffineEnvironment.transform 3 11 env57147 = env57148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57147 == env57148) = true)

theorem identity57148 : scanCanonicalize (H12AffineFastState.compose env57148 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57148 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57149 : List Nat := [2,4,8,11,1,10,128,5,512,4,1,0,650,0,522,641,136,522,4,522,523,1,513,521,515,513,137,0,137,0,646,137,4,523,137,512]

theorem envBound57149 : H12AffineFastState.Bounded env57149 := by
  intro p hp
  have h : env57149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57148_57149 : H12AffineEnvironment.transform 10 1 env57148 = env57149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57148 == env57149) = true)

theorem identity57149 : scanCanonicalize (H12AffineFastState.compose env57149 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57149 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57150 : List Nat := [2,4,8,11,1,10,128,5,136,4,1,0,2,0,130,9,136,130,4,130,131,1,137,129,139,137,137,0,137,0,14,137,4,131,137,136]

theorem envBound57150 : H12AffineFastState.Bounded env57150 := by
  intro p hp
  have h : env57150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57149_57150 : H12AffineEnvironment.transform 8 136 env57149 = env57150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57149 == env57150) = true)

theorem identity57150 : scanCanonicalize (H12AffineFastState.compose env57150 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57151 : List Nat := [2,4,2,1,1,0,128,5,130,4,1,0,2,0,130,3,130,130,4,130,131,1,131,129,129,131,131,0,131,0,4,131,4,131,131,130]

theorem envBound57151 : H12AffineFastState.Bounded env57151 := by
  intro p hp
  have h : env57151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57150_57151 : H12AffineEnvironment.transform 2 2 env57150 = env57151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57150 == env57151) = true)

theorem identity57151 : scanCanonicalize (H12AffineFastState.compose env57151 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57151 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57152 : List Nat := [2,4,2,1,1,0,2,5,0,4,1,0,2,0,0,3,0,0,4,0,1,1,1,3,3,1,1,0,1,0,4,1,4,1,1,0]

theorem envBound57152 : H12AffineFastState.Bounded env57152 := by
  intro p hp
  have h : env57152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57151_57152 : H12AffineEnvironment.transform 6 2 env57151 = env57152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57151 == env57152) = true)

def env57153 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,4096,2730,4128,2571,2688,4233,6672,36,2571,6698,32,2587,2569,2595,2619,4274,4128,4264,2080,2726,168,4,2602,4232,512]

theorem envBound57153 : H12AffineFastState.Bounded env57153 := by
  intro p hp
  have h : env57153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57139_57153 : H12AffineEnvironment.transform 5 49 env57139 = env57153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57139 == env57153) = true)

theorem identity57153 : scanCanonicalize (H12AffineFastState.compose env57153 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound57153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57154 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,2216,2730,2184,2571,2688,2081,696,36,2571,642,32,2587,2569,2595,2619,2074,2184,2048,2080,2726,168,4,2602,2080,512]

theorem envBound57154 : H12AffineFastState.Bounded env57154 := by
  intro p hp
  have h : env57154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57153_57154 : H12AffineEnvironment.transform 11 2216 env57153 = env57154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env57153 == env57154) = true)

def env57155 : List Nat := [2,4,8,16,32,49,128,5,512,36,648,544,34,512,131,8,681,696,36,131,642,32,147,129,171,179,658,512,648,680,46,168,4,162,680,512]

theorem envBound57155 : H12AffineFastState.Bounded env57155 := by
  intro p hp
  have h : env57155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57154_57155 : H12AffineEnvironment.transform 10 648 env57154 = env57155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57154 == env57155) = true)

theorem identity57155 : scanCanonicalize (H12AffineFastState.compose env57155 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57155 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57156 : List Nat := [2,4,8,16,32,49,50,5,512,36,570,544,34,512,49,8,539,522,36,49,560,32,33,51,25,1,544,512,570,538,46,26,4,16,538,512]

theorem envBound57156 : H12AffineFastState.Bounded env57156 := by
  intro p hp
  have h : env57156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57155_57156 : H12AffineEnvironment.transform 6 50 env57155 = env57156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57155 == env57156) = true)

theorem identity57156 : scanCanonicalize (H12AffineFastState.compose env57156 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57156 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57157 : List Nat := [2,4,3,16,32,49,50,5,512,36,561,544,34,512,49,3,528,513,36,49,560,32,33,51,18,1,544,512,561,529,37,17,4,16,529,512]

theorem envBound57157 : H12AffineFastState.Bounded env57157 := by
  intro p hp
  have h : env57157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57156_57157 : H12AffineEnvironment.transform 2 3 env57156 = env57157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57156 == env57157) = true)

def env57158 : List Nat := [2,4,8,16,32,49,128,5,512,36,649,545,35,513,130,9,680,696,36,130,642,32,146,128,170,178,659,513,649,681,47,168,4,163,681,512]

theorem envBound57158 : H12AffineFastState.Bounded env57158 := by
  intro p hp
  have h : env57158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57154_57158 : H12AffineEnvironment.transform 10 649 env57154 = env57158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57154 == env57158) = true)

theorem identity57158 : scanCanonicalize (H12AffineFastState.compose env57158 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57158 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57159 : List Nat := [2,4,8,16,32,49,56,5,512,36,561,545,35,513,58,9,528,512,36,58,570,32,42,56,18,10,555,513,561,529,47,16,4,27,529,512]

theorem envBound57159 : H12AffineFastState.Bounded env57159 := by
  intro p hp
  have h : env57159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57158_57159 : H12AffineEnvironment.transform 6 56 env57158 = env57159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57158 == env57159) = true)

def env57160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409088,10798237,16384,77954,4315354,8463815,10564039,257,6406394,78035,33563273]

theorem envBound57160 : H12AffineFastState.Bounded env57160 := by
  intro p hp
  have h : env57160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56719_57160 : H12AffineEnvironment.transform 26 10798237 env56719 = env57160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10798237 env56719 == env57160) = true)

def env57161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,4247640,8409088,10798237,16384,77954,4315354,8463815,10564039,257,6406394,78035,4256465]

theorem envBound57161 : H12AffineFastState.Bounded env57161 := by
  intro p hp
  have h : env57161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57160_57161 : H12AffineEnvironment.transform 24 4247640 env57160 = env57161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env57160 == env57161) = true)

def env57162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4486237,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound57162 : H12AffineFastState.Bounded env57162 := by
  intro p hp
  have h : env57162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57161_57162 : H12AffineEnvironment.transform 22 6336704 env57161 = env57162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env57161 == env57162) = true)

def env57163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4273309,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound57163 : H12AffineFastState.Bounded env57163 := by
  intro p hp
  have h : env57163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57162_57163 : H12AffineEnvironment.transform 17 82112 env57162 = env57163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57162 == env57163) = true)

def env57164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142599,28888,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57164 : H12AffineFastState.Bounded env57164 := by
  intro p hp
  have h : env57164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57163_57164 : H12AffineEnvironment.transform 21 41088 env57163 = env57164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57163 == env57164) = true)

theorem identity57164 : scanCanonicalize (H12AffineFastState.compose env57164 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 91182) := by decide +kernel

theorem selectedBound57164 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,91182,41088,95342,120233,28888,74862,103453,16384,77954,96346,20905,74119,257,1108,78035,21073]

theorem envBound57165 : H12AffineFastState.Bounded env57165 := by
  intro p hp
  have h : env57165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57164_57165 : H12AffineEnvironment.transform 20 91182 env57164 = env57165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91182 env57164 == env57165) = true)

theorem identity57165 : scanCanonicalize (H12AffineFastState.compose env57165 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 12709) := by decide +kernel

theorem selectedBound57165 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78181,1024,32768,71051,41088,67019,107532,381,74862,103453,12709,77954,68095,8204,74119,257,1108,78035,9204]

theorem envBound57166 : H12AffineFastState.Bounded env57166 := by
  intro p hp
  have h : env57166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57165_57166 : H12AffineEnvironment.transform 13 12709 env57165 = env57166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12709 env57165 == env57166) = true)

theorem identity57166 : scanCanonicalize (H12AffineFastState.compose env57166 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 41082) := by decide +kernel

theorem selectedBound57166 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,41082,37032,37151,1024,32768,46577,41088,42417,1142,381,33812,13415,12709,37112,43397,8204,33277,257,1108,37033,9204]

theorem envBound57167 : H12AffineFastState.Bounded env57167 := by
  intro p hp
  have h : env57167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57166_57167 : H12AffineEnvironment.transform 15 41082 env57166 = env57167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41082 env57166 == env57167) = true)

theorem identity57167 : scanCanonicalize (H12AffineFastState.compose env57167 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound57167 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,4177,32768,33166,37032,37151,1024,32768,37893,33140,33861,1142,381,33812,5523,4177,37112,34929,504,33277,257,1108,37033,512]

theorem envBound57168 : H12AffineFastState.Bounded env57168 := by
  intro p hp
  have h : env57168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57167_57168 : H12AffineEnvironment.transform 12 500 env57167 = env57168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env57167 == env57168) = true)

theorem identity57168 : scanCanonicalize (H12AffineFastState.compose env57168 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57168 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,500,4177,32768,33166,37032,37151,1024,32768,37893,33140,33861,1142,381,33812,5523,4177,37112,34682,504,33277,257,1108,37033,512]

theorem envBound57169 : H12AffineFastState.Bounded env57169 := by
  intro p hp
  have h : env57169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57168_57169 : H12AffineEnvironment.transform 10 1803 env57168 = env57169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57168 == env57169) = true)

theorem identity57169 : scanCanonicalize (H12AffineFastState.compose env57169 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound57169 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,500,4177,340,218,4604,4171,1024,340,5457,32,1297,1142,381,1344,5523,4177,4524,1582,504,169,257,1108,4605,512]

theorem envBound57170 : H12AffineFastState.Bounded env57170 := by
  intro p hp
  have h : env57170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57169_57170 : H12AffineEnvironment.transform 14 340 env57169 = env57170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env57169 == env57170) = true)

def env57171 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,4096,300,4177,340,2,4388,4171,1024,340,5457,32,1297,1142,381,1344,5451,4177,4468,1582,288,113,257,1108,4389,512]

theorem envBound57171 : H12AffineFastState.Bounded env57171 := by
  intro p hp
  have h : env57171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57170_57171 : H12AffineEnvironment.transform 6 88 env57170 = env57171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57170 == env57171) = true)

def env57172 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,0,300,81,340,2,292,75,1024,340,1361,32,1297,1142,381,1344,1355,81,372,1582,288,113,257,1108,293,512]

theorem envBound57172 : H12AffineFastState.Bounded env57172 := by
  intro p hp
  have h : env57172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57171_57172 : H12AffineEnvironment.transform 11 0 env57171 = env57172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57171 == env57172) = true)

theorem identity57172 : scanCanonicalize (H12AffineFastState.compose env57172 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57173 : List Nat := [2,4,8,16,32,64,88,21,512,1024,1566,0,57,81,65,2,49,75,1024,65,1092,32,1028,1142,104,1109,1118,81,97,1582,53,113,20,1108,48,512]

theorem envBound57173 : H12AffineFastState.Bounded env57173 := by
  intro p hp
  have h : env57173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57172_57173 : H12AffineEnvironment.transform 7 21 env57172 = env57173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57172 == env57173) = true)

theorem identity57173 : scanCanonicalize (H12AffineFastState.compose env57173 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 639) := by decide +kernel

theorem selectedBound57173 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57174 : List Nat := [2,4,8,16,32,64,88,21,512,639,97,0,57,81,65,2,49,75,639,65,571,32,635,521,104,554,545,81,97,81,53,113,20,555,48,512]

theorem envBound57174 : H12AffineFastState.Bounded env57174 := by
  intro p hp
  have h : env57174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57173_57174 : H12AffineEnvironment.transform 9 639 env57173 = env57174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 639 env57173 == env57174) = true)

theorem identity57174 : scanCanonicalize (H12AffineFastState.compose env57174 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound57174 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57175 : List Nat := [2,4,8,16,32,64,88,21,91,36,97,0,57,81,65,2,49,75,36,65,96,32,32,82,104,113,122,81,97,81,53,113,20,112,48,91]

theorem envBound57175 : H12AffineFastState.Bounded env57175 := by
  intro p hp
  have h : env57175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57174_57175 : H12AffineEnvironment.transform 8 91 env57174 = env57175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env57174 == env57175) = true)

theorem identity57175 : scanCanonicalize (H12AffineFastState.compose env57175 (packedSelected [0,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound57175 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57176 : List Nat := [2,4,8,16,32,58,34,21,33,36,27,0,57,43,59,2,49,49,36,59,26,32,32,40,18,11,0,43,27,43,53,11,20,10,48,33]

theorem envBound57176 : H12AffineFastState.Bounded env57176 := by
  intro p hp
  have h : env57176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57175_57176 : H12AffineEnvironment.transform 5 58 env57175 = env57176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env57175 == env57176) = true)

def env57177 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,1,300,80,340,2,293,74,1024,340,1360,32,1297,1142,381,1344,1354,80,373,1582,288,113,257,1108,292,512]

theorem envBound57177 : H12AffineFastState.Bounded env57177 := by
  intro p hp
  have h : env57177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57171_57177 : H12AffineEnvironment.transform 11 1 env57171 = env57177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57171 == env57177) = true)

theorem identity57177 : scanCanonicalize (H12AffineFastState.compose env57177 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound57177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57178 : List Nat := [2,4,8,16,32,64,88,256,512,517,270,1,300,80,340,2,293,74,517,340,853,32,788,627,381,837,847,80,373,43,288,113,257,593,292,512]

theorem envBound57178 : H12AffineFastState.Bounded env57178 := by
  intro p hp
  have h : env57178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57177_57178 : H12AffineEnvironment.transform 9 517 env57177 = env57178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env57177 == env57178) = true)

theorem identity57178 : scanCanonicalize (H12AffineFastState.compose env57178 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound57178 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57179 : List Nat := [2,4,8,16,32,64,88,256,90,95,270,1,300,80,340,2,293,74,95,340,271,32,334,41,381,287,277,80,373,43,288,113,257,11,292,90]

theorem envBound57179 : H12AffineFastState.Bounded env57179 := by
  intro p hp
  have h : env57179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57178_57179 : H12AffineEnvironment.transform 8 90 env57178 = env57179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env57178 == env57179) = true)

theorem identity57179 : scanCanonicalize (H12AffineFastState.compose env57179 (packedSelected [4,7,13] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57179 : packedSelected [4,7,13] rootPS < 2^1333 := by decide +kernel

def env57180 : List Nat := [2,4,8,16,32,11,19,256,17,20,270,1,300,27,287,2,293,1,20,287,271,32,261,41,310,287,277,27,318,43,288,58,257,11,292,17]

theorem envBound57180 : H12AffineFastState.Bounded env57180 := by
  intro p hp
  have h : env57180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57179_57180 : H12AffineEnvironment.transform 5 11 env57179 = env57180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57179 == env57180) = true)

def env57181 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,4096,301,4177,340,3,4389,4171,1024,340,5457,32,1297,1142,381,1344,5450,4177,4469,1582,289,112,257,1108,4388,512]

theorem envBound57181 : H12AffineFastState.Bounded env57181 := by
  intro p hp
  have h : env57181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57170_57181 : H12AffineEnvironment.transform 6 89 env57170 = env57181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57170 == env57181) = true)

def env57182 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,0,301,81,340,3,293,75,1024,340,1361,32,1297,1142,381,1344,1354,81,373,1582,289,112,257,1108,292,512]

theorem envBound57182 : H12AffineFastState.Bounded env57182 := by
  intro p hp
  have h : env57182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57181_57182 : H12AffineEnvironment.transform 11 0 env57181 = env57182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57181 == env57182) = true)

theorem identity57182 : scanCanonicalize (H12AffineFastState.compose env57182 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound57182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57183 : List Nat := [2,4,8,16,32,64,89,256,512,368,635,0,301,81,340,3,293,75,368,340,33,32,97,262,381,48,58,81,373,862,289,112,257,292,292,512]

theorem envBound57183 : H12AffineFastState.Bounded env57183 := by
  intro p hp
  have h : env57183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57182_57183 : H12AffineEnvironment.transform 9 368 env57182 = env57183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env57182 == env57183) = true)

theorem identity57183 : scanCanonicalize (H12AffineFastState.compose env57183 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57183 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57184 : List Nat := [2,4,8,16,32,64,89,78,512,62,635,0,99,81,26,3,107,75,62,26,33,32,97,72,51,48,58,81,59,528,111,112,79,106,106,512]

theorem envBound57184 : H12AffineFastState.Bounded env57184 := by
  intro p hp
  have h : env57184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57183_57184 : H12AffineEnvironment.transform 7 78 env57183 = env57184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57183 == env57184) = true)

def env57185 : List Nat := [2,4,8,16,32,48,41,62,512,62,523,0,19,33,26,3,27,59,62,26,33,32,17,56,51,48,58,33,59,528,31,0,63,26,26,512]

theorem envBound57185 : H12AffineFastState.Bounded env57185 := by
  intro p hp
  have h : env57185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57184_57185 : H12AffineEnvironment.transform 5 48 env57184 = env57185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57184 == env57185) = true)

theorem identity57185 : scanCanonicalize (H12AffineFastState.compose env57185 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound57185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57186 : List Nat := [2,4,8,16,32,48,41,62,17,62,26,0,19,33,26,3,27,59,62,26,33,32,17,56,51,48,58,33,59,1,31,0,63,26,26,17]

theorem envBound57186 : H12AffineFastState.Bounded env57186 := by
  intro p hp
  have h : env57186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57185_57186 : H12AffineEnvironment.transform 8 17 env57185 = env57186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env57185 == env57186) = true)

def env57187 : List Nat := [2,4,8,16,32,49,40,63,512,62,522,0,18,32,26,3,26,58,62,26,33,32,16,57,51,48,58,32,59,528,30,1,62,27,27,512]

theorem envBound57187 : H12AffineFastState.Bounded env57187 := by
  intro p hp
  have h : env57187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57184_57187 : H12AffineEnvironment.transform 5 49 env57184 = env57187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57184 == env57187) = true)

theorem identity57187 : scanCanonicalize (H12AffineFastState.compose env57187 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57188 : List Nat := [2,4,8,16,32,49,40,63,11,62,1,0,18,32,26,3,26,58,62,26,33,32,16,57,51,48,58,32,59,27,30,1,62,27,27,11]

theorem envBound57188 : H12AffineFastState.Bounded env57188 := by
  intro p hp
  have h : env57188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57187_57188 : H12AffineEnvironment.transform 8 11 env57187 = env57188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57187 == env57188) = true)

theorem identity57188 : scanCanonicalize (H12AffineFastState.compose env57188 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57188 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57189 : List Nat := [2,4,8,10,32,43,40,37,11,36,1,0,8,32,0,3,0,32,36,0,33,32,10,35,41,42,32,32,33,1,4,1,36,1,1,11]

theorem envBound57189 : H12AffineFastState.Bounded env57189 := by
  intro p hp
  have h : env57189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57188_57189 : H12AffineEnvironment.transform 3 10 env57188 = env57189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57188 == env57189) = true)

theorem identity57189 : scanCanonicalize (H12AffineFastState.compose env57189 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57190 : List Nat := [2,4,8,10,11,0,3,14,11,15,1,0,8,11,0,3,0,11,15,0,10,11,10,8,2,1,11,11,10,1,4,1,15,1,1,11]

theorem envBound57190 : H12AffineFastState.Bounded env57190 := by
  intro p hp
  have h : env57190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57189_57190 : H12AffineEnvironment.transform 4 11 env57189 = env57190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57189 == env57190) = true)

def env57191 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,1,301,80,340,3,292,74,1024,340,1360,32,1297,1142,381,1344,1355,80,372,1582,289,112,257,1108,293,512]

theorem envBound57191 : H12AffineFastState.Bounded env57191 := by
  intro p hp
  have h : env57191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57181_57191 : H12AffineEnvironment.transform 11 1 env57181 = env57191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57181 == env57191) = true)

theorem identity57191 : scanCanonicalize (H12AffineFastState.compose env57191 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound57191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57192 : List Nat := [2,4,8,16,32,64,89,256,96,1024,1387,1,301,80,340,3,292,74,1024,340,1360,32,1297,1142,381,1344,1355,80,372,1102,289,112,257,1108,293,96]

theorem envBound57192 : H12AffineFastState.Bounded env57192 := by
  intro p hp
  have h : env57192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57191_57192 : H12AffineEnvironment.transform 8 96 env57191 = env57192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env57191 == env57192) = true)

theorem identity57192 : scanCanonicalize (H12AffineFastState.compose env57192 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57192 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57193 : List Nat := [2,4,8,11,32,64,66,256,96,1024,1387,1,301,75,335,3,292,74,1024,335,1355,32,1290,1133,358,1344,1355,75,367,1102,289,107,257,1103,293,96]

theorem envBound57193 : H12AffineFastState.Bounded env57193 := by
  intro p hp
  have h : env57193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57192_57193 : H12AffineEnvironment.transform 3 11 env57192 = env57193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57192 == env57193) = true)

theorem identity57193 : scanCanonicalize (H12AffineFastState.compose env57193 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57193 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57194 : List Nat := [2,4,8,11,32,64,66,78,96,1024,1061,1,99,75,1,3,106,74,1024,1,1029,32,1092,1133,40,1038,1029,75,33,1102,111,107,79,1103,107,96]

theorem envBound57194 : H12AffineFastState.Bounded env57194 := by
  intro p hp
  have h : env57194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57193_57194 : H12AffineEnvironment.transform 7 78 env57193 = env57194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57193 == env57194) = true)

theorem identity57194 : scanCanonicalize (H12AffineFastState.compose env57194 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound57194 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57195 : List Nat := [2,4,8,11,32,64,66,78,96,37,0,1,99,75,1,3,106,74,37,1,32,32,97,72,40,43,32,75,33,107,111,107,79,106,107,96]

theorem envBound57195 : H12AffineFastState.Bounded env57195 := by
  intro p hp
  have h : env57195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57194_57195 : H12AffineEnvironment.transform 9 37 env57194 = env57195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env57194 == env57195) = true)

def env57196 : List Nat := [2,4,8,11,32,32,34,46,0,37,0,1,3,43,1,3,10,42,37,1,32,32,1,40,40,43,32,43,33,11,15,11,47,10,11,0]

theorem envBound57196 : H12AffineFastState.Bounded env57196 := by
  intro p hp
  have h : env57196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57195_57196 : H12AffineEnvironment.transform 5 32 env57195 = env57196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57195 == env57196) = true)

theorem identity57196 : scanCanonicalize (H12AffineFastState.compose env57196 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57196 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57197 : List Nat := [2,4,2,1,32,32,34,36,0,37,0,1,3,33,1,3,0,32,37,1,32,32,1,34,34,33,32,33,33,1,5,1,37,0,1,0]

theorem envBound57197 : H12AffineFastState.Bounded env57197 := by
  intro p hp
  have h : env57197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57196_57197 : H12AffineEnvironment.transform 2 2 env57196 = env57197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57196 == env57197) = true)

def env57198 : List Nat := [2,4,8,11,32,33,35,47,1,37,0,1,2,42,1,3,11,43,37,1,32,32,0,41,40,43,32,42,33,10,14,10,46,11,10,1]

theorem envBound57198 : H12AffineFastState.Bounded env57198 := by
  intro p hp
  have h : env57198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57195_57198 : H12AffineEnvironment.transform 5 33 env57195 = env57198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57195 == env57198) = true)

def env57199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142598,28889,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57199 : H12AffineFastState.Bounded env57199 := by
  intro p hp
  have h : env57199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57163_57199 : H12AffineEnvironment.transform 21 41089 env57163 = env57199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57163 == env57199) = true)

theorem identity57199 : scanCanonicalize (H12AffineFastState.compose env57199 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 74094) := by decide +kernel

theorem selectedBound57199 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,74094,41089,78127,102632,28889,90415,103452,16384,77954,96347,5352,74118,257,16661,78035,21072]

theorem envBound57200 : H12AffineFastState.Bounded env57200 := by
  intro p hp
  have h : env57200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57199_57200 : H12AffineEnvironment.transform 20 74094 env57199 = env57200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74094 env57199 == env57200) = true)

theorem identity57200 : scanCanonicalize (H12AffineFastState.compose env57200 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57200 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,16384,32768,65536,71130,82112,1024,32768,66662,34185,70695,102632,21969,82983,103452,16384,71050,89427,5352,66702,257,16661,71131,21072]

theorem envBound57201 : H12AffineFastState.Bounded env57201 := by
  intro p hp
  have h : env57201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57200_57201 : H12AffineEnvironment.transform 12 1288 env57200 = env57201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57200 == env57201) = true)

theorem identity57201 : scanCanonicalize (H12AffineFastState.compose env57201 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57201 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,444,32768,65536,71130,65916,1024,32768,66662,34185,70695,102632,5229,66971,103452,444,71050,72943,5352,66702,257,169,71131,5100]

theorem envBound57202 : H12AffineFastState.Bounded env57202 := by
  intro p hp
  have h : env57202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57201_57202 : H12AffineEnvironment.transform 13 444 env57201 = env57202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57201 == env57202) = true)

theorem identity57202 : scanCanonicalize (H12AffineFastState.compose env57202 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57202 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,65536,66614,65916,1024,32768,66662,34185,67019,98564,1409,66971,99824,444,66662,68867,1284,66702,257,169,66615,512]

theorem envBound57203 : H12AffineFastState.Bounded env57203 := by
  intro p hp
  have h : env57203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57202_57203 : H12AffineEnvironment.transform 11 492 env57202 = env57203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57202 == env57203) = true)

theorem identity57203 : scanCanonicalize (H12AffineFastState.compose env57203 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57203 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,1874,868,1582,1024,32768,820,34185,665,34390,1409,713,33442,444,820,2641,1284,988,257,169,869,512]

theorem envBound57204 : H12AffineFastState.Bounded env57204 := by
  intro p hp
  have h : env57204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57203_57204 : H12AffineEnvironment.transform 15 1874 env57203 = env57204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57203 == env57204) = true)

def env57205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295815,4247640,6348992,4273308,16384,77954,4315354,6395143,4292871,257,6406394,78035,4256465]

theorem envBound57205 : H12AffineFastState.Bounded env57205 := by
  intro p hp
  have h : env57205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57162_57205 : H12AffineEnvironment.transform 17 82113 env57162 = env57205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57162 == env57205) = true)

def env57206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142599,28888,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57206 : H12AffineFastState.Bounded env57206 := by
  intro p hp
  have h : env57206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57205_57206 : H12AffineEnvironment.transform 21 41088 env57205 = env57206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57205 == env57206) = true)

theorem identity57206 : scanCanonicalize (H12AffineFastState.compose env57206 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 78974) := by decide +kernel

theorem selectedBound57206 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,78974,41088,74814,99833,28888,95294,103452,16384,77954,96346,505,74119,257,21508,78035,21073]

theorem envBound57207 : H12AffineFastState.Bounded env57207 := by
  intro p hp
  have h : env57207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57206_57207 : H12AffineEnvironment.transform 20 78974 env57206 = env57207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78974 env57206 == env57207) = true)

theorem identity57207 : scanCanonicalize (H12AffineFastState.compose env57207 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 501) := by decide +kernel

theorem selectedBound57207 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82113,1024,32768,71051,33141,67019,99833,20781,87499,103452,16384,70007,88495,505,65650,257,21508,69926,21073]

theorem envBound57208 : H12AffineFastState.Bounded env57208 := by
  intro p hp
  have h : env57208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57207_57208 : H12AffineEnvironment.transform 12 501 env57207 = env57208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 501 env57207 == env57208) = true)

theorem identity57208 : scanCanonicalize (H12AffineFastState.compose env57208 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 53727) := by decide +kernel

theorem selectedBound57208 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,53727,49400,37150,1024,32768,50260,33141,54292,21542,20781,33812,17859,16384,49320,34928,505,53677,257,21508,49401,21073]

theorem envBound57209 : H12AffineFastState.Bounded env57209 := by
  intro p hp
  have h : env57209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57208_57209 : H12AffineEnvironment.transform 15 53727 env57208 = env57209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53727 env57208 == env57209) = true)

theorem identity57209 : scanCanonicalize (H12AffineFastState.compose env57209 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57209 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,4177,32768,33166,37033,37150,1024,32768,37893,33141,33861,1143,380,33812,5522,4177,37113,34928,505,33276,257,1109,37032,512]

theorem envBound57210 : H12AffineFastState.Bounded env57210 := by
  intro p hp
  have h : env57210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57209_57210 : H12AffineEnvironment.transform 13 4177 env57209 = env57210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57209 == env57210) = true)

theorem identity57210 : scanCanonicalize (H12AffineFastState.compose env57210 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57210 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,501,4177,32768,33166,37033,37150,1024,32768,37893,33141,33861,1143,380,33812,5522,4177,37113,34683,505,33276,257,1109,37032,512]

theorem envBound57211 : H12AffineFastState.Bounded env57211 := by
  intro p hp
  have h : env57211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57210_57211 : H12AffineEnvironment.transform 10 1803 env57210 = env57211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57210 == env57211) = true)

theorem identity57211 : scanCanonicalize (H12AffineFastState.compose env57211 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound57211 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,501,4177,341,219,4604,4171,1024,341,5456,32,1296,1143,380,1345,5522,4177,4524,1582,505,169,257,1109,4605,512]

theorem envBound57212 : H12AffineFastState.Bounded env57212 := by
  intro p hp
  have h : env57212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57211_57212 : H12AffineEnvironment.transform 14 341 env57211 = env57212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env57211 == env57212) = true)

def env57213 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,4096,301,4177,341,3,4388,4171,1024,341,5456,32,1296,1143,380,1345,5450,4177,4468,1582,289,113,257,1109,4389,512]

theorem envBound57213 : H12AffineFastState.Bounded env57213 := by
  intro p hp
  have h : env57213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57212_57213 : H12AffineEnvironment.transform 6 88 env57212 = env57213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57212 == env57213) = true)

def env57214 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,0,301,81,341,3,292,75,1024,341,1360,32,1296,1143,380,1345,1354,81,372,1582,289,113,257,1109,293,512]

theorem envBound57214 : H12AffineFastState.Bounded env57214 := by
  intro p hp
  have h : env57214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57213_57214 : H12AffineEnvironment.transform 11 0 env57213 = env57214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57213 == env57214) = true)

theorem identity57214 : scanCanonicalize (H12AffineFastState.compose env57214 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57214 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57215 : List Nat := [2,4,8,16,32,64,88,21,512,1024,1566,0,56,81,64,3,49,75,1024,64,1093,32,1029,1143,105,1108,1119,81,97,1582,52,113,20,1109,48,512]

theorem envBound57215 : H12AffineFastState.Bounded env57215 := by
  intro p hp
  have h : env57215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57214_57215 : H12AffineEnvironment.transform 7 21 env57214 = env57215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57214 == env57215) = true)

theorem identity57215 : scanCanonicalize (H12AffineFastState.compose env57215 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 639) := by decide +kernel

theorem selectedBound57215 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57216 : List Nat := [2,4,8,16,32,64,88,21,512,639,97,0,56,81,64,3,49,75,639,64,570,32,634,520,105,555,544,81,97,81,52,113,20,554,48,512]

theorem envBound57216 : H12AffineFastState.Bounded env57216 := by
  intro p hp
  have h : env57216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57215_57216 : H12AffineEnvironment.transform 9 639 env57215 = env57216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 639 env57215 == env57216) = true)

theorem identity57216 : scanCanonicalize (H12AffineFastState.compose env57216 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound57216 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57217 : List Nat := [2,4,8,16,32,64,88,21,90,37,97,0,56,81,64,3,49,75,37,64,96,32,32,82,105,113,122,81,97,81,52,113,20,112,48,90]

theorem envBound57217 : H12AffineFastState.Bounded env57217 := by
  intro p hp
  have h : env57217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57216_57217 : H12AffineEnvironment.transform 8 90 env57216 = env57217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env57216 == env57217) = true)

theorem identity57217 : scanCanonicalize (H12AffineFastState.compose env57217 (packedSelected [0,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound57217 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57218 : List Nat := [2,4,8,16,32,58,34,21,32,37,27,0,56,43,58,3,49,49,37,58,26,32,32,40,19,11,0,43,27,43,52,11,20,10,48,32]

theorem envBound57218 : H12AffineFastState.Bounded env57218 := by
  intro p hp
  have h : env57218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57217_57218 : H12AffineEnvironment.transform 5 58 env57217 = env57218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env57217 == env57218) = true)

def env57219 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,1,301,80,341,3,293,74,1024,341,1361,32,1296,1143,380,1345,1355,80,373,1582,289,113,257,1109,292,512]

theorem envBound57219 : H12AffineFastState.Bounded env57219 := by
  intro p hp
  have h : env57219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57213_57219 : H12AffineEnvironment.transform 11 1 env57213 = env57219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57213 == env57219) = true)

theorem identity57219 : scanCanonicalize (H12AffineFastState.compose env57219 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound57219 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57220 : List Nat := [2,4,8,16,32,64,88,256,512,517,270,1,301,80,341,3,293,74,517,341,852,32,789,626,380,836,846,80,373,43,289,113,257,592,292,512]

theorem envBound57220 : H12AffineFastState.Bounded env57220 := by
  intro p hp
  have h : env57220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57219_57220 : H12AffineEnvironment.transform 9 517 env57219 = env57220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env57219 == env57220) = true)

theorem identity57220 : scanCanonicalize (H12AffineFastState.compose env57220 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound57220 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57221 : List Nat := [2,4,8,16,32,64,88,256,91,94,270,1,301,80,341,3,293,74,94,341,271,32,334,41,380,287,277,80,373,43,289,113,257,11,292,91]

theorem envBound57221 : H12AffineFastState.Bounded env57221 := by
  intro p hp
  have h : env57221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57220_57221 : H12AffineEnvironment.transform 8 91 env57220 = env57221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env57220 == env57221) = true)

theorem identity57221 : scanCanonicalize (H12AffineFastState.compose env57221 (packedSelected [4,7,13] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57221 : packedSelected [4,7,13] rootPS < 2^1333 := by decide +kernel

def env57222 : List Nat := [2,4,8,16,32,11,19,256,16,21,270,1,301,27,286,3,293,1,21,286,271,32,261,41,311,287,277,27,318,43,289,58,257,11,292,16]

theorem envBound57222 : H12AffineFastState.Bounded env57222 := by
  intro p hp
  have h : env57222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57221_57222 : H12AffineEnvironment.transform 5 11 env57221 = env57222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57221 == env57222) = true)

def env57223 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,4096,300,4177,341,2,4389,4171,1024,341,5456,32,1296,1143,380,1345,5451,4177,4469,1582,288,112,257,1109,4388,512]

theorem envBound57223 : H12AffineFastState.Bounded env57223 := by
  intro p hp
  have h : env57223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57212_57223 : H12AffineEnvironment.transform 6 89 env57212 = env57223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57212 == env57223) = true)

def env57224 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,0,300,81,341,2,293,75,1024,341,1360,32,1296,1143,380,1345,1355,81,373,1582,288,112,257,1109,292,512]

theorem envBound57224 : H12AffineFastState.Bounded env57224 := by
  intro p hp
  have h : env57224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57223_57224 : H12AffineEnvironment.transform 11 0 env57223 = env57224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57223 == env57224) = true)

theorem identity57224 : scanCanonicalize (H12AffineFastState.compose env57224 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound57224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57225 : List Nat := [2,4,8,16,32,64,89,256,512,368,635,0,300,81,341,2,293,75,368,341,32,32,96,263,380,49,59,81,373,862,288,112,257,293,292,512]

theorem envBound57225 : H12AffineFastState.Bounded env57225 := by
  intro p hp
  have h : env57225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57224_57225 : H12AffineEnvironment.transform 9 368 env57224 = env57225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env57224 == env57225) = true)

theorem identity57225 : scanCanonicalize (H12AffineFastState.compose env57225 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57225 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57226 : List Nat := [2,4,8,16,32,64,89,79,512,63,635,0,99,81,26,2,106,75,63,26,32,32,96,72,51,49,59,81,58,529,111,112,78,106,107,512]

theorem envBound57226 : H12AffineFastState.Bounded env57226 := by
  intro p hp
  have h : env57226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57225_57226 : H12AffineEnvironment.transform 7 79 env57225 = env57226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57225 == env57226) = true)

def env57227 : List Nat := [2,4,8,16,32,48,41,63,512,63,523,0,19,33,26,2,26,59,63,26,32,32,16,56,51,49,59,33,58,529,31,0,62,26,27,512]

theorem envBound57227 : H12AffineFastState.Bounded env57227 := by
  intro p hp
  have h : env57227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57226_57227 : H12AffineEnvironment.transform 5 48 env57226 = env57227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57226 == env57227) = true)

theorem identity57227 : scanCanonicalize (H12AffineFastState.compose env57227 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57228 : List Nat := [2,4,8,16,32,48,41,63,10,63,1,0,19,33,26,2,26,59,63,26,32,32,16,56,51,49,59,33,58,27,31,0,62,26,27,10]

theorem envBound57228 : H12AffineFastState.Bounded env57228 := by
  intro p hp
  have h : env57228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57227_57228 : H12AffineEnvironment.transform 8 10 env57227 = env57228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57227 == env57228) = true)

theorem identity57228 : scanCanonicalize (H12AffineFastState.compose env57228 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57228 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57229 : List Nat := [2,4,8,10,32,42,41,37,10,37,1,0,9,33,0,2,0,33,37,0,32,32,10,34,41,43,33,33,32,1,5,0,36,0,1,10]

theorem envBound57229 : H12AffineFastState.Bounded env57229 := by
  intro p hp
  have h : env57229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57228_57229 : H12AffineEnvironment.transform 3 10 env57228 = env57229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57228 == env57229) = true)

theorem identity57229 : scanCanonicalize (H12AffineFastState.compose env57229 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57230 : List Nat := [2,4,8,10,11,1,2,14,10,14,1,0,9,10,0,2,0,10,14,0,11,11,10,9,2,0,10,10,11,1,5,0,15,0,1,10]

theorem envBound57230 : H12AffineFastState.Bounded env57230 := by
  intro p hp
  have h : env57230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57229_57230 : H12AffineEnvironment.transform 4 11 env57229 = env57230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57229 == env57230) = true)

def env57231 : List Nat := [2,4,8,16,32,49,40,62,512,63,522,0,18,32,26,2,27,58,63,26,32,32,17,57,51,49,59,32,58,529,30,1,63,27,26,512]

theorem envBound57231 : H12AffineFastState.Bounded env57231 := by
  intro p hp
  have h : env57231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57226_57231 : H12AffineEnvironment.transform 5 49 env57226 = env57231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57226 == env57231) = true)

theorem identity57231 : scanCanonicalize (H12AffineFastState.compose env57231 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound57231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57232 : List Nat := [2,4,8,16,32,49,40,62,16,63,26,0,18,32,26,2,27,58,63,26,32,32,17,57,51,49,59,32,58,1,30,1,63,27,26,16]

theorem envBound57232 : H12AffineFastState.Bounded env57232 := by
  intro p hp
  have h : env57232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57231_57232 : H12AffineEnvironment.transform 8 16 env57231 = env57232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env57231 == env57232) = true)

def env57233 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,1,300,80,341,2,292,74,1024,341,1361,32,1296,1143,380,1345,1354,80,372,1582,288,112,257,1109,293,512]

theorem envBound57233 : H12AffineFastState.Bounded env57233 := by
  intro p hp
  have h : env57233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57223_57233 : H12AffineEnvironment.transform 11 1 env57223 = env57233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57223 == env57233) = true)

theorem identity57233 : scanCanonicalize (H12AffineFastState.compose env57233 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound57233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57234 : List Nat := [2,4,8,16,32,64,89,256,96,1024,1387,1,300,80,341,2,292,74,1024,341,1361,32,1296,1143,380,1345,1354,80,372,1102,288,112,257,1109,293,96]

theorem envBound57234 : H12AffineFastState.Bounded env57234 := by
  intro p hp
  have h : env57234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57233_57234 : H12AffineEnvironment.transform 8 96 env57233 = env57234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env57233 == env57234) = true)

theorem identity57234 : scanCanonicalize (H12AffineFastState.compose env57234 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57234 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57235 : List Nat := [2,4,8,11,32,64,66,256,96,1024,1387,1,300,75,334,2,292,74,1024,334,1354,32,1291,1132,359,1345,1354,75,367,1102,288,107,257,1102,293,96]

theorem envBound57235 : H12AffineFastState.Bounded env57235 := by
  intro p hp
  have h : env57235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57234_57235 : H12AffineEnvironment.transform 3 11 env57234 = env57235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57234 == env57235) = true)

theorem identity57235 : scanCanonicalize (H12AffineFastState.compose env57235 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57235 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57236 : List Nat := [2,4,8,11,32,64,66,79,96,1024,1060,1,99,75,1,2,107,74,1024,1,1029,32,1092,1132,40,1038,1029,75,32,1102,111,107,78,1102,106,96]

theorem envBound57236 : H12AffineFastState.Bounded env57236 := by
  intro p hp
  have h : env57236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57235_57236 : H12AffineEnvironment.transform 7 79 env57235 = env57236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57235 == env57236) = true)

theorem identity57236 : scanCanonicalize (H12AffineFastState.compose env57236 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound57236 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57237 : List Nat := [2,4,8,11,32,64,66,79,96,36,0,1,99,75,1,2,107,74,36,1,33,32,96,72,40,42,33,75,32,106,111,107,78,106,106,96]

theorem envBound57237 : H12AffineFastState.Bounded env57237 := by
  intro p hp
  have h : env57237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57236_57237 : H12AffineEnvironment.transform 9 36 env57236 = env57237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env57236 == env57237) = true)

def env57238 : List Nat := [2,4,8,11,32,32,34,47,0,36,0,1,3,43,1,2,11,42,36,1,33,32,0,40,40,42,33,43,32,10,15,11,46,10,10,0]

theorem envBound57238 : H12AffineFastState.Bounded env57238 := by
  intro p hp
  have h : env57238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57237_57238 : H12AffineEnvironment.transform 5 32 env57237 = env57238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57237 == env57238) = true)

theorem identity57238 : scanCanonicalize (H12AffineFastState.compose env57238 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57239 : List Nat := [2,4,3,0,32,32,34,36,0,36,0,1,3,32,1,2,0,33,36,1,33,32,0,35,35,33,33,32,32,1,4,0,37,1,1,0]

theorem envBound57239 : H12AffineFastState.Bounded env57239 := by
  intro p hp
  have h : env57239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57238_57239 : H12AffineEnvironment.transform 2 3 env57238 = env57239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57238 == env57239) = true)

def env57240 : List Nat := [2,4,8,11,32,33,35,46,1,36,0,1,2,42,1,2,10,43,36,1,33,32,1,41,40,42,33,42,32,11,14,10,47,11,11,1]

theorem envBound57240 : H12AffineFastState.Bounded env57240 := by
  intro p hp
  have h : env57240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57237_57240 : H12AffineEnvironment.transform 5 33 env57237 = env57240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57237 == env57240) = true)

def env57241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142598,28889,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57241 : H12AffineFastState.Bounded env57241 := by
  intro p hp
  have h : env57241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57205_57241 : H12AffineEnvironment.transform 21 41089 env57205 = env57241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57205 == env57241) = true)

theorem identity57241 : scanCanonicalize (H12AffineFastState.compose env57241 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 94527) := by decide +kernel

theorem selectedBound57241 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,94527,41089,90494,114873,28889,78206,103453,16384,77954,96347,17593,74118,257,4420,78035,21072]

theorem envBound57242 : H12AffineFastState.Bounded env57242 := by
  intro p hp
  have h : env57242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57241_57242 : H12AffineEnvironment.transform 20 94527 env57241 = env57242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 94527 env57241 == env57242) = true)

theorem identity57242 : scanCanonicalize (H12AffineFastState.compose env57242 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57242 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,16384,32768,65536,71130,82113,1024,32768,87095,34185,83062,114873,21969,70774,103453,16384,71050,89427,17593,66702,257,4420,71131,21072]

theorem envBound57243 : H12AffineFastState.Bounded env57243 := by
  intro p hp
  have h : env57243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57242_57243 : H12AffineEnvironment.transform 12 1288 env57242 = env57243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57242 == env57243) = true)

theorem identity57243 : scanCanonicalize (H12AffineFastState.compose env57243 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57243 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,16384,32768,65536,66615,82113,1024,32768,83418,34185,83062,114873,17468,66971,99824,16384,66663,85182,17593,66702,257,169,66614,17341]

theorem envBound57244 : H12AffineFastState.Bounded env57244 := by
  intro p hp
  have h : env57244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57243_57244 : H12AffineEnvironment.transform 11 493 env57243 = env57244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57243 == env57244) = true)

theorem identity57244 : scanCanonicalize (H12AffineFastState.compose env57244 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57244 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,65536,66615,65916,1024,32768,66663,34185,67019,98564,1409,66971,99824,445,66663,68867,1284,66702,257,169,66614,512]

theorem envBound57245 : H12AffineFastState.Bounded env57245 := by
  intro p hp
  have h : env57245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57244_57245 : H12AffineEnvironment.transform 13 445 env57244 = env57245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57244 == env57245) = true)

theorem identity57245 : scanCanonicalize (H12AffineFastState.compose env57245 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57245 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,1874,869,1582,1024,32768,821,34185,665,34390,1409,713,33442,445,821,2641,1284,988,257,169,868,512]

theorem envBound57246 : H12AffineFastState.Bounded env57246 := by
  intro p hp
  have h : env57246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57245_57246 : H12AffineEnvironment.transform 15 1874 env57245 = env57246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57245 == env57246) = true)

def env57247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4486236,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound57247 : H12AffineFastState.Bounded env57247 := by
  intro p hp
  have h : env57247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57161_57247 : H12AffineEnvironment.transform 22 6336705 env57161 = env57247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env57161 == env57247) = true)

def env57248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295814,4247640,6348993,4273308,16384,77954,4315354,6395142,4292870,257,6406394,78035,4256465]

theorem envBound57248 : H12AffineFastState.Bounded env57248 := by
  intro p hp
  have h : env57248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57247_57248 : H12AffineEnvironment.transform 17 82112 env57247 = env57248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57247 == env57248) = true)

def env57249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142598,28888,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57249 : H12AffineFastState.Bounded env57249 := by
  intro p hp
  have h : env57249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57248_57249 : H12AffineEnvironment.transform 21 41088 env57248 = env57249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57248 == env57249) = true)

theorem identity57249 : scanCanonicalize (H12AffineFastState.compose env57249 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 70007) := by decide +kernel

theorem selectedBound57249 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,70007,41088,65846,106737,28888,86326,103452,16384,77954,96346,9457,74118,257,28941,78035,21073]

theorem envBound57250 : H12AffineFastState.Bounded env57250 := by
  intro p hp
  have h : env57250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57249_57250 : H12AffineEnvironment.transform 20 70007 env57249 = env57250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70007 env57249 == env57250) = true)

theorem identity57250 : scanCanonicalize (H12AffineFastState.compose env57250 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound57250 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57251 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,16384,32768,65536,78034,82112,252,32768,70007,41088,65846,106737,28888,86326,102624,16384,77954,96346,8205,74118,257,28941,78035,21073]

theorem envBound57251 : H12AffineFastState.Bounded env57251 := by
  intro p hp
  have h : env57251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57250_57251 : H12AffineEnvironment.transform 9 252 env57250 = env57251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57250 == env57251) = true)

theorem identity57251 : scanCanonicalize (H12AffineFastState.compose env57251 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound57251 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57252 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,16384,32768,33166,45404,49486,252,32768,37113,41088,32952,8575,28888,53432,4462,16384,45324,63956,8205,40968,257,28941,45405,21073]

theorem envBound57252 : H12AffineFastState.Bounded env57252 := by
  intro p hp
  have h : env57252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57251_57252 : H12AffineEnvironment.transform 15 33166 env57251 = env57252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env57251 == env57252) = true)

def env57253 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,4096,32768,33166,45404,37198,252,32768,37113,41088,32952,8575,8408,32952,4462,4096,45324,43476,8205,40968,257,8461,45405,593]

theorem envBound57253 : H12AffineFastState.Bounded env57253 := by
  intro p hp
  have h : env57253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57252_57253 : H12AffineEnvironment.transform 13 4096 env57252 = env57253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env57252 == env57253) = true)

def env57254 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4096,32768,33166,45324,37150,172,32768,37033,41088,32952,8495,8328,32952,4414,4096,45324,43396,8205,40968,257,8461,45325,513]

theorem envBound57254 : H12AffineFastState.Bounded env57254 := by
  intro p hp
  have h : env57254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57253_57254 : H12AffineEnvironment.transform 5 16 env57253 = env57254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57253 == env57254) = true)

theorem identity57254 : scanCanonicalize (H12AffineFastState.compose env57254 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound57254 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57255 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4096,33,431,12589,4415,172,33,4232,8353,153,8495,8328,153,4414,4096,12589,10661,8205,8233,257,8461,12588,513]

theorem envBound57255 : H12AffineFastState.Bounded env57255 := by
  intro p hp
  have h : env57255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57254_57255 : H12AffineEnvironment.transform 14 33 env57254 = env57255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env57254 == env57255) = true)

theorem identity57255 : scanCanonicalize (H12AffineFastState.compose env57255 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound57255 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57256 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,300,4096,33,431,4097,4415,172,33,4232,397,153,3,420,153,4414,4096,4097,2185,289,261,257,33,4096,513]

theorem envBound57256 : H12AffineFastState.Bounded env57256 := by
  intro p hp
  have h : env57256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57255_57256 : H12AffineEnvironment.transform 12 300 env57255 = env57256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env57255 == env57256) = true)

theorem identity57256 : scanCanonicalize (H12AffineFastState.compose env57256 (packedSelected [0,1,2,4,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 780) := by decide +kernel

theorem selectedBound57256 : packedSelected [0,1,2,4,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57257 : List Nat := [2,4,8,16,32,16,128,256,512,172,780,4096,300,4096,33,431,4097,4415,172,33,4232,397,153,3,420,153,4414,4096,4097,901,289,261,257,33,4096,513]

theorem envBound57257 : H12AffineFastState.Bounded env57257 := by
  intro p hp
  have h : env57257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57256_57257 : H12AffineEnvironment.transform 10 780 env57256 = env57257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 780 env57256 == env57257) = true)

theorem identity57257 : scanCanonicalize (H12AffineFastState.compose env57257 (packedSelected [0,1,2,4,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 927) := by decide +kernel

theorem selectedBound57257 : packedSelected [0,1,2,4,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57258 : List Nat := [2,4,8,16,32,16,128,256,512,172,780,927,300,927,33,431,926,672,172,33,791,397,153,3,420,153,673,927,926,901,289,261,257,33,927,513]

theorem envBound57258 : H12AffineFastState.Bounded env57258 := by
  intro p hp
  have h : env57258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57257_57258 : H12AffineEnvironment.transform 11 927 env57257 = env57258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 927 env57257 == env57258) = true)

theorem identity57258 : scanCanonicalize (H12AffineFastState.compose env57258 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 142) := by decide +kernel

theorem selectedBound57258 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57259 : List Nat := [2,4,8,16,32,16,128,142,512,172,642,529,162,529,33,33,528,672,172,33,665,3,153,3,42,153,673,529,528,523,175,139,143,33,529,513]

theorem envBound57259 : H12AffineFastState.Bounded env57259 := by
  intro p hp
  have h : env57259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57258_57259 : H12AffineEnvironment.transform 7 142 env57258 = env57259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 142 env57258 == env57259) = true)

theorem identity57259 : scanCanonicalize (H12AffineFastState.compose env57259 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 155) := by decide +kernel

theorem selectedBound57259 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env57260 : List Nat := [2,4,8,16,32,16,128,142,155,172,25,138,162,138,33,33,139,59,172,33,2,3,153,3,42,153,58,138,139,144,175,139,143,33,138,154]

theorem envBound57260 : H12AffineFastState.Bounded env57260 := by
  intro p hp
  have h : env57260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57259_57260 : H12AffineEnvironment.transform 8 155 env57259 = env57260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 155 env57259 == env57260) = true)

theorem identity57260 : scanCanonicalize (H12AffineFastState.compose env57260 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57260 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57261 : List Nat := [2,4,8,16,2,16,128,142,155,142,25,138,128,138,3,3,139,25,142,3,2,3,153,3,8,153,24,138,139,144,141,139,143,3,138,154]

theorem envBound57261 : H12AffineFastState.Bounded env57261 := by
  intro p hp
  have h : env57261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57260_57261 : H12AffineEnvironment.transform 4 2 env57260 = env57261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57260 == env57261) = true)

theorem identity57261 : scanCanonicalize (H12AffineFastState.compose env57261 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound57261 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57262 : List Nat := [2,4,8,16,2,16,26,20,1,20,25,16,26,16,3,3,17,25,20,3,2,3,3,3,8,3,24,16,17,10,23,17,21,3,16,0]

theorem envBound57262 : H12AffineFastState.Bounded env57262 := by
  intro p hp
  have h : env57262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57261_57262 : H12AffineEnvironment.transform 6 26 env57261 = env57262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env57261 == env57262) = true)

theorem identity57262 : scanCanonicalize (H12AffineFastState.compose env57262 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57262 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57263 : List Nat := [2,4,3,16,2,16,17,20,1,20,18,16,17,16,3,3,17,18,20,3,2,3,3,3,3,3,19,16,17,1,23,17,21,3,16,0]

theorem envBound57263 : H12AffineFastState.Bounded env57263 := by
  intro p hp
  have h : env57263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57262_57263 : H12AffineEnvironment.transform 2 3 env57262 = env57263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57262 == env57263) = true)

def env57264 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,8192,4096,32768,33166,45325,37151,173,32768,37032,41088,32952,8494,8329,32952,4415,4096,45324,43397,8205,40968,257,8461,45324,512]

theorem envBound57264 : H12AffineFastState.Bounded env57264 := by
  intro p hp
  have h : env57264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57253_57264 : H12AffineEnvironment.transform 5 17 env57253 = env57264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57253 == env57264) = true)

theorem identity57264 : scanCanonicalize (H12AffineFastState.compose env57264 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound57264 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57265 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,2563,4096,32768,33166,39694,37151,173,32768,37032,35459,32952,2861,2698,32952,4415,4096,39695,33670,2574,35339,257,2830,39695,512]

theorem envBound57265 : H12AffineFastState.Bounded env57265 := by
  intro p hp
  have h : env57265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57264_57265 : H12AffineEnvironment.transform 12 2563 env57264 = env57265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env57264 == env57265) = true)

theorem identity57265 : scanCanonicalize (H12AffineFastState.compose env57265 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57265 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57266 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,2563,4096,2723,2861,4525,7100,173,2723,6667,32,2587,2861,2698,2587,4415,4096,4524,2341,2574,168,257,2830,4524,512]

theorem envBound57266 : H12AffineFastState.Bounded env57266 := by
  intro p hp
  have h : env57266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57265_57266 : H12AffineEnvironment.transform 14 2723 env57265 = env57266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57265 == env57266) = true)

theorem identity57266 : scanCanonicalize (H12AffineFastState.compose env57266 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound57266 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57267 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,544,2563,544,2723,2861,909,2460,173,2723,2091,32,2587,2861,2698,2587,799,544,908,2341,2574,168,257,2830,908,512]

theorem envBound57267 : H12AffineFastState.Bounded env57267 := by
  intro p hp
  have h : env57267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57266_57267 : H12AffineEnvironment.transform 11 544 env57266 = env57267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env57266 == env57267) = true)

theorem identity57267 : scanCanonicalize (H12AffineFastState.compose env57267 (packedSelected [1,3,4,9,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57267 : packedSelected [1,3,4,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57268 : List Nat := [2,4,8,16,32,17,128,20,512,173,2048,544,2563,544,2723,2617,665,2184,173,2723,2091,32,2587,2617,2698,2587,523,544,664,2097,2574,168,21,2586,664,512]

theorem envBound57268 : H12AffineFastState.Bounded env57268 := by
  intro p hp
  have h : env57268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0