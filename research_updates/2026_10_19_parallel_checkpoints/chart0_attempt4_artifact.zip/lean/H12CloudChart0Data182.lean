import H12CloudChart0Data181

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound46091 : H12AffineFastState.Bounded env46091 := by
  intro p hp
  have h : env46091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46090_46091 : H12AffineEnvironment.transform 5 16 env46090 = env46091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46090 == env46091) = true)

theorem identity46091 : scanCanonicalize (H12AffineFastState.compose env46091 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46092 : List Nat := [2,4,8,0,1,0,8,4,512,5,0,0,9,0,1,3,0,1,4,0,0,0,1,3,9,0,1,0,0,0,4,1,5,0,0,512]

theorem envBound46092 : H12AffineFastState.Bounded env46092 := by
  intro p hp
  have h : env46092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46091_46092 : H12AffineEnvironment.transform 3 0 env46091 = env46092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46091 == env46092) = true)

theorem identity46092 : scanCanonicalize (H12AffineFastState.compose env46092 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46092 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46093 : List Nat := [2,0,8,0,1,0,8,0,512,1,0,0,9,0,1,3,0,1,0,0,0,0,1,3,9,0,1,0,0,0,0,1,1,0,0,512]

theorem envBound46093 : H12AffineFastState.Bounded env46093 := by
  intro p hp
  have h : env46093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46092_46093 : H12AffineEnvironment.transform 1 0 env46092 = env46093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46092 == env46093) = true)

theorem identity46093 : scanCanonicalize (H12AffineFastState.compose env46093 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46093 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46094 : List Nat := [2,0,8,0,1,0,8,0,0,1,0,0,9,0,1,3,0,1,0,0,0,0,1,3,9,0,1,0,0,0,0,1,1,0,0,0]

theorem envBound46094 : H12AffineFastState.Bounded env46094 := by
  intro p hp
  have h : env46094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46093_46094 : H12AffineEnvironment.transform 8 0 env46093 = env46094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46093 == env46094) = true)

def env46095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1025,32769,4160,305360,29844,8583,8328,64,43357,24980,12676,324820,1501,272393,257,21792,46213,63189]

theorem envBound46095 : H12AffineFastState.Bounded env46095 := by
  intro p hp
  have h : env46095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46079_46095 : H12AffineEnvironment.transform 16 16449 env46079 = env46095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env46079 == env46095) = true)

theorem identity46095 : scanCanonicalize (H12AffineFastState.compose env46095 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46095 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30082,16449,262144,1025,8540,4160,264589,29844,8583,8328,64,2048,24980,12676,284041,1501,272393,257,21792,5592,22408]

theorem envBound46096 : H12AffineFastState.Bounded env46096 := by
  intro p hp
  have h : env46096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46095_46096 : H12AffineEnvironment.transform 14 8541 env46095 = env46096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46095 == env46096) = true)

theorem identity46096 : scanCanonicalize (H12AffineFastState.compose env46096 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound46096 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env46097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30082,16449,32040,1025,8540,4160,29861,29844,8583,8328,64,2048,24980,12676,10401,1501,21793,257,21792,5592,22408]

theorem envBound46097 : H12AffineFastState.Bounded env46097 := by
  intro p hp
  have h : env46097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46096_46097 : H12AffineEnvironment.transform 17 32040 env46096 = env46097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env46096 == env46097) = true)

theorem identity46097 : scanCanonicalize (H12AffineFastState.compose env46097 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46097 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,30082,16400,32040,1025,8461,4113,29861,29844,8583,8328,17,2048,24980,12676,10401,1420,21793,257,21792,5513,22408]

theorem envBound46098 : H12AffineFastState.Bounded env46098 := by
  intro p hp
  have h : env46098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46097_46098 : H12AffineEnvironment.transform 5 17 env46097 = env46098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46097 == env46098) = true)

theorem identity46098 : scanCanonicalize (H12AffineFastState.compose env46098 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46098 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env46099 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29962,16400,32040,1025,8461,4113,29741,29724,8463,8192,17,2048,24860,12556,10281,1284,21793,257,21792,5377,22272]

theorem envBound46099 : H12AffineFastState.Bounded env46099 := by
  intro p hp
  have h : env46099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46098_46099 : H12AffineEnvironment.transform 6 8 env46098 = env46099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46098 == env46099) = true)

theorem identity46099 : scanCanonicalize (H12AffineFastState.compose env46099 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46099 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46100 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,5393,10281,1025,8461,4113,8492,8477,8463,8192,17,2048,13341,12556,10281,1284,32,257,33,5377,513]

theorem envBound46100 : H12AffineFastState.Bounded env46100 := by
  intro p hp
  have h : env46100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46099_46100 : H12AffineEnvironment.transform 13 5377 env46099 = env46100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46099 == env46100) = true)

theorem identity46100 : scanCanonicalize (H12AffineFastState.compose env46100 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46100 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46101 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4113,33,16,2,269,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound46101 : H12AffineFastState.Bounded env46101 := by
  intro p hp
  have h : env46101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46100_46101 : H12AffineEnvironment.transform 12 269 env46100 = env46101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46100 == env46101) = true)

theorem identity46101 : scanCanonicalize (H12AffineFastState.compose env46101 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46102 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,35,5172,2049,1025,0,4113,33,16,2,40,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound46102 : H12AffineFastState.Bounded env46102 := by
  intro p hp
  have h : env46102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46101_46102 : H12AffineEnvironment.transform 7 37 env46101 = env46102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46101 == env46102) = true)

def env46103 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,1,35,1028,2049,1025,0,33,33,16,2,40,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound46103 : H12AffineFastState.Bounded env46103 := by
  intro p hp
  have h : env46103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46102_46103 : H12AffineEnvironment.transform 11 48 env46102 = env46103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46102 == env46103) = true)

theorem identity46103 : scanCanonicalize (H12AffineFastState.compose env46103 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound46103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46104 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,48,40,561,1,35,545,2049,548,0,33,33,16,2,40,17,2048,544,49,2049,516,32,36,33,561,513]

theorem envBound46104 : H12AffineFastState.Bounded env46104 := by
  intro p hp
  have h : env46104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46103_46104 : H12AffineEnvironment.transform 9 549 env46103 = env46104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env46103 == env46104) = true)

def env46105 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,40,33,1,35,49,2049,52,0,33,33,16,2,40,17,2048,48,49,2049,20,32,36,33,33,17]

theorem envBound46105 : H12AffineFastState.Bounded env46105 := by
  intro p hp
  have h : env46105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46104_46105 : H12AffineEnvironment.transform 8 16 env46104 = env46105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46104 == env46105) = true)

theorem identity46105 : scanCanonicalize (H12AffineFastState.compose env46105 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound46105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46106 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,48,40,33,1,35,49,32,52,0,33,33,16,2,40,17,33,48,49,32,20,32,36,33,33,17]

theorem envBound46106 : H12AffineFastState.Bounded env46106 := by
  intro p hp
  have h : env46106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46105_46106 : H12AffineEnvironment.transform 10 33 env46105 = env46106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env46105 == env46106) = true)

def leafEnv46106 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,48,40,33,1,35,49,32,52,0,33,33,16,2,21,40,1,17,33,48,49,32,20,32,36,33,5,35,33,17,1,33,0]

def active46106 : List Nat := [0,1,2,3,4]

def tree46106 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46106 : H12WitnessSearch.Good tree46106 := H12GlobalWitnessIndex.good

theorem leafIdentity46106 : H12AffineFastState.composeSystem env46106 rootObs = leafEnv46106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46106 rootObs == leafEnv46106) = true)

theorem terminalChecked46106 : H12PackedTerminal.terminalCheckFast leafEnv46106 active46106 tree46106 = true := by decide +kernel

def env46107 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,40,32,1,35,48,2049,53,0,33,33,16,2,40,17,2048,49,49,2049,21,32,36,33,32,16]

theorem envBound46107 : H12AffineFastState.Bounded env46107 := by
  intro p hp
  have h : env46107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46104_46107 : H12AffineEnvironment.transform 8 17 env46104 = env46107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46104 == env46107) = true)

theorem identity46107 : scanCanonicalize (H12AffineFastState.compose env46107 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound46107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46108 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,40,32,1,35,48,27,53,0,33,33,16,2,40,17,26,49,49,27,21,32,36,33,32,16]

theorem envBound46108 : H12AffineFastState.Bounded env46108 := by
  intro p hp
  have h : env46108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46107_46108 : H12AffineEnvironment.transform 10 26 env46107 = env46108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env46107 == env46108) = true)

def leafEnv46108 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,40,32,1,35,48,27,53,0,33,33,16,2,20,40,1,17,26,49,49,27,21,32,36,33,5,35,32,16,1,33,0]

def active46108 : List Nat := [0,1,2,3,4]

def tree46108 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46108 : H12WitnessSearch.Good tree46108 := H12GlobalWitnessIndex.good

theorem leafIdentity46108 : H12AffineFastState.composeSystem env46108 rootObs = leafEnv46108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46108 rootObs == leafEnv46108) = true)

theorem terminalChecked46108 : H12PackedTerminal.terminalCheckFast leafEnv46108 active46108 tree46108 = true := by decide +kernel

def env46109 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,1,35,1029,2049,1025,0,32,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound46109 : H12AffineFastState.Bounded env46109 := by
  intro p hp
  have h : env46109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46102_46109 : H12AffineEnvironment.transform 11 49 env46102 = env46109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46102 == env46109) = true)

theorem identity46109 : scanCanonicalize (H12AffineFastState.compose env46109 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46110 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,49,40,1045,1,35,1029,2049,1025,0,32,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,16]

theorem envBound46110 : H12AffineFastState.Bounded env46110 := by
  intro p hp
  have h : env46110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46109_46110 : H12AffineEnvironment.transform 8 17 env46109 = env46110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46109 == env46110) = true)

def env46111 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,40,33,1,35,49,2049,53,0,32,33,16,2,40,17,2048,48,48,2049,21,32,36,33,33,16]

theorem envBound46111 : H12AffineFastState.Bounded env46111 := by
  intro p hp
  have h : env46111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46110_46111 : H12AffineEnvironment.transform 9 52 env46110 = env46111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46110 == env46111) = true)

theorem identity46111 : scanCanonicalize (H12AffineFastState.compose env46111 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound46111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46112 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,40,33,1,35,49,27,53,0,32,33,16,2,40,17,26,48,48,27,21,32,36,33,33,16]

theorem envBound46112 : H12AffineFastState.Bounded env46112 := by
  intro p hp
  have h : env46112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46111_46112 : H12AffineEnvironment.transform 10 26 env46111 = env46112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env46111 == env46112) = true)

def leafEnv46112 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,40,33,1,35,49,27,53,0,32,33,16,2,20,40,1,17,26,48,48,27,21,32,36,33,5,35,33,16,1,32,0]

def active46112 : List Nat := [0,1,2,3,4]

def tree46112 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46112 : H12WitnessSearch.Good tree46112 := H12GlobalWitnessIndex.good

theorem leafIdentity46112 : H12AffineFastState.composeSystem env46112 rootObs = leafEnv46112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46112 rootObs == leafEnv46112) = true)

theorem terminalChecked46112 : H12PackedTerminal.terminalCheckFast leafEnv46112 active46112 tree46112 = true := by decide +kernel

def env46113 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,40,32,1,35,48,2049,52,0,32,33,16,2,40,17,2048,49,48,2049,20,32,36,33,32,16]

theorem envBound46113 : H12AffineFastState.Bounded env46113 := by
  intro p hp
  have h : env46113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46110_46113 : H12AffineEnvironment.transform 9 53 env46110 = env46113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46110 == env46113) = true)

theorem identity46113 : scanCanonicalize (H12AffineFastState.compose env46113 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound46113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46114 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,49,40,32,1,35,48,33,52,0,32,33,16,2,40,17,32,49,48,33,20,32,36,33,32,16]

theorem envBound46114 : H12AffineFastState.Bounded env46114 := by
  intro p hp
  have h : env46114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46113_46114 : H12AffineEnvironment.transform 10 32 env46113 = env46114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env46113 == env46114) = true)

def leafEnv46114 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,49,40,32,1,35,48,33,52,0,32,33,16,2,21,40,1,17,32,49,48,33,20,32,36,33,5,35,32,16,1,32,0]

def active46114 : List Nat := [0,1,2,3,4]

def tree46114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46114 : H12WitnessSearch.Good tree46114 := H12GlobalWitnessIndex.good

theorem leafIdentity46114 : H12AffineFastState.composeSystem env46114 rootObs = leafEnv46114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46114 rootObs == leafEnv46114) = true)

theorem terminalChecked46114 : H12PackedTerminal.terminalCheckFast leafEnv46114 active46114 tree46114 = true := by decide +kernel

def env46115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144596,242969,8328,64,43356,139732,160197,324821,1500,272392,257,21792,46213,74251]

theorem envBound46115 : H12AffineFastState.Bounded env46115 := by
  intro p hp
  have h : env46115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46077_46115 : H12AffineEnvironment.transform 20 4161 env46077 = env46115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46077 == env46115) = true)

theorem identity46115 : scanCanonicalize (H12AffineFastState.compose env46115 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound46115 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,4161,392286,73755,41430,8328,64,43356,79131,91402,324821,1500,272392,257,21792,46213,74251]

theorem envBound46116 : H12AffineFastState.Bounded env46116 := by
  intro p hp
  have h : env46116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46115_46116 : H12AffineEnvironment.transform 16 70863 env46115 = env46116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env46115 == env46116) = true)

def env46117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4161,392286,73755,41310,8192,64,43356,79131,91402,324701,1364,272392,257,21792,46093,74251]

theorem envBound46117 : H12AffineFastState.Bounded env46117 := by
  intro p hp
  have h : env46117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46116_46117 : H12AffineEnvironment.transform 6 8 env46116 = env46117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46116 == env46117) = true)

theorem identity46117 : scanCanonicalize (H12AffineFastState.compose env46117 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound46117 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67619,1025,32769,4161,62589,73755,41310,8192,64,43356,79131,91402,130174,1364,73771,257,21792,46093,74251]

theorem envBound46118 : H12AffineFastState.Bounded env46118 := by
  intro p hp
  have h : env46118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46117_46118 : H12AffineEnvironment.transform 17 67619 env46117 = env46118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env46117 == env46118) = true)

theorem identity46118 : scanCanonicalize (H12AffineFastState.compose env46118 (packedSelected [0,2,4,5,6,7,10,14,15,16,18,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound46118 : packedSelected [0,2,4,5,6,7,10,14,15,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env46119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,56436,1025,32769,4161,62589,62540,41310,8192,64,43356,57676,45405,10281,1364,62588,257,21792,46093,63068]

theorem envBound46119 : H12AffineFastState.Bounded env46119 := by
  intro p hp
  have h : env46119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46118_46119 : H12AffineEnvironment.transform 15 54359 env46118 = env46119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env46118 == env46119) = true)

theorem identity46119 : scanCanonicalize (H12AffineFastState.compose env46119 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46119 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env46120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13388,10280,1025,29789,4161,33,16,21762,8192,64,23808,5392,17665,10281,1364,32,257,21792,16465,512]

theorem envBound46120 : H12AffineFastState.Bounded env46120 := by
  intro p hp
  have h : env46120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46119_46120 : H12AffineEnvironment.transform 14 29788 env46119 = env46120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46119 == env46120) = true)

theorem identity46120 : scanCanonicalize (H12AffineFastState.compose env46120 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound46120 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env46121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4145,9325,8203,13388,10280,1025,9324,4161,33,16,1331,8192,64,3377,5392,5424,10281,1364,32,257,1297,4192,512]

theorem envBound46121 : H12AffineFastState.Bounded env46121 := by
  intro p hp
  have h : env46121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46120_46121 : H12AffineEnvironment.transform 13 4145 env46120 = env46121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env46120 == env46121) = true)

theorem identity46121 : scanCanonicalize (H12AffineFastState.compose env46121 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound46121 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3076,8192,3125,9325,8203,10312,10280,1025,9324,3141,33,16,1331,8192,64,3377,2324,2356,10281,1364,32,257,1297,3172,512]

theorem envBound46122 : H12AffineFastState.Bounded env46122 := by
  intro p hp
  have h : env46122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46121_46122 : H12AffineEnvironment.transform 11 3076 env46121 = env46122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env46121 == env46122) = true)

theorem identity46122 : scanCanonicalize (H12AffineFastState.compose env46122 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46122 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46123 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2144,8192,2129,8201,8203,10312,10280,101,8200,2081,33,16,343,8192,64,2389,2324,2356,10281,304,32,257,373,2048,512]

theorem envBound46123 : H12AffineFastState.Bounded env46123 := by
  intro p hp
  have h : env46123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46122_46123 : H12AffineEnvironment.transform 9 100 env46122 = env46123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46122 == env46123) = true)

theorem identity46123 : scanCanonicalize (H12AffineFastState.compose env46123 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46123 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env46124 : List Nat := [2,4,8,16,32,64,8,5,512,100,2048,2144,8192,2129,8201,8203,10312,10280,101,8200,2081,33,16,82,8192,64,2128,2065,2097,10281,53,32,4,112,2048,512]

theorem envBound46124 : H12AffineFastState.Bounded env46124 := by
  intro p hp
  have h : env46124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46123_46124 : H12AffineEnvironment.transform 7 5 env46123 = env46124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46123 == env46124) = true)

theorem identity46124 : scanCanonicalize (H12AffineFastState.compose env46124 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2632) := by decide +kernel

theorem selectedBound46124 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46125 : List Nat := [2,4,8,16,32,64,8,5,512,100,2048,2144,2632,2129,2625,2627,512,608,101,2624,2081,33,16,82,2632,64,2128,2065,2097,609,53,32,4,112,2048,512]

theorem envBound46125 : H12AffineFastState.Bounded env46125 := by
  intro p hp
  have h : env46125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46124_46125 : H12AffineEnvironment.transform 12 2632 env46124 = env46125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2632 env46124 == env46125) = true)

theorem identity46125 : scanCanonicalize (H12AffineFastState.compose env46125 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46125 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env46126 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,2064,2616,2081,2609,2611,512,528,21,2608,2081,33,16,34,2616,48,2080,2065,2097,529,53,32,4,0,2048,512]

theorem envBound46126 : H12AffineFastState.Bounded env46126 := by
  intro p hp
  have h : env46126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46125_46126 : H12AffineEnvironment.transform 5 48 env46125 = env46126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46125 == env46126) = true)

theorem identity46126 : scanCanonicalize (H12AffineFastState.compose env46126 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound46126 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env46127 : List Nat := [2,4,8,16,32,48,8,5,512,20,529,513,41,560,32,34,512,528,21,33,560,33,16,34,41,48,561,512,544,529,53,32,4,0,529,512]

theorem envBound46127 : H12AffineFastState.Bounded env46127 := by
  intro p hp
  have h : env46127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46126_46127 : H12AffineEnvironment.transform 10 529 env46126 = env46127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env46126 == env46127) = true)

theorem identity46127 : scanCanonicalize (H12AffineFastState.compose env46127 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound46127 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46128 : List Nat := [2,4,8,16,32,48,8,5,32,20,49,33,41,16,32,34,32,48,21,33,16,33,16,34,41,48,17,32,0,49,53,32,4,0,49,32]

theorem envBound46128 : H12AffineFastState.Bounded env46128 := by
  intro p hp
  have h : env46128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46127_46128 : H12AffineEnvironment.transform 8 32 env46127 = env46128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env46127 == env46128) = true)

def env46129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4161,392286,73755,41311,8193,64,43356,79131,91402,324700,1365,272392,257,21792,46092,74251]

theorem envBound46129 : H12AffineFastState.Bounded env46129 := by
  intro p hp
  have h : env46129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46116_46129 : H12AffineEnvironment.transform 6 9 env46116 = env46129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46116 == env46129) = true)

theorem identity46129 : scanCanonicalize (H12AffineFastState.compose env46129 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound46129 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,4161,54560,73755,41311,8193,64,43356,79131,91402,122146,1365,65910,257,21792,46092,74251]

theorem envBound46130 : H12AffineFastState.Bounded env46130 := by
  intro p hp
  have h : env46130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46129_46130 : H12AffineEnvironment.transform 17 76158 env46129 = env46130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env46129 == env46130) = true)

theorem identity46130 : scanCanonicalize (H12AffineFastState.compose env46130 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound46130 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,16401,32041,1025,32769,4161,54560,29772,41311,8193,64,43356,24908,12637,35189,1365,21793,257,21792,46092,30300]

theorem envBound46131 : H12AffineFastState.Bounded env46131 := by
  intro p hp
  have h : env46131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46130_46131 : H12AffineEnvironment.transform 15 21591 env46130 = env46131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env46130 == env46131) = true)

theorem identity46131 : scanCanonicalize (H12AffineFastState.compose env46131 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46131 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env46132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21591,16401,32041,1025,29789,4161,8572,29772,21763,8193,64,23808,24908,12637,32041,1365,21793,257,21792,16464,30300]

theorem envBound46132 : H12AffineFastState.Bounded env46132 := by
  intro p hp
  have h : env46132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46131_46132 : H12AffineEnvironment.transform 14 29788 env46131 = env46132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46131 == env46132) = true)

theorem identity46132 : scanCanonicalize (H12AffineFastState.compose env46132 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound46132 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,372,8575,13625,2049,1025,373,4161,8572,356,8235,8193,64,10280,5220,12637,2049,1365,8201,257,8200,13688,884]

theorem envBound46133 : H12AffineFastState.Bounded env46133 := by
  intro p hp
  have h : env46133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46132_46133 : H12AffineEnvironment.transform 13 13608 env46132 = env46133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env46132 == env46133) = true)

theorem identity46133 : scanCanonicalize (H12AffineFastState.compose env46133 (packedSelected [2,3,5,10,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46133 : packedSelected [2,3,5,10,12,14] rootPS < 2^1333 := by decide +kernel

def env46134 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,12620,372,8575,12637,2049,101,373,4161,8572,356,8235,8193,64,10280,4096,12637,2049,305,8201,257,8200,12572,884]

theorem envBound46134 : H12AffineFastState.Bounded env46134 := by
  intro p hp
  have h : env46134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46133_46134 : H12AffineEnvironment.transform 9 100 env46133 = env46134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46133 == env46134) = true)

theorem identity46134 : scanCanonicalize (H12AffineFastState.compose env46134 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46134 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46135 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,12345,1,8202,12328,2049,101,0,4161,8201,17,8235,8193,64,10280,4096,12328,2049,68,8201,116,8200,12393,513]

theorem envBound46135 : H12AffineFastState.Bounded env46135 := by
  intro p hp
  have h : env46135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46134_46135 : H12AffineEnvironment.transform 7 117 env46134 = env46135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46134 == env46135) = true)

def env46136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound46136 : H12AffineFastState.Bounded env46136 := by
  intro p hp
  have h : env46136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45407_46136 : H12AffineEnvironment.transform 25 65 env45407 = env46136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env45407 == env46136) = true)

def env46137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound46137 : H12AffineFastState.Bounded env46137 := by
  intro p hp
  have h : env46137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46136_46137 : H12AffineEnvironment.transform 26 30393344 env46136 = env46137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env46136 == env46137) = true)

def env46138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound46138 : H12AffineFastState.Bounded env46138 := by
  intro p hp
  have h : env46138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46137_46138 : H12AffineEnvironment.transform 18 1024 env46137 = env46138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46137 == env46138) = true)

theorem identity46138 : scanCanonicalize (H12AffineFastState.compose env46138 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874485) := by decide +kernel

theorem selectedBound46138 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874485,8328,65,4237813,10939768,10507601,8830977,454117,15076405,256,2534745,2510076,510514]

theorem envBound46139 : H12AffineFastState.Bounded env46139 := by
  intro p hp
  have h : env46139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46138_46139 : H12AffineEnvironment.transform 23 8874485 env46138 = env46139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874485 env46138 == env46139) = true)

def env46140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,8388608,8874485,8328,65,4237813,8393984,8826153,8830977,454117,12645453,256,21793,46212,510514]

theorem envBound46140 : H12AffineFastState.Bounded env46140 := by
  intro p hp
  have h : env46140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46139_46140 : H12AffineEnvironment.transform 20 456824 env46139 = env46140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env46139 == env46140) = true)

def env46141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,98781,8328,65,4237813,458024,17665,10281,454117,4594789,256,21793,46212,510514]

theorem envBound46141 : H12AffineFastState.Bounded env46141 := by
  intro p hp
  have h : env46141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46140_46141 : H12AffineEnvironment.transform 22 452648 env46140 = env46141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env46140 == env46141) = true)

def env46142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,98781,8328,65,295285,458024,17665,10281,454117,144613,256,21793,46212,510514]

theorem envBound46142 : H12AffineFastState.Bounded env46142 := by
  intro p hp
  have h : env46142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46141_46142 : H12AffineEnvironment.transform 21 272512 env46141 = env46142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46141 == env46142) = true)

theorem identity46142 : scanCanonicalize (H12AffineFastState.compose env46142 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound46142 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115870,201830,120014,98781,8328,65,245139,115150,17665,10281,119043,144613,256,21793,46212,63188]

theorem envBound46143 : H12AffineFastState.Bounded env46143 := by
  intro p hp
  have h : env46143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46142_46143 : H12AffineEnvironment.transform 17 212198 env46142 = env46143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env46142 == env46143) = true)

def env46144 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115870,201782,119966,98701,8328,17,245139,115102,17665,10281,119043,144565,256,21793,46212,63108]

theorem envBound46144 : H12AffineFastState.Bounded env46144 := by
  intro p hp
  have h : env46144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46143_46144 : H12AffineEnvironment.transform 5 16 env46143 = env46144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46143 == env46144) = true)

theorem identity46144 : scanCanonicalize (H12AffineFastState.compose env46144 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115103) := by decide +kernel

theorem selectedBound46144 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46145 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,115103,64809,1024,32769,115870,54697,119966,98701,8328,17,31756,115102,17665,10281,119043,128298,256,21793,46212,63108]

theorem envBound46145 : H12AffineFastState.Bounded env46145 := by
  intro p hp
  have h : env46145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46144_46145 : H12AffineEnvironment.transform 16 115103 env46144 = env46145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115103 env46144 == env46145) = true)

theorem identity46145 : scanCanonicalize (H12AffineFastState.compose env46145 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound46145 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env46146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,65536,115103,56492,1024,32769,115870,54697,119966,98701,269,17,23945,115102,17665,2476,119043,119983,256,21793,38145,55041]

theorem envBound46146 : H12AffineFastState.Bounded env46146 := by
  intro p hp
  have h : env46146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46145_46146 : H12AffineEnvironment.transform 12 389 env46145 = env46146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env46145 == env46146) = true)

theorem identity46146 : scanCanonicalize (H12AffineFastState.compose env46146 (packedSelected [2,6,9,11,14,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound46146 : packedSelected [2,6,9,11,14,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env46147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,54278,5529,56492,1024,32769,4248,54697,152,21899,269,17,23945,5528,17665,2476,1285,169,256,21793,38145,55041]

theorem envBound46147 : H12AffineFastState.Bounded env46147 := by
  intro p hp
  have h : env46147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46146_46147 : H12AffineEnvironment.transform 15 54278 env46146 = env46147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env46146 == env46147) = true)

theorem identity46147 : scanCanonicalize (H12AffineFastState.compose env46147 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound46147 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46148 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,32768,33167,5529,35109,1024,32769,4248,32800,152,2,269,17,2048,5528,4232,2476,1285,169,256,168,38145,33416]

theorem envBound46148 : H12AffineFastState.Bounded env46148 := by
  intro p hp
  have h : env46148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46147_46148 : H12AffineEnvironment.transform 13 5513 env46147 = env46148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env46147 == env46148) = true)

theorem identity46148 : scanCanonicalize (H12AffineFastState.compose env46148 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound46148 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env46149 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,137,262,5529,2476,1024,136,4248,169,152,2,269,17,2048,5528,4232,2476,1285,169,256,168,5512,513]

theorem envBound46149 : H12AffineFastState.Bounded env46149 := by
  intro p hp
  have h : env46149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46148_46149 : H12AffineEnvironment.transform 14 137 env46148 = env46149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env46148 == env46149) = true)

theorem identity46149 : scanCanonicalize (H12AffineFastState.compose env46149 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46149 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46150 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1024,0,4112,33,16,2,269,17,2048,5392,4096,2340,1285,33,256,32,5376,513]

theorem envBound46150 : H12AffineFastState.Bounded env46150 := by
  intro p hp
  have h : env46150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46149_46150 : H12AffineEnvironment.transform 6 8 env46149 = env46150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46149 == env46150) = true)

theorem identity46150 : scanCanonicalize (H12AffineFastState.compose env46150 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46151 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,35,5172,2049,1024,0,4112,33,16,2,40,17,2048,5173,4096,2049,1056,33,37,32,5157,513]

theorem envBound46151 : H12AffineFastState.Bounded env46151 := by
  intro p hp
  have h : env46151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46150_46151 : H12AffineEnvironment.transform 7 37 env46150 = env46151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46150 == env46151) = true)

theorem identity46151 : scanCanonicalize (H12AffineFastState.compose env46151 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46152 : List Nat := [2,4,8,16,32,16,8,37,512,1024,523,4096,40,5156,1,35,5172,522,1024,0,4112,33,16,2,40,17,523,5173,4096,522,1056,33,37,32,5157,513]

theorem envBound46152 : H12AffineFastState.Bounded env46152 := by
  intro p hp
  have h : env46152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46151_46152 : H12AffineEnvironment.transform 10 523 env46151 = env46152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46151 == env46152) = true)

theorem identity46152 : scanCanonicalize (H12AffineFastState.compose env46152 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46152 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46153 : List Nat := [2,4,8,16,0,16,8,5,512,1024,523,4096,8,5124,1,3,5140,522,1024,0,4112,1,16,2,8,17,523,5141,4096,522,1024,1,5,0,5125,513]

theorem envBound46153 : H12AffineFastState.Bounded env46153 := by
  intro p hp
  have h : env46153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46152_46153 : H12AffineEnvironment.transform 4 0 env46152 = env46153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46152 == env46153) = true)

def env46154 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115870,201783,119967,98700,8328,16,245139,115103,17665,10281,119043,144564,256,21793,46212,63109]

theorem envBound46154 : H12AffineFastState.Bounded env46154 := by
  intro p hp
  have h : env46154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46143_46154 : H12AffineEnvironment.transform 5 17 env46143 = env46154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46143 == env46154) = true)

theorem identity46154 : scanCanonicalize (H12AffineFastState.compose env46154 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound46154 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46155 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76079,1024,32769,115870,65967,119967,98700,8328,16,108555,115103,17665,10281,119043,8492,256,21793,46212,63109]

theorem envBound46155 : H12AffineFastState.Bounded env46155 := by
  intro p hp
  have h : env46155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46154_46155 : H12AffineEnvironment.transform 16 5528 env46154 = env46155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env46154 == env46155) = true)

theorem identity46155 : scanCanonicalize (H12AffineFastState.compose env46155 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound46155 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env46156 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,21647,5528,32160,1024,32769,36881,21792,32784,54531,8328,16,64644,38160,17665,10281,34188,8492,256,21793,46212,63109]

theorem envBound46156 : H12AffineFastState.Bounded env46156 := by
  intro p hp
  have h : env46156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46155_46156 : H12AffineEnvironment.transform 15 21647 env46155 = env46156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env46155 == env46156) = true)

theorem identity46156 : scanCanonicalize (H12AffineFastState.compose env46156 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound46156 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env46157 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21896,21647,5528,32160,1024,21897,17817,21792,21912,139,8328,16,10508,16536,17665,10281,20484,8492,256,21793,24844,8973]

theorem envBound46157 : H12AffineFastState.Bounded env46157 := by
  intro p hp
  have h : env46157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46156_46157 : H12AffineEnvironment.transform 14 21896 env46156 = env46157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env46156 == env46157) = true)

theorem identity46157 : scanCanonicalize (H12AffineFastState.compose env46157 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound46157 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env46158 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,8580,8323,5528,2476,1024,8581,12693,8492,8596,139,8328,16,10508,13460,12557,10281,9224,8492,256,8493,5376,8973]

theorem envBound46158 : H12AffineFastState.Bounded env46158 := by
  intro p hp
  have h : env46158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46157_46158 : H12AffineEnvironment.transform 13 13324 env46157 = env46158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env46157 == env46158) = true)

theorem identity46158 : scanCanonicalize (H12AffineFastState.compose env46158 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound46158 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env46159 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6429,3345,6297,6558,5528,2476,1024,6296,2184,6193,6281,139,6549,16,4113,3465,2064,4404,7445,6193,256,6192,5376,6672]

theorem envBound46159 : H12AffineFastState.Bounded env46159 := by
  intro p hp
  have h : env46159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46158_46159 : H12AffineEnvironment.transform 12 6429 env46158 = env46159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env46158 == env46159) = true)

theorem identity46159 : scanCanonicalize (H12AffineFastState.compose env46159 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound46159 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,4096,5133,1,5513,5262,5528,1212,1024,5512,1432,5409,5529,139,5253,16,4113,153,1280,4404,4101,5409,256,5408,5376,5888]

theorem envBound46160 : H12AffineFastState.Bounded env46160 := by
  intro p hp
  have h : env46160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46159_46160 : H12AffineEnvironment.transform 10 1296 env46159 = env46160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env46159 == env46160) = true)

theorem identity46160 : scanCanonicalize (H12AffineFastState.compose env46160 (packedSelected [1,4,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46160 : packedSelected [1,4,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env46161 : List Nat := [2,4,8,16,32,17,128,256,512,272,0,4096,4381,1,4249,4510,4232,428,272,4248,136,4145,4233,139,4501,16,4113,153,16,4404,4101,4145,256,4144,4112,4624]

theorem envBound46161 : H12AffineFastState.Bounded env46161 := by
  intro p hp
  have h : env46161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46160_46161 : H12AffineEnvironment.transform 9 272 env46160 = env46161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46160 == env46161) = true)

theorem identity46161 : scanCanonicalize (H12AffineFastState.compose env46161 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound46161 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env46162 : List Nat := [2,4,8,16,32,17,128,256,512,272,0,153,388,1,0,263,17,428,272,1,136,168,16,139,268,16,136,153,16,429,156,168,256,169,137,649]

theorem envBound46162 : H12AffineFastState.Bounded env46162 := by
  intro p hp
  have h : env46162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46161_46162 : H12AffineEnvironment.transform 11 153 env46161 = env46162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env46161 == env46162) = true)

theorem identity46162 : scanCanonicalize (H12AffineFastState.compose env46162 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound46162 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46163 : List Nat := [2,4,8,16,32,17,128,256,302,272,0,153,388,1,0,263,17,428,272,1,136,168,16,139,268,16,136,153,16,429,156,168,256,169,137,423]

theorem envBound46163 : H12AffineFastState.Bounded env46163 := by
  intro p hp
  have h : env46163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46162_46163 : H12AffineEnvironment.transform 8 302 env46162 = env46163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env46162 == env46163) = true)

theorem identity46163 : scanCanonicalize (H12AffineFastState.compose env46163 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46163 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46164 : List Nat := [2,4,8,16,32,17,128,36,10,52,0,153,160,1,0,35,17,136,52,1,136,168,16,139,40,16,136,153,16,137,156,168,36,169,137,131]

theorem envBound46164 : H12AffineFastState.Bounded env46164 := by
  intro p hp
  have h : env46164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46163_46164 : H12AffineEnvironment.transform 7 36 env46163 = env46164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46163 == env46164) = true)

theorem identity46164 : scanCanonicalize (H12AffineFastState.compose env46164 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound46164 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env46165 : List Nat := [2,4,8,16,4,17,128,0,10,16,0,153,132,1,0,7,17,136,16,1,136,140,16,139,12,16,136,153,16,137,156,140,0,141,137,131]

theorem envBound46165 : H12AffineFastState.Bounded env46165 := by
  intro p hp
  have h : env46165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46164_46165 : H12AffineEnvironment.transform 4 4 env46164 = env46165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env46164 == env46165) = true)

theorem identity46165 : scanCanonicalize (H12AffineFastState.compose env46165 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46165 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env46166 : List Nat := [2,1,8,16,1,17,128,0,10,16,0,153,129,1,0,2,17,136,16,1,136,137,16,139,9,16,136,153,16,137,153,137,0,136,137,131]

theorem envBound46166 : H12AffineFastState.Bounded env46166 := by
  intro p hp
  have h : env46166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46165_46166 : H12AffineEnvironment.transform 1 1 env46165 = env46166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46165 == env46166) = true)

theorem identity46166 : scanCanonicalize (H12AffineFastState.compose env46166 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound46166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46167 : List Nat := [2,1,8,2,1,3,128,0,10,2,0,139,129,1,0,2,3,136,2,1,136,137,2,139,9,2,136,139,2,137,139,137,0,136,137,131]

theorem envBound46167 : H12AffineFastState.Bounded env46167 := by
  intro p hp
  have h : env46167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46166_46167 : H12AffineEnvironment.transform 3 2 env46166 = env46167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env46166 == env46167) = true)

theorem identity46167 : scanCanonicalize (H12AffineFastState.compose env46167 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46167 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46168 : List Nat := [2,1,8,2,1,3,8,0,10,2,0,3,9,1,0,2,3,0,2,1,0,1,2,3,9,2,0,3,2,1,3,1,0,0,1,11]

theorem envBound46168 : H12AffineFastState.Bounded env46168 := by
  intro p hp
  have h : env46168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46167_46168 : H12AffineEnvironment.transform 6 8 env46167 = env46168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46167 == env46168) = true)

def env46169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,98781,8328,65,295284,458024,17665,10281,454117,144612,256,21793,46212,510514]

theorem envBound46169 : H12AffineFastState.Bounded env46169 := by
  intro p hp
  have h : env46169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46141_46169 : H12AffineEnvironment.transform 21 272513 env46141 = env46169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46141 == env46169) = true)

theorem identity46169 : scanCanonicalize (H12AffineFastState.compose env46169 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound46169 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456824,272513,452648,21763,8328,65,295284,458024,17665,10281,454117,144612,256,21793,46212,401132]

theorem envBound46170 : H12AffineFastState.Bounded env46170 := by
  intro p hp
  have h : env46170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46169_46170 : H12AffineEnvironment.transform 15 54494 env46169 = env46170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env46169 == env46170) = true)

def env46171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456824,272393,452648,21763,8192,65,295284,458024,17665,10281,453997,144492,256,21793,46092,400996]

theorem envBound46171 : H12AffineFastState.Bounded env46171 := by
  intro p hp
  have h : env46171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46170_46171 : H12AffineEnvironment.transform 6 8 env46170 = env46171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46170 == env46171) = true)

theorem identity46171 : scanCanonicalize (H12AffineFastState.compose env46171 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound46171 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env46172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35189,1024,32769,160013,41340,155997,21763,8192,65,2049,160861,17665,10281,156696,144492,256,21793,46092,169745]

theorem envBound46172 : H12AffineFastState.Bounded env46172 := by
  intro p hp
  have h : env46172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46171_46172 : H12AffineEnvironment.transform 17 35189 env46171 = env46172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env46171 == env46172) = true)

theorem identity46172 : scanCanonicalize (H12AffineFastState.compose env46172 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound46172 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,35189,1024,32769,58397,41340,62541,21763,8192,65,2049,57677,17665,10281,61704,41340,256,21793,46092,513]

theorem envBound46173 : H12AffineFastState.Bounded env46173 := by
  intro p hp
  have h : env46173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46172_46173 : H12AffineEnvironment.transform 16 38160 env46172 = env46173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env46172 == env46173) = true)

theorem identity46173 : scanCanonicalize (H12AffineFastState.compose env46173 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46173 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,38160,35189,1024,32769,45341,41340,41293,3,8192,65,2049,46157,4097,10281,41992,41340,256,33,46092,513]

theorem envBound46174 : H12AffineFastState.Bounded env46174 := by
  intro p hp
  have h : env46174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46173_46174 : H12AffineEnvironment.transform 13 5376 env46173 = env46174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46173 == env46174) = true)

theorem identity46174 : scanCanonicalize (H12AffineFastState.compose env46174 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46174 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33110,38160,35189,1024,32769,36880,32881,32832,3,269,65,2049,38208,4097,2340,34053,32881,256,33,38145,513]

theorem envBound46175 : H12AffineFastState.Bounded env46175 := by
  intro p hp
  have h : env46175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46174_46175 : H12AffineEnvironment.transform 12 269 env46174 = env46175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46174 == env46175) = true)

def env46176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456824,272392,452648,21763,8193,65,295284,458024,17665,10281,453996,144493,256,21793,46093,400997]

theorem envBound46176 : H12AffineFastState.Bounded env46176 := by
  intro p hp
  have h : env46176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46170_46176 : H12AffineEnvironment.transform 6 9 env46170 = env46176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46170 == env46176) = true)

theorem identity46176 : scanCanonicalize (H12AffineFastState.compose env46176 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 179229) := by decide +kernel

theorem selectedBound46176 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env46177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179229,1024,32769,17509,168981,21557,21763,8193,65,146793,16693,17665,10281,20849,144493,256,21793,46093,41592]

theorem envBound46177 : H12AffineFastState.Bounded env46177 := by
  intro p hp
  have h : env46177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46176_46177 : H12AffineEnvironment.transform 17 179229 env46176 = env46177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179229 env46176 == env46177) = true)

theorem identity46177 : scanCanonicalize (H12AffineFastState.compose env46177 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound46177 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env46178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,131072,179229,1024,32769,12344,168981,8296,8542,8193,65,146793,13672,12636,10281,9516,144493,256,8572,46093,41592]

theorem envBound46178 : H12AffineFastState.Bounded env46178 := by
  intro p hp
  have h : env46178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46177_46178 : H12AffineEnvironment.transform 13 13405 env46177 = env46178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env46177 == env46178) = true)

theorem identity46178 : scanCanonicalize (H12AffineFastState.compose env46178 (packedSelected [2,3,4,6,10,11,16,19,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound46178 : packedSelected [2,3,4,6,10,11,16,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env46179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,13624,35109,1024,32769,12344,41261,8296,8542,8193,65,2129,13672,12636,10281,9516,341,256,8572,46093,41592]

theorem envBound46179 : H12AffineFastState.Bounded env46179 := by
  intro p hp
  have h : env46179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46178_46179 : H12AffineEnvironment.transform 16 13624 env46178 = env46179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env46178 == env46179) = true)

theorem identity46179 : scanCanonicalize (H12AffineFastState.compose env46179 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46179 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env46180 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,40970,13624,35109,1024,32769,12344,41261,8248,8462,8193,17,2049,13624,12556,10281,9516,261,256,8492,46093,41512]

theorem envBound46180 : H12AffineFastState.Bounded env46180 := by
  intro p hp
  have h : env46180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46179_46180 : H12AffineEnvironment.transform 5 16 env46179 = env46180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46179 == env46180) = true)

theorem identity46180 : scanCanonicalize (H12AffineFastState.compose env46180 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46180 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46181 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,8202,13624,2341,1024,1,12344,8493,8248,8462,8193,17,2049,13624,12556,10281,9516,261,256,8492,13325,8744]

theorem envBound46181 : H12AffineFastState.Bounded env46181 := by
  intro p hp
  have h : env46181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46180_46181 : H12AffineEnvironment.transform 14 0 env46180 = env46181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46180 == env46181) = true)

theorem identity46181 : scanCanonicalize (H12AffineFastState.compose env46181 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46181 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env46182 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,0,8202,13341,2048,1024,1,12344,8200,8248,8235,8193,17,2049,13341,12329,10281,9225,32,37,8201,13325,8744]

theorem envBound46182 : H12AffineFastState.Bounded env46182 := by
  intro p hp
  have h : env46182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46181_46182 : H12AffineEnvironment.transform 7 37 env46181 = env46182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46181 == env46182) = true)

theorem identity46182 : scanCanonicalize (H12AffineFastState.compose env46182 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46182 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46183 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,12344,0,8202,12328,2048,53,1,12344,8200,8248,8235,8193,17,2049,12328,12329,10281,8252,32,37,8201,12344,8744]

theorem envBound46183 : H12AffineFastState.Bounded env46183 := by
  intro p hp
  have h : env46183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46182_46183 : H12AffineEnvironment.transform 9 53 env46182 = env46183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46182 == env46183) = true)

theorem identity46183 : scanCanonicalize (H12AffineFastState.compose env46183 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46183 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46184 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,4096,8192,12328,0,8202,12328,2048,37,1,12328,8200,8232,8235,8193,1,2049,12328,12329,10281,8236,32,37,8201,12328,8744]

theorem envBound46184 : H12AffineFastState.Bounded env46184 := by
  intro p hp
  have h : env46184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46183_46184 : H12AffineEnvironment.transform 3 0 env46183 = env46184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46183 == env46184) = true)

theorem identity46184 : scanCanonicalize (H12AffineFastState.compose env46184 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6185) := by decide +kernel

theorem selectedBound46184 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env46185 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,4096,6185,2049,0,6179,2049,2048,37,1,2049,6177,6145,6146,6184,1,2049,2049,2048,4096,6149,32,37,6176,2049,6657]

theorem envBound46185 : H12AffineFastState.Bounded env46185 := by
  intro p hp
  have h : env46185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46184_46185 : H12AffineEnvironment.transform 12 6185 env46184 = env46185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6185 env46184 == env46185) = true)

theorem identity46185 : scanCanonicalize (H12AffineFastState.compose env46185 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound46185 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46186 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,2049,40,2049,0,34,2049,2048,37,1,2049,32,0,3,41,1,2049,2049,2048,2049,4,32,37,33,2049,512]

theorem envBound46186 : H12AffineFastState.Bounded env46186 := by
  intro p hp
  have h : env46186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46185_46186 : H12AffineEnvironment.transform 11 2049 env46185 = env46186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env46185 == env46186) = true)

theorem identity46186 : scanCanonicalize (H12AffineFastState.compose env46186 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound46186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46187 : List Nat := [2,4,8,0,5,0,9,0,512,0,2048,2049,13,2049,0,7,2049,2048,0,1,2049,5,0,3,12,1,2049,2049,2048,2049,4,5,0,4,2049,512]

theorem envBound46187 : H12AffineFastState.Bounded env46187 := by
  intro p hp
  have h : env46187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46186_46187 : H12AffineEnvironment.transform 4 5 env46186 = env46187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env46186 == env46187) = true)

theorem identity46187 : scanCanonicalize (H12AffineFastState.compose env46187 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound46187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46188 : List Nat := [2,4,8,0,5,0,9,0,9,0,2048,2049,13,2049,0,7,2049,2048,0,1,2049,5,0,3,12,1,2049,2049,2048,2049,4,5,0,4,2049,9]

theorem envBound46188 : H12AffineFastState.Bounded env46188 := by
  intro p hp
  have h : env46188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46187_46188 : H12AffineEnvironment.transform 8 9 env46187 = env46188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env46187 == env46188) = true)

theorem identity46188 : scanCanonicalize (H12AffineFastState.compose env46188 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46189 : List Nat := [2,1,8,0,0,0,9,0,9,0,2048,2049,8,2049,0,2,2049,2048,0,1,2049,0,0,3,9,1,2049,2049,2048,2049,1,0,0,1,2049,9]

theorem envBound46189 : H12AffineFastState.Bounded env46189 := by
  intro p hp
  have h : env46189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46188_46189 : H12AffineEnvironment.transform 1 1 env46188 = env46189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46188 == env46189) = true)

theorem identity46189 : scanCanonicalize (H12AffineFastState.compose env46189 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound46189 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46190 : List Nat := [2,1,8,0,0,0,9,0,9,0,10,11,8,11,0,2,11,10,0,1,11,0,0,3,9,1,11,11,10,11,1,0,0,1,11,9]

theorem envBound46190 : H12AffineFastState.Bounded env46190 := by
  intro p hp
  have h : env46190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46189_46190 : H12AffineEnvironment.transform 10 10 env46189 = env46190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env46189 == env46190) = true)

theorem identity46190 : scanCanonicalize (H12AffineFastState.compose env46190 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound46190 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46191 : List Nat := [2,1,2,0,0,0,3,0,3,0,0,1,2,1,0,2,1,0,0,1,1,0,0,3,3,1,1,1,0,1,1,0,0,1,1,3]

theorem envBound46191 : H12AffineFastState.Bounded env46191 := by
  intro p hp
  have h : env46191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46190_46191 : H12AffineEnvironment.transform 2 2 env46190 = env46191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env46190 == env46191) = true)

def env46192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,98780,8328,65,4237813,458025,17664,10280,454117,4594788,256,21793,46212,510514]

theorem envBound46192 : H12AffineFastState.Bounded env46192 := by
  intro p hp
  have h : env46192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46140_46192 : H12AffineEnvironment.transform 22 452649 env46140 = env46192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env46140 == env46192) = true)

def env46193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,98780,8328,65,295285,458025,17664,10280,454117,144612,256,21793,46212,510514]

theorem envBound46193 : H12AffineFastState.Bounded env46193 := by
  intro p hp
  have h : env46193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46192_46193 : H12AffineEnvironment.transform 21 272512 env46192 = env46193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46192 == env46193) = true)

theorem identity46193 : scanCanonicalize (H12AffineFastState.compose env46193 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound46193 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254131,73754,98780,8328,65,215366,79130,17664,10280,75222,144612,256,21793,46212,513]

theorem envBound46194 : H12AffineFastState.Bounded env46194 := by
  intro p hp
  have h : env46194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46193_46194 : H12AffineEnvironment.transform 17 247859 env46193 = env46194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env46193 == env46194) = true)

theorem identity46194 : scanCanonicalize (H12AffineFastState.compose env46194 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46194 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env46195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,180409,16,41430,8328,65,158028,5392,17664,10280,1500,144612,256,21793,46212,513]

theorem envBound46195 : H12AffineFastState.Bounded env46195 := by
  intro p hp
  have h : env46195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46194_46195 : H12AffineEnvironment.transform 15 8202 env46194 = env46195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46194 == env46195) = true)

theorem identity46195 : scanCanonicalize (H12AffineFastState.compose env46195 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46195 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4161,32937,16,41430,8328,65,10588,5392,17664,10280,1500,29940,256,21793,46212,513]

theorem envBound46196 : H12AffineFastState.Bounded env46196 := by
  intro p hp
  have h : env46196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46195_46196 : H12AffineEnvironment.transform 16 16400 env46195 = env46196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46195 == env46196) = true)

theorem identity46196 : scanCanonicalize (H12AffineFastState.compose env46196 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46196 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env46197 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4113,32937,16,41350,8328,17,10508,5392,17664,10280,1420,29860,256,21793,46212,513]

theorem envBound46197 : H12AffineFastState.Bounded env46197 := by
  intro p hp
  have h : env46197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46196_46197 : H12AffineEnvironment.transform 5 16 env46196 = env46197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46196 == env46197) = true)

theorem identity46197 : scanCanonicalize (H12AffineFastState.compose env46197 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46197 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env46198 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,262,16400,35109,1024,32769,4113,32937,16,32906,388,17,2048,5392,17664,2340,1420,21928,256,21793,38280,513]

theorem envBound46198 : H12AffineFastState.Bounded env46198 := by
  intro p hp
  have h : env46198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46197_46198 : H12AffineEnvironment.transform 12 268 env46197 = env46198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46197 == env46198) = true)

theorem identity46198 : scanCanonicalize (H12AffineFastState.compose env46198 (packedSelected [3,6,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 22805) := by decide +kernel

theorem selectedBound46198 : packedSelected [3,6,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env46199 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,22805,262,16400,20528,1024,22804,4113,22972,16,22943,388,17,2048,5392,17664,2340,1420,21928,256,21793,19613,513]

theorem envBound46199 : H12AffineFastState.Bounded env46199 := by
  intro p hp
  have h : env46199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46198_46199 : H12AffineEnvironment.transform 14 22805 env46198 = env46199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22805 env46198 == env46199) = true)

theorem identity46199 : scanCanonicalize (H12AffineFastState.compose env46199 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46199 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env46200 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,22805,262,16400,20528,1024,22804,4113,22836,16,22807,268,17,2048,5392,17664,2340,1284,21792,256,21793,19477,513]

theorem envBound46200 : H12AffineFastState.Bounded env46200 := by
  intro p hp
  have h : env46200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46199_46200 : H12AffineEnvironment.transform 6 8 env46199 = env46200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46199 == env46200) = true)

theorem identity46200 : scanCanonicalize (H12AffineFastState.compose env46200 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46200 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,3093,262,5392,1328,1024,3092,4113,3124,16,3095,268,17,2048,5392,4096,2340,1284,32,256,33,6421,513]

theorem envBound46201 : H12AffineFastState.Bounded env46201 := by
  intro p hp
  have h : env46201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46200_46201 : H12AffineEnvironment.transform 13 5376 env46200 = env46201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46200 == env46201) = true)

theorem identity46201 : scanCanonicalize (H12AffineFastState.compose env46201 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound46201 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env46202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,560,4096,268,5376,1573,262,5392,1328,1024,1572,4113,1540,16,1575,268,17,560,5392,4096,788,1284,32,256,33,4901,513]

theorem envBound46202 : H12AffineFastState.Bounded env46202 := by
  intro p hp
  have h : env46202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46201_46202 : H12AffineEnvironment.transform 10 560 env46201 = env46202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env46201 == env46202) = true)

theorem identity46202 : scanCanonicalize (H12AffineFastState.compose env46202 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound46202 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46203 : List Nat := [2,4,8,16,32,16,8,256,512,1024,560,292,268,1060,1573,262,1076,1328,1024,1572,309,1540,16,1575,268,17,560,1076,292,788,1284,32,256,33,513,513]

theorem envBound46203 : H12AffineFastState.Bounded env46203 := by
  intro p hp
  have h : env46203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46202_46203 : H12AffineEnvironment.transform 11 292 env46202 = env46203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env46202 == env46203) = true)

theorem identity46203 : scanCanonicalize (H12AffineFastState.compose env46203 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46203 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env46204 : List Nat := [2,4,8,1,32,1,8,256,512,1024,545,292,268,1060,1573,262,1061,1313,1024,1572,292,1540,1,1575,268,0,545,1061,292,773,1284,32,256,33,513,513]

theorem envBound46204 : H12AffineFastState.Bounded env46204 := by
  intro p hp
  have h : env46204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46203_46204 : H12AffineEnvironment.transform 3 1 env46203 = env46204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46203 == env46204) = true)

theorem identity46204 : scanCanonicalize (H12AffineFastState.compose env46204 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46204 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env46205 : List Nat := [2,4,8,1,0,1,8,256,512,1024,513,260,268,1028,1541,262,1029,1281,1024,1540,260,1540,1,1543,268,0,513,1029,260,773,1284,0,256,1,513,513]

theorem envBound46205 : H12AffineFastState.Bounded env46205 := by
  intro p hp
  have h : env46205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46204_46205 : H12AffineEnvironment.transform 4 0 env46204 = env46205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46204 == env46205) = true)

theorem identity46205 : scanCanonicalize (H12AffineFastState.compose env46205 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound46205 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env46206 : List Nat := [2,4,8,1,0,1,8,256,512,517,513,260,268,513,0,262,512,772,517,1,260,1,1,2,268,0,513,512,260,773,769,0,256,1,513,513]

theorem envBound46206 : H12AffineFastState.Bounded env46206 := by
  intro p hp
  have h : env46206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46205_46206 : H12AffineEnvironment.transform 9 517 env46205 = env46206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env46205 == env46206) = true)

theorem identity46206 : scanCanonicalize (H12AffineFastState.compose env46206 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound46206 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46207 : List Nat := [2,4,8,1,0,1,8,256,260,257,261,260,268,261,0,262,260,0,257,1,260,1,1,2,268,0,261,260,260,1,5,0,256,1,261,261]

theorem envBound46207 : H12AffineFastState.Bounded env46207 := by
  intro p hp
  have h : env46207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46206_46207 : H12AffineEnvironment.transform 8 260 env46206 = env46207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env46206 == env46207) = true)

theorem identity46207 : scanCanonicalize (H12AffineFastState.compose env46207 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46208 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,1,9,0,0,3,1,0,4,1,1,1,1,2,9,0,0,1,1,1,5,0,5,1,0,0]

theorem envBound46208 : H12AffineFastState.Bounded env46208 := by
  intro p hp
  have h : env46208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46207_46208 : H12AffineEnvironment.transform 7 5 env46207 = env46208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46207 == env46208) = true)

def env46209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,98780,8328,65,295284,458025,17664,10280,454117,144613,256,21793,46212,510514]

theorem envBound46209 : H12AffineFastState.Bounded env46209 := by
  intro p hp
  have h : env46209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46192_46209 : H12AffineEnvironment.transform 21 272513 env46192 = env46209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46192 == env46209) = true)

theorem identity46209 : scanCanonicalize (H12AffineFastState.compose env46209 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46209 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456824,272513,452649,41430,8328,65,295284,458025,17664,10280,454117,144613,256,21793,46212,453176]

theorem envBound46210 : H12AffineFastState.Bounded env46210 := by
  intro p hp
  have h : env46210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46209_46210 : H12AffineEnvironment.transform 15 8202 env46209 = env46210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46209 == env46210) = true)

def env46211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,8388608,8874485,8328,65,4237813,8393985,8826152,8830977,454117,12645452,256,21792,46213,510514]

theorem envBound46211 : H12AffineFastState.Bounded env46211 := by
  intro p hp
  have h : env46211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46139_46211 : H12AffineEnvironment.transform 20 456825 env46139 = env46211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env46139 == env46211) = true)

def env46212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,98781,8328,65,4237813,458025,17664,10281,454117,4594788,256,21792,46213,510514]

theorem envBound46212 : H12AffineFastState.Bounded env46212 := by
  intro p hp
  have h : env46212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46211_46212 : H12AffineEnvironment.transform 22 452648 env46211 = env46212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env46211 == env46212) = true)

def env46213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,98781,8328,65,295285,458025,17664,10281,454117,144612,256,21792,46213,510514]

theorem envBound46213 : H12AffineFastState.Bounded env46213 := by
  intro p hp
  have h : env46213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46212_46213 : H12AffineEnvironment.transform 21 272512 env46212 = env46213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46212 == env46213) = true)

theorem identity46213 : scanCanonicalize (H12AffineFastState.compose env46213 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound46213 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396461,272512,400636,95497,8328,65,292257,395773,17664,10281,399665,144612,256,21792,16465,474854]

theorem envBound46214 : H12AffineFastState.Bounded env46214 := by
  intro p hp
  have h : env46214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46213_46214 : H12AffineEnvironment.transform 14 29908 env46213 = env46214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env46213 == env46214) = true)

def env46215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140301,32,144476,95497,8328,65,23809,139613,17664,10281,143761,144612,256,21792,16465,202310]

theorem envBound46215 : H12AffineFastState.Bounded env46215 := by
  intro p hp
  have h : env46215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46214_46215 : H12AffineEnvironment.transform 17 10400 env46214 = env46215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46214 == env46215) = true)

theorem identity46215 : scanCanonicalize (H12AffineFastState.compose env46215 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound46215 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env46216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,479,131072,10400,1024,29909,140301,32,144476,29910,8328,65,23809,139613,17664,10281,143761,144612,256,21792,16465,137113]

theorem envBound46216 : H12AffineFastState.Bounded env46216 := by
  intro p hp
  have h : env46216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46215_46216 : H12AffineEnvironment.transform 15 479 env46215 = env46216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env46215 == env46216) = true)

theorem identity46216 : scanCanonicalize (H12AffineFastState.compose env46216 (packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound46216 : packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env46217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,217,479,131072,10400,1024,216,140301,32,144476,219,8328,65,10508,139613,12557,10281,143761,144612,256,8493,13404,137113]

theorem envBound46217 : H12AffineFastState.Bounded env46217 := by
  intro p hp
  have h : env46217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46216_46217 : H12AffineEnvironment.transform 13 13325 env46216 = env46217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env46216 == env46217) = true)

theorem identity46217 : scanCanonicalize (H12AffineFastState.compose env46217 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13793) := by decide +kernel

theorem selectedBound46217 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env46218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,217,479,13793,10400,1024,216,4588,32,445,219,8328,65,10508,5308,12557,10281,1136,261,256,8493,13404,8824]

theorem envBound46218 : H12AffineFastState.Bounded env46218 := by
  intro p hp
  have h : env46218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46217_46218 : H12AffineEnvironment.transform 16 13793 env46217 = env46218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13793 env46217 == env46218) = true)

theorem identity46218 : scanCanonicalize (H12AffineFastState.compose env46218 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46218 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,217,479,5357,2476,1024,216,4588,32,445,219,388,65,2048,5308,4097,2341,1136,261,256,33,5456,884]

theorem envBound46219 : H12AffineFastState.Bounded env46219 := by
  intro p hp
  have h : env46219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46218_46219 : H12AffineEnvironment.transform 12 268 env46218 = env46219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46218 == env46219) = true)

theorem identity46219 : scanCanonicalize (H12AffineFastState.compose env46219 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46219 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46220 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5377,1,263,5173,2420,1024,0,4404,32,357,3,348,65,2048,5220,4097,2341,1136,261,256,33,5456,884]

theorem envBound46220 : H12AffineFastState.Bounded env46220 := by
  intro p hp
  have h : env46220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46219_46220 : H12AffineEnvironment.transform 6 88 env46219 = env46220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46219 == env46220) = true)

theorem identity46220 : scanCanonicalize (H12AffineFastState.compose env46220 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound46220 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env46221 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,268,4452,1,263,4176,2420,101,0,4404,32,357,3,348,65,2048,4097,4097,2341,21,261,256,33,4405,884]

theorem envBound46221 : H12AffineFastState.Bounded env46221 := by
  intro p hp
  have h : env46221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46220_46221 : H12AffineEnvironment.transform 9 101 env46220 = env46221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env46220 == env46221) = true)

theorem identity46221 : scanCanonicalize (H12AffineFastState.compose env46221 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46221 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46222 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,1,263,4097,2341,52,0,4404,32,308,3,269,16,2048,4097,4097,2341,21,261,256,33,4405,805]

theorem envBound46222 : H12AffineFastState.Bounded env46222 := by
  intro p hp
  have h : env46222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46221_46222 : H12AffineEnvironment.transform 5 17 env46221 = env46222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46221 == env46222) = true)

theorem identity46222 : scanCanonicalize (H12AffineFastState.compose env46222 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2826) := by decide +kernel

theorem selectedBound46222 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46223 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2826,268,2623,1,263,2827,2341,52,0,2622,32,308,3,269,16,2048,2827,2827,2341,21,261,256,33,2623,805]

theorem envBound46223 : H12AffineFastState.Bounded env46223 := by
  intro p hp
  have h : env46223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46222_46223 : H12AffineEnvironment.transform 11 2826 env46222 = env46223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2826 env46222 == env46223) = true)

theorem identity46223 : scanCanonicalize (H12AffineFastState.compose env46223 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 803) := by decide +kernel

theorem selectedBound46223 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env46224 : List Nat := [2,4,8,16,32,17,9,256,512,52,803,41,268,284,1,263,40,518,52,0,285,32,308,3,269,16,803,40,40,518,21,261,256,33,284,805]

theorem envBound46224 : H12AffineFastState.Bounded env46224 := by
  intro p hp
  have h : env46224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46223_46224 : H12AffineEnvironment.transform 10 803 env46223 = env46224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 803 env46223 == env46224) = true)

def env46225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140300,33,144477,95497,8328,65,23808,139612,17664,10281,143760,144612,256,21792,16465,202311]

theorem envBound46225 : H12AffineFastState.Bounded env46225 := by
  intro p hp
  have h : env46225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46214_46225 : H12AffineEnvironment.transform 17 10401 env46214 = env46225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46214 == env46225) = true)

theorem identity46225 : scanCanonicalize (H12AffineFastState.compose env46225 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound46225 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env46226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10401,1024,29909,82967,33,87110,95497,8328,65,23808,82247,17664,10281,86411,87295,256,21792,16465,30300]

theorem envBound46226 : H12AffineFastState.Bounded env46226 := by
  intro p hp
  have h : env46226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46225_46226 : H12AffineEnvironment.transform 16 90139 env46225 = env46226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env46225 == env46226) = true)

theorem identity46226 : scanCanonicalize (H12AffineFastState.compose env46226 (packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46226 : packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env46227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,65536,82246,2556,1024,21896,82967,33,87110,87124,469,65,23808,82247,17664,2420,86411,87295,256,21792,16465,22273]

theorem envBound46227 : H12AffineFastState.Bounded env46227 := by
  intro p hp
  have h : env46227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46226_46227 : H12AffineEnvironment.transform 12 349 env46226 = env46227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46226 == env46227) = true)

theorem identity46227 : scanCanonicalize (H12AffineFastState.compose env46227 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound46227 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env46228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,21726,5528,2556,1024,21896,4297,33,152,138,469,65,23808,5529,17664,2420,1365,33,256,21792,16465,22273]

theorem envBound46228 : H12AffineFastState.Bounded env46228 := by
  intro p hp
  have h : env46228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46227_46228 : H12AffineEnvironment.transform 15 21726 env46227 = env46228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env46227 == env46228) = true)

theorem identity46228 : scanCanonicalize (H12AffineFastState.compose env46228 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46228 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env46229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,478,5528,2556,1024,136,4297,33,152,138,469,65,2048,5529,4096,2420,1365,33,256,32,5457,513]

theorem envBound46229 : H12AffineFastState.Bounded env46229 := by
  intro p hp
  have h : env46229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46228_46229 : H12AffineEnvironment.transform 13 5376 env46228 = env46229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46228 == env46229) = true)

theorem identity46229 : scanCanonicalize (H12AffineFastState.compose env46229 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46229 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46230 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,137,398,5528,2476,1024,136,4249,33,152,138,389,17,2048,5529,4096,2340,1285,33,256,32,5377,513]

theorem envBound46230 : H12AffineFastState.Bounded env46230 := by
  intro p hp
  have h : env46230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46229_46230 : H12AffineEnvironment.transform 5 16 env46229 = env46230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46229 == env46230) = true)

theorem identity46230 : scanCanonicalize (H12AffineFastState.compose env46230 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46230 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46231 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5157,137,171,5309,2185,1024,136,4249,33,152,138,160,17,2048,5308,4096,2049,1056,33,37,32,5156,513]

theorem envBound46231 : H12AffineFastState.Bounded env46231 := by
  intro p hp
  have h : env46231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46230_46231 : H12AffineEnvironment.transform 7 37 env46230 = env46231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46230 == env46231) = true)

theorem identity46231 : scanCanonicalize (H12AffineFastState.compose env46231 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound46231 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46232 : List Nat := [2,4,8,16,32,16,128,37,512,1024,643,4096,40,5157,137,171,5309,522,1024,136,4249,33,152,138,160,17,643,5308,4096,642,1056,33,37,32,5156,513]

theorem envBound46232 : H12AffineFastState.Bounded env46232 := by
  intro p hp
  have h : env46232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46231_46232 : H12AffineEnvironment.transform 10 643 env46231 = env46232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env46231 == env46232) = true)

def env46233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,98781,8328,65,295284,458025,17664,10281,454117,144613,256,21792,46213,510514]

theorem envBound46233 : H12AffineFastState.Bounded env46233 := by
  intro p hp
  have h : env46233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46212_46233 : H12AffineEnvironment.transform 21 272513 env46212 = env46233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46212 == env46233) = true)

theorem identity46233 : scanCanonicalize (H12AffineFastState.compose env46233 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound46233 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,58517,144493,62660,98781,8328,65,171416,57797,17664,10281,61705,144613,256,21792,46213,120542]

theorem envBound46234 : H12AffineFastState.Bounded env46234 := by
  intro p hp
  have h : env46234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46233_46234 : H12AffineEnvironment.transform 17 138476 env46233 = env46234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env46233 == env46234) = true)

def env46235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144493,62540,98645,8192,65,171280,57677,17664,10281,61705,144493,256,21792,46093,120406]

theorem envBound46235 : H12AffineFastState.Bounded env46235 := by
  intro p hp
  have h : env46235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46234_46235 : H12AffineEnvironment.transform 6 8 env46234 = env46235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46234 == env46235) = true)

theorem identity46235 : scanCanonicalize (H12AffineFastState.compose env46235 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46235 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env46236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138340,1024,8541,17729,144493,21776,73737,8192,65,146508,16401,17664,10281,20565,144493,256,21792,5457,96010]

theorem envBound46236 : H12AffineFastState.Bounded env46236 := by
  intro p hp
  have h : env46236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46235_46236 : H12AffineEnvironment.transform 14 8540 env46235 = env46236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46235 == env46236) = true)

theorem identity46236 : scanCanonicalize (H12AffineFastState.compose env46236 (packedSelected [1,3,16,17,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound46236 : packedSelected [1,3,16,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env46237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16449,23589,1024,8541,17729,29740,21776,73737,8192,65,31757,16401,17664,10281,20565,29740,256,21792,5457,96010]

theorem envBound46237 : H12AffineFastState.Bounded env46237 := by
  intro p hp
  have h : env46237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46236_46237 : H12AffineEnvironment.transform 16 16449 env46236 = env46237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env46236 == env46237) = true)

theorem identity46237 : scanCanonicalize (H12AffineFastState.compose env46237 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound46237 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,263,16449,23589,1024,8541,17729,29740,21776,8462,8192,65,31757,16401,17664,10281,20565,29740,256,21792,5457,30221]

theorem envBound46238 : H12AffineFastState.Bounded env46238 := by
  intro p hp
  have h : env46238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46237_46238 : H12AffineEnvironment.transform 15 263 env46237 = env46238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env46237 == env46238) = true)

theorem identity46238 : scanCanonicalize (H12AffineFastState.compose env46238 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46238 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env46239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,263,16449,23589,1024,81,17729,21792,21776,2,268,65,23809,16401,17664,2341,20565,21792,256,21792,5457,22273]

theorem envBound46239 : H12AffineFastState.Bounded env46239 := by
  intro p hp
  have h : env46239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46238_46239 : H12AffineEnvironment.transform 12 268 env46238 = env46239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46238 == env46239) = true)

theorem identity46239 : scanCanonicalize (H12AffineFastState.compose env46239 (packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2656) := by decide +kernel

theorem selectedBound46239 : packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,2656,80,263,2593,5701,1024,81,3873,8000,8048,2,268,65,5985,2673,3936,2341,6709,8000,256,8000,5457,7521]

theorem envBound46240 : H12AffineFastState.Bounded env46240 := by
  intro p hp
  have h : env46240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46239_46240 : H12AffineEnvironment.transform 13 2656 env46239 = env46240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2656 env46239 == env46240) = true)

theorem identity46240 : scanCanonicalize (H12AffineFastState.compose env46240 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound46240 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env46241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3888,268,2656,80,263,2593,2421,1024,81,3873,112,64,2,268,65,2129,2673,3936,2341,1285,112,256,112,2657,593]

theorem envBound46241 : H12AffineFastState.Bounded env46241 := by
  intro p hp
  have h : env46241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46240_46241 : H12AffineEnvironment.transform 11 3888 env46240 = env46241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env46240 == env46241) = true)

theorem identity46241 : scanCanonicalize (H12AffineFastState.compose env46241 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46241 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env46242 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,3637,9,2656,80,2,2593,2160,1024,81,3620,112,64,2,9,65,2129,2673,3685,2080,1024,112,5,112,2657,593]

theorem envBound46242 : H12AffineFastState.Bounded env46242 := by
  intro p hp
  have h : env46242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46241_46242 : H12AffineEnvironment.transform 7 5 env46241 = env46242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46241 == env46242) = true)

theorem identity46242 : scanCanonicalize (H12AffineFastState.compose env46242 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound46242 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46243 : List Nat := [2,4,8,16,32,64,8,5,512,1024,97,1620,9,513,80,2,576,17,1024,81,1605,112,64,2,9,65,48,528,1540,65,1024,112,5,112,512,593]

theorem envBound46243 : H12AffineFastState.Bounded env46243 := by
  intro p hp
  have h : env46243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46242_46243 : H12AffineEnvironment.transform 10 97 env46242 = env46243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env46242 == env46243) = true)

theorem identity46243 : scanCanonicalize (H12AffineFastState.compose env46243 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound46243 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46244 : List Nat := [2,4,8,16,32,64,8,5,512,565,97,97,9,513,80,2,576,17,565,81,112,112,64,2,9,65,48,528,49,65,565,112,5,112,512,593]

theorem envBound46244 : H12AffineFastState.Bounded env46244 := by
  intro p hp
  have h : env46244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46243_46244 : H12AffineEnvironment.transform 9 565 env46243 = env46244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env46243 == env46244) = true)

theorem identity46244 : scanCanonicalize (H12AffineFastState.compose env46244 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound46244 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46245 : List Nat := [2,4,8,16,32,64,8,5,81,100,97,97,9,80,80,2,17,17,100,81,112,112,64,2,9,65,48,65,49,65,100,112,5,112,81,0]

theorem envBound46245 : H12AffineFastState.Bounded env46245 := by
  intro p hp
  have h : env46245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46244_46245 : H12AffineEnvironment.transform 8 81 env46244 = env46245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env46244 == env46245) = true)

theorem identity46245 : scanCanonicalize (H12AffineFastState.compose env46245 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46245 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env46246 : List Nat := [2,4,8,1,32,64,8,5,64,100,97,97,9,65,65,2,0,0,100,64,97,97,64,2,9,65,33,65,32,65,100,97,5,97,64,0]

theorem envBound46246 : H12AffineFastState.Bounded env46246 := by
  intro p hp
  have h : env46246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46245_46246 : H12AffineEnvironment.transform 3 1 env46245 = env46246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46245 == env46246) = true)

theorem identity46246 : scanCanonicalize (H12AffineFastState.compose env46246 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound46246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46247 : List Nat := [2,4,8,1,32,1,8,5,1,37,32,32,9,0,0,2,0,0,37,1,32,32,1,2,9,0,33,0,32,0,37,32,5,32,1,0]

theorem envBound46247 : H12AffineFastState.Bounded env46247 := by
  intro p hp
  have h : env46247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46246_46247 : H12AffineEnvironment.transform 5 1 env46246 = env46247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env46246 == env46247) = true)

theorem identity46247 : scanCanonicalize (H12AffineFastState.compose env46247 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46248 : List Nat := [2,4,8,1,0,1,8,5,1,5,0,0,9,0,0,2,0,0,5,1,0,0,1,2,9,0,1,0,0,0,5,0,5,0,1,0]

theorem envBound46248 : H12AffineFastState.Bounded env46248 := by
  intro p hp
  have h : env46248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46247_46248 : H12AffineEnvironment.transform 4 0 env46247 = env46248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46247 == env46248) = true)

def env46249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58396,144493,62541,98644,8193,65,171281,57676,17664,10281,61705,144492,256,21792,46092,120407]

theorem envBound46249 : H12AffineFastState.Bounded env46249 := by
  intro p hp
  have h : env46249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46234_46249 : H12AffineEnvironment.transform 6 9 env46234 = env46249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46234 == env46249) = true)

theorem identity46249 : scanCanonicalize (H12AffineFastState.compose env46249 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 62511) := by decide +kernel

theorem selectedBound46249 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env46250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62511,131072,138341,1024,32769,58396,144493,62541,30075,8193,65,171281,57676,17664,10281,61705,144492,256,21792,46092,8824]

theorem envBound46250 : H12AffineFastState.Bounded env46250 := by
  intro p hp
  have h : env46250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46249_46250 : H12AffineEnvironment.transform 15 62511 env46249 = env46250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62511 env46249 == env46250) = true)

theorem identity46250 : scanCanonicalize (H12AffineFastState.compose env46250 (packedSelected [0,3,4,10,11,14,16,22,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound46250 : packedSelected [0,3,4,10,11,14,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env46251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,35,131072,138341,1024,29709,4112,144493,65,30075,8193,65,157981,5440,17664,10281,1285,144492,256,21792,16384,8824]

theorem envBound46251 : H12AffineFastState.Bounded env46251 := by
  intro p hp
  have h : env46251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46250_46251 : H12AffineEnvironment.transform 14 29708 env46250 = env46251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env46250 == env46251) = true)

theorem identity46251 : scanCanonicalize (H12AffineFastState.compose env46251 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound46251 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env46252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,35,13673,10508,1024,29709,4112,260,65,30075,8193,65,23668,5440,17664,10281,1285,261,256,21792,16384,8824]

theorem envBound46252 : H12AffineFastState.Bounded env46252 := by
  intro p hp
  have h : env46252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46251_46252 : H12AffineEnvironment.transform 16 13673 env46251 = env46252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env46251 == env46252) = true)

theorem identity46252 : scanCanonicalize (H12AffineFastState.compose env46252 (packedSelected [2,3,5,6,9,10,11,12,14,15,16,17,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46252 : packedSelected [2,3,5,6,9,10,11,12,14,15,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env46253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,35,13673,10508,1024,8460,4112,260,65,8314,8193,65,2421,5440,4097,10281,1285,261,256,33,5377,8824]

theorem envBound46253 : H12AffineFastState.Bounded env46253 := by
  intro p hp
  have h : env46253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46252_46253 : H12AffineEnvironment.transform 13 5377 env46252 = env46253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46252 == env46253) = true)

theorem identity46253 : scanCanonicalize (H12AffineFastState.compose env46253 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46253 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,373,35,5393,2420,1024,372,4112,260,65,2,121,65,2421,5440,4097,2129,1285,261,256,33,5377,512]

theorem envBound46254 : H12AffineFastState.Bounded env46254 := by
  intro p hp
  have h : env46254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46253_46254 : H12AffineEnvironment.transform 12 120 env46253 = env46254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46253 == env46254) = true)

theorem identity46254 : scanCanonicalize (H12AffineFastState.compose env46254 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46254 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46255 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,9,5377,260,35,5393,2309,1024,261,4112,260,48,2,8,48,2308,5425,4097,2080,1285,261,256,33,5377,512]

theorem envBound46255 : H12AffineFastState.Bounded env46255 := by
  intro p hp
  have h : env46255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46254_46255 : H12AffineEnvironment.transform 5 49 env46254 = env46255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46254 == env46255) = true)

theorem identity46255 : scanCanonicalize (H12AffineFastState.compose env46255 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46255 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46256 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,9,5156,33,35,5172,2080,1024,32,4112,33,48,2,8,48,2081,5140,4097,2080,1056,32,37,33,5156,512]

theorem envBound46256 : H12AffineFastState.Bounded env46256 := by
  intro p hp
  have h : env46256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46255_46256 : H12AffineEnvironment.transform 7 37 env46255 = env46256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46255 == env46256) = true)

def env46257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,98780,8328,65,4237813,458024,17665,10280,454117,4594789,256,21792,46213,510514]

theorem envBound46257 : H12AffineFastState.Bounded env46257 := by
  intro p hp
  have h : env46257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46211_46257 : H12AffineEnvironment.transform 22 452649 env46211 = env46257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env46211 == env46257) = true)

def env46258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,98780,8328,65,295285,458024,17665,10280,454117,144613,256,21792,46213,510514]

theorem envBound46258 : H12AffineFastState.Bounded env46258 := by
  intro p hp
  have h : env46258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46257_46258 : H12AffineEnvironment.transform 21 272512 env46257 = env46258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46257 == env46258) = true)

def env46259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452649,98644,8192,65,295285,458024,17665,10280,453997,144493,256,21792,46093,510514]

theorem envBound46259 : H12AffineFastState.Bounded env46259 := by
  intro p hp
  have h : env46259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46258_46259 : H12AffineEnvironment.transform 6 8 env46258 = env46259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46258 == env46259) = true)

def env46260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272392,272441,98644,8192,65,295285,277816,17665,10280,273789,62589,256,21792,46093,330274]

theorem envBound46260 : H12AffineFastState.Bounded env46260 := by
  intro p hp
  have h : env46260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46259_46260 : H12AffineEnvironment.transform 16 49168 env46259 = env46260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env46259 == env46260) = true)

theorem identity46260 : scanCanonicalize (H12AffineFastState.compose env46260 (packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46260 : packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env46261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,33,16,98644,8192,65,43356,5393,17665,10280,1364,62589,256,21792,46093,74251]

theorem envBound46261 : H12AffineFastState.Bounded env46261 := by
  intro p hp
  have h : env46261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46260_46261 : H12AffineEnvironment.transform 17 10281 env46260 = env46261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46260 == env46261) = true)

theorem identity46261 : scanCanonicalize (H12AffineFastState.compose env46261 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound46261 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49168,10281,1024,32769,4160,33,16,8542,8192,65,43356,5393,17665,10280,1364,62589,256,21792,46093,33281]

theorem envBound46262 : H12AffineFastState.Bounded env46262 := by
  intro p hp
  have h : env46262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46261_46262 : H12AffineEnvironment.transform 15 40970 env46261 = env46262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env46261 == env46262) = true)

theorem identity46262 : scanCanonicalize (H12AffineFastState.compose env46262 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound46262 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env46263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21591,13389,10281,1024,29788,4160,33,16,8542,8192,65,23809,5393,17665,10280,1364,32,256,21792,16464,30300]

theorem envBound46263 : H12AffineFastState.Bounded env46263 := by
  intro p hp
  have h : env46263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46262_46263 : H12AffineEnvironment.transform 14 29789 env46262 = env46263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env46262 == env46263) = true)

theorem identity46263 : scanCanonicalize (H12AffineFastState.compose env46263 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46263 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,343,13389,10281,1024,8540,4160,33,16,8542,8192,65,2049,5393,4097,10280,1364,32,256,32,5456,9052]

theorem envBound46264 : H12AffineFastState.Bounded env46264 := by
  intro p hp
  have h : env46264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46263_46264 : H12AffineEnvironment.transform 13 5376 env46263 = env46264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46263 == env46264) = true)

theorem identity46264 : scanCanonicalize (H12AffineFastState.compose env46264 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound46264 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1296,343,4096,3172,1024,1297,4160,33,16,1299,1101,65,2049,5393,4097,3173,1364,32,256,32,5456,1809]

theorem envBound46265 : H12AffineFastState.Bounded env46265 := by
  intro p hp
  have h : env46265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46264_46265 : H12AffineEnvironment.transform 12 1101 env46264 = env46265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env46264 == env46265) = true)

theorem identity46265 : scanCanonicalize (H12AffineFastState.compose env46265 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound46265 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46266 : List Nat := [2,4,8,16,32,64,8,256,512,69,2048,4096,8,4421,341,343,4096,2081,69,340,4160,33,16,342,8,65,2049,4436,4097,2080,273,32,256,32,4373,852]

theorem envBound46266 : H12AffineFastState.Bounded env46266 := by
  intro p hp
  have h : env46266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46265_46266 : H12AffineEnvironment.transform 9 69 env46265 = env46266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env46265 == env46266) = true)

theorem identity46266 : scanCanonicalize (H12AffineFastState.compose env46266 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound46266 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env46267 : List Nat := [2,4,8,16,32,64,8,84,512,69,2048,4096,8,4113,1,3,4096,2081,69,0,4160,33,16,2,8,65,2049,4096,4097,2080,69,32,84,32,4161,512]

theorem envBound46267 : H12AffineFastState.Bounded env46267 := by
  intro p hp
  have h : env46267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46266_46267 : H12AffineEnvironment.transform 7 84 env46266 = env46267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env46266 == env46267) = true)

def env46268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272392,272440,98644,8192,65,295285,277817,17665,10280,273788,62588,256,21792,46093,330275]

theorem envBound46268 : H12AffineFastState.Bounded env46268 := by
  intro p hp
  have h : env46268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46259_46268 : H12AffineEnvironment.transform 16 49169 env46259 = env46268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env46259 == env46268) = true)

theorem identity46268 : scanCanonicalize (H12AffineFastState.compose env46268 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46268 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,33,17,98644,8192,65,43356,5392,17665,10280,1365,62588,256,21792,46093,74250]

theorem envBound46269 : H12AffineFastState.Bounded env46269 := by
  intro p hp
  have h : env46269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46268_46269 : H12AffineEnvironment.transform 17 10281 env46268 = env46269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46268 == env46269) = true)

theorem identity46269 : scanCanonicalize (H12AffineFastState.compose env46269 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound46269 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env46270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10281,1024,32769,4161,33,17,8542,8192,65,43356,5392,17665,10280,1365,62588,256,21792,46093,33280]

theorem envBound46270 : H12AffineFastState.Bounded env46270 := by
  intro p hp
  have h : env46270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46269_46270 : H12AffineEnvironment.transform 15 40970 env46269 = env46270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env46269 == env46270) = true)

theorem identity46270 : scanCanonicalize (H12AffineFastState.compose env46270 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound46270 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env46271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40970,46157,10281,1024,32769,4161,33,17,8542,8192,65,43356,5392,12637,10280,1365,32800,256,8572,46093,33280]

theorem envBound46271 : H12AffineFastState.Bounded env46271 := by
  intro p hp
  have h : env46271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46270_46271 : H12AffineEnvironment.transform 13 13404 env46270 = env46271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env46270 == env46271) = true)

theorem identity46271 : scanCanonicalize (H12AffineFastState.compose env46271 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46271 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env46272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,343,5392,10281,1024,8540,4161,33,17,8542,8192,65,2049,5392,12637,10280,1365,8573,256,8572,5456,9053]

theorem envBound46272 : H12AffineFastState.Bounded env46272 := by
  intro p hp
  have h : env46272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46271_46272 : H12AffineEnvironment.transform 14 8541 env46271 = env46272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46271 == env46272) = true)

theorem identity46272 : scanCanonicalize (H12AffineFastState.compose env46272 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound46272 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4364,1360,4177,343,5392,6437,1024,4176,4161,33,17,4178,4364,65,2049,5392,81,6436,1365,4209,256,4208,5456,4689]

theorem envBound46273 : H12AffineFastState.Bounded env46273 := by
  intro p hp
  have h : env46273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46272_46273 : H12AffineEnvironment.transform 12 4364 env46272 = env46273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env46272 == env46273) = true)

theorem identity46273 : scanCanonicalize (H12AffineFastState.compose env46273 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46273 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46274 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,4364,1281,4096,262,5392,6437,1024,4097,4112,33,17,4099,4364,16,2049,5392,0,6436,1284,4128,256,4129,5377,4608]

theorem envBound46274 : H12AffineFastState.Bounded env46274 := by
  intro p hp
  have h : env46274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46273_46274 : H12AffineEnvironment.transform 5 17 env46273 = env46274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46273 == env46274) = true)

theorem identity46274 : scanCanonicalize (H12AffineFastState.compose env46274 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound46274 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env46275 : List Nat := [2,4,8,16,32,17,8,256,512,288,2048,4096,4364,33,4096,262,4144,6437,288,4097,4112,33,17,4099,4364,16,2049,4144,0,6436,36,4128,256,4129,4129,4608]

theorem envBound46275 : H12AffineFastState.Bounded env46275 := by
  intro p hp
  have h : env46275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46274_46275 : H12AffineEnvironment.transform 9 288 env46274 = env46275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env46274 == env46275) = true)

theorem identity46275 : scanCanonicalize (H12AffineFastState.compose env46275 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46275 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env46276 : List Nat := [2,4,8,16,32,17,8,21,512,53,2048,4096,4121,33,4096,19,4144,6192,53,4097,4112,33,17,4099,4121,16,2049,4144,0,6193,36,4128,21,4129,4129,4608]

theorem envBound46276 : H12AffineFastState.Bounded env46276 := by
  intro p hp
  have h : env46276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46275_46276 : H12AffineEnvironment.transform 7 21 env46275 = env46276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46275 == env46276) = true)

theorem identity46276 : scanCanonicalize (H12AffineFastState.compose env46276 (packedSelected [2,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46276 : packedSelected [2,15,16] rootPS < 2^1333 := by decide +kernel

def env46277 : List Nat := [2,4,8,16,32,17,8,21,512,53,2048,1,24,33,1,19,49,2097,53,0,17,33,17,2,24,16,2049,49,0,2096,36,33,21,32,32,513]

theorem envBound46277 : H12AffineFastState.Bounded env46277 := by
  intro p hp
  have h : env46277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46276_46277 : H12AffineEnvironment.transform 11 1 env46276 = env46277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46276 == env46277) = true)

theorem identity46277 : scanCanonicalize (H12AffineFastState.compose env46277 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound46277 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46278 : List Nat := [2,4,8,16,32,17,8,21,512,53,10,1,24,33,1,19,49,59,53,0,17,33,17,2,24,16,11,49,0,58,36,33,21,32,32,513]

theorem envBound46278 : H12AffineFastState.Bounded env46278 := by
  intro p hp
  have h : env46278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46277_46278 : H12AffineEnvironment.transform 10 10 env46277 = env46278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env46277 == env46278) = true)

theorem identity46278 : scanCanonicalize (H12AffineFastState.compose env46278 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound46278 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46279 : List Nat := [2,4,8,16,32,17,8,21,44,53,10,1,24,33,1,19,49,59,53,0,17,33,17,2,24,16,11,49,0,58,36,33,21,32,32,45]

theorem envBound46279 : H12AffineFastState.Bounded env46279 := by
  intro p hp
  have h : env46279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46278_46279 : H12AffineEnvironment.transform 8 44 env46278 = env46279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env46278 == env46279) = true)

theorem identity46279 : scanCanonicalize (H12AffineFastState.compose env46279 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46279 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46280 : List Nat := [2,4,8,16,10,17,8,21,6,31,10,1,24,11,1,19,27,17,31,0,17,11,17,2,24,16,11,27,0,16,14,11,21,10,10,7]

theorem envBound46280 : H12AffineFastState.Bounded env46280 := by
  intro p hp
  have h : env46280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46279_46280 : H12AffineEnvironment.transform 4 10 env46279 = env46280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46279 == env46280) = true)

def env46281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452649,98645,8193,65,295285,458024,17665,10280,453996,144492,256,21792,46092,510514]

theorem envBound46281 : H12AffineFastState.Bounded env46281 := by
  intro p hp
  have h : env46281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46258_46281 : H12AffineEnvironment.transform 6 9 env46258 = env46281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46258 == env46281) = true)

theorem identity46281 : scanCanonicalize (H12AffineFastState.compose env46281 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound46281 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env46282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,100386,1024,32769,225371,106539,221195,98645,8193,65,67927,226570,17665,10280,222542,144492,256,21792,46092,147984]

theorem envBound46282 : H12AffineFastState.Bounded env46282 := by
  intro p hp
  have h : env46282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46281_46282 : H12AffineEnvironment.transform 17 100386 env46281 = env46282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env46281 == env46282) = true)

theorem identity46282 : scanCanonicalize (H12AffineFastState.compose env46282 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound46282 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,100386,1024,32769,102679,106539,98631,98645,8193,65,67927,103494,17665,10280,99330,54560,256,21792,46092,41820]

theorem envBound46283 : H12AffineFastState.Bounded env46283 := by
  intro p hp
  have h : env46283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46282_46283 : H12AffineEnvironment.transform 16 57676 env46282 = env46283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env46282 == env46283) = true)

def env46284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,98780,8328,65,295284,458024,17665,10280,454117,144612,256,21792,46213,510514]

theorem envBound46284 : H12AffineFastState.Bounded env46284 := by
  intro p hp
  have h : env46284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46257_46284 : H12AffineEnvironment.transform 21 272513 env46257 = env46284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46257 == env46284) = true)

theorem identity46284 : scanCanonicalize (H12AffineFastState.compose env46284 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound46284 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180408,16,98780,8328,65,158029,5393,17665,10280,1500,144612,256,21792,46213,74251]

theorem envBound46285 : H12AffineFastState.Bounded env46285 := by
  intro p hp
  have h : env46285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46284_46285 : H12AffineEnvironment.transform 17 190521 env46284 = env46285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env46284 == env46285) = true)

theorem identity46285 : scanCanonicalize (H12AffineFastState.compose env46285 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46285 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,180408,16,41430,8328,65,158029,5393,17665,10280,1500,144612,256,21792,46213,513]

theorem envBound46286 : H12AffineFastState.Bounded env46286 := by
  intro p hp
  have h : env46286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46285_46286 : H12AffineEnvironment.transform 15 8202 env46285 = env46286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46285 == env46286) = true)

theorem identity46286 : scanCanonicalize (H12AffineFastState.compose env46286 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound46286 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32937,16,41430,8328,65,10588,5393,17665,10280,1500,29941,256,21792,46213,513]

theorem envBound46287 : H12AffineFastState.Bounded env46287 := by
  intro p hp
  have h : env46287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46286_46287 : H12AffineEnvironment.transform 16 16401 env46286 = env46287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46286 == env46287) = true)

theorem identity46287 : scanCanonicalize (H12AffineFastState.compose env46287 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound46287 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13508,43048,1024,32769,4160,32937,16,41430,8328,65,10588,5393,12756,10280,1500,32,256,8693,46213,513]

theorem envBound46288 : H12AffineFastState.Bounded env46288 := by
  intro p hp
  have h : env46288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46287_46288 : H12AffineEnvironment.transform 13 13525 env46287 = env46288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env46287 == env46288) = true)

theorem identity46288 : scanCanonicalize (H12AffineFastState.compose env46288 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46288 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env46289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8541,8202,13508,2421,1024,8540,4160,8692,16,139,8328,65,10588,5393,12756,10280,1500,32,256,8693,5592,513]

theorem envBound46289 : H12AffineFastState.Bounded env46289 := by
  intro p hp
  have h : env46289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46288_46289 : H12AffineEnvironment.transform 14 8541 env46288 = env46289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46288 == env46289) = true)

theorem identity46289 : scanCanonicalize (H12AffineFastState.compose env46289 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound46289 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,478,5392,2421,1024,136,4160,32,16,139,348,65,2184,5393,4096,2556,1500,32,256,33,5592,513]

theorem envBound46290 : H12AffineFastState.Bounded env46290 := by
  intro p hp
  have h : env46290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46289_46290 : H12AffineEnvironment.transform 12 468 env46289 = env46290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env46289 == env46290) = true)

theorem identity46290 : scanCanonicalize (H12AffineFastState.compose env46290 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 3308) := by decide +kernel

theorem selectedBound46290 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3308,468,2541,137,478,2556,2421,1024,136,3244,32,16,139,348,65,2184,2557,3308,2556,1500,32,256,33,2356,513]

theorem envBound46291 : H12AffineFastState.Bounded env46291 := by
  intro p hp
  have h : env46291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46290_46291 : H12AffineEnvironment.transform 11 3308 env46290 = env46291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3308 env46290 == env46291) = true)

theorem identity46291 : scanCanonicalize (H12AffineFastState.compose env46291 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46291 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3172,348,2405,1,342,2420,2421,1024,0,3108,32,16,3,348,65,2048,2421,3172,2420,1364,32,256,33,2356,513]

theorem envBound46292 : H12AffineFastState.Bounded env46292 := by
  intro p hp
  have h : env46292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46291_46292 : H12AffineEnvironment.transform 6 8 env46291 = env46292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46291 == env46292) = true)

theorem identity46292 : scanCanonicalize (H12AffineFastState.compose env46292 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound46292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46293 : List Nat := [2,4,8,16,32,64,8,256,512,266,2048,2414,348,2405,1,342,2420,2421,266,0,2350,32,16,3,348,65,2048,2421,2414,2420,94,32,256,33,2356,513]

theorem envBound46293 : H12AffineFastState.Bounded env46293 := by
  intro p hp
  have h : env46293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46292_46293 : H12AffineEnvironment.transform 9 266 env46292 = env46293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env46292 == env46293) = true)

def env46294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound46294 : H12AffineFastState.Bounded env46294 := by
  intro p hp
  have h : env46294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46137_46294 : H12AffineEnvironment.transform 18 1025 env46137 = env46294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46137 == env46294) = true)

theorem identity46294 : scanCanonicalize (H12AffineFastState.compose env46294 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound46294 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575540,18973836,10507601,8538485,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound46295 : H12AffineFastState.Bounded env46295 := by
  intro p hp
  have h : env46295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46294_46295 : H12AffineEnvironment.transform 17 35189 env46294 = env46295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env46294 == env46295) = true)

def env46296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575540,18973700,10507601,8538485,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound46296 : H12AffineFastState.Bounded env46296 := by
  intro p hp
  have h : env46296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46295_46296 : H12AffineEnvironment.transform 6 8 env46295 = env46296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46295 == env46296) = true)

theorem identity46296 : scanCanonicalize (H12AffineFastState.compose env46296 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound46296 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env46297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29370734,18973700,10507601,8464751,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound46297 : H12AffineFastState.Bounded env46297 := by
  intro p hp
  have h : env46297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46296_46297 : H12AffineEnvironment.transform 16 90138 env46296 = env46297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env46296 == env46297) = true)

def env46298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,8388608,98644,8192,65,12691514,2098512,10507601,8464751,8389956,6349852,257,10503537,10527837,8462874]

theorem envBound46298 : H12AffineFastState.Bounded env46298 := by
  intro p hp
  have h : env46298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46297_46298 : H12AffineEnvironment.transform 23 98644 env46297 = env46298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98644 env46297 == env46298) = true)

theorem identity46298 : scanCanonicalize (H12AffineFastState.compose env46298 (packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound46298 : packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env46299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,98678,8388608,98644,8192,65,8399180,2098512,10507601,8464751,8389956,2188650,257,10503537,10527837,8462874]

theorem envBound46299 : H12AffineFastState.Bounded env46299 := by
  intro p hp
  have h : env46299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46298_46299 : H12AffineEnvironment.transform 21 98678 env46298 = env46299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env46298 == env46299) = true)

def env46300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,4160,98678,8388608,98644,8192,65,8399180,5392,8406289,8464751,8389956,95530,257,8410417,8434717,8462874]

theorem envBound46300 : H12AffineFastState.Bounded env46300 := by
  intro p hp
  have h : env46300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46299_46300 : H12AffineEnvironment.transform 20 4160 env46299 = env46300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46299 == env46300) = true)

theorem identity46300 : scanCanonicalize (H12AffineFastState.compose env46300 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound46300 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,4160,98678,73755,98644,8192,65,67927,5392,91402,2420,75103,95530,257,95530,103430,513]

theorem envBound46301 : H12AffineFastState.Bounded env46301 := by
  intro p hp
  have h : env46301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46300_46301 : H12AffineEnvironment.transform 22 73755 env46300 = env46301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env46300 == env46301) = true)

theorem identity46301 : scanCanonicalize (H12AffineFastState.compose env46301 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 20544) := by decide +kernel

theorem selectedBound46301 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env46302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20544,65536,90138,22837,1025,20545,4160,86326,73755,86292,8192,65,67927,5392,91402,2420,75103,95530,257,95530,83014,513]

theorem envBound46302 : H12AffineFastState.Bounded env46302 := by
  intro p hp
  have h : env46302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46301_46302 : H12AffineEnvironment.transform 14 20544 env46301 = env46302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20544 env46301 == env46302) = true)

theorem identity46302 : scanCanonicalize (H12AffineFastState.compose env46302 (packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound46302 : packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env46303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9528,65536,71010,11341,1025,9529,4160,74830,73755,74860,8192,65,67927,5392,69746,2420,75103,65618,257,65618,78142,513]

theorem envBound46303 : H12AffineFastState.Bounded env46303 := by
  intro p hp
  have h : env46303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46302_46303 : H12AffineEnvironment.transform 13 13688 env46302 = env46303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env46302 == env46303) = true)

theorem identity46303 : scanCanonicalize (H12AffineFastState.compose env46303 (packedSelected [3,4,5,7,9,10,11,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46303 : packedSelected [3,4,5,7,9,10,11,18,27] rootPS < 2^1333 := by decide +kernel

def env46304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9528,8202,13672,11341,1025,9529,4160,1092,17,1126,8192,65,10589,5392,12408,2420,1365,8280,257,8280,4404,513]

theorem envBound46304 : H12AffineFastState.Bounded env46304 := by
  intro p hp
  have h : env46304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46303_46304 : H12AffineEnvironment.transform 15 8202 env46303 = env46304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46303 == env46304) = true)

theorem identity46304 : scanCanonicalize (H12AffineFastState.compose env46304 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound46304 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env46305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,8192,9577,9528,8202,9593,11341,1025,9529,81,1092,17,1126,8192,65,10589,1281,8297,2420,1365,8280,257,8280,293,513]

theorem envBound46305 : H12AffineFastState.Bounded env46305 := by
  intro p hp
  have h : env46305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46304_46305 : H12AffineEnvironment.transform 11 17 env46304 = env46305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env46304 == env46305) = true)

def env46306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,4161,98678,8388608,98644,8192,65,8399180,5393,8406288,8464751,8389956,95531,257,8410416,8434716,8462874]

theorem envBound46306 : H12AffineFastState.Bounded env46306 := by
  intro p hp
  have h : env46306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46299_46306 : H12AffineEnvironment.transform 20 4161 env46299 = env46306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46299 == env46306) = true)

def env46307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,4161,98678,16,98644,8192,65,10588,5393,17664,76159,1364,95531,257,21792,46092,74250]

theorem envBound46307 : H12AffineFastState.Bounded env46307 := by
  intro p hp
  have h : env46307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46306_46307 : H12AffineEnvironment.transform 22 16 env46306 = env46307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46306 == env46307) = true)

def env46308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,4161,98678,17,98644,8192,65,10589,5393,17665,76158,1365,95531,257,21793,46093,74251]

theorem envBound46308 : H12AffineFastState.Bounded env46308 := by
  intro p hp
  have h : env46308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46306_46308 : H12AffineEnvironment.transform 22 17 env46306 = env46308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46306 == env46308) = true)

theorem identity46308 : scanCanonicalize (H12AffineFastState.compose env46308 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46308 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1025,8541,4161,73770,17,73736,8192,65,10589,5393,17665,76158,1365,95531,257,21793,5457,74251]

theorem envBound46309 : H12AffineFastState.Bounded env46309 := by
  intro p hp
  have h : env46309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46308_46309 : H12AffineEnvironment.transform 14 8540 env46308 = env46309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46308 == env46309) = true)

theorem identity46309 : scanCanonicalize (H12AffineFastState.compose env46309 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound46309 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env46310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8540,65536,78911,10281,1025,8541,4161,73770,17,73736,8192,65,10589,5393,4388,76158,1365,73998,257,260,5457,74251]

theorem envBound46310 : H12AffineFastState.Bounded env46310 := by
  intro p hp
  have h : env46310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46309_46310 : H12AffineEnvironment.transform 13 5157 env46309 = env46310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env46309 == env46310) = true)

theorem identity46310 : scanCanonicalize (H12AffineFastState.compose env46310 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46310 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,373,65536,70678,2048,1025,372,4161,65539,17,65569,41,65,2420,5393,4388,67927,1365,65831,257,260,5457,66082]

theorem envBound46311 : H12AffineFastState.Bounded env46311 := by
  intro p hp
  have h : env46311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46310_46311 : H12AffineEnvironment.transform 12 41 env46310 = env46311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46310 == env46311) = true)

theorem identity46311 : scanCanonicalize (H12AffineFastState.compose env46311 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound46311 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,373,342,5440,2048,1025,372,4161,341,17,375,41,65,2420,5393,4388,2049,1365,113,257,260,5457,884]

theorem envBound46312 : H12AffineFastState.Bounded env46312 := by
  intro p hp
  have h : env46312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46311_46312 : H12AffineEnvironment.transform 15 342 env46311 = env46312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env46311 == env46312) = true)

theorem identity46312 : scanCanonicalize (H12AffineFastState.compose env46312 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46312 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env46313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,41,3125,373,342,3408,2048,1025,372,2129,341,17,375,41,65,2420,3329,2356,2049,1365,113,257,260,3393,884]

theorem envBound46313 : H12AffineFastState.Bounded env46313 := by
  intro p hp
  have h : env46313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46312_46313 : H12AffineEnvironment.transform 11 2064 env46312 = env46313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46312 == env46313) = true)

theorem identity46313 : scanCanonicalize (H12AffineFastState.compose env46313 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46313 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env46314 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2064,41,2341,373,342,2112,2048,273,372,2129,341,17,375,41,65,2420,2065,2356,2049,69,113,257,260,2129,884]

theorem envBound46314 : H12AffineFastState.Bounded env46314 := by
  intro p hp
  have h : env46314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46313_46314 : H12AffineEnvironment.transform 9 272 env46313 = env46314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46313 == env46314) = true)

theorem identity46314 : scanCanonicalize (H12AffineFastState.compose env46314 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46314 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env46315 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,2064,41,2048,80,115,2112,2048,52,81,2129,112,17,82,41,65,2129,2065,2065,2049,69,113,36,33,2129,593]

theorem envBound46315 : H12AffineFastState.Bounded env46315 := by
  intro p hp
  have h : env46315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46314_46315 : H12AffineEnvironment.transform 7 37 env46314 = env46315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46314 == env46315) = true)

theorem identity46315 : scanCanonicalize (H12AffineFastState.compose env46315 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46315 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46316 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,41,2048,1,34,2065,2048,52,0,2048,33,17,3,41,16,2048,2065,2065,2049,20,32,36,33,2048,512]

theorem envBound46316 : H12AffineFastState.Bounded env46316 := by
  intro p hp
  have h : env46316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46315_46316 : H12AffineEnvironment.transform 5 17 env46315 = env46316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46315 == env46316) = true)

theorem identity46316 : scanCanonicalize (H12AffineFastState.compose env46316 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound46316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46317 : List Nat := [2,4,8,16,32,17,8,37,512,53,21,5,41,21,1,34,4,21,52,0,21,33,17,3,41,16,21,4,4,20,20,32,36,33,21,512]

theorem envBound46317 : H12AffineFastState.Bounded env46317 := by
  intro p hp
  have h : env46317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46316_46317 : H12AffineEnvironment.transform 10 21 env46316 = env46317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env46316 == env46317) = true)

theorem identity46317 : scanCanonicalize (H12AffineFastState.compose env46317 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound46317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46318 : List Nat := [2,4,8,7,32,6,8,37,512,34,2,5,41,2,1,34,4,2,35,0,2,33,6,3,41,7,2,4,4,3,3,32,36,33,2,512]

theorem envBound46318 : H12AffineFastState.Bounded env46318 := by
  intro p hp
  have h : env46318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46317_46318 : H12AffineEnvironment.transform 3 7 env46317 = env46318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env46317 == env46318) = true)

theorem identity46318 : scanCanonicalize (H12AffineFastState.compose env46318 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound46318 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46319 : List Nat := [2,4,8,7,3,6,8,6,512,1,2,5,10,2,1,1,4,2,0,0,2,2,6,3,10,7,2,4,4,3,3,3,7,2,2,512]

theorem envBound46319 : H12AffineFastState.Bounded env46319 := by
  intro p hp
  have h : env46319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46318_46319 : H12AffineEnvironment.transform 4 3 env46318 = env46319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env46318 == env46319) = true)

theorem identity46319 : scanCanonicalize (H12AffineFastState.compose env46319 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound46319 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46320 : List Nat := [2,4,8,7,3,6,8,6,9,1,2,5,10,2,1,1,4,2,0,0,2,2,6,3,10,7,2,4,4,3,3,3,7,2,2,9]

theorem envBound46320 : H12AffineFastState.Bounded env46320 := by
  intro p hp
  have h : env46320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46319_46320 : H12AffineEnvironment.transform 8 9 env46319 = env46320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env46319 == env46320) = true)

theorem identity46320 : scanCanonicalize (H12AffineFastState.compose env46320 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46320 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46321 : List Nat := [1,4,8,4,0,5,8,5,9,1,1,5,9,1,1,1,4,1,0,0,1,1,5,0,9,4,1,4,4,0,0,0,4,1,1,9]

theorem envBound46321 : H12AffineFastState.Bounded env46321 := by
  intro p hp
  have h : env46321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46320_46321 : H12AffineEnvironment.transform 0 1 env46320 = env46321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46320 == env46321) = true)

def env46322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,8388608,98645,8192,65,12691515,2098513,10507601,8464751,8389957,6349853,257,10503536,10527836,8462875]

theorem envBound46322 : H12AffineFastState.Bounded env46322 := by
  intro p hp
  have h : env46322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46297_46322 : H12AffineEnvironment.transform 23 98645 env46297 = env46322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env46297 == env46322) = true)

theorem identity46322 : scanCanonicalize (H12AffineFastState.compose env46322 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound46322 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,73754,98645,8192,65,4229153,2098513,2192715,2421,75103,6349853,257,2188650,2196550,513]

theorem envBound46323 : H12AffineFastState.Bounded env46323 := by
  intro p hp
  have h : env46323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46322_46323 : H12AffineEnvironment.transform 22 73754 env46322 = env46323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env46322 == env46323) = true)

theorem identity46323 : scanCanonicalize (H12AffineFastState.compose env46323 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound46323 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env46324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,73770,73754,98645,8192,65,108555,2098513,2192715,2421,75103,2212919,257,2188650,2196550,513]

theorem envBound46324 : H12AffineFastState.Bounded env46324 := by
  intro p hp
  have h : env46324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46323_46324 : H12AffineEnvironment.transform 21 73770 env46323 = env46324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env46323 == env46324) = true)

theorem identity46324 : scanCanonicalize (H12AffineFastState.compose env46324 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound46324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,91466,73770,73754,98645,8192,65,108555,90139,4097,2421,75103,41341,257,32,57612,513]

theorem envBound46325 : H12AffineFastState.Bounded env46325 := by
  intro p hp
  have h : env46325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46324_46325 : H12AffineEnvironment.transform 20 91466 env46324 = env46325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env46324 == env46325) = true)

theorem identity46325 : scanCanonicalize (H12AffineFastState.compose env46325 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound46325 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30776,1025,29004,91466,73770,73754,94232,8192,65,88390,90139,4097,2421,75103,20528,257,32,4161,513]

theorem envBound46326 : H12AffineFastState.Bounded env46326 := by
  intro p hp
  have h : env46326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46325_46326 : H12AffineEnvironment.transform 14 29005 env46325 = env46326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env46325 == env46326) = true)

theorem identity46326 : scanCanonicalize (H12AffineFastState.compose env46326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30776,1025,29004,17729,33,17,20499,8192,65,31053,16400,4097,2421,1364,20528,257,32,4161,513]

theorem envBound46327 : H12AffineFastState.Bounded env46327 := by
  intro p hp
  have h : env46327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46326_46327 : H12AffineEnvironment.transform 15 8203 env46326 = env46327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46326 == env46327) = true)

theorem identity46327 : scanCanonicalize (H12AffineFastState.compose env46327 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound46327 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,1,8203,12637,2420,1025,0,13325,33,17,8543,8192,65,2049,12636,4097,2421,1364,8572,257,32,4161,513]

theorem envBound46328 : H12AffineFastState.Bounded env46328 := by
  intro p hp
  have h : env46328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46327_46328 : H12AffineEnvironment.transform 13 12620 env46327 = env46328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env46327 == env46328) = true)

theorem identity46328 : scanCanonicalize (H12AffineFastState.compose env46328 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 632) := by decide +kernel

theorem selectedBound46328 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,632,4916,1,627,4901,2420,1025,0,5749,33,17,807,632,65,2049,4900,4097,2421,1364,772,257,32,4161,513]

theorem envBound46329 : H12AffineFastState.Bounded env46329 := by
  intro p hp
  have h : env46329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46328_46329 : H12AffineEnvironment.transform 12 632 env46328 = env46329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 632 env46328 == env46329) = true)

theorem identity46329 : scanCanonicalize (H12AffineFastState.compose env46329 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound46329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46330 : List Nat := [2,4,8,16,32,64,8,256,293,1024,2048,4096,349,4113,1,342,4096,2420,1025,0,5456,33,17,2,349,65,2049,4097,4097,2421,1364,33,257,32,4161,292]

theorem envBound46330 : H12AffineFastState.Bounded env46330 := by
  intro p hp
  have h : env46330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46329_46330 : H12AffineEnvironment.transform 8 293 env46329 = env46330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env46329 == env46330) = true)

theorem identity46330 : scanCanonicalize (H12AffineFastState.compose env46330 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound46330 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46331 : List Nat := [2,4,8,16,32,64,8,256,293,1024,2048,1297,349,1280,1,342,1297,2420,1025,0,65,33,17,2,349,65,2049,1296,1296,2421,1364,33,257,32,1360,292]

theorem envBound46331 : H12AffineFastState.Bounded env46331 := by
  intro p hp
  have h : env46331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46330_46331 : H12AffineEnvironment.transform 11 1297 env46330 = env46331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env46330 == env46331) = true)

theorem identity46331 : scanCanonicalize (H12AffineFastState.compose env46331 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46331 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46332 : List Nat := [2,4,8,16,32,64,8,256,293,272,2048,1,349,16,1,342,1,2420,273,0,65,33,17,2,349,65,2049,0,0,2421,68,33,257,32,64,292]

theorem envBound46332 : H12AffineFastState.Bounded env46332 := by
  intro p hp
  have h : env46332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46331_46332 : H12AffineEnvironment.transform 9 272 env46331 = env46332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46331 == env46332) = true)

theorem identity46332 : scanCanonicalize (H12AffineFastState.compose env46332 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound46332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46333 : List Nat := [2,4,8,16,32,64,8,101,64,117,2048,1,56,16,1,51,1,2065,116,0,65,33,17,2,56,65,2049,0,0,2064,68,33,100,32,64,65]

theorem envBound46333 : H12AffineFastState.Bounded env46333 := by
  intro p hp
  have h : env46333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46332_46333 : H12AffineEnvironment.transform 7 101 env46332 = env46333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env46332 == env46333) = true)

theorem identity46333 : scanCanonicalize (H12AffineFastState.compose env46333 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46333 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46334 : List Nat := [2,4,8,16,1,64,8,68,64,84,2048,1,25,16,1,18,1,2065,85,0,65,0,17,2,25,65,2049,0,0,2064,68,0,69,1,64,65]

theorem envBound46334 : H12AffineFastState.Bounded env46334 := by
  intro p hp
  have h : env46334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46333_46334 : H12AffineEnvironment.transform 4 1 env46333 = env46334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46333 == env46334) = true)

theorem identity46334 : scanCanonicalize (H12AffineFastState.compose env46334 (packedSelected [0,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46334 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env46335 : List Nat := [2,4,8,0,1,64,8,68,64,68,2048,1,9,0,1,2,1,2049,69,0,65,0,1,2,9,65,2049,0,0,2048,68,0,69,1,64,65]

theorem envBound46335 : H12AffineFastState.Bounded env46335 := by
  intro p hp
  have h : env46335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46334_46335 : H12AffineEnvironment.transform 3 0 env46334 = env46335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46334 == env46335) = true)

theorem identity46335 : scanCanonicalize (H12AffineFastState.compose env46335 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound46335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46336 : List Nat := [2,4,8,0,1,64,8,68,64,68,64,1,9,0,1,2,1,65,69,0,65,0,1,2,9,65,65,0,0,64,68,0,69,1,64,65]

theorem envBound46336 : H12AffineFastState.Bounded env46336 := by
  intro p hp
  have h : env46336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46335_46336 : H12AffineEnvironment.transform 10 64 env46335 = env46336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env46335 == env46336) = true)

def env46337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575540,18973701,10507601,8538485,25265168,23160137,257,27378724,27337993,25207631]

theorem envBound46337 : H12AffineFastState.Bounded env46337 := by
  intro p hp
  have h : env46337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46295_46337 : H12AffineEnvironment.transform 6 9 env46295 = env46337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46295 == env46337) = true)

def env46338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,16777216,8193,65,21039476,18973701,2233681,2421,17024016,23160137,257,19104804,19096841,16966479]

theorem envBound46338 : H12AffineFastState.Bounded env46338 := by
  intro p hp
  have h : env46338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46337_46338 : H12AffineEnvironment.transform 22 147456 env46337 = env46338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env46337 == env46338) = true)

def env46339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,16777216,8193,65,21039476,18973701,2118977,2421,16876544,23160137,257,18990132,18949401,16819039]

theorem envBound46339 : H12AffineFastState.Bounded env46339 := by
  intro p hp
  have h : env46339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46338_46339 : H12AffineEnvironment.transform 16 16400 env46338 = env46339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46338 == env46339) = true)

theorem identity46339 : scanCanonicalize (H12AffineFastState.compose env46339 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46339 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env46340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,2097152,4194304,16,16777216,8193,65,21039476,18949465,2118977,2421,16852316,23160137,257,18965864,18949401,16777731]

theorem envBound46340 : H12AffineFastState.Bounded env46340 := by
  intro p hp
  have h : env46340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46339_46340 : H12AffineEnvironment.transform 14 8540 env46339 = env46340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46339 == env46340) = true)

theorem identity46340 : scanCanonicalize (H12AffineFastState.compose env46340 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 65876) := by decide +kernel

theorem selectedBound46340 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env46341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,2097152,4194304,16,65876,8193,65,4196384,2106381,2118977,2421,9224,6317085,257,2122812,2106445,66391]

theorem envBound46341 : H12AffineFastState.Bounded env46341 := by
  intro p hp
  have h : env46341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46340_46341 : H12AffineEnvironment.transform 23 65876 env46340 = env46341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65876 env46340 == env46341) = true)

theorem identity46341 : scanCanonicalize (H12AffineFastState.compose env46341 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound46341 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS < 2^1333 := by decide +kernel

def env46342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,17680,4194304,16,65876,8193,65,4196384,24861,4177,2421,9224,4202765,257,8492,24925,66391]

theorem envBound46342 : H12AffineFastState.Bounded env46342 := by
  intro p hp
  have h : env46342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46341_46342 : H12AffineEnvironment.transform 20 17680 env46341 = env46342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env46341 == env46342) = true)

theorem identity46342 : scanCanonicalize (H12AffineFastState.compose env46342 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound46342 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env46343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,17680,8572,16,65876,8193,65,10588,24861,4177,2421,9224,113,257,8492,24925,66391]

theorem envBound46343 : H12AffineFastState.Bounded env46343 := by
  intro p hp
  have h : env46343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46342_46343 : H12AffineEnvironment.transform 21 8572 env46342 = env46343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env46342 == env46343) = true)

theorem identity46343 : scanCanonicalize (H12AffineFastState.compose env46343 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46343 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env46344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,65536,16400,2421,1025,1,17680,32,16,65876,349,65,2048,16449,4177,2421,1364,113,257,112,16385,66391]

theorem envBound46344 : H12AffineFastState.Bounded env46344 := by
  intro p hp
  have h : env46344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46343_46344 : H12AffineEnvironment.transform 12 348 env46343 = env46344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46343 == env46344) = true)

theorem identity46344 : scanCanonicalize (H12AffineFastState.compose env46344 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2145) := by decide +kernel

theorem selectedBound46344 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2145,348,16384,0,65536,16400,2421,1025,1,17680,32,16,65876,349,65,2048,16449,2096,2421,1364,113,257,112,16385,66391]

theorem envBound46345 : H12AffineFastState.Bounded env46345 := by
  intro p hp
  have h : env46345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46344_46345 : H12AffineEnvironment.transform 11 2145 env46344 = env46345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2145 env46344 == env46345) = true)

theorem identity46345 : scanCanonicalize (H12AffineFastState.compose env46345 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46345 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46346 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2065,300,16384,0,65536,16400,2309,1025,1,17680,32,16,65828,301,49,2048,16433,2096,2309,1316,1,257,0,16385,66343]

theorem envBound46346 : H12AffineFastState.Bounded env46346 := by
  intro p hp
  have h : env46346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0