import H12CloudChart0Data184

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound46845 : H12AffineFastState.Bounded env46845 := by
  intro p hp
  have h : env46845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46844_46845 : H12AffineEnvironment.transform 4 1 env46844 = env46845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46844 == env46845) = true)

theorem identity46845 : scanCanonicalize (H12AffineFastState.compose env46845 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46845 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46846 : List Nat := [2,4,8,16,1,17,9,4,10,21,0,16,8,0,1,3,16,1,20,0,0,0,16,2,9,16,1,16,17,1,21,1,5,1,1,11]

theorem envBound46846 : H12AffineFastState.Bounded env46846 := by
  intro p hp
  have h : env46846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46845_46846 : H12AffineEnvironment.transform 7 4 env46845 = env46846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46845 == env46846) = true)

theorem identity46846 : scanCanonicalize (H12AffineFastState.compose env46846 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound46846 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46847 : List Nat := [2,4,8,14,1,15,9,4,10,11,0,14,8,0,1,3,14,1,10,0,0,0,14,2,9,14,1,14,15,1,11,1,5,1,1,11]

theorem envBound46847 : H12AffineFastState.Bounded env46847 := by
  intro p hp
  have h : env46847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46846_46847 : H12AffineEnvironment.transform 3 14 env46846 = env46847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env46846 == env46847) = true)

theorem identity46847 : scanCanonicalize (H12AffineFastState.compose env46847 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46848 : List Nat := [2,4,5,3,1,2,4,4,7,6,0,3,5,0,1,3,3,1,7,0,0,0,3,2,4,3,1,3,2,1,6,1,5,1,1,6]

theorem envBound46848 : H12AffineFastState.Bounded env46848 := by
  intro p hp
  have h : env46848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46847_46848 : H12AffineEnvironment.transform 2 5 env46847 = env46848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46847 == env46848) = true)

def env46849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294201,98780,8328,65,398436,288824,17664,179512,293109,41460,257,21793,46212,352035]

theorem envBound46849 : H12AffineFastState.Bounded env46849 := by
  intro p hp
  have h : env46849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46790_46849 : H12AffineEnvironment.transform 21 272513 env46790 = env46849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46790 == env46849) = true)

theorem identity46849 : scanCanonicalize (H12AffineFastState.compose env46849 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound46849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,290152,272513,294201,95497,8328,65,398436,288824,17664,149997,293109,21793,257,21793,16465,352035]

theorem envBound46850 : H12AffineFastState.Bounded env46850 := by
  intro p hp
  have h : env46850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46849_46850 : H12AffineEnvironment.transform 14 29909 env46849 = env46850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env46849 == env46850) = true)

theorem identity46850 : scanCanonicalize (H12AffineFastState.compose env46850 (packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound46850 : packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS < 2^1333 := by decide +kernel

def env46851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,131072,262144,1025,29908,290152,272513,294201,139,8328,65,398436,288824,17664,149997,293109,21793,257,21793,16465,273057]

theorem envBound46851 : H12AffineFastState.Bounded env46851 := by
  intro p hp
  have h : env46851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46850_46851 : H12AffineEnvironment.transform 15 30082 env46850 = env46851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env46850 == env46851) = true)

theorem identity46851 : scanCanonicalize (H12AffineFastState.compose env46851 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound46851 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,131072,2476,1025,29908,25796,8493,29845,139,8328,65,138696,24980,17664,149997,29017,21793,257,21793,16465,8973]

theorem envBound46852 : H12AffineFastState.Bounded env46852 := by
  intro p hp
  have h : env46852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46851_46852 : H12AffineEnvironment.transform 17 2476 env46851 = env46852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env46851 == env46852) = true)

theorem identity46852 : scanCanonicalize (H12AffineFastState.compose env46852 (packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 12512) := by decide +kernel

theorem selectedBound46852 : packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env46853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12512,1077,1378,131072,2476,1025,1076,5156,8493,1141,139,8328,65,138696,4468,13792,145677,441,9665,257,9665,12465,8973]

theorem envBound46853 : H12AffineFastState.Bounded env46853 := by
  intro p hp
  have h : env46853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46852_46853 : H12AffineEnvironment.transform 13 12512 env46852 = env46853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12512 env46852 == env46853) = true)

theorem identity46853 : scanCanonicalize (H12AffineFastState.compose env46853 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 12328) := by decide +kernel

theorem selectedBound46853 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env46854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12512,1077,1378,12328,2476,1025,1076,5156,8493,1141,139,8328,65,11744,4468,13792,2341,441,9665,257,9665,12465,8973]

theorem envBound46854 : H12AffineFastState.Bounded env46854 := by
  intro p hp
  have h : env46854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46853_46854 : H12AffineEnvironment.transform 16 12328 env46853 = env46854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12328 env46853 == env46854) = true)

theorem identity46854 : scanCanonicalize (H12AffineFastState.compose env46854 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 7380) := by decide +kernel

theorem selectedBound46854 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env46855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7380,3124,1077,1378,3324,2476,1025,1076,5156,7673,1141,139,7260,65,4404,4468,2356,2341,441,6421,257,6421,3173,8153]

theorem envBound46855 : H12AffineFastState.Bounded env46855 := by
  intro p hp
  have h : env46855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46854_46855 : H12AffineEnvironment.transform 12 7380 env46854 = env46855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7380 env46854 == env46855) = true)

theorem identity46855 : scanCanonicalize (H12AffineFastState.compose env46855 (packedSelected [1,2,3,4,5,6,8,9,10,11,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound46855 : packedSelected [1,2,3,4,5,6,8,9,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env46856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,309,3553,3124,1077,1378,3324,2476,1025,1076,1297,3276,1141,139,3433,65,1,65,2356,2341,441,2080,257,2080,3173,3820]

theorem envBound46856 : H12AffineFastState.Bounded env46856 := by
  intro p hp
  have h : env46856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46855_46856 : H12AffineEnvironment.transform 11 309 env46855 = env46856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env46855 == env46856) = true)

theorem identity46856 : scanCanonicalize (H12AffineFastState.compose env46856 (packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound46856 : packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46857 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,309,2088,2557,508,171,2357,2476,456,509,216,2309,444,139,2208,65,1,65,2356,2341,441,2080,257,2080,2476,2853]

theorem envBound46857 : H12AffineFastState.Bounded env46857 := by
  intro p hp
  have h : env46857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46856_46857 : H12AffineEnvironment.transform 9 457 env46856 = env46857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env46856 == env46857) = true)

theorem identity46857 : scanCanonicalize (H12AffineFastState.compose env46857 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46857 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46858 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,17,2088,2265,216,171,2065,2184,236,217,216,2081,152,139,2208,65,1,65,2064,2049,157,2080,37,2080,2184,2561]

theorem envBound46858 : H12AffineFastState.Bounded env46858 := by
  intro p hp
  have h : env46858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46857_46858 : H12AffineEnvironment.transform 7 36 env46857 = env46858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46857 == env46858) = true)

theorem identity46858 : scanCanonicalize (H12AffineFastState.compose env46858 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound46858 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46859 : List Nat := [2,4,8,16,32,64,128,36,512,237,80,17,120,137,216,171,65,216,236,217,216,113,152,139,240,65,1,65,64,81,157,112,37,112,216,593]

theorem envBound46859 : H12AffineFastState.Bounded env46859 := by
  intro p hp
  have h : env46859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46858_46859 : H12AffineEnvironment.transform 10 80 env46858 = env46859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env46858 == env46859) = true)

theorem identity46859 : scanCanonicalize (H12AffineFastState.compose env46859 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46859 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46860 : List Nat := [2,4,8,16,32,64,89,36,512,52,80,17,120,80,1,114,65,1,53,0,1,113,65,82,41,65,1,65,64,81,68,112,37,112,1,593]

theorem envBound46860 : H12AffineFastState.Bounded env46860 := by
  intro p hp
  have h : env46860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46859_46860 : H12AffineEnvironment.transform 6 89 env46859 = env46860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46859 == env46860) = true)

theorem identity46860 : scanCanonicalize (H12AffineFastState.compose env46860 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46860 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46861 : List Nat := [2,4,8,16,0,64,89,4,512,20,80,17,88,80,1,82,65,1,21,0,1,81,65,82,9,65,1,65,64,81,68,80,5,80,1,593]

theorem envBound46861 : H12AffineFastState.Bounded env46861 := by
  intro p hp
  have h : env46861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46860_46861 : H12AffineEnvironment.transform 4 0 env46860 = env46861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46860 == env46861) = true)

theorem identity46861 : scanCanonicalize (H12AffineFastState.compose env46861 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46862 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,17,9,1,1,3,16,1,21,0,1,0,16,3,9,16,1,16,17,0,21,1,5,1,1,512]

theorem envBound46862 : H12AffineFastState.Bounded env46862 := by
  intro p hp
  have h : env46862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46861_46862 : H12AffineEnvironment.transform 5 17 env46861 = env46862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46861 == env46862) = true)

theorem identity46862 : scanCanonicalize (H12AffineFastState.compose env46862 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46862 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46863 : List Nat := [2,4,8,1,0,0,8,4,512,5,1,0,9,1,1,3,1,1,4,0,1,0,1,3,9,1,1,1,0,0,4,1,5,1,1,512]

theorem envBound46863 : H12AffineFastState.Bounded env46863 := by
  intro p hp
  have h : env46863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46862_46863 : H12AffineEnvironment.transform 3 1 env46862 = env46863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46862 == env46863) = true)

theorem identity46863 : scanCanonicalize (H12AffineFastState.compose env46863 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46863 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46864 : List Nat := [2,1,8,1,0,0,8,1,512,0,1,0,9,1,1,3,1,1,1,0,1,0,1,3,9,1,1,1,0,0,1,1,0,1,1,512]

theorem envBound46864 : H12AffineFastState.Bounded env46864 := by
  intro p hp
  have h : env46864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46863_46864 : H12AffineEnvironment.transform 1 1 env46863 = env46864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46863 == env46864) = true)

def env46865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294201,98781,8328,65,4340964,288824,17665,179512,293108,4491637,257,21793,46212,352034]

theorem envBound46865 : H12AffineFastState.Bounded env46865 := by
  intro p hp
  have h : env46865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46789_46865 : H12AffineEnvironment.transform 20 290153 env46789 = env46865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env46789 == env46865) = true)

def env46866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294201,98781,8328,65,398436,288824,17665,179512,293108,41461,257,21793,46212,352034]

theorem envBound46866 : H12AffineFastState.Bounded env46866 := by
  intro p hp
  have h : env46866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46865_46866 : H12AffineEnvironment.transform 21 272512 env46865 = env46866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46865 == env46866) = true)

theorem identity46866 : scanCanonicalize (H12AffineFastState.compose env46866 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound46866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21928,17,98781,8328,65,158028,5392,17665,179512,1500,41461,257,21793,46212,74250]

theorem envBound46867 : H12AffineFastState.Bounded env46867 := by
  intro p hp
  have h : env46867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46866_46867 : H12AffineEnvironment.transform 17 32040 env46866 = env46867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env46866 == env46867) = true)

theorem identity46867 : scanCanonicalize (H12AffineFastState.compose env46867 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46867 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4161,21928,17,41430,8328,65,158028,5392,17665,179512,1500,41461,257,21793,46212,513]

theorem envBound46868 : H12AffineFastState.Bounded env46868 := by
  intro p hp
  have h : env46868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46867_46868 : H12AffineEnvironment.transform 15 8203 env46867 = env46868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46867 == env46868) = true)

theorem identity46868 : scanCanonicalize (H12AffineFastState.compose env46868 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound46868 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,32040,1025,29709,4161,21928,17,21978,8328,65,158028,5392,17665,149812,1500,22009,257,21793,16520,513]

theorem envBound46869 : H12AffineFastState.Bounded env46869 := by
  intro p hp
  have h : env46869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46868_46869 : H12AffineEnvironment.transform 14 29708 env46868 = env46869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env46868 == env46869) = true)

def env46870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8540,8203,131072,10360,1025,8541,4161,248,17,138,8328,65,146460,5392,4177,138340,1500,169,257,113,5592,513]

theorem envBound46870 : H12AffineFastState.Bounded env46870 := by
  intro p hp
  have h : env46870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46869_46870 : H12AffineEnvironment.transform 13 5456 env46869 = env46870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46869 == env46870) = true)

theorem identity46870 : scanCanonicalize (H12AffineFastState.compose env46870 (packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46870 : packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS < 2^1333 := by decide +kernel

def env46871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,80,263,131072,2420,1025,81,4161,248,17,138,388,65,138512,5392,4177,138340,1500,169,257,113,5592,513]

theorem envBound46871 : H12AffineFastState.Bounded env46871 := by
  intro p hp
  have h : env46871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46870_46871 : H12AffineEnvironment.transform 12 268 env46870 = env46871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46870 == env46871) = true)

theorem identity46871 : scanCanonicalize (H12AffineFastState.compose env46871 (packedSelected [0,2,3,5,6,9,10,11,12,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46871 : packedSelected [0,2,3,5,6,9,10,11,12,19] rootPS < 2^1333 := by decide +kernel

def env46872 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,41,5237,80,34,131072,2129,1025,81,4161,248,17,138,161,65,138293,5173,4177,138340,1273,169,36,113,5373,513]

theorem envBound46872 : H12AffineFastState.Bounded env46872 := by
  intro p hp
  have h : env46872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46871_46872 : H12AffineEnvironment.transform 7 37 env46871 = env46872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46871 == env46872) = true)

theorem identity46872 : scanCanonicalize (H12AffineFastState.compose env46872 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound46872 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env46873 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,41,5237,80,34,5356,2129,1025,81,4161,248,17,138,161,65,2265,5173,4177,2184,1273,169,36,113,5373,513]

theorem envBound46873 : H12AffineFastState.Bounded env46873 := by
  intro p hp
  have h : env46873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46872_46873 : H12AffineEnvironment.transform 16 5356 env46872 = env46873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env46872 == env46873) = true)

theorem identity46873 : scanCanonicalize (H12AffineFastState.compose env46873 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46873 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46874 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,41,5156,1,34,5309,2048,1025,0,4112,169,17,138,161,16,2184,5173,4096,2184,1192,169,36,32,5292,513]

theorem envBound46874 : H12AffineFastState.Bounded env46874 := by
  intro p hp
  have h : env46874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46873_46874 : H12AffineEnvironment.transform 5 17 env46873 = env46874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46873 == env46874) = true)

theorem identity46874 : scanCanonicalize (H12AffineFastState.compose env46874 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46874 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46875 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1025,0,4112,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound46875 : H12AffineFastState.Bounded env46875 := by
  intro p hp
  have h : env46875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46874_46875 : H12AffineEnvironment.transform 6 8 env46874 = env46875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46874 == env46875) = true)

def env46876 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,1,34,1029,2048,1025,0,32,33,17,2,41,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound46876 : H12AffineFastState.Bounded env46876 := by
  intro p hp
  have h : env46876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46875_46876 : H12AffineEnvironment.transform 11 48 env46875 = env46876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46875 == env46876) = true)

theorem identity46876 : scanCanonicalize (H12AffineFastState.compose env46876 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound46876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46877 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,41,1044,1,34,1029,32,1025,0,32,33,17,2,41,16,32,1029,48,32,1056,33,36,32,1044,513]

theorem envBound46877 : H12AffineFastState.Bounded env46877 := by
  intro p hp
  have h : env46877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46876_46877 : H12AffineEnvironment.transform 10 32 env46876 = env46877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env46876 == env46877) = true)

def env46878 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,32,1,34,49,32,53,0,32,33,17,2,41,16,32,49,48,32,20,33,36,32,32,513]

theorem envBound46878 : H12AffineFastState.Bounded env46878 := by
  intro p hp
  have h : env46878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46877_46878 : H12AffineEnvironment.transform 9 52 env46877 = env46878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46877 == env46878) = true)

theorem identity46878 : scanCanonicalize (H12AffineFastState.compose env46878 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46879 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,41,32,1,34,49,32,53,0,32,33,17,2,41,16,32,49,48,32,20,33,36,32,32,11]

theorem envBound46879 : H12AffineFastState.Bounded env46879 := by
  intro p hp
  have h : env46879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46878_46879 : H12AffineEnvironment.transform 8 10 env46878 = env46879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46878 == env46879) = true)

def leafEnv46879 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,41,32,1,34,49,32,53,0,32,33,17,2,21,41,1,16,32,49,48,32,20,33,36,32,5,34,32,11,1,32,0]

def active46879 : List Nat := [0,1,2,3,4]

def tree46879 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46879 : H12WitnessSearch.Good tree46879 := H12GlobalWitnessIndex.good

theorem leafIdentity46879 : H12AffineFastState.composeSystem env46879 rootObs = leafEnv46879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46879 rootObs == leafEnv46879) = true)

theorem terminalChecked46879 : H12PackedTerminal.terminalCheckFast leafEnv46879 active46879 tree46879 = true := by decide +kernel

def env46880 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,41,33,1,34,48,32,52,0,32,33,17,2,41,16,32,48,48,32,21,33,36,32,33,513]

theorem envBound46880 : H12AffineFastState.Bounded env46880 := by
  intro p hp
  have h : env46880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46877_46880 : H12AffineEnvironment.transform 9 53 env46877 = env46880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46877 == env46880) = true)

theorem identity46880 : scanCanonicalize (H12AffineFastState.compose env46880 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46881 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,0,1,3,17,1,21,0,1,0,17,2,8,16,1,17,17,1,21,0,5,1,0,513]

theorem envBound46881 : H12AffineFastState.Bounded env46881 := by
  intro p hp
  have h : env46881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46880_46881 : H12AffineEnvironment.transform 4 1 env46880 = env46881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46880 == env46881) = true)

def leafEnv46881 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,0,1,3,17,1,21,0,1,0,17,2,20,8,1,16,1,17,17,1,21,0,5,1,5,3,0,513,1,1,0]

def active46881 : List Nat := [0,1,2,3,8]

def tree46881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46881 : H12WitnessSearch.Good tree46881 := H12GlobalWitnessIndex.good

theorem leafIdentity46881 : H12AffineFastState.composeSystem env46881 rootObs = leafEnv46881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46881 rootObs == leafEnv46881) = true)

theorem terminalChecked46881 : H12PackedTerminal.terminalCheckFast leafEnv46881 active46881 tree46881 = true := by decide +kernel

def env46882 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,1,34,1028,2048,1025,0,33,33,17,2,41,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound46882 : H12AffineFastState.Bounded env46882 := by
  intro p hp
  have h : env46882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46875_46882 : H12AffineEnvironment.transform 11 49 env46875 = env46882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46875 == env46882) = true)

theorem identity46882 : scanCanonicalize (H12AffineFastState.compose env46882 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound46882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46883 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,41,1045,1,34,1028,1045,1025,0,33,33,17,2,41,16,1045,1028,49,1045,1056,33,36,32,1045,513]

theorem envBound46883 : H12AffineFastState.Bounded env46883 := by
  intro p hp
  have h : env46883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46882_46883 : H12AffineEnvironment.transform 10 1045 env46882 = env46883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env46882 == env46883) = true)

def env46884 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,41,33,1,34,48,33,53,0,33,33,17,2,41,16,33,48,49,33,20,33,36,32,33,513]

theorem envBound46884 : H12AffineFastState.Bounded env46884 := by
  intro p hp
  have h : env46884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46883_46884 : H12AffineEnvironment.transform 9 52 env46883 = env46884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46883 == env46884) = true)

theorem identity46884 : scanCanonicalize (H12AffineFastState.compose env46884 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound46884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46885 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,41,33,1,34,48,33,53,0,33,33,17,2,41,16,33,48,49,33,20,33,36,32,33,10]

theorem envBound46885 : H12AffineFastState.Bounded env46885 := by
  intro p hp
  have h : env46885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46884_46885 : H12AffineEnvironment.transform 8 11 env46884 = env46885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env46884 == env46885) = true)

def leafEnv46885 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,41,33,1,34,48,33,53,0,33,33,17,2,21,41,1,16,33,48,49,33,20,33,36,32,5,34,33,10,1,33,0]

def active46885 : List Nat := [0,1,2,3,4]

def tree46885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46885 : H12WitnessSearch.Good tree46885 := H12GlobalWitnessIndex.good

theorem leafIdentity46885 : H12AffineFastState.composeSystem env46885 rootObs = leafEnv46885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46885 rootObs == leafEnv46885) = true)

theorem terminalChecked46885 : H12PackedTerminal.terminalCheckFast leafEnv46885 active46885 tree46885 = true := by decide +kernel

def env46886 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,32,1,34,49,32,52,0,33,33,17,2,41,16,32,49,49,32,21,33,36,32,32,513]

theorem envBound46886 : H12AffineFastState.Bounded env46886 := by
  intro p hp
  have h : env46886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46883_46886 : H12AffineEnvironment.transform 9 53 env46883 = env46886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46883 == env46886) = true)

theorem identity46886 : scanCanonicalize (H12AffineFastState.compose env46886 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46887 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,8,1,1,3,16,1,21,0,0,0,17,2,8,16,1,16,16,1,21,0,5,1,1,513]

theorem envBound46887 : H12AffineFastState.Bounded env46887 := by
  intro p hp
  have h : env46887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46886_46887 : H12AffineEnvironment.transform 4 1 env46886 = env46887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46886 == env46887) = true)

def leafEnv46887 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,8,1,1,3,16,1,21,0,0,0,17,2,20,8,1,16,1,16,16,1,21,0,5,1,5,3,1,513,1,0,0]

def active46887 : List Nat := [0,1,2,3,8]

def tree46887 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46887 : H12WitnessSearch.Good tree46887 := H12GlobalWitnessIndex.good

theorem leafIdentity46887 : H12AffineFastState.composeSystem env46887 rootObs = leafEnv46887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46887 rootObs == leafEnv46887) = true)

theorem terminalChecked46887 : H12PackedTerminal.terminalCheckFast leafEnv46887 active46887 tree46887 = true := by decide +kernel

def env46888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8541,8203,131072,10361,1025,8540,4161,249,17,139,8328,65,146461,5392,4176,138341,1500,168,257,112,5593,513]

theorem envBound46888 : H12AffineFastState.Bounded env46888 := by
  intro p hp
  have h : env46888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46869_46888 : H12AffineEnvironment.transform 13 5457 env46869 = env46888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46869 == env46888) = true)

theorem identity46888 : scanCanonicalize (H12AffineFastState.compose env46888 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,8203,131072,10361,1025,8540,4161,113,17,3,8192,65,146461,5392,4176,138341,1364,32,257,112,5457,513]

theorem envBound46889 : H12AffineFastState.Bounded env46889 := by
  intro p hp
  have h : env46889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46888_46889 : H12AffineEnvironment.transform 6 8 env46888 = env46889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46888 == env46889) = true)

theorem identity46889 : scanCanonicalize (H12AffineFastState.compose env46889 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound46889 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,8203,5220,10361,1025,8540,4161,113,17,3,8192,65,10361,5392,4176,2049,1364,32,257,112,5457,513]

theorem envBound46890 : H12AffineFastState.Bounded env46890 := by
  intro p hp
  have h : env46890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46889_46890 : H12AffineEnvironment.transform 16 5220 env46889 = env46890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env46889 == env46890) = true)

theorem identity46890 : scanCanonicalize (H12AffineFastState.compose env46890 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound46890 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env46891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2396,5457,2049,2391,5220,293,1025,2048,4161,113,17,3,2396,65,293,5392,4176,2049,1364,32,257,112,5457,513]

theorem envBound46891 : H12AffineFastState.Bounded env46891 := by
  intro p hp
  have h : env46891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46890_46891 : H12AffineEnvironment.transform 12 2396 env46890 = env46891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env46890 == env46891) = true)

theorem identity46891 : scanCanonicalize (H12AffineFastState.compose env46891 (packedSelected [2,14] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound46891 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env46892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,4096,41,5457,372,34,5220,293,1025,373,4161,113,17,3,41,65,293,5392,4176,372,1364,32,257,112,5457,513]

theorem envBound46892 : H12AffineFastState.Bounded env46892 := by
  intro p hp
  have h : env46892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46891_46892 : H12AffineEnvironment.transform 10 373 env46891 = env46892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env46891 == env46892) = true)

theorem identity46892 : scanCanonicalize (H12AffineFastState.compose env46892 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound46892 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env46893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,357,41,1076,372,34,1281,293,1025,373,292,113,17,3,41,65,293,1141,309,372,1364,32,257,112,1076,513]

theorem envBound46893 : H12AffineFastState.Bounded env46893 := by
  intro p hp
  have h : env46893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46892_46893 : H12AffineEnvironment.transform 11 357 env46892 = env46893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env46892 == env46893) = true)

theorem identity46893 : scanCanonicalize (H12AffineFastState.compose env46893 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46893 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env46894 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,309,41,1076,292,34,1281,293,1025,293,292,33,17,3,41,17,293,1061,309,292,1284,32,257,32,1076,513]

theorem envBound46894 : H12AffineFastState.Bounded env46894 := by
  intro p hp
  have h : env46894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46893_46894 : H12AffineEnvironment.transform 5 16 env46893 = env46894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46893 == env46894) = true)

def env46895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294201,98781,8328,65,398437,288824,17665,179512,293108,41460,257,21793,46212,352034]

theorem envBound46895 : H12AffineFastState.Bounded env46895 := by
  intro p hp
  have h : env46895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46865_46895 : H12AffineEnvironment.transform 21 272513 env46865 = env46895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46865 == env46895) = true)

def env46896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294201,98645,8192,65,398437,288824,17665,179512,292988,41340,257,21793,46092,352034]

theorem envBound46896 : H12AffineFastState.Bounded env46896 := by
  intro p hp
  have h : env46896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46895_46896 : H12AffineEnvironment.transform 6 8 env46895 = env46896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46895 == env46896) = true)

theorem identity46896 : scanCanonicalize (H12AffineFastState.compose env46896 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound46896 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env46897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73754,98645,8192,65,215366,79131,17665,179512,75103,41340,257,21793,46092,513]

theorem envBound46897 : H12AffineFastState.Bounded env46897 := by
  intro p hp
  have h : env46897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46896_46897 : H12AffineEnvironment.transform 17 89379 env46896 = env46897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env46896 == env46897) = true)

theorem identity46897 : scanCanonicalize (H12AffineFastState.compose env46897 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound46897 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35189,1025,32769,58396,41340,62540,21763,8192,65,171280,57677,17665,179512,61705,41340,257,21793,46092,513]

theorem envBound46898 : H12AffineFastState.Bounded env46898 := by
  intro p hp
  have h : env46898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46897_46898 : H12AffineEnvironment.transform 15 54358 env46897 = env46898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env46897 == env46898) = true)

theorem identity46898 : scanCanonicalize (H12AffineFastState.compose env46898 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46898 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env46899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,35189,1025,32769,45341,41340,41293,2,8192,65,171280,46156,4096,179512,41992,41340,257,32,46092,513]

theorem envBound46899 : H12AffineFastState.Bounded env46899 := by
  intro p hp
  have h : env46899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46898_46899 : H12AffineEnvironment.transform 13 5377 env46898 = env46899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46898 == env46899) = true)

theorem identity46899 : scanCanonicalize (H12AffineFastState.compose env46899 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound46899 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8461,8282,131072,10360,1025,8460,4112,113,64,2,8192,65,146461,5441,4096,138293,1285,113,257,32,5377,513]

theorem envBound46900 : H12AffineFastState.Bounded env46900 := by
  intro p hp
  have h : env46900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46899_46900 : H12AffineEnvironment.transform 14 8461 env46899 = env46900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env46899 == env46900) = true)

theorem identity46900 : scanCanonicalize (H12AffineFastState.compose env46900 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46901 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,10281,1025,8460,4112,32,17,2,8192,16,146461,5392,4096,138293,1285,32,257,32,5377,513]

theorem envBound46901 : H12AffineFastState.Bounded env46901 := by
  intro p hp
  have h : env46901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46900_46901 : H12AffineEnvironment.transform 5 17 env46900 = env46901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46900 == env46901) = true)

theorem identity46901 : scanCanonicalize (H12AffineFastState.compose env46901 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound46901 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46902 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,260,2,131072,2080,1025,261,4112,32,17,2,9,16,138260,5392,4096,138293,1285,32,257,32,5377,513]

theorem envBound46902 : H12AffineFastState.Bounded env46902 := by
  intro p hp
  have h : env46902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46901_46902 : H12AffineEnvironment.transform 12 9 env46901 = env46902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env46901 == env46902) = true)

def env46903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272392,294201,98644,8193,65,398437,288824,17665,179512,292989,41341,257,21793,46093,352034]

theorem envBound46903 : H12AffineFastState.Bounded env46903 := by
  intro p hp
  have h : env46903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46895_46903 : H12AffineEnvironment.transform 6 9 env46895 = env46903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46895 == env46903) = true)

theorem identity46903 : scanCanonicalize (H12AffineFastState.compose env46903 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46903 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env46904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,290153,272392,294201,98644,8193,65,283765,288824,17665,64808,292989,41341,257,21793,46093,352034]

theorem envBound46904 : H12AffineFastState.Bounded env46904 := by
  intro p hp
  have h : env46904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46903_46904 : H12AffineEnvironment.transform 16 16400 env46903 = env46904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46903 == env46904) = true)

def env46905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,262144,1025,32769,276585,272392,272441,98644,8193,65,262517,277816,4097,43048,273789,41341,257,33,46093,330274]

theorem envBound46905 : H12AffineFastState.Bounded env46905 := by
  intro p hp
  have h : env46905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46904_46905 : H12AffineEnvironment.transform 13 5376 env46904 = env46905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46904 == env46905) = true)

theorem identity46905 : scanCanonicalize (H12AffineFastState.compose env46905 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound46905 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,35188,1025,32769,45341,41340,41293,98644,8193,65,34817,46156,4097,43048,41993,41341,257,33,46093,99158]

theorem envBound46906 : H12AffineFastState.Bounded env46906 := by
  intro p hp
  have h : env46906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46905_46906 : H12AffineEnvironment.transform 17 35188 env46905 = env46906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env46905 == env46906) = true)

theorem identity46906 : scanCanonicalize (H12AffineFastState.compose env46906 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46906 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,5392,10281,1025,8540,4160,33,16,73737,8193,65,10588,5393,4097,2421,1364,32,257,33,5456,74251]

theorem envBound46907 : H12AffineFastState.Bounded env46907 := by
  intro p hp
  have h : env46907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46906_46907 : H12AffineEnvironment.transform 14 8541 env46906 = env46907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46906 == env46907) = true)

theorem identity46907 : scanCanonicalize (H12AffineFastState.compose env46907 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46907 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,262,5392,10281,1025,8540,4160,33,16,8463,8193,65,10588,5393,4097,2421,1364,32,257,33,5456,8973]

theorem envBound46908 : H12AffineFastState.Bounded env46908 := by
  intro p hp
  have h : env46908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46907_46908 : H12AffineEnvironment.transform 15 262 env46907 = env46908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46907 == env46908) = true)

theorem identity46908 : scanCanonicalize (H12AffineFastState.compose env46908 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46908 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,262,5392,2340,1025,81,4160,33,16,2,268,65,2129,5393,4097,2421,1364,32,257,33,5456,512]

theorem envBound46909 : H12AffineFastState.Bounded env46909 := by
  intro p hp
  have h : env46909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46908_46909 : H12AffineEnvironment.transform 12 269 env46908 = env46909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46908 == env46909) = true)

theorem identity46909 : scanCanonicalize (H12AffineFastState.compose env46909 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1605) := by decide +kernel

theorem selectedBound46909 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1605,269,837,80,262,853,2340,1025,81,1541,33,16,2,268,65,2129,852,1604,2421,1364,32,257,33,789,512]

theorem envBound46910 : H12AffineFastState.Bounded env46910 := by
  intro p hp
  have h : env46910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46909_46910 : H12AffineEnvironment.transform 11 1605 env46909 = env46910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1605 env46909 == env46910) = true)

theorem identity46910 : scanCanonicalize (H12AffineFastState.compose env46910 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46910 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46911 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,1589,269,821,32,262,805,2340,1025,33,1541,33,16,2,268,49,2081,804,1588,2309,1316,32,257,33,789,512]

theorem envBound46911 : H12AffineFastState.Bounded env46911 := by
  intro p hp
  have h : env46911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46910_46911 : H12AffineEnvironment.transform 5 48 env46910 = env46911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46910 == env46911) = true)

def env46912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5393,262144,1025,32769,276584,272392,272440,98644,8193,65,262516,277817,4096,43049,273788,41341,257,32,46093,330275]

theorem envBound46912 : H12AffineFastState.Bounded env46912 := by
  intro p hp
  have h : env46912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46904_46912 : H12AffineEnvironment.transform 13 5377 env46904 = env46912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46904 == env46912) = true)

theorem identity46912 : scanCanonicalize (H12AffineFastState.compose env46912 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46912 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5393,262144,1025,8541,276584,272392,272440,73736,8193,65,262516,277817,4096,2421,273788,33,257,32,5457,330275]

theorem envBound46913 : H12AffineFastState.Bounded env46913 := by
  intro p hp
  have h : env46913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46912_46913 : H12AffineEnvironment.transform 14 8540 env46912 = env46913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46912 == env46913) = true)

theorem identity46913 : scanCanonicalize (H12AffineFastState.compose env46913 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46913 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5393,262144,1025,8541,276584,272392,272440,2,8193,65,262516,277817,4096,2421,273788,33,257,32,5457,272937]

theorem envBound46914 : H12AffineFastState.Bounded env46914 := by
  intro p hp
  have h : env46914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46913_46914 : H12AffineEnvironment.transform 15 8202 env46913 = env46914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46913 == env46914) = true)

theorem identity46914 : scanCanonicalize (H12AffineFastState.compose env46914 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound46914 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5393,2340,1025,8541,12620,8492,8476,2,8193,65,2128,13341,4096,2421,9304,33,257,32,5457,8973]

theorem envBound46915 : H12AffineFastState.Bounded env46915 := by
  intro p hp
  have h : env46915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46914_46915 : H12AffineEnvironment.transform 17 2340 env46914 = env46915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env46914 == env46915) = true)

theorem identity46915 : scanCanonicalize (H12AffineFastState.compose env46915 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46915 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env46916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,292,114,5393,2340,1025,293,4404,340,356,2,121,65,2128,5221,4096,2421,1056,33,257,32,5457,885]

theorem envBound46916 : H12AffineFastState.Bounded env46916 := by
  intro p hp
  have h : env46916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46915_46916 : H12AffineEnvironment.transform 12 120 env46915 = env46916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46915 == env46916) = true)

def env46917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound46917 : H12AffineFastState.Bounded env46917 := by
  intro p hp
  have h : env46917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43994_46917 : H12AffineEnvironment.transform 31 145662401 env43994 = env46917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env43994 == env46917) = true)

def env46918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound46918 : H12AffineFastState.Bounded env46918 := by
  intro p hp
  have h : env46918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46917_46918 : H12AffineEnvironment.transform 29 155254784 env46917 = env46918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env46917 == env46918) = true)

def env46919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound46919 : H12AffineFastState.Bounded env46919 := by
  intro p hp
  have h : env46919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46918_46919 : H12AffineEnvironment.transform 25 64 env46918 = env46919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env46918 == env46919) = true)

def env46920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound46920 : H12AffineFastState.Bounded env46920 := by
  intro p hp
  have h : env46920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46919_46920 : H12AffineEnvironment.transform 26 30393344 env46919 = env46920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env46919 == env46920) = true)

def env46921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound46921 : H12AffineFastState.Bounded env46921 := by
  intro p hp
  have h : env46921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46920_46921 : H12AffineEnvironment.transform 18 1024 env46920 = env46921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46920 == env46921) = true)

theorem identity46921 : scanCanonicalize (H12AffineFastState.compose env46921 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601613) := by decide +kernel

theorem selectedBound46921 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601613,8328,64,6685837,8404992,10507600,8830976,2113692,12624204,256,32,57732,2189130]

theorem envBound46922 : H12AffineFastState.Bounded env46922 := by
  intro p hp
  have h : env46922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46921_46922 : H12AffineEnvironment.transform 23 10601613 env46921 = env46922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601613 env46921 == env46922) = true)

def env46923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685837,8393984,10485840,8819968,2102684,12624204,256,32,46212,2175562]

theorem envBound46923 : H12AffineFastState.Bounded env46923 := by
  intro p hp
  have h : env46923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46922_46923 : H12AffineEnvironment.transform 13 5376 env46922 = env46923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46922 == env46923) = true)

def env46924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685837,2098648,4232,2524632,2102684,6336916,256,32,46212,2175562]

theorem envBound46924 : H12AffineFastState.Bounded env46924 := by
  intro p hp
  have h : env46924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46923_46924 : H12AffineEnvironment.transform 22 2101464 env46923 = env46924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env46923 == env46924) = true)

def env46925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491565,2098648,4232,2524632,2102684,2142644,256,32,46212,2175562]

theorem envBound46925 : H12AffineFastState.Bounded env46925 := by
  intro p hp
  have h : env46925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46924_46925 : H12AffineEnvironment.transform 21 32 env46924 = env46925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env46924 == env46925) = true)

theorem identity46925 : scanCanonicalize (H12AffineFastState.compose env46925 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46925 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98645,8192,64,2491429,2098512,4096,2524496,2102548,2142524,256,32,46092,2175562]

theorem envBound46926 : H12AffineFastState.Bounded env46926 := by
  intro p hp
  have h : env46926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46925_46926 : H12AffineEnvironment.transform 6 8 env46925 = env46926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46925 == env46926) = true)

def env46927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398437,5392,4096,431376,1364,41340,256,32,46092,74250]

theorem envBound46927 : H12AffineFastState.Bounded env46927 := by
  intro p hp
  have h : env46927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46926_46927 : H12AffineEnvironment.transform 20 4160 env46926 = env46927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46926 == env46927) = true)

theorem identity46927 : scanCanonicalize (H12AffineFastState.compose env46927 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46927 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41310,8192,64,398437,5392,4096,431376,1364,41340,256,32,46092,513]

theorem envBound46928 : H12AffineFastState.Bounded env46928 := by
  intro p hp
  have h : env46928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46927_46928 : H12AffineEnvironment.transform 15 8203 env46927 = env46928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46927 == env46928) = true)

theorem identity46928 : scanCanonicalize (H12AffineFastState.compose env46928 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46928 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env46929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,32,16,2,8192,64,398437,5392,4096,406604,1364,32,256,32,5456,513]

theorem envBound46929 : H12AffineFastState.Bounded env46929 := by
  intro p hp
  have h : env46929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46928_46929 : H12AffineEnvironment.transform 14 8540 env46928 = env46929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46928 == env46929) = true)

theorem identity46929 : scanCanonicalize (H12AffineFastState.compose env46929 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound46929 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10360,1024,8541,4160,32,16,2,8192,64,146461,5392,4096,138292,1364,32,256,32,5456,513]

theorem envBound46930 : H12AffineFastState.Bounded env46930 := by
  intro p hp
  have h : env46930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46929_46930 : H12AffineEnvironment.transform 17 10360 env46929 = env46930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env46929 == env46930) = true)

def env46931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398436,5393,4096,431377,1365,41341,256,32,46092,74251]

theorem envBound46931 : H12AffineFastState.Bounded env46931 := by
  intro p hp
  have h : env46931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46926_46931 : H12AffineEnvironment.transform 20 4161 env46926 = env46931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46926 == env46931) = true)

theorem identity46931 : scanCanonicalize (H12AffineFastState.compose env46931 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound46931 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,4161,32,17,98645,8192,64,146508,5393,4096,179513,1365,41341,256,32,46092,74251]

theorem envBound46932 : H12AffineFastState.Bounded env46932 := by
  intro p hp
  have h : env46932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46931_46932 : H12AffineEnvironment.transform 17 10280 env46931 = env46932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46931 == env46932) = true)

def env46933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491564,2098648,4232,2524632,2102684,2142645,256,32,46212,2175562]

theorem envBound46933 : H12AffineFastState.Bounded env46933 := by
  intro p hp
  have h : env46933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46924_46933 : H12AffineEnvironment.transform 21 33 env46924 = env46933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env46924 == env46933) = true)

theorem identity46933 : scanCanonicalize (H12AffineFastState.compose env46933 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound46933 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,152,98645,8328,64,398572,5528,4232,431512,1500,41461,256,32,46212,74250]

theorem envBound46934 : H12AffineFastState.Bounded env46934 := by
  intro p hp
  have h : env46934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46933_46934 : H12AffineEnvironment.transform 20 4160 env46933 = env46934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46933 == env46934) = true)

def env46935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398436,5392,4096,431376,1364,41341,256,32,46092,74250]

theorem envBound46935 : H12AffineFastState.Bounded env46935 := by
  intro p hp
  have h : env46935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46934_46935 : H12AffineEnvironment.transform 6 8 env46934 = env46935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46934 == env46935) = true)

theorem identity46935 : scanCanonicalize (H12AffineFastState.compose env46935 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46935 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41310,8192,64,398436,5392,4096,431376,1364,41341,256,32,46092,513]

theorem envBound46936 : H12AffineFastState.Bounded env46936 := by
  intro p hp
  have h : env46936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46935_46936 : H12AffineEnvironment.transform 15 8203 env46935 = env46936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46935 == env46936) = true)

theorem identity46936 : scanCanonicalize (H12AffineFastState.compose env46936 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46936 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env46937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,33,16,2,8192,64,398436,5392,4096,406604,1364,33,256,32,5456,513]

theorem envBound46937 : H12AffineFastState.Bounded env46937 := by
  intro p hp
  have h : env46937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46936_46937 : H12AffineEnvironment.transform 14 8540 env46936 = env46937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46936 == env46937) = true)

theorem identity46937 : scanCanonicalize (H12AffineFastState.compose env46937 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound46937 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10360,1024,8541,4160,33,16,2,8192,64,146460,5392,4096,138292,1364,33,256,32,5456,513]

theorem envBound46938 : H12AffineFastState.Bounded env46938 := by
  intro p hp
  have h : env46938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46937_46938 : H12AffineEnvironment.transform 17 10360 env46937 = env46938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env46937 == env46938) = true)

theorem identity46938 : scanCanonicalize (H12AffineFastState.compose env46938 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound46938 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13388,10360,1024,8541,4160,33,16,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5456,513]

theorem envBound46939 : H12AffineFastState.Bounded env46939 := by
  intro p hp
  have h : env46939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46938_46939 : H12AffineEnvironment.transform 16 13388 env46938 = env46939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env46938 == env46939) = true)

theorem identity46939 : scanCanonicalize (H12AffineFastState.compose env46939 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46939 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5392,2340,1024,1,4160,33,16,2,348,64,2128,5392,4096,2340,1364,33,256,32,5456,513]

theorem envBound46940 : H12AffineFastState.Bounded env46940 := by
  intro p hp
  have h : env46940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46939_46940 : H12AffineEnvironment.transform 12 348 env46939 = env46940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46939 == env46940) = true)

theorem identity46940 : scanCanonicalize (H12AffineFastState.compose env46940 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46940 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46941 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5156,0,115,5172,2048,1024,1,4160,33,16,2,120,64,2128,5172,4096,2048,1136,33,36,32,5236,513]

theorem envBound46941 : H12AffineFastState.Bounded env46941 := by
  intro p hp
  have h : env46941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46940_46941 : H12AffineEnvironment.transform 7 36 env46940 = env46941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46940 == env46941) = true)

theorem identity46941 : scanCanonicalize (H12AffineFastState.compose env46941 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46941 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46942 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,35,5172,2048,1024,1,4112,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound46942 : H12AffineFastState.Bounded env46942 := by
  intro p hp
  have h : env46942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46941_46942 : H12AffineEnvironment.transform 5 16 env46941 = env46942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46941 == env46942) = true)

def env46943 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,0,35,1028,2048,1024,1,32,33,16,2,40,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound46943 : H12AffineFastState.Bounded env46943 := by
  intro p hp
  have h : env46943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46942_46943 : H12AffineEnvironment.transform 11 48 env46942 = env46943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46942 == env46943) = true)

theorem identity46943 : scanCanonicalize (H12AffineFastState.compose env46943 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound46943 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46944 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,48,40,1044,0,35,1028,1077,1024,1,32,33,16,2,40,16,1077,1028,48,1077,1056,33,36,32,1044,513]

theorem envBound46944 : H12AffineFastState.Bounded env46944 := by
  intro p hp
  have h : env46944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46943_46944 : H12AffineEnvironment.transform 10 1077 env46943 = env46944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env46943 == env46944) = true)

def env46945 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,40,32,0,35,48,1,52,1,32,33,16,2,40,16,1,48,48,1,20,33,36,32,32,513]

theorem envBound46945 : H12AffineFastState.Bounded env46945 := by
  intro p hp
  have h : env46945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46944_46945 : H12AffineEnvironment.transform 9 52 env46944 = env46945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46944 == env46945) = true)

def leafEnv46945 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,40,32,0,35,48,1,52,1,32,33,16,2,20,40,1,16,1,48,48,1,20,33,36,32,4,35,32,513,1,32,0]

def active46945 : List Nat := [0,1,2,3,4,8]

def tree46945 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46945 : H12WitnessSearch.Good tree46945 := H12GlobalWitnessIndex.good

theorem leafIdentity46945 : H12AffineFastState.composeSystem env46945 rootObs = leafEnv46945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46945 rootObs == leafEnv46945) = true)

theorem terminalChecked46945 : H12PackedTerminal.terminalCheckFast leafEnv46945 active46945 tree46945 = true := by decide +kernel

def env46946 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,33,0,35,49,0,53,1,32,33,16,2,40,16,0,49,48,0,21,33,36,32,33,513]

theorem envBound46946 : H12AffineFastState.Bounded env46946 := by
  intro p hp
  have h : env46946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46944_46946 : H12AffineEnvironment.transform 9 53 env46944 = env46946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46944 == env46946) = true)

theorem identity46946 : scanCanonicalize (H12AffineFastState.compose env46946 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound46946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46947 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,48,40,33,0,35,49,0,53,1,32,33,16,2,40,16,0,49,48,0,21,33,36,32,33,42]

theorem envBound46947 : H12AffineFastState.Bounded env46947 := by
  intro p hp
  have h : env46947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46946_46947 : H12AffineEnvironment.transform 8 43 env46946 = env46947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env46946 == env46947) = true)

def leafEnv46947 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,48,40,33,0,35,49,0,53,1,32,33,16,2,21,40,1,16,0,49,48,0,21,33,36,32,4,35,33,42,1,32,0]

def active46947 : List Nat := [0,1,2,3,4]

def tree46947 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46947 : H12WitnessSearch.Good tree46947 := H12GlobalWitnessIndex.good

theorem leafIdentity46947 : H12AffineFastState.composeSystem env46947 rootObs = leafEnv46947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46947 rootObs == leafEnv46947) = true)

theorem terminalChecked46947 : H12PackedTerminal.terminalCheckFast leafEnv46947 active46947 tree46947 = true := by decide +kernel

def env46948 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,0,35,1029,2048,1024,1,33,33,16,2,40,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound46948 : H12AffineFastState.Bounded env46948 := by
  intro p hp
  have h : env46948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46942_46948 : H12AffineEnvironment.transform 11 49 env46942 = env46948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46942 == env46948) = true)

theorem identity46948 : scanCanonicalize (H12AffineFastState.compose env46948 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46949 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,49,40,1045,0,35,1029,0,1024,1,33,33,16,2,40,16,0,1029,49,0,1056,33,36,32,1045,513]

theorem envBound46949 : H12AffineFastState.Bounded env46949 := by
  intro p hp
  have h : env46949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46948_46949 : H12AffineEnvironment.transform 10 0 env46948 = env46949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46948 == env46949) = true)

def env46950 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,33,0,35,49,0,52,1,33,33,16,2,40,16,0,49,49,0,20,33,36,32,33,513]

theorem envBound46950 : H12AffineFastState.Bounded env46950 := by
  intro p hp
  have h : env46950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46949_46950 : H12AffineEnvironment.transform 9 52 env46949 = env46950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46949 == env46950) = true)

def leafEnv46950 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,33,0,35,49,0,52,1,33,33,16,2,20,40,1,16,0,49,49,0,20,33,36,32,4,35,33,513,1,33,0]

def active46950 : List Nat := [0,1,2,3,4,8]

def tree46950 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46950 : H12WitnessSearch.Good tree46950 := H12GlobalWitnessIndex.good

theorem leafIdentity46950 : H12AffineFastState.composeSystem env46950 rootObs = leafEnv46950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46950 rootObs == leafEnv46950) = true)

theorem terminalChecked46950 : H12PackedTerminal.terminalCheckFast leafEnv46950 active46950 tree46950 = true := by decide +kernel

def env46951 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,40,32,0,35,48,0,53,1,33,33,16,2,40,16,0,48,49,0,21,33,36,32,32,513]

theorem envBound46951 : H12AffineFastState.Bounded env46951 := by
  intro p hp
  have h : env46951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46949_46951 : H12AffineEnvironment.transform 9 53 env46949 = env46951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46949 == env46951) = true)

theorem identity46951 : scanCanonicalize (H12AffineFastState.compose env46951 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound46951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46952 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,49,40,32,0,35,48,0,53,1,33,33,16,2,40,16,0,48,49,0,21,33,36,32,32,42]

theorem envBound46952 : H12AffineFastState.Bounded env46952 := by
  intro p hp
  have h : env46952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46951_46952 : H12AffineEnvironment.transform 8 43 env46951 = env46952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env46951 == env46952) = true)

def leafEnv46952 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,49,40,32,0,35,48,0,53,1,33,33,16,2,21,40,1,16,0,48,49,0,21,33,36,32,4,35,32,42,1,33,0]

def active46952 : List Nat := [0,1,2,3,4]

def tree46952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46952 : H12WitnessSearch.Good tree46952 := H12GlobalWitnessIndex.good

theorem leafIdentity46952 : H12AffineFastState.composeSystem env46952 rootObs = leafEnv46952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46952 rootObs == leafEnv46952) = true)

theorem terminalChecked46952 : H12PackedTerminal.terminalCheckFast leafEnv46952 active46952 tree46952 = true := by decide +kernel

def env46953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,17,98645,8193,64,398437,5393,4097,431377,1365,41340,256,32,46093,74250]

theorem envBound46953 : H12AffineFastState.Bounded env46953 := by
  intro p hp
  have h : env46953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46934_46953 : H12AffineEnvironment.transform 6 9 env46934 = env46953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46934 == env46953) = true)

theorem identity46953 : scanCanonicalize (H12AffineFastState.compose env46953 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound46953 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1024,32769,4160,33,17,98645,8193,64,171280,5393,4097,138340,1365,41340,256,32,46093,74250]

theorem envBound46954 : H12AffineFastState.Bounded env46954 := by
  intro p hp
  have h : env46954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46953_46954 : H12AffineEnvironment.transform 17 35189 env46953 = env46954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env46953 == env46954) = true)

theorem identity46954 : scanCanonicalize (H12AffineFastState.compose env46954 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound46954 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35189,1024,32769,4160,33,17,98645,8193,64,34817,5393,4097,2421,1365,41340,256,32,46093,74250]

theorem envBound46955 : H12AffineFastState.Bounded env46955 := by
  intro p hp
  have h : env46955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46954_46955 : H12AffineEnvironment.transform 16 5393 env46954 = env46955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env46954 == env46955) = true)

theorem identity46955 : scanCanonicalize (H12AffineFastState.compose env46955 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46955 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,35189,1024,32769,4160,33,17,41311,8193,64,34817,5393,4097,2421,1365,41340,256,32,46093,512]

theorem envBound46956 : H12AffineFastState.Bounded env46956 := by
  intro p hp
  have h : env46956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46955_46956 : H12AffineEnvironment.transform 15 8202 env46955 = env46956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46955 == env46956) = true)

theorem identity46956 : scanCanonicalize (H12AffineFastState.compose env46956 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound46956 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8200,8202,5393,10621,1024,8201,4160,33,17,343,8193,64,10249,5393,4097,2421,1365,372,256,32,5125,512]

theorem envBound46957 : H12AffineFastState.Bounded env46957 := by
  intro p hp
  have h : env46957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46956_46957 : H12AffineEnvironment.transform 14 8200 env46956 = env46957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env46956 == env46957) = true)

theorem identity46957 : scanCanonicalize (H12AffineFastState.compose env46957 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46957 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env46958 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8200,8202,5221,10249,1024,8201,4160,33,17,35,8193,64,10249,5221,4097,2049,1057,0,116,32,5125,512]

theorem envBound46958 : H12AffineFastState.Bounded env46958 := by
  intro p hp
  have h : env46958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46957_46958 : H12AffineEnvironment.transform 7 116 env46957 = env46958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46957 == env46958) = true)

theorem identity46958 : scanCanonicalize (H12AffineFastState.compose env46958 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6147) := by decide +kernel

theorem selectedBound46958 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46959 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,6147,5236,6155,6153,5221,4106,1024,6154,4160,33,17,35,6146,64,4106,5221,4097,2049,1057,0,116,32,5125,512]

theorem envBound46959 : H12AffineFastState.Bounded env46959 := by
  intro p hp
  have h : env46959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46958_46959 : H12AffineEnvironment.transform 12 6147 env46958 = env46959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6147 env46958 == env46959) = true)

theorem identity46959 : scanCanonicalize (H12AffineFastState.compose env46959 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2139) := by decide +kernel

theorem selectedBound46959 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46960 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2139,88,3119,80,82,3134,2129,1024,81,2075,33,17,35,89,64,2129,3134,2138,2049,1057,0,116,32,3166,512]

theorem envBound46960 : H12AffineFastState.Bounded env46960 := by
  intro p hp
  have h : env46960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46959_46960 : H12AffineEnvironment.transform 11 2139 env46959 = env46960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2139 env46959 == env46960) = true)

theorem identity46960 : scanCanonicalize (H12AffineFastState.compose env46960 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46960 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env46961 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2059,8,3119,0,2,3134,2049,1024,1,2075,33,17,35,9,16,2049,3134,2058,2049,1057,0,36,32,3086,512]

theorem envBound46961 : H12AffineFastState.Bounded env46961 := by
  intro p hp
  have h : env46961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46960_46961 : H12AffineEnvironment.transform 5 16 env46960 = env46961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46960 == env46961) = true)

theorem identity46961 : scanCanonicalize (H12AffineFastState.compose env46961 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46962 : List Nat := [2,4,8,1,32,1,9,36,512,1024,2048,2059,8,3119,0,2,3119,2049,1024,1,2058,33,0,35,9,1,2049,3119,2058,2049,1057,0,36,32,3086,512]

theorem envBound46962 : H12AffineFastState.Bounded env46962 := by
  intro p hp
  have h : env46962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46961_46962 : H12AffineEnvironment.transform 3 1 env46961 = env46962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46961 == env46962) = true)

theorem identity46962 : scanCanonicalize (H12AffineFastState.compose env46962 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46962 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46963 : List Nat := [2,4,8,1,0,1,9,4,512,1024,2048,2059,8,3087,0,2,3087,2049,1024,1,2058,1,0,3,9,1,2049,3087,2058,2049,1025,0,4,0,3086,512]

theorem envBound46963 : H12AffineFastState.Bounded env46963 := by
  intro p hp
  have h : env46963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46962_46963 : H12AffineEnvironment.transform 4 0 env46962 = env46963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46962 == env46963) = true)

theorem identity46963 : scanCanonicalize (H12AffineFastState.compose env46963 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound46963 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46964 : List Nat := [2,4,8,1,0,1,9,4,512,1024,513,522,8,1550,0,2,1550,512,1024,1,523,1,0,3,9,1,512,1550,523,512,1025,0,4,0,1551,512]

theorem envBound46964 : H12AffineFastState.Bounded env46964 := by
  intro p hp
  have h : env46964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46963_46964 : H12AffineEnvironment.transform 10 513 env46963 = env46964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env46963 == env46964) = true)

theorem identity46964 : scanCanonicalize (H12AffineFastState.compose env46964 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound46964 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46965 : List Nat := [2,4,8,1,0,1,9,4,2,1024,3,8,8,1036,0,2,1036,2,1024,1,9,1,0,3,9,1,2,1036,9,2,1025,0,4,0,1037,2]

theorem envBound46965 : H12AffineFastState.Bounded env46965 := by
  intro p hp
  have h : env46965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46964_46965 : H12AffineEnvironment.transform 8 2 env46964 = env46965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env46964 == env46965) = true)

theorem identity46965 : scanCanonicalize (H12AffineFastState.compose env46965 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound46965 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env46966 : List Nat := [2,4,8,1,0,1,9,4,2,15,3,8,8,3,0,2,3,2,15,1,9,1,0,3,9,1,2,3,9,2,14,0,4,0,2,2]

theorem envBound46966 : H12AffineFastState.Bounded env46966 := by
  intro p hp
  have h : env46966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46965_46966 : H12AffineEnvironment.transform 9 15 env46965 = env46966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env46965 == env46966) = true)

def env46967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685837,2098649,4233,2524633,2102684,6336917,256,32,46212,2175562]

theorem envBound46967 : H12AffineFastState.Bounded env46967 := by
  intro p hp
  have h : env46967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46923_46967 : H12AffineEnvironment.transform 22 2101465 env46923 = env46967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env46923 == env46967) = true)

def env46968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491565,2098649,4233,2524633,2102684,2142645,256,32,46212,2175562]

theorem envBound46968 : H12AffineFastState.Bounded env46968 := by
  intro p hp
  have h : env46968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46967_46968 : H12AffineEnvironment.transform 21 32 env46967 = env46968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env46967 == env46968) = true)

theorem identity46968 : scanCanonicalize (H12AffineFastState.compose env46968 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46968 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,2097152,32,2101465,73736,8328,64,2491565,2098649,4233,2499717,2102684,2101481,256,32,5592,2175562]

theorem envBound46969 : H12AffineFastState.Bounded env46969 := by
  intro p hp
  have h : env46969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46968_46969 : H12AffineEnvironment.transform 14 8540 env46968 = env46969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46968 == env46969) = true)

def env46970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,2097152,32,2101465,73736,8328,64,2239501,2098649,4233,2231333,2102684,2101481,256,32,5592,2175562]

theorem envBound46970 : H12AffineFastState.Bounded env46970 := by
  intro p hp
  have h : env46970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46969_46970 : H12AffineEnvironment.transform 17 10400 env46969 = env46970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46969 == env46970) = true)

def env46971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,132568,32,136449,73736,8328,64,10709,131073,4233,2557,135236,136497,256,32,5592,210834]

theorem envBound46971 : H12AffineFastState.Bounded env46971 := by
  intro p hp
  have h : env46971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46970_46971 : H12AffineEnvironment.transform 20 132568 env46970 = env46971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132568 env46970 == env46971) = true)

theorem identity46971 : scanCanonicalize (H12AffineFastState.compose env46971 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound46971 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env46972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10400,1024,8541,78019,32,73754,73736,8328,64,10709,79130,4233,2557,75103,73770,256,32,5592,649]

theorem envBound46972 : H12AffineFastState.Bounded env46972 := by
  intro p hp
  have h : env46972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46971_46972 : H12AffineEnvironment.transform 16 79131 env46971 = env46972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env46971 == env46972) = true)

theorem identity46972 : scanCanonicalize (H12AffineFastState.compose env46972 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46972 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10280,1024,8541,77899,32,73754,73736,8192,64,10589,79130,4097,2421,75103,73770,256,32,5456,513]

theorem envBound46973 : H12AffineFastState.Bounded env46973 := by
  intro p hp
  have h : env46973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46972_46973 : H12AffineEnvironment.transform 6 8 env46972 = env46973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46972 == env46973) = true)

theorem identity46973 : scanCanonicalize (H12AffineFastState.compose env46973 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46973 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10280,1024,8541,4161,32,16,2,8192,64,10589,5392,4097,2421,1365,32,256,32,5456,513]

theorem envBound46974 : H12AffineFastState.Bounded env46974 := by
  intro p hp
  have h : env46974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46973_46974 : H12AffineEnvironment.transform 15 8202 env46973 = env46974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46973 == env46974) = true)

def env46975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,132569,32,136448,73736,8328,64,10708,131072,4233,2556,135237,136496,256,32,5592,210835]

theorem envBound46975 : H12AffineFastState.Bounded env46975 := by
  intro p hp
  have h : env46975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46970_46975 : H12AffineEnvironment.transform 20 132569 env46970 = env46975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132569 env46970 == env46975) = true)

theorem identity46975 : scanCanonicalize (H12AffineFastState.compose env46975 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound46975 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env46976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79250,10400,1024,8541,77899,32,73874,73736,8328,64,10708,79250,4233,2556,75223,73890,256,32,5592,513]

theorem envBound46976 : H12AffineFastState.Bounded env46976 := by
  intro p hp
  have h : env46976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46975_46976 : H12AffineEnvironment.transform 16 79250 env46975 = env46976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env46975 == env46976) = true)

theorem identity46976 : scanCanonicalize (H12AffineFastState.compose env46976 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46976 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env46977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,5528,10400,1024,8541,4161,32,152,2,8328,64,10708,5528,4233,2556,1501,168,256,32,5592,513]

theorem envBound46977 : H12AffineFastState.Bounded env46977 := by
  intro p hp
  have h : env46977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46976_46977 : H12AffineEnvironment.transform 15 8202 env46976 = env46977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46976 == env46977) = true)

theorem identity46977 : scanCanonicalize (H12AffineFastState.compose env46977 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46977 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env46978 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5236,8232,8202,5356,10400,1024,8233,4161,32,152,2,8328,64,10400,5356,4233,2184,1193,168,116,32,5292,513]

theorem envBound46978 : H12AffineFastState.Bounded env46978 := by
  intro p hp
  have h : env46978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46977_46978 : H12AffineEnvironment.transform 7 116 env46977 = env46978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46977 == env46978) = true)

theorem identity46978 : scanCanonicalize (H12AffineFastState.compose env46978 (packedSelected [3,4,5,6,9,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46978 : packedSelected [3,4,5,6,9,10,20] rootPS < 2^1333 := by decide +kernel

def env46979 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,8202,5220,10280,1024,8233,4161,32,16,2,8192,64,10280,5220,4097,2048,1057,32,116,32,5156,513]

theorem envBound46979 : H12AffineFastState.Bounded env46979 := by
  intro p hp
  have h : env46979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46978_46979 : H12AffineEnvironment.transform 6 8 env46978 = env46979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46978 == env46979) = true)

theorem identity46979 : scanCanonicalize (H12AffineFastState.compose env46979 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46979 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46980 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,0,34,5220,2048,1024,1,4161,32,16,2,40,64,2048,5220,4097,2048,1057,32,116,32,5156,513]

theorem envBound46980 : H12AffineFastState.Bounded env46980 := by
  intro p hp
  have h : env46980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46979_46980 : H12AffineEnvironment.transform 12 40 env46979 = env46980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46979 == env46980) = true)

theorem identity46980 : scanCanonicalize (H12AffineFastState.compose env46980 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound46980 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46981 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1646,4096,40,5236,0,34,5220,1646,1024,1,4161,32,16,2,40,64,1646,5220,4097,1646,1057,32,116,32,5156,513]

theorem envBound46981 : H12AffineFastState.Bounded env46981 := by
  intro p hp
  have h : env46981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46980_46981 : H12AffineEnvironment.transform 10 1646 env46980 = env46981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env46980 == env46981) = true)

theorem identity46981 : scanCanonicalize (H12AffineFastState.compose env46981 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound46981 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46982 : List Nat := [2,4,8,16,32,64,8,116,512,622,0,4096,40,4634,0,34,4618,0,622,1,4161,32,16,2,40,64,0,4618,4097,0,591,32,116,32,4682,513]

theorem envBound46982 : H12AffineFastState.Bounded env46982 := by
  intro p hp
  have h : env46982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46981_46982 : H12AffineEnvironment.transform 9 622 env46981 = env46982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env46981 == env46982) = true)

theorem identity46982 : scanCanonicalize (H12AffineFastState.compose env46982 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound46982 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46983 : List Nat := [2,4,8,16,32,64,8,116,123,21,0,4096,40,4193,0,34,4209,0,21,1,4161,32,16,2,40,64,0,4209,4097,0,52,32,116,32,4145,122]

theorem envBound46983 : H12AffineFastState.Bounded env46983 := by
  intro p hp
  have h : env46983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46982_46983 : H12AffineEnvironment.transform 8 123 env46982 = env46983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env46982 == env46983) = true)

theorem identity46983 : scanCanonicalize (H12AffineFastState.compose env46983 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound46983 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46984 : List Nat := [2,4,8,16,25,64,8,77,66,21,0,4096,17,4184,0,27,4168,0,21,1,4161,25,16,2,17,64,0,4168,4097,0,13,25,77,25,4104,67]

theorem envBound46984 : H12AffineFastState.Bounded env46984 := by
  intro p hp
  have h : env46984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46983_46984 : H12AffineEnvironment.transform 4 25 env46983 = env46984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env46983 == env46984) = true)

def env46985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,2097152,32,2101465,73736,8328,64,2239500,2098649,4233,2231332,2102684,2101481,256,32,5592,2175562]

theorem envBound46985 : H12AffineFastState.Bounded env46985 := by
  intro p hp
  have h : env46985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46969_46985 : H12AffineEnvironment.transform 17 10401 env46969 = env46985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46969 == env46985) = true)

theorem identity46985 : scanCanonicalize (H12AffineFastState.compose env46985 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound46985 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,4297,32,16,73736,8328,64,146629,5392,4233,138477,1365,32,256,32,5592,74371]

theorem envBound46986 : H12AffineFastState.Bounded env46986 := by
  intro p hp
  have h : env46986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46985_46986 : H12AffineEnvironment.transform 20 4297 env46985 = env46986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env46985 == env46986) = true)

theorem identity46986 : scanCanonicalize (H12AffineFastState.compose env46986 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound46986 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,70862,10401,1024,8541,4297,32,16,73736,8328,64,75787,5392,4233,67619,1365,32,256,32,5592,74371]

theorem envBound46987 : H12AffineFastState.Bounded env46987 := by
  intro p hp
  have h : env46987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46986_46987 : H12AffineEnvironment.transform 16 70862 env46986 = env46987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env46986 == env46987) = true)

theorem identity46987 : scanCanonicalize (H12AffineFastState.compose env46987 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound46987 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env46988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,343,5529,10401,1024,8541,4297,32,16,8543,8328,64,10588,5392,4233,2420,1365,32,256,32,5592,9172]

theorem envBound46988 : H12AffineFastState.Bounded env46988 := by
  intro p hp
  have h : env46988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46987_46988 : H12AffineEnvironment.transform 15 343 env46987 = env46988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env46987 == env46988) = true)

theorem identity46988 : scanCanonicalize (H12AffineFastState.compose env46988 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound46988 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,137,343,5529,2420,1024,136,4297,32,16,138,349,64,2185,5392,4233,2420,1365,32,256,32,5592,513]

theorem envBound46989 : H12AffineFastState.Bounded env46989 := by
  intro p hp
  have h : env46989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46988_46989 : H12AffineEnvironment.transform 12 469 env46988 = env46989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env46988 == env46989) = true)

theorem identity46989 : scanCanonicalize (H12AffineFastState.compose env46989 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound46989 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env46990 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,469,4249,137,343,4096,2420,409,136,4297,32,16,138,349,64,2185,4233,4233,2420,204,32,256,32,4161,513]

theorem envBound46990 : H12AffineFastState.Bounded env46990 := by
  intro p hp
  have h : env46990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46989_46990 : H12AffineEnvironment.transform 9 409 env46989 = env46990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env46989 == env46990) = true)

theorem identity46990 : scanCanonicalize (H12AffineFastState.compose env46990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46991 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4113,1,343,4096,2420,273,0,4161,32,16,2,349,64,2049,4097,4097,2420,68,32,256,32,4161,513]

theorem envBound46991 : H12AffineFastState.Bounded env46991 := by
  intro p hp
  have h : env46991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46990_46991 : H12AffineEnvironment.transform 6 8 env46990 = env46991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46990 == env46991) = true)

theorem identity46991 : scanCanonicalize (H12AffineFastState.compose env46991 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46992 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,4096,72,4113,1,66,4096,2145,4,0,4161,32,16,2,72,64,2049,4097,4097,2145,68,32,21,32,4161,513]

theorem envBound46992 : H12AffineFastState.Bounded env46992 := by
  intro p hp
  have h : env46992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46991_46992 : H12AffineEnvironment.transform 7 21 env46991 = env46992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46991 == env46992) = true)

theorem identity46992 : scanCanonicalize (H12AffineFastState.compose env46992 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound46992 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46993 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,544,72,561,1,66,544,2145,4,0,609,32,16,2,72,64,2049,545,545,2145,68,32,21,32,609,513]

theorem envBound46993 : H12AffineFastState.Bounded env46993 := by
  intro p hp
  have h : env46993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46992_46993 : H12AffineEnvironment.transform 11 544 env46992 = env46993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env46992 == env46993) = true)

def env46994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491564,2098649,4233,2524633,2102684,2142644,256,32,46212,2175562]

theorem envBound46994 : H12AffineFastState.Bounded env46994 := by
  intro p hp
  have h : env46994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46967_46994 : H12AffineEnvironment.transform 21 33 env46967 = env46994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env46967 == env46994) = true)

theorem identity46994 : scanCanonicalize (H12AffineFastState.compose env46994 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound46994 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,45461,33,41292,98644,8328,64,439609,46156,4233,406604,41993,33,256,32,46212,99295]

theorem envBound46995 : H12AffineFastState.Bounded env46995 := by
  intro p hp
  have h : env46995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46994_46995 : H12AffineEnvironment.transform 20 45461 env46994 = env46995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env46994 == env46995) = true)

theorem identity46995 : scanCanonicalize (H12AffineFastState.compose env46995 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound46995 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,45461,33,41292,98644,8328,64,203847,46156,4233,236850,41993,33,256,32,46212,99295]

theorem envBound46996 : H12AffineFastState.Bounded env46996 := by
  intro p hp
  have h : env46996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46995_46996 : H12AffineEnvironment.transform 17 108926 env46995 = env46996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env46995 == env46996) = true)

def env46997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67618,1024,8541,4297,33,16,73736,8328,64,203847,5392,4233,212078,1365,33,256,32,5592,74371]

theorem envBound46997 : H12AffineFastState.Bounded env46997 := by
  intro p hp
  have h : env46997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46996_46997 : H12AffineEnvironment.transform 14 8540 env46996 = env46997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46996 == env46997) = true)

theorem identity46997 : scanCanonicalize (H12AffineFastState.compose env46997 (packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70815) := by decide +kernel

theorem selectedBound46997 : packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env46998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,70815,67618,1024,8541,4297,33,16,73736,8328,64,2264,5392,4233,10481,1365,33,256,32,5592,74371]

theorem envBound46998 : H12AffineFastState.Bounded env46998 := by
  intro p hp
  have h : env46998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46997_46998 : H12AffineEnvironment.transform 16 70815 env46997 = env46998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70815 env46997 == env46998) = true)

theorem identity46998 : scanCanonicalize (H12AffineFastState.compose env46998 (packedSelected [0,2,3,5,6,7,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46998 : packedSelected [0,2,3,5,6,7,14,19] rootPS < 2^1333 := by decide +kernel

def env46999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,81,65536,70815,67618,1024,80,4297,33,16,65797,389,64,2264,5392,4233,2556,1365,33,256,32,5592,66446]

theorem envBound46999 : H12AffineFastState.Bounded env46999 := by
  intro p hp
  have h : env46999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46998_46999 : H12AffineEnvironment.transform 12 269 env46998 = env46999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46998 == env46999) = true)

theorem identity46999 : scanCanonicalize (H12AffineFastState.compose env46999 (packedSelected [3,14,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46999 : packedSelected [3,14,20,24] rootPS < 2^1333 := by decide +kernel

def env47000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,65536,70678,67618,1024,80,4160,33,16,65797,268,64,2129,5392,4096,2421,1365,33,256,32,5457,66311]

theorem envBound47000 : H12AffineFastState.Bounded env47000 := by
  intro p hp
  have h : env47000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46999_47000 : H12AffineEnvironment.transform 6 9 env46999 = env47000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46999 == env47000) = true)

theorem identity47000 : scanCanonicalize (H12AffineFastState.compose env47000 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47000 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env47001 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,65536,70678,67618,1024,80,4160,33,16,65648,121,64,2129,5221,4096,2048,1056,33,117,32,5156,66162]

theorem envBound47001 : H12AffineFastState.Bounded env47001 := by
  intro p hp
  have h : env47001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47000_47001 : H12AffineEnvironment.transform 7 117 env47000 = env47001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47000 == env47001) = true)

theorem identity47001 : scanCanonicalize (H12AffineFastState.compose env47001 (packedSelected [3,4,5,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound47001 : packedSelected [3,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env47002 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,35,5173,2049,1024,80,4160,33,16,83,121,64,2129,5221,4096,2048,1056,33,117,32,5156,593]

theorem envBound47002 : H12AffineFastState.Bounded env47002 := by
  intro p hp
  have h : env47002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47001_47002 : H12AffineEnvironment.transform 15 35 env47001 = env47002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env47001 == env47002) = true)

theorem identity47002 : scanCanonicalize (H12AffineFastState.compose env47002 (packedSelected [4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound47002 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env47003 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2112,120,3125,81,35,3189,2049,1024,80,2048,33,16,83,121,64,2129,3109,2112,2048,1056,33,117,32,3172,593]

theorem envBound47003 : H12AffineFastState.Bounded env47003 := by
  intro p hp
  have h : env47003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47002_47003 : H12AffineEnvironment.transform 11 2112 env47002 = env47003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env47002 == env47003) = true)

theorem identity47003 : scanCanonicalize (H12AffineFastState.compose env47003 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47003 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env47004 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,2112,120,2129,81,35,2065,2049,100,80,2048,33,16,83,121,64,2129,2113,2112,2048,68,33,117,32,2048,593]

theorem envBound47004 : H12AffineFastState.Bounded env47004 := by
  intro p hp
  have h : env47004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47003_47004 : H12AffineEnvironment.transform 9 100 env47003 = env47004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47003 == env47004) = true)

theorem identity47004 : scanCanonicalize (H12AffineFastState.compose env47004 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47004 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env47005 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,40,2049,1,35,2065,2049,52,0,2048,33,16,3,41,16,2049,2065,2064,2048,20,33,37,32,2048,513]

theorem envBound47005 : H12AffineFastState.Bounded env47005 := by
  intro p hp
  have h : env47005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47004_47005 : H12AffineEnvironment.transform 5 16 env47004 = env47005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47004 == env47005) = true)

theorem identity47005 : scanCanonicalize (H12AffineFastState.compose env47005 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47006 : List Nat := [2,4,8,16,32,16,9,37,1,52,2048,2064,40,2049,1,35,2065,2049,52,0,2048,33,16,3,41,16,2049,2065,2064,2048,20,33,37,32,2048,0]

theorem envBound47006 : H12AffineFastState.Bounded env47006 := by
  intro p hp
  have h : env47006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47005_47006 : H12AffineEnvironment.transform 8 1 env47005 = env47006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47005 == env47006) = true)

theorem identity47006 : scanCanonicalize (H12AffineFastState.compose env47006 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound47006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47007 : List Nat := [2,4,8,16,32,16,9,37,1,52,11,27,40,10,1,35,26,10,52,0,11,33,16,3,41,16,10,26,27,11,20,33,37,32,11,0]

theorem envBound47007 : H12AffineFastState.Bounded env47007 := by
  intro p hp
  have h : env47007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47006_47007 : H12AffineEnvironment.transform 10 11 env47006 = env47007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env47006 == env47007) = true)

def env47008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67619,1024,8540,4296,33,17,73737,8328,64,203847,5393,4233,212079,1364,33,256,32,5593,74370]

theorem envBound47008 : H12AffineFastState.Bounded env47008 := by
  intro p hp
  have h : env47008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46996_47008 : H12AffineEnvironment.transform 14 8541 env46996 = env47008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46996 == env47008) = true)

theorem identity47008 : scanCanonicalize (H12AffineFastState.compose env47008 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47008 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10280,1024,8540,4296,33,17,2,8328,64,146508,5393,4233,138340,1364,33,256,32,5593,649]

theorem envBound47009 : H12AffineFastState.Bounded env47009 := by
  intro p hp
  have h : env47009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47008_47009 : H12AffineEnvironment.transform 15 8203 env47008 = env47009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47008 == env47009) = true)

theorem identity47009 : scanCanonicalize (H12AffineFastState.compose env47009 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47009 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,263,131072,2340,1024,80,4296,33,17,2,388,64,138560,5393,4233,138340,1364,33,256,32,5593,649]

theorem envBound47010 : H12AffineFastState.Bounded env47010 := by
  intro p hp
  have h : env47010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47009_47010 : H12AffineEnvironment.transform 12 268 env47009 = env47010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47009 == env47010) = true)

theorem identity47010 : scanCanonicalize (H12AffineFastState.compose env47010 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound47010 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env47011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,263,5576,2340,1024,80,4296,33,17,2,388,64,2184,5393,4233,2476,1364,33,256,32,5593,649]

theorem envBound47011 : H12AffineFastState.Bounded env47011 := by
  intro p hp
  have h : env47011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47010_47011 : H12AffineEnvironment.transform 16 5576 env47010 = env47011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env47010 == env47011) = true)

theorem identity47011 : scanCanonicalize (H12AffineFastState.compose env47011 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47011 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,263,5441,2340,1024,80,4161,33,17,2,269,64,2049,5393,4096,2341,1364,33,256,32,5456,512]

theorem envBound47012 : H12AffineFastState.Bounded env47012 := by
  intro p hp
  have h : env47012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47011_47012 : H12AffineEnvironment.transform 6 9 env47011 = env47012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47011 == env47012) = true)

theorem identity47012 : scanCanonicalize (H12AffineFastState.compose env47012 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1889) := by decide +kernel

theorem selectedBound47012 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1889,268,609,81,263,544,2340,1024,80,1824,33,17,2,269,64,2049,624,1889,2341,1364,33,256,32,561,512]

theorem envBound47013 : H12AffineFastState.Bounded env47013 := by
  intro p hp
  have h : env47013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47012_47013 : H12AffineEnvironment.transform 11 1889 env47012 = env47013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1889 env47012 == env47013) = true)

theorem identity47013 : scanCanonicalize (H12AffineFastState.compose env47013 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47013 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47014 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1857,268,577,81,263,512,2308,1024,80,1792,1,17,2,269,64,2049,592,1857,2309,1364,1,256,0,529,512]

theorem envBound47014 : H12AffineFastState.Bounded env47014 := by
  intro p hp
  have h : env47014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47013_47014 : H12AffineEnvironment.transform 4 0 env47013 = env47014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47013 == env47014) = true)

theorem identity47014 : scanCanonicalize (H12AffineFastState.compose env47014 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound47014 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env47015 : List Nat := [2,4,8,16,0,64,9,256,512,532,2048,341,268,577,81,263,512,2308,532,80,276,1,17,2,269,64,2049,592,341,2309,832,1,256,0,529,512]

theorem envBound47015 : H12AffineFastState.Bounded env47015 := by
  intro p hp
  have h : env47015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47014_47015 : H12AffineEnvironment.transform 9 532 env47014 = env47015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env47014 == env47015) = true)

theorem identity47015 : scanCanonicalize (H12AffineFastState.compose env47015 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound47015 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env47016 : List Nat := [2,4,8,16,0,64,9,256,81,69,2048,341,268,16,81,263,81,2308,69,80,276,1,17,2,269,64,2049,1,341,2309,273,1,256,0,64,81]

theorem envBound47016 : H12AffineFastState.Bounded env47016 := by
  intro p hp
  have h : env47016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47015_47016 : H12AffineEnvironment.transform 8 81 env47015 = env47016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env47015 == env47016) = true)

def env47017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685837,8393985,10485841,8819969,2102685,12624204,256,32,46213,2175563]

theorem envBound47017 : H12AffineFastState.Bounded env47017 := by
  intro p hp
  have h : env47017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46922_47017 : H12AffineEnvironment.transform 13 5377 env46922 = env47017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46922 == env47017) = true)

def env47018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685837,2098649,4233,2524633,2102685,6336916,256,32,46213,2175563]

theorem envBound47018 : H12AffineFastState.Bounded env47018 := by
  intro p hp
  have h : env47018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47017_47018 : H12AffineEnvironment.transform 22 2101464 env47017 = env47018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env47017 == env47018) = true)

def env47019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491565,2098649,4233,2524633,2102685,2142644,256,32,46213,2175563]

theorem envBound47019 : H12AffineFastState.Bounded env47019 := by
  intro p hp
  have h : env47019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47018_47019 : H12AffineEnvironment.transform 21 32 env47018 = env47019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47018 == env47019) = true)

theorem identity47019 : scanCanonicalize (H12AffineFastState.compose env47019 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102678) := by decide +kernel

theorem selectedBound47019 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98766,98644,8328,64,497083,103631,4233,464079,99467,73890,256,32,46213,41821]

theorem envBound47020 : H12AffineFastState.Bounded env47020 := by
  intro p hp
  have h : env47020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47019_47020 : H12AffineEnvironment.transform 20 102678 env47019 = env47020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102678 env47019 == env47020) = true)

def env47021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1024,32769,102678,32,98766,98644,8328,64,245019,103631,4233,212079,99467,73890,256,32,46213,41821]

theorem envBound47021 : H12AffineFastState.Bounded env47021 := by
  intro p hp
  have h : env47021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47020_47021 : H12AffineEnvironment.transform 17 10400 env47020 = env47021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47020 == env47021) = true)

def env47022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102678,32,98630,98644,8192,64,245019,103495,4097,212079,99331,73770,256,32,46093,41821]

theorem envBound47022 : H12AffineFastState.Bounded env47022 := by
  intro p hp
  have h : env47022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47021_47022 : H12AffineEnvironment.transform 6 8 env47021 = env47022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47021 == env47022) = true)

theorem identity47022 : scanCanonicalize (H12AffineFastState.compose env47022 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound47022 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env47023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,70727,10280,1024,32769,102678,32,98630,98644,8192,64,43356,103495,4097,10280,99331,73770,256,32,46093,41821]

theorem envBound47023 : H12AffineFastState.Bounded env47023 := by
  intro p hp
  have h : env47023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47022_47023 : H12AffineEnvironment.transform 16 70727 env47022 = env47023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env47022 == env47023) = true)

theorem identity47023 : scanCanonicalize (H12AffineFastState.compose env47023 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47023 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,65536,70727,10280,1024,1,69910,32,65862,65876,8192,64,10588,70727,4097,10280,66563,73770,256,32,13325,9053]

theorem envBound47024 : H12AffineFastState.Bounded env47024 := by
  intro p hp
  have h : env47024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47023_47024 : H12AffineEnvironment.transform 14 0 env47023 = env47024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47023 == env47024) = true)

theorem identity47024 : scanCanonicalize (H12AffineFastState.compose env47024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,13389,10280,1024,1,12572,32,8524,8542,8192,64,10588,13389,4097,10280,9225,32,256,32,13325,9053]

theorem envBound47025 : H12AffineFastState.Bounded env47025 := by
  intro p hp
  have h : env47025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47024_47025 : H12AffineEnvironment.transform 15 8202 env47024 = env47025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47024 == env47025) = true)

theorem identity47025 : scanCanonicalize (H12AffineFastState.compose env47025 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47025 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,0,34,5221,2048,1024,1,4404,32,356,374,40,64,2420,5221,4097,2048,1057,32,256,32,5157,885]

theorem envBound47026 : H12AffineFastState.Bounded env47026 := by
  intro p hp
  have h : env47026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47025_47026 : H12AffineEnvironment.transform 12 40 env47025 = env47026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47025 == env47026) = true)

theorem identity47026 : scanCanonicalize (H12AffineFastState.compose env47026 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47026 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env47027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,40,5377,0,34,5221,1,1024,1,4404,32,356,374,40,64,373,5221,4097,1,1057,32,256,32,5157,885]

theorem envBound47027 : H12AffineFastState.Bounded env47027 := by
  intro p hp
  have h : env47027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47026_47027 : H12AffineEnvironment.transform 10 1 env47026 = env47027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47026 == env47027) = true)

theorem identity47027 : scanCanonicalize (H12AffineFastState.compose env47027 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound47027 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47028 : List Nat := [2,4,8,16,32,64,8,256,512,69,1,4096,40,4420,0,34,4128,1,69,1,4404,32,356,374,40,64,373,4128,4097,1,100,32,256,32,4192,885]

theorem envBound47028 : H12AffineFastState.Bounded env47028 := by
  intro p hp
  have h : env47028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47027_47028 : H12AffineEnvironment.transform 9 69 env47027 = env47028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env47027 == env47028) = true)

theorem identity47028 : scanCanonicalize (H12AffineFastState.compose env47028 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47028 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47029 : List Nat := [2,4,8,16,32,64,8,117,512,69,1,4096,40,4145,0,34,4128,1,69,1,4161,32,17,3,40,64,0,4128,4097,1,100,32,117,32,4192,512]

theorem envBound47029 : H12AffineFastState.Bounded env47029 := by
  intro p hp
  have h : env47029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47028_47029 : H12AffineEnvironment.transform 7 117 env47028 = env47029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47028 == env47029) = true)

theorem identity47029 : scanCanonicalize (H12AffineFastState.compose env47029 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound47029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47030 : List Nat := [2,4,8,16,32,64,8,117,512,69,1,27,40,42,0,34,59,1,69,1,90,32,17,3,40,64,0,59,26,1,100,32,117,32,123,512]

theorem envBound47030 : H12AffineFastState.Bounded env47030 := by
  intro p hp
  have h : env47030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47029_47030 : H12AffineEnvironment.transform 11 27 env47029 = env47030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env47029 == env47030) = true)

theorem identity47030 : scanCanonicalize (H12AffineFastState.compose env47030 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound47030 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47031 : List Nat := [2,4,8,16,32,49,8,4,512,52,1,27,40,42,0,34,59,1,52,1,43,32,17,3,40,49,0,59,26,1,21,32,4,32,10,512]

theorem envBound47031 : H12AffineFastState.Bounded env47031 := by
  intro p hp
  have h : env47031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47030_47031 : H12AffineEnvironment.transform 5 49 env47030 = env47031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env47030 == env47031) = true)

theorem identity47031 : scanCanonicalize (H12AffineFastState.compose env47031 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound47031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47032 : List Nat := [2,4,8,16,32,49,8,4,47,52,1,27,40,42,0,34,59,1,52,1,43,32,17,3,40,49,0,59,26,1,21,32,4,32,10,47]

theorem envBound47032 : H12AffineFastState.Bounded env47032 := by
  intro p hp
  have h : env47032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47031_47032 : H12AffineEnvironment.transform 8 47 env47031 = env47032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env47031 == env47032) = true)

theorem identity47032 : scanCanonicalize (H12AffineFastState.compose env47032 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47033 : List Nat := [2,4,8,1,32,32,8,4,47,37,1,10,40,42,0,34,42,1,37,1,43,32,0,3,40,32,0,42,11,1,4,32,4,32,10,47]

theorem envBound47033 : H12AffineFastState.Bounded env47033 := by
  intro p hp
  have h : env47033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47032_47033 : H12AffineEnvironment.transform 3 1 env47032 = env47033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47032 == env47033) = true)

theorem identity47033 : scanCanonicalize (H12AffineFastState.compose env47033 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound47033 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47034 : List Nat := [2,4,8,1,11,11,8,4,4,14,1,10,3,1,0,9,1,1,14,1,0,11,0,3,3,11,0,1,11,1,4,11,4,11,10,4]

theorem envBound47034 : H12AffineFastState.Bounded env47034 := by
  intro p hp
  have h : env47034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47033_47034 : H12AffineEnvironment.transform 4 11 env47033 = env47034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env47033 == env47034) = true)

theorem identity47034 : scanCanonicalize (H12AffineFastState.compose env47034 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47034 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47035 : List Nat := [2,4,2,1,1,1,2,4,4,4,1,0,3,1,0,3,1,1,4,1,0,1,0,3,3,1,0,1,1,1,4,1,4,1,0,4]

theorem envBound47035 : H12AffineFastState.Bounded env47035 := by
  intro p hp
  have h : env47035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47034_47035 : H12AffineEnvironment.transform 2 2 env47034 = env47035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47034 == env47035) = true)

theorem identity47035 : scanCanonicalize (H12AffineFastState.compose env47035 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47036 : List Nat := [1,4,1,1,1,1,1,4,4,4,1,0,0,1,0,0,1,1,4,1,0,1,0,0,0,1,0,1,1,1,4,1,4,1,0,4]

theorem envBound47036 : H12AffineFastState.Bounded env47036 := by
  intro p hp
  have h : env47036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47035_47036 : H12AffineEnvironment.transform 0 1 env47035 = env47036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47035 == env47036) = true)

def env47037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,32,98631,98644,8193,64,245019,103494,4096,212079,99330,73771,256,32,46092,41821]

theorem envBound47037 : H12AffineFastState.Bounded env47037 := by
  intro p hp
  have h : env47037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47021_47037 : H12AffineEnvironment.transform 6 9 env47021 = env47037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47021 == env47037) = true)

theorem identity47037 : scanCanonicalize (H12AffineFastState.compose env47037 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,32,73755,73736,8193,64,203847,79130,4096,212079,75102,73771,256,32,5456,513]

theorem envBound47038 : H12AffineFastState.Bounded env47038 := by
  intro p hp
  have h : env47038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47037_47038 : H12AffineEnvironment.transform 14 8540 env47037 = env47038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47037 == env47038) = true)

theorem identity47038 : scanCanonicalize (H12AffineFastState.compose env47038 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound47038 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,13673,10281,1024,8541,77898,32,73755,73736,8193,64,76078,79130,4096,67846,75102,73771,256,32,5456,513]

theorem envBound47039 : H12AffineFastState.Bounded env47039 := by
  intro p hp
  have h : env47039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47038_47039 : H12AffineEnvironment.transform 16 13673 env47038 = env47039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env47038 == env47039) = true)

theorem identity47039 : scanCanonicalize (H12AffineFastState.compose env47039 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound47039 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,9498,13673,10281,1024,8541,5456,32,1281,1298,8193,64,3124,4096,4096,11292,68,1329,256,32,5456,513]

theorem envBound47040 : H12AffineFastState.Bounded env47040 := by
  intro p hp
  have h : env47040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47039_47040 : H12AffineEnvironment.transform 15 9498 env47039 = env47040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env47039 == env47040) = true)

theorem identity47040 : scanCanonicalize (H12AffineFastState.compose env47040 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47040 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47041 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8540,8202,12409,10281,272,8541,4160,32,17,2,8193,64,2340,4096,4096,10508,68,33,256,32,4160,513]

theorem envBound47041 : H12AffineFastState.Bounded env47041 := by
  intro p hp
  have h : env47041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47040_47041 : H12AffineEnvironment.transform 9 272 env47040 = env47041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47040 == env47041) = true)

theorem identity47041 : scanCanonicalize (H12AffineFastState.compose env47041 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47041 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47042 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,8192,4113,8233,8202,12409,10281,101,8232,4160,32,17,2,8193,64,2129,4096,4096,10361,68,33,117,32,4160,513]

theorem envBound47042 : H12AffineFastState.Bounded env47042 := by
  intro p hp
  have h : env47042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47041_47042 : H12AffineEnvironment.transform 7 117 env47041 = env47042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47041 == env47042) = true)

theorem identity47042 : scanCanonicalize (H12AffineFastState.compose env47042 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound47042 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47043 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,8192,2129,8233,8202,10297,10281,101,8232,2048,32,17,2,8193,64,2129,2112,2112,10361,68,33,117,32,2048,513]

theorem envBound47043 : H12AffineFastState.Bounded env47043 := by
  intro p hp
  have h : env47043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47042_47043 : H12AffineEnvironment.transform 11 2112 env47042 = env47043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env47042 == env47043) = true)

theorem identity47043 : scanCanonicalize (H12AffineFastState.compose env47043 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound47043 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47044 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,121,2129,80,115,2112,2128,101,81,2048,32,17,2,120,64,2129,2112,2112,2048,68,33,117,32,2048,513]

theorem envBound47044 : H12AffineFastState.Bounded env47044 := by
  intro p hp
  have h : env47044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47043_47044 : H12AffineEnvironment.transform 12 121 env47043 = env47044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env47043 == env47044) = true)

theorem identity47044 : scanCanonicalize (H12AffineFastState.compose env47044 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound47044 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47045 : List Nat := [2,4,8,16,32,64,9,117,58,101,2048,2112,121,2129,80,115,2112,2128,101,81,2048,32,17,2,120,64,2129,2112,2112,2048,68,33,117,32,2048,59]

theorem envBound47045 : H12AffineFastState.Bounded env47045 := by
  intro p hp
  have h : env47045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47044_47045 : H12AffineEnvironment.transform 8 58 env47044 = env47045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env47044 == env47045) = true)

theorem identity47045 : scanCanonicalize (H12AffineFastState.compose env47045 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound47045 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47046 : List Nat := [2,4,8,16,32,64,9,117,58,101,81,17,121,0,80,115,17,1,101,81,81,32,17,2,120,64,0,17,17,81,68,33,117,32,81,59]

theorem envBound47046 : H12AffineFastState.Bounded env47046 := by
  intro p hp
  have h : env47046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47045_47046 : H12AffineEnvironment.transform 10 81 env47045 = env47046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env47045 == env47046) = true)

theorem identity47046 : scanCanonicalize (H12AffineFastState.compose env47046 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47047 : List Nat := [2,4,8,16,32,16,9,37,58,53,1,17,41,0,0,35,17,1,53,1,1,32,17,2,40,16,0,17,17,1,20,33,37,32,1,59]

theorem envBound47047 : H12AffineFastState.Bounded env47047 := by
  intro p hp
  have h : env47047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47046_47047 : H12AffineEnvironment.transform 5 16 env47046 = env47047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47046 == env47047) = true)

def env47048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1024,32769,102678,32,98766,98644,8328,64,245018,103631,4233,212078,99467,73890,256,32,46213,41821]

theorem envBound47048 : H12AffineFastState.Bounded env47048 := by
  intro p hp
  have h : env47048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47020_47048 : H12AffineEnvironment.transform 17 10401 env47020 = env47048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47020 == env47048) = true)

theorem identity47048 : scanCanonicalize (H12AffineFastState.compose env47048 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound47048 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,103494,10401,1024,32769,102678,32,98766,98644,8328,64,10588,103631,4233,43048,99467,73890,256,32,46213,41821]

theorem envBound47049 : H12AffineFastState.Bounded env47049 := by
  intro p hp
  have h : env47049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47048_47049 : H12AffineEnvironment.transform 16 103494 env47048 = env47049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env47048 == env47049) = true)

theorem identity47049 : scanCanonicalize (H12AffineFastState.compose env47049 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound47049 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env47050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5528,10401,1024,32769,4296,32,16,138,8328,64,10588,5393,4233,43048,1365,41340,256,32,46213,41821]

theorem envBound47050 : H12AffineFastState.Bounded env47050 := by
  intro p hp
  have h : env47050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47049_47050 : H12AffineEnvironment.transform 15 33246 env47049 = env47050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env47049 == env47050) = true)

theorem identity47050 : scanCanonicalize (H12AffineFastState.compose env47050 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound47050 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env47051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,217,263,5528,10401,1024,216,4296,32,16,138,8328,64,10588,5393,4233,10481,1365,8613,256,32,13404,9092]

theorem envBound47051 : H12AffineFastState.Bounded env47051 := by
  intro p hp
  have h : env47051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47050_47051 : H12AffineEnvironment.transform 14 217 env47050 = env47051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env47050 == env47051) = true)

theorem identity47051 : scanCanonicalize (H12AffineFastState.compose env47051 (packedSelected [0,5,8,9,11,15,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47051 : packedSelected [0,5,8,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env47052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,81,263,5392,10281,1024,80,4160,32,16,2,8192,64,10588,5393,4097,10361,1365,8493,256,32,13404,8972]

theorem envBound47052 : H12AffineFastState.Bounded env47052 := by
  intro p hp
  have h : env47052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47051_47052 : H12AffineEnvironment.transform 6 8 env47051 = env47052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47051 == env47052) = true)

theorem identity47052 : scanCanonicalize (H12AffineFastState.compose env47052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47053 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,81,263,4096,10281,272,80,4160,32,16,2,8192,64,10588,4097,4097,10361,69,8493,256,32,12620,8972]

theorem envBound47053 : H12AffineFastState.Bounded env47053 := by
  intro p hp
  have h : env47053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47052_47053 : H12AffineEnvironment.transform 9 272 env47052 = env47053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47052 == env47053) = true)

theorem identity47053 : scanCanonicalize (H12AffineFastState.compose env47053 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47053 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env47054 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,8192,4113,33,263,4096,10281,272,32,4144,32,16,2,8192,48,10540,4097,4097,10249,53,8493,256,32,12604,8972]

theorem envBound47054 : H12AffineFastState.Bounded env47054 := by
  intro p hp
  have h : env47054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47053_47054 : H12AffineEnvironment.transform 5 48 env47053 = env47054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47053 == env47054) = true)

def env47055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491564,2098649,4233,2524633,2102685,2142645,256,32,46213,2175563]

theorem envBound47055 : H12AffineFastState.Bounded env47055 := by
  intro p hp
  have h : env47055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47018_47055 : H12AffineEnvironment.transform 21 33 env47018 = env47055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47018 == env47055) = true)

theorem identity47055 : scanCanonicalize (H12AffineFastState.compose env47055 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound47055 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491564,2098649,4233,2524633,2102685,2142645,256,32,46213,2143125]

theorem envBound47056 : H12AffineFastState.Bounded env47056 := by
  intro p hp
  have h : env47056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47055_47056 : H12AffineEnvironment.transform 15 33246 env47055 = env47056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env47055 == env47056) = true)

theorem identity47056 : scanCanonicalize (H12AffineFastState.compose env47056 (packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound47056 : packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,301364,33,297452,138,8328,64,171416,302317,4233,138477,298153,272513,256,32,46213,273057]

theorem envBound47057 : H12AffineFastState.Bounded env47057 := by
  intro p hp
  have h : env47057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47056_47057 : H12AffineEnvironment.transform 20 301364 env47056 = env47057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env47056 == env47057) = true)

theorem identity47057 : scanCanonicalize (H12AffineFastState.compose env47057 (packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound47057 : packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS < 2^1333 := by decide +kernel

def env47058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10400,1024,32769,45460,33,41292,138,8328,64,171416,46157,4233,138477,41993,33,256,32,46213,513]

theorem envBound47058 : H12AffineFastState.Bounded env47058 := by
  intro p hp
  have h : env47058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47057_47058 : H12AffineEnvironment.transform 17 10400 env47057 = env47058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47057 == env47058) = true)

theorem identity47058 : scanCanonicalize (H12AffineFastState.compose env47058 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound47058 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env47059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13340,10400,1024,32769,45460,33,41292,138,8328,64,43396,46157,4233,10481,41993,33,256,32,46213,513]

theorem envBound47059 : H12AffineFastState.Bounded env47059 := by
  intro p hp
  have h : env47059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47058_47059 : H12AffineEnvironment.transform 16 13340 env47058 = env47059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env47058 == env47059) = true)

theorem identity47059 : scanCanonicalize (H12AffineFastState.compose env47059 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound47059 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env47060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13340,10400,1024,8660,4161,33,153,138,8328,64,2129,5528,4233,10481,1500,33,256,32,5456,513]

theorem envBound47060 : H12AffineFastState.Bounded env47060 := by
  intro p hp
  have h : env47060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47059_47060 : H12AffineEnvironment.transform 14 8661 env47059 = env47060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env47059 == env47060) = true)

theorem identity47060 : scanCanonicalize (H12AffineFastState.compose env47060 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound47060 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5377,1480,1046,4097,3261,1024,1481,4161,33,153,138,1173,64,2129,5528,4233,3308,1500,33,256,32,5456,513]

theorem envBound47061 : H12AffineFastState.Bounded env47061 := by
  intro p hp
  have h : env47061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47060_47061 : H12AffineEnvironment.transform 12 1053 env47060 = env47061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env47060 == env47061) = true)

theorem identity47061 : scanCanonicalize (H12AffineFastState.compose env47061 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound47061 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47062 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,4160,137,343,4097,2556,321,136,4161,33,153,138,468,64,2129,4313,4233,2477,157,33,256,32,4113,513]

theorem envBound47062 : H12AffineFastState.Bounded env47062 := by
  intro p hp
  have h : env47062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47061_47062 : H12AffineEnvironment.transform 9 321 env47061 = env47062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47061 == env47062) = true)

theorem identity47062 : scanCanonicalize (H12AffineFastState.compose env47062 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47062 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47063 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,4112,137,263,4097,2476,273,136,4113,33,153,138,388,16,2049,4233,4233,2477,157,33,256,32,4113,513]

theorem envBound47063 : H12AffineFastState.Bounded env47063 := by
  intro p hp
  have h : env47063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47062_47063 : H12AffineEnvironment.transform 5 16 env47062 = env47063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47062 == env47063) = true)

theorem identity47063 : scanCanonicalize (H12AffineFastState.compose env47063 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound47063 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47064 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,2493,268,2477,137,263,2492,2476,273,136,2476,33,153,138,388,16,2049,2356,2356,2477,157,33,256,32,2476,513]

theorem envBound47064 : H12AffineFastState.Bounded env47064 := by
  intro p hp
  have h : env47064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47063_47064 : H12AffineEnvironment.transform 11 2493 env47063 = env47064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env47063 == env47064) = true)

theorem identity47064 : scanCanonicalize (H12AffineFastState.compose env47064 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound47064 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env47065 : List Nat := [2,4,8,16,32,16,128,256,512,273,396,49,268,33,137,263,48,32,273,136,32,33,153,138,388,16,397,184,184,33,157,33,256,32,32,513]

theorem envBound47065 : H12AffineFastState.Bounded env47065 := by
  intro p hp
  have h : env47065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47064_47065 : H12AffineEnvironment.transform 10 396 env47064 = env47065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env47064 == env47065) = true)

theorem identity47065 : scanCanonicalize (H12AffineFastState.compose env47065 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound47065 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env47066 : List Nat := [2,4,8,16,32,16,128,173,512,188,33,49,161,33,137,170,48,32,188,136,32,33,153,138,41,16,32,184,184,33,157,33,173,32,32,513]

theorem envBound47066 : H12AffineFastState.Bounded env47066 := by
  intro p hp
  have h : env47066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47065_47066 : H12AffineEnvironment.transform 7 173 env47065 = env47066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47065 == env47066) = true)

def env47067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685837,2098648,4232,2524632,2102685,6336917,256,32,46213,2175563]

theorem envBound47067 : H12AffineFastState.Bounded env47067 := by
  intro p hp
  have h : env47067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47017_47067 : H12AffineEnvironment.transform 22 2101465 env47017 = env47067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env47017 == env47067) = true)

def env47068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491565,2098648,4232,2524632,2102685,2142645,256,32,46213,2175563]

theorem envBound47068 : H12AffineFastState.Bounded env47068 := by
  intro p hp
  have h : env47068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47067_47068 : H12AffineEnvironment.transform 21 32 env47067 = env47068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47067 == env47068) = true)

theorem identity47068 : scanCanonicalize (H12AffineFastState.compose env47068 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound47068 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,73755,98645,8328,64,472175,79130,4232,505114,75103,98679,256,32,46213,649]

theorem envBound47069 : H12AffineFastState.Bounded env47069 := by
  intro p hp
  have h : env47069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47068_47069 : H12AffineEnvironment.transform 20 78018 env47068 = env47069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env47068 == env47069) = true)

theorem identity47069 : scanCanonicalize (H12AffineFastState.compose env47069 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47069 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env47070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472175,79130,4096,505114,75103,98679,256,32,46093,513]

theorem envBound47070 : H12AffineFastState.Bounded env47070 := by
  intro p hp
  have h : env47070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47069_47070 : H12AffineEnvironment.transform 6 8 env47069 = env47070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47069 == env47070) = true)

theorem identity47070 : scanCanonicalize (H12AffineFastState.compose env47070 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47070 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,32,73755,73737,8192,64,472175,79130,4096,463942,75103,73771,256,32,5457,513]

theorem envBound47071 : H12AffineFastState.Bounded env47071 := by
  intro p hp
  have h : env47071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47070_47071 : H12AffineEnvironment.transform 14 8540 env47070 = env47071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47070 == env47071) = true)

theorem identity47071 : scanCanonicalize (H12AffineFastState.compose env47071 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47071 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4161,32,16,2,8192,64,398436,5393,4096,406605,1364,32,256,32,5457,513]

theorem envBound47072 : H12AffineFastState.Bounded env47072 := by
  intro p hp
  have h : env47072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47071_47072 : H12AffineEnvironment.transform 15 8203 env47071 = env47072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47071 == env47072) = true)

theorem identity47072 : scanCanonicalize (H12AffineFastState.compose env47072 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47072 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10360,1024,8541,4161,32,16,2,8192,64,146460,5393,4096,138293,1364,32,256,32,5457,513]

theorem envBound47073 : H12AffineFastState.Bounded env47073 := by
  intro p hp
  have h : env47073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47072_47073 : H12AffineEnvironment.transform 17 10360 env47072 = env47073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47072 == env47073) = true)

def env47074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491564,2098648,4232,2524632,2102685,2142644,256,32,46213,2175563]

theorem envBound47074 : H12AffineFastState.Bounded env47074 := by
  intro p hp
  have h : env47074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47067_47074 : H12AffineEnvironment.transform 21 33 env47067 = env47074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47067 == env47074) = true)

theorem identity47074 : scanCanonicalize (H12AffineFastState.compose env47074 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47074 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101465,41310,8328,64,2491564,2098648,4232,2524632,2102685,2142644,256,32,46213,2101824]

theorem envBound47075 : H12AffineFastState.Bounded env47075 := by
  intro p hp
  have h : env47075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47074_47075 : H12AffineEnvironment.transform 15 8203 env47074 = env47075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47074 == env47075) = true)

def env47076 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101385,41230,8328,16,2491564,2098568,4232,2524552,2102685,2142644,256,32,46213,2101776]

theorem envBound47076 : H12AffineFastState.Bounded env47076 := by
  intro p hp
  have h : env47076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47075_47076 : H12AffineEnvironment.transform 5 16 env47075 = env47076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47075 == env47076) = true)

theorem identity47076 : scanCanonicalize (H12AffineFastState.compose env47076 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound47076 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env47077 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35244,1024,32769,2097152,33,2101385,41230,8328,16,2264320,2098568,4232,2231332,2102685,2142644,256,32,46213,2101776]

theorem envBound47077 : H12AffineFastState.Bounded env47077 := by
  intro p hp
  have h : env47077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47076_47077 : H12AffineEnvironment.transform 17 35244 env47076 = env47077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env47076 == env47077) = true)

theorem identity47077 : scanCanonicalize (H12AffineFastState.compose env47077 (packedSelected [0,3,9,10,22,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47077 : packedSelected [0,3,9,10,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47078 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35108,1024,32769,2097152,33,2101249,41230,8192,16,2264320,2098432,4096,2231332,2102549,2142524,256,32,46093,2101776]

theorem envBound47078 : H12AffineFastState.Bounded env47078 := by
  intro p hp
  have h : env47078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47077_47078 : H12AffineEnvironment.transform 6 8 env47077 = env47078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47077 == env47078) = true)

theorem identity47078 : scanCanonicalize (H12AffineFastState.compose env47078 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(20+1) ^^^ 4113) := by decide +kernel

theorem selectedBound47078 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47079 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35108,1024,32769,4113,33,16,41230,8192,16,171281,5393,4096,138293,1284,41261,256,32,46093,513]

theorem envBound47079 : H12AffineFastState.Bounded env47079 := by
  intro p hp
  have h : env47079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47078_47079 : H12AffineEnvironment.transform 20 4113 env47078 = env47079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4113 env47078 == env47079) = true)

theorem identity47079 : scanCanonicalize (H12AffineFastState.compose env47079 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound47079 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47080 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,13341,35108,1024,32769,4113,33,16,41230,8192,16,43276,5393,4096,10280,1284,41261,256,32,46093,513]

theorem envBound47080 : H12AffineFastState.Bounded env47080 := by
  intro p hp
  have h : env47080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47079_47080 : H12AffineEnvironment.transform 16 13341 env47079 = env47080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env47079 == env47080) = true)

theorem identity47080 : scanCanonicalize (H12AffineFastState.compose env47080 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47080 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47081 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,0,8203,13341,2340,1024,1,4113,33,16,8462,8192,16,10508,5393,4096,10280,1284,8493,256,32,13325,513]

theorem envBound47081 : H12AffineFastState.Bounded env47081 := by
  intro p hp
  have h : env47081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47080_47081 : H12AffineEnvironment.transform 14 0 env47080 = env47081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47080 == env47081) = true)

theorem identity47081 : scanCanonicalize (H12AffineFastState.compose env47081 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47081 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47082 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1024,1,4113,33,16,2,268,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound47082 : H12AffineFastState.Bounded env47082 := by
  intro p hp
  have h : env47082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47081_47082 : H12AffineEnvironment.transform 12 268 env47081 = env47082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47081 == env47082) = true)

theorem identity47082 : scanCanonicalize (H12AffineFastState.compose env47082 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47083 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5173,2048,1024,1,4113,33,16,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound47083 : H12AffineFastState.Bounded env47083 := by
  intro p hp
  have h : env47083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47082_47083 : H12AffineEnvironment.transform 7 36 env47082 = env47083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47082 == env47083) = true)

def env47084 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101384,41231,8328,17,2491564,2098569,4232,2524553,2102685,2142644,256,32,46213,2101777]

theorem envBound47084 : H12AffineFastState.Bounded env47084 := by
  intro p hp
  have h : env47084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47075_47084 : H12AffineEnvironment.transform 5 17 env47075 = env47084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47075 == env47084) = true)

theorem identity47084 : scanCanonicalize (H12AffineFastState.compose env47084 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47084 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env47085 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101248,41231,8192,17,2491428,2098433,4096,2524417,2102549,2142524,256,32,46093,2101777]

theorem envBound47085 : H12AffineFastState.Bounded env47085 := by
  intro p hp
  have h : env47085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47084_47085 : H12AffineEnvironment.transform 6 8 env47084 = env47085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47084 == env47085) = true)

theorem identity47085 : scanCanonicalize (H12AffineFastState.compose env47085 (packedSelected [3,4,5,9,10,12,14,15,16,18,19,21,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound47085 : packedSelected [3,4,5,9,10,12,14,15,16,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env47086 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,262144,1024,8461,2097152,33,2101248,3,8192,17,2491428,2098433,4096,2499597,2102549,2101296,256,32,5377,2101777]

theorem envBound47086 : H12AffineFastState.Bounded env47086 := by
  intro p hp
  have h : env47086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47085_47086 : H12AffineEnvironment.transform 14 8460 env47085 = env47086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env47085 == env47086) = true)

theorem identity47086 : scanCanonicalize (H12AffineFastState.compose env47086 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound47086 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env47087 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,10281,1024,8461,2097152,33,2101248,3,8192,17,2239501,2098433,4096,2231332,2102549,2101296,256,32,5377,2101777]

theorem envBound47087 : H12AffineFastState.Bounded env47087 := by
  intro p hp
  have h : env47087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47086_47087 : H12AffineEnvironment.transform 17 10281 env47086 = env47087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47086 == env47087) = true)

theorem identity47087 : scanCanonicalize (H12AffineFastState.compose env47087 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 4128) := by decide +kernel

theorem selectedBound47087 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env47088 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,4128,10281,1024,8461,2097152,33,2101248,3,8192,17,2112557,2098433,4096,2104324,2102549,2101296,256,32,5377,2101777]

theorem envBound47088 : H12AffineFastState.Bounded env47088 := by
  intro p hp
  have h : env47088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47087_47088 : H12AffineEnvironment.transform 16 4128 env47087 = env47088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4128 env47087 == env47088) = true)

theorem identity47088 : scanCanonicalize (H12AffineFastState.compose env47088 (packedSelected [6,14] rootPS)) = affineNative (2^(20+1) ^^^ 12605) := by decide +kernel

theorem selectedBound47088 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env47089 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,4128,10281,1024,8461,12605,33,8509,3,8192,17,3344,13372,4096,11577,9256,8461,256,32,5377,9004]

theorem envBound47089 : H12AffineFastState.Bounded env47089 := by
  intro p hp
  have h : env47089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47088_47089 : H12AffineEnvironment.transform 20 12605 env47088 = env47089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12605 env47088 == env47089) = true)

theorem identity47089 : scanCanonicalize (H12AffineFastState.compose env47089 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound47089 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env47090 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,5377,1296,1047,4128,3125,1024,1297,5409,33,1313,3,1052,17,3344,4128,4096,2341,52,1297,256,32,5377,1840]

theorem envBound47090 : H12AffineFastState.Bounded env47090 := by
  intro p hp
  have h : env47090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47089_47090 : H12AffineEnvironment.transform 12 1052 env47089 = env47090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env47089 == env47090) = true)

theorem identity47090 : scanCanonicalize (H12AffineFastState.compose env47090 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47090 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47091 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,1052,5377,1296,1047,4096,3093,1024,1297,5377,1,1281,3,1052,17,3344,4096,4096,2309,20,1297,256,0,5377,1808]

theorem envBound47091 : H12AffineFastState.Bounded env47091 := by
  intro p hp
  have h : env47091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47090_47091 : H12AffineEnvironment.transform 4 0 env47090 = env47091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47090 == env47091) = true)

theorem identity47091 : scanCanonicalize (H12AffineFastState.compose env47091 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound47091 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47092 : List Nat := [2,4,8,16,0,17,8,256,512,1024,1809,4096,1052,5377,1296,1047,4096,772,1024,1297,5377,1,1281,3,1052,17,513,4096,4096,1556,20,1297,256,0,5377,1808]

theorem envBound47092 : H12AffineFastState.Bounded env47092 := by
  intro p hp
  have h : env47092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47091_47092 : H12AffineEnvironment.transform 10 1809 env47091 = env47092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env47091 == env47092) = true)

theorem identity47092 : scanCanonicalize (H12AffineFastState.compose env47092 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound47092 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47093 : List Nat := [2,4,8,16,0,17,8,256,512,257,528,4096,285,4096,17,278,4096,772,257,16,4096,1,0,3,285,17,513,4096,4096,789,20,16,256,0,4096,529]

theorem envBound47093 : H12AffineFastState.Bounded env47093 := by
  intro p hp
  have h : env47093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47092_47093 : H12AffineEnvironment.transform 9 257 env47092 = env47093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env47092 == env47093) = true)

theorem identity47093 : scanCanonicalize (H12AffineFastState.compose env47093 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47093 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47094 : List Nat := [2,4,8,1,0,0,8,256,512,257,513,4096,268,4096,0,263,4096,772,257,1,4096,1,0,3,268,0,513,4096,4096,772,5,1,256,0,4096,512]

theorem envBound47094 : H12AffineFastState.Bounded env47094 := by
  intro p hp
  have h : env47094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47093_47094 : H12AffineEnvironment.transform 3 1 env47093 = env47094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47093 == env47094) = true)

theorem identity47094 : scanCanonicalize (H12AffineFastState.compose env47094 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound47094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47095 : List Nat := [2,4,8,1,0,0,8,256,512,257,513,513,268,513,0,263,513,772,257,1,513,1,0,3,268,0,513,513,513,772,5,1,256,0,513,512]

theorem envBound47095 : H12AffineFastState.Bounded env47095 := by
  intro p hp
  have h : env47095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47094_47095 : H12AffineEnvironment.transform 11 513 env47094 = env47095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env47094 == env47095) = true)

theorem identity47095 : scanCanonicalize (H12AffineFastState.compose env47095 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound47095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47096 : List Nat := [2,4,6,1,0,0,6,256,512,257,513,513,258,513,0,263,513,772,257,1,513,1,0,3,258,0,513,513,513,772,5,1,256,0,513,512]

theorem envBound47096 : H12AffineFastState.Bounded env47096 := by
  intro p hp
  have h : env47096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47095_47096 : H12AffineEnvironment.transform 2 6 env47095 = env47096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env47095 == env47096) = true)

theorem identity47096 : scanCanonicalize (H12AffineFastState.compose env47096 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound47096 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47097 : List Nat := [2,4,6,1,0,0,6,256,260,257,261,261,258,261,0,263,261,0,257,1,261,1,0,3,258,0,261,261,261,0,5,1,256,0,261,260]

theorem envBound47097 : H12AffineFastState.Bounded env47097 := by
  intro p hp
  have h : env47097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47096_47097 : H12AffineEnvironment.transform 8 260 env47096 = env47097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env47096 == env47097) = true)

theorem identity47097 : scanCanonicalize (H12AffineFastState.compose env47097 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47097 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47098 : List Nat := [2,4,6,1,0,0,6,5,1,4,0,0,7,0,0,2,0,0,4,1,0,1,0,3,7,0,0,0,0,0,5,1,5,0,0,1]

theorem envBound47098 : H12AffineFastState.Bounded env47098 := by
  intro p hp
  have h : env47098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0