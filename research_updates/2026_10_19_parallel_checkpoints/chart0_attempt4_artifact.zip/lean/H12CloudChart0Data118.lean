import H12CloudChart0Data117

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound29929 : H12AffineFastState.Bounded env29929 := by
  intro p hp
  have h : env29929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29928_29929 : H12AffineEnvironment.transform 5 16 env29928 = env29929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29928 == env29929) = true)

theorem identity29929 : scanCanonicalize (H12AffineFastState.compose env29929 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29929 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29930 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,21761,65536,5392,89379,1024,21760,82966,87298,87347,87328,41,17,67619,81970,17445,2049,86274,260,256,21793,16677,22052]

theorem envBound29930 : H12AffineFastState.Bounded env29930 := by
  intro p hp
  have h : env29930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29929_29930 : H12AffineEnvironment.transform 12 41 env29929 = env29930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29929 == env29930) = true)

theorem identity29930 : scanCanonicalize (H12AffineFastState.compose env29930 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29930 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29931 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,21761,263,5392,23588,1024,21760,17681,21509,21556,21543,41,17,2340,16693,17445,2049,20485,260,256,21793,16677,22052]

theorem envBound29931 : H12AffineFastState.Bounded env29931 := by
  intro p hp
  have h : env29931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29930_29931 : H12AffineEnvironment.transform 15 263 env29930 = env29931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29930 == env29931) = true)

theorem identity29931 : scanCanonicalize (H12AffineFastState.compose env29931 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound29931 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29932 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,41,16384,18724,263,2357,16385,1024,18725,17681,18464,18449,18434,41,17,2340,16693,17445,2049,19488,260,256,18692,16677,18945]

theorem envBound29932 : H12AffineFastState.Bounded env29932 := by
  intro p hp
  have h : env29932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29931_29932 : H12AffineEnvironment.transform 11 3109 env29931 = env29932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env29931 == env29932) = true)

theorem identity29932 : scanCanonicalize (H12AffineFastState.compose env29932 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound29932 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29933 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,41,3125,1297,263,2357,3124,1024,1296,2340,1045,1060,1079,41,17,2340,3328,2064,2049,21,260,256,1329,3344,1588]

theorem envBound29933 : H12AffineFastState.Bounded env29933 := by
  intro p hp
  have h : env29933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29932_29933 : H12AffineEnvironment.transform 13 3125 env29932 = env29933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env29932 == env29933) = true)

theorem identity29933 : scanCanonicalize (H12AffineFastState.compose env29933 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound29933 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env29934 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1296,309,41,293,1297,263,1061,292,1024,1296,1076,1045,1060,1079,41,17,1076,16,1280,1297,21,260,256,1329,0,1588]

theorem envBound29934 : H12AffineFastState.Bounded env29934 := by
  intro p hp
  have h : env29934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29933_29934 : H12AffineEnvironment.transform 10 1296 env29933 = env29934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env29933 == env29934) = true)

theorem identity29934 : scanCanonicalize (H12AffineFastState.compose env29934 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29934 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29935 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1077,16,41,0,1076,34,1061,1,1024,1077,1076,1045,1060,1079,41,17,1076,16,1061,1076,21,33,37,1044,0,1588]

theorem envBound29935 : H12AffineFastState.Bounded env29935 := by
  intro p hp
  have h : env29935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29934_29935 : H12AffineEnvironment.transform 7 37 env29934 = env29935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29934 == env29935) = true)

theorem identity29935 : scanCanonicalize (H12AffineFastState.compose env29935 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29935 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env29936 : List Nat := [2,4,8,1,32,1,8,37,512,1024,1060,1,41,0,1061,34,1061,1,1024,1060,1061,1028,1060,1062,41,0,1061,1,1061,1061,4,33,37,1029,0,1573]

theorem envBound29936 : H12AffineFastState.Bounded env29936 := by
  intro p hp
  have h : env29936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29935_29936 : H12AffineEnvironment.transform 3 1 env29935 = env29936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29935 == env29936) = true)

theorem identity29936 : scanCanonicalize (H12AffineFastState.compose env29936 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound29936 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env29937 : List Nat := [2,4,8,1,32,1,8,37,512,516,544,1,41,0,545,34,545,1,516,544,545,512,544,546,41,0,545,1,545,545,4,33,37,513,0,33]

theorem envBound29937 : H12AffineFastState.Bounded env29937 := by
  intro p hp
  have h : env29937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29936_29937 : H12AffineEnvironment.transform 9 516 env29936 = env29937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env29936 == env29937) = true)

theorem identity29937 : scanCanonicalize (H12AffineFastState.compose env29937 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29937 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29938 : List Nat := [2,4,8,1,32,1,8,37,0,4,32,1,41,0,33,34,33,1,4,32,33,0,32,34,41,0,33,1,33,33,4,33,37,1,0,33]

theorem envBound29938 : H12AffineFastState.Bounded env29938 := by
  intro p hp
  have h : env29938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29937_29938 : H12AffineEnvironment.transform 8 0 env29937 = env29938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29937 == env29938) = true)

theorem identity29938 : scanCanonicalize (H12AffineFastState.compose env29938 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29939 : List Nat := [2,4,8,1,0,1,8,5,0,4,0,1,9,0,1,2,1,1,4,0,1,0,0,2,9,0,1,1,1,1,4,1,5,1,0,1]

theorem envBound29939 : H12AffineFastState.Bounded env29939 := by
  intro p hp
  have h : env29939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29938_29939 : H12AffineEnvironment.transform 4 0 env29938 = env29939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29938 == env29939) = true)

theorem identity29939 : scanCanonicalize (H12AffineFastState.compose env29939 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29940 : List Nat := [2,4,2,1,0,1,2,5,0,4,0,1,3,0,1,2,1,1,4,0,1,0,0,2,3,0,1,1,1,1,4,1,5,1,0,1]

theorem envBound29940 : H12AffineFastState.Bounded env29940 := by
  intro p hp
  have h : env29940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29939_29940 : H12AffineEnvironment.transform 2 2 env29939 = env29940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29939 == env29940) = true)

def env29941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272393,452649,95497,8193,65,292137,458024,45404,10281,399664,144493,256,21793,46092,474734]

theorem envBound29941 : H12AffineFastState.Bounded env29941 := by
  intro p hp
  have h : env29941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29912_29941 : H12AffineEnvironment.transform 6 9 env29912 = env29941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29912 == env29941) = true)

def env29942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272393,272441,95497,8193,65,292137,277816,45404,10281,317728,62589,256,21793,46092,392830]

theorem envBound29942 : H12AffineFastState.Bounded env29942 := by
  intro p hp
  have h : env29942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29941_29942 : H12AffineEnvironment.transform 16 49168 env29941 = env29942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29941 == env29942) = true)

theorem identity29942 : scanCanonicalize (H12AffineFastState.compose env29942 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound29942 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1024,32769,314421,272393,272441,41310,8193,65,292137,277816,45404,10281,317728,62589,256,21793,46092,272937]

theorem envBound29943 : H12AffineFastState.Bounded env29943 := by
  intro p hp
  have h : env29943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29942_29943 : H12AffineEnvironment.transform 15 54359 env29942 = env29943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env29942 == env29943) = true)

theorem identity29943 : scanCanonicalize (H12AffineFastState.compose env29943 (packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29943 : packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env29944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,41050,46109,262144,1024,32769,309304,272393,272441,41310,8193,65,262436,277816,45404,10281,306477,32880,256,8492,46092,272937]

theorem envBound29944 : H12AffineFastState.Bounded env29944 := by
  intro p hp
  have h : env29944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29943_29944 : H12AffineEnvironment.transform 13 13325 env29943 = env29944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29943 == env29944) = true)

theorem identity29944 : scanCanonicalize (H12AffineFastState.compose env29944 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound29944 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,41050,46109,43048,1024,32769,4112,32801,32785,41310,8193,65,43276,38160,45404,10281,1285,32880,256,8492,46092,33281]

theorem envBound29945 : H12AffineFastState.Bounded env29945 := by
  intro p hp
  have h : env29945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29944_29945 : H12AffineEnvironment.transform 17 43048 env29944 = env29945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env29944 == env29945) = true)

theorem identity29945 : scanCanonicalize (H12AffineFastState.compose env29945 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29945 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29946 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,40971,46109,43048,1024,32769,4112,32801,32785,41231,8193,16,43276,38160,45325,10281,1285,32801,256,8492,46092,33281]

theorem envBound29946 : H12AffineFastState.Bounded env29946 := by
  intro p hp
  have h : env29946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29945_29946 : H12AffineEnvironment.transform 5 17 env29945 = env29946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29945 == env29946) = true)

theorem identity29946 : scanCanonicalize (H12AffineFastState.compose env29946 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound29946 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29947 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,263,5393,2340,1024,8461,4112,8493,8477,3,8193,16,2048,13340,4097,10281,1285,8493,256,8492,5376,8973]

theorem envBound29947 : H12AffineFastState.Bounded env29947 := by
  intro p hp
  have h : env29947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29946_29947 : H12AffineEnvironment.transform 14 8460 env29946 = env29947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env29946 == env29947) = true)

theorem identity29947 : scanCanonicalize (H12AffineFastState.compose env29947 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29947 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29948 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,12345,8460,263,4389,2340,52,8461,4112,8493,8477,3,8193,16,2048,12328,4097,10281,305,8493,256,8492,4404,8973]

theorem envBound29948 : H12AffineFastState.Bounded env29948 := by
  intro p hp
  have h : env29948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29947_29948 : H12AffineEnvironment.transform 9 52 env29947 = env29948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29947 == env29948) = true)

theorem identity29948 : scanCanonicalize (H12AffineFastState.compose env29948 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29948 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29949 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,8192,12313,8460,263,4357,2308,20,8461,4112,8461,8477,3,8193,16,2048,12296,4097,10249,273,8461,256,8460,4372,8973]

theorem envBound29949 : H12AffineFastState.Bounded env29949 := by
  intro p hp
  have h : env29949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29948_29949 : H12AffineEnvironment.transform 4 0 env29948 = env29949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29948 == env29949) = true)

theorem identity29949 : scanCanonicalize (H12AffineFastState.compose env29949 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29949 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29950 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4372,1,263,4357,2308,20,0,4112,0,16,3,268,16,2048,4357,4097,2308,273,0,256,1,4372,512]

theorem envBound29950 : H12AffineFastState.Bounded env29950 := by
  intro p hp
  have h : env29950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29949_29950 : H12AffineEnvironment.transform 12 269 env29949 = env29950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29949 == env29950) = true)

theorem identity29950 : scanCanonicalize (H12AffineFastState.compose env29950 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound29950 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29951 : List Nat := [2,4,8,16,0,17,9,256,512,20,782,4096,269,4372,1,263,4357,522,20,0,4112,0,16,3,268,16,782,4357,4097,522,273,0,256,1,4372,512]

theorem envBound29951 : H12AffineFastState.Bounded env29951 := by
  intro p hp
  have h : env29951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29950_29951 : H12AffineEnvironment.transform 10 782 env29950 = env29951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env29950 == env29951) = true)

theorem identity29951 : scanCanonicalize (H12AffineFastState.compose env29951 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound29951 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29952 : List Nat := [2,4,8,16,0,17,9,256,512,20,782,538,269,782,1,263,799,522,20,0,522,0,16,3,268,16,782,799,539,522,273,0,256,1,782,512]

theorem envBound29952 : H12AffineFastState.Bounded env29952 := by
  intro p hp
  have h : env29952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29951_29952 : H12AffineEnvironment.transform 11 538 env29951 = env29952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env29951 == env29952) = true)

def env29953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272393,272440,95497,8193,65,292137,277817,45404,10281,317729,62588,256,21793,46092,392831]

theorem envBound29953 : H12AffineFastState.Bounded env29953 := by
  intro p hp
  have h : env29953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29941_29953 : H12AffineEnvironment.transform 16 49169 env29941 = env29953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29941 == env29953) = true)

theorem identity29953 : scanCanonicalize (H12AffineFastState.compose env29953 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound29953 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,77898,119927,119878,95497,8193,65,100695,115015,45404,10281,75103,62588,256,21793,46092,513]

theorem envBound29954 : H12AffineFastState.Bounded env29954 := by
  intro p hp
  have h : env29954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29953_29954 : H12AffineEnvironment.transform 17 130174 env29953 = env29954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env29953 == env29954) = true)

theorem identity29954 : scanCanonicalize (H12AffineFastState.compose env29954 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound29954 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,10280,1024,32769,58396,33,16,41311,8193,65,23809,5393,45404,10281,61705,62588,256,21793,46092,513]

theorem envBound29955 : H12AffineFastState.Bounded env29955 := by
  intro p hp
  have h : env29955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29954_29955 : H12AffineEnvironment.transform 15 54358 env29954 = env29955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env29954 == env29955) = true)

theorem identity29955 : scanCanonicalize (H12AffineFastState.compose env29955 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound29955 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,263,5440,10280,1024,21840,12621,33,16,29710,8193,65,23809,5393,25613,10281,9304,8493,256,21793,24925,513]

theorem envBound29956 : H12AffineFastState.Bounded env29956 := by
  intro p hp
  have h : env29956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29955_29956 : H12AffineEnvironment.transform 14 21841 env29955 = env29956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env29955 == env29956) = true)

theorem identity29956 : scanCanonicalize (H12AffineFastState.compose env29956 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29956 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8461,263,5440,10280,1024,8460,12621,33,16,82,8193,65,10589,5393,4177,10281,9304,8493,256,8573,5377,513]

theorem envBound29957 : H12AffineFastState.Bounded env29957 := by
  intro p hp
  have h : env29957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29956_29957 : H12AffineEnvironment.transform 13 13404 env29956 = env29957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29956 == env29957) = true)

theorem identity29957 : scanCanonicalize (H12AffineFastState.compose env29957 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29957 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,81,263,5440,2420,1024,80,4113,33,16,82,349,65,2049,5393,4177,2421,1284,113,256,33,5377,513]

theorem envBound29958 : H12AffineFastState.Bounded env29958 := by
  intro p hp
  have h : env29958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29957_29958 : H12AffineEnvironment.transform 12 348 env29957 = env29958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29957 == env29958) = true)

theorem identity29958 : scanCanonicalize (H12AffineFastState.compose env29958 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound29958 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1281,4096,348,5376,81,263,5440,1141,1024,80,4113,33,16,82,349,65,1280,5393,4177,1140,1284,113,256,33,5377,513]

theorem envBound29959 : H12AffineFastState.Bounded env29959 := by
  intro p hp
  have h : env29959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29958_29959 : H12AffineEnvironment.transform 10 1281 env29958 = env29959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env29958 == env29959) = true)

theorem identity29959 : scanCanonicalize (H12AffineFastState.compose env29959 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound29959 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env29960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1281,81,348,1361,81,263,1297,1141,1024,80,64,33,16,82,349,65,1280,1344,0,1140,1284,113,256,33,1360,513]

theorem envBound29960 : H12AffineFastState.Bounded env29960 := by
  intro p hp
  have h : env29960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29959_29960 : H12AffineEnvironment.transform 11 81 env29959 = env29960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env29959 == env29960) = true)

theorem identity29960 : scanCanonicalize (H12AffineFastState.compose env29960 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29960 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env29961 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1281,0,269,1280,0,263,1297,1060,1024,1,17,33,16,3,268,16,1280,1297,0,1061,1284,32,256,33,1281,513]

theorem envBound29961 : H12AffineFastState.Bounded env29961 := by
  intro p hp
  have h : env29961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29960_29961 : H12AffineEnvironment.transform 5 17 env29960 = env29961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29960 == env29961) = true)

theorem identity29961 : scanCanonicalize (H12AffineFastState.compose env29961 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29962 : List Nat := [2,4,8,16,32,17,9,256,512,53,308,0,269,309,0,263,292,17,53,1,17,33,16,3,268,16,309,292,0,16,305,32,256,33,308,513]

theorem envBound29962 : H12AffineFastState.Bounded env29962 := by
  intro p hp
  have h : env29962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29961_29962 : H12AffineEnvironment.transform 9 53 env29961 = env29962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29961 == env29962) = true)

theorem identity29962 : scanCanonicalize (H12AffineFastState.compose env29962 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29962 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29963 : List Nat := [2,4,8,16,32,17,9,256,0,53,308,0,269,309,0,263,292,17,53,1,17,33,16,3,268,16,309,292,0,16,305,32,256,33,308,1]

theorem envBound29963 : H12AffineFastState.Bounded env29963 := by
  intro p hp
  have h : env29963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29962_29963 : H12AffineEnvironment.transform 8 0 env29962 = env29963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29962 == env29963) = true)

theorem identity29963 : scanCanonicalize (H12AffineFastState.compose env29963 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29963 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29964 : List Nat := [2,4,8,16,32,17,9,36,0,53,16,0,41,17,0,35,0,17,53,1,17,33,16,3,40,16,17,0,0,16,21,32,36,33,16,1]

theorem envBound29964 : H12AffineFastState.Bounded env29964 := by
  intro p hp
  have h : env29964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29963_29964 : H12AffineEnvironment.transform 7 36 env29963 = env29964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29963 == env29964) = true)

theorem identity29964 : scanCanonicalize (H12AffineFastState.compose env29964 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29965 : List Nat := [2,4,8,16,0,17,9,4,0,21,16,0,9,17,0,3,0,17,21,1,17,1,16,3,8,16,17,0,0,16,21,0,4,1,16,1]

theorem envBound29965 : H12AffineFastState.Bounded env29965 := by
  intro p hp
  have h : env29965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29964_29965 : H12AffineEnvironment.transform 4 0 env29964 = env29965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29964 == env29965) = true)

theorem identity29965 : scanCanonicalize (H12AffineFastState.compose env29965 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29966 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,0,9,1,0,3,0,1,5,1,1,1,0,3,8,0,1,0,0,0,5,0,4,1,0,1]

theorem envBound29966 : H12AffineFastState.Bounded env29966 := by
  intro p hp
  have h : env29966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29965_29966 : H12AffineEnvironment.transform 3 0 env29965 = env29966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29965 == env29966) = true)

def env29967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452768,95497,8328,65,292136,458145,45525,10400,399801,144492,256,21793,46213,474734]

theorem envBound29967 : H12AffineFastState.Bounded env29967 := by
  intro p hp
  have h : env29967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29911_29967 : H12AffineEnvironment.transform 21 272513 env29911 = env29967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29911 == env29967) = true)

theorem identity29967 : scanCanonicalize (H12AffineFastState.compose env29967 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound29967 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,58517,180273,16,95497,8328,65,171416,5393,45525,10400,61705,144492,256,21793,46213,120542]

theorem envBound29968 : H12AffineFastState.Bounded env29968 := by
  intro p hp
  have h : env29968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29967_29968 : H12AffineEnvironment.transform 17 190640 env29967 = env29968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env29967 == env29968) = true)

def env29969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58397,180273,16,95497,8192,65,171280,5393,45405,10280,61705,144492,256,21793,46093,120406]

theorem envBound29969 : H12AffineFastState.Bounded env29969 := by
  intro p hp
  have h : env29969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29968_29969 : H12AffineEnvironment.transform 6 8 env29968 = env29969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29968 == env29969) = true)

theorem identity29969 : scanCanonicalize (H12AffineFastState.compose env29969 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound29969 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,89379,1024,32769,58397,95530,16,95497,8192,65,75787,5393,45405,10280,61705,98679,256,21793,46093,120406]

theorem envBound29970 : H12AffineFastState.Bounded env29970 := by
  intro p hp
  have h : env29970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29969_29970 : H12AffineEnvironment.transform 16 111899 env29969 = env29970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env29969 == env29970) = true)

theorem identity29970 : scanCanonicalize (H12AffineFastState.compose env29970 (packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound29970 : packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41343,5220,64604,1024,32769,58397,54357,16,54390,8192,65,35188,5393,45405,10280,61705,8200,256,21793,46093,30505]

theorem envBound29971 : H12AffineFastState.Bounded env29971 := by
  intro p hp
  have h : env29971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29970_29971 : H12AffineEnvironment.transform 15 41343 env29970 = env29971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env29970 == env29971) = true)

theorem identity29971 : scanCanonicalize (H12AffineFastState.compose env29971 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29971 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21795,5220,2048,1024,29789,4161,8201,16,8234,8192,65,32040,5393,17665,10280,1365,8200,256,21793,16465,30505]

theorem envBound29972 : H12AffineFastState.Bounded env29972 := by
  intro p hp
  have h : env29972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29971_29972 : H12AffineEnvironment.transform 14 29788 env29971 = env29972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29971 == env29972) = true)

theorem identity29972 : scanCanonicalize (H12AffineFastState.compose env29972 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound29972 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,342,5220,2048,1024,8232,4161,8201,16,8234,8192,65,10589,5393,4468,10280,1365,8200,256,340,5156,9052]

theorem envBound29973 : H12AffineFastState.Bounded env29973 := by
  intro p hp
  have h : env29973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29972_29973 : H12AffineEnvironment.transform 13 5237 env29972 = env29973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env29972 == env29973) = true)

theorem identity29973 : scanCanonicalize (H12AffineFastState.compose env29973 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29973 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env29974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,373,342,5220,2048,1024,372,4161,341,16,374,348,65,2049,5393,4468,2420,1365,340,256,340,5156,512]

theorem envBound29974 : H12AffineFastState.Bounded env29974 := by
  intro p hp
  have h : env29974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29973_29974 : H12AffineEnvironment.transform 12 348 env29973 = env29974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29973 == env29974) = true)

theorem identity29974 : scanCanonicalize (H12AffineFastState.compose env29974 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29974 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29975 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,88,5237,113,82,5220,2048,1024,112,4161,81,16,114,88,65,2049,5141,4208,2160,1105,80,4,80,5156,512]

theorem envBound29975 : H12AffineFastState.Bounded env29975 := by
  intro p hp
  have h : env29975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29974_29975 : H12AffineEnvironment.transform 7 4 env29974 = env29975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29974 == env29975) = true)

theorem identity29975 : scanCanonicalize (H12AffineFastState.compose env29975 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound29975 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env29976 : List Nat := [2,4,8,16,32,64,8,4,123,1024,2048,4096,88,5237,113,82,5220,2048,1024,112,4161,81,16,114,88,65,2049,5141,4208,2160,1105,80,4,80,5156,123]

theorem envBound29976 : H12AffineFastState.Bounded env29976 := by
  intro p hp
  have h : env29976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29975_29976 : H12AffineEnvironment.transform 8 123 env29975 = env29976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env29975 == env29976) = true)

theorem identity29976 : scanCanonicalize (H12AffineFastState.compose env29976 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound29976 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env29977 : List Nat := [2,4,8,16,32,64,8,4,123,1024,2048,1028,88,113,113,82,96,2048,1024,112,1093,81,16,114,88,65,2049,17,1140,2160,1105,80,4,80,32,123]

theorem envBound29977 : H12AffineFastState.Bounded env29977 := by
  intro p hp
  have h : env29977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29976_29977 : H12AffineEnvironment.transform 11 1028 env29976 = env29977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env29976 == env29977) = true)

theorem identity29977 : scanCanonicalize (H12AffineFastState.compose env29977 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound29977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29978 : List Nat := [2,4,8,16,32,64,8,4,123,1024,33,1028,88,113,113,82,96,33,1024,112,1093,81,16,114,88,65,32,17,1140,81,1105,80,4,80,32,123]

theorem envBound29978 : H12AffineFastState.Bounded env29978 := by
  intro p hp
  have h : env29978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29977_29978 : H12AffineEnvironment.transform 10 33 env29977 = env29978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env29977 == env29978) = true)

theorem identity29978 : scanCanonicalize (H12AffineFastState.compose env29978 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 118) := by decide +kernel

theorem selectedBound29978 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env29979 : List Nat := [2,4,8,16,32,64,8,4,123,118,33,114,88,113,113,82,96,33,118,112,51,81,16,114,88,65,32,17,2,81,39,80,4,80,32,123]

theorem envBound29979 : H12AffineFastState.Bounded env29979 := by
  intro p hp
  have h : env29979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29978_29979 : H12AffineEnvironment.transform 9 118 env29978 = env29979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 118 env29978 == env29979) = true)

theorem identity29979 : scanCanonicalize (H12AffineFastState.compose env29979 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29979 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env29980 : List Nat := [2,4,8,16,16,64,8,4,75,70,17,66,88,65,65,82,80,17,70,64,3,81,16,66,88,65,16,17,2,81,23,80,4,80,16,75]

theorem envBound29980 : H12AffineFastState.Bounded env29980 := by
  intro p hp
  have h : env29980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29979_29980 : H12AffineEnvironment.transform 4 16 env29979 = env29980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29979 == env29980) = true)

theorem identity29980 : scanCanonicalize (H12AffineFastState.compose env29980 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29980 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env29981 : List Nat := [2,0,8,16,16,64,8,0,75,66,17,66,88,65,65,82,80,17,66,64,3,81,16,66,88,65,16,17,2,81,19,80,0,80,16,75]

theorem envBound29981 : H12AffineFastState.Bounded env29981 := by
  intro p hp
  have h : env29981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29980_29981 : H12AffineEnvironment.transform 1 0 env29980 = env29981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29980 == env29981) = true)

theorem identity29981 : scanCanonicalize (H12AffineFastState.compose env29981 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29981 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29982 : List Nat := [2,0,8,1,1,64,8,0,75,66,0,66,73,65,65,67,65,0,66,64,3,64,1,66,73,65,1,0,2,64,2,65,0,65,1,75]

theorem envBound29982 : H12AffineFastState.Bounded env29982 := by
  intro p hp
  have h : env29982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29981_29982 : H12AffineEnvironment.transform 3 1 env29981 = env29982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29981 == env29982) = true)

theorem identity29982 : scanCanonicalize (H12AffineFastState.compose env29982 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29982 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29983 : List Nat := [2,0,2,1,1,64,2,0,65,66,0,66,67,65,65,67,65,0,66,64,3,64,1,66,67,65,1,0,2,64,2,65,0,65,1,65]

theorem envBound29983 : H12AffineFastState.Bounded env29983 := by
  intro p hp
  have h : env29983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29982_29983 : H12AffineEnvironment.transform 2 2 env29982 = env29983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29982 == env29983) = true)

theorem identity29983 : scanCanonicalize (H12AffineFastState.compose env29983 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29984 : List Nat := [0,0,0,1,1,64,0,0,65,64,0,64,65,65,65,65,65,0,64,64,1,64,1,64,65,65,1,0,0,64,0,65,0,65,1,65]

theorem envBound29984 : H12AffineFastState.Bounded env29984 := by
  intro p hp
  have h : env29984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29983_29984 : H12AffineEnvironment.transform 0 0 env29983 = env29984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29983 == env29984) = true)

theorem identity29984 : scanCanonicalize (H12AffineFastState.compose env29984 (packedSelected [14] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29984 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env29985 : List Nat := [0,0,0,1,1,1,0,0,0,1,0,1,0,0,0,0,0,0,1,1,1,1,1,1,0,0,1,0,0,1,0,0,0,0,1,0]

theorem envBound29985 : H12AffineFastState.Bounded env29985 := by
  intro p hp
  have h : env29985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29984_29985 : H12AffineEnvironment.transform 5 1 env29984 = env29985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29984 == env29985) = true)

def env29986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58396,180273,16,95497,8193,65,171281,5393,45404,10281,61705,144492,256,21793,46092,120407]

theorem envBound29986 : H12AffineFastState.Bounded env29986 := by
  intro p hp
  have h : env29986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29968_29986 : H12AffineEnvironment.transform 6 9 env29968 = env29986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29968 == env29986) = true)

theorem identity29986 : scanCanonicalize (H12AffineFastState.compose env29986 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound29986 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,130174,1024,32769,58396,119926,16,95497,8193,65,100694,5393,45404,10281,61705,73771,256,21793,46092,120407]

theorem envBound29987 : H12AffineFastState.Bounded env29987 := by
  intro p hp
  have h : env29987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29986_29987 : H12AffineEnvironment.transform 16 70727 env29986 = env29987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env29986 == env29987) = true)

theorem identity29987 : scanCanonicalize (H12AffineFastState.compose env29987 (packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29987 : packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env29988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,70727,108927,1024,32769,45341,98679,16,73736,8193,65,100694,5393,45404,10281,41992,73771,256,32,46092,99158]

theorem envBound29988 : H12AffineFastState.Bounded env29988 := by
  intro p hp
  have h : env29988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29987_29988 : H12AffineEnvironment.transform 13 5377 env29987 = env29988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29987 == env29988) = true)

theorem identity29988 : scanCanonicalize (H12AffineFastState.compose env29988 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound29988 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env29989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40970,46157,2421,1024,32769,45341,8573,16,32770,8193,65,10588,5393,45404,10281,41992,32801,256,32,46092,9052]

theorem envBound29989 : H12AffineFastState.Bounded env29989 := by
  intro p hp
  have h : env29989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29988_29989 : H12AffineEnvironment.transform 15 40970 env29988 = env29989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env29988 == env29989) = true)

theorem identity29989 : scanCanonicalize (H12AffineFastState.compose env29989 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound29989 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env29990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,8282,13341,2421,1024,81,12621,8573,16,82,8193,65,10588,5393,12556,10281,9304,113,256,32,13404,9052]

theorem envBound29990 : H12AffineFastState.Bounded env29990 := by
  intro p hp
  have h : env29990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29989_29990 : H12AffineEnvironment.transform 14 80 env29989 = env29990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env29989 == env29990) = true)

theorem identity29990 : scanCanonicalize (H12AffineFastState.compose env29990 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29990 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,343,5392,2421,1024,81,4160,112,16,82,268,65,2129,5393,4097,2340,1365,113,256,32,5457,593]

theorem envBound29991 : H12AffineFastState.Bounded env29991 := by
  intro p hp
  have h : env29991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29990_29991 : H12AffineEnvironment.transform 12 269 env29990 = env29991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29990 == env29991) = true)

theorem identity29991 : scanCanonicalize (H12AffineFastState.compose env29991 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29991 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29992 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,269,5377,80,343,5392,2388,1024,81,4160,81,16,82,268,65,2129,5393,4097,2309,1365,80,256,1,5457,593]

theorem envBound29992 : H12AffineFastState.Bounded env29992 := by
  intro p hp
  have h : env29992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29991_29992 : H12AffineEnvironment.transform 4 1 env29991 = env29992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29991 == env29992) = true)

theorem identity29992 : scanCanonicalize (H12AffineFastState.compose env29992 (packedSelected [1,2,4,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound29992 : packedSelected [1,2,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env29993 : List Nat := [2,4,8,16,1,64,9,256,512,1024,81,4096,269,5377,80,343,5392,261,1024,81,4160,81,16,82,268,65,0,5393,4097,340,1365,80,256,1,5457,593]

theorem envBound29993 : H12AffineFastState.Bounded env29993 := by
  intro p hp
  have h : env29993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29992_29993 : H12AffineEnvironment.transform 10 81 env29992 = env29993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env29992 == env29993) = true)

theorem identity29993 : scanCanonicalize (H12AffineFastState.compose env29993 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound29993 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env29994 : List Nat := [2,4,8,16,1,64,9,256,512,1024,81,65,269,1344,80,343,1361,261,1024,81,1,81,16,82,268,65,0,1360,64,340,1365,80,256,1,1296,593]

theorem envBound29994 : H12AffineFastState.Bounded env29994 := by
  intro p hp
  have h : env29994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29993_29994 : H12AffineEnvironment.transform 11 65 env29993 = env29994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env29993 == env29994) = true)

theorem identity29994 : scanCanonicalize (H12AffineFastState.compose env29994 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound29994 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env29995 : List Nat := [2,4,8,16,1,64,9,256,512,69,81,65,269,261,80,343,276,261,69,81,1,81,16,82,268,65,0,277,64,340,272,80,256,1,341,593]

theorem envBound29995 : H12AffineFastState.Bounded env29995 := by
  intro p hp
  have h : env29995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29994_29995 : H12AffineEnvironment.transform 9 69 env29994 = env29995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env29994 == env29995) = true)

theorem identity29995 : scanCanonicalize (H12AffineFastState.compose env29995 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29995 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env29996 : List Nat := [2,4,8,16,1,16,9,256,512,21,1,17,269,261,0,263,276,261,21,1,1,1,16,2,268,17,0,277,16,260,272,0,256,1,261,513]

theorem envBound29996 : H12AffineFastState.Bounded env29996 := by
  intro p hp
  have h : env29996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29995_29996 : H12AffineEnvironment.transform 5 16 env29995 = env29996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29995 == env29996) = true)

theorem identity29996 : scanCanonicalize (H12AffineFastState.compose env29996 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29997 : List Nat := [2,4,8,1,1,1,9,256,512,4,1,0,269,261,0,263,261,261,4,1,1,1,1,2,268,0,0,260,1,260,257,0,256,1,261,513]

theorem envBound29997 : H12AffineFastState.Bounded env29997 := by
  intro p hp
  have h : env29997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29996_29997 : H12AffineEnvironment.transform 3 1 env29996 = env29997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29996 == env29997) = true)

theorem identity29997 : scanCanonicalize (H12AffineFastState.compose env29997 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound29997 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29998 : List Nat := [2,4,8,1,1,1,9,256,260,4,1,0,269,261,0,263,261,261,4,1,1,1,1,2,268,0,0,260,1,260,257,0,256,1,261,261]

theorem envBound29998 : H12AffineFastState.Bounded env29998 := by
  intro p hp
  have h : env29998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29997_29998 : H12AffineEnvironment.transform 8 260 env29997 = env29998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env29997 == env29998) = true)

theorem identity29998 : scanCanonicalize (H12AffineFastState.compose env29998 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29999 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,0,9,1,0,3,1,1,4,1,1,1,1,2,8,0,0,0,1,0,5,0,4,1,1,1]

theorem envBound29999 : H12AffineFastState.Bounded env29999 := by
  intro p hp
  have h : env29999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29998_29999 : H12AffineEnvironment.transform 7 4 env29998 = env29999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29998 == env29999) = true)

theorem identity29999 : scanCanonicalize (H12AffineFastState.compose env29999 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30000 : List Nat := [2,4,2,1,1,1,3,4,0,4,1,0,3,1,0,3,1,1,4,1,1,1,1,2,2,0,0,0,1,0,5,0,4,1,1,1]

theorem envBound30000 : H12AffineFastState.Bounded env30000 := by
  intro p hp
  have h : env30000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29999_30000 : H12AffineEnvironment.transform 2 2 env29999 = env30000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29999 == env30000) = true)

def env30001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452769,95496,8328,65,4218281,458144,45524,10401,399801,4594924,256,21793,46213,474734]

theorem envBound30001 : H12AffineFastState.Bounded env30001 := by
  intro p hp
  have h : env30001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29910_30001 : H12AffineEnvironment.transform 22 452769 env29910 = env30001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env29910 == env30001) = true)

def env30002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452769,95496,8328,65,292137,458144,45524,10401,399801,144492,256,21793,46213,474734]

theorem envBound30002 : H12AffineFastState.Bounded env30002 := by
  intro p hp
  have h : env30002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30001_30002 : H12AffineEnvironment.transform 21 272512 env30001 = env30002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30001 == env30002) = true)

theorem identity30002 : scanCanonicalize (H12AffineFastState.compose env30002 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30002 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396325,272512,400500,95496,8328,65,292137,395637,17665,10401,399801,144492,256,21793,16464,474734]

theorem envBound30003 : H12AffineFastState.Bounded env30003 := by
  intro p hp
  have h : env30003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30002_30003 : H12AffineEnvironment.transform 14 29909 env30002 = env30003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30002 == env30003) = true)

def env30004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140421,32,144596,95496,8328,65,23945,139733,17665,10401,143641,144492,256,21793,16464,202446]

theorem envBound30004 : H12AffineFastState.Bounded env30004 := by
  intro p hp
  have h : env30004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30003_30004 : H12AffineEnvironment.transform 17 10400 env30003 = env30004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30003 == env30004) = true)

theorem identity30004 : scanCanonicalize (H12AffineFastState.compose env30004 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound30004 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env30005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21591,131072,10400,1024,29908,140421,32,144596,8543,8328,65,23945,139733,17665,10401,143641,144492,256,21793,16464,148121]

theorem envBound30005 : H12AffineFastState.Bounded env30005 := by
  intro p hp
  have h : env30005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30004_30005 : H12AffineEnvironment.transform 15 21591 env30004 = env30005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env30004 == env30005) = true)

theorem identity30005 : scanCanonicalize (H12AffineFastState.compose env30005 (packedSelected [3,5,8,10,16,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound30005 : packedSelected [3,5,8,10,16,20,28,31] rootPS < 2^1333 := by decide +kernel

def env30006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,8202,131072,10400,1024,137,140421,32,144596,8543,8328,65,10708,139733,12636,10401,143641,144492,256,8572,13325,145092]

theorem envBound30006 : H12AffineFastState.Bounded env30006 := by
  intro p hp
  have h : env30006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30005_30006 : H12AffineEnvironment.transform 13 13405 env30005 = env30006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env30005 == env30006) = true)

theorem identity30006 : scanCanonicalize (H12AffineFastState.compose env30006 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30006 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,8202,13388,10400,1024,137,4297,32,152,8543,8328,65,10708,5529,12636,10401,1365,32,256,8572,13325,648]

theorem envBound30007 : H12AffineFastState.Bounded env30007 := by
  intro p hp
  have h : env30007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30006_30007 : H12AffineEnvironment.transform 16 13388 env30006 = env30007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30006 == env30007) = true)

theorem identity30007 : scanCanonicalize (H12AffineFastState.compose env30007 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound30007 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env30008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5156,136,115,5173,2265,1024,137,4297,32,152,294,241,65,2477,5529,4389,2264,1365,32,256,261,5236,648]

theorem envBound30008 : H12AffineFastState.Bounded env30008 := by
  intro p hp
  have h : env30008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30007_30008 : H12AffineEnvironment.transform 12 121 env30007 = env30008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env30007 == env30008) = true)

theorem identity30008 : scanCanonicalize (H12AffineFastState.compose env30008 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30008 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30009 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,121,5156,136,115,5173,2265,1024,137,4297,32,152,2,241,65,2185,5309,4097,2264,1137,32,36,33,5236,648]

theorem envBound30009 : H12AffineFastState.Bounded env30009 := by
  intro p hp
  have h : env30009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30008_30009 : H12AffineEnvironment.transform 7 36 env30008 = env30009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30008 == env30009) = true)

theorem identity30009 : scanCanonicalize (H12AffineFastState.compose env30009 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30009 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env30010 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,121,5156,81,115,5173,2048,1024,80,4112,32,65,2,40,65,2128,5220,4097,2049,1137,32,36,33,5236,593]

theorem envBound30010 : H12AffineFastState.Bounded env30010 := by
  intro p hp
  have h : env30010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30009_30010 : H12AffineEnvironment.transform 6 89 env30009 = env30010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30009 == env30010) = true)

theorem identity30010 : scanCanonicalize (H12AffineFastState.compose env30010 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30010 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env30011 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,35,5173,2048,1024,0,4112,32,17,2,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound30011 : H12AffineFastState.Bounded env30011 := by
  intro p hp
  have h : env30011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30010_30011 : H12AffineEnvironment.transform 5 16 env30010 = env30011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30010 == env30011) = true)

theorem identity30011 : scanCanonicalize (H12AffineFastState.compose env30011 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound30011 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30012 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1061,41,1,1,35,16,2048,1024,0,1077,32,17,2,40,17,2048,17,1060,2049,1057,32,36,33,1,513]

theorem envBound30012 : H12AffineFastState.Bounded env30012 := by
  intro p hp
  have h : env30012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30011_30012 : H12AffineEnvironment.transform 11 1061 env30011 = env30012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env30011 == env30012) = true)

theorem identity30012 : scanCanonicalize (H12AffineFastState.compose env30012 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30012 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30013 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,1061,41,1,1,35,16,0,1024,0,1077,32,17,2,40,17,0,17,1060,1,1057,32,36,33,1,513]

theorem envBound30013 : H12AffineFastState.Bounded env30013 := by
  intro p hp
  have h : env30013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30012_30013 : H12AffineEnvironment.transform 10 0 env30012 = env30013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30012 == env30013) = true)

theorem identity30013 : scanCanonicalize (H12AffineFastState.compose env30013 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30013 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30014 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,16,41,1,1,35,16,0,53,0,0,32,17,2,40,17,0,17,17,1,20,32,36,33,1,513]

theorem envBound30014 : H12AffineFastState.Bounded env30014 := by
  intro p hp
  have h : env30014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30013_30014 : H12AffineEnvironment.transform 9 53 env30013 = env30014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30013 == env30014) = true)

theorem identity30014 : scanCanonicalize (H12AffineFastState.compose env30014 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30014 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30015 : List Nat := [2,4,8,16,32,16,9,36,1,53,0,16,41,1,1,35,16,0,53,0,0,32,17,2,40,17,0,17,17,1,20,32,36,33,1,0]

theorem envBound30015 : H12AffineFastState.Bounded env30015 := by
  intro p hp
  have h : env30015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30014_30015 : H12AffineEnvironment.transform 8 1 env30014 = env30015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30014 == env30015) = true)

theorem identity30015 : scanCanonicalize (H12AffineFastState.compose env30015 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30016 : List Nat := [2,4,3,16,32,16,2,36,1,53,0,16,34,1,1,35,16,0,53,0,0,32,17,2,35,17,0,17,17,1,20,32,36,33,1,0]

theorem envBound30016 : H12AffineFastState.Bounded env30016 := by
  intro p hp
  have h : env30016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30015_30016 : H12AffineEnvironment.transform 2 3 env30015 = env30016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30015 == env30016) = true)

def env30017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140420,33,144597,95496,8328,65,23944,139732,17665,10401,143640,144492,256,21793,16464,202447]

theorem envBound30017 : H12AffineFastState.Bounded env30017 := by
  intro p hp
  have h : env30017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30003_30017 : H12AffineEnvironment.transform 17 10401 env30003 = env30017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30003 == env30017) = true)

theorem identity30017 : scanCanonicalize (H12AffineFastState.compose env30017 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound30017 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env30018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,131072,10401,1024,29908,140420,33,144597,29910,8328,65,23944,139732,17665,10401,143640,144492,256,21793,16464,136977]

theorem envBound30018 : H12AffineFastState.Bounded env30018 := by
  intro p hp
  have h : env30018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30017_30018 : H12AffineEnvironment.transform 15 478 env30017 = env30018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env30017 == env30018) = true)

theorem identity30018 : scanCanonicalize (H12AffineFastState.compose env30018 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound30018 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,478,131072,10401,1024,137,140420,33,144597,139,8328,65,10709,139732,12636,10401,143640,144492,256,8572,13325,136977]

theorem envBound30019 : H12AffineFastState.Bounded env30019 := by
  intro p hp
  have h : env30019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30018_30019 : H12AffineEnvironment.transform 13 13405 env30018 = env30019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env30018 == env30019) = true)

theorem identity30019 : scanCanonicalize (H12AffineFastState.compose env30019 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound30019 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,478,13509,10401,1024,137,4161,33,16,139,8328,65,10709,5393,12636,10401,1501,169,256,8572,13325,9172]

theorem envBound30020 : H12AffineFastState.Bounded env30020 := by
  intro p hp
  have h : env30020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30019_30020 : H12AffineEnvironment.transform 16 13509 env30019 = env30020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env30019 == env30020) = true)

theorem identity30020 : scanCanonicalize (H12AffineFastState.compose env30020 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30020 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,343,13388,10280,1024,0,4161,33,16,2,8193,65,10588,5393,12636,10280,1364,32,256,8572,13325,9053]

theorem envBound30021 : H12AffineFastState.Bounded env30021 := by
  intro p hp
  have h : env30021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30020_30021 : H12AffineEnvironment.transform 6 9 env30020 = env30021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30020 == env30021) = true)

theorem identity30021 : scanCanonicalize (H12AffineFastState.compose env30021 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30021 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5393,2421,1024,0,4161,33,16,2,348,65,2049,5393,4097,2421,1364,32,256,33,5456,512]

theorem envBound30022 : H12AffineFastState.Bounded env30022 := by
  intro p hp
  have h : env30022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30021_30022 : H12AffineEnvironment.transform 12 349 env30021 = env30022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30021 == env30022) = true)

theorem identity30022 : scanCanonicalize (H12AffineFastState.compose env30022 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2894) := by decide +kernel

theorem selectedBound30022 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2894,349,3662,1,343,3679,2421,1024,0,2831,33,16,2,348,65,2049,3679,2895,2421,1364,32,256,33,3614,512]

theorem envBound30023 : H12AffineFastState.Bounded env30023 := by
  intro p hp
  have h : env30023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30022_30023 : H12AffineEnvironment.transform 11 2894 env30022 = env30023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2894 env30022 == env30023) = true)

theorem identity30023 : scanCanonicalize (H12AffineFastState.compose env30023 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30023 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30024 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2878,301,3646,1,295,3631,2309,1024,0,2831,33,16,2,300,49,2049,3631,2879,2309,1316,32,256,33,3614,512]

theorem envBound30024 : H12AffineFastState.Bounded env30024 := by
  intro p hp
  have h : env30024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30023_30024 : H12AffineEnvironment.transform 5 48 env30023 = env30024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30023 == env30024) = true)

theorem identity30024 : scanCanonicalize (H12AffineFastState.compose env30024 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound30024 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30025 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1296,1582,301,814,1,295,831,1045,1024,0,1567,33,16,2,300,49,1297,831,1583,1045,1316,32,256,33,782,512]

theorem envBound30025 : H12AffineFastState.Bounded env30025 := by
  intro p hp
  have h : env30025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30024_30025 : H12AffineEnvironment.transform 10 1296 env30024 = env30025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env30024 == env30025) = true)

def env30026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452769,95496,8328,65,292136,458144,45524,10401,399801,144493,256,21793,46213,474734]

theorem envBound30026 : H12AffineFastState.Bounded env30026 := by
  intro p hp
  have h : env30026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30001_30026 : H12AffineEnvironment.transform 21 272513 env30001 = env30026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30001 == env30026) = true)

theorem identity30026 : scanCanonicalize (H12AffineFastState.compose env30026 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound30026 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,144613,62661,95496,8328,65,158028,57796,45524,10401,1501,144493,256,21793,46213,74250]

theorem envBound30027 : H12AffineFastState.Bounded env30027 := by
  intro p hp
  have h : env30027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30026_30027 : H12AffineEnvironment.transform 17 138340 env30026 = env30027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env30026 == env30027) = true)

theorem identity30027 : scanCanonicalize (H12AffineFastState.compose env30027 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30027 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1024,32769,4161,144613,62661,21763,8328,65,158028,57796,45524,10401,1501,144493,256,21793,46213,513]

theorem envBound30028 : H12AffineFastState.Bounded env30028 := by
  intro p hp
  have h : env30028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30027_30028 : H12AffineEnvironment.transform 15 8203 env30027 = env30028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30027 == env30028) = true)

theorem identity30028 : scanCanonicalize (H12AffineFastState.compose env30028 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30028 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env30029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,138340,1024,32769,4161,136632,54680,21763,469,65,149521,49305,37001,2556,1501,136496,256,21793,38360,513]

theorem envBound30029 : H12AffineFastState.Bounded env30029 := by
  intro p hp
  have h : env30029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30028_30029 : H12AffineEnvironment.transform 12 349 env30028 = env30029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30028 == env30029) = true)

theorem identity30029 : scanCanonicalize (H12AffineFastState.compose env30029 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound30029 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env30030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,5528,2556,1024,32769,4161,32,54680,21763,469,65,23945,49305,37001,2556,1501,168,256,21793,38360,513]

theorem envBound30030 : H12AffineFastState.Bounded env30030 := by
  intro p hp
  have h : env30030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30029_30030 : H12AffineEnvironment.transform 16 5528 env30029 = env30030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env30029 == env30030) = true)

theorem identity30030 : scanCanonicalize (H12AffineFastState.compose env30030 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound30030 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env30031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,5528,2556,1024,21896,4161,32,17,21763,469,65,23945,5392,17664,2556,1501,168,256,21793,16465,513]

theorem envBound30031 : H12AffineFastState.Bounded env30031 := by
  intro p hp
  have h : env30031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30030_30031 : H12AffineEnvironment.transform 14 21897 env30030 = env30031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env30030 == env30031) = true)

theorem identity30031 : scanCanonicalize (H12AffineFastState.compose env30031 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,216,342,5528,2556,1024,217,4161,32,17,82,469,65,2264,5392,4177,2556,1501,168,256,112,5376,513]

theorem envBound30032 : H12AffineFastState.Bounded env30032 := by
  intro p hp
  have h : env30032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30031_30032 : H12AffineEnvironment.transform 13 5457 env30031 = env30032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30031 == env30032) = true)

theorem identity30032 : scanCanonicalize (H12AffineFastState.compose env30032 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30032 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30033 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,1,342,5441,2341,1024,0,4161,32,17,82,268,65,2049,5392,4177,2341,1284,113,256,112,5376,513]

theorem envBound30033 : H12AffineFastState.Bounded env30033 := by
  intro p hp
  have h : env30033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30032_30033 : H12AffineEnvironment.transform 6 89 env30032 = env30033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30032 == env30033) = true)

theorem identity30033 : scanCanonicalize (H12AffineFastState.compose env30033 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1857) := by decide +kernel

theorem selectedBound30033 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30034 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1857,349,528,1,342,512,2341,1024,0,1792,32,17,82,268,65,2049,593,1808,2341,1284,113,256,112,577,513]

theorem envBound30034 : H12AffineFastState.Bounded env30034 := by
  intro p hp
  have h : env30034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30033_30034 : H12AffineEnvironment.transform 11 1857 env30033 = env30034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1857 env30033 == env30034) = true)

theorem identity30034 : scanCanonicalize (H12AffineFastState.compose env30034 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1857) := by decide +kernel

theorem selectedBound30034 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30035 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1857,1857,349,528,1,342,512,1636,1024,0,1792,32,17,82,268,65,1856,593,1808,1636,1284,113,256,112,577,513]

theorem envBound30035 : H12AffineFastState.Bounded env30035 := by
  intro p hp
  have h : env30035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30034_30035 : H12AffineEnvironment.transform 10 1857 env30034 = env30035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1857 env30034 == env30035) = true)

theorem identity30035 : scanCanonicalize (H12AffineFastState.compose env30035 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound30035 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30036 : List Nat := [2,4,8,16,32,64,89,256,512,116,821,821,349,528,1,342,512,528,116,0,884,32,17,82,268,65,820,593,868,528,368,113,256,112,577,513]

theorem envBound30036 : H12AffineFastState.Bounded env30036 := by
  intro p hp
  have h : env30036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30035_30036 : H12AffineEnvironment.transform 9 116 env30035 = env30036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env30035 == env30036) = true)

theorem identity30036 : scanCanonicalize (H12AffineFastState.compose env30036 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound30036 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30037 : List Nat := [2,4,8,16,32,64,89,100,512,116,593,593,57,528,1,50,512,528,116,0,528,32,17,82,104,65,592,593,512,528,20,113,100,112,577,513]

theorem envBound30037 : H12AffineFastState.Bounded env30037 := by
  intro p hp
  have h : env30037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30036_30037 : H12AffineEnvironment.transform 7 100 env30036 = env30037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env30036 == env30037) = true)

def env30038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound30038 : H12AffineFastState.Bounded env30038 := by
  intro p hp
  have h : env30038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29823_30038 : H12AffineEnvironment.transform 18 1025 env29823 = env30038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29823 == env30038) = true)

theorem identity30038 : scanCanonicalize (H12AffineFastState.compose env30038 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10874020) := by decide +kernel

theorem selectedBound30038 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10874020,8328,65,6433957,8677416,10507600,8830977,2386100,12880229,257,272392,313773,2445154]

theorem envBound30039 : H12AffineFastState.Bounded env30039 := by
  intro p hp
  have h : env30039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30038_30039 : H12AffineEnvironment.transform 23 10874020 env30038 = env30039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10874020 env30038 == env30039) = true)

def env30040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433957,8393984,10507600,8568105,2102684,12645453,257,21792,46213,2175562]

theorem envBound30040 : H12AffineFastState.Bounded env30040 := by
  intro p hp
  have h : env30040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30039_30040 : H12AffineEnvironment.transform 17 32040 env30039 = env30040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30039 == env30040) = true)

def env30041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101328,98780,8328,65,6433957,2098512,17664,2272633,2102684,6349853,257,21792,46213,2175562]

theorem envBound30041 : H12AffineFastState.Bounded env30041 := by
  intro p hp
  have h : env30041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30040_30041 : H12AffineEnvironment.transform 22 2101328 env30040 = env30041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env30040 == env30041) = true)

def env30042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,16,98780,8328,65,4340965,5392,17664,179513,1500,4256861,257,21792,46213,74250]

theorem envBound30042 : H12AffineFastState.Bounded env30042 := by
  intro p hp
  have h : env30042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30041_30042 : H12AffineEnvironment.transform 20 4160 env30041 = env30042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30041 == env30042) = true)

theorem identity30042 : scanCanonicalize (H12AffineFastState.compose env30042 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound30042 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,41340,16,98780,8328,65,171417,5392,17664,179513,1500,21793,257,21792,46213,74250]

theorem envBound30043 : H12AffineFastState.Bounded env30043 := by
  intro p hp
  have h : env30043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30042_30043 : H12AffineEnvironment.transform 21 41340 env30042 = env30043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env30042 == env30043) = true)

theorem identity30043 : scanCanonicalize (H12AffineFastState.compose env30043 (packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound30043 : packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env30044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,65536,131072,2476,1025,32769,4160,41340,16,98780,8328,65,171417,5392,12676,179513,1500,8613,257,8612,46213,74250]

theorem envBound30044 : H12AffineFastState.Bounded env30044 := by
  intro p hp
  have h : env30044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30043_30044 : H12AffineEnvironment.transform 13 13444 env30043 = env30044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env30043 == env30044) = true)

theorem identity30044 : scanCanonicalize (H12AffineFastState.compose env30044 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound30044 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,263,131072,2476,1025,32769,4160,41340,16,32987,8328,65,171417,5392,12676,179513,1500,8613,257,8612,46213,8973]

theorem envBound30045 : H12AffineFastState.Bounded env30045 := by
  intro p hp
  have h : env30045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30044_30045 : H12AffineEnvironment.transform 15 263 env30044 = env30045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env30044 == env30045) = true)

theorem identity30045 : scanCanonicalize (H12AffineFastState.compose env30045 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound30045 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env30046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,263,13460,2476,1025,32769,4160,41340,16,32987,8328,65,43277,5392,12676,35245,1500,8613,257,8612,46213,8973]

theorem envBound30046 : H12AffineFastState.Bounded env30046 := by
  intro p hp
  have h : env30046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30045_30046 : H12AffineEnvironment.transform 16 13460 env30045 = env30046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env30045 == env30046) = true)

def env30047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,263,13340,2340,1025,32769,4160,41340,16,32851,8192,65,43277,5392,12556,35109,1364,8493,257,8492,46093,8973]

theorem envBound30047 : H12AffineFastState.Bounded env30047 := by
  intro p hp
  have h : env30047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30046_30047 : H12AffineEnvironment.transform 6 8 env30046 = env30047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30046 == env30047) = true)

theorem identity30047 : scanCanonicalize (H12AffineFastState.compose env30047 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30047 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env30048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,263,5393,2340,1025,32769,4160,32881,16,32851,269,65,34816,5392,4097,35109,1364,32,257,33,38144,512]

theorem envBound30048 : H12AffineFastState.Bounded env30048 := by
  intro p hp
  have h : env30048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30047_30048 : H12AffineEnvironment.transform 12 269 env30047 = env30048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30047 == env30048) = true)

theorem identity30048 : scanCanonicalize (H12AffineFastState.compose env30048 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound30048 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,261,263,5393,2340,1025,260,4160,372,16,342,269,65,2309,5392,4097,2080,1364,32,257,33,5125,512]

theorem envBound30049 : H12AffineFastState.Bounded env30049 := by
  intro p hp
  have h : env30049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30048_30049 : H12AffineEnvironment.transform 14 261 env30048 = env30049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env30048 == env30049) = true)

theorem identity30049 : scanCanonicalize (H12AffineFastState.compose env30049 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30049 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30050 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,4113,261,263,4097,2340,273,260,4160,372,16,342,269,65,2309,4096,4097,2080,68,32,257,33,4373,512]

theorem envBound30050 : H12AffineFastState.Bounded env30050 := by
  intro p hp
  have h : env30050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30049_30050 : H12AffineEnvironment.transform 9 272 env30049 = env30050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30049 == env30050) = true)

theorem identity30050 : scanCanonicalize (H12AffineFastState.compose env30050 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound30050 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env30051 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,357,269,372,261,263,356,2340,273,260,293,372,16,342,269,65,2309,357,356,2080,68,32,257,33,112,512]

theorem envBound30051 : H12AffineFastState.Bounded env30051 := by
  intro p hp
  have h : env30051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30050_30051 : H12AffineEnvironment.transform 11 357 env30050 = env30051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env30050 == env30051) = true)

theorem identity30051 : scanCanonicalize (H12AffineFastState.compose env30051 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound30051 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env30052 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,357,269,372,261,263,356,113,273,260,293,372,16,342,269,65,80,357,356,373,68,32,257,33,112,512]

theorem envBound30052 : H12AffineFastState.Bounded env30052 := by
  intro p hp
  have h : env30052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30051_30052 : H12AffineEnvironment.transform 10 341 env30051 = env30052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env30051 == env30052) = true)

theorem identity30052 : scanCanonicalize (H12AffineFastState.compose env30052 (packedSelected [0,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30052 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env30053 : List Nat := [2,4,8,16,32,64,8,116,512,100,33,17,121,0,113,115,16,113,101,112,81,0,16,34,121,65,80,17,16,1,68,32,117,33,112,512]

theorem envBound30053 : H12AffineFastState.Bounded env30053 := by
  intro p hp
  have h : env30053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30052_30053 : H12AffineEnvironment.transform 7 116 env30052 = env30053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30052 == env30053) = true)

theorem identity30053 : scanCanonicalize (H12AffineFastState.compose env30053 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30053 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env30054 : List Nat := [2,4,8,16,32,48,8,4,512,20,33,17,9,0,1,3,16,1,21,0,33,0,16,34,9,49,32,17,16,1,52,32,5,33,0,512]

theorem envBound30054 : H12AffineFastState.Bounded env30054 := by
  intro p hp
  have h : env30054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30053_30054 : H12AffineEnvironment.transform 5 48 env30053 = env30054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30053 == env30054) = true)

theorem identity30054 : scanCanonicalize (H12AffineFastState.compose env30054 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30055 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,17,9,0,1,3,16,1,21,0,0,0,16,3,9,16,1,17,16,1,21,1,5,0,0,512]

theorem envBound30055 : H12AffineFastState.Bounded env30055 := by
  intro p hp
  have h : env30055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30054_30055 : H12AffineEnvironment.transform 4 1 env30054 = env30055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30054 == env30055) = true)

theorem identity30055 : scanCanonicalize (H12AffineFastState.compose env30055 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30056 : List Nat := [2,0,8,16,1,17,8,0,512,16,0,17,9,0,1,3,16,1,17,0,0,0,16,3,9,16,1,17,16,1,17,1,1,0,0,512]

theorem envBound30056 : H12AffineFastState.Bounded env30056 := by
  intro p hp
  have h : env30056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30055_30056 : H12AffineEnvironment.transform 1 0 env30055 = env30056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30055 == env30056) = true)

def env30057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,263,13341,2341,1025,32769,4160,41340,16,32850,8193,65,43277,5392,12557,35108,1365,8492,257,8493,46092,8973]

theorem envBound30057 : H12AffineFastState.Bounded env30057 := by
  intro p hp
  have h : env30057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30046_30057 : H12AffineEnvironment.transform 6 9 env30046 = env30057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30046 == env30057) = true)

theorem identity30057 : scanCanonicalize (H12AffineFastState.compose env30057 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30057 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,263,13341,2341,1025,8541,4160,32,16,8462,8193,65,2129,5392,12557,10360,1365,8492,257,8493,5456,8973]

theorem envBound30058 : H12AffineFastState.Bounded env30058 := by
  intro p hp
  have h : env30058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30057_30058 : H12AffineEnvironment.transform 14 8540 env30057 = env30058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30057 == env30058) = true)

theorem identity30058 : scanCanonicalize (H12AffineFastState.compose env30058 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 624) := by decide +kernel

theorem selectedBound30058 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,624,8192,9853,8540,263,9837,2341,1025,8541,560,32,16,8462,8193,65,2129,1888,9085,10360,1365,8492,257,8493,1824,8973]

theorem envBound30059 : H12AffineFastState.Bounded env30059 := by
  intro p hp
  have h : env30059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30058_30059 : H12AffineEnvironment.transform 11 624 env30058 = env30059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 624 env30058 == env30059) = true)

theorem identity30059 : scanCanonicalize (H12AffineFastState.compose env30059 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound30059 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,624,1052,609,1344,263,625,2341,1025,1345,560,32,16,1298,1053,65,2129,1888,1889,3172,1365,1328,257,1329,1824,1809]

theorem envBound30060 : H12AffineFastState.Bounded env30060 := by
  intro p hp
  have h : env30060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30059_30060 : H12AffineEnvironment.transform 12 1052 env30059 = env30060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env30059 == env30060) = true)

theorem identity30060 : scanCanonicalize (H12AffineFastState.compose env30060 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound30060 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env30061 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,512,1052,529,1328,263,513,2341,1025,1329,560,32,16,1298,1053,49,2081,1808,1809,3092,1317,1328,257,1329,1824,1809]

theorem envBound30061 : H12AffineFastState.Bounded env30061 := by
  intro p hp
  have h : env30061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30060_30061 : H12AffineEnvironment.transform 5 48 env30060 = env30061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env30060 == env30061) = true)

theorem identity30061 : scanCanonicalize (H12AffineFastState.compose env30061 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30061 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30062 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,512,1052,529,1297,263,513,2308,1025,1296,529,1,16,1298,1053,16,2048,1808,1809,3092,1284,1297,257,1296,1793,1809]

theorem envBound30062 : H12AffineFastState.Bounded env30062 := by
  intro p hp
  have h : env30062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30061_30062 : H12AffineEnvironment.transform 4 1 env30061 = env30062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30061 == env30062) = true)

theorem identity30062 : scanCanonicalize (H12AffineFastState.compose env30062 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound30062 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env30063 : List Nat := [2,4,8,16,1,17,9,256,512,1024,789,512,1052,529,1297,263,513,529,1025,1296,529,1,16,1298,1053,16,789,1808,1809,1793,1284,1297,257,1296,1793,1809]

theorem envBound30063 : H12AffineFastState.Bounded env30063 := by
  intro p hp
  have h : env30063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30062_30063 : H12AffineEnvironment.transform 10 789 env30062 = env30063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env30062 == env30063) = true)

theorem identity30063 : scanCanonicalize (H12AffineFastState.compose env30063 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30063 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env30064 : List Nat := [2,4,8,16,1,17,9,5,512,1024,528,512,1052,529,1044,2,513,529,1025,1045,529,1,16,1047,1053,16,528,1557,1556,1540,1025,1044,4,1045,1540,1556]

theorem envBound30064 : H12AffineFastState.Bounded env30064 := by
  intro p hp
  have h : env30064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30063_30064 : H12AffineEnvironment.transform 7 5 env30063 = env30064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30063 == env30064) = true)

theorem identity30064 : scanCanonicalize (H12AffineFastState.compose env30064 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30064 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30065 : List Nat := [2,4,8,1,1,0,9,5,512,1024,513,512,1037,512,1029,2,513,512,1025,1028,512,1,1,1030,1036,1,513,1540,1541,1540,1025,1029,4,1028,1540,1541]

theorem envBound30065 : H12AffineFastState.Bounded env30065 := by
  intro p hp
  have h : env30065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30064_30065 : H12AffineEnvironment.transform 3 1 env30064 = env30065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30064 == env30065) = true)

theorem identity30065 : scanCanonicalize (H12AffineFastState.compose env30065 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30066 : List Nat := [2,4,8,1,1,0,9,5,1,1024,0,1,1037,1,1029,2,0,1,1025,1028,1,1,1,1030,1036,1,0,1029,1028,1029,1025,1029,4,1028,1029,1028]

theorem envBound30066 : H12AffineFastState.Bounded env30066 := by
  intro p hp
  have h : env30066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30065_30066 : H12AffineEnvironment.transform 8 1 env30065 = env30066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30065 == env30066) = true)

theorem identity30066 : scanCanonicalize (H12AffineFastState.compose env30066 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30066 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30067 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,1,9,1,1,2,0,1,5,0,1,1,1,2,8,1,0,1,0,1,5,1,4,0,1,0]

theorem envBound30067 : H12AffineFastState.Bounded env30067 := by
  intro p hp
  have h : env30067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30066_30067 : H12AffineEnvironment.transform 9 4 env30066 = env30067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30066 == env30067) = true)

def env30068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98780,8328,65,4340964,5393,17664,179512,1501,4256860,257,21792,46213,74251]

theorem envBound30068 : H12AffineFastState.Bounded env30068 := by
  intro p hp
  have h : env30068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30041_30068 : H12AffineEnvironment.transform 20 4161 env30041 = env30068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30041 == env30068) = true)

theorem identity30068 : scanCanonicalize (H12AffineFastState.compose env30068 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30068 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32040,1025,29909,4161,4194304,17,95496,8328,65,4340964,5393,17664,149996,1501,4194440,257,21792,16465,74251]

theorem envBound30069 : H12AffineFastState.Bounded env30069 := by
  intro p hp
  have h : env30069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30068_30069 : H12AffineEnvironment.transform 14 29908 env30068 = env30069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30068 == env30069) = true)

def env30070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10280,1025,8661,4161,4194304,17,73736,8328,65,4340964,5393,4096,138476,1501,4194440,257,32,5457,74251]

theorem envBound30070 : H12AffineFastState.Bounded env30070 := by
  intro p hp
  have h : env30070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30069_30070 : H12AffineEnvironment.transform 13 5376 env30069 = env30070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30069 == env30070) = true)

theorem identity30070 : scanCanonicalize (H12AffineFastState.compose env30070 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30070 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8322,131072,10280,1025,8661,4161,4194304,17,138,8328,65,4340964,5393,4096,138476,1501,4194440,257,32,5457,649]

theorem envBound30071 : H12AffineFastState.Bounded env30071 := by
  intro p hp
  have h : env30071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30070_30071 : H12AffineEnvironment.transform 15 8322 env30070 = env30071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30070 == env30071) = true)

theorem identity30071 : scanCanonicalize (H12AffineFastState.compose env30071 (packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30071 : packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS < 2^1333 := by decide +kernel

def env30072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,479,131072,2421,1025,136,4161,4194304,17,138,469,65,4332985,5393,4096,138476,1501,4194440,257,32,5457,649]

theorem envBound30072 : H12AffineFastState.Bounded env30072 := by
  intro p hp
  have h : env30072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30071_30072 : H12AffineEnvironment.transform 12 349 env30071 = env30072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30071 == env30072) = true)

theorem identity30072 : scanCanonicalize (H12AffineFastState.compose env30072 (packedSelected [0,3,4,5,7,9,10,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 136632) := by decide +kernel

theorem selectedBound30072 : packedSelected [0,3,4,5,7,9,10,16,18] rootPS < 2^1333 := by decide +kernel

def env30073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,479,131072,2421,1025,136,4161,136632,17,138,469,65,2049,5393,4096,138476,1501,136496,257,32,5457,649]

theorem envBound30073 : H12AffineFastState.Bounded env30073 := by
  intro p hp
  have h : env30073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30072_30073 : H12AffineEnvironment.transform 21 136632 env30072 = env30073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136632 env30072 == env30073) = true)

theorem identity30073 : scanCanonicalize (H12AffineFastState.compose env30073 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30073 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env30074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,479,5393,2421,1025,136,4161,169,17,138,469,65,2049,5393,4096,2557,1501,33,257,32,5457,649]

theorem envBound30074 : H12AffineFastState.Bounded env30074 := by
  intro p hp
  have h : env30074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30073_30074 : H12AffineEnvironment.transform 16 5393 env30073 = env30074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30073 == env30074) = true)

theorem identity30074 : scanCanonicalize (H12AffineFastState.compose env30074 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound30074 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30075 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,349,5376,33,375,5393,2421,1025,32,4161,1,17,34,381,65,2049,5393,4096,2389,1397,33,257,32,5457,545]

theorem envBound30075 : H12AffineFastState.Bounded env30075 := by
  intro p hp
  have h : env30075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30074_30075 : H12AffineEnvironment.transform 6 40 env30074 = env30075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env30074 == env30075) = true)

theorem identity30075 : scanCanonicalize (H12AffineFastState.compose env30075 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30075 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env30076 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2389,1025,0,4161,1,17,2,349,65,2049,5393,4096,2389,1365,1,257,0,5457,513]

theorem envBound30076 : H12AffineFastState.Bounded env30076 := by
  intro p hp
  have h : env30076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30075_30076 : H12AffineEnvironment.transform 4 0 env30075 = env30076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30075 == env30076) = true)

theorem identity30076 : scanCanonicalize (H12AffineFastState.compose env30076 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1873) := by decide +kernel

theorem selectedBound30076 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30077 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,1873,349,593,1,343,576,2389,1025,0,1808,1,17,2,349,65,2049,576,1873,2389,1365,1,257,0,512,513]

theorem envBound30077 : H12AffineFastState.Bounded env30077 := by
  intro p hp
  have h : env30077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30076_30077 : H12AffineEnvironment.transform 11 1873 env30076 = env30077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1873 env30076 == env30077) = true)

def env30078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1025,8660,4161,4194304,17,73737,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5456,74251]

theorem envBound30078 : H12AffineFastState.Bounded env30078 := by
  intro p hp
  have h : env30078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30069_30078 : H12AffineEnvironment.transform 13 5377 env30069 = env30078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30069 == env30078) = true)

theorem identity30078 : scanCanonicalize (H12AffineFastState.compose env30078 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30078 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,131072,10281,1025,8660,4161,4194304,17,3,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5456,513]

theorem envBound30079 : H12AffineFastState.Bounded env30079 := by
  intro p hp
  have h : env30079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30078_30079 : H12AffineEnvironment.transform 15 8202 env30078 = env30079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30078 == env30079) = true)

theorem identity30079 : scanCanonicalize (H12AffineFastState.compose env30079 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound30079 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,131072,10281,1025,8660,4161,8321,17,3,8328,65,138341,5393,4097,138477,1501,8201,257,33,5456,513]

theorem envBound30080 : H12AffineFastState.Bounded env30080 := by
  intro p hp
  have h : env30080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30079_30080 : H12AffineEnvironment.transform 21 8321 env30079 = env30080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env30079 == env30080) = true)

theorem identity30080 : scanCanonicalize (H12AffineFastState.compose env30080 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound30080 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5392,10281,1025,8660,4161,8321,17,3,8328,65,2421,5393,4097,2557,1501,8201,257,33,5456,513]

theorem envBound30081 : H12AffineFastState.Bounded env30081 := by
  intro p hp
  have h : env30081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30080_30081 : H12AffineEnvironment.transform 16 5392 env30080 = env30081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env30080 == env30081) = true)

theorem identity30081 : scanCanonicalize (H12AffineFastState.compose env30081 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30081 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30082 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4113,8661,8202,4096,10281,273,8660,4161,8321,17,3,8328,65,2421,4097,4097,2557,205,8201,257,33,4160,513]

theorem envBound30082 : H12AffineFastState.Bounded env30082 := by
  intro p hp
  have h : env30082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30081_30082 : H12AffineEnvironment.transform 9 272 env30081 = env30082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30081 == env30082) = true)

theorem identity30082 : scanCanonicalize (H12AffineFastState.compose env30082 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound30082 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env30083 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,4096,8192,4113,8249,8202,4096,10281,253,8248,4161,8321,17,3,8328,65,2201,4097,4097,2065,205,8201,237,33,4160,513]

theorem envBound30083 : H12AffineFastState.Bounded env30083 := by
  intro p hp
  have h : env30083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30082_30083 : H12AffineEnvironment.transform 7 236 env30082 = env30083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env30082 == env30083) = true)

theorem identity30083 : scanCanonicalize (H12AffineFastState.compose env30083 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound30083 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env30084 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,4096,160,4113,153,170,4096,2185,253,152,4161,33,17,3,40,65,2201,4097,4097,2065,205,169,237,33,4160,513]

theorem envBound30084 : H12AffineFastState.Bounded env30084 := by
  intro p hp
  have h : env30084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30083_30084 : H12AffineEnvironment.transform 12 160 env30083 = env30084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env30083 == env30084) = true)

theorem identity30084 : scanCanonicalize (H12AffineFastState.compose env30084 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound30084 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env30085 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,2201,160,2184,153,170,2201,2185,253,152,2264,33,17,3,40,65,2201,2200,2200,2065,205,169,237,33,2265,513]

theorem envBound30085 : H12AffineFastState.Bounded env30085 := by
  intro p hp
  have h : env30085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30084_30085 : H12AffineEnvironment.transform 11 2201 env30084 = env30085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env30084 == env30085) = true)

theorem identity30085 : scanCanonicalize (H12AffineFastState.compose env30085 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30085 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env30086 : List Nat := [2,4,8,16,32,64,9,101,512,117,2048,2064,41,2049,16,35,2064,2048,116,17,2129,33,17,3,40,65,2064,2065,2065,2065,68,32,100,33,2128,513]

theorem envBound30086 : H12AffineFastState.Bounded env30086 := by
  intro p hp
  have h : env30086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30085_30086 : H12AffineEnvironment.transform 6 9 env30085 = env30086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30085 == env30086) = true)

theorem identity30086 : scanCanonicalize (H12AffineFastState.compose env30086 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30086 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30087 : List Nat := [2,4,8,16,0,64,9,69,512,85,2048,2064,9,2049,16,3,2064,2048,84,17,2129,1,17,3,8,65,2064,2065,2065,2065,68,0,68,1,2128,513]

theorem envBound30087 : H12AffineFastState.Bounded env30087 := by
  intro p hp
  have h : env30087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30086_30087 : H12AffineEnvironment.transform 4 0 env30086 = env30087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30086 == env30087) = true)

theorem identity30087 : scanCanonicalize (H12AffineFastState.compose env30087 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30087 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30088 : List Nat := [2,4,8,16,0,17,9,20,512,4,2048,2064,9,2049,16,3,2064,2048,5,17,2048,1,17,3,8,16,2064,2065,2065,2065,21,0,21,1,2049,513]

theorem envBound30088 : H12AffineFastState.Bounded env30088 := by
  intro p hp
  have h : env30088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30087_30088 : H12AffineEnvironment.transform 5 17 env30087 = env30088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30087 == env30088) = true)

theorem identity30088 : scanCanonicalize (H12AffineFastState.compose env30088 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound30088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30089 : List Nat := [2,4,8,16,0,17,9,20,512,4,528,512,9,529,16,3,512,528,5,17,528,1,17,3,8,16,512,513,513,513,21,0,21,1,529,513]

theorem envBound30089 : H12AffineFastState.Bounded env30089 := by
  intro p hp
  have h : env30089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30088_30089 : H12AffineEnvironment.transform 10 528 env30088 = env30089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env30088 == env30089) = true)

def env30090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101329,98781,8328,65,6433957,2098513,17665,2272632,2102684,6349852,257,21792,46213,2175562]

theorem envBound30090 : H12AffineFastState.Bounded env30090 := by
  intro p hp
  have h : env30090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30040_30090 : H12AffineEnvironment.transform 22 2101329 env30040 = env30090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env30040 == env30090) = true)

def env30091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98781,8328,65,4340965,5393,17665,179512,1500,4256860,257,21792,46213,74250]

theorem envBound30091 : H12AffineFastState.Bounded env30091 := by
  intro p hp
  have h : env30091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30090_30091 : H12AffineEnvironment.transform 20 4160 env30090 = env30091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30090 == env30091) = true)

def env30092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98645,8192,65,4340845,5393,17665,179512,1364,4256860,257,21792,46093,74250]

theorem envBound30092 : H12AffineFastState.Bounded env30092 := by
  intro p hp
  have h : env30092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30091_30092 : H12AffineEnvironment.transform 6 8 env30091 = env30092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30091 == env30092) = true)

theorem identity30092 : scanCanonicalize (H12AffineFastState.compose env30092 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30092 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41310,8192,65,4340845,5393,17665,179512,1364,4256860,257,21792,46093,513]

theorem envBound30093 : H12AffineFastState.Bounded env30093 := by
  intro p hp
  have h : env30093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30092_30093 : H12AffineEnvironment.transform 15 8203 env30092 = env30093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30092 == env30093) = true)

theorem identity30093 : scanCanonicalize (H12AffineFastState.compose env30093 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30093 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env30094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,4194304,17,21762,8192,65,4340845,5393,17665,149860,1364,4194304,257,21792,16465,513]

theorem envBound30094 : H12AffineFastState.Bounded env30094 := by
  intro p hp
  have h : env30094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30093_30094 : H12AffineEnvironment.transform 14 29788 env30093 = env30094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30093 == env30094) = true)

theorem identity30094 : scanCanonicalize (H12AffineFastState.compose env30094 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound30094 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env30095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21872,17,21762,8192,65,157981,5393,17665,149860,1364,21872,257,21792,16465,513]

theorem envBound30095 : H12AffineFastState.Bounded env30095 := by
  intro p hp
  have h : env30095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30094_30095 : H12AffineEnvironment.transform 21 21872 env30094 = env30095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env30094 == env30095) = true)

theorem identity30095 : scanCanonicalize (H12AffineFastState.compose env30095 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30095 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16401,32040,1025,29789,4160,21872,17,21762,8192,65,10508,5393,17665,2421,1364,21872,257,21792,16465,513]

theorem envBound30096 : H12AffineFastState.Bounded env30096 := by
  intro p hp
  have h : env30096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30095_30096 : H12AffineEnvironment.transform 16 16401 env30095 = env30096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30095 == env30096) = true)

theorem identity30096 : scanCanonicalize (H12AffineFastState.compose env30096 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30096 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10280,1025,8541,4160,112,17,2,8192,65,10508,5393,4097,2421,1364,112,257,32,5457,513]

theorem envBound30097 : H12AffineFastState.Bounded env30097 := by
  intro p hp
  have h : env30097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30096_30097 : H12AffineEnvironment.transform 13 5376 env30096 = env30097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30096 == env30097) = true)

theorem identity30097 : scanCanonicalize (H12AffineFastState.compose env30097 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30097 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30098 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,5393,10280,1025,8460,4113,33,17,2,8192,16,10508,5393,4097,2340,1285,33,257,32,5376,513]

theorem envBound30098 : H12AffineFastState.Bounded env30098 := by
  intro p hp
  have h : env30098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30097_30098 : H12AffineEnvironment.transform 5 17 env30097 = env30098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30097 == env30098) = true)

theorem identity30098 : scanCanonicalize (H12AffineFastState.compose env30098 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30099 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,8192,309,8461,8203,292,10280,1025,8460,1060,33,17,2,8192,16,10508,292,1076,2340,1285,33,257,32,309,513]

theorem envBound30099 : H12AffineFastState.Bounded env30099 := by
  intro p hp
  have h : env30099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30098_30099 : H12AffineEnvironment.transform 11 1077 env30098 = env30099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env30098 == env30099) = true)

theorem identity30099 : scanCanonicalize (H12AffineFastState.compose env30099 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound30099 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30100 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,2083,309,2350,2088,292,11,1025,2351,1060,33,17,2,2083,16,303,292,1076,2340,1285,33,257,32,309,513]

theorem envBound30100 : H12AffineFastState.Bounded env30100 := by
  intro p hp
  have h : env30100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30099_30100 : H12AffineEnvironment.transform 12 2083 env30099 = env30100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env30099 == env30100) = true)

theorem identity30100 : scanCanonicalize (H12AffineFastState.compose env30100 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound30100 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30101 : List Nat := [2,4,8,16,32,17,8,256,512,1024,303,1077,268,309,1,263,292,11,1025,0,1060,33,17,2,268,16,303,292,1076,11,1285,33,257,32,309,513]

theorem envBound30101 : H12AffineFastState.Bounded env30101 := by
  intro p hp
  have h : env30101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30100_30101 : H12AffineEnvironment.transform 10 303 env30100 = env30101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env30100 == env30101) = true)

def env30102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98644,8193,65,4340844,5393,17665,179512,1365,4256860,257,21792,46092,74250]

theorem envBound30102 : H12AffineFastState.Bounded env30102 := by
  intro p hp
  have h : env30102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30091_30102 : H12AffineEnvironment.transform 6 9 env30091 = env30102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30091 == env30102) = true)

theorem identity30102 : scanCanonicalize (H12AffineFastState.compose env30102 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30102 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,32040,1025,32769,4160,4194304,17,3,8193,65,4340844,5393,17665,179512,1365,4256860,257,21792,46092,41821]

theorem envBound30103 : H12AffineFastState.Bounded env30103 := by
  intro p hp
  have h : env30103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30102_30103 : H12AffineEnvironment.transform 15 33111 env30102 = env30103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30102 == env30103) = true)

theorem identity30103 : scanCanonicalize (H12AffineFastState.compose env30103 (packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30103 : packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env30104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32040,1025,8541,4160,4194304,17,3,8193,65,4340844,5393,17665,138340,1365,4216064,257,21792,5456,513]

theorem envBound30104 : H12AffineFastState.Bounded env30104 := by
  intro p hp
  have h : env30104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30103_30104 : H12AffineEnvironment.transform 14 8540 env30103 = env30104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30103 == env30104) = true)

theorem identity30104 : scanCanonicalize (H12AffineFastState.compose env30104 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30104 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,32040,1025,8541,4160,4194304,17,3,8193,65,4226172,5393,17665,23668,1365,4216064,257,21792,5456,513]

theorem envBound30105 : H12AffineFastState.Bounded env30105 := by
  intro p hp
  have h : env30105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30104_30105 : H12AffineEnvironment.transform 16 16400 env30104 = env30105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30104 == env30105) = true)

theorem identity30105 : scanCanonicalize (H12AffineFastState.compose env30105 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30105 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30106 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,8540,8203,16400,30777,272,8541,4160,4194304,17,3,8193,65,4225389,4096,16400,22885,68,4214801,257,20529,4161,513]

theorem envBound30106 : H12AffineFastState.Bounded env30106 := by
  intro p hp
  have h : env30106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30105_30106 : H12AffineEnvironment.transform 9 273 env30105 = env30106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30105 == env30106) = true)

theorem identity30106 : scanCanonicalize (H12AffineFastState.compose env30106 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound30106 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env30107 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4452,8540,8203,4468,10589,272,8541,4160,4194304,17,3,8193,65,4204553,4096,4468,2049,68,4194677,257,341,4161,513]

theorem envBound30107 : H12AffineFastState.Bounded env30107 := by
  intro p hp
  have h : env30107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30106_30107 : H12AffineEnvironment.transform 13 4452 env30106 = env30107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env30106 == env30107) = true)

theorem identity30107 : scanCanonicalize (H12AffineFastState.compose env30107 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound30107 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env30108 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4452,8540,8203,4468,10589,272,8541,4160,33,17,3,8193,65,10280,4096,4468,2049,68,340,257,341,4161,513]

theorem envBound30108 : H12AffineFastState.Bounded env30108 := by
  intro p hp
  have h : env30108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30107_30108 : H12AffineEnvironment.transform 21 33 env30107 = env30108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env30107 == env30108) = true)

theorem identity30108 : scanCanonicalize (H12AffineFastState.compose env30108 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30108 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30109 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4161,8313,8203,4177,10360,53,8312,4160,33,17,3,8193,65,10280,4096,4177,2049,68,113,36,112,4161,513]

theorem envBound30109 : H12AffineFastState.Bounded env30109 := by
  intro p hp
  have h : env30109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30108_30109 : H12AffineEnvironment.transform 7 37 env30108 = env30109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30108 == env30109) = true)

theorem identity30109 : scanCanonicalize (H12AffineFastState.compose env30109 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound30109 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env30110 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,6248,4161,6161,6243,4177,4112,53,6160,4160,33,17,3,6249,65,4160,4096,4177,2049,68,113,36,112,4161,513]

theorem envBound30110 : H12AffineFastState.Bounded env30110 := by
  intro p hp
  have h : env30110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30109_30110 : H12AffineEnvironment.transform 12 6248 env30109 = env30110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env30109 == env30110) = true)

theorem identity30110 : scanCanonicalize (H12AffineFastState.compose env30110 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound30110 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30111 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,96,2056,33,2161,2051,49,112,53,2160,32,33,17,3,2057,65,32,96,49,2049,68,113,36,112,33,513]

theorem envBound30111 : H12AffineFastState.Bounded env30111 := by
  intro p hp
  have h : env30111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30110_30111 : H12AffineEnvironment.transform 11 96 env30110 = env30111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env30110 == env30111) = true)

theorem identity30111 : scanCanonicalize (H12AffineFastState.compose env30111 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound30111 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env30112 : List Nat := [2,4,8,16,32,64,9,37,512,52,33,96,41,33,80,34,49,112,53,81,32,33,17,3,40,65,32,96,49,32,68,113,36,112,33,513]

theorem envBound30112 : H12AffineFastState.Bounded env30112 := by
  intro p hp
  have h : env30112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30111_30112 : H12AffineEnvironment.transform 10 33 env30111 = env30112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env30111 == env30112) = true)

theorem identity30112 : scanCanonicalize (H12AffineFastState.compose env30112 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30112 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30113 : List Nat := [2,4,8,16,32,16,9,37,512,52,33,48,41,33,0,34,49,32,53,1,32,33,17,3,40,17,32,48,49,32,20,33,36,32,33,513]

theorem envBound30113 : H12AffineFastState.Bounded env30113 := by
  intro p hp
  have h : env30113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30112_30113 : H12AffineEnvironment.transform 5 16 env30112 = env30113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30112 == env30113) = true)

theorem identity30113 : scanCanonicalize (H12AffineFastState.compose env30113 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30113 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30114 : List Nat := [2,4,8,16,32,16,9,37,16,52,33,48,41,33,0,34,49,32,53,1,32,33,17,3,40,17,32,48,49,32,20,33,36,32,33,17]

theorem envBound30114 : H12AffineFastState.Bounded env30114 := by
  intro p hp
  have h : env30114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30113_30114 : H12AffineEnvironment.transform 8 16 env30113 = env30114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30113 == env30114) = true)

theorem identity30114 : scanCanonicalize (H12AffineFastState.compose env30114 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound30114 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30115 : List Nat := [2,4,8,16,27,16,9,30,16,15,26,11,18,26,0,25,10,27,14,1,27,26,17,3,19,17,27,11,10,27,20,26,31,27,26,17]

theorem envBound30115 : H12AffineFastState.Bounded env30115 := by
  intro p hp
  have h : env30115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30114_30115 : H12AffineEnvironment.transform 4 27 env30114 = env30115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env30114 == env30115) = true)

theorem identity30115 : scanCanonicalize (H12AffineFastState.compose env30115 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30116 : List Nat := [2,4,8,11,0,11,9,5,11,15,1,11,9,1,0,2,10,0,14,1,0,1,10,3,8,10,0,11,10,0,15,1,4,0,1,10]

theorem envBound30116 : H12AffineFastState.Bounded env30116 := by
  intro p hp
  have h : env30116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30115_30116 : H12AffineEnvironment.transform 3 11 env30115 = env30116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30115 == env30116) = true)

theorem identity30116 : scanCanonicalize (H12AffineFastState.compose env30116 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30116 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30117 : List Nat := [2,4,3,0,0,0,2,5,0,4,1,0,2,1,0,2,1,0,5,1,0,1,1,3,3,1,0,0,1,0,4,1,4,0,1,1]

theorem envBound30117 : H12AffineFastState.Bounded env30117 := by
  intro p hp
  have h : env30117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30116_30117 : H12AffineEnvironment.transform 2 3 env30116 = env30117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30116 == env30117) = true)

def env30118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,16,98781,8328,65,4340964,5392,17665,179513,1501,4256861,257,21792,46213,74251]

theorem envBound30118 : H12AffineFastState.Bounded env30118 := by
  intro p hp
  have h : env30118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30090_30118 : H12AffineEnvironment.transform 20 4161 env30090 = env30118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30090 == env30118) = true)

theorem identity30118 : scanCanonicalize (H12AffineFastState.compose env30118 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21928) := by decide +kernel

theorem selectedBound30118 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21928,16,98781,8328,65,158028,5392,17665,179513,1501,41461,257,21792,46213,74251]

theorem envBound30119 : H12AffineFastState.Bounded env30119 := by
  intro p hp
  have h : env30119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30118_30119 : H12AffineEnvironment.transform 21 21928 env30118 = env30119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21928 env30118 == env30119) = true)

theorem identity30119 : scanCanonicalize (H12AffineFastState.compose env30119 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30119 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,21928,16,41431,8328,65,158028,5392,17665,179513,1501,41461,257,21792,46213,513]

theorem envBound30120 : H12AffineFastState.Bounded env30120 := by
  intro p hp
  have h : env30120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30119_30120 : H12AffineEnvironment.transform 15 8202 env30119 = env30120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30119 == env30120) = true)

theorem identity30120 : scanCanonicalize (H12AffineFastState.compose env30120 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30120 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32040,1025,32769,4161,21928,16,41431,8328,65,10589,5392,17665,64808,1501,41461,257,21792,46213,513]

theorem envBound30121 : H12AffineFastState.Bounded env30121 := by
  intro p hp
  have h : env30121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30120_30121 : H12AffineEnvironment.transform 16 16401 env30120 = env30121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30120 == env30121) = true)

def env30122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433957,8393985,10507600,8568104,2102685,12645452,257,21793,46212,2175563]

theorem envBound30122 : H12AffineFastState.Bounded env30122 := by
  intro p hp
  have h : env30122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30039_30122 : H12AffineEnvironment.transform 17 32041 env30039 = env30122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env30039 == env30122) = true)

def env30123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101328,98781,8328,65,6433957,2098513,17664,2272632,2102685,6349852,257,21793,46212,2175563]

theorem envBound30123 : H12AffineFastState.Bounded env30123 := by
  intro p hp
  have h : env30123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30122_30123 : H12AffineEnvironment.transform 22 2101328 env30122 = env30123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env30122 == env30123) = true)

def env30124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,16,98781,8328,65,4340965,5393,17664,179512,1501,4256860,257,21793,46212,74251]

theorem envBound30124 : H12AffineFastState.Bounded env30124 := by
  intro p hp
  have h : env30124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30123_30124 : H12AffineEnvironment.transform 20 4160 env30123 = env30124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30123 == env30124) = true)

theorem identity30124 : scanCanonicalize (H12AffineFastState.compose env30124 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95651) := by decide +kernel

theorem selectedBound30124 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95651,16,98781,8328,65,215366,5393,17664,179512,1501,98815,257,21793,46212,74251]

theorem envBound30125 : H12AffineFastState.Bounded env30125 := by
  intro p hp
  have h : env30125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30124_30125 : H12AffineEnvironment.transform 21 95651 env30124 = env30125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95651 env30124 == env30125) = true)

def env30126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95531,16,98645,8192,65,215366,5393,17664,179512,1365,98679,257,21793,46092,74251]

theorem envBound30126 : H12AffineFastState.Bounded env30126 := by
  intro p hp
  have h : env30126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30125_30126 : H12AffineEnvironment.transform 6 8 env30125 = env30126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30125 == env30126) = true)

theorem identity30126 : scanCanonicalize (H12AffineFastState.compose env30126 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound30126 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32041,1025,32769,4160,32,16,62558,8192,65,146509,5393,17664,179512,1365,62588,257,21793,46092,22272]

theorem envBound30127 : H12AffineFastState.Bounded env30127 := by
  intro p hp
  have h : env30127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30126_30127 : H12AffineEnvironment.transform 15 29963 env30126 = env30127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env30126 == env30127) = true)

theorem identity30127 : scanCanonicalize (H12AffineFastState.compose env30127 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound30127 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env30128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46157,32041,1025,32769,4160,32,16,62558,8192,65,34816,5393,17664,2421,1365,62588,257,21793,46092,22272]

theorem envBound30128 : H12AffineFastState.Bounded env30128 := by
  intro p hp
  have h : env30128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30127_30128 : H12AffineEnvironment.transform 16 46157 env30127 = env30128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env30127 == env30128) = true)

theorem identity30128 : scanCanonicalize (H12AffineFastState.compose env30128 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30128 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,16401,32041,1025,29789,4160,32,16,2,8192,65,31836,5393,17664,2421,1365,32,257,21793,16464,22272]

theorem envBound30129 : H12AffineFastState.Bounded env30129 := by
  intro p hp
  have h : env30129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30128_30129 : H12AffineEnvironment.transform 14 29788 env30128 = env30129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30128 == env30129) = true)

theorem identity30129 : scanCanonicalize (H12AffineFastState.compose env30129 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound30129 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,292,115,13673,2129,1025,293,4160,32,16,2,8192,65,2340,5393,12408,2421,1365,32,257,8281,13608,8824]

theorem envBound30130 : H12AffineFastState.Bounded env30130 := by
  intro p hp
  have h : env30130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30129_30130 : H12AffineEnvironment.transform 13 13688 env30129 = env30130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env30129 == env30130) = true)

theorem identity30130 : scanCanonicalize (H12AffineFastState.compose env30130 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30130 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30131 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,13405,1,115,13388,2129,1025,0,4160,32,16,2,8192,65,2049,5172,12408,2128,1136,32,36,8281,13325,8824]

theorem envBound30131 : H12AffineFastState.Bounded env30131 := by
  intro p hp
  have h : env30131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30130_30131 : H12AffineEnvironment.transform 7 37 env30130 = env30131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30130 == env30131) = true)

theorem identity30131 : scanCanonicalize (H12AffineFastState.compose env30131 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30131 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30132 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5236,1,115,5221,2129,1025,0,4160,32,16,2,41,65,2049,5172,4177,2128,1136,32,36,112,5156,593]

theorem envBound30132 : H12AffineFastState.Bounded env30132 := by
  intro p hp
  have h : env30132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30131_30132 : H12AffineEnvironment.transform 12 41 env30131 = env30132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30131 == env30132) = true)

theorem identity30132 : scanCanonicalize (H12AffineFastState.compose env30132 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound30132 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env30133 : List Nat := [2,4,8,16,32,64,8,37,512,1024,81,4096,41,5236,1,115,5221,0,1025,0,4160,32,16,2,41,65,80,5172,4177,1,1136,32,36,112,5156,593]

theorem envBound30133 : H12AffineFastState.Bounded env30133 := by
  intro p hp
  have h : env30133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30132_30133 : H12AffineEnvironment.transform 10 81 env30132 = env30133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env30132 == env30133) = true)

theorem identity30133 : scanCanonicalize (H12AffineFastState.compose env30133 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound30133 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env30134 : List Nat := [2,4,8,16,32,64,8,37,512,1024,81,16,41,1124,1,115,1141,0,1025,0,80,32,16,2,41,65,80,1060,65,1,1136,32,36,112,1076,593]

theorem envBound30134 : H12AffineFastState.Bounded env30134 := by
  intro p hp
  have h : env30134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30133_30134 : H12AffineEnvironment.transform 11 16 env30133 = env30134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30133 == env30134) = true)

theorem identity30134 : scanCanonicalize (H12AffineFastState.compose env30134 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30134 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30135 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,16,41,1077,1,34,1060,0,1025,0,1,32,16,2,41,16,1,1060,16,1,1057,32,36,33,1076,512]

theorem envBound30135 : H12AffineFastState.Bounded env30135 := by
  intro p hp
  have h : env30135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30134_30135 : H12AffineEnvironment.transform 5 17 env30134 = env30135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30134 == env30135) = true)

theorem identity30135 : scanCanonicalize (H12AffineFastState.compose env30135 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30136 : List Nat := [2,4,8,16,16,17,8,21,512,1024,0,16,25,1029,1,18,1044,0,1025,0,1,16,16,2,25,16,1,1044,16,1,1041,16,20,17,1028,512]

theorem envBound30136 : H12AffineFastState.Bounded env30136 := by
  intro p hp
  have h : env30136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30135_30136 : H12AffineEnvironment.transform 4 16 env30135 = env30136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30135 == env30136) = true)

theorem identity30136 : scanCanonicalize (H12AffineFastState.compose env30136 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound30136 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30137 : List Nat := [2,4,8,16,16,17,8,21,512,532,0,16,25,529,1,18,512,0,533,0,1,16,16,2,25,16,1,512,16,1,517,16,20,17,528,512]

theorem envBound30137 : H12AffineFastState.Bounded env30137 := by
  intro p hp
  have h : env30137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30136_30137 : H12AffineEnvironment.transform 9 532 env30136 = env30137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env30136 == env30137) = true)

theorem identity30137 : scanCanonicalize (H12AffineFastState.compose env30137 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30137 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30138 : List Nat := [2,4,8,1,1,0,8,4,512,517,0,1,8,512,1,3,512,0,516,0,1,1,1,2,8,1,1,512,1,1,517,1,5,0,513,512]

theorem envBound30138 : H12AffineFastState.Bounded env30138 := by
  intro p hp
  have h : env30138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30137_30138 : H12AffineEnvironment.transform 3 1 env30137 = env30138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30137 == env30138) = true)

def env30139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95530,16,98644,8193,65,215366,5393,17664,179512,1364,98678,257,21793,46093,74251]

theorem envBound30139 : H12AffineFastState.Bounded env30139 := by
  intro p hp
  have h : env30139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30125_30139 : H12AffineEnvironment.transform 6 9 env30125 = env30139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30125 == env30139) = true)

theorem identity30139 : scanCanonicalize (H12AffineFastState.compose env30139 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound30139 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4160,41340,16,21762,8193,65,171280,5393,17664,179512,1364,21792,257,21793,46093,63069]

theorem envBound30140 : H12AffineFastState.Bounded env30140 := by
  intro p hp
  have h : env30140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30139_30140 : H12AffineEnvironment.transform 15 54358 env30139 = env30140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env30139 == env30140) = true)

theorem identity30140 : scanCanonicalize (H12AffineFastState.compose env30140 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound30140 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env30141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,57676,32041,1025,32769,4160,41340,16,21762,8193,65,31836,5393,17664,23668,1364,21792,257,21793,46093,63069]

theorem envBound30141 : H12AffineFastState.Bounded env30141 := by
  intro p hp
  have h : env30141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30140_30141 : H12AffineEnvironment.transform 16 57676 env30140 = env30141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env30140 == env30141) = true)

theorem identity30141 : scanCanonicalize (H12AffineFastState.compose env30141 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound30141 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env30142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,21794,24632,32041,1025,373,4160,8200,16,21762,8193,65,31836,5393,17664,23668,1364,21792,257,21793,13689,30505]

theorem envBound30142 : H12AffineFastState.Bounded env30142 := by
  intro p hp
  have h : env30142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30141_30142 : H12AffineEnvironment.transform 14 372 env30141 = env30142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env30141 == env30142) = true)

theorem identity30142 : scanCanonicalize (H12AffineFastState.compose env30142 (packedSelected [2,4,9,11,16,23] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound30142 : packedSelected [2,4,9,11,16,23] rootPS < 2^1333 := by decide +kernel

def env30143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,372,262,13340,10509,1025,373,4160,8200,16,294,8193,65,10360,5393,4388,2128,1364,260,257,261,13689,8973]

theorem envBound30143 : H12AffineFastState.Bounded env30143 := by
  intro p hp
  have h : env30143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30142_30143 : H12AffineEnvironment.transform 13 5156 env30142 = env30143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env30142 == env30143) = true)

theorem identity30143 : scanCanonicalize (H12AffineFastState.compose env30143 (packedSelected [3,4,5,6,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30143 : packedSelected [3,4,5,6,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env30144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5156,372,262,5393,2048,1025,373,4160,261,16,294,268,65,2421,5393,4388,2128,1364,260,257,261,5236,512]

theorem envBound30144 : H12AffineFastState.Bounded env30144 := by
  intro p hp
  have h : env30144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30143_30144 : H12AffineEnvironment.transform 12 269 env30143 = env30144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30143 == env30144) = true)

theorem identity30144 : scanCanonicalize (H12AffineFastState.compose env30144 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30144 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30145 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,81,35,5172,2048,1025,80,4160,32,16,3,41,65,2128,5172,4097,2128,1137,33,36,32,5236,512]

theorem envBound30145 : H12AffineFastState.Bounded env30145 := by
  intro p hp
  have h : env30145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30144_30145 : H12AffineEnvironment.transform 7 37 env30144 = env30145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30144 == env30145) = true)

theorem identity30145 : scanCanonicalize (H12AffineFastState.compose env30145 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound30145 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30146 : List Nat := [2,4,8,16,32,64,9,37,512,1024,522,4096,40,5156,81,35,5172,522,1025,80,4160,32,16,3,41,65,602,5172,4097,602,1137,33,36,32,5236,512]

theorem envBound30146 : H12AffineFastState.Bounded env30146 := by
  intro p hp
  have h : env30146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30145_30146 : H12AffineEnvironment.transform 10 522 env30145 = env30146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env30145 == env30146) = true)

theorem identity30146 : scanCanonicalize (H12AffineFastState.compose env30146 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound30146 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30147 : List Nat := [2,4,8,16,32,49,9,37,512,1024,522,4096,40,5156,32,35,5172,522,1025,33,4145,32,16,3,41,48,555,5172,4097,555,1024,33,36,32,5125,512]

theorem envBound30147 : H12AffineFastState.Bounded env30147 := by
  intro p hp
  have h : env30147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30146_30147 : H12AffineEnvironment.transform 5 49 env30146 = env30147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env30146 == env30147) = true)

theorem identity30147 : scanCanonicalize (H12AffineFastState.compose env30147 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30147 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30148 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,4096,9,5125,1,2,5141,522,1025,0,4112,1,16,3,8,17,522,5141,4097,522,1024,0,5,1,5125,512]

theorem envBound30148 : H12AffineFastState.Bounded env30148 := by
  intro p hp
  have h : env30148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30147_30148 : H12AffineEnvironment.transform 4 1 env30147 = env30148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30147 == env30148) = true)

theorem identity30148 : scanCanonicalize (H12AffineFastState.compose env30148 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30149 : List Nat := [2,4,8,16,1,16,9,4,512,20,522,4096,9,4113,1,2,4097,522,21,0,4112,1,16,3,8,17,522,4097,4097,522,20,0,5,1,4113,512]

theorem envBound30149 : H12AffineFastState.Bounded env30149 := by
  intro p hp
  have h : env30149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30148_30149 : H12AffineEnvironment.transform 9 20 env30148 = env30149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30148 == env30149) = true)

theorem identity30149 : scanCanonicalize (H12AffineFastState.compose env30149 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 31) := by decide +kernel

theorem selectedBound30149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30150 : List Nat := [2,4,8,16,1,16,9,4,512,20,522,31,9,14,1,2,30,522,21,0,15,1,16,3,8,17,522,30,30,522,20,0,5,1,14,512]

theorem envBound30150 : H12AffineFastState.Bounded env30150 := by
  intro p hp
  have h : env30150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30149_30150 : H12AffineEnvironment.transform 11 31 env30149 = env30150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 31 env30149 == env30150) = true)

theorem identity30150 : scanCanonicalize (H12AffineFastState.compose env30150 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30151 : List Nat := [2,4,4,16,1,16,5,4,512,20,518,19,5,2,1,2,18,518,21,0,3,1,16,3,4,17,518,18,18,518,20,0,5,1,2,512]

theorem envBound30151 : H12AffineFastState.Bounded env30151 := by
  intro p hp
  have h : env30151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30150_30151 : H12AffineEnvironment.transform 2 4 env30150 = env30151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30150 == env30151) = true)

theorem identity30151 : scanCanonicalize (H12AffineFastState.compose env30151 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound30151 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30152 : List Nat := [2,4,4,16,1,16,5,4,5,20,3,19,5,2,1,2,18,3,21,0,3,1,16,3,4,17,3,18,18,3,20,0,5,1,2,5]

theorem envBound30152 : H12AffineFastState.Bounded env30152 := by
  intro p hp
  have h : env30152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30151_30152 : H12AffineEnvironment.transform 8 5 env30151 = env30152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env30151 == env30152) = true)

def env30153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98781,8328,65,4340964,5392,17664,179513,1500,4256861,257,21793,46212,74250]

theorem envBound30153 : H12AffineFastState.Bounded env30153 := by
  intro p hp
  have h : env30153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30123_30153 : H12AffineEnvironment.transform 20 4161 env30123 = env30153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30123 == env30153) = true)

theorem identity30153 : scanCanonicalize (H12AffineFastState.compose env30153 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30153 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41430,8328,65,4340964,5392,17664,179513,1500,4256861,257,21793,46212,513]

theorem envBound30154 : H12AffineFastState.Bounded env30154 := by
  intro p hp
  have h : env30154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30153_30154 : H12AffineEnvironment.transform 15 8203 env30153 = env30154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30153 == env30154) = true)

theorem identity30154 : scanCanonicalize (H12AffineFastState.compose env30154 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41380) := by decide +kernel

theorem selectedBound30154 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41380,17,41430,8328,65,171328,5392,17664,179513,1500,22009,257,21793,46212,513]

theorem envBound30155 : H12AffineFastState.Bounded env30155 := by
  intro p hp
  have h : env30155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30154_30155 : H12AffineEnvironment.transform 21 41380 env30154 = env30155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41380 env30154 == env30155) = true)

def env30156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41260,17,41310,8192,65,171328,5392,17664,179513,1364,21873,257,21793,46092,513]

theorem envBound30156 : H12AffineFastState.Bounded env30156 := by
  intro p hp
  have h : env30156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30155_30156 : H12AffineEnvironment.transform 6 8 env30155 = env30156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30155 == env30156) = true)

theorem identity30156 : scanCanonicalize (H12AffineFastState.compose env30156 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30156 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env30157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,21873,17,21763,8192,65,157981,5392,17664,149860,1364,21873,257,21793,16465,513]

theorem envBound30157 : H12AffineFastState.Bounded env30157 := by
  intro p hp
  have h : env30157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30156_30157 : H12AffineEnvironment.transform 14 29789 env30156 = env30157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30156 == env30157) = true)

theorem identity30157 : scanCanonicalize (H12AffineFastState.compose env30157 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30157 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16401,32041,1025,29788,4161,21873,17,21763,8192,65,10508,5392,17664,2421,1364,21873,257,21793,16465,513]

theorem envBound30158 : H12AffineFastState.Bounded env30158 := by
  intro p hp
  have h : env30158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30157_30158 : H12AffineEnvironment.transform 16 16401 env30157 = env30158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30157 == env30158) = true)

theorem identity30158 : scanCanonicalize (H12AffineFastState.compose env30158 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30158 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10280,1025,8541,4161,112,17,2,8192,65,10508,5392,4097,2421,1364,112,257,32,5456,513]

theorem envBound30159 : H12AffineFastState.Bounded env30159 := by
  intro p hp
  have h : env30159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30158_30159 : H12AffineEnvironment.transform 13 5377 env30158 = env30159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30158 == env30159) = true)

theorem identity30159 : scanCanonicalize (H12AffineFastState.compose env30159 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30159 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30160 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,5392,10280,1025,8460,4112,33,17,2,8192,16,10508,5392,4097,2340,1285,33,257,32,5377,513]

theorem envBound30160 : H12AffineFastState.Bounded env30160 := by
  intro p hp
  have h : env30160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30159_30160 : H12AffineEnvironment.transform 5 17 env30159 = env30160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30159 == env30160) = true)

theorem identity30160 : scanCanonicalize (H12AffineFastState.compose env30160 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30160 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30161 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,8192,309,8461,8203,292,10280,1025,8460,1060,33,17,2,8192,16,10508,292,1077,2340,1285,33,257,32,309,513]

theorem envBound30161 : H12AffineFastState.Bounded env30161 := by
  intro p hp
  have h : env30161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30160_30161 : H12AffineEnvironment.transform 11 1076 env30160 = env30161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env30160 == env30161) = true)

theorem identity30161 : scanCanonicalize (H12AffineFastState.compose env30161 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound30161 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30162 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,2082,309,2351,2089,292,10,1025,2350,1060,33,17,2,2082,16,302,292,1077,2340,1285,33,257,32,309,513]

theorem envBound30162 : H12AffineFastState.Bounded env30162 := by
  intro p hp
  have h : env30162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30161_30162 : H12AffineEnvironment.transform 12 2082 env30161 = env30162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env30161 == env30162) = true)

theorem identity30162 : scanCanonicalize (H12AffineFastState.compose env30162 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound30162 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30163 : List Nat := [2,4,8,16,32,17,8,256,512,1024,302,1076,268,309,1,263,292,10,1025,0,1060,33,17,2,268,16,302,292,1077,10,1285,33,257,32,309,513]

theorem envBound30163 : H12AffineFastState.Bounded env30163 := by
  intro p hp
  have h : env30163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30162_30163 : H12AffineEnvironment.transform 10 302 env30162 = env30163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env30162 == env30163) = true)

def env30164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41261,17,41311,8193,65,171328,5392,17664,179513,1365,21872,257,21793,46093,513]

theorem envBound30164 : H12AffineFastState.Bounded env30164 := by
  intro p hp
  have h : env30164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30155_30164 : H12AffineEnvironment.transform 6 9 env30155 = env30164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30155 == env30164) = true)

theorem identity30164 : scanCanonicalize (H12AffineFastState.compose env30164 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30164 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32041,1025,8541,4161,113,17,3,8193,65,146460,5392,17664,138341,1365,21872,257,21793,5457,513]

theorem envBound30165 : H12AffineFastState.Bounded env30165 := by
  intro p hp
  have h : env30165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30164_30165 : H12AffineEnvironment.transform 14 8540 env30164 = env30165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30164 == env30165) = true)

theorem identity30165 : scanCanonicalize (H12AffineFastState.compose env30165 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30165 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,32041,1025,8541,4161,113,17,3,8193,65,31756,5392,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound30166 : H12AffineFastState.Bounded env30166 := by
  intro p hp
  have h : env30166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30165_30166 : H12AffineEnvironment.transform 16 16400 env30165 = env30166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30165 == env30166) = true)

theorem identity30166 : scanCanonicalize (H12AffineFastState.compose env30166 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound30166 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8540,8203,13673,2128,1025,8541,4161,113,17,3,8193,65,2421,5392,12409,10508,1365,8201,257,8280,5457,513]

theorem envBound30167 : H12AffineFastState.Bounded env30167 := by
  intro p hp
  have h : env30167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30166_30167 : H12AffineEnvironment.transform 13 13689 env30166 = env30167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env30166 == env30167) = true)

theorem identity30167 : scanCanonicalize (H12AffineFastState.compose env30167 (packedSelected [5,8,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30167 : packedSelected [5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env30168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,372,35,5441,2128,1025,373,4161,113,17,3,41,65,2421,5392,4177,2340,1365,33,257,112,5457,513]

theorem envBound30168 : H12AffineFastState.Bounded env30168 := by
  intro p hp
  have h : env30168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30167_30168 : H12AffineEnvironment.transform 12 40 env30167 = env30168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30167 == env30168) = true)

theorem identity30168 : scanCanonicalize (H12AffineFastState.compose env30168 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound30168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30169 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,40,4144,372,35,4128,2128,352,373,4161,113,17,3,41,65,2421,4209,4177,2340,52,33,257,112,4144,513]

theorem envBound30169 : H12AffineFastState.Bounded env30169 := by
  intro p hp
  have h : env30169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30168_30169 : H12AffineEnvironment.transform 9 353 env30168 = env30169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env30168 == env30169) = true)

theorem identity30169 : scanCanonicalize (H12AffineFastState.compose env30169 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30169 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30170 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,40,4144,292,35,4128,2048,304,293,4113,33,17,3,41,17,2341,4129,4097,2340,52,33,257,32,4144,513]

theorem envBound30170 : H12AffineFastState.Bounded env30170 := by
  intro p hp
  have h : env30170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30169_30170 : H12AffineEnvironment.transform 5 16 env30169 = env30170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30169 == env30170) = true)

theorem identity30170 : scanCanonicalize (H12AffineFastState.compose env30170 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound30170 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30171 : List Nat := [2,4,8,16,32,16,9,256,512,305,261,4096,40,4144,292,35,4128,261,304,293,4113,33,17,3,41,17,32,4129,4097,33,52,33,257,32,4144,513]

theorem envBound30171 : H12AffineFastState.Bounded env30171 := by
  intro p hp
  have h : env30171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30170_30171 : H12AffineEnvironment.transform 10 261 env30170 = env30171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env30170 == env30171) = true)

theorem identity30171 : scanCanonicalize (H12AffineFastState.compose env30171 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 788) := by decide +kernel

theorem selectedBound30171 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env30172 : List Nat := [2,4,8,16,32,16,9,256,512,305,261,788,40,804,292,35,820,261,304,293,773,33,17,3,41,17,32,821,789,33,52,33,257,32,804,513]

theorem envBound30172 : H12AffineFastState.Bounded env30172 := by
  intro p hp
  have h : env30172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30171_30172 : H12AffineEnvironment.transform 11 788 env30171 = env30172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 788 env30171 == env30172) = true)

theorem identity30172 : scanCanonicalize (H12AffineFastState.compose env30172 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30172 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30173 : List Nat := [2,4,8,16,32,16,9,5,512,52,0,529,40,545,33,35,561,0,53,32,512,33,17,3,41,17,32,560,528,33,52,33,4,32,545,513]

theorem envBound30173 : H12AffineFastState.Bounded env30173 := by
  intro p hp
  have h : env30173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30172_30173 : H12AffineEnvironment.transform 7 5 env30172 = env30173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30172 == env30173) = true)

theorem identity30173 : scanCanonicalize (H12AffineFastState.compose env30173 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound30173 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30174 : List Nat := [2,4,8,16,32,16,9,5,33,52,0,48,40,0,33,35,16,0,53,32,33,33,17,3,41,17,32,17,49,33,52,33,4,32,0,32]

theorem envBound30174 : H12AffineFastState.Bounded env30174 := by
  intro p hp
  have h : env30174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30173_30174 : H12AffineEnvironment.transform 8 33 env30173 = env30174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env30173 == env30174) = true)

theorem identity30174 : scanCanonicalize (H12AffineFastState.compose env30174 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30174 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30175 : List Nat := [2,4,8,16,16,16,9,5,17,4,0,0,24,0,17,19,16,0,5,16,17,17,17,3,25,17,16,17,1,17,4,17,4,16,0,16]

theorem envBound30175 : H12AffineFastState.Bounded env30175 := by
  intro p hp
  have h : env30175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30174_30175 : H12AffineEnvironment.transform 4 16 env30174 = env30175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30174 == env30175) = true)

def env30176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101329,98780,8328,65,6433957,2098512,17665,2272633,2102685,6349853,257,21793,46212,2175563]

theorem envBound30176 : H12AffineFastState.Bounded env30176 := by
  intro p hp
  have h : env30176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30122_30176 : H12AffineEnvironment.transform 22 2101329 env30122 = env30176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env30122 == env30176) = true)

def env30177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98780,8328,65,4340965,5392,17665,179513,1501,4256861,257,21793,46212,74251]

theorem envBound30177 : H12AffineFastState.Bounded env30177 := by
  intro p hp
  have h : env30177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30176_30177 : H12AffineEnvironment.transform 20 4160 env30176 = env30177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30176 == env30177) = true)

theorem identity30177 : scanCanonicalize (H12AffineFastState.compose env30177 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound30177 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32041,1025,32769,4160,4194304,17,21763,8328,65,4340965,5392,17665,179513,1501,4256861,257,21793,46212,63188]

theorem envBound30178 : H12AffineFastState.Bounded env30178 := by
  intro p hp
  have h : env30178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30177_30178 : H12AffineEnvironment.transform 15 54495 env30177 = env30178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env30177 == env30178) = true)

def env30179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4160,4194304,17,21763,8192,65,4340845,5392,17665,179513,1365,4256861,257,21793,46092,63068]

theorem envBound30179 : H12AffineFastState.Bounded env30179 := by
  intro p hp
  have h : env30179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30178_30179 : H12AffineEnvironment.transform 6 8 env30178 = env30179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30178 == env30179) = true)

theorem identity30179 : scanCanonicalize (H12AffineFastState.compose env30179 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30179 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4160,4194304,17,21763,8192,65,4340845,5392,17665,149860,1365,4194304,257,21793,16465,513]

theorem envBound30180 : H12AffineFastState.Bounded env30180 := by
  intro p hp
  have h : env30180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30179_30180 : H12AffineEnvironment.transform 14 29789 env30179 = env30180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30179 == env30180) = true)

theorem identity30180 : scanCanonicalize (H12AffineFastState.compose env30180 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound30180 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env30181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4160,147504,17,21763,8192,65,31837,5392,17665,149860,1365,147504,257,21793,16465,513]

theorem envBound30181 : H12AffineFastState.Bounded env30181 := by
  intro p hp
  have h : env30181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30180_30181 : H12AffineEnvironment.transform 21 147504 env30180 = env30181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env30180 == env30181) = true)

theorem identity30181 : scanCanonicalize (H12AffineFastState.compose env30181 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30181 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,32041,1025,29788,4160,32,17,21763,8192,65,31837,5392,17665,2420,1365,32,257,21793,16465,513]

theorem envBound30182 : H12AffineFastState.Bounded env30182 := by
  intro p hp
  have h : env30182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30181_30182 : H12AffineEnvironment.transform 16 16400 env30181 = env30182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30181 == env30182) = true)

theorem identity30182 : scanCanonicalize (H12AffineFastState.compose env30182 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound30182 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,13388,2421,1025,0,4160,32,17,8543,8192,65,2049,5392,12637,2420,1365,32,257,8573,13325,513]

theorem envBound30183 : H12AffineFastState.Bounded env30183 := by
  intro p hp
  have h : env30183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30182_30183 : H12AffineEnvironment.transform 13 13404 env30182 = env30183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env30182 == env30183) = true)

end H12CloudChart0