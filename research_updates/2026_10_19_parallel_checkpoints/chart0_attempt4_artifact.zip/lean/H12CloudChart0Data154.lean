import H12CloudChart0Data153

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound39044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39045 : List Nat := [2,4,8,16,16,16,8,256,512,516,2048,4096,269,4869,1,263,4885,2325,516,0,4113,17,17,3,269,17,2048,4884,4097,2325,768,16,256,16,4869,513]

theorem envBound39045 : H12AffineFastState.Bounded env39045 := by
  intro p hp
  have h : env39045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39044_39045 : H12AffineEnvironment.transform 4 16 env39044 = env39045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39044 == env39045) = true)

theorem identity39045 : scanCanonicalize (H12AffineFastState.compose env39045 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound39045 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39046 : List Nat := [2,4,8,16,16,16,8,256,276,272,2048,4096,269,4113,1,263,4097,2325,272,0,4113,17,17,3,269,17,2048,4096,4097,2325,20,16,256,16,4113,277]

theorem envBound39046 : H12AffineFastState.Bounded env39046 := by
  intro p hp
  have h : env39046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39045_39046 : H12AffineEnvironment.transform 8 276 env39045 = env39046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env39045 == env39046) = true)

theorem identity39046 : scanCanonicalize (H12AffineFastState.compose env39046 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound39046 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39047 : List Nat := [2,4,8,16,16,16,8,256,276,272,2048,2048,269,2065,1,263,2049,2325,272,0,2065,17,17,3,269,17,2048,2048,2049,2325,20,16,256,16,2065,277]

theorem envBound39047 : H12AffineFastState.Bounded env39047 := by
  intro p hp
  have h : env39047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39046_39047 : H12AffineEnvironment.transform 11 2048 env39046 = env39047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env39046 == env39047) = true)

theorem identity39047 : scanCanonicalize (H12AffineFastState.compose env39047 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound39047 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39048 : List Nat := [2,4,8,16,16,16,8,256,276,272,277,277,269,260,1,263,276,0,272,0,260,17,17,3,269,17,277,277,276,0,20,16,256,16,260,277]

theorem envBound39048 : H12AffineFastState.Bounded env39048 := by
  intro p hp
  have h : env39048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39047_39048 : H12AffineEnvironment.transform 10 277 env39047 = env39048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env39047 == env39048) = true)

theorem identity39048 : scanCanonicalize (H12AffineFastState.compose env39048 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound39048 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39049 : List Nat := [2,4,8,16,16,16,8,21,1,5,0,0,24,17,1,18,1,0,5,0,17,17,17,3,24,17,0,0,1,0,20,16,21,16,17,0]

theorem envBound39049 : H12AffineFastState.Bounded env39049 := by
  intro p hp
  have h : env39049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39048_39049 : H12AffineEnvironment.transform 7 21 env39048 = env39049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env39048 == env39049) = true)

theorem identity39049 : scanCanonicalize (H12AffineFastState.compose env39049 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39049 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env39050 : List Nat := [2,4,8,1,1,1,8,4,1,5,0,0,9,0,1,3,1,0,5,0,0,0,0,3,9,0,0,0,1,0,5,1,4,1,0,0]

theorem envBound39050 : H12AffineFastState.Bounded env39050 := by
  intro p hp
  have h : env39050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39049_39050 : H12AffineEnvironment.transform 3 1 env39049 = env39050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39049 == env39050) = true)

def env39051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363553,21762,8328,65,215366,115151,4378672,4332612,4408371,4268163,256,4396238,4453738,4350948]

theorem envBound39051 : H12AffineFastState.Bounded env39051 := by
  intro p hp
  have h : env39051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38985_39051 : H12AffineEnvironment.transform 22 4363553 env38985 = env39051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env38985 == env39051) = true)

theorem identity39051 : scanCanonicalize (H12AffineFastState.compose env39051 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound39051 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,16,21762,8328,65,215366,115151,17665,35189,119042,243122,256,98815,90203,63189]

theorem envBound39052 : H12AffineFastState.Bounded env39052 := by
  intro p hp
  have h : env39052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39051_39052 : H12AffineEnvironment.transform 21 169265 env39051 = env39052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env39051 == env39052) = true)

def env39053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,16,21762,8192,65,215366,115015,17665,35189,119042,243002,256,98679,90203,63069]

theorem envBound39053 : H12AffineFastState.Bounded env39053 := by
  intro p hp
  have h : env39053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39052_39053 : H12AffineEnvironment.transform 6 8 env39052 = env39053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39052 == env39053) = true)

theorem identity39053 : scanCanonicalize (H12AffineFastState.compose env39053 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound39053 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1024,32769,4161,62588,16,21762,8192,65,75787,115015,17665,35189,119042,119927,256,98679,90203,63069]

theorem envBound39054 : H12AffineFastState.Bounded env39054 := by
  intro p hp
  have h : env39054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39053_39054 : H12AffineEnvironment.transform 16 24909 env39053 = env39054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env39053 == env39054) = true)

theorem identity39054 : scanCanonicalize (H12AffineFastState.compose env39054 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound39054 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,10280,1024,32769,4161,62588,16,21762,8192,65,64604,5392,17665,35189,1365,32,256,21792,46092,63069]

theorem envBound39055 : H12AffineFastState.Bounded env39055 := by
  intro p hp
  have h : env39055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39054_39055 : H12AffineEnvironment.transform 15 54359 env39054 = env39055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env39054 == env39055) = true)

theorem identity39055 : scanCanonicalize (H12AffineFastState.compose env39055 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound39055 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1024,29789,4161,32,16,21762,8192,65,2048,5392,17665,32041,1365,32,256,21792,16464,513]

theorem envBound39056 : H12AffineFastState.Bounded env39056 := by
  intro p hp
  have h : env39056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39055_39056 : H12AffineEnvironment.transform 14 29788 env39055 = env39056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39055 == env39056) = true)

theorem identity39056 : scanCanonicalize (H12AffineFastState.compose env39056 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39056 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39057 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8203,24860,10280,1024,29708,4112,32,16,21762,8192,16,2048,5392,17665,32041,1284,32,256,21792,16385,513]

theorem envBound39057 : H12AffineFastState.Bounded env39057 := by
  intro p hp
  have h : env39057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39056_39057 : H12AffineEnvironment.transform 5 17 env39056 = env39057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39056 == env39057) = true)

theorem identity39057 : scanCanonicalize (H12AffineFastState.compose env39057 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39057 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39058 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21761,263,16400,2340,1024,21760,4112,32,16,21762,268,16,2048,5392,17665,23589,1284,32,256,21792,16385,513]

theorem envBound39058 : H12AffineFastState.Bounded env39058 := by
  intro p hp
  have h : env39058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39057_39058 : H12AffineEnvironment.transform 12 268 env39057 = env39058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39057 == env39058) = true)

theorem identity39058 : scanCanonicalize (H12AffineFastState.compose env39058 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39058 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39059 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1024,1,4112,32,16,3,268,16,2048,5392,4096,2340,1284,32,256,33,5376,513]

theorem envBound39059 : H12AffineFastState.Bounded env39059 := by
  intro p hp
  have h : env39059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39058_39059 : H12AffineEnvironment.transform 13 5377 env39058 = env39059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39058 == env39059) = true)

theorem identity39059 : scanCanonicalize (H12AffineFastState.compose env39059 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39059 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39060 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,268,4372,0,263,4356,2340,21,1,4112,32,16,3,268,16,2048,4357,4096,2340,273,32,256,33,4373,513]

theorem envBound39060 : H12AffineFastState.Bounded env39060 := by
  intro p hp
  have h : env39060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39059_39060 : H12AffineEnvironment.transform 9 21 env39059 = env39060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39059 == env39060) = true)

theorem identity39060 : scanCanonicalize (H12AffineFastState.compose env39060 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound39060 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39061 : List Nat := [2,4,8,16,32,17,8,256,512,21,815,4096,268,4372,0,263,4356,523,21,1,4112,32,16,3,268,16,815,4357,4096,523,273,32,256,33,4373,513]

theorem envBound39061 : H12AffineFastState.Bounded env39061 := by
  intro p hp
  have h : env39061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39060_39061 : H12AffineEnvironment.transform 10 815 env39060 = env39061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env39060 == env39061) = true)

theorem identity39061 : scanCanonicalize (H12AffineFastState.compose env39061 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound39061 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39062 : List Nat := [2,4,8,16,32,17,8,256,293,21,10,4096,268,4372,0,263,4356,302,21,1,4112,32,16,3,268,16,10,4357,4096,302,273,32,256,33,4373,292]

theorem envBound39062 : H12AffineFastState.Bounded env39062 := by
  intro p hp
  have h : env39062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39061_39062 : H12AffineEnvironment.transform 8 293 env39061 = env39062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env39061 == env39062) = true)

theorem identity39062 : scanCanonicalize (H12AffineFastState.compose env39062 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound39062 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39063 : List Nat := [2,4,8,16,32,17,8,256,293,21,10,292,268,48,0,263,32,302,21,1,308,32,16,3,268,16,10,33,292,302,273,32,256,33,49,292]

theorem envBound39063 : H12AffineFastState.Bounded env39063 := by
  intro p hp
  have h : env39063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39062_39063 : H12AffineEnvironment.transform 11 292 env39062 = env39063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env39062 == env39063) = true)

theorem identity39063 : scanCanonicalize (H12AffineFastState.compose env39063 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39063 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39064 : List Nat := [2,4,8,16,0,17,8,256,261,21,10,260,268,16,0,263,0,270,21,1,276,0,16,3,268,16,10,1,260,270,273,0,256,1,17,260]

theorem envBound39064 : H12AffineFastState.Bounded env39064 := by
  intro p hp
  have h : env39064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39063_39064 : H12AffineEnvironment.transform 4 0 env39063 = env39064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39063 == env39064) = true)

theorem identity39064 : scanCanonicalize (H12AffineFastState.compose env39064 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39064 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39065 : List Nat := [2,4,8,7,0,6,8,256,261,2,10,260,268,7,0,263,0,270,2,1,259,0,7,3,268,7,10,1,260,270,262,0,256,1,6,260]

theorem envBound39065 : H12AffineFastState.Bounded env39065 := by
  intro p hp
  have h : env39065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39064_39065 : H12AffineEnvironment.transform 3 7 env39064 = env39065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39064 == env39065) = true)

def env39066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,16,21762,8193,65,215366,115014,17665,35189,119042,243003,256,98678,90203,63068]

theorem envBound39066 : H12AffineFastState.Bounded env39066 := by
  intro p hp
  have h : env39066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39052_39066 : H12AffineEnvironment.transform 6 9 env39052 = env39066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39052 == env39066) = true)

theorem identity39066 : scanCanonicalize (H12AffineFastState.compose env39066 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound39066 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21792,16,21762,8193,65,100695,115014,17665,35189,119042,95530,256,98678,90203,63068]

theorem envBound39067 : H12AffineFastState.Bounded env39067 := by
  intro p hp
  have h : env39067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39066_39067 : H12AffineEnvironment.transform 16 49169 env39066 = env39067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env39066 == env39067) = true)

theorem identity39067 : scanCanonicalize (H12AffineFastState.compose env39067 (packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound39067 : packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env39068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41342,49169,35188,1024,32769,4161,21792,16,21762,8193,65,10281,24632,17665,35189,28796,54356,256,8200,49445,63068]

theorem envBound39068 : H12AffineFastState.Bounded env39068 := by
  intro p hp
  have h : env39068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39067_39068 : H12AffineEnvironment.transform 15 41342 env39067 = env39068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env39067 == env39068) = true)

theorem identity39068 : scanCanonicalize (H12AffineFastState.compose env39068 (packedSelected [2,6,9,11,14,16,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound39068 : packedSelected [2,6,9,11,14,16,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env39069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,41342,46392,35188,1024,32769,4161,8201,16,8235,8193,65,10281,5393,12328,35189,1365,41341,256,8200,46092,33653]

theorem envBound39069 : H12AffineFastState.Bounded env39069 := by
  intro p hp
  have h : env39069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39068_39069 : H12AffineEnvironment.transform 13 13609 env39068 = env39069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env39068 == env39069) = true)

theorem identity39069 : scanCanonicalize (H12AffineFastState.compose env39069 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39069 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env39070 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,32768,40971,46157,34817,1024,32769,4161,8201,16,8235,8193,65,10281,5220,12328,34816,1056,40968,117,8200,46092,33280]

theorem envBound39070 : H12AffineFastState.Bounded env39070 := by
  intro p hp
  have h : env39070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39069_39070 : H12AffineEnvironment.transform 7 117 env39069 = env39070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39069 == env39070) = true)

theorem identity39070 : scanCanonicalize (H12AffineFastState.compose env39070 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39070 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39071 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,32768,32802,37988,34817,1024,32769,4161,32,16,2,40,65,2048,5220,4097,34816,1056,32801,117,33,37925,33280]

theorem envBound39071 : H12AffineFastState.Bounded env39071 := by
  intro p hp
  have h : env39071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39070_39071 : H12AffineEnvironment.transform 12 41 env39070 = env39071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39070 == env39071) = true)

theorem identity39071 : scanCanonicalize (H12AffineFastState.compose env39071 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound39071 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env39072 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,2049,2083,7269,0,1024,2048,4161,32,16,2,40,65,2048,5220,4097,1,1056,2080,117,33,7204,2561]

theorem envBound39072 : H12AffineFastState.Bounded env39072 := by
  intro p hp
  have h : env39072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39071_39072 : H12AffineEnvironment.transform 14 2049 env39071 = env39072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env39071 == env39072) = true)

theorem identity39072 : scanCanonicalize (H12AffineFastState.compose env39072 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound39072 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39073 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,41,81,2049,2083,2113,0,1024,2048,1125,32,16,2,40,65,2048,64,1061,1,1056,2080,117,33,2048,2561]

theorem envBound39073 : H12AffineFastState.Bounded env39073 := by
  intro p hp
  have h : env39073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39072_39073 : H12AffineEnvironment.transform 11 1060 env39072 = env39073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env39072 == env39073) = true)

theorem identity39073 : scanCanonicalize (H12AffineFastState.compose env39073 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39073 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env39074 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,1060,41,81,0,34,64,0,1024,1,1125,32,16,2,40,65,1,64,1061,1,1056,33,117,33,1,512]

theorem envBound39074 : H12AffineFastState.Bounded env39074 := by
  intro p hp
  have h : env39074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39073_39074 : H12AffineEnvironment.transform 10 1 env39073 = env39074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39073 == env39074) = true)

theorem identity39074 : scanCanonicalize (H12AffineFastState.compose env39074 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 591) := by decide +kernel

theorem selectedBound39074 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39075 : List Nat := [2,4,8,16,32,64,9,117,512,591,1,619,41,81,0,34,64,0,591,1,554,32,16,2,40,65,1,64,618,1,623,33,117,33,1,512]

theorem envBound39075 : H12AffineFastState.Bounded env39075 := by
  intro p hp
  have h : env39075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39074_39075 : H12AffineEnvironment.transform 9 591 env39074 = env39075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 591 env39074 == env39075) = true)

theorem identity39075 : scanCanonicalize (H12AffineFastState.compose env39075 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 119) := by decide +kernel

theorem selectedBound39075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39076 : List Nat := [2,4,8,16,32,64,9,117,119,56,1,28,41,81,0,34,64,0,56,1,93,32,16,2,40,65,1,64,29,1,24,33,117,33,1,119]

theorem envBound39076 : H12AffineFastState.Bounded env39076 := by
  intro p hp
  have h : env39076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39075_39076 : H12AffineEnvironment.transform 8 119 env39075 = env39076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 119 env39075 == env39076) = true)

def env39077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound39077 : H12AffineFastState.Bounded env39077 := by
  intro p hp
  have h : env39077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38814_39077 : H12AffineEnvironment.transform 18 1025 env38814 = env39077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env38814 == env39077) = true)

theorem identity39077 : scanCanonicalize (H12AffineFastState.compose env39077 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485415) := by decide +kernel

theorem selectedBound39077 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485415,16777216,8328,65,23211174,18973837,375287,2305190,19163319,23160256,257,17049610,17090991,19222369]

theorem envBound39078 : H12AffineFastState.Bounded env39078 := by
  intro p hp
  have h : env39078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39077_39078 : H12AffineEnvironment.transform 22 2485415 env39077 = env39078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485415 env39077 == env39078) = true)

def env39079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485415,16777216,8328,65,16959642,18973837,375287,2305190,19163319,16876028,257,17049610,17090991,19222369]

theorem envBound39079 : H12AffineFastState.Bounded env39079 := by
  intro p hp
  have h : env39079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39078_39079 : H12AffineEnvironment.transform 21 2155580 env39078 = env39079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env39078 == env39079) = true)

def env39080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,16777216,8192,65,16959506,18973701,375167,2305070,19163199,16875892,257,17049610,17090855,19222369]

theorem envBound39080 : H12AffineFastState.Bounded env39080 := by
  intro p hp
  have h : env39080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39079_39080 : H12AffineEnvironment.transform 6 8 env39079 = env39080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39079 == env39080) = true)

def env39081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,16777216,8192,65,16959506,18973701,102743,2305070,18890775,16875892,257,16777250,16834831,18966345]

theorem envBound39081 : H12AffineFastState.Bounded env39081 := by
  intro p hp
  have h : env39081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39080_39081 : H12AffineEnvironment.transform 17 10280 env39080 = env39081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39080 == env39081) = true)

theorem identity39081 : scanCanonicalize (H12AffineFastState.compose env39081 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound39081 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,91466,98678,41293,16777216,8192,65,16959506,16834895,102743,149860,16852317,16875892,257,16777250,16834831,16777731]

theorem envBound39082 : H12AffineFastState.Bounded env39082 := by
  intro p hp
  have h : env39082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39081_39082 : H12AffineEnvironment.transform 20 91466 env39081 = env39082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env39081 == env39082) = true)

theorem identity39082 : scanCanonicalize (H12AffineFastState.compose env39082 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39082 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env39083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,91466,73770,17,16777216,8192,65,16935246,16793619,77835,149860,16852317,16850984,257,16777250,16793683,16777731]

theorem envBound39083 : H12AffineFastState.Bounded env39083 := by
  intro p hp
  have h : env39083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39082_39083 : H12AffineEnvironment.transform 14 8540 env39082 = env39083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39082 == env39083) = true)

theorem identity39083 : scanCanonicalize (H12AffineFastState.compose env39083 (packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound39083 : packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1025,8541,91466,73770,17,16777216,8192,65,16845140,16793619,77835,76158,16852317,16850984,257,16777250,16793683,16777731]

theorem envBound39084 : H12AffineFastState.Bounded env39084 := by
  intro p hp
  have h : env39084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39083_39084 : H12AffineEnvironment.transform 16 90138 env39083 = env39084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env39083 == env39084) = true)

theorem identity39084 : scanCanonicalize (H12AffineFastState.compose env39084 (packedSelected [0,3,4,5,7,10,17,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound39084 : packedSelected [0,3,4,5,7,10,17,22] rootPS < 2^1333 := by decide +kernel

def env39085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24908,10280,1025,8541,25628,8572,17,16777216,8192,65,16779266,16793619,12637,10280,16786443,16785790,257,16777250,16793683,16777731]

theorem envBound39085 : H12AffineFastState.Bounded env39085 := by
  intro p hp
  have h : env39085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39084_39085 : H12AffineEnvironment.transform 15 342 env39084 = env39085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env39084 == env39085) = true)

theorem identity39085 : scanCanonicalize (H12AffineFastState.compose env39085 (packedSelected [16,20] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound39085 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24908,10280,1025,8541,25628,8572,17,2,8192,65,2048,16401,12637,10280,9225,8572,257,32,16465,513]

theorem envBound39086 : H12AffineFastState.Bounded env39086 := by
  intro p hp
  have h : env39086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39085_39086 : H12AffineEnvironment.transform 23 2 env39085 = env39086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env39085 == env39086) = true)

theorem identity39086 : scanCanonicalize (H12AffineFastState.compose env39086 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39086 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env39087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8540,8540,342,16,10280,1025,8541,1344,8572,17,2,8192,65,2048,8525,12637,10280,9225,8572,257,32,8461,513]

theorem envBound39087 : H12AffineFastState.Bounded env39087 := by
  intro p hp
  have h : env39087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39086_39087 : H12AffineEnvironment.transform 13 8540 env39086 = env39087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8540 env39086 == env39087) = true)

theorem identity39087 : scanCanonicalize (H12AffineFastState.compose env39087 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound39087 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,2341,2341,342,16,81,1025,2340,1344,2309,17,2,2169,65,2048,2356,6436,81,3184,2309,257,32,2420,513]

theorem envBound39088 : H12AffineFastState.Bounded env39088 := by
  intro p hp
  have h : env39088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39087_39088 : H12AffineEnvironment.transform 12 2169 env39087 = env39088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env39087 == env39088) = true)

theorem identity39088 : scanCanonicalize (H12AffineFastState.compose env39088 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound39088 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,2169,2341,2341,342,16,81,1025,2340,1344,2309,17,2,2169,65,2048,2356,2356,81,3184,2309,257,32,2420,513]

theorem envBound39089 : H12AffineFastState.Bounded env39089 := by
  intro p hp
  have h : env39089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39088_39089 : H12AffineEnvironment.transform 11 16 env39088 = env39089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env39088 == env39089) = true)

theorem identity39089 : scanCanonicalize (H12AffineFastState.compose env39089 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound39089 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,16,1100,1296,1296,342,16,81,1025,1297,1344,1328,17,2,1100,65,1077,1281,1281,81,69,1328,257,32,1345,513]

theorem envBound39090 : H12AffineFastState.Bounded env39090 := by
  intro p hp
  have h : env39090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39089_39090 : H12AffineEnvironment.transform 10 1077 env39089 = env39090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env39089 == env39090) = true)

theorem identity39090 : scanCanonicalize (H12AffineFastState.compose env39090 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound39090 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39091 : List Nat := [2,4,8,16,32,64,8,256,512,100,81,16,40,372,372,342,16,81,101,373,292,340,17,2,40,65,81,357,357,81,69,340,257,32,293,513]

theorem envBound39091 : H12AffineFastState.Bounded env39091 := by
  intro p hp
  have h : env39091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39090_39091 : H12AffineEnvironment.transform 9 100 env39090 = env39091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env39090 == env39091) = true)

theorem identity39091 : scanCanonicalize (H12AffineFastState.compose env39091 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39091 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39092 : List Nat := [2,4,8,16,32,64,8,68,512,100,81,16,40,48,48,18,16,81,101,49,96,16,17,2,40,65,81,33,33,81,69,16,69,32,97,513]

theorem envBound39092 : H12AffineFastState.Bounded env39092 := by
  intro p hp
  have h : env39092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39091_39092 : H12AffineEnvironment.transform 7 68 env39091 = env39092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39091 == env39092) = true)

theorem identity39092 : scanCanonicalize (H12AffineFastState.compose env39092 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound39092 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39093 : List Nat := [2,4,8,16,32,48,8,52,512,20,33,16,40,48,48,18,16,33,21,49,16,16,17,2,40,49,33,33,33,33,53,16,53,32,17,513]

theorem envBound39093 : H12AffineFastState.Bounded env39093 := by
  intro p hp
  have h : env39093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39092_39093 : H12AffineEnvironment.transform 5 48 env39092 = env39093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env39092 == env39093) = true)

def env39094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,16777216,8192,65,16959506,18973701,102742,2305070,18890774,16875892,257,16777251,16834830,18966344]

theorem envBound39094 : H12AffineFastState.Bounded env39094 := by
  intro p hp
  have h : env39094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39080_39094 : H12AffineEnvironment.transform 17 10281 env39080 = env39094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39080 == env39094) = true)

theorem identity39094 : scanCanonicalize (H12AffineFastState.compose env39094 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39094 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,2114912,2188634,16777216,8192,65,16935246,18949465,77834,2305070,18890774,16850984,257,16777251,16793682,18966344]

theorem envBound39095 : H12AffineFastState.Bounded env39095 := by
  intro p hp
  have h : env39095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39094_39095 : H12AffineEnvironment.transform 14 8540 env39094 = env39095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39094 == env39095) = true)

theorem identity39095 : scanCanonicalize (H12AffineFastState.compose env39095 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2303321) := by decide +kernel

theorem selectedBound39095 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env39096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,2097152,2114912,2188634,2303321,8192,65,2182167,131072,77834,2305070,222543,2229617,257,2303354,2319627,147985]

theorem envBound39096 : H12AffineFastState.Bounded env39096 := by
  intro p hp
  have h : env39096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39095_39096 : H12AffineEnvironment.transform 23 2303321 env39095 = env39096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2303321 env39095 == env39096) = true)

theorem identity39096 : scanCanonicalize (H12AffineFastState.compose env39096 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39096 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,10281,1025,8541,2097152,2114912,2114896,2229587,8192,65,2124829,131072,4096,2231332,148805,2229617,257,2229616,2245889,147985]

theorem envBound39097 : H12AffineFastState.Bounded env39097 := by
  intro p hp
  have h : env39097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39096_39097 : H12AffineEnvironment.transform 15 8202 env39096 = env39097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39096 == env39097) = true)

theorem identity39097 : scanCanonicalize (H12AffineFastState.compose env39097 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39097 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env39098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,10281,1025,8541,5456,20528,20480,135171,8192,65,31053,131072,4096,137588,148805,135201,257,135200,151633,147985]

theorem envBound39098 : H12AffineFastState.Bounded env39098 := by
  intro p hp
  have h : env39098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39097_39098 : H12AffineEnvironment.transform 20 5456 env39097 = env39098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env39097 == env39098) = true)

theorem identity39098 : scanCanonicalize (H12AffineFastState.compose env39098 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound39098 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env39099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8540,8202,131072,10281,1025,8541,5456,8572,8524,135171,8192,65,2049,131072,4096,137588,144393,135201,257,135200,139549,144221]

theorem envBound39099 : H12AffineFastState.Bounded env39099 := by
  intro p hp
  have h : env39099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39098_39099 : H12AffineEnvironment.transform 13 12620 env39098 = env39099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env39098 == env39099) = true)

theorem identity39099 : scanCanonicalize (H12AffineFastState.compose env39099 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound39099 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env39100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8540,8202,13673,10281,1025,8541,5456,8572,8524,9578,8192,65,2049,13673,4096,11293,352,9544,257,9545,5236,1588]

theorem envBound39100 : H12AffineFastState.Bounded env39100 := by
  intro p hp
  have h : env39100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39099_39100 : H12AffineEnvironment.transform 16 13673 env39099 = env39100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env39099 == env39100) = true)

theorem identity39100 : scanCanonicalize (H12AffineFastState.compose env39100 (packedSelected [2,3,4,5,6,9,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39100 : packedSelected [2,3,4,5,6,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env39101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1,343,5172,2420,1025,0,5456,33,17,1079,349,65,2049,5172,4096,3392,352,1045,257,1044,5236,1588]

theorem envBound39101 : H12AffineFastState.Bounded env39101 := by
  intro p hp
  have h : env39101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39100_39101 : H12AffineEnvironment.transform 12 349 env39100 = env39101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39100 == env39101) = true)

theorem identity39101 : scanCanonicalize (H12AffineFastState.compose env39101 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39101 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39102 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,4113,1,114,5172,2129,1025,0,5237,33,17,1079,120,65,2049,5172,4096,3173,69,1045,36,1044,5236,1588]

theorem envBound39102 : H12AffineFastState.Bounded env39102 := by
  intro p hp
  have h : env39102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39101_39102 : H12AffineEnvironment.transform 7 37 env39101 = env39102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39101 == env39102) = true)

theorem identity39102 : scanCanonicalize (H12AffineFastState.compose env39102 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound39102 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env39103 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,4096,120,4113,1,114,4176,2129,101,0,4113,33,17,83,120,65,2049,4176,4096,2049,69,113,36,112,4112,592]

theorem envBound39103 : H12AffineFastState.Bounded env39103 := by
  intro p hp
  have h : env39103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39102_39103 : H12AffineEnvironment.transform 9 100 env39102 = env39103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env39102 == env39103) = true)

theorem identity39103 : scanCanonicalize (H12AffineFastState.compose env39103 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound39103 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39104 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,2112,120,2129,1,114,2064,2129,101,0,2129,33,17,83,120,65,2049,2064,2112,2049,69,113,36,112,2128,592]

theorem envBound39104 : H12AffineFastState.Bounded env39104 := by
  intro p hp
  have h : env39104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39103_39104 : H12AffineEnvironment.transform 11 2112 env39103 = env39104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env39103 == env39104) = true)

def env39105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,16777216,8193,65,16959507,18973700,375166,2305071,19163198,16875893,257,17049610,17090854,19222369]

theorem envBound39105 : H12AffineFastState.Bounded env39105 := by
  intro p hp
  have h : env39105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39079_39105 : H12AffineEnvironment.transform 6 9 env39079 = env39105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39079 == env39105) = true)

theorem identity39105 : scanCanonicalize (H12AffineFastState.compose env39105 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound39105 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env39106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329731,17,16777216,8193,65,16959507,17066043,375166,442384,16876545,16875893,257,17049610,17090854,16819038]

theorem envBound39106 : H12AffineFastState.Bounded env39106 := by
  intro p hp
  have h : env39106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39105_39106 : H12AffineEnvironment.transform 20 388159 env39105 = env39106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env39105 == env39106) = true)

def env39107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388159,329731,17,16777216,8193,65,16812035,17066043,375166,294912,16876545,16875893,257,17049610,17090854,16819038]

theorem envBound39107 : H12AffineFastState.Bounded env39107 := by
  intro p hp
  have h : env39107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39106_39107 : H12AffineEnvironment.transform 16 16400 env39106 = env39107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39106 == env39107) = true)

theorem identity39107 : scanCanonicalize (H12AffineFastState.compose env39107 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound39107 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388159,329731,17,41311,8193,65,10588,313700,375166,294912,75102,73770,257,297301,288889,513]

theorem envBound39108 : H12AffineFastState.Bounded env39108 := by
  intro p hp
  have h : env39108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39107_39108 : H12AffineEnvironment.transform 23 41311 env39107 = env39108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env39107 == env39108) = true)

theorem identity39108 : scanCanonicalize (H12AffineFastState.compose env39108 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound39108 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env39109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,76158,1025,32769,50497,8573,17,41311,8193,65,10588,122906,36864,108926,75102,73770,257,106539,82183,513]

theorem envBound39109 : H12AffineFastState.Bounded env39109 := by
  intro p hp
  have h : env39109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39108_39109 : H12AffineEnvironment.transform 17 76158 env39108 = env39109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env39108 == env39109) = true)

theorem identity39109 : scanCanonicalize (H12AffineFastState.compose env39109 (packedSelected [2,6,7,14,17,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound39109 : packedSelected [2,6,7,14,17,20,27] rootPS < 2^1333 := by decide +kernel

def env39110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16400,43048,1025,32769,50497,8573,17,41311,8193,65,10588,24908,36864,10280,41992,41340,257,8573,49233,513]

theorem envBound39110 : H12AffineFastState.Bounded env39110 := by
  intro p hp
  have h : env39110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39109_39110 : H12AffineEnvironment.transform 15 33110 env39109 = env39110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env39109 == env39110) = true)

theorem identity39110 : scanCanonicalize (H12AffineFastState.compose env39110 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39110 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env39111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,342,16400,10280,1025,1,17729,8573,17,8543,8193,65,10588,24908,4096,10280,9224,8572,257,8573,16465,513]

theorem envBound39111 : H12AffineFastState.Bounded env39111 := by
  intro p hp
  have h : env39111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39110_39111 : H12AffineEnvironment.transform 14 0 env39110 = env39111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39110 == env39111) = true)

theorem identity39111 : scanCanonicalize (H12AffineFastState.compose env39111 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39111 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16400,2420,1025,1,17729,33,17,3,349,65,2048,16400,4096,2420,1364,32,257,33,16465,513]

theorem envBound39112 : H12AffineFastState.Bounded env39112 := by
  intro p hp
  have h : env39112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39111_39112 : H12AffineEnvironment.transform 12 348 env39111 = env39112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39111 == env39112) = true)

theorem identity39112 : scanCanonicalize (H12AffineFastState.compose env39112 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39112 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5393,2420,1025,1,4160,33,17,3,349,65,2048,5393,4096,2420,1364,32,257,33,5456,513]

theorem envBound39113 : H12AffineFastState.Bounded env39113 := by
  intro p hp
  have h : env39113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39112_39113 : H12AffineEnvironment.transform 13 5377 env39112 = env39113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39112 == env39113) = true)

theorem identity39113 : scanCanonicalize (H12AffineFastState.compose env39113 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39113 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39114 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1025,1,4113,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5377,513]

theorem envBound39114 : H12AffineFastState.Bounded env39114 := by
  intro p hp
  have h : env39114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39113_39114 : H12AffineEnvironment.transform 5 17 env39113 = env39114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39113 == env39114) = true)

theorem identity39114 : scanCanonicalize (H12AffineFastState.compose env39114 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39115 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4113,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound39115 : H12AffineFastState.Bounded env39115 := by
  intro p hp
  have h : env39115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39114_39115 : H12AffineEnvironment.transform 7 36 env39114 = env39115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39114 == env39115) = true)

def env39116 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,0,35,1029,2049,1025,1,33,33,17,3,40,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound39116 : H12AffineFastState.Bounded env39116 := by
  intro p hp
  have h : env39116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39115_39116 : H12AffineEnvironment.transform 11 48 env39115 = env39116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39115 == env39116) = true)

theorem identity39116 : scanCanonicalize (H12AffineFastState.compose env39116 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39116 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39117 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1045,0,3,1029,2049,1025,1,1,1,17,3,8,16,2048,1029,16,2049,1025,0,5,1,1045,513]

theorem envBound39117 : H12AffineFastState.Bounded env39117 := by
  intro p hp
  have h : env39117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39116_39117 : H12AffineEnvironment.transform 4 0 env39116 = env39117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39116 == env39117) = true)

def env39118 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,1,0,3,17,2049,21,1,1,1,17,3,8,16,2048,17,16,2049,21,0,5,1,1,513]

theorem envBound39118 : H12AffineFastState.Bounded env39118 := by
  intro p hp
  have h : env39118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39117_39118 : H12AffineEnvironment.transform 9 20 env39117 = env39118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env39117 == env39118) = true)

theorem identity39118 : scanCanonicalize (H12AffineFastState.compose env39118 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound39118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39119 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,16,9,1,0,3,17,523,21,1,1,1,17,3,8,16,522,17,16,523,21,0,5,1,1,513]

theorem envBound39119 : H12AffineFastState.Bounded env39119 := by
  intro p hp
  have h : env39119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39118_39119 : H12AffineEnvironment.transform 10 522 env39118 = env39119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env39118 == env39119) = true)

def leafEnv39119 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,16,9,1,0,3,17,523,21,1,1,1,17,3,20,8,1,16,522,17,16,523,21,0,5,1,5,2,1,513,1,1,0]

def active39119 : List Nat := [0,1,2,3,8]

def tree39119 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39119 : H12WitnessSearch.Good tree39119 := H12GlobalWitnessIndex.good

theorem leafIdentity39119 : H12AffineFastState.composeSystem env39119 rootObs = leafEnv39119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39119 rootObs == leafEnv39119) = true)

theorem terminalChecked39119 : H12PackedTerminal.terminalCheckFast leafEnv39119 active39119 tree39119 = true := by decide +kernel

def env39120 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,9,0,0,3,16,2049,20,1,1,1,17,3,8,16,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound39120 : H12AffineFastState.Bounded env39120 := by
  intro p hp
  have h : env39120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39117_39120 : H12AffineEnvironment.transform 9 21 env39117 = env39120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39117 == env39120) = true)

theorem identity39120 : scanCanonicalize (H12AffineFastState.compose env39120 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39121 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,0,0,3,16,1,20,1,1,1,17,3,8,16,0,16,16,1,20,0,5,1,0,513]

theorem envBound39121 : H12AffineFastState.Bounded env39121 := by
  intro p hp
  have h : env39121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39120_39121 : H12AffineEnvironment.transform 10 0 env39120 = env39121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39120 == env39121) = true)

def leafEnv39121 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,0,0,3,16,1,20,1,1,1,17,3,21,8,1,16,0,16,16,1,20,0,5,1,5,2,0,513,1,1,0]

def active39121 : List Nat := [0,1,2,3,8]

def tree39121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39121 : H12WitnessSearch.Good tree39121 := H12GlobalWitnessIndex.good

theorem leafIdentity39121 : H12AffineFastState.composeSystem env39121 rootObs = leafEnv39121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39121 rootObs == leafEnv39121) = true)

theorem terminalChecked39121 : H12PackedTerminal.terminalCheckFast leafEnv39121 active39121 tree39121 = true := by decide +kernel

def env39122 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,0,35,1028,2049,1025,1,32,33,17,3,40,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound39122 : H12AffineFastState.Bounded env39122 := by
  intro p hp
  have h : env39122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39115_39122 : H12AffineEnvironment.transform 11 49 env39115 = env39122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39115 == env39122) = true)

theorem identity39122 : scanCanonicalize (H12AffineFastState.compose env39122 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39123 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,49,41,1,0,35,17,2049,20,1,32,33,17,3,40,16,2048,17,49,2049,52,32,37,33,1,513]

theorem envBound39123 : H12AffineFastState.Bounded env39123 := by
  intro p hp
  have h : env39123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39122_39123 : H12AffineEnvironment.transform 9 21 env39122 = env39123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39122 == env39123) = true)

def env39124 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,1,0,3,17,2049,20,1,0,1,17,3,8,16,2048,17,17,2049,20,0,5,1,1,513]

theorem envBound39124 : H12AffineFastState.Bounded env39124 := by
  intro p hp
  have h : env39124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39123_39124 : H12AffineEnvironment.transform 4 0 env39123 = env39124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39123 == env39124) = true)

theorem identity39124 : scanCanonicalize (H12AffineFastState.compose env39124 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39125 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,1,0,3,17,0,20,1,0,1,17,3,8,16,1,17,17,0,20,0,5,1,1,513]

theorem envBound39125 : H12AffineFastState.Bounded env39125 := by
  intro p hp
  have h : env39125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39124_39125 : H12AffineEnvironment.transform 10 1 env39124 = env39125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39124 == env39125) = true)

def leafEnv39125 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,1,0,3,17,0,20,1,0,1,17,3,21,8,1,16,1,17,17,0,20,0,5,1,5,2,1,513,1,0,0]

def active39125 : List Nat := [0,1,2,3,8]

def tree39125 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39125 : H12WitnessSearch.Good tree39125 := H12GlobalWitnessIndex.good

theorem leafIdentity39125 : H12AffineFastState.composeSystem env39125 rootObs = leafEnv39125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39125 rootObs == leafEnv39125) = true)

theorem terminalChecked39125 : H12PackedTerminal.terminalCheckFast leafEnv39125 active39125 tree39125 = true := by decide +kernel

def env39126 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,0,2,17,2049,20,1,1,0,17,3,9,16,2048,17,16,2049,21,1,4,0,1,513]

theorem envBound39126 : H12AffineFastState.Bounded env39126 := by
  intro p hp
  have h : env39126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39123_39126 : H12AffineEnvironment.transform 4 1 env39123 = env39126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39123 == env39126) = true)

theorem identity39126 : scanCanonicalize (H12AffineFastState.compose env39126 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound39126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39127 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,16,8,1,0,2,17,522,20,1,1,0,17,3,9,16,523,17,16,522,21,1,4,0,1,513]

theorem envBound39127 : H12AffineFastState.Bounded env39127 := by
  intro p hp
  have h : env39127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39126_39127 : H12AffineEnvironment.transform 10 523 env39126 = env39127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env39126 == env39127) = true)

def leafEnv39127 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,16,8,1,0,2,17,522,20,1,1,0,17,3,20,9,1,16,523,17,16,522,21,1,4,0,5,3,1,513,1,1,0]

def active39127 : List Nat := [0,1,2,3,8]

def tree39127 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39127 : H12WitnessSearch.Good tree39127 := H12GlobalWitnessIndex.good

theorem leafIdentity39127 : H12AffineFastState.composeSystem env39127 rootObs = leafEnv39127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39127 rootObs == leafEnv39127) = true)

theorem terminalChecked39127 : H12PackedTerminal.terminalCheckFast leafEnv39127 active39127 tree39127 = true := by decide +kernel

def env39128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329731,17,16777216,8193,65,16812034,17066043,375166,294913,16876545,16875893,257,17049610,17090854,16819038]

theorem envBound39128 : H12AffineFastState.Bounded env39128 := by
  intro p hp
  have h : env39128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39106_39128 : H12AffineEnvironment.transform 16 16401 env39106 = env39128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39106 == env39128) = true)

def env39129 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329731,17,16777216,8193,65,16812034,17066043,374794,294913,16876545,16875521,117,17049610,17090642,16818730]

theorem envBound39129 : H12AffineFastState.Bounded env39129 := by
  intro p hp
  have h : env39129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39128_39129 : H12AffineEnvironment.transform 7 116 env39128 = env39129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39128 == env39129) = true)

theorem identity39129 : scanCanonicalize (H12AffineFastState.compose env39129 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound39129 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39130 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329731,17,41003,8193,65,10281,313360,374794,294913,74794,73770,117,296993,288889,513]

theorem envBound39130 : H12AffineFastState.Bounded env39130 := by
  intro p hp
  have h : env39130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39129_39130 : H12AffineEnvironment.transform 23 41003 env39129 = env39130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env39129 == env39130) = true)

theorem identity39130 : scanCanonicalize (H12AffineFastState.compose env39130 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39130 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env39131 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115735,73771,17,41003,8193,65,10281,57400,102434,43049,74794,73770,117,40969,16465,513]

theorem envBound39131 : H12AffineFastState.Bounded env39131 := by
  intro p hp
  have h : env39131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39130_39131 : H12AffineEnvironment.transform 17 10280 env39130 = env39131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39130 == env39131) = true)

theorem identity39131 : scanCanonicalize (H12AffineFastState.compose env39131 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39131 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39132 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,1,65536,16401,10280,1025,0,82966,73771,17,8234,8193,65,10281,24633,69667,10280,74794,73770,117,8200,16465,513]

theorem envBound39132 : H12AffineFastState.Bounded env39132 := by
  intro p hp
  have h : env39132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39131_39132 : H12AffineEnvironment.transform 14 1 env39131 = env39132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39131 == env39132) = true)

def env39133 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329731,17,16777216,8193,65,16812034,17066043,374795,294913,16876545,16875520,116,17049610,17090643,16818731]

theorem envBound39133 : H12AffineFastState.Bounded env39133 := by
  intro p hp
  have h : env39133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39128_39133 : H12AffineEnvironment.transform 7 117 env39128 = env39133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39128 == env39133) = true)

def env39134 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388127,329731,17,16777216,8193,65,16812034,17066011,374795,294913,16876545,16875520,84,17049610,17090643,16818699]

theorem envBound39134 : H12AffineFastState.Bounded env39134 := by
  intro p hp
  have h : env39134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39133_39134 : H12AffineEnvironment.transform 4 0 env39133 = env39134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39133 == env39134) = true)

theorem identity39134 : scanCanonicalize (H12AffineFastState.compose env39134 (packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound39134 : packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env39135 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,16384,32768,40970,16401,262144,1025,32769,281621,305161,17,16777216,8193,65,16812034,17066011,268289,294913,16786443,16785418,84,17049610,17090643,16818699]

theorem envBound39135 : H12AffineFastState.Bounded env39135 := by
  intro p hp
  have h : env39135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39134_39135 : H12AffineEnvironment.transform 15 40970 env39134 = env39135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env39134 == env39135) = true)

def env39136 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388126,329731,17,16777216,8193,65,16812034,17066010,374795,294913,16876545,16875520,85,17049610,17090643,16818698]

theorem envBound39136 : H12AffineFastState.Bounded env39136 := by
  intro p hp
  have h : env39136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39133_39136 : H12AffineEnvironment.transform 4 1 env39133 = env39136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39133 == env39136) = true)

theorem identity39136 : scanCanonicalize (H12AffineFastState.compose env39136 (packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 65537) := by decide +kernel

theorem selectedBound39136 : packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env39137 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388126,329731,17,65537,8193,65,100355,354331,374795,294913,33792,32769,85,337931,378962,107019]

theorem envBound39137 : H12AffineFastState.Bounded env39137 := by
  intro p hp
  have h : env39137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39136_39137 : H12AffineEnvironment.transform 23 65537 env39136 = env39137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env39136 == env39137) = true)

theorem identity39137 : scanCanonicalize (H12AffineFastState.compose env39137 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10248) := by decide +kernel

theorem selectedBound39137 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39138 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,10248,1025,32769,115734,73739,17,65537,8193,65,100355,81939,102403,43017,33792,32769,85,65539,122970,107019]

theorem envBound39138 : H12AffineFastState.Bounded env39138 := by
  intro p hp
  have h : env39138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39137_39138 : H12AffineEnvironment.transform 17 10248 env39137 = env39138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10248 env39137 == env39138) = true)

theorem identity39138 : scanCanonicalize (H12AffineFastState.compose env39138 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39138 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env39139 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,1,65536,16401,10248,1025,0,82967,73739,17,65537,8193,65,67586,81939,69634,10248,1025,0,85,65539,90203,74250]

theorem envBound39139 : H12AffineFastState.Bounded env39139 := by
  intro p hp
  have h : env39139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39138_39139 : H12AffineEnvironment.transform 14 1 env39138 = env39139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39138 == env39139) = true)

theorem identity39139 : scanCanonicalize (H12AffineFastState.compose env39139 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound39139 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env39140 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,12312,1,65536,12297,10248,1025,0,78863,73739,17,65537,8193,65,67586,77835,69634,10248,1025,0,85,65539,69699,74250]

theorem envBound39140 : H12AffineFastState.Bounded env39140 := by
  intro p hp
  have h : env39140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39139_39140 : H12AffineEnvironment.transform 13 12312 env39139 = env39140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env39139 == env39140) = true)

theorem identity39140 : scanCanonicalize (H12AffineFastState.compose env39140 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound39140 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env39141 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,12312,1,2,12297,10248,1025,0,13325,8201,17,3,8193,65,2048,12297,4096,10248,1025,0,85,1,4161,8712]

theorem envBound39141 : H12AffineFastState.Bounded env39141 := by
  intro p hp
  have h : env39141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39140_39141 : H12AffineEnvironment.transform 15 2 env39140 = env39141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env39140 == env39141) = true)

theorem identity39141 : scanCanonicalize (H12AffineFastState.compose env39141 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound39141 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39142 : List Nat := [2,4,8,16,1,64,9,84,512,68,2048,4096,8192,12312,1,2,12297,10248,69,0,12361,8201,17,3,8193,65,2048,12297,4096,10248,69,0,85,1,4161,8712]

theorem envBound39142 : H12AffineFastState.Bounded env39142 := by
  intro p hp
  have h : env39142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39141_39142 : H12AffineEnvironment.transform 9 68 env39141 = env39142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env39141 == env39142) = true)

theorem identity39142 : scanCanonicalize (H12AffineFastState.compose env39142 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound39142 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env39143 : List Nat := [2,4,8,16,1,64,9,84,81,68,2048,4096,8192,12312,1,2,12297,10248,69,0,12361,8201,17,3,8193,65,2048,12297,4096,10248,69,0,85,1,4161,8281]

theorem envBound39143 : H12AffineFastState.Bounded env39143 := by
  intro p hp
  have h : env39143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39142_39143 : H12AffineEnvironment.transform 8 81 env39142 = env39143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env39142 == env39143) = true)

theorem identity39143 : scanCanonicalize (H12AffineFastState.compose env39143 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39143 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39144 : List Nat := [2,4,8,16,1,16,9,4,1,20,2048,4096,8192,12312,1,2,12297,10248,21,0,12313,8201,17,3,8193,17,2048,12297,4096,10248,21,0,5,1,4113,8201]

theorem envBound39144 : H12AffineFastState.Bounded env39144 := by
  intro p hp
  have h : env39144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39143_39144 : H12AffineEnvironment.transform 5 16 env39143 = env39144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39143 == env39144) = true)

theorem identity39144 : scanCanonicalize (H12AffineFastState.compose env39144 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound39144 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39145 : List Nat := [2,4,8,16,1,16,9,4,1,20,2048,4096,8,4112,1,2,4097,2048,21,0,4113,1,17,3,9,17,2048,4097,4096,2048,21,0,5,1,4113,1]

theorem envBound39145 : H12AffineFastState.Bounded env39145 := by
  intro p hp
  have h : env39145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39144_39145 : H12AffineEnvironment.transform 12 8 env39144 = env39145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env39144 == env39145) = true)

theorem identity39145 : scanCanonicalize (H12AffineFastState.compose env39145 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound39145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39146 : List Nat := [2,4,8,16,1,16,9,4,1,20,2048,2065,8,2049,1,2,2064,2048,21,0,2048,1,17,3,9,17,2048,2064,2065,2048,21,0,5,1,2048,1]

theorem envBound39146 : H12AffineFastState.Bounded env39146 := by
  intro p hp
  have h : env39146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39145_39146 : H12AffineEnvironment.transform 11 2065 env39145 = env39146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env39145 == env39146) = true)

theorem identity39146 : scanCanonicalize (H12AffineFastState.compose env39146 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound39146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39147 : List Nat := [2,4,8,16,1,16,9,4,1,20,30,15,8,31,1,2,14,30,21,0,30,1,17,3,9,17,30,14,15,30,21,0,5,1,30,1]

theorem envBound39147 : H12AffineFastState.Bounded env39147 := by
  intro p hp
  have h : env39147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39146_39147 : H12AffineEnvironment.transform 10 30 env39146 = env39147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env39146 == env39147) = true)

def leafEnv39147 : List Nat := [2,4,8,16,1,16,9,4,1,20,30,15,8,31,1,2,14,30,21,0,30,1,17,3,20,9,1,17,30,14,15,30,21,0,5,1,5,3,30,1,1,31,0]

def active39147 : List Nat := [0,1,2,3]

def tree39147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39147 : H12WitnessSearch.Good tree39147 := H12GlobalWitnessIndex.good

theorem leafIdentity39147 : H12AffineFastState.composeSystem env39147 rootObs = leafEnv39147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39147 rootObs == leafEnv39147) = true)

theorem terminalChecked39147 : H12PackedTerminal.terminalCheckFast leafEnv39147 active39147 tree39147 = true := by decide +kernel

def env39148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485415,16777216,8328,65,16959643,18973837,375287,2305190,19163319,16876029,257,17049610,17090991,19222369]

theorem envBound39148 : H12AffineFastState.Bounded env39148 := by
  intro p hp
  have h : env39148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39078_39148 : H12AffineEnvironment.transform 21 2155581 env39078 = env39148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env39078 == env39148) = true)

def env39149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,16777216,8192,65,16959507,18973701,375167,2305070,19163199,16875893,257,17049610,17090855,19222369]

theorem envBound39149 : H12AffineFastState.Bounded env39149 := by
  intro p hp
  have h : env39149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39148_39149 : H12AffineEnvironment.transform 6 8 env39148 = env39149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39148 == env39149) = true)

theorem identity39149 : scanCanonicalize (H12AffineFastState.compose env39149 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound39149 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env39150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,16,16777216,8192,65,16959507,17066042,375167,442385,16876544,16875893,257,17049610,17090855,16819038]

theorem envBound39150 : H12AffineFastState.Bounded env39150 := by
  intro p hp
  have h : env39150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39149_39150 : H12AffineEnvironment.transform 20 388159 env39149 = env39150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env39149 == env39150) = true)

theorem identity39150 : scanCanonicalize (H12AffineFastState.compose env39150 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound39150 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,91466,98679,16,16777216,8192,65,16959507,16834895,77834,149860,16876544,16875893,257,16818559,16793682,16819038]

theorem envBound39151 : H12AffineFastState.Bounded env39151 := by
  intro p hp
  have h : env39151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39150_39151 : H12AffineEnvironment.transform 17 35189 env39150 = env39151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env39150 == env39151) = true)

theorem identity39151 : scanCanonicalize (H12AffineFastState.compose env39151 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 246085) := by decide +kernel

theorem selectedBound39151 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,91466,98679,16,246085,8192,65,67926,204810,77834,149860,148805,147504,257,221242,229655,221723]

theorem envBound39152 : H12AffineFastState.Bounded env39152 := by
  intro p hp
  have h : env39152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39151_39152 : H12AffineEnvironment.transform 23 246085 env39151 = env39152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 246085 env39151 == env39152) = true)

theorem identity39152 : scanCanonicalize (H12AffineFastState.compose env39152 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound39152 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env39153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1025,32769,91466,98679,16,73736,8192,65,67926,115015,77834,43049,41992,41341,257,98679,90202,99158]

theorem envBound39153 : H12AffineFastState.Bounded env39153 := by
  intro p hp
  have h : env39153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39152_39153 : H12AffineEnvironment.transform 16 57677 env39152 = env39153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env39152 == env39153) = true)

theorem identity39153 : scanCanonicalize (H12AffineFastState.compose env39153 (packedSelected [6,7,9,14,17,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound39153 : packedSelected [6,7,9,14,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env39154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,46392,35189,1025,32769,78143,98679,16,73736,8192,65,67926,103730,77834,43049,41992,41341,257,98679,78895,99158]

theorem envBound39154 : H12AffineFastState.Bounded env39154 := by
  intro p hp
  have h : env39154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39153_39154 : H12AffineEnvironment.transform 13 5237 env39153 = env39154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env39153 == env39154) = true)

theorem identity39154 : scanCanonicalize (H12AffineFastState.compose env39154 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39154 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env39155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,33111,46392,35189,1025,32769,45160,32,16,41311,8192,65,34817,5221,45405,43049,41992,41341,257,32,46456,513]

theorem envBound39155 : H12AffineFastState.Bounded env39155 := by
  intro p hp
  have h : env39155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39154_39155 : H12AffineEnvironment.transform 15 33111 env39154 = env39155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39154 == env39155) = true)

theorem identity39155 : scanCanonicalize (H12AffineFastState.compose env39155 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound39155 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,81,262,13673,2340,1025,80,12345,32,16,8462,8192,65,2128,5221,12556,10360,9305,8492,257,32,13609,513]

theorem envBound39156 : H12AffineFastState.Bounded env39156 := by
  intro p hp
  have h : env39156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39155_39156 : H12AffineEnvironment.transform 14 81 env39155 = env39156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env39155 == env39156) = true)

theorem identity39156 : scanCanonicalize (H12AffineFastState.compose env39156 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,81,262,5220,2340,1025,80,4404,32,16,3,269,65,2128,5221,4097,2421,1364,33,257,32,5156,513]

theorem envBound39157 : H12AffineFastState.Bounded env39157 := by
  intro p hp
  have h : env39157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39156_39157 : H12AffineEnvironment.transform 12 269 env39156 = env39157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39156 == env39157) = true)

theorem identity39157 : scanCanonicalize (H12AffineFastState.compose env39157 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound39157 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39158 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4405,81,262,4388,2340,321,80,4404,32,16,3,269,65,2128,4389,4097,2421,20,33,257,32,4452,513]

theorem envBound39158 : H12AffineFastState.Bounded env39158 := by
  intro p hp
  have h : env39158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39157_39158 : H12AffineEnvironment.transform 9 320 env39157 = env39158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39157 == env39158) = true)

theorem identity39158 : scanCanonicalize (H12AffineFastState.compose env39158 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound39158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39159 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,65,269,372,81,262,357,2340,321,80,373,32,16,3,269,65,2128,356,64,2421,20,33,257,32,293,513]

theorem envBound39159 : H12AffineFastState.Bounded env39159 := by
  intro p hp
  have h : env39159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39158_39159 : H12AffineEnvironment.transform 11 65 env39158 = env39159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env39158 == env39159) = true)

theorem identity39159 : scanCanonicalize (H12AffineFastState.compose env39159 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39159 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39160 : List Nat := [2,4,8,16,32,64,8,256,512,320,0,65,269,372,81,262,357,292,321,80,373,32,16,3,269,65,80,356,64,373,20,33,257,32,293,513]

theorem envBound39160 : H12AffineFastState.Bounded env39160 := by
  intro p hp
  have h : env39160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39159_39160 : H12AffineEnvironment.transform 10 0 env39159 = env39160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39159 == env39160) = true)

theorem identity39160 : scanCanonicalize (H12AffineFastState.compose env39160 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39160 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env39161 : List Nat := [2,4,8,16,32,64,8,117,512,53,0,65,120,1,81,115,16,81,52,80,0,32,16,3,120,65,80,17,64,0,20,33,116,32,80,513]

theorem envBound39161 : H12AffineFastState.Bounded env39161 := by
  intro p hp
  have h : env39161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39160_39161 : H12AffineEnvironment.transform 7 117 env39160 = env39161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39160 == env39161) = true)

def env39162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,16777216,8193,65,16959506,18973700,375166,2305071,19163198,16875892,257,17049610,17090854,19222369]

theorem envBound39162 : H12AffineFastState.Bounded env39162 := by
  intro p hp
  have h : env39162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39148_39162 : H12AffineEnvironment.transform 6 9 env39148 = env39162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39148 == env39162) = true)

def env39163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,16777216,8193,65,16959506,18973700,102742,2305071,18890774,16875892,257,16777250,16834830,18966345]

theorem envBound39163 : H12AffineFastState.Bounded env39163 := by
  intro p hp
  have h : env39163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39162_39163 : H12AffineEnvironment.transform 17 10280 env39162 = env39163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39162 == env39163) = true)

def env39164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62589,119878,16777216,8193,65,16959506,16880708,102742,212079,16797782,16875892,257,16777250,16834830,16873225]

theorem envBound39164 : H12AffineFastState.Bounded env39164 := by
  intro p hp
  have h : env39164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39163_39164 : H12AffineEnvironment.transform 20 4160 env39163 = env39164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39163 == env39164) = true)

def env39165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62589,119878,95496,8193,65,245018,57676,102742,212079,75102,62588,257,95530,103430,513]

theorem envBound39165 : H12AffineFastState.Bounded env39165 := by
  intro p hp
  have h : env39165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39164_39165 : H12AffineEnvironment.transform 23 95496 env39164 = env39165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env39164 == env39165) = true)

theorem identity39165 : scanCanonicalize (H12AffineFastState.compose env39165 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39165 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env39166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1025,8540,4160,21792,95515,95496,8193,65,203847,16401,77835,212079,75102,21793,257,95530,79195,513]

theorem envBound39166 : H12AffineFastState.Bounded env39166 := by
  intro p hp
  have h : env39166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39165_39166 : H12AffineEnvironment.transform 14 8541 env39165 = env39166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39165 == env39166) = true)

theorem identity39166 : scanCanonicalize (H12AffineFastState.compose env39166 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39166 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,65536,131072,10280,1025,8540,4160,112,73803,73816,8193,65,203847,5441,77835,212079,75102,113,257,73850,79195,513]

theorem envBound39167 : H12AffineFastState.Bounded env39167 := by
  intro p hp
  have h : env39167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39166_39167 : H12AffineEnvironment.transform 13 5456 env39166 = env39167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env39166 == env39167) = true)

theorem identity39167 : scanCanonicalize (H12AffineFastState.compose env39167 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39167 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env39168 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,65536,131072,10280,1025,8461,4113,33,73754,73737,8193,16,203798,5392,77835,212030,75023,32,257,73771,79114,513]

theorem envBound39168 : H12AffineFastState.Bounded env39168 := by
  intro p hp
  have h : env39168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39167_39168 : H12AffineEnvironment.transform 5 17 env39167 = env39168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39167 == env39168) = true)

theorem identity39168 : scanCanonicalize (H12AffineFastState.compose env39168 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound39168 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39169 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,65536,70679,10280,1025,8461,4113,33,73754,73737,8193,16,2049,5392,77835,10281,75023,32,257,73771,79114,513]

theorem envBound39169 : H12AffineFastState.Bounded env39169 := by
  intro p hp
  have h : env39169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39168_39169 : H12AffineEnvironment.transform 16 70679 env39168 = env39169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env39168 == env39169) = true)

theorem identity39169 : scanCanonicalize (H12AffineFastState.compose env39169 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39169 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39170 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10280,1025,8461,4113,33,17,2,8193,16,2049,5392,4096,10281,1284,32,257,32,5377,513]

theorem envBound39170 : H12AffineFastState.Bounded env39170 := by
  intro p hp
  have h : env39170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39169_39170 : H12AffineEnvironment.transform 15 8203 env39169 = env39170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39169 == env39170) = true)

def env39171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62589,119878,95497,8193,65,245019,57677,102742,212079,75103,62589,257,95531,103431,512]

theorem envBound39171 : H12AffineFastState.Bounded env39171 := by
  intro p hp
  have h : env39171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39164_39171 : H12AffineEnvironment.transform 23 95497 env39164 = env39171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env39164 == env39171) = true)

theorem identity39171 : scanCanonicalize (H12AffineFastState.compose env39171 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39171 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1025,32769,4160,62589,41292,3,8193,65,182289,57677,58460,149861,20565,62589,257,33,57613,512]

theorem envBound39172 : H12AffineFastState.Bounded env39172 := by
  intro p hp
  have h : env39172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39171_39172 : H12AffineEnvironment.transform 15 29962 env39171 = env39172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39171 == env39172) = true)

theorem identity39172 : scanCanonicalize (H12AffineFastState.compose env39172 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58381) := by decide +kernel

theorem selectedBound39172 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env39173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,58381,10280,1025,32769,4160,62589,41292,3,8193,65,11292,57677,58460,44392,20565,62589,257,33,57613,512]

theorem envBound39173 : H12AffineFastState.Bounded env39173 := by
  intro p hp
  have h : env39173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39172_39173 : H12AffineEnvironment.transform 16 58381 env39172 = env39173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58381 env39172 == env39173) = true)

theorem identity39173 : scanCanonicalize (H12AffineFastState.compose env39173 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22804) := by decide +kernel

theorem selectedBound39173 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env39174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,22804,29962,15641,10280,1025,22805,4160,11625,30808,3,8193,65,11292,14425,15688,29820,20565,11625,257,33,14361,512]

theorem envBound39174 : H12AffineFastState.Bounded env39174 := by
  intro p hp
  have h : env39174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39173_39174 : H12AffineEnvironment.transform 14 22804 env39173 = env39174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22804 env39173 == env39174) = true)

theorem identity39174 : scanCanonicalize (H12AffineFastState.compose env39174 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound39174 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env39175 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,22804,28747,14424,10280,320,22805,4160,10280,30808,3,8193,65,10589,14425,14345,28989,20565,10280,257,33,14361,512]

theorem envBound39175 : H12AffineFastState.Bounded env39175 := by
  intro p hp
  have h : env39175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39174_39175 : H12AffineEnvironment.transform 9 321 env39174 = env39175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39174 == env39175) = true)

theorem identity39175 : scanCanonicalize (H12AffineFastState.compose env39175 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound39175 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env39176 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,8192,16384,18693,24666,10313,10280,320,18692,81,10280,26697,3,8193,65,10589,10312,10264,24876,16452,10280,257,33,10248,512]

theorem envBound39176 : H12AffineFastState.Bounded env39176 := by
  intro p hp
  have h : env39176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39175_39176 : H12AffineEnvironment.transform 11 17 env39175 = env39176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env39175 == env39176) = true)

theorem identity39176 : scanCanonicalize (H12AffineFastState.compose env39176 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 10328) := by decide +kernel

theorem selectedBound39176 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39177 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,8192,10328,8541,2050,10313,10280,320,8540,81,10280,17,3,8193,65,10589,10312,10264,2420,10268,10280,257,33,10248,512]

theorem envBound39177 : H12AffineFastState.Bounded env39177 := by
  intro p hp
  have h : env39177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39176_39177 : H12AffineEnvironment.transform 13 10328 env39176 = env39177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10328 env39176 == env39177) = true)

theorem identity39177 : scanCanonicalize (H12AffineFastState.compose env39177 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound39177 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39178 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,2057,81,2388,2050,64,33,320,2389,81,33,17,3,2056,65,340,65,17,2420,21,33,257,33,1,512]

theorem envBound39178 : H12AffineFastState.Bounded env39178 := by
  intro p hp
  have h : env39178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39177_39178 : H12AffineEnvironment.transform 12 2057 env39177 = env39178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env39177 == env39178) = true)

theorem identity39178 : scanCanonicalize (H12AffineFastState.compose env39178 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound39178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39179 : List Nat := [2,4,8,16,32,64,9,256,512,321,32,17,41,81,372,34,64,33,320,373,81,33,17,3,40,65,340,65,17,340,21,33,257,33,1,512]

theorem envBound39179 : H12AffineFastState.Bounded env39179 := by
  intro p hp
  have h : env39179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39178_39179 : H12AffineEnvironment.transform 10 32 env39178 = env39179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env39178 == env39179) = true)

theorem identity39179 : scanCanonicalize (H12AffineFastState.compose env39179 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound39179 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39180 : List Nat := [2,4,8,16,32,64,9,256,90,321,32,17,41,81,372,34,64,33,320,373,81,33,17,3,40,65,340,65,17,340,21,33,257,33,1,90]

theorem envBound39180 : H12AffineFastState.Bounded env39180 := by
  intro p hp
  have h : env39180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39179_39180 : H12AffineEnvironment.transform 8 90 env39179 = env39180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env39179 == env39180) = true)

theorem identity39180 : scanCanonicalize (H12AffineFastState.compose env39180 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39180 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39181 : List Nat := [2,4,8,16,1,64,9,256,90,321,1,17,8,81,341,3,64,0,320,340,81,0,17,3,9,65,340,65,17,340,21,0,257,0,1,90]

theorem envBound39181 : H12AffineFastState.Bounded env39181 := by
  intro p hp
  have h : env39181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39180_39181 : H12AffineEnvironment.transform 4 1 env39180 = env39181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39180 == env39181) = true)

theorem identity39181 : scanCanonicalize (H12AffineFastState.compose env39181 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound39181 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39182 : List Nat := [2,4,8,16,1,64,9,15,90,78,1,17,8,81,90,3,64,0,79,91,81,0,17,3,9,65,91,65,17,91,21,0,14,0,1,90]

theorem envBound39182 : H12AffineFastState.Bounded env39182 := by
  intro p hp
  have h : env39182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39181_39182 : H12AffineEnvironment.transform 7 15 env39181 = env39182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env39181 == env39182) = true)

theorem identity39182 : scanCanonicalize (H12AffineFastState.compose env39182 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39182 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39183 : List Nat := [2,4,8,16,1,0,9,15,26,14,1,17,8,17,26,3,0,0,15,27,17,0,17,3,9,1,27,1,17,27,21,0,14,0,1,26]

theorem envBound39183 : H12AffineFastState.Bounded env39183 := by
  intro p hp
  have h : env39183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39182_39183 : H12AffineEnvironment.transform 5 0 env39182 = env39183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39182 == env39183) = true)

theorem identity39183 : scanCanonicalize (H12AffineFastState.compose env39183 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound39183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39184 : List Nat := [2,4,8,13,1,0,9,15,7,14,1,12,8,12,7,3,0,0,15,6,12,0,12,3,9,1,6,1,12,6,8,0,14,0,1,7]

theorem envBound39184 : H12AffineFastState.Bounded env39184 := by
  intro p hp
  have h : env39184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39183_39184 : H12AffineEnvironment.transform 3 13 env39183 = env39184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env39183 == env39184) = true)

theorem identity39184 : scanCanonicalize (H12AffineFastState.compose env39184 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39185 : List Nat := [2,4,5,0,1,0,4,2,7,3,1,1,5,1,7,3,0,0,2,6,1,0,1,3,4,1,6,1,1,6,5,0,3,0,1,7]

theorem envBound39185 : H12AffineFastState.Bounded env39185 := by
  intro p hp
  have h : env39185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39184_39185 : H12AffineEnvironment.transform 2 5 env39184 = env39185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39184 == env39185) = true)

theorem identity39185 : scanCanonicalize (H12AffineFastState.compose env39185 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39186 : List Nat := [0,4,5,0,1,0,4,0,5,1,1,1,5,1,5,1,0,0,0,4,1,0,1,1,4,1,4,1,1,4,5,0,1,0,1,5]

theorem envBound39186 : H12AffineFastState.Bounded env39186 := by
  intro p hp
  have h : env39186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39185_39186 : H12AffineEnvironment.transform 0 0 env39185 = env39186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39185 == env39186) = true)

theorem identity39186 : scanCanonicalize (H12AffineFastState.compose env39186 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39186 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env39187 : List Nat := [0,0,1,0,1,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,1,0,1,1,0,1,0,1,1,0,1,0,1,0,1,1]

theorem envBound39187 : H12AffineFastState.Bounded env39187 := by
  intro p hp
  have h : env39187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39186_39187 : H12AffineEnvironment.transform 1 0 env39186 = env39187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39186 == env39187) = true)

def env39188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62588,119879,16777216,8193,65,16959506,16880709,102742,212078,16797783,16875892,257,16777250,16834830,16873224]

theorem envBound39188 : H12AffineFastState.Bounded env39188 := by
  intro p hp
  have h : env39188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39163_39188 : H12AffineEnvironment.transform 20 4161 env39163 = env39188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39163 == env39188) = true)

theorem identity39188 : scanCanonicalize (H12AffineFastState.compose env39188 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound39188 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62588,119879,95497,8193,65,245019,57676,102742,212078,75102,62589,257,95531,103431,513]

theorem envBound39189 : H12AffineFastState.Bounded env39189 := by
  intro p hp
  have h : env39189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39188_39189 : H12AffineEnvironment.transform 23 95497 env39188 = env39189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env39188 == env39189) = true)

theorem identity39189 : scanCanonicalize (H12AffineFastState.compose env39189 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39189 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env39190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1025,8540,4161,21793,95514,95497,8193,65,203846,16401,77835,212078,75102,21792,257,95531,79194,513]

theorem envBound39190 : H12AffineFastState.Bounded env39190 := by
  intro p hp
  have h : env39190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39189_39190 : H12AffineEnvironment.transform 14 8541 env39189 = env39190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39189 == env39190) = true)

theorem identity39190 : scanCanonicalize (H12AffineFastState.compose env39190 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound39190 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,65536,131072,10280,1025,8540,4161,112,73803,73816,8193,65,203846,5440,77835,212078,75102,113,257,73850,79194,513]

theorem envBound39191 : H12AffineFastState.Bounded env39191 := by
  intro p hp
  have h : env39191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39190_39191 : H12AffineEnvironment.transform 13 5457 env39190 = env39191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env39190 == env39191) = true)

theorem identity39191 : scanCanonicalize (H12AffineFastState.compose env39191 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39191 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env39192 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,65536,131072,10280,1025,8461,4112,33,73754,73737,8193,16,203799,5393,77835,212031,75023,32,257,73771,79115,513]

theorem envBound39192 : H12AffineFastState.Bounded env39192 := by
  intro p hp
  have h : env39192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39191_39192 : H12AffineEnvironment.transform 5 17 env39191 = env39192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39191 == env39192) = true)

theorem identity39192 : scanCanonicalize (H12AffineFastState.compose env39192 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound39192 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39193 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,65536,70678,10280,1025,8461,4112,33,73754,73737,8193,16,2049,5393,77835,10281,75023,32,257,73771,79115,513]

theorem envBound39193 : H12AffineFastState.Bounded env39193 := by
  intro p hp
  have h : env39193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39192_39193 : H12AffineEnvironment.transform 16 70678 env39192 = env39193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env39192 == env39193) = true)

theorem identity39193 : scanCanonicalize (H12AffineFastState.compose env39193 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39193 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39194 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,13341,10280,1025,8461,4112,33,17,2,8193,16,2049,5393,4096,10281,1284,32,257,32,5376,513]

theorem envBound39194 : H12AffineFastState.Bounded env39194 := by
  intro p hp
  have h : env39194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39193_39194 : H12AffineEnvironment.transform 15 8203 env39193 = env39194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39193 == env39194) = true)

def env39195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,16777216,8193,65,16959506,18973700,102743,2305071,18890775,16875892,257,16777251,16834831,18966344]

theorem envBound39195 : H12AffineFastState.Bounded env39195 := by
  intro p hp
  have h : env39195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39162_39195 : H12AffineEnvironment.transform 17 10281 env39162 = env39195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39162 == env39195) = true)

theorem identity39195 : scanCanonicalize (H12AffineFastState.compose env39195 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound39195 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,73771,17,16777216,8193,65,16959506,16793618,102743,190521,16876545,16875892,257,16777251,16834831,16819038]

theorem envBound39196 : H12AffineFastState.Bounded env39196 := by
  intro p hp
  have h : env39196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39195_39196 : H12AffineEnvironment.transform 20 115734 env39195 = env39196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env39195 == env39196) = true)

theorem identity39196 : scanCanonicalize (H12AffineFastState.compose env39196 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound39196 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115734,73771,17,16777216,8193,65,16885768,16793618,102743,100387,16876545,16875892,257,16777251,16834831,16819038]

theorem envBound39197 : H12AffineFastState.Bounded env39197 := by
  intro p hp
  have h : env39197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39196_39197 : H12AffineEnvironment.transform 16 90138 env39196 = env39197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env39196 == env39197) = true)

theorem identity39197 : scanCanonicalize (H12AffineFastState.compose env39197 (packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound39197 : packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env39198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41343,49509,10281,1025,32769,25961,33108,17,16777216,8193,65,16779639,16793618,12328,10588,16786814,16785419,257,16777251,16834831,16819038]

theorem envBound39198 : H12AffineFastState.Bounded env39198 := by
  intro p hp
  have h : env39198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39197_39198 : H12AffineEnvironment.transform 15 41343 env39197 = env39198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env39197 == env39198) = true)

theorem identity39198 : scanCanonicalize (H12AffineFastState.compose env39198 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound39198 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env39199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,32768,41343,45405,10281,1025,32769,5457,33108,17,16777216,8193,65,16779639,16789546,12328,10588,16786814,16785419,257,16777251,16814391,16819038]

theorem envBound39199 : H12AffineFastState.Bounded env39199 := by
  intro p hp
  have h : env39199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39198_39199 : H12AffineEnvironment.transform 13 12344 env39198 = env39199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env39198 == env39199) = true)

theorem identity39199 : scanCanonicalize (H12AffineFastState.compose env39199 (packedSelected [4,8,9,14,16,17,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 8234) := by decide +kernel

theorem selectedBound39199 : packedSelected [4,8,9,14,16,17,28,31] rootPS < 2^1333 := by decide +kernel

def env39200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,32768,41343,45405,10281,1025,32769,5457,33108,17,8234,8193,65,10589,4096,12328,10588,1364,33,257,8201,45341,33652]

theorem envBound39200 : H12AffineFastState.Bounded env39200 := by
  intro p hp
  have h : env39200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39199_39200 : H12AffineEnvironment.transform 23 8234 env39199 = env39200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8234 env39199 == env39200) = true)

theorem identity39200 : scanCanonicalize (H12AffineFastState.compose env39200 (packedSelected [11,16,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39200 : packedSelected [11,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env39201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,32768,33110,37236,2048,1025,32769,5457,33108,17,3,40,65,2420,4096,4097,2421,1364,33,257,32,37172,33652]

theorem envBound39201 : H12AffineFastState.Bounded env39201 := by
  intro p hp
  have h : env39201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39200_39201 : H12AffineEnvironment.transform 12 41 env39200 = env39201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39200 == env39201) = true)

theorem identity39201 : scanCanonicalize (H12AffineFastState.compose env39201 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39201 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env39202 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,4113,32768,33110,37204,2048,1025,32769,5457,33108,17,3,8,65,2388,4096,4097,2389,1364,1,257,0,37140,33620]

theorem envBound39202 : H12AffineFastState.Bounded env39202 := by
  intro p hp
  have h : env39202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39201_39202 : H12AffineEnvironment.transform 4 0 env39201 = env39202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39201 == env39202) = true)

theorem identity39202 : scanCanonicalize (H12AffineFastState.compose env39202 (packedSelected [2,4,9] rootPS)) = affineNative (2^(14+1) ^^^ 3345) := by decide +kernel

theorem selectedBound39202 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39203 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,4113,3345,3143,7237,2048,1025,3344,5457,3141,17,3,8,65,2388,4096,4097,2389,1364,1,257,0,7173,3653]

theorem envBound39203 : H12AffineFastState.Bounded env39203 := by
  intro p hp
  have h : env39203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39202_39203 : H12AffineEnvironment.transform 14 3345 env39202 = env39203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3345 env39202 == env39203) = true)

theorem identity39203 : scanCanonicalize (H12AffineFastState.compose env39203 (packedSelected [0,1,7,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound39203 : packedSelected [0,1,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39204 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1108,9,1093,3345,3143,2065,2048,1025,3344,261,3141,17,3,8,65,2388,1108,1109,2389,1364,1,257,0,2129,3653]

theorem envBound39204 : H12AffineFastState.Bounded env39204 := by
  intro p hp
  have h : env39204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39203_39204 : H12AffineEnvironment.transform 11 1108 env39203 = env39204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env39203 == env39204) = true)

theorem identity39204 : scanCanonicalize (H12AffineFastState.compose env39204 (packedSelected [6,10] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound39204 : packedSelected [6,10] rootPS < 2^1333 := by decide +kernel

def env39205 : List Nat := [2,4,8,16,0,64,9,256,512,257,2048,341,9,324,2064,2374,2065,2048,256,2065,261,2372,17,3,8,65,2388,341,340,2389,85,1,257,0,2129,2884]

theorem envBound39205 : H12AffineFastState.Bounded env39205 := by
  intro p hp
  have h : env39205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39204_39205 : H12AffineEnvironment.transform 9 257 env39204 = env39205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env39204 == env39205) = true)

theorem identity39205 : scanCanonicalize (H12AffineFastState.compose env39205 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound39205 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env39206 : List Nat := [2,4,8,16,0,64,9,256,512,257,260,341,9,324,276,66,277,260,256,277,261,64,17,3,8,65,80,341,340,81,85,1,257,0,341,576]

theorem envBound39206 : H12AffineFastState.Bounded env39206 := by
  intro p hp
  have h : env39206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39205_39206 : H12AffineEnvironment.transform 10 260 env39205 = env39206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env39205 == env39206) = true)

theorem identity39206 : scanCanonicalize (H12AffineFastState.compose env39206 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39207 : List Nat := [2,4,8,16,0,64,9,68,512,69,64,17,9,0,80,66,81,64,68,81,65,64,17,3,8,65,80,17,16,81,85,1,69,0,17,576]

theorem envBound39207 : H12AffineFastState.Bounded env39207 := by
  intro p hp
  have h : env39207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39206_39207 : H12AffineEnvironment.transform 7 68 env39206 = env39207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39206 == env39207) = true)

theorem identity39207 : scanCanonicalize (H12AffineFastState.compose env39207 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39207 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39208 : List Nat := [2,4,8,16,0,64,9,68,1,69,64,17,9,0,80,66,81,64,68,81,65,64,17,3,8,65,80,17,16,81,85,1,69,0,17,65]

theorem envBound39208 : H12AffineFastState.Bounded env39208 := by
  intro p hp
  have h : env39208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39207_39208 : H12AffineEnvironment.transform 8 1 env39207 = env39208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39207 == env39208) = true)

theorem identity39208 : scanCanonicalize (H12AffineFastState.compose env39208 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39208 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env39209 : List Nat := [2,4,8,16,0,17,9,21,1,20,17,17,9,0,1,19,0,17,21,0,16,17,17,3,8,16,1,17,16,0,4,1,20,0,17,16]

theorem envBound39209 : H12AffineFastState.Bounded env39209 := by
  intro p hp
  have h : env39209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39208_39209 : H12AffineEnvironment.transform 5 17 env39208 = env39209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39208 == env39209) = true)

theorem identity39209 : scanCanonicalize (H12AffineFastState.compose env39209 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39209 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39210 : List Nat := [2,4,8,0,0,1,9,5,1,4,1,1,9,0,1,3,0,1,5,0,0,1,1,3,8,0,1,1,0,0,4,1,4,0,1,0]

theorem envBound39210 : H12AffineFastState.Bounded env39210 := by
  intro p hp
  have h : env39210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39209_39210 : H12AffineEnvironment.transform 3 0 env39209 = env39210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39209 == env39210) = true)

def env39211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound39211 : H12AffineFastState.Bounded env39211 := by
  intro p hp
  have h : env39211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38813_39211 : H12AffineEnvironment.transform 26 30393345 env38813 = env39211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env38813 == env39211) = true)

def env39212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound39212 : H12AffineFastState.Bounded env39212 := by
  intro p hp
  have h : env39212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39211_39212 : H12AffineEnvironment.transform 18 1024 env39211 = env39212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env39211 == env39212) = true)

theorem identity39212 : scanCanonicalize (H12AffineFastState.compose env39212 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound39212 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403622,18973836,10507600,8497638,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound39213 : H12AffineFastState.Bounded env39213 := by
  intro p hp
  have h : env39213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39212_39213 : H12AffineEnvironment.transform 17 223719 env39212 = env39213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env39212 == env39213) = true)

def env39214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760058,5392,10507600,8497638,10491276,4256861,256,8410417,8434836,10564187]

theorem envBound39214 : H12AffineFastState.Bounded env39214 := by
  intro p hp
  have h : env39214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39213_39214 : H12AffineEnvironment.transform 23 2199964 env39213 = env39214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env39213 == env39214) = true)

def env39215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270122,5392,17664,2210230,1500,4256861,256,2114913,2139332,74251]

theorem envBound39215 : H12AffineFastState.Bounded env39215 := by
  intro p hp
  have h : env39215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39214_39215 : H12AffineEnvironment.transform 22 2101328 env39214 = env39215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env39214 == env39215) = true)

def env39216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,16,98780,8328,65,4270122,5392,17664,109046,1500,4256861,256,21793,46212,74251]

theorem envBound39216 : H12AffineFastState.Bounded env39216 := by
  intro p hp
  have h : env39216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39215_39216 : H12AffineEnvironment.transform 20 4160 env39215 = env39216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39215 == env39216) = true)

theorem identity39216 : scanCanonicalize (H12AffineFastState.compose env39216 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound39216 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,223719,1024,29908,4160,4194304,16,95497,8328,65,4270122,5392,17664,89379,1500,4194440,256,21793,16465,74251]

theorem envBound39217 : H12AffineFastState.Bounded env39217 := by
  intro p hp
  have h : env39217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39216_39217 : H12AffineEnvironment.transform 14 29909 env39216 = env39217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39216 == env39217) = true)

def env39218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212199,1024,8660,4160,4194304,16,73737,8328,65,4270122,5392,4096,67619,1500,4194440,256,33,5457,74251]

theorem envBound39218 : H12AffineFastState.Bounded env39218 := by
  intro p hp
  have h : env39218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39217_39218 : H12AffineEnvironment.transform 13 5376 env39217 = env39218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39217 == env39218) = true)

theorem identity39218 : scanCanonicalize (H12AffineFastState.compose env39218 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound39218 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,10401,1024,8660,4160,4194304,16,73737,8328,65,4270122,5392,4096,67619,1500,4194440,256,33,5457,74251]

theorem envBound39219 : H12AffineFastState.Bounded env39219 := by
  intro p hp
  have h : env39219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39218_39219 : H12AffineEnvironment.transform 16 70726 env39218 = env39219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env39218 == env39219) = true)

theorem identity39219 : scanCanonicalize (H12AffineFastState.compose env39219 (packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound39219 : packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env39220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,10401,1024,8660,4160,8492,16,73737,8328,65,67846,5392,4096,67619,1500,8612,256,33,5457,74251]

theorem envBound39220 : H12AffineFastState.Bounded env39220 := by
  intro p hp
  have h : env39220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39219_39220 : H12AffineEnvironment.transform 21 8492 env39219 = env39220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env39219 == env39220) = true)

theorem identity39220 : scanCanonicalize (H12AffineFastState.compose env39220 (packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39220 : packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS < 2^1333 := by decide +kernel

def env39221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,65536,70726,2556,1024,137,4160,113,16,65876,469,65,67846,5392,4096,67619,1500,249,256,33,5457,66390]

theorem envBound39221 : H12AffineFastState.Bounded env39221 := by
  intro p hp
  have h : env39221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39220_39221 : H12AffineEnvironment.transform 12 349 env39220 = env39221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39220 == env39221) = true)

theorem identity39221 : scanCanonicalize (H12AffineFastState.compose env39221 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound39221 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env39222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,478,5528,2556,1024,137,4160,113,16,138,469,65,2264,5392,4096,2557,1500,249,256,33,5457,648]

theorem envBound39222 : H12AffineFastState.Bounded env39222 := by
  intro p hp
  have h : env39222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39221_39222 : H12AffineEnvironment.transform 15 478 env39221 = env39222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env39221 == env39222) = true)

theorem identity39222 : scanCanonicalize (H12AffineFastState.compose env39222 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39222 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39223 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,136,398,5528,2476,1024,137,4112,33,16,138,389,17,2184,5392,4096,2477,1420,169,256,33,5377,648]

theorem envBound39223 : H12AffineFastState.Bounded env39223 := by
  intro p hp
  have h : env39223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39222_39223 : H12AffineEnvironment.transform 5 16 env39222 = env39223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39222 == env39223) = true)

theorem identity39223 : scanCanonicalize (H12AffineFastState.compose env39223 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39223 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39224 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,269,4113,136,398,4233,2476,273,137,4112,33,16,138,389,17,2184,4097,4096,2477,157,169,256,33,4112,648]

theorem envBound39224 : H12AffineFastState.Bounded env39224 := by
  intro p hp
  have h : env39224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39223_39224 : H12AffineEnvironment.transform 9 273 env39223 = env39224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39223 == env39224) = true)

theorem identity39224 : scanCanonicalize (H12AffineFastState.compose env39224 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39224 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39225 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,269,4113,1,263,4096,2341,273,0,4112,33,16,3,268,17,2049,4097,4096,2340,20,32,256,33,4112,513]

theorem envBound39225 : H12AffineFastState.Bounded env39225 := by
  intro p hp
  have h : env39225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39224_39225 : H12AffineEnvironment.transform 6 9 env39224 = env39225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39224 == env39225) = true)

theorem identity39225 : scanCanonicalize (H12AffineFastState.compose env39225 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39226 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,1,34,4096,2048,52,0,4112,33,16,3,41,17,2049,4097,4096,2049,20,32,37,33,4112,513]

theorem envBound39226 : H12AffineFastState.Bounded env39226 := by
  intro p hp
  have h : env39226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39225_39226 : H12AffineEnvironment.transform 7 37 env39225 = env39226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39225 == env39226) = true)

theorem identity39226 : scanCanonicalize (H12AffineFastState.compose env39226 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound39226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39227 : List Nat := [2,4,8,16,5,16,9,0,512,17,2048,4096,13,4113,1,7,4096,2048,17,0,4112,4,16,3,12,17,2049,4097,4096,2049,20,5,0,4,4112,513]

theorem envBound39227 : H12AffineFastState.Bounded env39227 := by
  intro p hp
  have h : env39227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39226_39227 : H12AffineEnvironment.transform 4 5 env39226 = env39227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env39226 == env39227) = true)

theorem identity39227 : scanCanonicalize (H12AffineFastState.compose env39227 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound39227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39228 : List Nat := [2,4,8,16,5,16,9,0,512,17,9,4096,13,4113,1,7,4096,9,17,0,4112,4,16,3,12,17,8,4097,4096,8,20,5,0,4,4112,513]

theorem envBound39228 : H12AffineFastState.Bounded env39228 := by
  intro p hp
  have h : env39228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39227_39228 : H12AffineEnvironment.transform 10 9 env39227 = env39228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env39227 == env39228) = true)

theorem identity39228 : scanCanonicalize (H12AffineFastState.compose env39228 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound39228 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39229 : List Nat := [2,4,8,16,5,16,9,0,3,17,9,4096,13,4113,1,7,4096,9,17,0,4112,4,16,3,12,17,8,4097,4096,8,20,5,0,4,4112,2]

theorem envBound39229 : H12AffineFastState.Bounded env39229 := by
  intro p hp
  have h : env39229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39228_39229 : H12AffineEnvironment.transform 8 3 env39228 = env39229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env39228 == env39229) = true)

theorem identity39229 : scanCanonicalize (H12AffineFastState.compose env39229 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39229 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39230 : List Nat := [2,4,5,16,5,16,4,0,3,17,4,4096,0,4113,1,7,4096,4,17,0,4112,4,16,3,1,17,5,4097,4096,5,20,5,0,4,4112,2]

theorem envBound39230 : H12AffineFastState.Bounded env39230 := by
  intro p hp
  have h : env39230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39229_39230 : H12AffineEnvironment.transform 2 5 env39229 = env39230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39229 == env39230) = true)

theorem identity39230 : scanCanonicalize (H12AffineFastState.compose env39230 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 21) := by decide +kernel

theorem selectedBound39230 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39231 : List Nat := [2,4,5,16,5,16,4,0,3,17,4,21,0,4,1,7,21,4,17,0,5,4,16,3,1,17,5,20,21,5,20,5,0,4,5,2]

theorem envBound39231 : H12AffineFastState.Bounded env39231 := by
  intro p hp
  have h : env39231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39230_39231 : H12AffineEnvironment.transform 11 21 env39230 = env39231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 21 env39230 == env39231) = true)

def env39232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212198,1024,8661,4160,4194304,16,73736,8328,65,4270122,5392,4097,67618,1500,4194440,256,32,5456,74251]

theorem envBound39232 : H12AffineFastState.Bounded env39232 := by
  intro p hp
  have h : env39232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39217_39232 : H12AffineEnvironment.transform 13 5377 env39217 = env39232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39217 == env39232) = true)

theorem identity39232 : scanCanonicalize (H12AffineFastState.compose env39232 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound39232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70862,10280,1024,8661,4160,4194304,16,73736,8328,65,4270122,5392,4097,67618,1500,4194440,256,32,5456,74251]

theorem envBound39233 : H12AffineFastState.Bounded env39233 := by
  intro p hp
  have h : env39233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39232_39233 : H12AffineEnvironment.transform 16 70862 env39232 = env39233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env39232 == env39233) = true)

theorem identity39233 : scanCanonicalize (H12AffineFastState.compose env39233 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound39233 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env39234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,478,5392,10280,1024,8661,4160,4194304,16,8662,8328,65,4205044,5392,4097,2556,1500,4194440,256,32,5456,9173]

theorem envBound39234 : H12AffineFastState.Bounded env39234 := by
  intro p hp
  have h : env39234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39233_39234 : H12AffineEnvironment.transform 15 478 env39233 = env39234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env39233 == env39234) = true)

theorem identity39234 : scanCanonicalize (H12AffineFastState.compose env39234 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound39234 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,478,5392,2556,1024,1,4160,4194304,16,2,348,65,4196384,5392,4097,2556,1500,4194440,256,32,5456,513]

theorem envBound39235 : H12AffineFastState.Bounded env39235 := by
  intro p hp
  have h : env39235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39234_39235 : H12AffineEnvironment.transform 12 468 env39234 = env39235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env39234 == env39235) = true)

theorem identity39235 : scanCanonicalize (H12AffineFastState.compose env39235 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound39235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,478,5392,2556,1024,1,4160,112,16,2,348,65,2128,5392,4097,2556,1500,248,256,32,5456,513]

theorem envBound39236 : H12AffineFastState.Bounded env39236 := by
  intro p hp
  have h : env39236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39235_39236 : H12AffineEnvironment.transform 21 112 env39235 = env39236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env39235 == env39236) = true)

theorem identity39236 : scanCanonicalize (H12AffineFastState.compose env39236 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39236 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env39237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5392,2421,1024,1,4160,112,16,2,348,65,2128,5392,4097,2421,1365,113,256,32,5456,513]

theorem envBound39237 : H12AffineFastState.Bounded env39237 := by
  intro p hp
  have h : env39237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39236_39237 : H12AffineEnvironment.transform 6 9 env39236 = env39237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39236 == env39237) = true)

theorem identity39237 : scanCanonicalize (H12AffineFastState.compose env39237 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39237 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39238 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1024,1,4113,33,16,2,269,16,2049,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound39238 : H12AffineFastState.Bounded env39238 := by
  intro p hp
  have h : env39238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39237_39238 : H12AffineEnvironment.transform 5 17 env39237 = env39238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39237 == env39238) = true)

theorem identity39238 : scanCanonicalize (H12AffineFastState.compose env39238 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound39238 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39239 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2587,268,3866,0,262,3851,2340,1024,1,2570,33,16,2,269,16,2049,3851,2586,2340,1284,32,256,32,3866,513]

theorem envBound39239 : H12AffineFastState.Bounded env39239 := by
  intro p hp
  have h : env39239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39238_39239 : H12AffineEnvironment.transform 11 2587 env39238 = env39239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env39238 == env39239) = true)

theorem identity39239 : scanCanonicalize (H12AffineFastState.compose env39239 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound39239 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39240 : List Nat := [2,4,8,16,32,17,9,256,512,1024,782,277,268,1044,0,262,1029,554,1024,1,260,33,16,2,269,16,783,1029,276,554,1284,32,256,32,1044,513]

theorem envBound39240 : H12AffineFastState.Bounded env39240 := by
  intro p hp
  have h : env39240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39239_39240 : H12AffineEnvironment.transform 10 782 env39239 = env39240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env39239 == env39240) = true)

theorem identity39240 : scanCanonicalize (H12AffineFastState.compose env39240 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound39240 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39241 : List Nat := [2,4,8,16,32,17,9,256,512,542,782,277,268,522,0,262,539,554,542,1,260,33,16,2,269,16,783,539,276,554,794,32,256,32,522,513]

theorem envBound39241 : H12AffineFastState.Bounded env39241 := by
  intro p hp
  have h : env39241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39240_39241 : H12AffineEnvironment.transform 9 542 env39240 = env39241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env39240 == env39241) = true)

def env39242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,17,98781,8328,65,4270122,5392,17664,109047,1500,4256861,256,21792,46213,74251]

theorem envBound39242 : H12AffineFastState.Bounded env39242 := by
  intro p hp
  have h : env39242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39215_39242 : H12AffineEnvironment.transform 20 4161 env39215 = env39242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39215 == env39242) = true)

theorem identity39242 : scanCanonicalize (H12AffineFastState.compose env39242 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound39242 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,156013,17,98781,8328,65,215367,5392,17664,109047,1500,169264,256,21792,46213,74251]

theorem envBound39243 : H12AffineFastState.Bounded env39243 := by
  intro p hp
  have h : env39243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39242_39243 : H12AffineEnvironment.transform 21 156013 env39242 = env39243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env39242 == env39243) = true)

def env39244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,156013,17,98645,8192,65,215367,5392,17664,108927,1364,169264,256,21792,46093,74251]

theorem envBound39244 : H12AffineFastState.Bounded env39244 := by
  intro p hp
  have h : env39244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39243_39244 : H12AffineEnvironment.transform 6 8 env39243 = env39244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39243 == env39244) = true)

theorem identity39244 : scanCanonicalize (H12AffineFastState.compose env39244 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39244 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4161,156013,17,73736,8192,65,215367,5392,17664,67618,1364,144493,256,21792,5456,74251]

theorem envBound39245 : H12AffineFastState.Bounded env39245 := by
  intro p hp
  have h : env39245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39244_39245 : H12AffineEnvironment.transform 14 8541 env39244 = env39245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39244 == env39245) = true)

theorem identity39245 : scanCanonicalize (H12AffineFastState.compose env39245 (packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound39245 : packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,79179,23588,1024,8540,4161,87078,17,73736,8192,65,31756,5392,17664,67618,1364,65830,256,21792,5456,74251]

theorem envBound39246 : H12AffineFastState.Bounded env39246 := by
  intro p hp
  have h : env39246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39245_39246 : H12AffineEnvironment.transform 16 79179 env39245 = env39246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env39245 == env39246) = true)

theorem identity39246 : scanCanonicalize (H12AffineFastState.compose env39246 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound39246 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env39247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30043,16400,23588,1024,8540,4161,8573,17,21843,8192,65,31756,5392,17664,32121,1364,29821,256,21792,5456,22352]

theorem envBound39247 : H12AffineFastState.Bounded env39247 := by
  intro p hp
  have h : env39247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39246_39247 : H12AffineEnvironment.transform 15 30043 env39246 = env39247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env39246 == env39247) = true)

theorem identity39247 : scanCanonicalize (H12AffineFastState.compose env39247 (packedSelected [2,4,6,7,10,11,12,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound39247 : packedSelected [2,4,6,7,10,11,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env39248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,8541,1331,12408,11340,1024,8540,4161,8573,17,9531,8192,65,3172,5392,13672,3345,1364,1045,256,9544,5456,10040]

theorem envBound39248 : H12AffineFastState.Bounded env39248 := by
  intro p hp
  have h : env39248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39247_39248 : H12AffineEnvironment.transform 13 12392 env39247 = env39248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env39247 == env39248) = true)

theorem identity39248 : scanCanonicalize (H12AffineFastState.compose env39248 (packedSelected [2,3,5,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39248 : packedSelected [2,3,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39249 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,12392,8312,1046,12408,11340,1024,8313,4161,8280,17,9246,8192,65,3172,5173,13389,3124,1137,1045,37,9325,5237,9757]

theorem envBound39249 : H12AffineFastState.Bounded env39249 := by
  intro p hp
  have h : env39249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39248_39249 : H12AffineEnvironment.transform 7 37 env39248 = env39249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39248 == env39249) = true)

theorem identity39249 : scanCanonicalize (H12AffineFastState.compose env39249 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound39249 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39250 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,4113,1,1046,4097,3125,1024,0,4161,33,17,1127,121,65,3172,5173,5172,3124,1137,1045,37,1044,5237,1636]

theorem envBound39250 : H12AffineFastState.Bounded env39250 := by
  intro p hp
  have h : env39250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39249_39250 : H12AffineEnvironment.transform 12 121 env39249 = env39250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env39249 == env39250) = true)

theorem identity39250 : scanCanonicalize (H12AffineFastState.compose env39250 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound39250 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env39251 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,2064,121,2049,1,1046,2065,3125,1024,0,2129,33,17,1127,121,65,3172,3109,3108,3124,1137,1045,37,1044,3173,1636]

theorem envBound39251 : H12AffineFastState.Bounded env39251 := by
  intro p hp
  have h : env39251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39250_39251 : H12AffineEnvironment.transform 11 2064 env39250 = env39251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env39250 == env39251) = true)

theorem identity39251 : scanCanonicalize (H12AffineFastState.compose env39251 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39251 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39252 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2064,121,2049,1,34,2065,2049,52,0,2129,33,17,83,121,65,2128,2065,2064,2048,69,33,37,32,2129,592]

theorem envBound39252 : H12AffineFastState.Bounded env39252 := by
  intro p hp
  have h : env39252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39251_39252 : H12AffineEnvironment.transform 9 52 env39251 = env39252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39251 == env39252) = true)

theorem identity39252 : scanCanonicalize (H12AffineFastState.compose env39252 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound39252 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env39253 : List Nat := [2,4,8,16,32,33,8,37,512,52,2048,2064,24,2049,1,34,2065,2049,52,0,2096,33,17,50,24,32,2097,2065,2064,2048,36,33,37,32,2096,561]

theorem envBound39253 : H12AffineFastState.Bounded env39253 := by
  intro p hp
  have h : env39253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39252_39253 : H12AffineEnvironment.transform 5 33 env39252 = env39253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env39252 == env39253) = true)

theorem identity39253 : scanCanonicalize (H12AffineFastState.compose env39253 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39254 : List Nat := [2,4,8,16,17,16,8,20,512,5,2048,2064,24,2049,1,19,2065,2049,5,0,2049,16,17,3,24,17,2048,2065,2064,2048,21,16,20,17,2049,512]

theorem envBound39254 : H12AffineFastState.Bounded env39254 := by
  intro p hp
  have h : env39254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39253_39254 : H12AffineEnvironment.transform 4 17 env39253 = env39254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39253 == env39254) = true)

theorem identity39254 : scanCanonicalize (H12AffineFastState.compose env39254 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound39254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39255 : List Nat := [2,4,8,16,17,16,8,20,512,5,513,529,24,512,1,19,528,512,5,0,512,16,17,3,24,17,513,528,529,513,21,16,20,17,512,512]

theorem envBound39255 : H12AffineFastState.Bounded env39255 := by
  intro p hp
  have h : env39255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39254_39255 : H12AffineEnvironment.transform 10 513 env39254 = env39255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env39254 == env39255) = true)

theorem identity39255 : scanCanonicalize (H12AffineFastState.compose env39255 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound39255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39256 : List Nat := [2,4,8,16,17,16,8,20,5,5,4,20,24,5,1,19,21,5,5,0,5,16,17,3,24,17,4,21,20,4,21,16,20,17,5,5]

theorem envBound39256 : H12AffineFastState.Bounded env39256 := by
  intro p hp
  have h : env39256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39255_39256 : H12AffineEnvironment.transform 8 5 env39255 = env39256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env39255 == env39256) = true)

theorem identity39256 : scanCanonicalize (H12AffineFastState.compose env39256 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39256 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39257 : List Nat := [2,4,8,0,1,0,8,4,5,5,4,4,8,5,1,3,5,5,5,0,5,0,1,3,8,1,4,5,4,4,5,0,4,1,5,5]

theorem envBound39257 : H12AffineFastState.Bounded env39257 := by
  intro p hp
  have h : env39257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39256_39257 : H12AffineEnvironment.transform 3 0 env39256 = env39257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39256 == env39257) = true)

def env39258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,156013,17,98644,8193,65,215367,5392,17664,108926,1365,169264,256,21792,46092,74251]

theorem envBound39258 : H12AffineFastState.Bounded env39258 := by
  intro p hp
  have h : env39258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39243_39258 : H12AffineEnvironment.transform 6 9 env39243 = env39258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39243 == env39258) = true)

theorem identity39258 : scanCanonicalize (H12AffineFastState.compose env39258 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38209) := by decide +kernel

theorem selectedBound39258 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38209,130095,1024,32769,4161,62508,17,98644,8193,65,121862,5392,17664,108926,1365,113,256,21792,46092,74251]

theorem envBound39259 : H12AffineFastState.Bounded env39259 := by
  intro p hp
  have h : env39259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39258_39259 : H12AffineEnvironment.transform 16 38209 env39258 = env39259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38209 env39258 == env39259) = true)

theorem identity39259 : scanCanonicalize (H12AffineFastState.compose env39259 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39259 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env39260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,5440,97326,1024,0,4161,29741,17,65877,8193,65,89095,5392,17664,76159,1365,113,256,21792,13325,74251]

theorem envBound39260 : H12AffineFastState.Bounded env39260 := by
  intro p hp
  have h : env39260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39259_39260 : H12AffineEnvironment.transform 14 1 env39259 = env39260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39259 == env39260) = true)

theorem identity39260 : scanCanonicalize (H12AffineFastState.compose env39260 (packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39260 : packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,65536,5440,89459,1024,0,4161,21872,17,65877,348,65,89095,5392,17664,67618,1365,113,256,21792,5456,66390]

theorem envBound39261 : H12AffineFastState.Bounded env39261 := by
  intro p hp
  have h : env39261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39260_39261 : H12AffineEnvironment.transform 12 349 env39260 = env39261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39260 == env39261) = true)

theorem identity39261 : scanCanonicalize (H12AffineFastState.compose env39261 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39261 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39262 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,1,65536,5173,89094,1024,0,4161,21509,17,65568,41,65,89095,5221,17525,67618,1056,113,117,21589,5157,66083]

theorem envBound39262 : H12AffineFastState.Bounded env39262 := by
  intro p hp
  have h : env39262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39261_39262 : H12AffineEnvironment.transform 7 117 env39261 = env39262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39261 == env39262) = true)

theorem identity39262 : scanCanonicalize (H12AffineFastState.compose env39262 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound39262 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39263 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,1,65536,5173,67619,1024,0,4161,32,17,65568,41,65,67618,5221,4176,67618,1056,113,117,112,5157,66083]

theorem envBound39263 : H12AffineFastState.Bounded env39263 := by
  intro p hp
  have h : env39263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39262_39263 : H12AffineEnvironment.transform 13 5157 env39262 = env39263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env39262 == env39263) = true)

theorem identity39263 : scanCanonicalize (H12AffineFastState.compose env39263 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4195) := by decide +kernel

theorem selectedBound39263 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env39264 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,1,4195,5173,6208,1024,0,4161,32,17,4163,41,65,6209,5221,4176,6209,1056,113,117,112,5157,4672]

theorem envBound39264 : H12AffineFastState.Bounded env39264 := by
  intro p hp
  have h : env39264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39263_39264 : H12AffineEnvironment.transform 15 4195 env39263 = env39264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4195 env39263 == env39264) = true)

theorem identity39264 : scanCanonicalize (H12AffineFastState.compose env39264 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound39264 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env39265 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,40,2048,1,3142,2064,1125,1024,0,3172,32,17,3174,41,65,1124,2112,3189,1124,1056,113,117,112,2048,3685]

theorem envBound39265 : H12AffineFastState.Bounded env39265 := by
  intro p hp
  have h : env39265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39264_39265 : H12AffineEnvironment.transform 11 3109 env39264 = env39265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env39264 == env39265) = true)

theorem identity39265 : scanCanonicalize (H12AffineFastState.compose env39265 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39265 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39266 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,40,2048,1,2083,2064,0,101,0,2049,32,17,2051,41,65,1,2112,2064,1,69,113,117,112,2048,2560]

theorem envBound39266 : H12AffineFastState.Bounded env39266 := by
  intro p hp
  have h : env39266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39265_39266 : H12AffineEnvironment.transform 9 101 env39265 = env39266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39265 == env39266) = true)

theorem identity39266 : scanCanonicalize (H12AffineFastState.compose env39266 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39266 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env39267 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,65,40,1,1,34,17,0,101,0,0,32,17,2,41,65,1,65,17,1,69,113,117,112,1,513]

theorem envBound39267 : H12AffineFastState.Bounded env39267 := by
  intro p hp
  have h : env39267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39266_39267 : H12AffineEnvironment.transform 10 1 env39266 = env39267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39266 == env39267) = true)

def env39268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270123,5392,17665,2210231,1501,4256861,256,2114912,2139333,74250]

theorem envBound39268 : H12AffineFastState.Bounded env39268 := by
  intro p hp
  have h : env39268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39214_39268 : H12AffineEnvironment.transform 22 2101329 env39214 = env39268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env39214 == env39268) = true)

def env39269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,17,98780,8328,65,4270123,5392,17665,109047,1501,4256861,256,21792,46213,74250]

theorem envBound39269 : H12AffineFastState.Bounded env39269 := by
  intro p hp
  have h : env39269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39268_39269 : H12AffineEnvironment.transform 20 4160 env39268 = env39269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39268 == env39269) = true)

theorem identity39269 : scanCanonicalize (H12AffineFastState.compose env39269 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound39269 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,169400,17,98780,8328,65,245139,5392,17665,109047,1501,156133,256,21792,46213,74250]

theorem envBound39270 : H12AffineFastState.Bounded env39270 := by
  intro p hp
  have h : env39270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39269_39270 : H12AffineEnvironment.transform 21 169400 env39269 = env39270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env39269 == env39270) = true)

def env39271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169264,17,98644,8192,65,245019,5392,17665,108927,1365,156013,256,21792,46093,74250]

theorem envBound39271 : H12AffineFastState.Bounded env39271 := by
  intro p hp
  have h : env39271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39270_39271 : H12AffineEnvironment.transform 6 8 env39270 = env39271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39270 == env39271) = true)

theorem identity39271 : scanCanonicalize (H12AffineFastState.compose env39271 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39271 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4160,144493,17,73737,8192,65,203846,5392,17665,67618,1365,156013,256,21792,5456,74250]

theorem envBound39272 : H12AffineFastState.Bounded env39272 := by
  intro p hp
  have h : env39272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39271_39272 : H12AffineEnvironment.transform 14 8541 env39271 = env39272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39271 == env39272) = true)

theorem identity39272 : scanCanonicalize (H12AffineFastState.compose env39272 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound39272 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env39273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8495,131072,149568,1024,8540,4160,144493,17,294,8192,65,146793,5392,17665,10509,1365,156013,256,21792,5456,805]

theorem envBound39273 : H12AffineFastState.Bounded env39273 := by
  intro p hp
  have h : env39273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39272_39273 : H12AffineEnvironment.transform 15 8495 env39272 = env39273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env39272 == env39273) = true)

theorem identity39273 : scanCanonicalize (H12AffineFastState.compose env39273 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound39273 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS < 2^1333 := by decide +kernel

def env39274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8495,16449,2049,1024,8540,4160,29740,17,294,8192,65,32040,5392,17665,10509,1365,8492,256,21792,5456,805]

theorem envBound39274 : H12AffineFastState.Bounded env39274 := by
  intro p hp
  have h : env39274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39273_39274 : H12AffineEnvironment.transform 16 16449 env39273 = env39274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env39273 == env39274) = true)

theorem identity39274 : scanCanonicalize (H12AffineFastState.compose env39274 (packedSelected [2,4,6,11,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39274 : packedSelected [2,4,6,11,20,22,23] rootPS < 2^1333 := by decide +kernel

def env39275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,372,262,16449,2049,1024,373,4160,21509,17,294,41,65,23809,5392,17665,2340,1365,261,256,21792,5456,805]

theorem envBound39275 : H12AffineFastState.Bounded env39275 := by
  intro p hp
  have h : env39275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39274_39275 : H12AffineEnvironment.transform 12 41 env39274 = env39275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39274 == env39275) = true)

theorem identity39275 : scanCanonicalize (H12AffineFastState.compose env39275 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39275 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env39276 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,81,35,16449,2049,1024,80,4160,21509,17,3,41,65,23588,5173,17444,2049,1136,32,37,21509,5237,512]

theorem envBound39276 : H12AffineFastState.Bounded env39276 := by
  intro p hp
  have h : env39276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39275_39276 : H12AffineEnvironment.transform 7 37 env39275 = env39276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39275 == env39276) = true)

theorem identity39276 : scanCanonicalize (H12AffineFastState.compose env39276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39277 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,35,16400,2049,1024,1,4113,21509,17,3,41,16,23588,5173,17444,2049,1057,32,37,21509,5156,512]

theorem envBound39277 : H12AffineFastState.Bounded env39277 := by
  intro p hp
  have h : env39277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39276_39277 : H12AffineEnvironment.transform 5 17 env39276 = env39277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39276 == env39277) = true)

theorem identity39277 : scanCanonicalize (H12AffineFastState.compose env39277 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39277 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39278 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,16384,0,2,16400,2049,1024,1,4113,21509,17,3,8,16,23557,5140,17413,2049,1024,1,4,21509,5125,512]

theorem envBound39278 : H12AffineFastState.Bounded env39278 := by
  intro p hp
  have h : env39278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39277_39278 : H12AffineEnvironment.transform 4 1 env39277 = env39278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39277 == env39278) = true)

theorem identity39278 : scanCanonicalize (H12AffineFastState.compose env39278 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound39278 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39279 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,4096,8,16384,0,2,16400,1054,1024,1,4113,21509,17,3,8,16,20506,5140,17413,1054,1024,1,4,21509,5125,512]

theorem envBound39279 : H12AffineFastState.Bounded env39279 := by
  intro p hp
  have h : env39279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39278_39279 : H12AffineEnvironment.transform 10 1055 env39278 = env39279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env39278 == env39279) = true)

theorem identity39279 : scanCanonicalize (H12AffineFastState.compose env39279 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39279 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39280 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,4096,8,5124,0,2,5140,1054,1024,1,4113,1,17,3,8,16,1054,5140,4097,1054,1024,1,4,1,5125,512]

theorem envBound39280 : H12AffineFastState.Bounded env39280 := by
  intro p hp
  have h : env39280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39279_39280 : H12AffineEnvironment.transform 13 5124 env39279 = env39280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39279 == env39280) = true)

theorem identity39280 : scanCanonicalize (H12AffineFastState.compose env39280 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound39280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39281 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,1045,8,17,0,2,1,1054,1024,1,1028,1,17,3,8,16,1054,1,1044,1054,1024,1,4,1,16,512]

theorem envBound39281 : H12AffineFastState.Bounded env39281 := by
  intro p hp
  have h : env39281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39280_39281 : H12AffineEnvironment.transform 11 1045 env39280 = env39281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env39280 == env39281) = true)

theorem identity39281 : scanCanonicalize (H12AffineFastState.compose env39281 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39281 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39282 : List Nat := [2,4,8,16,1,17,8,4,512,5,26,16,8,17,0,2,1,27,5,1,1,1,17,3,8,16,27,1,17,27,5,1,4,1,16,512]

theorem envBound39282 : H12AffineFastState.Bounded env39282 := by
  intro p hp
  have h : env39282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39281_39282 : H12AffineEnvironment.transform 9 5 env39281 = env39282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39281 == env39282) = true)

theorem identity39282 : scanCanonicalize (H12AffineFastState.compose env39282 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39283 : List Nat := [2,1,8,16,1,17,8,1,512,0,26,16,8,17,0,2,1,27,0,1,1,1,17,3,8,16,27,1,17,27,0,1,1,1,16,512]

theorem envBound39283 : H12AffineFastState.Bounded env39283 := by
  intro p hp
  have h : env39283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39282_39283 : H12AffineEnvironment.transform 1 1 env39282 = env39283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39282 == env39283) = true)

theorem identity39283 : scanCanonicalize (H12AffineFastState.compose env39283 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39283 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39284 : List Nat := [2,1,8,11,1,10,8,1,512,0,1,11,8,10,0,2,1,0,0,1,1,1,10,3,8,11,0,1,10,0,0,1,1,1,11,512]

theorem envBound39284 : H12AffineFastState.Bounded env39284 := by
  intro p hp
  have h : env39284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39283_39284 : H12AffineEnvironment.transform 3 11 env39283 = env39284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39283 == env39284) = true)

theorem identity39284 : scanCanonicalize (H12AffineFastState.compose env39284 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39284 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39285 : List Nat := [2,1,3,0,1,1,3,1,512,0,1,0,3,1,0,2,1,0,0,1,1,1,1,3,3,0,0,1,1,0,0,1,1,1,0,512]

theorem envBound39285 : H12AffineFastState.Bounded env39285 := by
  intro p hp
  have h : env39285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39284_39285 : H12AffineEnvironment.transform 2 3 env39284 = env39285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39284 == env39285) = true)

theorem identity39285 : scanCanonicalize (H12AffineFastState.compose env39285 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound39285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39286 : List Nat := [2,1,3,0,1,1,3,1,3,0,1,0,3,1,0,2,1,0,0,1,1,1,1,3,3,0,0,1,1,0,0,1,1,1,0,3]

theorem envBound39286 : H12AffineFastState.Bounded env39286 := by
  intro p hp
  have h : env39286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39285_39286 : H12AffineEnvironment.transform 8 3 env39285 = env39286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env39285 == env39286) = true)

def env39287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,169265,17,98645,8193,65,245018,5392,17665,108926,1364,156012,256,21792,46092,74250]

theorem envBound39287 : H12AffineFastState.Bounded env39287 := by
  intro p hp
  have h : env39287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39270_39287 : H12AffineEnvironment.transform 6 9 env39270 = env39287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39270 == env39287) = true)

theorem identity39287 : scanCanonicalize (H12AffineFastState.compose env39287 (packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound39287 : packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env39288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103494,64808,1024,32769,4160,65911,17,98645,8193,65,10588,5392,17665,108926,1364,128298,256,21792,46092,74250]

theorem envBound39288 : H12AffineFastState.Bounded env39288 := by
  intro p hp
  have h : env39288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39287_39288 : H12AffineEnvironment.transform 16 103494 env39287 = env39288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env39287 == env39288) = true)

theorem identity39288 : scanCanonicalize (H12AffineFastState.compose env39288 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound39288 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env39289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,2420,1024,29789,4160,65911,17,95497,8193,65,10588,5392,17665,89378,1364,65910,256,21792,16464,74250]

theorem envBound39289 : H12AffineFastState.Bounded env39289 := by
  intro p hp
  have h : env39289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39288_39289 : H12AffineEnvironment.transform 14 29788 env39288 = env39289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39288 == env39289) = true)

theorem identity39289 : scanCanonicalize (H12AffineFastState.compose env39289 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39289 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16401,2420,1024,29789,4160,8572,17,21762,8193,65,10588,5392,17665,32041,1364,8573,256,21792,16464,513]

theorem envBound39290 : H12AffineFastState.Bounded env39290 := by
  intro p hp
  have h : env39290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39289_39290 : H12AffineEnvironment.transform 15 8203 env39289 = env39290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39289 == env39290) = true)

theorem identity39290 : scanCanonicalize (H12AffineFastState.compose env39290 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39290 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,8203,5441,2420,1024,8461,4160,8572,17,82,8193,65,10588,5392,4177,10361,1364,8573,256,112,5376,513]

theorem envBound39291 : H12AffineFastState.Bounded env39291 := by
  intro p hp
  have h : env39291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39290_39291 : H12AffineEnvironment.transform 13 5456 env39290 = env39291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env39290 == env39291) = true)

theorem identity39291 : scanCanonicalize (H12AffineFastState.compose env39291 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound39291 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,57,5456,309,50,5441,2420,1024,308,4160,325,17,82,56,65,2405,5392,4177,2112,1364,324,256,112,5376,513]

theorem envBound39292 : H12AffineFastState.Bounded env39292 := by
  intro p hp
  have h : env39292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39291_39292 : H12AffineEnvironment.transform 12 57 env39291 = env39292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env39291 == env39292) = true)

theorem identity39292 : scanCanonicalize (H12AffineFastState.compose env39292 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 849) := by decide +kernel

theorem selectedBound39292 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env39293 : List Nat := [2,4,8,16,32,64,9,256,512,849,2048,4096,57,4609,309,50,4624,2420,849,308,4160,325,17,82,56,65,2405,4673,4177,2112,517,324,256,112,4689,513]

theorem envBound39293 : H12AffineFastState.Bounded env39293 := by
  intro p hp
  have h : env39293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39292_39293 : H12AffineEnvironment.transform 9 849 env39292 = env39293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 849 env39292 == env39293) = true)

def env39294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,16,98781,8328,65,4270123,5392,17665,109046,1501,4256861,256,21793,46212,74250]

theorem envBound39294 : H12AffineFastState.Bounded env39294 := by
  intro p hp
  have h : env39294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39268_39294 : H12AffineEnvironment.transform 20 4161 env39268 = env39294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39268 == env39294) = true)

def env39295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98645,8192,65,4270123,5392,17665,108926,1365,4256861,256,21793,46092,74250]

theorem envBound39295 : H12AffineFastState.Bounded env39295 := by
  intro p hp
  have h : env39295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39294_39295 : H12AffineEnvironment.transform 6 8 env39294 = env39295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39294 == env39295) = true)

theorem identity39295 : scanCanonicalize (H12AffineFastState.compose env39295 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound39295 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35188,1024,32769,4161,4194304,16,98645,8192,65,4270123,5392,17665,108926,1365,4256861,256,21793,46092,74250]

theorem envBound39296 : H12AffineFastState.Bounded env39296 := by
  intro p hp
  have h : env39296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39295_39296 : H12AffineEnvironment.transform 16 122907 env39295 = env39296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env39295 == env39296) = true)

theorem identity39296 : scanCanonicalize (H12AffineFastState.compose env39296 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound39296 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,38209,35188,1024,32769,4161,4194304,16,62479,8192,65,4218225,5392,17665,56356,1365,4256861,256,21793,46092,22352]

end H12CloudChart0