import H12CloudChart0Data054

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env13804 : List Nat := [2,4,8,16,0,64,9,256,512,68,2048,2324,349,2128,1,343,2113,2388,69,0,2389,0,17,2,348,64,2049,2113,2324,2389,272,1,257,1,2048,512]

theorem envBound13804 : H12AffineFastState.Bounded env13804 := by
  intro p hp
  have h : env13804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13803_13804 : H12AffineEnvironment.transform 6 9 env13803 = env13804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13803 == env13804) = true)

theorem identity13804 : scanCanonicalize (H12AffineFastState.compose env13804 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound13804 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13805 : List Nat := [2,4,8,16,0,64,9,84,512,68,2048,2112,9,2128,1,3,2113,2048,69,0,2049,0,17,2,8,64,2049,2113,2112,2049,68,1,85,1,2048,512]

theorem envBound13805 : H12AffineFastState.Bounded env13805 := by
  intro p hp
  have h : env13805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13804_13805 : H12AffineEnvironment.transform 7 84 env13804 = env13805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env13804 == env13805) = true)

theorem identity13805 : scanCanonicalize (H12AffineFastState.compose env13805 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound13805 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13806 : List Nat := [2,4,8,16,0,64,9,84,30,68,2048,2112,9,2128,1,3,2113,2048,69,0,2049,0,17,2,8,64,2049,2113,2112,2049,68,1,85,1,2048,30]

theorem envBound13806 : H12AffineFastState.Bounded env13806 := by
  intro p hp
  have h : env13806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13805_13806 : H12AffineEnvironment.transform 8 30 env13805 = env13806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env13805 == env13806) = true)

theorem identity13806 : scanCanonicalize (H12AffineFastState.compose env13806 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound13806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13807 : List Nat := [2,4,8,16,0,64,9,84,30,68,80,16,9,0,1,3,17,80,69,0,81,0,17,2,8,64,81,17,16,81,68,1,85,1,80,30]

theorem envBound13807 : H12AffineFastState.Bounded env13807 := by
  intro p hp
  have h : env13807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13806_13807 : H12AffineEnvironment.transform 10 80 env13806 = env13807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env13806 == env13807) = true)

theorem identity13807 : scanCanonicalize (H12AffineFastState.compose env13807 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13807 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13808 : List Nat := [2,4,8,0,0,64,9,68,14,68,64,0,9,0,1,3,1,64,69,0,65,0,1,2,8,64,65,1,0,65,68,1,69,1,64,14]

theorem envBound13808 : H12AffineFastState.Bounded env13808 := by
  intro p hp
  have h : env13808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13807_13808 : H12AffineEnvironment.transform 3 0 env13807 = env13808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13807 == env13808) = true)

theorem identity13808 : scanCanonicalize (H12AffineFastState.compose env13808 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound13808 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13809 : List Nat := [2,4,8,0,0,15,9,11,14,11,15,0,9,0,1,3,1,15,10,0,14,0,1,2,8,15,14,1,0,14,11,1,10,1,15,14]

theorem envBound13809 : H12AffineFastState.Bounded env13809 := by
  intro p hp
  have h : env13809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13808_13809 : H12AffineEnvironment.transform 5 15 env13808 = env13809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env13808 == env13809) = true)

theorem identity13809 : scanCanonicalize (H12AffineFastState.compose env13809 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound13809 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13810 : List Nat := [2,4,6,0,0,1,7,5,0,5,1,0,7,0,1,3,1,1,4,0,0,0,1,2,6,1,0,1,0,0,5,1,4,1,1,0]

theorem envBound13810 : H12AffineFastState.Bounded env13810 := by
  intro p hp
  have h : env13810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13809_13810 : H12AffineEnvironment.transform 2 6 env13809 = env13810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env13809 == env13810) = true)

def env13811 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,262144,1025,29908,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29789,24845,66391]

theorem envBound13811 : H12AffineFastState.Bounded env13811 := by
  intro p hp
  have h : env13811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13796_13811 : H12AffineEnvironment.transform 4 1 env13796 = env13811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13796 == env13811) = true)

theorem identity13811 : scanCanonicalize (H12AffineFastState.compose env13811 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 76247) := by decide +kernel

theorem selectedBound13811 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env13812 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,76247,1025,29908,4161,65879,73755,29791,8328,64,10588,70726,91402,23637,9344,136,257,29789,24845,66391]

theorem envBound13812 : H12AffineFastState.Bounded env13812 := by
  intro p hp
  have h : env13812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13811_13812 : H12AffineEnvironment.transform 17 76247 env13811 = env13812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76247 env13811 == env13812) = true)

theorem identity13812 : scanCanonicalize (H12AffineFastState.compose env13812 (packedSelected [1,2,3,5,6,8,10,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound13812 : packedSelected [1,2,3,5,6,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env13813 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,478,24908,10249,1025,29908,4161,137,8645,29791,8328,64,10588,5528,25812,23637,9344,136,257,29789,24845,649]

theorem envBound13813 : H12AffineFastState.Bounded env13813 := by
  intro p hp
  have h : env13813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13812_13813 : H12AffineEnvironment.transform 15 478 env13812 = env13813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env13812 == env13813) = true)

theorem identity13813 : scanCanonicalize (H12AffineFastState.compose env13813 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound13813 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13814 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,1221,16384,20496,478,17801,3276,1025,20497,4161,137,1280,20634,1101,64,3481,5528,16401,23637,69,136,257,20632,17864,649]

theorem envBound13814 : H12AffineFastState.Bounded env13814 := by
  intro p hp
  have h : env13814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13813_13814 : H12AffineEnvironment.transform 12 1221 env13813 = env13814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env13813 == env13814) = true)

theorem identity13814 : scanCanonicalize (H12AffineFastState.compose env13814 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1416) := by decide +kernel

theorem selectedBound13814 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env13815 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,1416,1221,16384,17816,478,17801,3276,1025,17817,1481,137,1280,17682,1101,64,3481,16,16401,18909,69,136,257,17680,17864,649]

theorem envBound13815 : H12AffineFastState.Bounded env13815 := by
  intro p hp
  have h : env13815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13814_13815 : H12AffineEnvironment.transform 11 1416 env13814 = env13815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1416 env13814 == env13815) = true)

theorem identity13815 : scanCanonicalize (H12AffineFastState.compose env13815 (packedSelected [0,4,7,9,11,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 3140) := by decide +kernel

theorem selectedBound13815 : packedSelected [0,4,7,9,11,14,16] rootPS < 2^1333 := by decide +kernel

def env13816 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,1416,1221,3140,2524,478,2509,3276,1025,2525,1481,137,1280,2390,1101,64,3481,16,3157,1433,69,136,257,2388,2444,649]

theorem envBound13816 : H12AffineFastState.Bounded env13816 := by
  intro p hp
  have h : env13816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13815_13816 : H12AffineEnvironment.transform 13 3140 env13815 = env13816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3140 env13815 == env13816) = true)

theorem identity13816 : scanCanonicalize (H12AffineFastState.compose env13816 (packedSelected [0,1,2,4,7,8,9,11,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13816 : packedSelected [0,1,2,4,7,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env13817 : List Nat := [2,4,8,16,1,64,128,256,512,272,2048,152,469,2388,2524,478,2509,2524,273,2525,217,137,16,2390,349,64,2185,16,2373,137,69,136,257,2388,2444,649]

theorem envBound13817 : H12AffineFastState.Bounded env13817 := by
  intro p hp
  have h : env13817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13816_13817 : H12AffineEnvironment.transform 9 272 env13816 = env13817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13816 == env13817) = true)

theorem identity13817 : scanCanonicalize (H12AffineFastState.compose env13817 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13817 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env13818 : List Nat := [2,4,8,16,1,64,128,5,512,21,2048,152,208,2129,2265,219,2248,2265,20,2264,217,137,16,2131,88,64,2185,16,2112,137,69,136,4,2129,2185,649]

theorem envBound13818 : H12AffineFastState.Bounded env13818 := by
  intro p hp
  have h : env13818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13817_13818 : H12AffineEnvironment.transform 7 5 env13817 = env13818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13817 == env13818) = true)

theorem identity13818 : scanCanonicalize (H12AffineFastState.compose env13818 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound13818 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env13819 : List Nat := [2,4,8,16,1,64,88,5,512,21,2048,64,8,2129,2049,3,2064,2049,20,2048,1,81,16,2131,88,64,2129,16,2112,81,69,80,4,2129,2129,593]

theorem envBound13819 : H12AffineFastState.Bounded env13819 := by
  intro p hp
  have h : env13819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13818_13819 : H12AffineEnvironment.transform 6 88 env13818 = env13819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env13818 == env13819) = true)

theorem identity13819 : scanCanonicalize (H12AffineFastState.compose env13819 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound13819 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13820 : List Nat := [2,4,8,16,1,64,88,5,512,21,80,64,8,1,81,3,64,81,20,80,1,81,16,3,88,64,1,16,16,81,69,80,4,1,1,593]

theorem envBound13820 : H12AffineFastState.Bounded env13820 := by
  intro p hp
  have h : env13820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13819_13820 : H12AffineEnvironment.transform 10 80 env13819 = env13820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env13819 == env13820) = true)

def env13821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213335,16777216,8328,64,16959642,16974164,102878,360791,16958790,17148372,257,16777250,16834950,17031825]

theorem envBound13821 : H12AffineFastState.Bounded env13821 := by
  intro p hp
  have h : env13821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13771_13821 : H12AffineEnvironment.transform 20 165337 env13771 = env13821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env13771 == env13821) = true)

def env13822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213335,254096,8328,64,75786,57796,102878,360791,75222,411972,257,254130,196886,513]

theorem envBound13822 : H12AffineFastState.Bounded env13822 := by
  intro p hp
  have h : env13822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13821_13822 : H12AffineEnvironment.transform 23 254096 env13821 = env13822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env13821 == env13822) = true)

def env13823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213335,253976,8192,64,75786,57676,102742,360791,75102,411972,257,254010,196886,513]

theorem envBound13823 : H12AffineFastState.Bounded env13823 := by
  intro p hp
  have h : env13823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13822_13823 : H12AffineEnvironment.transform 6 8 env13822 = env13823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13822 == env13823) = true)

theorem identity13823 : scanCanonicalize (H12AffineFastState.compose env13823 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound13823 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env13824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,165201,180273,213335,253976,8192,64,75786,57676,102742,67618,75102,180273,257,254010,196886,513]

theorem envBound13824 : H12AffineFastState.Bounded env13824 := by
  intro p hp
  have h : env13824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13823_13824 : H12AffineEnvironment.transform 17 35189 env13823 = env13824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env13823 == env13824) = true)

theorem identity13824 : scanCanonicalize (H12AffineFastState.compose env13824 (packedSelected [1,3,4,5,8,9,10,14,15,16,19,38] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound13824 : packedSelected [1,3,4,5,8,9,10,14,15,16,19,38] rootPS < 2^1333 := by decide +kernel

def env13825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82198,35189,1025,32769,115783,98599,65,41230,8192,64,75786,57676,102742,67618,75102,98599,257,41260,16384,513]

theorem envBound13825 : H12AffineFastState.Bounded env13825 := by
  intro p hp
  have h : env13825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13824_13825 : H12AffineEnvironment.transform 16 82198 env13824 = env13825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env13824 == env13825) = true)

theorem identity13825 : scanCanonicalize (H12AffineFastState.compose env13825 (packedSelected [1,2,3,5,6,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13825 : packedSelected [1,2,3,5,6,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env13826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,82198,10360,1025,8460,91466,73770,65,3,8192,64,75786,16449,77915,67618,75102,73770,257,33,16384,513]

theorem envBound13826 : H12AffineFastState.Bounded env13826 := by
  intro p hp
  have h : env13826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13825_13826 : H12AffineEnvironment.transform 14 8461 env13825 = env13826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13825 == env13826) = true)

theorem identity13826 : scanCanonicalize (H12AffineFastState.compose env13826 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13827 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,82198,10281,1025,8460,91419,73770,16,3,8192,17,75786,16400,77834,67618,75023,73770,257,33,16384,513]

theorem envBound13827 : H12AffineFastState.Bounded env13827 := by
  intro p hp
  have h : env13827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13826_13827 : H12AffineEnvironment.transform 5 17 env13826 = env13827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13826 == env13827) = true)

theorem identity13827 : scanCanonicalize (H12AffineFastState.compose env13827 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13827 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13828 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,65536,82198,2340,1025,1,82966,65831,16,3,269,17,67847,16400,69895,67618,66562,65831,257,33,16384,513]

theorem envBound13828 : H12AffineFastState.Bounded env13828 := by
  intro p hp
  have h : env13828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13827_13828 : H12AffineEnvironment.transform 12 269 env13827 = env13828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13827 == env13828) = true)

theorem identity13828 : scanCanonicalize (H12AffineFastState.compose env13828 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound13828 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13829 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1025,1,17680,33,16,3,269,17,2049,16400,4097,2340,1284,33,257,33,16384,513]

theorem envBound13829 : H12AffineFastState.Bounded env13829 := by
  intro p hp
  have h : env13829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13828_13829 : H12AffineEnvironment.transform 15 262 env13828 = env13829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env13828 == env13829) = true)

theorem identity13829 : scanCanonicalize (H12AffineFastState.compose env13829 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1280) := by decide +kernel

theorem selectedBound13829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13830 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,1280,0,262,1296,2340,1025,1,16,33,16,3,269,17,2049,1296,4097,2340,1284,33,257,33,1280,513]

theorem envBound13830 : H12AffineFastState.Bounded env13830 := by
  intro p hp
  have h : env13830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13829_13830 : H12AffineEnvironment.transform 13 1280 env13829 = env13830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1280 env13829 == env13830) = true)

theorem identity13830 : scanCanonicalize (H12AffineFastState.compose env13830 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2366) := by decide +kernel

theorem selectedBound13830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13831 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2366,269,1280,0,262,1296,2340,1025,1,16,33,16,3,269,17,2049,1296,2367,2340,1284,33,257,33,1280,513]

theorem envBound13831 : H12AffineFastState.Bounded env13831 := by
  intro p hp
  have h : env13831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13830_13831 : H12AffineEnvironment.transform 11 2366 env13830 = env13831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2366 env13830 == env13831) = true)

theorem identity13831 : scanCanonicalize (H12AffineFastState.compose env13831 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1339) := by decide +kernel

theorem selectedBound13831 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13832 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1339,1029,269,1280,0,262,1296,1055,1025,1,16,33,16,3,269,17,1338,1296,1028,1055,1284,33,257,33,1280,513]

theorem envBound13832 : H12AffineFastState.Bounded env13832 := by
  intro p hp
  have h : env13832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13831_13832 : H12AffineEnvironment.transform 10 1339 env13831 = env13832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1339 env13831 == env13832) = true)

theorem identity13832 : scanCanonicalize (H12AffineFastState.compose env13832 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound13832 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13833 : List Nat := [2,4,8,16,32,17,8,256,512,30,293,27,269,286,0,262,270,1,31,1,16,33,16,3,269,17,292,270,26,1,282,33,257,33,286,513]

theorem envBound13833 : H12AffineFastState.Bounded env13833 := by
  intro p hp
  have h : env13833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13832_13833 : H12AffineEnvironment.transform 9 30 env13832 = env13833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env13832 == env13833) = true)

theorem identity13833 : scanCanonicalize (H12AffineFastState.compose env13833 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound13833 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13834 : List Nat := [2,4,8,16,32,17,8,62,512,30,27,27,51,32,0,56,48,1,31,1,16,33,16,3,51,17,26,48,26,1,36,33,63,33,32,513]

theorem envBound13834 : H12AffineFastState.Bounded env13834 := by
  intro p hp
  have h : env13834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13833_13834 : H12AffineEnvironment.transform 7 62 env13833 = env13834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env13833 == env13834) = true)

theorem identity13834 : scanCanonicalize (H12AffineFastState.compose env13834 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound13834 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13835 : List Nat := [2,4,8,16,27,17,8,5,512,30,27,27,8,27,0,3,11,1,31,1,16,26,16,3,8,17,26,11,26,1,31,26,4,26,27,513]

theorem envBound13835 : H12AffineFastState.Bounded env13835 := by
  intro p hp
  have h : env13835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13834_13835 : H12AffineEnvironment.transform 4 27 env13834 = env13835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env13834 == env13835) = true)

def env13836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213335,253977,8193,64,75786,57677,102743,360791,75103,411972,257,254011,196886,513]

theorem envBound13836 : H12AffineFastState.Bounded env13836 := by
  intro p hp
  have h : env13836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13822_13836 : H12AffineEnvironment.transform 6 9 env13822 = env13836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13822 == env13836) = true)

theorem identity13836 : scanCanonicalize (H12AffineFastState.compose env13836 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound13836 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,124234,338271,8525,32771,8193,64,75786,57677,102743,360791,75103,338270,257,32801,24844,513]

theorem envBound13837 : H12AffineFastState.Bounded env13837 := by
  intro p hp
  have h : env13837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13836_13837 : H12AffineEnvironment.transform 16 90138 env13836 = env13837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env13836 == env13837) = true)

theorem identity13837 : scanCanonicalize (H12AffineFastState.compose env13837 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 53526) := by decide +kernel

theorem selectedBound13837 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env13838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53526,45324,262144,1025,32769,13404,325705,8525,32771,8193,64,63772,57677,16449,282689,62537,325704,257,32801,24844,513]

theorem envBound13838 : H12AffineFastState.Bounded env13838 := by
  intro p hp
  have h : env13838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13837_13838 : H12AffineEnvironment.transform 15 53526 env13837 = env13838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53526 env13837 == env13838) = true)

theorem identity13838 : scanCanonicalize (H12AffineFastState.compose env13838 (packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound13838 : packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env13839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53526,45324,2420,1025,32769,13404,61757,8525,32771,8193,64,63772,57677,16449,22837,62537,61756,257,32801,24844,513]

theorem envBound13839 : H12AffineFastState.Bounded env13839 := by
  intro p hp
  have h : env13839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13838_13839 : H12AffineEnvironment.transform 17 2420 env13838 = env13839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env13838 == env13839) = true)

theorem identity13839 : scanCanonicalize (H12AffineFastState.compose env13839 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28747,4177,2420,1025,8540,13404,20576,8525,8542,8193,64,22593,16400,16449,22837,21780,20577,257,8572,24844,513]

theorem envBound13840 : H12AffineFastState.Bounded env13840 := by
  intro p hp
  have h : env13840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13839_13840 : H12AffineEnvironment.transform 14 8541 env13839 = env13840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13839 == env13840) = true)

theorem identity13840 : scanCanonicalize (H12AffineFastState.compose env13840 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound13840 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env13841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,8541,343,4177,2420,1025,8540,13404,8572,8525,8542,8193,64,10589,12556,12637,10281,9224,8573,257,8572,4112,513]

theorem envBound13841 : H12AffineFastState.Bounded env13841 := by
  intro p hp
  have h : env13841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13840_13841 : H12AffineEnvironment.transform 13 12572 env13840 = env13841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env13840 == env13841) = true)

theorem identity13841 : scanCanonicalize (H12AffineFastState.compose env13841 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13841 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,4112,81,343,4177,2420,1025,80,5456,112,65,82,269,64,2129,4096,4177,2341,1284,113,257,112,4112,513]

theorem envBound13842 : H12AffineFastState.Bounded env13842 := by
  intro p hp
  have h : env13842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13841_13842 : H12AffineEnvironment.transform 12 268 env13841 = env13842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13841 == env13842) = true)

def env13843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213335,254097,8328,64,75787,57797,102878,360791,75223,411973,257,254131,196887,512]

theorem envBound13843 : H12AffineFastState.Bounded env13843 := by
  intro p hp
  have h : env13843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13821_13843 : H12AffineEnvironment.transform 23 254097 env13821 = env13843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env13821 == env13843) = true)

theorem identity13843 : scanCanonicalize (H12AffineFastState.compose env13843 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound13843 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,318549,120014,95496,8328,64,75787,57797,102878,360791,75223,318684,257,95530,103566,512]

theorem envBound13844 : H12AffineFastState.Bounded env13844 := by
  intro p hp
  have h : env13844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13843_13844 : H12AffineEnvironment.transform 16 38297 env13843 = env13844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env13843 == env13844) = true)

theorem identity13844 : scanCanonicalize (H12AffineFastState.compose env13844 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13844 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env13845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,38297,262144,1025,32769,4160,318549,54681,29791,8328,64,10588,57797,37001,294912,9344,318684,257,29821,38361,512]

theorem envBound13845 : H12AffineFastState.Bounded env13845 := by
  intro p hp
  have h : env13845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13844_13845 : H12AffineEnvironment.transform 15 343 env13844 = env13845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13844 == env13845) = true)

theorem identity13845 : scanCanonicalize (H12AffineFastState.compose env13845 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound13845 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,343,16400,262144,1025,21896,4160,264668,16,29791,8328,64,10588,13388,17664,284041,9344,264533,257,29821,16464,512]

theorem envBound13846 : H12AffineFastState.Bounded env13846 := by
  intro p hp
  have h : env13846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13845_13846 : H12AffineEnvironment.transform 14 21897 env13845 = env13846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env13845 == env13846) = true)

theorem identity13846 : scanCanonicalize (H12AffineFastState.compose env13846 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound13846 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,343,16400,2184,1025,21896,4160,340,16,29791,8328,64,10588,13388,17664,23809,9344,477,257,29821,16464,512]

theorem envBound13847 : H12AffineFastState.Bounded env13847 := by
  intro p hp
  have h : env13847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13846_13847 : H12AffineEnvironment.transform 17 2184 env13846 = env13847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env13846 == env13847) = true)

theorem identity13847 : scanCanonicalize (H12AffineFastState.compose env13847 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound13847 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env13848 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,21621,171,16400,2184,1025,21620,4160,168,16,29791,8328,64,10400,13388,17660,23805,9344,33,253,29821,16464,512]

theorem envBound13848 : H12AffineFastState.Bounded env13848 := by
  intro p hp
  have h : env13848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13847_13848 : H12AffineEnvironment.transform 7 252 env13847 = env13848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env13847 == env13848) = true)

theorem identity13848 : scanCanonicalize (H12AffineFastState.compose env13848 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound13848 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env13849 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,16384,21621,171,16400,2184,1025,21620,4160,168,16,21758,41,64,2049,5357,17660,23805,1057,33,253,21724,16464,512]

theorem envBound13849 : H12AffineFastState.Bounded env13849 := by
  intro p hp
  have h : env13849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13848_13849 : H12AffineEnvironment.transform 12 161 env13848 = env13849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env13848 == env13849) = true)

theorem identity13849 : scanCanonicalize (H12AffineFastState.compose env13849 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13849 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13850 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,21621,34,16400,2049,1025,21620,4160,33,16,21623,41,64,2049,5220,17525,23668,1057,33,116,21589,16464,512]

theorem envBound13850 : H12AffineFastState.Bounded env13850 := by
  intro p hp
  have h : env13850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13849_13850 : H12AffineEnvironment.transform 6 9 env13849 = env13850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13849 == env13850) = true)

theorem identity13850 : scanCanonicalize (H12AffineFastState.compose env13850 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound13850 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13851 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5125,112,34,5141,2049,1025,113,4160,33,16,114,41,64,2049,5220,4208,2161,1057,33,116,80,5205,512]

theorem envBound13851 : H12AffineFastState.Bounded env13851 := by
  intro p hp
  have h : env13851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13850_13851 : H12AffineEnvironment.transform 13 5125 env13850 = env13851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env13850 == env13851) = true)

theorem identity13851 : scanCanonicalize (H12AffineFastState.compose env13851 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13851 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env13852 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5125,33,34,5141,2049,1025,32,4113,33,16,35,41,17,2049,5173,4129,2080,1057,33,37,1,5124,512]

theorem envBound13852 : H12AffineFastState.Bounded env13852 := by
  intro p hp
  have h : env13852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13851_13852 : H12AffineEnvironment.transform 5 17 env13851 = env13852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13851 == env13852) = true)

theorem identity13852 : scanCanonicalize (H12AffineFastState.compose env13852 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound13852 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13853 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1044,4096,40,5125,33,34,5141,1045,1025,32,4113,33,16,35,41,17,1045,5173,4129,1076,1057,33,37,1,5124,512]

theorem envBound13853 : H12AffineFastState.Bounded env13853 := by
  intro p hp
  have h : env13853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13852_13853 : H12AffineEnvironment.transform 10 1044 env13852 = env13853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env13852 == env13853) = true)

theorem identity13853 : scanCanonicalize (H12AffineFastState.compose env13853 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound13853 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13854 : List Nat := [2,4,8,16,32,17,9,36,512,20,0,4096,40,4113,33,34,4097,1,21,32,4113,33,16,35,41,17,1,4129,4129,32,53,33,37,1,4112,512]

theorem envBound13854 : H12AffineFastState.Bounded env13854 := by
  intro p hp
  have h : env13854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13853_13854 : H12AffineEnvironment.transform 9 20 env13853 = env13854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13853 == env13854) = true)

theorem identity13854 : scanCanonicalize (H12AffineFastState.compose env13854 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound13854 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13855 : List Nat := [2,4,0,16,32,17,1,36,512,20,0,4096,32,4113,33,34,4097,1,21,32,4113,33,16,35,33,17,1,4129,4129,32,53,33,37,1,4112,512]

theorem envBound13855 : H12AffineFastState.Bounded env13855 := by
  intro p hp
  have h : env13855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13854_13855 : H12AffineEnvironment.transform 2 0 env13854 = env13855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env13854 == env13855) = true)

theorem identity13855 : scanCanonicalize (H12AffineFastState.compose env13855 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13855 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13856 : List Nat := [2,4,0,16,32,17,1,36,512,20,0,16,32,1,33,34,17,1,21,32,1,33,16,35,33,17,1,49,49,32,53,33,37,1,0,512]

theorem envBound13856 : H12AffineFastState.Bounded env13856 := by
  intro p hp
  have h : env13856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13855_13856 : H12AffineEnvironment.transform 11 16 env13855 = env13856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13855 == env13856) = true)

theorem identity13856 : scanCanonicalize (H12AffineFastState.compose env13856 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound13856 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env13857 : List Nat := [2,4,0,16,32,17,1,36,35,20,0,16,32,1,33,34,17,1,21,32,1,33,16,35,33,17,1,49,49,32,53,33,37,1,0,35]

theorem envBound13857 : H12AffineFastState.Bounded env13857 := by
  intro p hp
  have h : env13857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13856_13857 : H12AffineEnvironment.transform 8 35 env13856 = env13857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env13856 == env13857) = true)

theorem identity13857 : scanCanonicalize (H12AffineFastState.compose env13857 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13857 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13858 : List Nat := [2,4,0,16,0,17,1,4,3,20,0,16,0,1,1,2,17,1,21,0,1,1,16,3,1,17,1,17,17,0,21,1,5,1,0,3]

theorem envBound13858 : H12AffineFastState.Bounded env13858 := by
  intro p hp
  have h : env13858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13857_13858 : H12AffineEnvironment.transform 4 0 env13857 = env13858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13857 == env13858) = true)

theorem identity13858 : scanCanonicalize (H12AffineFastState.compose env13858 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound13858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13859 : List Nat := [2,4,0,6,0,7,1,4,3,2,0,6,0,1,1,2,7,1,3,0,1,1,6,3,1,7,1,7,7,0,3,1,5,1,0,3]

theorem envBound13859 : H12AffineFastState.Bounded env13859 := by
  intro p hp
  have h : env13859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13858_13859 : H12AffineEnvironment.transform 3 6 env13858 = env13859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env13858 == env13859) = true)

def env13860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412109,213335,16777216,8328,64,16959643,18973837,2298887,360791,16958790,19344396,257,19039739,19031135,17031825]

theorem envBound13860 : H12AffineFastState.Bounded env13860 := by
  intro p hp
  have h : env13860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13770_13860 : H12AffineEnvironment.transform 21 412109 env13770 = env13860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412109 env13770 == env13860) = true)

def env13861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213335,16777216,8328,64,16959643,16974165,102879,360791,16958790,17148372,257,16777251,16834951,17031825]

theorem envBound13861 : H12AffineFastState.Bounded env13861 := by
  intro p hp
  have h : env13861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13860_13861 : H12AffineEnvironment.transform 20 165336 env13860 = env13861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env13860 == env13861) = true)

theorem identity13861 : scanCanonicalize (H12AffineFastState.compose env13861 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106624) := by decide +kernel

theorem selectedBound13861 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env13862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213335,106624,8328,64,223259,172501,102879,360791,222662,264532,257,106659,82183,147985]

theorem envBound13862 : H12AffineFastState.Bounded env13862 := by
  intro p hp
  have h : env13862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13861_13862 : H12AffineEnvironment.transform 23 106624 env13861 = env13862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106624 env13861 == env13862) = true)

def env13863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50632,264669,65863,106624,8328,64,75787,57797,102879,360791,75222,264532,257,106659,82183,513]

theorem envBound13863 : H12AffineFastState.Bounded env13863 := by
  intro p hp
  have h : env13863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13862_13863 : H12AffineEnvironment.transform 16 16400 env13862 = env13863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13862 == env13863) = true)

theorem identity13863 : scanCanonicalize (H12AffineFastState.compose env13863 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13863 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,50632,264669,8525,32906,8328,64,2049,57797,45525,303453,1500,264532,257,32937,24845,513]

theorem envBound13864 : H12AffineFastState.Bounded env13864 := by
  intro p hp
  have h : env13864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13863_13864 : H12AffineEnvironment.transform 15 8202 env13863 = env13864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13863 == env13864) = true)

theorem identity13864 : scanCanonicalize (H12AffineFastState.compose env13864 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound13864 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env13865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10401,1025,32769,50632,8572,8525,32906,8328,64,2049,57797,45525,35324,1500,8693,257,32937,24845,513]

theorem envBound13865 : H12AffineFastState.Bounded env13865 := by
  intro p hp
  have h : env13865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13864_13865 : H12AffineEnvironment.transform 17 10401 env13864 = env13865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env13864 == env13865) = true)

theorem identity13865 : scanCanonicalize (H12AffineFastState.compose env13865 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13865 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env13866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16400,10401,1025,1,17864,8572,8525,138,8328,64,2049,25029,12757,2556,1500,8693,257,169,24845,513]

theorem envBound13866 : H12AffineFastState.Bounded env13866 := by
  intro p hp
  have h : env13866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13865_13866 : H12AffineEnvironment.transform 14 0 env13865 = env13866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13865 == env13866) = true)

theorem identity13866 : scanCanonicalize (H12AffineFastState.compose env13866 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound13866 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env13867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,0,399,16400,2340,1025,1,17864,249,200,138,269,64,2049,16448,4176,2556,1500,112,257,169,16520,513]

theorem envBound13867 : H12AffineFastState.Bounded env13867 := by
  intro p hp
  have h : env13867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13866_13867 : H12AffineEnvironment.transform 12 389 env13866 = env13867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env13866 == env13867) = true)

theorem identity13867 : scanCanonicalize (H12AffineFastState.compose env13867 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13867 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env13868 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,0,399,16400,2340,1025,1,17816,169,152,138,269,16,2049,16400,4096,2476,1420,32,257,169,16520,513]

theorem envBound13868 : H12AffineFastState.Bounded env13868 := by
  intro p hp
  have h : env13868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13867_13868 : H12AffineEnvironment.transform 5 16 env13867 = env13868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13867 == env13868) = true)

theorem identity13868 : scanCanonicalize (H12AffineFastState.compose env13868 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound13868 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13869 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3244,389,16384,0,399,16400,2340,1025,1,17816,169,152,138,269,16,2049,16400,3244,2476,1420,32,257,169,16520,513]

theorem envBound13869 : H12AffineFastState.Bounded env13869 := by
  intro p hp
  have h : env13869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13868_13869 : H12AffineEnvironment.transform 11 3244 env13868 = env13869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env13868 == env13869) = true)

theorem identity13869 : scanCanonicalize (H12AffineFastState.compose env13869 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound13869 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env13870 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,2065,389,16384,0,399,16400,2340,188,1,16677,169,152,138,269,16,2049,16400,2065,2476,305,32,257,169,16520,513]

theorem envBound13870 : H12AffineFastState.Bounded env13870 := by
  intro p hp
  have h : env13870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13869_13870 : H12AffineEnvironment.transform 9 189 env13869 = env13870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env13869 == env13870) = true)

theorem identity13870 : scanCanonicalize (H12AffineFastState.compose env13870 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13870 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env13871 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2065,269,16384,0,263,16400,2340,52,1,16677,33,16,2,269,16,2049,16400,2065,2340,305,32,257,33,16384,513]

theorem envBound13871 : H12AffineFastState.Bounded env13871 := by
  intro p hp
  have h : env13871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13870_13871 : H12AffineEnvironment.transform 6 8 env13870 = env13871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13870 == env13871) = true)

theorem identity13871 : scanCanonicalize (H12AffineFastState.compose env13871 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound13871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13872 : List Nat := [2,4,8,16,32,16,8,21,512,53,2048,2065,24,16384,0,18,16400,2097,52,1,16432,33,16,2,24,16,2049,16400,2065,2097,36,32,20,33,16384,513]

theorem envBound13872 : H12AffineFastState.Bounded env13872 := by
  intro p hp
  have h : env13872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13871_13872 : H12AffineEnvironment.transform 7 21 env13871 = env13872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env13871 == env13872) = true)

theorem identity13872 : scanCanonicalize (H12AffineFastState.compose env13872 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound13872 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13873 : List Nat := [2,4,8,16,32,16,8,21,512,53,2048,2065,24,512,0,18,528,2097,52,1,560,33,16,2,24,16,2049,528,2065,2097,36,32,20,33,512,513]

theorem envBound13873 : H12AffineFastState.Bounded env13873 := by
  intro p hp
  have h : env13873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13872_13873 : H12AffineEnvironment.transform 13 512 env13872 = env13873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env13872 == env13873) = true)

theorem identity13873 : scanCanonicalize (H12AffineFastState.compose env13873 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound13873 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13874 : List Nat := [2,4,8,16,32,16,8,21,512,53,49,32,24,512,0,18,528,0,52,1,560,33,16,2,24,16,48,528,32,0,36,32,20,33,512,513]

theorem envBound13874 : H12AffineFastState.Bounded env13874 := by
  intro p hp
  have h : env13874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13873_13874 : H12AffineEnvironment.transform 10 49 env13873 = env13874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env13873 == env13874) = true)

theorem identity13874 : scanCanonicalize (H12AffineFastState.compose env13874 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13874 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13875 : List Nat := [2,4,8,16,1,16,8,21,512,20,16,1,24,512,0,18,528,0,21,1,529,0,16,2,24,16,17,528,1,0,5,1,20,0,512,513]

theorem envBound13875 : H12AffineFastState.Bounded env13875 := by
  intro p hp
  have h : env13875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13874_13875 : H12AffineEnvironment.transform 4 1 env13874 = env13875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13874 == env13875) = true)

theorem identity13875 : scanCanonicalize (H12AffineFastState.compose env13875 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound13875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13876 : List Nat := [2,4,8,16,1,16,8,21,16,20,16,1,24,16,0,18,0,0,21,1,1,0,16,2,24,16,17,0,1,0,5,1,20,0,16,17]

theorem envBound13876 : H12AffineFastState.Bounded env13876 := by
  intro p hp
  have h : env13876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13875_13876 : H12AffineEnvironment.transform 8 16 env13875 = env13876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env13875 == env13876) = true)

theorem identity13876 : scanCanonicalize (H12AffineFastState.compose env13876 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13876 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13877 : List Nat := [2,4,8,1,1,1,8,4,1,5,1,1,9,1,0,3,0,0,4,1,1,0,1,2,9,1,0,0,1,0,5,1,5,0,1,0]

theorem envBound13877 : H12AffineFastState.Bounded env13877 := by
  intro p hp
  have h : env13877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13876_13877 : H12AffineEnvironment.transform 3 1 env13876 = env13877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13876 == env13877) = true)

def env13878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50633,264668,65862,106624,8328,64,75786,57796,102879,360791,75223,264532,257,106659,82183,512]

theorem envBound13878 : H12AffineFastState.Bounded env13878 := by
  intro p hp
  have h : env13878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13862_13878 : H12AffineEnvironment.transform 16 16401 env13862 = env13878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13862 == env13878) = true)

theorem identity13878 : scanCanonicalize (H12AffineFastState.compose env13878 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound13878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,16401,262144,1025,32769,50633,264668,62660,21762,8328,64,56712,57796,25693,292053,53333,264532,257,21793,46213,512]

theorem envBound13879 : H12AffineFastState.Bounded env13879 := by
  intro p hp
  have h : env13879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13878_13879 : H12AffineEnvironment.transform 15 62850 env13878 = env13879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env13878 == env13879) = true)

theorem identity13879 : scanCanonicalize (H12AffineFastState.compose env13879 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound13879 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env13880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16401,262144,1025,29908,12572,264668,17,21762,8328,64,10589,5393,25693,292053,9344,264532,257,21793,16464,512]

theorem envBound13880 : H12AffineFastState.Bounded env13880 := by
  intro p hp
  have h : env13880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13879_13880 : H12AffineEnvironment.transform 14 29909 env13879 = env13880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env13879 == env13880) = true)

theorem identity13880 : scanCanonicalize (H12AffineFastState.compose env13880 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound13880 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16401,10708,1025,29908,12572,8200,17,21762,8328,64,10589,5393,25693,23809,9344,8320,257,21793,16464,512]

theorem envBound13881 : H12AffineFastState.Bounded env13881 := by
  intro p hp
  have h : env13881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13880_13881 : H12AffineEnvironment.transform 17 10708 env13880 = env13881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env13880 == env13881) = true)

theorem identity13881 : scanCanonicalize (H12AffineFastState.compose env13881 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13881 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env13882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,21757,343,16401,2556,1025,21756,4404,32,17,21762,160,64,2421,5393,17525,23809,1192,168,257,21793,16464,512]

theorem envBound13882 : H12AffineFastState.Bounded env13882 := by
  intro p hp
  have h : env13882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13881_13882 : H12AffineEnvironment.transform 12 40 env13881 = env13882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13881 == env13882) = true)

theorem identity13882 : scanCanonicalize (H12AffineFastState.compose env13882 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound13882 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env13883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,137,343,5221,2556,1025,136,4404,32,17,374,160,64,2421,5393,4097,2421,1192,168,257,341,5156,512]

theorem envBound13883 : H12AffineFastState.Bounded env13883 := by
  intro p hp
  have h : env13883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13882_13883 : H12AffineEnvironment.transform 13 5236 env13882 = env13883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env13882 == env13883) = true)

theorem identity13883 : scanCanonicalize (H12AffineFastState.compose env13883 (packedSelected [0,2,7,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound13883 : packedSelected [0,2,7,12,14] rootPS < 2^1333 := by decide +kernel

def env13884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,40,2556,137,343,2541,2556,1025,136,3260,32,17,374,160,64,2421,2201,3465,2421,1192,168,257,341,2476,512]

theorem envBound13884 : H12AffineFastState.Bounded env13884 := by
  intro p hp
  have h : env13884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13883_13884 : H12AffineEnvironment.transform 11 3464 env13883 = env13884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env13883 == env13884) = true)

theorem identity13884 : scanCanonicalize (H12AffineFastState.compose env13884 (packedSelected [2,6,7,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13884 : packedSelected [2,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13885 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,3464,8,2524,137,343,2509,2524,1025,136,3228,0,17,342,128,64,2389,2201,3465,2389,1160,136,257,341,2444,512]

theorem envBound13885 : H12AffineFastState.Bounded env13885 := by
  intro p hp
  have h : env13885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13884_13885 : H12AffineEnvironment.transform 4 0 env13884 = env13885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13884 == env13885) = true)

theorem identity13885 : scanCanonicalize (H12AffineFastState.compose env13885 (packedSelected [0,1,6,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13885 : packedSelected [0,1,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env13886 : List Nat := [2,4,8,16,0,64,128,5,512,1024,2048,3213,8,2265,137,82,2248,2265,1025,136,3228,0,17,83,128,64,2128,2201,3212,2128,1160,136,4,80,2185,512]

theorem envBound13886 : H12AffineFastState.Bounded env13886 := by
  intro p hp
  have h : env13886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13885_13886 : H12AffineEnvironment.transform 7 5 env13885 = env13886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13885 == env13886) = true)

theorem identity13886 : scanCanonicalize (H12AffineFastState.compose env13886 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound13886 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env13887 : List Nat := [2,4,8,16,0,64,89,5,512,1024,2048,3156,8,2048,80,82,2065,2048,1025,81,3141,0,17,83,89,64,2128,2112,3157,2128,1105,81,4,80,2128,512]

theorem envBound13887 : H12AffineFastState.Bounded env13887 := by
  intro p hp
  have h : env13887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13886_13887 : H12AffineEnvironment.transform 6 89 env13886 = env13887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env13886 == env13887) = true)

theorem identity13887 : scanCanonicalize (H12AffineFastState.compose env13887 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13887 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13888 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3076,8,2048,0,2,2065,2048,1025,1,3093,0,17,3,9,16,2048,2064,3077,2048,1025,1,4,0,2048,512]

theorem envBound13888 : H12AffineFastState.Bounded env13888 := by
  intro p hp
  have h : env13888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13887_13888 : H12AffineEnvironment.transform 5 16 env13887 = env13888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13887 == env13888) = true)

theorem identity13888 : scanCanonicalize (H12AffineFastState.compose env13888 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound13888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13889 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1045,17,8,1045,0,2,1028,1045,1025,1,0,0,17,3,9,16,1045,1029,16,1045,1025,1,4,0,1045,512]

theorem envBound13889 : H12AffineFastState.Bounded env13889 := by
  intro p hp
  have h : env13889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13888_13889 : H12AffineEnvironment.transform 10 1045 env13888 = env13889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env13888 == env13889) = true)

theorem identity13889 : scanCanonicalize (H12AffineFastState.compose env13889 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13890 : List Nat := [2,4,8,16,0,16,9,5,0,1024,1045,17,8,1045,0,2,1028,1045,1025,1,0,0,17,3,9,16,1045,1029,16,1045,1025,1,4,0,1045,0]

theorem envBound13890 : H12AffineFastState.Bounded env13890 := by
  intro p hp
  have h : env13890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13889_13890 : H12AffineEnvironment.transform 8 0 env13889 = env13890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13889 == env13890) = true)

def env13891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213335,16777216,8328,64,16959643,16974164,102878,360791,16958790,17148373,257,16777250,16834950,17031825]

theorem envBound13891 : H12AffineFastState.Bounded env13891 := by
  intro p hp
  have h : env13891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13860_13891 : H12AffineEnvironment.transform 20 165337 env13860 = env13891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env13860 == env13891) = true)

theorem identity13891 : scanCanonicalize (H12AffineFastState.compose env13891 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound13891 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env13892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115871,329867,17,16777216,8328,64,16878045,16793618,102878,360791,16876544,17148373,257,16777250,16834950,16819159]

theorem envBound13892 : H12AffineFastState.Bounded env13892 := by
  intro p hp
  have h : env13892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13891_13892 : H12AffineEnvironment.transform 16 82246 env13891 = env13892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env13891 == env13892) = true)

def env13893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115871,329867,17,95496,8328,64,64725,79130,102878,360791,61704,318685,257,95530,103566,120543]

theorem envBound13893 : H12AffineFastState.Bounded env13893 := by
  intro p hp
  have h : env13893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13892_13893 : H12AffineEnvironment.transform 23 95496 env13892 = env13893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env13892 == env13893) = true)

def env13894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115735,329731,17,95496,8192,64,64605,79130,102742,360791,61704,318549,257,95530,103430,120407]

theorem envBound13894 : H12AffineFastState.Bounded env13894 := by
  intro p hp
  have h : env13894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13893_13894 : H12AffineEnvironment.transform 6 8 env13893 = env13894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13893 == env13894) = true)

theorem identity13894 : scanCanonicalize (H12AffineFastState.compose env13894 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound13894 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130175,1025,32769,115735,62588,17,95496,8192,64,64605,79130,102742,32040,61704,73770,257,95530,103430,120407]

theorem envBound13895 : H12AffineFastState.Bounded env13895 := by
  intro p hp
  have h : env13895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13894_13895 : H12AffineEnvironment.transform 17 130175 env13894 = env13895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env13894 == env13895) = true)

theorem identity13895 : scanCanonicalize (H12AffineFastState.compose env13895 (packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13895 : packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env13896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,65536,82246,122226,1025,32769,115735,54641,17,87045,269,64,56656,70679,102742,23589,53253,65831,257,87079,103430,120407]

theorem envBound13896 : H12AffineFastState.Bounded env13896 := by
  intro p hp
  have h : env13896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13895_13896 : H12AffineEnvironment.transform 12 269 env13895 = env13896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13895 == env13896) = true)

theorem identity13896 : scanCanonicalize (H12AffineFastState.compose env13896 (packedSelected [1,2,4,6,8,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13896 : packedSelected [1,2,4,6,8,16,19,22] rootPS < 2^1333 := by decide +kernel

def env13897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,65536,82246,89458,1025,1,82967,21873,17,87045,269,64,23888,70679,69974,23589,20485,65831,257,87079,70662,87639]

theorem envBound13897 : H12AffineFastState.Bounded env13897 := by
  intro p hp
  have h : env13897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13896_13897 : H12AffineEnvironment.transform 14 0 env13896 = env13897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13896 == env13897) = true)

theorem identity13897 : scanCanonicalize (H12AffineFastState.compose env13897 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound13897 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env13898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,21510,5440,2420,1025,1,4113,21873,17,3,269,64,23888,16401,17744,23589,20485,21793,257,33,16384,593]

theorem envBound13898 : H12AffineFastState.Bounded env13898 := by
  intro p hp
  have h : env13898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13897_13898 : H12AffineEnvironment.transform 15 21510 env13897 = env13898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env13897 == env13898) = true)

theorem identity13898 : scanCanonicalize (H12AffineFastState.compose env13898 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound13898 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,269,16384,0,19479,3409,2420,1025,1,2048,19808,17,3,269,64,17729,16401,17744,17460,18452,19760,257,33,16384,593]

theorem envBound13899 : H12AffineFastState.Bounded env13899 := by
  intro p hp
  have h : env13899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13898_13899 : H12AffineEnvironment.transform 11 2065 env13898 = env13899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env13898 == env13899) = true)

theorem identity13899 : scanCanonicalize (H12AffineFastState.compose env13899 (packedSelected [2,4,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound13899 : packedSelected [2,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,112,97,269,16384,0,17511,1313,260,1025,1,112,17680,17,3,269,64,17729,16401,17744,17460,16484,17728,257,33,16384,593]

theorem envBound13900 : H12AffineFastState.Bounded env13900 := by
  intro p hp
  have h : env13900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13899_13900 : H12AffineEnvironment.transform 10 112 env13899 = env13900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env13899 == env13900) = true)

theorem identity13900 : scanCanonicalize (H12AffineFastState.compose env13900 (packedSelected [0,2,3,4,5,6,12] rootPS)) = affineNative (2^(13+1) ^^^ 261) := by decide +kernel

theorem selectedBound13900 : packedSelected [0,2,3,4,5,6,12] rootPS < 2^1333 := by decide +kernel

def env13901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,112,97,269,261,0,1378,1313,260,1025,1,112,1045,17,3,269,64,1092,276,1109,1329,353,1093,257,33,261,593]

theorem envBound13901 : H12AffineFastState.Bounded env13901 := by
  intro p hp
  have h : env13901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13900_13901 : H12AffineEnvironment.transform 13 261 env13900 = env13901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 261 env13900 == env13901) = true)

theorem identity13901 : scanCanonicalize (H12AffineFastState.compose env13901 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13901 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env13902 : List Nat := [2,4,8,16,32,64,8,256,512,101,112,97,269,261,0,263,324,260,100,1,112,112,17,3,269,64,33,276,48,340,353,32,257,33,261,593]

theorem envBound13902 : H12AffineFastState.Bounded env13902 := by
  intro p hp
  have h : env13902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13901_13902 : H12AffineEnvironment.transform 9 101 env13901 = env13902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13901 == env13902) = true)

theorem identity13902 : scanCanonicalize (H12AffineFastState.compose env13902 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound13902 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13903 : List Nat := [2,4,8,16,32,10,8,256,512,47,58,43,269,261,0,263,270,260,46,1,58,58,17,3,269,10,33,276,48,286,299,32,257,33,261,539]

theorem envBound13903 : H12AffineFastState.Bounded env13903 := by
  intro p hp
  have h : env13903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13902_13903 : H12AffineEnvironment.transform 5 10 env13902 = env13903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env13902 == env13903) = true)

theorem identity13903 : scanCanonicalize (H12AffineFastState.compose env13903 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13903 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13904 : List Nat := [2,4,8,0,32,10,8,256,512,47,42,43,269,261,0,263,270,260,46,1,42,42,1,3,269,10,33,260,32,270,299,32,257,33,261,523]

theorem envBound13904 : H12AffineFastState.Bounded env13904 := by
  intro p hp
  have h : env13904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13903_13904 : H12AffineEnvironment.transform 3 0 env13903 = env13904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13903 == env13904) = true)

theorem identity13904 : scanCanonicalize (H12AffineFastState.compose env13904 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13904 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env13905 : List Nat := [2,4,3,0,32,1,3,256,512,36,33,32,262,261,0,263,261,260,37,1,33,33,1,3,262,1,33,260,32,261,288,32,257,33,261,512]

theorem envBound13905 : H12AffineFastState.Bounded env13905 := by
  intro p hp
  have h : env13905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13904_13905 : H12AffineEnvironment.transform 2 3 env13904 = env13905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13904 == env13905) = true)

theorem identity13905 : scanCanonicalize (H12AffineFastState.compose env13905 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 295) := by decide +kernel

theorem selectedBound13905 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13906 : List Nat := [2,4,3,0,32,1,3,256,295,36,33,32,262,261,0,263,261,260,37,1,33,33,1,3,262,1,33,260,32,261,288,32,257,33,261,295]

theorem envBound13906 : H12AffineFastState.Bounded env13906 := by
  intro p hp
  have h : env13906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13905_13906 : H12AffineEnvironment.transform 8 295 env13905 = env13906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 295 env13905 == env13906) = true)

theorem identity13906 : scanCanonicalize (H12AffineFastState.compose env13906 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13907 : List Nat := [2,4,3,0,1,1,3,256,262,5,0,1,262,261,0,263,261,260,4,1,0,0,1,3,262,1,0,260,1,261,257,1,257,0,261,262]

theorem envBound13907 : H12AffineFastState.Bounded env13907 := by
  intro p hp
  have h : env13907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13906_13907 : H12AffineEnvironment.transform 4 1 env13906 = env13907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13906 == env13907) = true)

def env13908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115734,329730,17,95496,8193,64,64604,79130,102743,360791,61704,318548,257,95530,103431,120406]

theorem envBound13908 : H12AffineFastState.Bounded env13908 := by
  intro p hp
  have h : env13908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13893_13908 : H12AffineEnvironment.transform 6 9 env13893 = env13908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13893 == env13908) = true)

theorem identity13908 : scanCanonicalize (H12AffineFastState.compose env13908 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound13908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,89378,1025,32769,115734,21792,17,95496,8193,64,64604,79130,102743,56437,61704,98678,257,95530,103431,120406]

theorem envBound13909 : H12AffineFastState.Bounded env13909 := by
  intro p hp
  have h : env13909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13908_13909 : H12AffineEnvironment.transform 17 89378 env13908 = env13909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env13908 == env13909) = true)

theorem identity13909 : scanCanonicalize (H12AffineFastState.compose env13909 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13909 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,89378,1025,32769,115734,21792,17,87124,349,64,56576,70726,102743,56437,53332,98678,257,87158,103431,120406]

theorem envBound13910 : H12AffineFastState.Bounded env13910 := by
  intro p hp
  have h : env13910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13909_13910 : H12AffineEnvironment.transform 12 348 env13909 = env13910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13909 == env13910) = true)

theorem identity13910 : scanCanonicalize (H12AffineFastState.compose env13910 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound13910 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env13911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21591,5393,2421,1025,32769,36929,21792,17,3,349,64,56576,16401,50432,56437,53332,54561,257,33,49232,33281]

theorem envBound13911 : H12AffineFastState.Bounded env13911 := by
  intro p hp
  have h : env13911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13910_13911 : H12AffineEnvironment.transform 15 21591 env13910 = env13911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env13910 == env13911) = true)

theorem identity13911 : scanCanonicalize (H12AffineFastState.compose env13911 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13911 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env13912 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,21591,5220,2048,1025,32769,36929,21589,17,3,40,64,56437,16401,50293,56437,53332,54356,116,33,49232,33281]

theorem envBound13912 : H12AffineFastState.Bounded env13912 := by
  intro p hp
  have h : env13912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13911_13912 : H12AffineEnvironment.transform 7 117 env13911 = env13912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13911 == env13912) = true)

theorem identity13912 : scanCanonicalize (H12AffineFastState.compose env13912 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound13912 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env13913 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21620,21591,5220,2048,1025,21621,17461,21589,17,3,40,64,2049,16401,4097,2049,1056,32,116,33,5156,22133]

theorem envBound13913 : H12AffineFastState.Bounded env13913 := by
  intro p hp
  have h : env13913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13912_13913 : H12AffineEnvironment.transform 14 21620 env13912 = env13913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env13912 == env13913) = true)

theorem identity13913 : scanCanonicalize (H12AffineFastState.compose env13913 (packedSelected [4,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13913 : packedSelected [4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env13914 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,34,5220,2048,1025,0,4160,32,17,3,40,64,2049,5220,4097,2049,1056,32,116,33,5156,512]

theorem envBound13914 : H12AffineFastState.Bounded env13914 := by
  intro p hp
  have h : env13914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13913_13914 : H12AffineEnvironment.transform 13 5237 env13913 = env13914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13913 == env13914) = true)

theorem identity13914 : scanCanonicalize (H12AffineFastState.compose env13914 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound13914 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13915 : List Nat := [2,4,8,16,32,64,9,117,512,1024,554,4096,41,5237,1,34,5220,554,1025,0,4160,32,17,3,40,64,555,5220,4097,555,1056,32,116,33,5156,512]

theorem envBound13915 : H12AffineFastState.Bounded env13915 := by
  intro p hp
  have h : env13915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13914_13915 : H12AffineEnvironment.transform 10 554 env13914 = env13915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env13914 == env13915) = true)

theorem identity13915 : scanCanonicalize (H12AffineFastState.compose env13915 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound13915 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13916 : List Nat := [2,4,8,16,32,49,9,4,512,1024,554,4096,41,5124,1,34,5141,554,1025,0,4145,32,17,3,40,49,555,5141,4097,555,1056,32,5,33,5156,512]

theorem envBound13916 : H12AffineFastState.Bounded env13916 := by
  intro p hp
  have h : env13916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13915_13916 : H12AffineEnvironment.transform 5 49 env13915 = env13916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env13915 == env13916) = true)

theorem identity13916 : scanCanonicalize (H12AffineFastState.compose env13916 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13916 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13917 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,4096,8,5124,1,3,5141,523,1025,0,4112,1,17,3,9,16,522,5141,4097,522,1025,1,5,0,5125,512]

theorem envBound13917 : H12AffineFastState.Bounded env13917 := by
  intro p hp
  have h : env13917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13916_13917 : H12AffineEnvironment.transform 4 1 env13916 = env13917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13916 == env13917) = true)

def env13918 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,16,8,1044,1,3,1029,523,1025,0,0,1,17,3,9,16,522,1029,17,522,1025,1,5,0,1045,512]

theorem envBound13918 : H12AffineFastState.Bounded env13918 := by
  intro p hp
  have h : env13918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13917_13918 : H12AffineEnvironment.transform 11 16 env13917 = env13918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13917 == env13918) = true)

theorem identity13918 : scanCanonicalize (H12AffineFastState.compose env13918 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound13918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13919 : List Nat := [2,4,8,5,1,5,9,4,512,1024,523,5,8,1025,1,3,1029,523,1025,0,0,1,4,3,9,5,522,1029,4,522,1025,1,5,0,1024,512]

theorem envBound13919 : H12AffineFastState.Bounded env13919 := by
  intro p hp
  have h : env13919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13918_13919 : H12AffineEnvironment.transform 3 5 env13918 = env13919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env13918 == env13919) = true)

def env13920 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,5,8,1,1,3,5,523,1,0,0,1,4,3,9,5,522,5,4,522,1,1,5,0,0,512]

theorem envBound13920 : H12AffineFastState.Bounded env13920 := by
  intro p hp
  have h : env13920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13919_13920 : H12AffineEnvironment.transform 9 0 env13919 = env13920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env13919 == env13920) = true)

theorem identity13920 : scanCanonicalize (H12AffineFastState.compose env13920 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound13920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13921 : List Nat := [0,4,8,5,1,5,9,4,512,0,521,5,8,1,1,1,5,521,1,0,0,1,4,1,9,5,520,5,4,520,1,1,5,0,0,512]

theorem envBound13921 : H12AffineFastState.Bounded env13921 := by
  intro p hp
  have h : env13921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13920_13921 : H12AffineEnvironment.transform 0 0 env13920 = env13921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env13920 == env13921) = true)

def leafEnv13921 : List Nat := [0,4,8,5,1,5,9,4,512,0,521,5,8,1,1,1,5,521,1,0,0,1,4,1,1,9,1,5,520,5,4,520,1,1,5,0,4,0,0,512,1,1,0]

def active13921 : List Nat := [1,2,8]

def tree13921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13921 : H12WitnessSearch.Good tree13921 := H12GlobalWitnessIndex.good

theorem leafIdentity13921 : H12AffineFastState.composeSystem env13921 rootObs = leafEnv13921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13921 rootObs == leafEnv13921) = true)

theorem terminalChecked13921 : H12PackedTerminal.terminalCheckFast leafEnv13921 active13921 tree13921 = true := by decide +kernel

def env13922 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,5,8,0,1,3,4,523,0,0,0,1,4,3,9,5,522,4,4,522,0,1,5,0,1,512]

theorem envBound13922 : H12AffineFastState.Bounded env13922 := by
  intro p hp
  have h : env13922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13919_13922 : H12AffineEnvironment.transform 9 1 env13919 = env13922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env13919 == env13922) = true)

theorem identity13922 : scanCanonicalize (H12AffineFastState.compose env13922 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound13922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13923 : List Nat := [2,4,8,5,1,5,9,4,9,1,2,5,8,0,1,3,4,2,0,0,0,1,4,3,9,5,3,4,4,3,0,1,5,0,1,9]

theorem envBound13923 : H12AffineFastState.Bounded env13923 := by
  intro p hp
  have h : env13923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13922_13923 : H12AffineEnvironment.transform 8 9 env13922 = env13923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env13922 == env13923) = true)

def leafEnv13923 : List Nat := [2,4,8,5,1,5,9,4,9,1,2,5,8,0,1,3,4,2,0,0,0,1,4,3,0,9,1,5,3,4,4,3,0,1,5,0,4,2,1,9,1,1,0]

def active13923 : List Nat := [0,1,2]

def tree13923 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13923 : H12WitnessSearch.Good tree13923 := H12GlobalWitnessIndex.good

theorem leafIdentity13923 : H12AffineFastState.composeSystem env13923 rootObs = leafEnv13923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13923 rootObs == leafEnv13923) = true)

theorem terminalChecked13923 : H12PackedTerminal.terminalCheckFast leafEnv13923 active13923 tree13923 = true := by decide +kernel

def env13924 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,17,8,1045,1,3,1028,523,1025,0,1,1,17,3,9,16,522,1028,16,522,1025,1,5,0,1044,512]

theorem envBound13924 : H12AffineFastState.Bounded env13924 := by
  intro p hp
  have h : env13924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13917_13924 : H12AffineEnvironment.transform 11 17 env13917 = env13924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13917 == env13924) = true)

theorem identity13924 : scanCanonicalize (H12AffineFastState.compose env13924 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound13924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13925 : List Nat := [2,4,8,16,1,16,9,4,512,1,523,17,8,20,1,3,5,523,0,0,1,1,17,3,9,16,522,5,16,522,0,1,5,0,21,512]

theorem envBound13925 : H12AffineFastState.Bounded env13925 := by
  intro p hp
  have h : env13925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13924_13925 : H12AffineEnvironment.transform 9 1 env13924 = env13925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env13924 == env13925) = true)

def env13926 : List Nat := [2,4,8,4,1,4,9,4,512,1,523,5,8,0,1,3,5,523,0,0,1,1,5,3,9,4,522,5,4,522,0,1,5,0,1,512]

theorem envBound13926 : H12AffineFastState.Bounded env13926 := by
  intro p hp
  have h : env13926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13925_13926 : H12AffineEnvironment.transform 3 4 env13925 = env13926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env13925 == env13926) = true)

theorem identity13926 : scanCanonicalize (H12AffineFastState.compose env13926 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound13926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13927 : List Nat := [0,4,8,4,1,4,9,4,512,1,521,5,8,0,1,1,5,521,0,0,1,1,5,1,9,4,520,5,4,520,0,1,5,0,1,512]

theorem envBound13927 : H12AffineFastState.Bounded env13927 := by
  intro p hp
  have h : env13927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13926_13927 : H12AffineEnvironment.transform 0 0 env13926 = env13927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env13926 == env13927) = true)

def leafEnv13927 : List Nat := [0,4,8,4,1,4,9,4,512,1,521,5,8,0,1,1,5,521,0,0,1,1,5,1,0,9,1,4,520,5,4,520,0,1,5,0,4,0,1,512,1,0,0]

def active13927 : List Nat := [1,2,8]

def tree13927 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13927 : H12WitnessSearch.Good tree13927 := H12GlobalWitnessIndex.good

theorem leafIdentity13927 : H12AffineFastState.composeSystem env13927 rootObs = leafEnv13927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13927 rootObs == leafEnv13927) = true)

theorem terminalChecked13927 : H12PackedTerminal.terminalCheckFast leafEnv13927 active13927 tree13927 = true := by decide +kernel

def env13928 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,4,8,1,1,3,5,523,0,0,1,1,4,3,9,5,522,5,5,522,0,1,5,0,0,512]

theorem envBound13928 : H12AffineFastState.Bounded env13928 := by
  intro p hp
  have h : env13928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13925_13928 : H12AffineEnvironment.transform 3 5 env13925 = env13928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env13925 == env13928) = true)

theorem identity13928 : scanCanonicalize (H12AffineFastState.compose env13928 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound13928 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13929 : List Nat := [2,4,8,5,1,5,9,4,8,1,3,4,8,1,1,3,5,3,0,0,1,1,4,3,9,5,2,5,5,2,0,1,5,0,0,8]

theorem envBound13929 : H12AffineFastState.Bounded env13929 := by
  intro p hp
  have h : env13929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13928_13929 : H12AffineEnvironment.transform 8 8 env13928 = env13929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env13928 == env13929) = true)

def leafEnv13929 : List Nat := [2,4,8,5,1,5,9,4,8,1,3,4,8,1,1,3,5,3,0,0,1,1,4,3,0,9,1,5,2,5,5,2,0,1,5,0,4,2,0,8,1,0,0]

def active13929 : List Nat := [0,1,2]

def tree13929 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13929 : H12WitnessSearch.Good tree13929 := H12GlobalWitnessIndex.good

theorem leafIdentity13929 : H12AffineFastState.composeSystem env13929 rootObs = leafEnv13929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13929 rootObs == leafEnv13929) = true)

theorem terminalChecked13929 : H12PackedTerminal.terminalCheckFast leafEnv13929 active13929 tree13929 = true := by decide +kernel

def env13930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115871,329867,17,95497,8328,64,64724,79131,102878,360791,61705,318684,257,95531,103567,120542]

theorem envBound13930 : H12AffineFastState.Bounded env13930 := by
  intro p hp
  have h : env13930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13892_13930 : H12AffineEnvironment.transform 23 95497 env13892 = env13930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env13892 == env13930) = true)

theorem identity13930 : scanCanonicalize (H12AffineFastState.compose env13930 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound13930 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38297,262144,1025,32769,4160,318548,17,41430,8328,64,64724,57796,17665,284040,61705,318684,257,41460,16464,513]

theorem envBound13931 : H12AffineFastState.Bounded env13931 := by
  intro p hp
  have h : env13931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13930_13931 : H12AffineEnvironment.transform 15 54495 env13930 = env13931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env13930 == env13931) = true)

def env13932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,4160,318548,17,41310,8192,64,64604,57676,17665,283904,61705,318548,257,41340,16464,513]

theorem envBound13932 : H12AffineFastState.Bounded env13932 := by
  intro p hp
  have h : env13932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13931_13932 : H12AffineEnvironment.transform 6 8 env13931 = env13932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13931 == env13932) = true)

theorem identity13932 : scanCanonicalize (H12AffineFastState.compose env13932 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound13932 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1025,32769,4160,62589,17,41310,8192,64,64604,57676,17665,32041,61705,62589,257,41340,16464,513]

theorem envBound13933 : H12AffineFastState.Bounded env13933 := by
  intro p hp
  have h : env13933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13932_13933 : H12AffineEnvironment.transform 17 10281 env13932 = env13933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13932 == env13933) = true)

theorem identity13933 : scanCanonicalize (H12AffineFastState.compose env13933 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13933 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env13934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,10281,1025,32769,4160,41340,17,41310,8192,64,43357,46157,4096,10280,41992,41340,257,41340,5457,513]

theorem envBound13934 : H12AffineFastState.Bounded env13934 := by
  intro p hp
  have h : env13934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13933_13934 : H12AffineEnvironment.transform 13 5377 env13933 = env13934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13933 == env13934) = true)

theorem identity13934 : scanCanonicalize (H12AffineFastState.compose env13934 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13934 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13935 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,32768,32803,37988,10281,1025,32769,4160,40969,17,41003,8192,64,43048,46157,4096,10280,41992,40969,116,40969,5156,513]

theorem envBound13935 : H12AffineFastState.Bounded env13935 := by
  intro p hp
  have h : env13935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13934_13935 : H12AffineEnvironment.transform 7 117 env13934 = env13935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13934 == env13935) = true)

theorem identity13935 : scanCanonicalize (H12AffineFastState.compose env13935 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound13935 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env13936 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,80,115,5172,10281,1025,81,4160,8281,17,8315,8192,64,10360,13341,4096,10280,9304,8281,116,8281,5156,513]

theorem envBound13936 : H12AffineFastState.Bounded env13936 := by
  intro p hp
  have h : env13936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13935_13936 : H12AffineEnvironment.transform 14 80 env13935 = env13936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env13935 == env13936) = true)

theorem identity13936 : scanCanonicalize (H12AffineFastState.compose env13936 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound13936 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env13937 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5236,80,115,5172,2128,1025,81,4160,32,17,2,121,64,2049,5220,4096,2129,1057,32,116,32,5156,513]

theorem envBound13937 : H12AffineFastState.Bounded env13937 := by
  intro p hp
  have h : env13937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13936_13937 : H12AffineEnvironment.transform 12 121 env13936 = env13937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env13936 == env13937) = true)

theorem identity13937 : scanCanonicalize (H12AffineFastState.compose env13937 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13937 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13938 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,121,1124,80,115,1060,2128,1025,81,80,32,17,2,121,64,2049,1140,16,2129,1057,32,116,32,1076,513]

theorem envBound13938 : H12AffineFastState.Bounded env13938 := by
  intro p hp
  have h : env13938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13937_13938 : H12AffineEnvironment.transform 11 16 env13937 = env13938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13937 == env13938) = true)

theorem identity13938 : scanCanonicalize (H12AffineFastState.compose env13938 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound13938 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env13939 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1125,16,121,1124,80,115,1060,1077,1025,81,80,32,17,2,121,64,1124,1140,16,1076,1057,32,116,32,1076,513]

theorem envBound13939 : H12AffineFastState.Bounded env13939 := by
  intro p hp
  have h : env13939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13938_13939 : H12AffineEnvironment.transform 10 1125 env13938 = env13939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env13938 == env13939) = true)

theorem identity13939 : scanCanonicalize (H12AffineFastState.compose env13939 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13939 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env13940 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,16,40,1077,1,34,1060,1077,1025,0,1,32,17,2,40,17,1077,1061,16,1076,1057,32,37,32,1076,513]

theorem envBound13940 : H12AffineFastState.Bounded env13940 := by
  intro p hp
  have h : env13940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13939_13940 : H12AffineEnvironment.transform 5 17 env13939 = env13940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13939 == env13940) = true)

theorem identity13940 : scanCanonicalize (H12AffineFastState.compose env13940 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13940 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13941 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1061,1,40,1060,1,34,1060,1060,1025,0,1,32,0,2,40,0,1060,1061,1,1061,1057,32,37,32,1061,513]

theorem envBound13941 : H12AffineFastState.Bounded env13941 := by
  intro p hp
  have h : env13941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13940_13941 : H12AffineEnvironment.transform 3 1 env13940 = env13941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13940 == env13941) = true)

theorem identity13941 : scanCanonicalize (H12AffineFastState.compose env13941 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound13941 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13942 : List Nat := [2,4,8,1,32,0,8,36,512,46,11,1,40,10,1,34,10,10,47,0,1,32,0,2,40,0,10,11,1,11,15,32,37,32,11,513]

theorem envBound13942 : H12AffineFastState.Bounded env13942 := by
  intro p hp
  have h : env13942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13941_13942 : H12AffineEnvironment.transform 9 46 env13941 = env13942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env13941 == env13942) = true)

theorem identity13942 : scanCanonicalize (H12AffineFastState.compose env13942 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13942 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13943 : List Nat := [2,4,8,1,11,0,8,15,512,5,11,1,3,10,1,9,10,10,4,0,1,11,0,2,3,0,10,11,1,11,15,11,14,11,11,513]

theorem envBound13943 : H12AffineFastState.Bounded env13943 := by
  intro p hp
  have h : env13943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13942_13943 : H12AffineEnvironment.transform 4 11 env13942 = env13943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13942 == env13943) = true)

theorem identity13943 : scanCanonicalize (H12AffineFastState.compose env13943 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13943 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13944 : List Nat := [2,0,8,1,11,0,8,11,512,1,11,1,3,10,1,9,10,10,0,0,1,11,0,2,3,0,10,11,1,11,11,11,10,11,11,513]

theorem envBound13944 : H12AffineFastState.Bounded env13944 := by
  intro p hp
  have h : env13944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13943_13944 : H12AffineEnvironment.transform 1 0 env13943 = env13944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13943 == env13944) = true)

theorem identity13944 : scanCanonicalize (H12AffineFastState.compose env13944 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13944 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13945 : List Nat := [2,0,2,1,1,0,2,1,512,1,1,1,3,0,1,3,0,0,0,0,1,1,0,2,3,0,0,1,1,1,1,1,0,1,1,513]

theorem envBound13945 : H12AffineFastState.Bounded env13945 := by
  intro p hp
  have h : env13945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13944_13945 : H12AffineEnvironment.transform 2 2 env13944 = env13945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13944 == env13945) = true)

theorem identity13945 : scanCanonicalize (H12AffineFastState.compose env13945 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound13945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13946 : List Nat := [1,0,1,1,1,0,1,1,512,1,1,1,0,0,1,0,0,0,0,0,1,1,0,1,0,0,0,1,1,1,1,1,0,1,1,513]

theorem envBound13946 : H12AffineFastState.Bounded env13946 := by
  intro p hp
  have h : env13946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13945_13946 : H12AffineEnvironment.transform 0 1 env13945 = env13946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env13945 == env13946) = true)

def env13947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,4160,318548,17,41311,8193,64,64605,57677,17665,283905,61705,318549,257,41341,16464,513]

theorem envBound13947 : H12AffineFastState.Bounded env13947 := by
  intro p hp
  have h : env13947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13931_13947 : H12AffineEnvironment.transform 6 9 env13931 = env13947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13931 == env13947) = true)

theorem identity13947 : scanCanonicalize (H12AffineFastState.compose env13947 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound13947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,35189,1025,32769,4160,21793,17,41311,8193,64,64605,57677,17665,56436,61705,21792,257,41341,16464,513]

theorem envBound13948 : H12AffineFastState.Bounded env13948 := by
  intro p hp
  have h : env13948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13947_13948 : H12AffineEnvironment.transform 17 35189 env13947 = env13948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env13947 == env13948) = true)

theorem identity13948 : scanCanonicalize (H12AffineFastState.compose env13948 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound13948 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env13949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28698,12636,11577,1025,9293,4160,21793,17,1299,8193,64,22545,17665,17665,30776,21829,21792,257,1329,16464,513]

theorem envBound13949 : H12AffineFastState.Bounded env13949 := by
  intro p hp
  have h : env13949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13948_13949 : H12AffineEnvironment.transform 14 9292 env13948 = env13949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env13948 == env13949) = true)

theorem identity13949 : scanCanonicalize (H12AffineFastState.compose env13949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1296,20806,4096,3173,1025,1297,4160,21793,17,1299,349,64,22545,17665,17665,22884,21829,21792,257,1329,16464,513]

theorem envBound13950 : H12AffineFastState.Bounded env13950 := by
  intro p hp
  have h : env13950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13949_13950 : H12AffineEnvironment.transform 12 348 env13949 = env13950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13949 == env13950) = true)

theorem identity13950 : scanCanonicalize (H12AffineFastState.compose env13950 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13950 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13951 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,16384,0,20806,4096,2421,273,1,4160,20529,17,3,349,64,22545,16401,16401,22884,20565,20528,257,33,16464,513]

theorem envBound13951 : H12AffineFastState.Bounded env13951 := by
  intro p hp
  have h : env13951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13950_13951 : H12AffineEnvironment.transform 9 272 env13950 = env13951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13950 == env13951) = true)

theorem identity13951 : scanCanonicalize (H12AffineFastState.compose env13951 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13951 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env13952 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,16,348,16384,0,16726,16,2421,273,1,80,16417,17,3,349,64,18433,16401,16401,18804,16453,16416,257,33,16464,513]

theorem envBound13952 : H12AffineFastState.Bounded env13952 := by
  intro p hp
  have h : env13952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13951_13952 : H12AffineEnvironment.transform 11 16 env13951 = env13952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13951 == env13952) = true)

theorem identity13952 : scanCanonicalize (H12AffineFastState.compose env13952 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13952 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env13953 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,16,121,16384,0,16499,16,2128,52,1,80,16417,17,3,120,64,18433,16401,16401,18513,16453,16416,36,33,16464,513]

theorem envBound13953 : H12AffineFastState.Bounded env13953 := by
  intro p hp
  have h : env13953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13952_13953 : H12AffineEnvironment.transform 7 37 env13952 = env13953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13952 == env13953) = true)

def env13954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound13954 : H12AffineFastState.Bounded env13954 := by
  intro p hp
  have h : env13954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13645_13954 : H12AffineEnvironment.transform 26 30393345 env13645 = env13954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env13645 == env13954) = true)

def env13955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound13955 : H12AffineFastState.Bounded env13955 := by
  intro p hp
  have h : env13955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13954_13955 : H12AffineEnvironment.transform 18 1024 env13954 = env13955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13954 == env13955) = true)

theorem identity13955 : scanCanonicalize (H12AffineFastState.compose env13955 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound13955 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,16777216,8328,64,29868033,16793754,8491334,8830976,25265169,21012950,256,25166010,25223454,25207751]

theorem envBound13956 : H12AffineFastState.Bounded env13956 := by
  intro p hp
  have h : env13956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13955_13956 : H12AffineEnvironment.transform 20 115734 env13955 = env13956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env13955 == env13956) = true)

def env13957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,95616,8328,64,13022593,79130,8491334,8830976,8450449,4314198,256,8484154,8492190,8508999]

theorem envBound13957 : H12AffineFastState.Bounded env13957 := by
  intro p hp
  have h : env13957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13956_13957 : H12AffineEnvironment.transform 23 95616 env13956 = env13957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95616 env13956 == env13957) = true)

def env13958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73856,8328,64,13022593,79130,8491334,8819968,8430737,4292950,256,8462394,8492190,8487751]

theorem envBound13958 : H12AffineFastState.Bounded env13958 := by
  intro p hp
  have h : env13958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13958 : H12AffineEnvironment.transform 13 5376 env13957 = env13958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13957 == env13958) = true)

def env13959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73856,8328,64,8828321,79130,8491334,8819968,8430737,98678,256,8462394,8492190,8487751]

theorem envBound13959 : H12AffineFastState.Bounded env13959 := by
  intro p hp
  have h : env13959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13958_13959 : H12AffineEnvironment.transform 21 32 env13958 = env13959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13958 == env13959) = true)

theorem identity13959 : scanCanonicalize (H12AffineFastState.compose env13959 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound13959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,98766,73856,8328,64,472175,79130,4232,464078,75103,98678,256,41460,5456,649]

theorem envBound13960 : H12AffineFastState.Bounded env13960 := by
  intro p hp
  have h : env13960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13959_13960 : H12AffineEnvironment.transform 22 98766 env13959 = env13960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env13959 == env13960) = true)

theorem identity13960 : scanCanonicalize (H12AffineFastState.compose env13960 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound13960 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env13961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1024,32769,102678,32,98766,73856,8328,64,203982,79130,4232,212079,75103,98678,256,41460,5456,649]

theorem envBound13961 : H12AffineFastState.Bounded env13961 := by
  intro p hp
  have h : env13961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13960_13961 : H12AffineEnvironment.transform 17 10401 env13960 = env13961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env13960 == env13961) = true)

theorem identity13961 : scanCanonicalize (H12AffineFastState.compose env13961 (packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13961 : packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102678,32,98630,73736,8192,64,203846,79130,4096,212079,75103,98678,256,41340,5456,513]

theorem envBound13962 : H12AffineFastState.Bounded env13962 := by
  intro p hp
  have h : env13962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13961_13962 : H12AffineEnvironment.transform 6 8 env13961 = env13962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13961 == env13962) = true)

theorem identity13962 : scanCanonicalize (H12AffineFastState.compose env13962 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound13962 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env13963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,65536,131072,10281,1024,8461,77850,32,73802,73736,8192,64,203846,79130,4096,212079,75103,73850,256,112,5456,513]

theorem envBound13963 : H12AffineFastState.Bounded env13963 := by
  intro p hp
  have h : env13963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13962_13963 : H12AffineEnvironment.transform 14 8460 env13962 = env13963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env13962 == env13963) = true)

theorem identity13963 : scanCanonicalize (H12AffineFastState.compose env13963 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound13963 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,65536,13341,10281,1024,8461,77850,32,73802,73736,8192,64,75867,79130,4096,67698,75103,73850,256,112,5456,513]

theorem envBound13964 : H12AffineFastState.Bounded env13964 := by
  intro p hp
  have h : env13964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13963_13964 : H12AffineEnvironment.transform 16 13341 env13963 = env13964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env13963 == env13964) = true)

theorem identity13964 : scanCanonicalize (H12AffineFastState.compose env13964 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13964 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,80,65536,5441,2421,1024,81,69958,32,65814,65876,348,64,67847,70726,4096,67698,66563,65830,256,112,5456,513]

theorem envBound13965 : H12AffineFastState.Bounded env13965 := by
  intro p hp
  have h : env13965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13964_13965 : H12AffineEnvironment.transform 12 348 env13964 = env13965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13964 == env13965) = true)

def env13966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,8388608,73856,8328,64,8828320,79130,8491334,8819968,8430737,98679,256,8462394,8492190,8487751]

theorem envBound13966 : H12AffineFastState.Bounded env13966 := by
  intro p hp
  have h : env13966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13958_13966 : H12AffineEnvironment.transform 21 33 env13958 = env13966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13958 == env13966) = true)

theorem identity13966 : scanCanonicalize (H12AffineFastState.compose env13966 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound13966 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,131072,262144,1024,32769,4296,33,8388608,41310,8328,64,8828320,46276,8392856,8819968,8430737,169,256,8430052,8394048,8389273]

theorem envBound13967 : H12AffineFastState.Bounded env13967 := by
  intro p hp
  have h : env13967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13966_13967 : H12AffineEnvironment.transform 15 33246 env13966 = env13967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env13966 == env13967) = true)

theorem identity13967 : scanCanonicalize (H12AffineFastState.compose env13967 (packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound13967 : packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env13968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,131072,262144,1024,32769,4296,33,16,41310,8328,64,439728,46276,4232,431376,42113,169,256,41460,5456,649]

theorem envBound13968 : H12AffineFastState.Bounded env13968 := by
  intro p hp
  have h : env13968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13967_13968 : H12AffineEnvironment.transform 22 16 env13967 = env13968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env13967 == env13968) = true)

theorem identity13968 : scanCanonicalize (H12AffineFastState.compose env13968 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13968 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env13969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,33,16,41310,8192,64,439608,46156,4096,431376,41993,33,256,41340,5456,513]

theorem envBound13969 : H12AffineFastState.Bounded env13969 := by
  intro p hp
  have h : env13969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13968_13969 : H12AffineEnvironment.transform 6 8 env13968 = env13969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13968 == env13969) = true)

theorem identity13969 : scanCanonicalize (H12AffineFastState.compose env13969 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13969 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env13970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,262144,1024,8541,4160,33,16,2,8192,64,398436,5392,4096,406604,1365,33,256,32,5456,513]

theorem envBound13970 : H12AffineFastState.Bounded env13970 := by
  intro p hp
  have h : env13970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13969_13970 : H12AffineEnvironment.transform 14 8540 env13969 = env13970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13969 == env13970) = true)

def env13971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73857,8328,64,13022593,79130,8491334,8819969,8430736,4292951,256,8462395,8492190,8487750]

theorem envBound13971 : H12AffineFastState.Bounded env13971 := by
  intro p hp
  have h : env13971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13971 : H12AffineEnvironment.transform 13 5377 env13957 = env13971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13957 == env13971) = true)

def env13972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73857,8328,64,8828321,79130,8491334,8819969,8430736,98679,256,8462395,8492190,8487750]

theorem envBound13972 : H12AffineFastState.Bounded env13972 := by
  intro p hp
  have h : env13972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13971_13972 : H12AffineEnvironment.transform 21 32 env13971 = env13972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13971 == env13972) = true)

theorem identity13972 : scanCanonicalize (H12AffineFastState.compose env13972 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98631) := by decide +kernel

theorem selectedBound13972 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73857,8328,64,472294,79130,4097,463942,75223,98679,256,41340,5593,513]

theorem envBound13973 : H12AffineFastState.Bounded env13973 := by
  intro p hp
  have h : env13973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13972_13973 : H12AffineEnvironment.transform 22 98631 env13972 = env13973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98631 env13972 == env13973) = true)

def env13974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73737,8192,64,472174,79130,4097,463942,75103,98679,256,41340,5457,513]

theorem envBound13974 : H12AffineFastState.Bounded env13974 := by
  intro p hp
  have h : env13974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13973_13974 : H12AffineEnvironment.transform 6 8 env13973 = env13974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13973 == env13974) = true)

def env13975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102679,32,98631,73737,8192,64,203846,79130,4097,212078,75103,98679,256,41340,5457,513]

theorem envBound13975 : H12AffineFastState.Bounded env13975 := by
  intro p hp
  have h : env13975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13974_13975 : H12AffineEnvironment.transform 17 10280 env13974 = env13975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13974 == env13975) = true)

theorem identity13975 : scanCanonicalize (H12AffineFastState.compose env13975 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 15672) := by decide +kernel

theorem selectedBound13975 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env13976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,15672,10280,1024,32769,102679,32,98631,73737,8192,64,74110,79130,4097,65878,75103,98679,256,41340,5457,513]

theorem envBound13976 : H12AffineFastState.Bounded env13976 := by
  intro p hp
  have h : env13976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13975_13976 : H12AffineEnvironment.transform 16 15672 env13975 = env13976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 15672 env13975 == env13976) = true)

theorem identity13976 : scanCanonicalize (H12AffineFastState.compose env13976 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound13976 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env13977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,2083,15672,10280,1024,32769,39220,32,35172,10282,8192,64,10589,15673,4097,2421,11644,35156,256,41340,5457,513]

theorem envBound13977 : H12AffineFastState.Bounded env13977 := by
  intro p hp
  have h : env13977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13976_13977 : H12AffineEnvironment.transform 15 2083 env13976 = env13977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env13976 == env13977) = true)

theorem identity13977 : scanCanonicalize (H12AffineFastState.compose env13977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound13977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9292,2083,15672,10280,1024,9293,15736,32,11560,10282,8192,64,10589,15673,4097,2421,11644,11544,256,1328,5457,513]

theorem envBound13978 : H12AffineFastState.Bounded env13978 := by
  intro p hp
  have h : env13978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13977_13978 : H12AffineEnvironment.transform 14 9292 env13977 = env13978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env13977 == env13978) = true)

theorem identity13978 : scanCanonicalize (H12AffineFastState.compose env13978 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound13978 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3384,5377,2420,2083,4096,1296,1024,2421,4160,32,16,1298,3384,64,1125,4097,4097,2421,68,32,256,1328,5457,513]

theorem envBound13979 : H12AffineFastState.Bounded env13979 := by
  intro p hp
  have h : env13979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13978_13979 : H12AffineEnvironment.transform 12 3384 env13978 = env13979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env13978 == env13979) = true)

theorem identity13979 : scanCanonicalize (H12AffineFastState.compose env13979 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound13979 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,41,5377,1125,1330,4096,1296,1024,1124,4160,32,16,1298,41,64,1125,4097,4097,1124,68,32,256,1328,5457,513]

theorem envBound13980 : H12AffineFastState.Bounded env13980 := by
  intro p hp
  have h : env13980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13979_13980 : H12AffineEnvironment.transform 10 1297 env13979 = env13980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env13979 == env13980) = true)

theorem identity13980 : scanCanonicalize (H12AffineFastState.compose env13980 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound13980 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env13981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1280,41,1,1125,1330,1280,1296,1024,1124,1344,32,16,1298,41,64,1125,1281,1281,1124,68,32,256,1328,81,513]

theorem envBound13981 : H12AffineFastState.Bounded env13981 := by
  intro p hp
  have h : env13981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13980_13981 : H12AffineEnvironment.transform 11 1280 env13980 = env13981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env13980 == env13981) = true)

theorem identity13981 : scanCanonicalize (H12AffineFastState.compose env13981 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13981 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env13982 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1297,1280,41,1,1076,1330,1280,1296,1024,1077,1297,32,16,1298,41,17,1076,1281,1281,1077,21,32,256,1328,0,513]

theorem envBound13982 : H12AffineFastState.Bounded env13982 := by
  intro p hp
  have h : env13982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13981_13982 : H12AffineEnvironment.transform 5 17 env13981 = env13982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13981 == env13982) = true)

theorem identity13982 : scanCanonicalize (H12AffineFastState.compose env13982 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13982 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env13983 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,1,1076,1047,1061,1077,1024,1077,1076,32,16,1079,41,17,1076,1060,1060,1077,21,32,37,1045,0,513]

theorem envBound13983 : H12AffineFastState.Bounded env13983 := by
  intro p hp
  have h : env13983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13982_13983 : H12AffineEnvironment.transform 7 37 env13982 = env13983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13982 == env13983) = true)

theorem identity13983 : scanCanonicalize (H12AffineFastState.compose env13983 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound13983 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env13984 : List Nat := [2,4,8,16,32,17,8,37,512,517,561,544,41,1,561,530,544,560,517,560,561,32,16,562,41,17,561,545,545,560,21,32,37,528,0,513]

theorem envBound13984 : H12AffineFastState.Bounded env13984 := by
  intro p hp
  have h : env13984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13983_13984 : H12AffineEnvironment.transform 9 517 env13983 = env13984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env13983 == env13984) = true)

theorem identity13984 : scanCanonicalize (H12AffineFastState.compose env13984 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13984 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13985 : List Nat := [2,4,8,16,32,17,8,37,49,52,0,17,41,1,0,35,17,1,52,1,0,32,16,3,41,17,0,16,16,1,21,32,37,33,0,48]

theorem envBound13985 : H12AffineFastState.Bounded env13985 := by
  intro p hp
  have h : env13985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13984_13985 : H12AffineEnvironment.transform 8 49 env13984 = env13985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13984 == env13985) = true)

theorem identity13985 : scanCanonicalize (H12AffineFastState.compose env13985 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13986 : List Nat := [2,4,8,16,17,17,8,20,0,5,0,17,24,1,0,18,17,1,5,1,0,17,16,3,24,17,0,16,16,1,21,17,20,16,0,1]

theorem envBound13986 : H12AffineFastState.Bounded env13986 := by
  intro p hp
  have h : env13986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13985_13986 : H12AffineEnvironment.transform 4 17 env13985 = env13986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13985 == env13986) = true)

theorem identity13986 : scanCanonicalize (H12AffineFastState.compose env13986 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13986 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13987 : List Nat := [2,4,8,0,1,1,8,4,0,5,0,1,8,1,0,2,1,1,5,1,0,1,0,3,8,1,0,0,0,1,5,1,4,0,0,1]

theorem envBound13987 : H12AffineFastState.Bounded env13987 := by
  intro p hp
  have h : env13987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13986_13987 : H12AffineEnvironment.transform 3 0 env13986 = env13987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13986 == env13987) = true)

def env13988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102679,32,98631,73737,8192,64,203847,79130,4097,212079,75103,98679,256,41340,5457,513]

theorem envBound13988 : H12AffineFastState.Bounded env13988 := by
  intro p hp
  have h : env13988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13974_13988 : H12AffineEnvironment.transform 17 10281 env13974 = env13988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13974 == env13988) = true)

theorem identity13988 : scanCanonicalize (H12AffineFastState.compose env13988 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13988 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env13989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,343,131072,10281,1024,32769,36928,32,32784,8542,8192,64,138512,13389,4097,146744,9224,32800,256,41340,5457,513]

theorem envBound13989 : H12AffineFastState.Bounded env13989 := by
  intro p hp
  have h : env13989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13988_13989 : H12AffineEnvironment.transform 15 343 env13988 = env13989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13988 == env13989) = true)

theorem identity13989 : scanCanonicalize (H12AffineFastState.compose env13989 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13989 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13990 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,262,131072,10281,1024,32769,36881,32,32784,8463,8192,17,138512,13340,4097,146744,9224,32800,256,41261,5376,513]

theorem envBound13990 : H12AffineFastState.Bounded env13990 := by
  intro p hp
  have h : env13990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13989_13990 : H12AffineEnvironment.transform 5 17 env13989 = env13990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13989 == env13990) = true)

theorem identity13990 : scanCanonicalize (H12AffineFastState.compose env13990 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound13990 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13991 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,262,13341,10281,1024,32769,36881,32,32784,8463,8192,17,10509,13340,4097,2341,9224,32800,256,41261,5376,513]

theorem envBound13991 : H12AffineFastState.Bounded env13991 := by
  intro p hp
  have h : env13991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13990_13991 : H12AffineEnvironment.transform 16 13341 env13990 = env13991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env13990 == env13991) = true)

theorem identity13991 : scanCanonicalize (H12AffineFastState.compose env13991 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13991 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13992 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,0,262,13341,10281,1024,1,4113,32,16,8463,8192,17,10509,13340,4097,2341,9224,32,256,8493,5376,513]

theorem envBound13992 : H12AffineFastState.Bounded env13992 := by
  intro p hp
  have h : env13992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13991_13992 : H12AffineEnvironment.transform 14 0 env13991 = env13992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13991 == env13992) = true)

theorem identity13992 : scanCanonicalize (H12AffineFastState.compose env13992 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6940) := by decide +kernel

theorem selectedBound13992 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env13993 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,6940,5377,0,262,3841,4917,1024,1,4113,32,16,6675,6940,17,4625,3840,4097,2341,7956,32,256,6705,5376,513]

theorem envBound13993 : H12AffineFastState.Bounded env13993 := by
  intro p hp
  have h : env13993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13992_13993 : H12AffineEnvironment.transform 12 6940 env13992 = env13993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6940 env13992 == env13993) = true)

theorem identity13993 : scanCanonicalize (H12AffineFastState.compose env13993 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound13993 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env13994 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,6940,4389,0,262,2853,4917,36,1,4113,32,16,6675,6940,17,4625,2852,4097,2341,6960,32,256,6705,4388,513]

theorem envBound13994 : H12AffineFastState.Bounded env13994 := by
  intro p hp
  have h : env13994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13993_13994 : H12AffineEnvironment.transform 9 36 env13993 = env13994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env13993 == env13994) = true)

theorem identity13994 : scanCanonicalize (H12AffineFastState.compose env13994 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound13994 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env13995 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,513,2333,804,0,262,2853,308,36,1,528,32,16,2066,2333,17,16,2852,512,2341,2353,32,256,2096,805,513]

theorem envBound13995 : H12AffineFastState.Bounded env13995 := by
  intro p hp
  have h : env13995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13994_13995 : H12AffineEnvironment.transform 11 513 env13994 = env13995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env13994 == env13995) = true)

theorem identity13995 : scanCanonicalize (H12AffineFastState.compose env13995 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound13995 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env13996 : List Nat := [2,4,8,16,32,17,8,256,512,36,820,513,553,804,0,262,17,308,36,1,528,32,16,806,553,17,16,16,512,529,517,32,256,772,805,513]

theorem envBound13996 : H12AffineFastState.Bounded env13996 := by
  intro p hp
  have h : env13996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13995_13996 : H12AffineEnvironment.transform 10 820 env13995 = env13996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env13995 == env13996) = true)

theorem identity13996 : scanCanonicalize (H12AffineFastState.compose env13996 (packedSelected [1,3,11] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound13996 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env13997 : List Nat := [2,4,8,16,32,17,8,256,293,36,17,292,268,1,0,262,17,308,36,1,309,32,16,3,268,17,16,16,293,308,288,32,256,33,0,292]

theorem envBound13997 : H12AffineFastState.Bounded env13997 := by
  intro p hp
  have h : env13997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13996_13997 : H12AffineEnvironment.transform 8 293 env13996 = env13997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env13996 == env13997) = true)

theorem identity13997 : scanCanonicalize (H12AffineFastState.compose env13997 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound13997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13998 : List Nat := [2,4,8,16,32,17,8,53,16,36,17,17,57,1,0,51,17,1,36,1,0,32,16,3,57,17,16,16,16,1,21,32,53,33,0,17]

theorem envBound13998 : H12AffineFastState.Bounded env13998 := by
  intro p hp
  have h : env13998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13997_13998 : H12AffineEnvironment.transform 7 53 env13997 = env13998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env13997 == env13998) = true)

theorem identity13998 : scanCanonicalize (H12AffineFastState.compose env13998 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13999 : List Nat := [2,4,8,16,0,17,8,21,16,4,17,17,25,1,0,19,17,1,4,1,0,0,16,3,25,17,16,16,16,1,21,0,21,1,0,17]

theorem envBound13999 : H12AffineFastState.Bounded env13999 := by
  intro p hp
  have h : env13999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13998_13999 : H12AffineEnvironment.transform 4 0 env13998 = env13999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13998 == env13999) = true)

theorem identity13999 : scanCanonicalize (H12AffineFastState.compose env13999 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14000 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,0,8,1,0,2,0,1,4,1,0,0,1,3,8,0,1,1,1,1,4,0,4,1,0,0]

theorem envBound14000 : H12AffineFastState.Bounded env14000 := by
  intro p hp
  have h : env14000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13999_14000 : H12AffineEnvironment.transform 3 1 env13999 = env14000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13999 == env14000) = true)

def env14001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73736,8193,64,472175,79130,4097,463942,75102,98679,256,41340,5456,513]

theorem envBound14001 : H12AffineFastState.Bounded env14001 := by
  intro p hp
  have h : env14001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13973_14001 : H12AffineEnvironment.transform 6 9 env13973 = env14001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13973 == env14001) = true)

theorem identity14001 : scanCanonicalize (H12AffineFastState.compose env14001 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound14001 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,102679,32,98631,73736,8193,64,262516,79130,4097,270685,75102,98679,256,41340,5456,513]

theorem envBound14002 : H12AffineFastState.Bounded env14002 := by
  intro p hp
  have h : env14002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14001_14002 : H12AffineEnvironment.transform 16 79131 env14001 = env14002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env14001 == env14002) = true)

theorem identity14002 : scanCanonicalize (H12AffineFastState.compose env14002 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound14002 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9293,65536,79131,262144,1024,9292,79194,32,75018,73736,8193,64,262516,79130,4097,270685,75102,75066,256,1329,5456,513]

theorem envBound14003 : H12AffineFastState.Bounded env14003 := by
  intro p hp
  have h : env14003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14002_14003 : H12AffineEnvironment.transform 14 9293 env14002 = env14003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env14002 == env14003) = true)

theorem identity14003 : scanCanonicalize (H12AffineFastState.compose env14003 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 68915) := by decide +kernel

theorem selectedBound14003 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env14004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9293,65536,79131,68915,1024,9292,79194,32,75018,73736,8193,64,68679,79130,4097,76910,75102,75066,256,1329,5456,513]

theorem envBound14004 : H12AffineFastState.Bounded env14004 := by
  intro p hp
  have h : env14004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14003_14004 : H12AffineEnvironment.transform 17 68915 env14003 = env14004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68915 env14003 == env14004) = true)

theorem identity14004 : scanCanonicalize (H12AffineFastState.compose env14004 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14004 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14005 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8540,65536,77834,67618,273,8541,77899,32,73755,73736,8193,64,67926,77835,4097,76159,73807,73771,256,32,4161,513]

theorem envBound14005 : H12AffineFastState.Bounded env14005 := by
  intro p hp
  have h : env14005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14004_14005 : H12AffineEnvironment.transform 9 273 env14004 = env14005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14004 == env14005) = true)

theorem identity14005 : scanCanonicalize (H12AffineFastState.compose env14005 (packedSelected [1,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound14005 : packedSelected [1,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14006 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,4096,8192,4112,8540,65536,77834,65798,273,8541,77899,32,73755,73736,8193,64,65650,77835,4097,73819,73807,73771,256,32,4161,513]

theorem envBound14006 : H12AffineFastState.Bounded env14006 := by
  intro p hp
  have h : env14006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14005_14006 : H12AffineEnvironment.transform 10 292 env14005 = env14006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env14005 == env14006) = true)

theorem identity14006 : scanCanonicalize (H12AffineFastState.compose env14006 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14006 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14007 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,4096,269,4112,81,65536,69895,65798,273,80,69958,32,65814,65797,268,64,65650,69894,4097,65878,65858,65830,256,32,4161,513]

theorem envBound14007 : H12AffineFastState.Bounded env14007 := by
  intro p hp
  have h : env14007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14006_14007 : H12AffineEnvironment.transform 12 269 env14006 = env14007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14006 == env14007) = true)

theorem identity14007 : scanCanonicalize (H12AffineFastState.compose env14007 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound14007 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env14008 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,356,269,372,81,65536,65635,65798,273,80,65570,32,65814,65797,268,64,65650,65634,357,65878,65858,65830,256,32,293,513]

theorem envBound14008 : H12AffineFastState.Bounded env14008 := by
  intro p hp
  have h : env14008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14007_14008 : H12AffineEnvironment.transform 11 356 env14007 = env14008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env14007 == env14008) = true)

theorem identity14008 : scanCanonicalize (H12AffineFastState.compose env14008 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14008 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14009 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,17,120,1,81,65536,65635,65651,100,80,65570,32,65635,65648,121,64,65650,65634,16,65571,65591,65619,117,32,80,513]

theorem envBound14009 : H12AffineFastState.Bounded env14009 := by
  intro p hp
  have h : env14009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14008_14009 : H12AffineEnvironment.transform 7 117 env14008 = env14009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14008 == env14009) = true)

theorem identity14009 : scanCanonicalize (H12AffineFastState.compose env14009 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound14009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14010 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,17,120,1,81,115,16,0,100,80,81,32,16,3,121,64,1,17,16,80,68,32,117,32,80,513]

theorem envBound14010 : H12AffineFastState.Bounded env14010 := by
  intro p hp
  have h : env14010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14009_14010 : H12AffineEnvironment.transform 15 115 env14009 = env14010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env14009 == env14010) = true)

def env14011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,8388608,73857,8328,64,8828320,79130,8491334,8819969,8430736,98678,256,8462395,8492190,8487750]

theorem envBound14011 : H12AffineFastState.Bounded env14011 := by
  intro p hp
  have h : env14011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13971_14011 : H12AffineEnvironment.transform 21 33 env13971 = env14011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13971 == env14011) = true)

theorem identity14011 : scanCanonicalize (H12AffineFastState.compose env14011 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound14011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4160,33,8388608,41430,8328,64,8828320,46157,8392721,8819969,8430736,33,256,8429932,8394185,8389137]

theorem envBound14012 : H12AffineFastState.Bounded env14012 := by
  intro p hp
  have h : env14012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14011_14012 : H12AffineEnvironment.transform 15 33111 env14011 = env14012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env14011 == env14012) = true)

def env14013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146864,1024,32769,4160,33,8388608,41430,8328,64,8423440,46157,8392721,8431793,8430736,33,256,8429932,8394185,8389137]

theorem envBound14013 : H12AffineFastState.Bounded env14013 := by
  intro p hp
  have h : env14013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14012_14013 : H12AffineEnvironment.transform 17 146864 env14012 = env14013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env14012 == env14013) = true)

theorem identity14013 : scanCanonicalize (H12AffineFastState.compose env14013 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 136585) := by decide +kernel

theorem selectedBound14013 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146864,1024,32769,4160,33,136585,41430,8328,64,171417,46157,132504,179512,176409,33,256,177381,131136,137112]

theorem envBound14014 : H12AffineFastState.Bounded env14014 := by
  intro p hp
  have h : env14014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14013_14014 : H12AffineEnvironment.transform 22 136585 env14013 = env14014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136585 env14013 == env14014) = true)

theorem identity14014 : scanCanonicalize (H12AffineFastState.compose env14014 (packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14014 : packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env14015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146744,1024,32769,4160,33,136449,41310,8192,64,171281,46157,132368,179512,176409,33,256,177261,131136,136976]

theorem envBound14015 : H12AffineFastState.Bounded env14015 := by
  intro p hp
  have h : env14015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14014_14015 : H12AffineEnvironment.transform 6 8 env14014 = env14015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14014 == env14015) = true)

theorem identity14015 : scanCanonicalize (H12AffineFastState.compose env14015 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound14015 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env14016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,13389,2421,1024,32769,4160,33,8524,41310,8192,64,43356,46157,12637,35189,34132,33,256,32800,13325,9053]

theorem envBound14016 : H12AffineFastState.Bounded env14016 := by
  intro p hp
  have h : env14016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14015_14016 : H12AffineEnvironment.transform 16 13389 env14015 = env14016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env14015 == env14016) = true)

theorem identity14016 : scanCanonicalize (H12AffineFastState.compose env14016 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14016 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env14017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13389,2421,1024,8541,4160,33,8524,2,8192,64,2048,5393,12637,10281,9224,33,256,8572,13325,9053]

theorem envBound14017 : H12AffineFastState.Bounded env14017 := by
  intro p hp
  have h : env14017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14016_14017 : H12AffineEnvironment.transform 14 8540 env14016 = env14017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14016 == env14017) = true)

theorem identity14017 : scanCanonicalize (H12AffineFastState.compose env14017 (packedSelected [1,2,3,4,5,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14017 : packedSelected [1,2,3,4,5,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1024,0,4160,33,17,2,349,64,2048,5393,4096,2420,1365,33,256,33,5456,512]

theorem envBound14018 : H12AffineFastState.Bounded env14018 := by
  intro p hp
  have h : env14018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14017_14018 : H12AffineEnvironment.transform 12 349 env14017 = env14018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14017 == env14018) = true)

theorem identity14018 : scanCanonicalize (H12AffineFastState.compose env14018 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3962) := by decide +kernel

theorem selectedBound14018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3962,349,2683,1,342,2666,2421,1024,0,3898,33,17,2,349,64,2048,2667,3962,2420,1365,33,256,33,2602,512]

theorem envBound14019 : H12AffineFastState.Bounded env14019 := by
  intro p hp
  have h : env14019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14018_14019 : H12AffineEnvironment.transform 11 3962 env14018 = env14019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3962 env14018 == env14019) = true)

theorem identity14019 : scanCanonicalize (H12AffineFastState.compose env14019 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14019 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14020 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,3930,349,2651,1,342,2634,2389,1024,0,3866,1,17,2,349,64,2048,2635,3930,2388,1365,1,256,1,2570,512]

theorem envBound14020 : H12AffineFastState.Bounded env14020 := by
  intro p hp
  have h : env14020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14019_14020 : H12AffineEnvironment.transform 4 0 env14019 = env14020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14019 == env14020) = true)

theorem identity14020 : scanCanonicalize (H12AffineFastState.compose env14020 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound14020 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14021 : List Nat := [2,4,8,16,0,64,8,256,512,1024,260,1630,349,863,1,342,846,81,1024,0,1566,1,17,2,349,64,260,847,1630,80,1365,1,256,1,782,512]

theorem envBound14021 : H12AffineFastState.Bounded env14021 := by
  intro p hp
  have h : env14021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14020_14021 : H12AffineEnvironment.transform 10 260 env14020 = env14021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env14020 == env14021) = true)

theorem identity14021 : scanCanonicalize (H12AffineFastState.compose env14021 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound14021 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14022 : List Nat := [2,4,8,16,0,64,8,256,512,527,260,81,349,863,1,342,846,81,527,0,17,1,17,2,349,64,260,847,81,80,858,1,256,1,782,512]

theorem envBound14022 : H12AffineFastState.Bounded env14022 := by
  intro p hp
  have h : env14022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14021_14022 : H12AffineEnvironment.transform 9 527 env14021 = env14022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env14021 == env14022) = true)

theorem identity14022 : scanCanonicalize (H12AffineFastState.compose env14022 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14022 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14023 : List Nat := [2,4,8,16,0,17,8,256,512,527,260,0,268,782,1,263,799,0,527,0,17,1,17,2,268,17,260,798,0,1,779,1,256,1,782,512]

theorem envBound14023 : H12AffineFastState.Bounded env14023 := by
  intro p hp
  have h : env14023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14022_14023 : H12AffineEnvironment.transform 5 17 env14022 = env14023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14022 == env14023) = true)

theorem identity14023 : scanCanonicalize (H12AffineFastState.compose env14023 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 286) := by decide +kernel

theorem selectedBound14023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14024 : List Nat := [2,4,8,16,0,17,8,256,286,273,260,0,268,16,1,263,1,0,273,0,17,1,17,2,268,17,260,0,0,1,21,1,256,1,16,286]

theorem envBound14024 : H12AffineFastState.Bounded env14024 := by
  intro p hp
  have h : env14024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14023_14024 : H12AffineEnvironment.transform 8 286 env14023 = env14024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 286 env14023 == env14024) = true)

theorem identity14024 : scanCanonicalize (H12AffineFastState.compose env14024 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound14024 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14025 : List Nat := [2,4,8,16,0,17,8,15,17,30,11,0,3,16,1,8,1,0,30,0,17,1,17,2,3,17,11,0,0,1,21,1,15,1,16,17]

theorem envBound14025 : H12AffineFastState.Bounded env14025 := by
  intro p hp
  have h : env14025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14024_14025 : H12AffineEnvironment.transform 7 15 env14024 = env14025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env14024 == env14025) = true)

theorem identity14025 : scanCanonicalize (H12AffineFastState.compose env14025 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound14025 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14026 : List Nat := [2,4,8,9,0,8,8,15,8,7,11,0,3,9,1,8,1,0,7,0,8,1,8,2,3,8,11,0,0,1,12,1,15,1,9,8]

theorem envBound14026 : H12AffineFastState.Bounded env14026 := by
  intro p hp
  have h : env14026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14025_14026 : H12AffineEnvironment.transform 3 9 env14025 = env14026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env14025 == env14026) = true)

theorem identity14026 : scanCanonicalize (H12AffineFastState.compose env14026 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound14026 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env14027 : List Nat := [2,4,1,0,0,1,1,6,1,7,2,0,3,0,1,1,1,0,7,0,1,1,1,2,3,1,2,0,0,1,5,1,6,1,0,1]

theorem envBound14027 : H12AffineFastState.Bounded env14027 := by
  intro p hp
  have h : env14027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14026_14027 : H12AffineEnvironment.transform 2 1 env14026 = env14027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env14026 == env14027) = true)

theorem identity14027 : scanCanonicalize (H12AffineFastState.compose env14027 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound14027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14028 : List Nat := [2,3,1,0,0,1,1,1,1,0,2,0,3,0,1,1,1,0,0,0,1,1,1,2,3,1,2,0,0,1,2,1,1,1,0,1]

theorem envBound14028 : H12AffineFastState.Bounded env14028 := by
  intro p hp
  have h : env14028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14027_14028 : H12AffineEnvironment.transform 1 3 env14027 = env14028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env14027 == env14028) = true)

def env14029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146865,1024,32769,4160,33,8388608,41430,8328,64,8423441,46157,8392721,8431792,8430736,33,256,8429932,8394185,8389137]

theorem envBound14029 : H12AffineFastState.Bounded env14029 := by
  intro p hp
  have h : env14029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14012_14029 : H12AffineEnvironment.transform 17 146865 env14012 = env14029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env14012 == env14029) = true)

theorem identity14029 : scanCanonicalize (H12AffineFastState.compose env14029 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 136448) := by decide +kernel

theorem selectedBound14029 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146865,1024,32769,4160,33,136448,41430,8328,64,171281,46157,132369,179632,176528,33,256,177260,131273,136977]

theorem envBound14030 : H12AffineFastState.Bounded env14030 := by
  intro p hp
  have h : env14030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14029_14030 : H12AffineEnvironment.transform 22 136448 env14029 = env14030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env14029 == env14030) = true)

theorem identity14030 : scanCanonicalize (H12AffineFastState.compose env14030 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14030 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env14031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,5392,10401,1024,32769,4160,33,16,41430,8328,64,34817,46157,4097,43168,42112,33,256,41340,5593,513]

theorem envBound14031 : H12AffineFastState.Bounded env14031 := by
  intro p hp
  have h : env14031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14030_14031 : H12AffineEnvironment.transform 16 5392 env14030 = env14031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14030 == env14031) = true)

theorem identity14031 : scanCanonicalize (H12AffineFastState.compose env14031 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14031 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env14032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,1,342,5392,10401,1024,0,4160,33,16,8663,8328,64,2048,13388,4097,10401,9345,33,256,8573,5593,513]

theorem envBound14032 : H12AffineFastState.Bounded env14032 := by
  intro p hp
  have h : env14032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14031_14032 : H12AffineEnvironment.transform 14 1 env14031 = env14032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14031 == env14032) = true)

theorem identity14032 : scanCanonicalize (H12AffineFastState.compose env14032 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14032 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,1,342,5392,2556,1024,0,4160,33,16,138,469,64,2048,5393,4097,2556,1500,33,256,32,5593,513]

theorem envBound14033 : H12AffineFastState.Bounded env14033 := by
  intro p hp
  have h : env14033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14032_14033 : H12AffineEnvironment.transform 12 349 env14032 = env14033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14032 == env14033) = true)

theorem identity14033 : scanCanonicalize (H12AffineFastState.compose env14033 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14033 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14034 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,1,263,5392,2477,1024,0,4113,33,16,138,388,17,2048,5393,4097,2477,1421,33,256,32,5512,513]

theorem envBound14034 : H12AffineFastState.Bounded env14034 := by
  intro p hp
  have h : env14034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14033_14034 : H12AffineEnvironment.transform 5 17 env14033 = env14034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14033 == env14034) = true)

theorem identity14034 : scanCanonicalize (H12AffineFastState.compose env14034 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14034 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14035 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,4096,268,4405,1,263,4388,2477,52,0,4113,33,16,138,388,17,2048,4389,4097,2477,441,33,256,32,4540,513]

theorem envBound14035 : H12AffineFastState.Bounded env14035 := by
  intro p hp
  have h : env14035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14034_14035 : H12AffineEnvironment.transform 9 52 env14034 = env14035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14034 == env14035) = true)

theorem identity14035 : scanCanonicalize (H12AffineFastState.compose env14035 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14035 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14036 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,4096,160,4249,1,171,4232,2049,52,0,4113,33,16,138,40,17,2048,4233,4097,2049,21,33,172,32,4112,513]

theorem envBound14036 : H12AffineFastState.Bounded env14036 := by
  intro p hp
  have h : env14036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14035_14036 : H12AffineEnvironment.transform 7 172 env14035 = env14036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14035 == env14036) = true)

def env14037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,95617,8328,64,13022592,79131,8491334,8830976,8450448,4314199,256,8484155,8492191,8508998]

theorem envBound14037 : H12AffineFastState.Bounded env14037 := by
  intro p hp
  have h : env14037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13956_14037 : H12AffineEnvironment.transform 23 95617 env13956 = env14037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95617 env13956 == env14037) = true)

def env14038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73857,8328,64,13022592,79131,8491334,8819968,8430736,4292951,256,8462395,8492191,8487750]

theorem envBound14038 : H12AffineFastState.Bounded env14038 := by
  intro p hp
  have h : env14038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14038 : H12AffineEnvironment.transform 13 5376 env14037 = env14038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14037 == env14038) = true)

def env14039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73857,8328,64,8828320,79131,8491334,8819968,8430736,98679,256,8462395,8492191,8487750]

theorem envBound14039 : H12AffineFastState.Bounded env14039 := by
  intro p hp
  have h : env14039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14038_14039 : H12AffineEnvironment.transform 21 32 env14038 = env14039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14038 == env14039) = true)

def env14040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73737,8192,64,8828200,79131,8491334,8819968,8430616,98679,256,8462395,8492055,8487750]

theorem envBound14040 : H12AffineFastState.Bounded env14040 := by
  intro p hp
  have h : env14040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14039_14040 : H12AffineEnvironment.transform 6 8 env14039 = env14040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14039 == env14040) = true)

def env14041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,16,73737,8192,64,439608,79131,102742,431376,41992,98679,256,73771,103431,99158]

theorem envBound14041 : H12AffineFastState.Bounded env14041 := by
  intro p hp
  have h : env14041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14040_14041 : H12AffineEnvironment.transform 22 16 env14040 = env14041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14040 == env14041) = true)

theorem identity14041 : scanCanonicalize (H12AffineFastState.compose env14041 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound14041 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4161,32,16,41310,8192,64,439608,46156,4097,431376,41992,32,256,41340,5456,513]

theorem envBound14042 : H12AffineFastState.Bounded env14042 := by
  intro p hp
  have h : env14042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14041_14042 : H12AffineEnvironment.transform 15 33111 env14041 = env14042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env14041 == env14042) = true)

theorem identity14042 : scanCanonicalize (H12AffineFastState.compose env14042 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound14042 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env14043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,262144,1024,32769,4161,32,16,41310,8192,64,262517,46156,4097,270685,41992,32,256,41340,5456,513]

theorem envBound14043 : H12AffineFastState.Bounded env14043 := by
  intro p hp
  have h : env14043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14042_14043 : H12AffineEnvironment.transform 16 46157 env14042 = env14043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env14042 == env14043) = true)

theorem identity14043 : scanCanonicalize (H12AffineFastState.compose env14043 (packedSelected [2,3,5,6,10,12,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound14043 : packedSelected [2,3,5,6,10,12,18,23,38] rootPS < 2^1333 := by decide +kernel

def env14044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,46157,35188,1024,32769,4161,32,16,41310,8192,64,34817,46156,4097,43049,41992,32,256,41340,5456,513]

theorem envBound14044 : H12AffineFastState.Bounded env14044 := by
  intro p hp
  have h : env14044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14043_14044 : H12AffineEnvironment.transform 17 35188 env14043 = env14044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env14043 == env14044) = true)

theorem identity14044 : scanCanonicalize (H12AffineFastState.compose env14044 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14044 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,13388,2421,1024,0,4161,32,16,8543,8192,64,2048,13389,4097,10280,9225,32,256,8573,5456,513]

theorem envBound14045 : H12AffineFastState.Bounded env14045 := by
  intro p hp
  have h : env14045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14044_14045 : H12AffineEnvironment.transform 14 1 env14044 = env14045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14044 == env14045) = true)

theorem identity14045 : scanCanonicalize (H12AffineFastState.compose env14045 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14045 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env14046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5392,2421,1024,0,4161,32,16,3,348,64,2048,5393,4097,2420,1365,32,256,33,5456,513]

theorem envBound14046 : H12AffineFastState.Bounded env14046 := by
  intro p hp
  have h : env14046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14045_14046 : H12AffineEnvironment.transform 12 348 env14045 = env14046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14045 == env14046) = true)

theorem identity14046 : scanCanonicalize (H12AffineFastState.compose env14046 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound14046 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,869,348,1637,1,342,1653,2421,1024,0,804,32,16,3,348,64,2048,1652,868,2420,1365,32,256,33,1589,513]

theorem envBound14047 : H12AffineFastState.Bounded env14047 := by
  intro p hp
  have h : env14047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14046_14047 : H12AffineEnvironment.transform 11 869 env14046 = env14047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env14046 == env14047) = true)

def env14048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,17,73737,8192,64,439609,79131,102743,431377,41993,98679,256,73770,103430,99159]

theorem envBound14048 : H12AffineFastState.Bounded env14048 := by
  intro p hp
  have h : env14048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14040_14048 : H12AffineEnvironment.transform 22 17 env14040 = env14048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14040 == env14048) = true)

theorem identity14048 : scanCanonicalize (H12AffineFastState.compose env14048 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound14048 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,102678,32,17,73737,8192,64,203846,79131,102743,212078,41993,98679,256,73770,103430,99159]

theorem envBound14049 : H12AffineFastState.Bounded env14049 := by
  intro p hp
  have h : env14049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14048_14049 : H12AffineEnvironment.transform 17 108927 env14048 = env14049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env14048 == env14049) = true)

theorem identity14049 : scanCanonicalize (H12AffineFastState.compose env14049 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound14049 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,46156,108927,1024,32769,102678,32,17,73737,8192,64,108554,79131,102743,100386,41993,98679,256,73770,103430,99159]

theorem envBound14050 : H12AffineFastState.Bounded env14050 := by
  intro p hp
  have h : env14050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14049_14050 : H12AffineEnvironment.transform 16 46156 env14049 = env14050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env14049 == env14050) = true)

theorem identity14050 : scanCanonicalize (H12AffineFastState.compose env14050 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14050 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env14051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,46156,35189,1024,32769,45340,32,17,3,8192,64,34816,5393,45405,43048,41993,41341,256,32,46092,41821]

theorem envBound14051 : H12AffineFastState.Bounded env14051 := by
  intro p hp
  have h : env14051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14050_14051 : H12AffineEnvironment.transform 15 8202 env14050 = env14051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14050 == env14051) = true)

theorem identity14051 : scanCanonicalize (H12AffineFastState.compose env14051 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14051 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,263,38209,35189,1024,32769,36881,32,17,3,269,64,34816,5393,36944,35109,34052,32880,256,32,38145,33360]

theorem envBound14052 : H12AffineFastState.Bounded env14052 := by
  intro p hp
  have h : env14052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14051_14052 : H12AffineEnvironment.transform 12 269 env14051 = env14052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14051 == env14052) = true)

theorem identity14052 : scanCanonicalize (H12AffineFastState.compose env14052 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound14052 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env14053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1076,263,4469,3393,1024,1077,5157,32,17,3,269,64,3124,5393,5220,3345,304,1092,256,32,4405,1636]

theorem envBound14053 : H12AffineFastState.Bounded env14053 := by
  intro p hp
  have h : env14053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14052_14053 : H12AffineEnvironment.transform 14 1076 env14052 = env14053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env14052 == env14053) = true)

def env14054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73736,8193,64,8828201,79131,8491334,8819968,8430617,98679,256,8462395,8492054,8487750]

theorem envBound14054 : H12AffineFastState.Bounded env14054 := by
  intro p hp
  have h : env14054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14039_14054 : H12AffineEnvironment.transform 6 9 env14039 = env14054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14039 == env14054) = true)

def env14055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,16,73736,8193,64,439609,79131,102742,431376,41993,98679,256,73771,103430,99158]

theorem envBound14055 : H12AffineFastState.Bounded env14055 := by
  intro p hp
  have h : env14055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14054_14055 : H12AffineEnvironment.transform 22 16 env14054 = env14055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14054 == env14055) = true)

theorem identity14055 : scanCanonicalize (H12AffineFastState.compose env14055 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14055 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,45341,32,16,3,8193,64,439609,5392,45405,431376,41993,41340,256,32,46093,41821]

theorem envBound14056 : H12AffineFastState.Bounded env14056 := by
  intro p hp
  have h : env14056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14055_14056 : H12AffineEnvironment.transform 15 8203 env14055 = env14056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14055 == env14056) = true)

theorem identity14056 : scanCanonicalize (H12AffineFastState.compose env14056 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound14056 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,46157,262144,1024,32769,45341,32,16,3,8193,64,262516,5392,45405,270685,41993,41340,256,32,46093,41821]

theorem envBound14057 : H12AffineFastState.Bounded env14057 := by
  intro p hp
  have h : env14057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14056_14057 : H12AffineEnvironment.transform 16 46157 env14056 = env14057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env14056 == env14057) = true)

end H12CloudChart0